#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger.h"
#include "game/actor/logic/actor_logic_state_machine.h"

namespace actor {


  //#####################################################################


  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor)
  {

  }

  ActorControl::~ActorControl()
  {

  }

  void ActorControl::Update(float delta_time)
  {
    //for Debug quick watch
    Actor* debug_actor = actor_;
    ActorData* debug_actor_data = actor_->GetActorData();
    
    UpdateAuto();
    UpdateManual();
    
    //apply control data
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
//     ActorControlData* user_control_data = actor_->GetActorData()->GetControlData();
//     ActorControlData* routine_control_data = actor_->GetActorData()->GetRoutineControlData();
// 
//     ApplyControlData(user_control_data, control_data);
//     ApplyControlData(routine_control_data, control_data);

    eActorLogicState result_logic_state_type = DecideLogicState();
    if (ControlLogicStateChange(result_logic_state_type))
    {
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][Update] ControlLogicStateChange PASS result_logic_state_type:%d control_priority:%d", result_logic_state_type, control_data->GetMaxPriority());
      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type));
    }
  }


  //decide logic state, this will be checked every update
  eActorLogicState ActorControl::DecideLogicState()
  {
    if (actor_->GetIsActorAlive() == false)
    {
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][DecideLogicState] actor dead");
      return kActorLogicStateDead;
    }

//     switch (actor_->GetActorData()->GetControlData()->GetMaxPriority())
//     {
//     case kActorControlPriorityMoveAuto:
//     case kActorControlPriorityMoveManual:
//       return kActorLogicStateMove;
//       break;
//     case kActorControlPriorityAttackNormalAuto:
//     case kActorControlPriorityAttackPowerAuto:
//     case kActorControlPriorityAttackNormalManual:
//     case kActorControlPriorityAttackSpecialAuto:
//     case kActorControlPriorityAttackSpecialManual:
//       return kActorLogicStateAttack;
//       break;
//     case kActorControlPriorityIncontrollable:
//       return kActorLogicStateIncontrollable;
//       break;
//     case kActorControlPriorityMin:
//       return kActorLogicStateIdle;  //nothing set
//       break;
//     case kActorControlPriorityMax:
//     default:
//       assert(false);  //error priority
//       break;
//     }


    switch (actor_->GetActorData()->GetControlData()->GetMaxPriorityOperationType())
    {
    case kActorControlOperationPositionMove:
    case kActorControlOperationIdTargetMove:
      return kActorLogicStateMove;
      break;
    case kActorControlOperationIdTargetAttack:
    case kActorControlOperationIdSkill:
      return kActorLogicStateAttack;
      break;
    case kActorControlOperationTypeIncontrollable:
      return kActorLogicStateIncontrollable;
      break;
    case kActorControlOperation:
      return kActorLogicStateIdle;  //nothing set
      break;
    default:
      assert(false);  //error type
      break;
    }

    return kActorLogicState;
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState next_logic_state_type)
  {
    eActorLogicState current_logic_state_type = (eActorLogicState)actor_->GetActorData()->GetActorStatus(kActorStatusLogicState);

    if (current_logic_state_type == next_logic_state_type
      || current_logic_state_type == kActorLogicStateDead
      || next_logic_state_type == kActorLogicState)
      return false;

    switch (next_logic_state_type)
    {
    case kActorLogicStateMove:
      if (actor_->GetActorData()->GetActorStatusBool(kActorLogicStatusCanMove) == false)
      {
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetMove);
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationPositionMove);
        return false;
      }
      break;
    case kActorLogicStateAttack:
      if (actor_->GetActorData()->GetActorStatusBool(kActorLogicStatusCanAttack) == false)
      {
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdSkill);  //can't attack at all
        return false;
      }
      break;
    }

    return true;
  }



  void ActorControl::UpdateManual()
  {
    //nothing special
  }

  void ActorControl::UpdateAuto()
  {
    if (actor_->GetActorData()->GetActorStatusBool(kActorControlStatusIsAuto) //preset AUTO (enemy)
      || (actor_->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport && GetIsAllyActorAuto())) //User + AUTO On
    {
      if (actor_->GetActorData()->GetActorStatus(kActorControlStatusAutoReleaseSpecialSkillType) != kActorControlAutoReleaseSkillInvalid)
      {
        UpdateAutoReleaseSkill();
      }

      if (actor_->GetActorData()->GetActorStatus(kActorStatusLogicState) == kActorLogicStateIdle
        && actor_->GetActorData()->GetActorStatus(kActorControlStatusAutoGuardType) != kActorControlAutoGuardInvalid)
      {
        UpdateAutoGuard();
      }
    }
  }


  void ActorControl::UpdateAutoGuard()
  {
    //check trigger
    ActorTrigger* guard_trigger = actor_->GetActorData()->GetSkillData()->GetGuardTriggerAuto();
    if (guard_trigger)
    {
      guard_trigger->Update();
      if (guard_trigger->GetIsTriggered())
      {
        switch(actor_->GetActorData()->GetActorStatus(kActorControlStatusAutoGuardType))
        {
        case kActorControlAutoGuardDefault:
          switch (actor_->GetActorData()->GetActorStatus(kActorSkillStatusAttackType))
          {
          case kActorAttackMelee:
            {
              if (actor_->GetActorData()->GetActorStatus(kActorStatusCareer) == kActorCareerWarrior)
                UpdateAutoGuardMelee(guard_trigger);//for melee character
              if (actor_->GetActorData()->GetActorStatus(kActorStatusCareer) == kActorCareerKnight)
                UpdateAutoGuardMeleeX(guard_trigger);//special for home defenders
            }
            break;
          case kActorAttackRanged:
            if (rand() > 0.7f * RAND_MAX) 
              UpdateAutoGuardRangedNearestX(guard_trigger); //for ranged character
            else
              UpdateAutoGuardRangedNearestY(guard_trigger); //for ranged character
            break;
          }
          break;
        case kActorControlAutoGuardPreferY:
          switch (actor_->GetActorData()->GetActorStatus(kActorSkillStatusAttackType))
          {
          case kActorAttackMelee:
            UpdateAutoGuardMeleeY(guard_trigger); //special for home defenders
            break;
          case kActorAttackRanged:
            UpdateAutoGuardRangedNearestY(guard_trigger); //for ranged character
            break;
          }
          break;
        case kActorControlAutoGuard:
        default:
          assert(false);
          break;
        }
      }
    }
  }


  void ActorControl::UpdateAutoReleaseSkill()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
    ActorSkillData* skill_data = actor_->GetActorData()->GetSkillData();

    int skill_id_special = actor_->GetActorData()->GetSkillData()->GetSkillIdByType(kActorSkillSpecial);

    if (skill_id_special == ACTOR_INVALID_ID || actor_->GetActorData()->GetActorStatusBool(kActorLogicStatusCanAttackSpecial) == false)
      return;

    switch (actor_->GetActorData()->GetActorStatus(kActorControlStatusAutoReleaseSpecialSkillType))
    {
    case kActorControlAutoReleaseSkillWithPause:
      {
        if (skill_data->GetIsSpecialSkillReady() == true)
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill WithPause PASS AutoReleaseSpecialSkill");
          AutoReleaseSpecialSkill(actor_->GetScriptObjectId());//more directly
        }
      }
      break;
    case kActorControlAutoReleaseSkillNoPause:
      {
        if (skill_data->GetIsSpecialSkillReady() == true)
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill NoPause PASS SetSkill:%d", skill_id_special);
          actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdSkill, kActorControlPriorityAttackSpecialAuto, skill_id_special);
        }
      }
      break;
    case kActorControlAutoReleaseSkillWithProbability:
      {
        if (actor_->GetActorData()->GetActorStatus(kActorStatusLogicState) == kActorLogicStateIdle
          && ((rand() % 100) < actor_->GetActorData()->GetActorStatus(kActorControlStatusAutoReleaseSpecialSkillProbability) * 100))
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill WithProbability PASS SetSkill:%d", skill_id_special);
          actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdSkill, kActorControlPriorityAttackSpecialAuto, skill_id_special);
        }
      }
      break;
    case kActorControlAutoReleaseSkillByAttackCount:
      {
        int count = actor_->GetActorData()->GetActorStatus(kActorControlStatusAutoReleaseSpecialSkillCount);
        if (actor_->GetActorData()->GetActorStatus(kActorStatusLogicState) == kActorLogicStateIdle
          && (int)actor_->GetActorData()->GetActorAttribute(kActorSkillAttributeAttackCount) % count == (count - 1))
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill WithProbability PASS SetSkill:%d", skill_id_special);
          actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdSkill, kActorControlPriorityAttackSpecialAuto, skill_id_special);
        }
      }
      break;
    case kActorControlAutoReleaseSkill:
    default:
      assert(false);
      break;
    }
  }

  void ActorControl::UpdateAutoGuardMelee(ActorTrigger* guard_trigger)
  {
    int target_id = *(guard_trigger->GetTriggeredActorIdList()->begin());
    actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id); //move to target
    actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoGuardMelee] target_id:%d", target_id);
  }

  void ActorControl::UpdateAutoGuardMeleeX(ActorTrigger* guard_trigger)
  {
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    int target_id = -1;
    float target_position_x_min = 9999999;
    eActorAnimationDirection home_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection);
    float home_position_x = (home_direction == kActorAnimationDirectionLeft ? 0 : 1500);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      if (target_position_x_min > abs(home_position_x - target_position.x))
      {
        target_position_x_min = abs(home_position_x - target_position.x);
        target_id = target_actor->GetScriptObjectId();
      }
      ++iterator;
    }

    if (target_id >= 0 && target_position_x_min > 0)
    {
      //move to target
      actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id);
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoGuardMeleeX] target_id:%d", target_id);
    }
  }


  void ActorControl::UpdateAutoGuardMeleeY(ActorTrigger* guard_trigger)
  {
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    int target_id = -1;
    bool has_same_grid_y_target = false;
    float target_distance_min = 9999999;
    cocos2d::CCPoint actor_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
    int actor_grid_y= GetGridYFromPositionY(actor_position.y);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

      float target_distance = actor_position.getDistance(target_position);
      bool is_same_grid_y_target = (GetGridYFromPositionY(target_position.y) == actor_grid_y);

      if ( (has_same_grid_y_target == false && is_same_grid_y_target == true) //same grid y first, highest priority
        || (has_same_grid_y_target == is_same_grid_y_target && target_distance_min > target_distance) ) //then distance
      {
        target_distance_min = target_distance;
        has_same_grid_y_target = is_same_grid_y_target;
        target_id = target_actor->GetScriptObjectId();
      }

      ++iterator;
    }

    if (target_id >= 0 && target_distance_min > 0)
    {
      //move to target
      actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id);
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoGuardMeleeY] target_id:%d", target_id);
    }
  }

  void ActorControl::UpdateAutoGuardRangedNearestX(ActorTrigger* guard_trigger)
  {
    // -- the grid-y of the closest to home enemy
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    int target_grid_y = -1;
    float target_position_x_min = 9999999;
    eActorAnimationDirection home_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection);
    float home_position_x = (home_direction == kActorAnimationDirectionLeft ? 0 : 1500);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      if (target_position_x_min > abs(home_position_x - target_position.x))
      {
        target_position_x_min = abs(home_position_x - target_position.x);
        target_grid_y = GetGridYFromPositionY(target_position.y);
      }
      ++iterator;
    }

    if (target_grid_y > 0 && target_position_x_min > 0)
    {
      bool is_grid_y_valid[GRID_Y_RANGE] = {false, false, false};
      is_grid_y_valid[target_grid_y - 1] = true;
      actor_->GetActorData()->GetLog()->AddLog("[ActorControl][UpdateAutoGuardRangedNearestX]");
      ApplyAutoRangedPosition(is_grid_y_valid);
    }
  }

  void ActorControl::UpdateAutoGuardRangedNearestY(ActorTrigger* guard_trigger)
  {
    // -- the least-moving-possible-grid-y change
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    bool is_grid_y_valid[GRID_Y_RANGE] = {false, false, false};

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      int target_grid_y = GetGridYFromPositionY(target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).y);
      is_grid_y_valid[target_grid_y - 1] = true;
      ++iterator;
    }

    actor_->GetActorData()->GetLog()->AddLog("[ActorControl][UpdateAutoGuardRangedNearestY]");
    ApplyAutoRangedPosition(is_grid_y_valid);
  }

  void ActorControl::ApplyAutoRangedPosition(bool is_grid_y_valid[])  //find the valid position close to home base line
  {
    cocos2d::CCPoint actor_grid = GetGridFromPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));
    if (is_grid_y_valid[(int)(actor_grid.y) - 1])
      return; // target and actor already in row

    //set target Grid to home base line
    eActorAnimationDirection actor_home_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection);
    cocos2d::CCPoint target_grid = ccp(actor_home_direction == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT : GRID_X_RANGE_RIGHT, actor_grid.y);

    //find best grid (is_grid_y_valid + nearest available)
    bool is_target_grid_position_valid = false;
    float target_grid_distance_min = 99999;
    cocos2d::CCPoint target_grid_position;

    //std::list<cocos2d::CCPoint>* valid_grid_list = actor_->GetActorData()->GetSpecifiedData()->GetValidGridList(actor_->GetActorExtEnv()->GetActorExtGrid()->GetActorGridList());
    std::list<cocos2d::CCPoint>* valid_grid_list = actor_->GetActorExtEnv()->GetActorExtGrid()->GetValidGridList(actor_);
    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;
        if (is_grid_y_valid[(int)(grid_position.y) - 1])
        {
          float target_grid_distance = grid_position.getDistance(target_grid);
          if (target_grid_distance < target_grid_distance_min)
          {
            is_target_grid_position_valid = true;
            target_grid_distance_min = target_grid_distance;
            target_grid_position = grid_position;
          }
        }
        ++iterator;
      }
    }

    delete valid_grid_list;

    //move to grid
    if (is_target_grid_position_valid)
    {
      actor_->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveManual, GetPositionFromGrid(target_grid_position));

      actor_->GetActorExtEnv()->GetActorExtGrid()->GetActorGridList()->push_back(std::pair<Actor*, cocos2d::CCPoint>(actor_, target_grid_position));  //prevent another actor move to 
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][ApplyAutoRangedPosition] target_grid_position:(%f,%f)", target_grid_position.x, target_grid_position.y);
    }
  }


  void ActorControl::UpdateSpecialGuard(int type)
  {
    //check trigger
    ActorTrigger* guard_trigger = actor_->GetActorData()->GetSkillData()->GetGuardTriggerAuto();
    if (guard_trigger)
    {
      bool is_pause = guard_trigger->GetIsPause();
      guard_trigger->SetIsPause(false);
      guard_trigger->Update();
      if (guard_trigger->GetIsTriggered())
      {
        switch (type)
        {
        case 0:
        default:
          switch (actor_->GetActorData()->GetActorStatus(kActorSkillStatusAttackType))
          {
          case kActorAttackMelee:
            {
              Actor* target_actor = *(guard_trigger->GetTriggeredActorList()->begin());
              float distance = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).getDistance(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));
              if (distance <= taomee::battle::kMapTileMaxLength * 3)
              {
                int target_id = target_actor->GetScriptObjectId();
                actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id); //move to target
                actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateSpecialGuard] type:%d, target_id:%d", type, target_id);
              }
            }
            break;
          }
          break;
        }
      }
      guard_trigger->SetIsPause(is_pause);
    }
  }



  void ActorControl::ApplyControlData(ActorControlData* from_control_data, ActorControlData* to_control_data)
  {
//     if (!from_control_data || !to_control_data)
//     {
//       assert(false);
//       return;
//     }
// 
//     if (from_control_data->IsSet())
//     {
//       if (from_control_data->IsSetPosition())
//       {
//         cocos2d::CCPoint set_position = from_control_data->GetPosition();
//         eActorControlPriority control_priority = from_control_data->GetPositionPriority();
//         to_control_data->SetPosition(set_position, control_priority);
//       }
// 
//       if (from_control_data->IsSetTarget())
//       {
//         int set_target = from_control_data->GetTarget();
//         eActorControlPriority control_priority = from_control_data->GetTargetPriority();
//         to_control_data->SetTarget(set_target, control_priority);
//       }
// 
//       if (from_control_data->IsSetSkill())
//       {
//         int set_skill = from_control_data->GetSkill();
//         eActorControlPriority control_priority = from_control_data->GetSkillPriority();
//         to_control_data->SetSkill(set_skill, control_priority);
//       }
// 
//       if (from_control_data->IsSetIncontrollable())
//       {
//         eActorControlIncontrollableType set_incontrollable = from_control_data->GetIncontrollable();
//         eActorControlPriority control_priority = from_control_data->GetIncontrollablePriority();
//         to_control_data->SetIncontrollable(set_incontrollable, control_priority);
//       }
// 
//       from_control_data->Reset(); //clear from data
//     }
  }

} // namespace actor