#ifndef ACTOR_BUFF_H
#define ACTOR_BUFF_H

#include "game/actor/actor_adapter.h"
#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;



  //effect needed link data
//   typedef struct tActorEffectLinkData {
//     int     effect_key;
//     int     effect_id;     // --> Effect Data Table
// 
//     int     buff_key;
//     int     buff_id;       // --> Buff Data Table
//     
//     int     actor_id;      //from
//     int     actor_level;
//     
//     int     skill_id;      // --> Skill Data Table
//     int     skill_level;
//   } ActorEffectLinkData;




  //Difference from ActorBuffData: 
  //    access to higher interface (actor | ext_env)
  //    provide higher interface
  //    don't bother the data directly
  //maintain buff interaction
  class ActorBuff
  {
  public:
    ActorBuff(Actor* actor_);
    ~ActorBuff();

    void Update(float delta_time);

    //add buff from data table, return is added
    bool AddBuff(int buff_id, int source_actor_id = ACTOR_INVALID_ID, int source_skill_id = ACTOR_INVALID_ID, int source_skill_level = 0);
    void RemoveBuff(int buff_key);
    
    void AddQuickBuff(std::string buff_script_arguments_string, int skill_level = 0);

    //not in use
//     void ProcessAddDamage(DamagePackage* damage_package, int buff_id);
//     void ProcessReduceDamage(DamagePackage* damage_package, int buff_id);
  private:
    Actor* actor_;

    std::map<int, int> buff_key_map_; //buff_key - buff_id | the buff related to this actor
  };

} // namespace actor


#endif // ACTOR_BUFF_H