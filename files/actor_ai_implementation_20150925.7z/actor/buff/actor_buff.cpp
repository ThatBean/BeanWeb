#include "actor_buff.h"

#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

#define SCRIPT_OBJECT_LUA "script/actor/script_object.lua"

namespace actor {

  //ActorBuff
  ActorBuff::ActorBuff(Actor* actor)
    :actor_(actor)
  {
    
  }

  ActorBuff::~ActorBuff()
  {
    
  }

  void ActorBuff::Update(float delta_time)
  { 
    ActorBuffData* buff_data = actor_->GetActorData()->GetBuffData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    //update incontrollable
    buff_data->UpdateIncontrollable();

    //check if incontrollable
    if (actor_->GetActorData()->GetActorStatusBool(kActorLogicStatusIsIncontrollable) == true)
      control_data->AddIdOperation(kActorControlOperationTypeIncontrollable, kActorControlPriorityIncontrollable, kActorControlIncontrollableBuff);  //mute other operation with higher priority
    else
      control_data->RemoveOperationData(kActorControlOperationTypeIncontrollable);

    //update shader
    actor_->GetActorData()->SetActorStatus(kActorBuffStatusShaderType, buff_data->UpdateShader());
  }

  bool ActorBuff::AddBuff(int buff_id, int source_actor_id, int source_skill_id, int source_skill_level)
  {
    ActorBuffData* actor_buff_data = actor_->GetActorData()->GetBuffData();
    
    BuffData* buff_data = DataManager::GetInstance().GetBuffDataTable()->GetBuff(buff_id);

    //from data table
    std::string slot_string = buff_data->GetSlot();
    eActorSlotResolveType slot_resolve_type = eActorSlotResolveType(buff_data->GetSlotResolveType());
    std::string effect_id_list_string = buff_data->GetEffectIdList();
    std::string buff_script_name = buff_data->GetScriptName();
    std::string buff_script_arguments_string = buff_data->GetScriptArg();

    if (buff_script_name == "buff_quick_attribute") 
    {
      //// no script, special for displayable actor buff
      //change attribute_id by (base * skill_level + add)
      //fire and forget

      AddQuickBuff(buff_script_arguments_string, source_skill_level);
      return true;
    }

    //check slot valid
    std::list<std::string>* slot_list = ActorStringSplit(slot_string, std::string("|,"));
    std::list<std::string>::iterator iterator;
    assert(slot_list->size() > 0);
    iterator = slot_list->begin();
    while (iterator != slot_list->end())
    {
      int buff_slot = atoi(iterator->c_str());
      if (actor_buff_data->ResolveSlot(buff_slot) == false)
      {
        delete slot_list; //delete parsed slot list
        return false;
      }

      iterator++;
    }

    //buff control register
    int buff_key = LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", actor_->GetScriptObjectId(), 
      "AddBuff", 
      effect_id_list_string, 
      buff_script_name, 
      buff_script_arguments_string);

    if (buff_key == ACTOR_INVALID_ID) 
    {
      delete slot_list; //delete parsed slot list
      return false;
    }

    //occupy slot
    iterator = slot_list->begin();
    while (iterator != slot_list->end())
    {
      int buff_slot = atoi(iterator->c_str());
      int replaced_buff_key = actor_buff_data->ReserveSlot(buff_slot, buff_key, slot_resolve_type);
      if (replaced_buff_key != ACTOR_INVALID_ID) RemoveBuff(replaced_buff_key);

      iterator++;
    }

    buff_key_map_[buff_key] = buff_id;

    delete slot_list; //delete parsed slot list
    return true;
  }



  void ActorBuff::RemoveBuff(int buff_key)
  {
    if (buff_key == ACTOR_INVALID_ID) return;

    ActorBuffData* actor_buff_data = actor_->GetActorData()->GetBuffData();

    //release slot
    int buff_slot = 0;
    actor_buff_data->ReleaseSlot(buff_slot);
    
    //buff control register
    actor_->CallScriptObjectFunction(std::string("RemoveBuff"), buff_key);

    buff_key_map_.erase(buff_key);

  }
  

  void ActorBuff::AddQuickBuff(std::string buff_script_arguments_string, int skill_level)
  {
    //// no script, special for displayable actor buff
    //change attribute_id by (base * skill_level + add)
    //fire and forget

    std::list<std::string>* attribute_mod_string_list = ActorStringSplit(buff_script_arguments_string, std::string("|"));
    std::list<std::string>::iterator iterator;
    iterator = attribute_mod_string_list->begin();
    while (iterator != attribute_mod_string_list->end())
    {
      std::list<std::string>* attribute_mod_list = ActorStringSplit(*iterator, std::string(","));
      std::list<std::string>::iterator it = attribute_mod_list->begin();

      int attribute_id = atoi(it->c_str());
      it++;
      float value_base = String2Float(*it);
      it++;
      float value_add = String2Float(*it);

      eActorAttributeType attribute_type = eActorAttributeType(attribute_id);
      float value_final = value_add * skill_level + value_add;

      actor_->GetActorData()->AddActorAttribute(attribute_type, value_final);

      delete attribute_mod_list;
      iterator++;
    }

    delete attribute_mod_string_list;
  }
  
  
  //ActorBuff

} // namespace actor