#ifndef ACTOR_DATA_TYPEDEF_H
#define ACTOR_DATA_TYPEDEF_H

#include "game/actor/actor_adapter.h"

namespace actor {

  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_CIRCLE = "attack_range_circle_red.png";
  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_BOX = "attack_red.png";


  const int ACTOR_INVALID_ID = -1;


  const float ACTOR_WEAK_THRESHOLD = 0.20f; //health ratio

  const float ACTOR_CONTROL_COUNTDOWN = 0.5f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_GUARD = 0.1f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_ATTACK = 0.05f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_DEAD = 1.5f; //control update interval, in second.


  const int GRID_Y_RANGE = 3;
  const int GRID_Y_RANGE_TOP = 1;
  const int GRID_Y_RANGE_MIDDLE = 2;
  const int GRID_Y_RANGE_BOTTOM = 3;
//   const int GRID_Y_RANGE_MIDDLE = (GRID_Y_RANGE_TOP + GRID_Y_RANGE) * 0.5;
//   const int GRID_Y_RANGE_BOTTOM = GRID_Y_RANGE_TOP + (GRID_Y_RANGE - 1);

  const int GRID_X_RANGE = 6;
  const int GRID_X_RANGE_LEFT = 1;
  //const float GRID_X_RANGE_MIDDLE = 3.5;
  const int GRID_X_RANGE_RIGHT = 6;
  const int GRID_X_RANGE_LEFT_MIDDLE = 2;
  const int GRID_X_RANGE_RIGHT_MIDDLE = 5;
//   const float GRID_X_RANGE_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE) * 0.5;
//   const int GRID_X_RANGE_RIGHT = GRID_X_RANGE_LEFT + (GRID_X_RANGE - 1);
//   const int GRID_X_RANGE_LEFT_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE_MIDDLE) * 0.5;
//   const int GRID_X_RANGE_RIGHT_MIDDLE = (GRID_X_RANGE_MIDDLE + GRID_X_RANGE_RIGHT) * 0.5;


  // for player controlled actor in PVE
  const int PLAYER_IDLE_VALID_GRID_X_RANGE = 4;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = 4;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = 3;
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = GRID_X_RANGE_LEFT + (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = GRID_X_RANGE_RIGHT - (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);


  const float ACTOR_DIRECTION_CHANGE_THRESHOLD = 20;  //the minimum distance needed for a direction change

  const float ACTOR_ANIMATION_HEALTH_DISPLAY_TIME = 2.0f; //The health display time

} // namespace actor

namespace actor {

  enum eActorModuleType
  {
    kActorModuleAnimation = 1 << 0,
    kActorModuleData      = 1 << 1,
    kActorModuleControl   = 1 << 2,
    kActorModuleBuff      = 1 << 3,
    kActorModuleLogic     = 1 << 4,
    kActorModuleMotion    = 1 << 5,
    kActorModuleScriptExporter    = 1 << 6,
    //kActorModule = 1 << 0,
    kActorModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_MODEL_ACTOR = 0
    | kActorModuleAnimation
    | kActorModuleData
    | kActorModuleControl
    | kActorModuleBuff
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleScriptExporter
    | 0;

  const unsigned long ACTOR_MODEL_EFFECT = 0
    | kActorModuleAnimation
    | kActorModuleData
    | kActorModuleScriptExporter
    | 0;

  const unsigned long ACTOR_MODEL_DATA = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | 0;


  //data dependency
  const unsigned long ACTOR_DATA_DEPENDENCY_BASIC = 0
    | kActorModuleLogic
    | kActorModuleMotion
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_SKILL = 0
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_BUFF = 0
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_DAMAGE = 0
    | kActorModuleAnimation
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_CONTROL = 0
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleBuff
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleScriptExporter
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_LOGIC = 0
    | kActorModuleLogic
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_MOTION = 0
    | kActorModuleAnimation
    | kActorModuleMotion
    | 0;


  enum eActorAnimationModuleType
  {
    kActorAnimationModuleSkeletonAnimation  = 1 << 0,
    kActorAnimationModuleOverheadLayer      = 1 << 1,
    kActorAnimationModuleBottomSyncLayer    = 1 << 2,
    //kActorAnimationModule = 1 << 0,
    kActorAnimationModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR = 0
    | kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleOverheadLayer
    | kActorAnimationModuleBottomSyncLayer
    | 0;

  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR_LITE = 0
    | kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleOverheadLayer
    | 0;

  const unsigned long ACTOR_ANIMATION_MODEL_EFFECT = 0
//     | kActorAnimationModuleSkeletonAnimation
//     | kActorAnimationModuleOverheadLayer
//     | kActorAnimationModuleBottomSyncLayer
    | 0;

  const unsigned long ACTOR_ANIMATION_MODEL_DATA = 0
//     | kActorAnimationModuleSkeletonAnimation
//     | kActorAnimationModuleOverheadLayer
//     | kActorAnimationModuleBottomSyncLayer
    | 0;

}



namespace actor {
  
//BELOW WILL BE EXPORTED TO LUA IN [actor_script_exporter.pkg]
//BELOW WILL BE EXPORTED TO LUA IN [actor_script_exporter.pkg]
//BELOW WILL BE EXPORTED TO LUA IN [actor_script_exporter.pkg]

  enum eActorModelType
  {
    kActorModelActor = ACTOR_MODEL_ACTOR,
    kActorModelEffect = ACTOR_MODEL_EFFECT,
    kActorModelData = ACTOR_MODEL_DATA,
    //kActorModel = 1 << 0,
    kActorModel = -1
  };

  enum eActorAnimationModelType
  {
    kActorAnimationModelActor = ACTOR_ANIMATION_MODEL_ACTOR,
    kActorAnimationModelActorLite = ACTOR_ANIMATION_MODEL_ACTOR_LITE,
    kActorAnimationModelEffect = ACTOR_ANIMATION_MODEL_EFFECT,
    kActorAnimationModelData = ACTOR_ANIMATION_MODEL_DATA,
    //kActorAnimationModel = 1 << 0,
    kActorAnimationModel = -1
  };

  enum eActorDataClassType
  {
    kActorDataClassAttribute = 1,
    kActorDataClassStatus,
    kActorDataClassPosition,
    kActorDataClass = -1
  };

  
  //from 1 to 9999
  enum eActorAttributeType  //independent float value
  {
    kActorAttributeInvalid = 0, //min

    //basic
    kActorAttributeTimeActive,

    kActorAttributeGuardAreaRadius, //by the number of grid, not pixel
    kActorAttributeGuardAreaWidth, //by the number of grid, not pixel
    kActorAttributeGuardAreaHeight, //by the number of grid, not pixel

    kActorAttributeAttackAreaRadius, //by the number of grid, not pixel
    kActorAttributeAttackAreaWidth, //by the number of grid, not pixel
    kActorAttributeAttackAreaHeight, //by the number of grid, not pixel

    //Health & Energy
    kActorAttributeHealthCurrent,  //battle only
    kActorAttributeEnergyCurrent,
    kActorAttributeHealthMax,  //normal
    kActorAttributeEnergyMax,

    //Factor
    kActorAttributeFactorCritical,
    kActorAttributeFactorHit,
    kActorAttributeFactorDodge,

    //Speed
    kActorAttributeSpeedAttack,
    kActorAttributeSpeedMove,

    //Damage Related
    kActorAttributeAttackPhysical,
    kActorAttributeAttackMagical,
    kActorAttributeAttackCritical,

    kActorAttributeDefensePhysical,
    kActorAttributeDefenseMagical,
    kActorAttributeDefenseCritical,

    //kActorAttributeDamage,
    kActorAttributeDamageAddition,  //for all kinds, applied last
    kActorAttributeDamageAdditionPhysical,
    kActorAttributeDamageAdditionMagical,
    kActorAttributeDamageAdditionCritical,
    kActorAttributeDamageAdditionIce,
    kActorAttributeDamageAdditionFire,
    kActorAttributeDamageAdditionWind,
    kActorAttributeDamageAdditionHealth,
    kActorAttributeDamageAdditionEnergy,

    kActorAttributeDamageReduction, //for all kinds, applied last
    kActorAttributeDamageReductionPhysical,
    kActorAttributeDamageReductionMagical,
    kActorAttributeDamageReductionCritical,
    kActorAttributeDamageReductionIce,
    kActorAttributeDamageReductionFire,
    kActorAttributeDamageReductionWind,
    kActorAttributeDamageReductionHealth,
    kActorAttributeDamageReductionEnergy,

    kActorLogicAttributeInvalid = 1000,

    kActorMotionAttributeInvalid = 2000,

    kActorControlAttributeInvalid = 3000,

    kActorBuffAttributeInvalid = 4000,

    kActorSkillAttributeInvalid = 5000,
    kActorSkillAttributeAttackCount,
    kActorSkillAttributeAttackNormalCount,
    kActorSkillAttributeAttackPowerCount,
    kActorSkillAttributeAttackSpecialCount,

    kActorAnimationAttributeInvalid = 6000,

    kActorSpecifiedAttributeInvalid = 7000,

    kActorLinkAttributeInvalid = 19000,  //for data link back to source(where this Actor is created)
    kActorLinkAttributeValue, //a data store slot

    kActorAttribute = 9999  //max
  };


  //from 10000 to 19999
  enum eActorStatusType  //independent bool/enum/int value
  {
    kActorStatusInvalid = 10000,  //min
    
    //Basic
    kActorStatusActorModel, //eActorModelType
    kActorStatusAnimationModel, //eActorAnimationModelType
    kActorStatusActorId,
    kActorStatusLevel,
    kActorStatusAppearance,
    kActorStatusFaction,
    kActorStatusCareer,
    kActorStatusCardId,

    kActorStatusGuardAreaType, //eActorPredefinedGuardTriggerType
    kActorStatusAttackAreaType, //eActorPredefinedAttackTriggerType

    kActorStatusLogicState,
    kActorStatusMotionState,

    kActorStatusDisableUserOperation,

    //AcceptDamage(Immune = do not accept)
    kActorStatusAcceptDamage,
    kActorStatusAcceptDamagePhysical,
    kActorStatusAcceptDamageMagical,
    kActorStatusAcceptDamageCritical,
    kActorStatusAcceptDamageIce,
    kActorStatusAcceptDamageFire,
    kActorStatusAcceptDamageWind,

    //Logic & Motion
    kActorLogicStatusInvalid = 11000,
    kActorLogicStatusIsIncontrollable,
    kActorLogicStatusCanMove,
    kActorLogicStatusCanAttack,
    kActorLogicStatusCanAttackNormal,
    kActorLogicStatusCanAttackPower,
    kActorLogicStatusCanAttackSpecial,

    kActorMotionStatusInvalid = 12000,
    kActorMotionStatusIsBusy,  //IsMotionAnimationEnded

    kActorControlStatusInvalid = 13000,
    kActorControlStatusIsAuto,
    kActorControlStatusIsManual,
    kActorControlStatusIsCounterAttack,
    kActorControlStatusAutoGuardType,
    kActorControlStatusAutoReleaseSpecialSkillType,
    kActorControlStatusAutoReleaseSpecialSkillCount,
    kActorControlStatusAutoReleaseSpecialSkillProbability,

    kActorBuffStatusInvalid = 14000,
    kActorBuffStatusShaderType,
    kActorBuffStatusIsPauseAnimation,
    kActorBuffStatusIsChangeColor,

    kActorSkillStatusInvalid = 15000,
    kActorSkillStatusCurrentSkillId,
    kActorSkillStatusIsBusy,
    kActorSkillStatusIsPaused,
    kActorSkillStatusGuardType,
    kActorSkillStatusAttackType,

    kActorAnimationStatusInvalid = 16000,
    kActorAnimationStatusIsPaused,
    kActorAnimationStatusDirection,
    kActorAnimationStatusIsHealthChanged,

    kActorSpecifiedStatusInvalid = 17000,
    kActorSpecifiedStatusHomeDirection,
    kActorSpecifiedStatusIsLimitGridX,

    kActorLinkStatusInvalid = 19000,  //for data link back to source(where this Actor is created)
    kActorLinkStatusScriptObjectId,  //--> Reference to ExtEnv, dynamic data
    kActorLinkStatusScriptObjectIdActor,
    kActorLinkStatusScriptObjectIdBuff,
    //kActorLinkStatusScriptObjectIdSkill,  //not yet
    kActorLinkStatusScriptObjectIdEffect,
    
    kActorLinkStatusDataIdActor,  //--> Reference to Data Table, static data
    kActorLinkStatusDataIdBuff,
    kActorLinkStatusDataIdSkill,
    kActorLinkStatusDataIdEffect,

    kActorLinkStatusLevelActor, //quick access, record and prevent dynamic data lost(actor unlink)
    kActorLinkStatusLevelSkill,

    kActorStatus = 19999  //max
  };


  //from 20000 to 29999
  enum eActorPositionType  //independent CCPoint value
  {
    kActorPositionInvalid = 20000,  //min

    //Info
    kActorPositionAnimation,  // TODO: Animation position

    kActorLogicPositionInvalid = 21000,

    kActorMotionPositionInvalid = 22000,
    kActorMotionPositionMoveTarget,     //  Target move position
    kActorMotionPositionMoveSpeedUnit,     // Normalized speed vector(the Direction)

    kActorControlPositionInvalid = 23000,
    
    kActorBuffPositionInvalid = 24000,

    kActorSkillPositionInvalid = 25000,

    kActorAnimationPositionInvalid = 26000,

    kActorSpecifiedPositionInvalid = 27000,
    kActorSpecifiedPositionLastIdleGrid,

    kActorPosition = 29999  //max
  };


  enum eActorAppearanceType
  {
    kActorAppearanceCharacter = 1,
    kActorAppearanceEnemyPawn,
    kActorAppearanceEnemyBoss,
    kActorAppearance = -1
  };

  enum eActorFactionType
  {
    kActorFactionUserSupport = 1,    //where user are
    kActorFactionUserOppose,   //who attacks user
    kActorFactionNeutral, //usually for some special actor that doesn't attack, or attack both
    kActorFaction = -1
  };

  enum eActorCareerType
  {
    kActorCareerWarrior = 1,
    kActorCareerKnight,
    kActorCareerPriest,
    kActorCareerWizard,
    kActorCareerArcher,
    kActorCareer = -1
  };

  enum eActorAnimationDirection
  {
    kActorAnimationDirectionLeft = 1,
    kActorAnimationDirectionRight,
    kActorAnimationDirection = -1
  };

  enum eActorGuardType
  {
    kActorGuardMelee = 1, //Circle
    kActorGuardRanged, //Rectangle front & same row
    kActorGuard = -1
  };

  enum eActorAttackType
  {
    kActorAttackMelee   = 1 << 0,
    kActorAttackRanged  = 1 << 1,
    kActorAttackHeal    = 1 << 2,
    kActorAttack = 0
  };

  enum eActorSkillType
  {
    kActorSkillNormal   = 1 << 0,
    kActorSkillPower    = 1 << 1,
    kActorSkillSpecial  = 1 << 2,
    kActorSkillOverload = 1 << 3,
    kActorSkill = 0
  };



  enum eActorDamageAttributeType
  {
    //basic
    kActorDamageAttributePhysical  = 1 << 0,
    kActorDamageAttributeMagical   = 1 << 1,  //mix of Elemental?
    kActorDamageAttributeCritical  = 1 << 2,

    //elemental
    kActorDamageAttributeIce       = 1 << 3,
    kActorDamageAttributeFire      = 1 << 4,
    kActorDamageAttributeWind      = 1 << 5,

    //modify directly
    kActorDamageAttributeHealth    = 1 << 6,   //Should be Healing, and should have (damage_value < 0)
    kActorDamageAttributeEnergy    = 1 << 7,   //Should be Energy Charging, and should have (damage_value < 0)

    //for calculation
    kActorDamageAttribute = 0,
  };

  //priority of control
  //need to keep update in lua
  enum eActorControlPriority
  {
    kActorControlPriorityMin = 0,

    kActorControlPriorityCheckGuardAuto, //skill check guard(result in auto move to target)

    kActorControlPriorityMoveAuto,

    kActorControlPriorityCheckAttackAuto, //skill check attack(result in auto normal attack)
    kActorControlPriorityCounterAttackAuto, //commit counter attack priority

    kActorControlPriorityAttackNormalAuto,
    kActorControlPriorityAttackNormalManual,
    
    kActorControlPriorityMoveManual,  //user move operation priority

    kActorControlPriorityAttackPowerAuto,
    kActorControlPriorityAttackSpecialAuto,
    kActorControlPriorityAttackSpecialManual,

    kActorControlPriorityIncontrollable,  //normally max priority

    kActorControlPriorityMax,

    kActorControlPriority = -1
  };

//ABOVE WILL BE EXPORTED TO LUA IN [actor_script_exporter.pkg]
//ABOVE WILL BE EXPORTED TO LUA IN [actor_script_exporter.pkg]
//ABOVE WILL BE EXPORTED TO LUA IN [actor_script_exporter.pkg]

  enum eActorControlAutoGuardType
  {
    kActorControlAutoGuardInvalid = -1,
    kActorControlAutoGuardDefault = 1,
    kActorControlAutoGuardPreferY,  //will first respond to enemy with same grid Y
    kActorControlAutoGuard = -1
  };


  enum eActorControlAutoReleaseSkillType
  {
    kActorControlAutoReleaseSkillInvalid = -1,
    kActorControlAutoReleaseSkillNoPause = 1,
    kActorControlAutoReleaseSkillWithPause,
    kActorControlAutoReleaseSkillWithProbability,
    kActorControlAutoReleaseSkillByAttackCount,
    kActorControlAutoReleaseSkill = -1
  };


  enum eActorControlIncontrollableType  //the reason why the actor is incontrollable
  {
    kActorControlIncontrollableBuff = 1,
    kActorControlIncontrollableSkill,
    kActorControlIncontrollableScript,
    kActorControlIncontrollableOther,
    kActorControlIncontrollable = -1
  };


  enum eActorDamageStatusType
  {
    kActorDamageStatusCountAddProcessActor = 1,
    kActorDamageStatusCountSubProcessActor,

    kActorDamageStatusIsMissed,
    kActorDamageStatusIsCritical,

    kActorDamageStatusIsSuicide,
    kActorDamageStatusIsHeal,
    
    kActorDamageStatusSourceActorId,
    kActorDamageStatusSourceActorLevel,

    kActorDamageStatusSourceSkillId,
    kActorDamageStatusSourceSkillLevel,
    kActorDamageStatusSourceSkillType,

    kActorDamageStatusSourceBuffId,
    kActorDamageStatusSourceEffectId,

    kActorDamageStatusTargetActorId,

    kActorDamageStatus = 0
  };


  typedef struct tActorSkillInfo {
    int skill_id;
    int skill_level;
    eActorSkillType skill_type;
  } ActorSkillInfo;


//   enum eActorIncontrollableMotionType
//   {
//     kActorIncontrollableMotionFreezed,  //Animation Stopped, No Move, No Direction Change
//     kActorIncontrollableMotionDelayed,  //Animation Idle, No Move, No Direction Change
//     kActorIncontrollableMotionRunHome,  //Animation Move, Move To Left/Right Most, Normal Direction Change
//     kActorIncontrollableMotionPushBack, //Animation Stopped, Move Backwards a little, No Direction Change
//     kActorIncontrollableMotion
//   };
// 
// 
//   enum eActorBuffColorType  //These Type will be converted to color or shader
//   {
//     kActorBuffColorFreezed,
//     kActorBuffColorOnFire,
//     kActorBuffColorPosioned,
//     kActorBuffColorShocked,
//     kActorBuffColorStoned,
//     kActorBuffColorEtc,
//     kActorBuffColor
//   };
// 
// 
//   enum eActorBuffAnimationType  //These will be overload animation, mostly used in motion Incontrollable
//   {
//     kActorBuffAnimationIdle,
//     kActorBuffAnimationMove,
//     kActorBuffAnimationAttacked,
//     kActorBuffAnimationEtc,
//     kActorBuffAnimation
//   };


} // namespace actor


#endif // ACTOR_DATA_TYPEDEF_H