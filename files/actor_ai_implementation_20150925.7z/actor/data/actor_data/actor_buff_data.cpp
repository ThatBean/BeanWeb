#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"
#include "game/battle/damage/damage_constants.h"

namespace actor {

  const unsigned long ACTOR_BUFF_FLAG_MOVE_AUTO = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_MOVE_LOCK = 0
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | taomee::battle::kDamageIntertwine
    | 0;



  const unsigned long ACTOR_BUFF_FLAG_ATTACK_LOCK = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_NORMAL_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageBlinded
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_POWER_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageBlinded
	  | taomee::battle::kDamageSilence
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_SPECIAL_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageSilence
    | 0;


  const unsigned long ACTOR_BUFF_FLAG_ANIMATION_LOCK = 0
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_COLORED = 0
    | taomee::battle::kDamageFireProperty
    | taomee::battle::kDamageFireProperty
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_INCONTROLLABLE = 0
    | ACTOR_BUFF_FLAG_MOVE_AUTO 
    | ACTOR_BUFF_FLAG_MOVE_LOCK
    | 0;



  ActorBuffData::ActorBuffData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }



  //link OnDataOperation to selected signal
  void ActorBuffData::ConnectDataSignal()
  {
    //add data signal
    //actor_data_->GetActorStatusData(kActorBuffStatusIsPauseAnimation)->Connect<ActorBuffData>(this, &ActorBuffData::OnDataOperation);
  }

  //callback for data operation signal
  void ActorBuffData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

//     switch (actor_data_type)
//     {
//     case kActorBuffStatusIsPauseAnimation:
//       {
//         switch (operation_type)
//         {
//         case kActorDataOperationReset:
//         case kActorDataOperationSet:
//           {
//             bool is_pause = actor_data_->GetActorStatusBool(kActorBuffStatusIsPauseAnimation);
// 
//             actor_data_->GetActorStatusData(kActorAnimationStatusIsPaused)->Stack(is_pause);
//           }
//           break;
//         }
//       }
//       break;
//     }
  }


  //Slot
  bool ActorBuffData::ResolveSlot(int slot_id)
  {
    if (buff_slot_map_.find(slot_id) != buff_slot_map_.end())
    {
      switch (buff_slot_map_[slot_id].resolve_type)
      {
      case kActorSlotResolveKeepOld:
        return false;
      case kActorSlotResolveKeepNew:
        return true;
      default:
        assert(false);
        //no resolve = keep new + alert
        break;
      }
    }

    return true;
  }
  int ActorBuffData::ReserveSlot(int slot_id, int data_id, eActorSlotResolveType resolve_type)
  {
    int replaced_data_id = ACTOR_INVALID_ID;
    if (buff_slot_map_.find(slot_id) != buff_slot_map_.end())
      replaced_data_id = buff_slot_map_[slot_id].data_id;

    buff_slot_map_[slot_id].data_id = data_id;
    buff_slot_map_[slot_id].resolve_type = resolve_type;

    return replaced_data_id; //may return replaced data_id
  }
  void ActorBuffData::ReleaseSlot(int slot_id)
  {
    assert(buff_slot_map_.find(slot_id) != buff_slot_map_.end());
    buff_slot_map_.erase(slot_id);
  }








  //BitFlag
  void ActorBuffData::AddBitFlag(int data_id, ActorBitFlagData bit_flag_data)
  {
    if (buff_bit_flag_data_map_.find(data_id) != buff_bit_flag_data_map_.end())
    {
      assert(false);
      return;
    }
    
    buff_bit_flag_data_map_[data_id] = bit_flag_data;

    //UpdateBitFlag();  //event better
    buff_bit_flag_data_.flag &= bit_flag_data.flag;
    buff_bit_flag_data_.mute_flag &= bit_flag_data.mute_flag;
  }
  void ActorBuffData::RemoveBitFlagByFlag(BitFlag flag)
  {
    if ((buff_bit_flag_data_.flag & flag) >= flag)
    {
      std::map<int, ActorBitFlagData>::iterator iterator = buff_bit_flag_data_map_.begin();

      while(iterator != buff_bit_flag_data_map_.end())
      {
        int data_id = iterator->first;
        ActorBitFlagData bit_flag_data = iterator->second;

        if (flag == bit_flag_data.flag) 
        {
          buff_bit_flag_data_map_.erase(data_id);
          break;
        }

        iterator++;
      }

      UpdateBitFlag();
    }
  }
  void ActorBuffData::RemoveBitFlag(int data_id)
  {
    //if (buff_bit_flag_data_map_.find(data_id) != buff_bit_flag_data_map_.end()) 
      buff_bit_flag_data_map_.erase(data_id);

    UpdateBitFlag();
  }
  BitFlag ActorBuffData::GetBitFlag()
  {
    return buff_bit_flag_data_.GetFlag();
  }
  bool ActorBuffData::CheckBitFlag(BitFlag flag)
  {
    return ((flag & buff_bit_flag_data_.GetFlag()) == 0) ? false : true;
  }
  void ActorBuffData::UpdateBitFlag()
  {
    buff_bit_flag_data_.Clear();

    std::map<int, ActorBitFlagData>::iterator iterator = buff_bit_flag_data_map_.begin();

    while(iterator != buff_bit_flag_data_map_.end())
    {
      buff_bit_flag_data_.flag &= iterator->second.flag;
      buff_bit_flag_data_.mute_flag &= iterator->second.mute_flag;

      iterator++;
    }
  }





  void ActorBuffData::UpdateIncontrollable()
  {
    uint_32 buff_flag = actor_adapter_->battle_status_flag();

    //BitFlag buff_flag = buff_bit_flag_data_.GetFlag();


    actor_data_->SetActorStatusBool(kActorLogicStatusIsIncontrollable, ((buff_flag & ACTOR_BUFF_FLAG_INCONTROLLABLE) != 0));

    actor_data_->SetActorStatusBool(kActorLogicStatusCanMove, ((buff_flag & ACTOR_BUFF_FLAG_MOVE_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttack, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttackNormal, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_NORMAL_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttackPower, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_POWER_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttackSpecial, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_SPECIAL_LOCK) == 0));

    bool is_pause_animation = (buff_flag & ACTOR_BUFF_FLAG_ANIMATION_LOCK) != 0;
    if (is_pause_animation != actor_data_->GetActorStatusBool(kActorBuffStatusIsPauseAnimation)) 
    {
      actor_data_->SetActorStatusBool(kActorBuffStatusIsPauseAnimation, is_pause_animation);
      actor_data_->GetActorStatusData(kActorAnimationStatusIsPaused)->Stack(is_pause_animation);
    }

    actor_data_->SetActorStatusBool(kActorBuffStatusIsChangeColor, ((buff_flag & ACTOR_BUFF_FLAG_COLORED) != 0));
    //actor_data_->SetActorStatusBool(kActorBuffStatusForceMoveAuto, ((buff_flag & ACTOR_BUFF_FLAG_MOVE_AUTO) == 0));  // TODO:
  }



  int ActorBuffData::UpdateShader()
  {
    uint_32 buff_flag = actor_adapter_->battle_status_flag();

    if ( buff_flag & taomee::battle::kDamagePetrifaction )
      return taomee::shader::kShaderGray;

    if ( buff_flag & taomee::battle::kDamageLoweMoveSpeed )
      return taomee::shader::kShaderFrozen;

    return taomee::shader::kShaderDefault;
  }




  //currently in adapter

} // namespace actor