#ifndef ACTOR_MOTION_DATA_H
#define ACTOR_MOTION_DATA_H

#include "../actor_data_typedef.h"

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;

  class ActorMotionData
  {
  public:
    ActorMotionData(ActorData* actor_data);
    ~ActorMotionData();

    //void    
    void Update(float delta_time);

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);


  private:
    ActorData*    actor_data_;
  };


} // namespace actor


#endif // ACTOR_MOTION_DATA_H