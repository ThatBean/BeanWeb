#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"
#include "game/actor/actor_adapter.h"
#include "game/actor/trigger/actor_trigger.h"


#include "game/ago_skill/control/ASkillControl.h"


namespace actor {
  ActorSkillData::ActorSkillData(ActorData* actor_data, Actor* actor)
    :actor_data_(actor_data),
    attack_trigger_(NULL),
    guard_trigger_(NULL),
    guard_trigger_auto_(NULL),
    skill_control_(NULL)
  {
    Reset();

    //ASkillControl
    skill_control_ = ASkillControl::create();
    skill_control_->setActor(actor);
    skill_control_->retain();
  }

  ActorSkillData::~ActorSkillData()
  {
    Reset();

    //ASkillControl
    skill_control_->setActor(NULL);
    CC_SAFE_RELEASE(skill_control_);
    skill_control_ = NULL;
  }

  void ActorSkillData::Reset()
  {
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackCount)->Reset();
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackNormalCount)->Reset();
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackPowerCount)->Reset();
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackSpecialCount)->Reset();


    skill_info_map_.clear();
    skill_cycle_list_.clear();


    if (attack_trigger_) delete attack_trigger_;
    if (guard_trigger_) delete guard_trigger_;
    if (guard_trigger_auto_) delete guard_trigger_auto_;

    attack_trigger_ = NULL;
    guard_trigger_ = NULL;
    guard_trigger_auto_ = NULL;


  }




  //link OnDataOperation to selected signal
  void ActorSkillData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorStatusData(kActorSkillStatusIsPaused)->Connect<ActorSkillData>(this, &ActorSkillData::OnDataOperation);
  }

  //callback for data operation signal
  void ActorSkillData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

    switch (actor_data_type)
    {
    case kActorSkillStatusIsPaused:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            bool is_pause = actor_data_->GetActorStatusBool(kActorSkillStatusIsPaused);

            if (is_pause) 
              skill_control_->pauseAllSkill();
            else 
              skill_control_->resumeAllSkill();
          }
          break;
        }
      }
      break;
    }
  }











  bool ActorSkillData::IsSkillValid(int skill_id)
  {
    bool is_attack_valid = true;
    eActorSkillType skill_type = GetSkillTypeById(skill_id);

    switch(skill_type)
    {
    case kActorSkillNormal:
      is_attack_valid = actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackNormal);
      break;
    case kActorSkillPower:
      is_attack_valid = actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackPower);
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      is_attack_valid = actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackSpecial);
      break;
    case kActorSkill:
    default:
      //assert(false);
      is_attack_valid = false;
      break;
    }

    //not check here, but when skill release
    //cool down check - this only used to add cool down time between skill, default = 0
    //is_attack_valid = is_attack_valid && (GetSkillCooldownByType(skill_type) <= actor_data_->GetControlData()->GetSkillCountdown());

    return is_attack_valid;
  }



  bool ActorSkillData::CheckAttackTrigger()
  {
    if (!attack_trigger_)
      return false;
    if (NextSkill() == ACTOR_INVALID_ID || IsSkillValid(NextSkill()) == false)
      return false; //skill not ready
    if (actor_data_->GetControlData()->CheckOperationData(kActorControlOperationPositionMove) && actor_data_->GetControlData()->GetOperationData(kActorControlOperationPositionMove)->priority > kActorControlPriorityCheckAttackAuto) 
      return false;//user set position, ignore all target

    attack_trigger_->Update();//update trigger
    if (attack_trigger_->GetIsTriggered() == false) 
      return false;//no target

    //decide target
    ActorControlData* control_data = actor_data_->GetControlData();
    Actor* target_actor = NULL;
    std::list<Actor*>* triggered_actor_list = attack_trigger_->GetTriggeredActorList();
    if (control_data->CheckOperationData(kActorControlOperationIdTargetMove) && control_data->GetOperationData(kActorControlOperationIdTargetMove)->priority > kActorControlPriorityCheckAttackAuto) 
    {
      int target_actor_id = control_data->GetIdOperationData(kActorControlOperationIdTargetMove); //user set target

      std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
      while (iterator != triggered_actor_list->end())
      {
        Actor* triggered_actor = *iterator;
        if (target_actor_id == triggered_actor->GetScriptObjectId()) 
        {
          target_actor = triggered_actor;
        }
        iterator ++;
      }
    }
    else
    {
      target_actor = *(triggered_actor_list->begin());
    }

    // no target
    if (!target_actor)
      return false;

    int next_skill_id = NextSkill();

    switch (GetSkillTypeById(next_skill_id))
    {
    case kActorSkillNormal:
      control_data->AddIdOperation(kActorControlOperationIdSkill, kActorControlPriorityAttackNormalAuto, next_skill_id);
      CycleSkillCycleList();//cycle attack cycle
      break;
    case kActorSkillPower:
      control_data->AddIdOperation(kActorControlOperationIdSkill, kActorControlPriorityAttackPowerAuto, next_skill_id);
      CycleSkillCycleList();//cycle attack cycle
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      actor_data_->GetLog()->AddErrorLogF("[CheckAttackTrigger] Get Special/Overload Skill! id:%d type:%d", next_skill_id, GetSkillTypeById(next_skill_id));
      control_data->AddIdOperation(kActorControlOperationIdSkill, kActorControlPriorityAttackSpecialAuto, next_skill_id);
      break;
    default:
      actor_data_->GetLog()->AddErrorLogF("[CheckAttackTrigger] Error skill type! id:%d type:%d", next_skill_id, GetSkillTypeById(next_skill_id));
      assert(false);
      break;
    }

    //set to control data
    control_data->RemoveOperationData(kActorControlOperationIdTargetMove); // found the target, clear control priority for attack
    control_data->AddIdOperation(kActorControlOperationIdTargetAttack, kActorControlPriorityAttackNormalAuto, target_actor->GetScriptObjectId()); // found the target, clear control priority for attack
    return true;
  }


  bool ActorSkillData::CheckGuardTrigger()
  {
    if (!guard_trigger_) 
      return false;
    if (NextSkill() == ACTOR_INVALID_ID || IsSkillValid(NextSkill()) == false)
      return false; //skill not ready
    if (actor_data_->GetControlData()->GetMaxPriority() > kActorControlPriorityCheckGuardAuto) 
      return false; //has other target set

    guard_trigger_->Update();

    if (guard_trigger_->GetIsTriggered() && actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackNormal))
    {
      int target_id = *(guard_trigger_->GetTriggeredActorIdList()->begin());
      actor_data_->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id);
      return true;
    }

    return false;
  }




  void ActorSkillData::AddSkillInfo(int skill_id, int skill_level, eActorSkillType skill_type)
  {
    if (GetSkillInfoById(skill_id))
    {
      actor_data_->GetLog()->AddErrorLogF("[Error][ActorSkillData][AddSkillInfo] Already has this skill in map! id:%d", skill_id);
      assert(false);
      return;
    }

    int skill_index = skill_type * 1000000 + skill_id;

    skill_info_map_[skill_index].skill_id = skill_id;
    skill_info_map_[skill_index].skill_level = skill_level;
    skill_info_map_[skill_index].skill_type = skill_type;
  }

  ActorSkillInfo* ActorSkillData::GetSkillInfoById(int skill_id)
  {
    //not allowed
    if (skill_id == ACTOR_INVALID_ID) return NULL;

    //check map
    std::map<int, ActorSkillInfo>::iterator iterator = skill_info_map_.begin();
    while (iterator != skill_info_map_.end())
    {
      if (iterator->second.skill_id == skill_id) return &(iterator->second);
      iterator++;
    }

    return NULL;
  }



  eActorSkillType ActorSkillData::GetSkillTypeById(int skill_id)
  {
    //not allowed
    if (skill_id == ACTOR_INVALID_ID) return kActorSkill;

    //check map
    ActorSkillInfo* skill_info = GetSkillInfoById(skill_id);
    if (skill_info) return skill_info->skill_type;
    else return kActorSkillOverload;
  }


  int ActorSkillData::GetSkillIdByType(int skill_type, int skip_count/* = 0*/)
  {
    //check map
    std::map<int, ActorSkillInfo>::iterator iterator = skill_info_map_.begin();

    while (iterator != skill_info_map_.end())
    {
      if (skill_type & kActorSkillOverload || iterator->second.skill_type & skill_type)
      {
        if (skip_count == 0) return iterator->second.skill_id;
        else skip_count--;
      }
      iterator++;
    }

    return ACTOR_INVALID_ID;
  }


  int ActorSkillData::NextSkill()
  {
    if (skill_cycle_list_.size() == 0)
    {
      //actor_data_->GetLog()->AddErrorLogF("[Error][ActorSkillData][NextSkill] No skill at all in list!");
      //assert(false);
      return ACTOR_INVALID_ID;
    }

    return *(skill_cycle_list_.begin());
  }


  void ActorSkillData::CycleSkillCycleList()
  {
    int skill_id = *(skill_cycle_list_.begin());
    skill_cycle_list_.pop_front();
    skill_cycle_list_.push_back(skill_id);
  }


  void ActorSkillData::SetSkillCycleList(std::string& skill_cycle_string)
  {
    std::list<std::string>* result_list = ActorStringSplit(skill_cycle_string, std::string("|,"));

    assert(result_list->size() > 0);

    skill_cycle_list_.clear();

    std::list<std::string>::iterator iterator = result_list->begin();
    while (iterator != result_list->end())
    {
      int skill_id = ACTOR_INVALID_ID;
      
      if (iterator->c_str()[0] >= '0' && iterator->c_str()[0] <= '9')
      {
        //normal skill
        int skip_count = atoi(iterator->c_str());
        skill_id = GetSkillIdByType(kActorSkillNormal | kActorSkillPower, skip_count);
      }

      if (iterator->c_str()[0] >= 'a' && iterator->c_str()[0] <= 'z')
      {
        //special skill
        int skip_count = iterator->c_str()[0] - 'a';
        skill_id = GetSkillIdByType(kActorSkillSpecial, skip_count);
      }

      if (skill_id != ACTOR_INVALID_ID) skill_cycle_list_.push_back(skill_id);
      else actor_data_->GetLog()->AddErrorLogF("[Error][ActorSkillData][SetSkillCycleList] skipped invalid symbol: [%s]", iterator->c_str());

      iterator++;
    }

    delete result_list;
  }



  void ActorSkillData::CommitSkill(int skill_id, int target_actor_id)
  {
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackCount)->Add(1);

    if (skill_id <= 0) return;
     
    eActorSkillType skill_type = GetSkillTypeById(skill_id);
    switch (skill_type)
    {
    case kActorSkillNormal:
      actor_data_->GetActorAttributeData(kActorSkillAttributeAttackNormalCount)->Add(1);
      break;
    case kActorSkillPower:
      actor_data_->GetActorAttributeData(kActorSkillAttributeAttackPowerCount)->Add(1);
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      actor_data_->GetActorAttributeData(kActorSkillAttributeAttackSpecialCount)->Add(1);
      actor_data_->SetActorAttribute(kActorAttributeEnergyCurrent, 0);
      if (actor_data_->GetActorStatusBool(kActorSkillStatusIsBusy) == true) 
      {
        actor_data_->GetLog()->AddLogF("[ActorSkillData][CommitSkill] Reset Previous Skill. Current skill_id:%d type:%d count:%d", skill_id, skill_type, (int)actor_data_->GetActorAttribute(kActorSkillAttributeAttackCount));
        
        skill_control_->removeAllActorSkill();
      }
      break;
    default:
      assert(false);
      break;
    }

    actor_data_->GetLog()->AddLogF("[ActorSkillData][CommitSkill] <!> Attack! Current skill_id:%d type:%d count:%d", skill_id, skill_type, (int)actor_data_->GetActorAttribute(kActorSkillAttributeAttackCount));
    
    int skill_release_type = -1;

    switch (eActorSkillType(skill_type))
    {
    case kActorSkillNormal:
      skill_release_type = kSkillNormal;
      break;
    case kActorSkillPower:
      skill_release_type = kSkillPower1;
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      skill_release_type = kSkillSpecial;
      break;
    }

    skill_control_->playSkillByID(skill_id, skill_release_type, target_actor_id);
  }

  bool ActorSkillData::GetIsSpecialSkillReady()
  {
    return actor_data_->GetActorAttribute(kActorAttributeEnergyCurrent) >= actor_data_->GetActorAttribute(kActorAttributeEnergyMax);
  }

  float ActorSkillData::GetSkillCooldownByType(eActorSkillType skill_type)
  {
    switch (skill_type)
    {
    case kActorSkillNormal:
    case kActorSkillPower:
      return actor_data_->GetActorAttribute(kActorAttributeSpeedAttack);
    default:
      return 0;
    }
  }

  //ActorSkillData

} // namespace actor