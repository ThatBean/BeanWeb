#ifndef ACTOR_SKILL_DATA_H
#define ACTOR_SKILL_DATA_H

#include "../actor_data_typedef.h"


class ASkillControl; 


namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;
  class ActorTrigger;


  class ActorSkillData
  {
  public:
    ActorSkillData(ActorData* actor_data, Actor* actor);
    ~ActorSkillData();

    void Reset();

    //link OnDataOperation to selected signal
    void ConnectDataSignal();
    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);


    bool IsSkillValid(int skill_id);
    bool CheckAttackTrigger();
    bool CheckGuardTrigger();


    void            AddSkillInfo(int skill_id, int skill_level, eActorSkillType skill_type);
    ActorSkillInfo* GetSkillInfoById(int skill_id);
    eActorSkillType GetSkillTypeById(int skill_id);
    int             GetSkillIdByType(int skill_type, int skip_count = 0);

    int   NextSkill();
    void  CycleSkillCycleList();
    void  SetSkillCycleList(std::string& skill_cycle_string);

    void          SetGuardTrigger(ActorTrigger* trigger) { guard_trigger_ = trigger; }
    ActorTrigger* GetGuardTrigger() { return guard_trigger_; }
    void          SetGuardTriggerAuto(ActorTrigger* trigger) { guard_trigger_auto_ = trigger; }
    ActorTrigger* GetGuardTriggerAuto() { return guard_trigger_auto_; }
    void          SetAttackTrigger(ActorTrigger* trigger) { attack_trigger_ = trigger; }
    ActorTrigger* GetAttackTrigger() { return attack_trigger_; }

    //currently in adapter
    void CommitSkill(int skill_id, int target_actor_id);

    bool GetIsSpecialSkillReady();

    float GetSkillCooldownByType(eActorSkillType skill_type);

    //messy but messy, link MoveObject data
    void SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }

  private:
    ActorData*    actor_data_;

    std::map<int, ActorSkillInfo>    skill_info_map_;
    std::list<int>    skill_cycle_list_;  //pop_front and push_back

    ActorTrigger*       attack_trigger_;  //
    //used in logic guard, if triggered, actor will move to attack
    ActorTrigger*       guard_trigger_;  //target searching by <guard range>, mostly used in Idle/Move
    ActorTrigger*       guard_trigger_auto_; //target searching by <auto range>(much bigger than guard), used in Auto Control, if true, auto move(approach) and attack

  private:
    ASkillControl*      skill_control_; //a skill control

    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*       actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };

} // namespace actor


#endif // ACTOR_SKILL_DATA_H