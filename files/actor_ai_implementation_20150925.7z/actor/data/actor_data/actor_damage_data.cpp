#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext_damage.h"
#include "game/actor/actor_script_exporter.h"

#include "game/game_manager/data_manager.h"


namespace actor {

  const unsigned long ACTOR_DAMAGE_MODIFY_HEALTH = 0
    | kActorDamageAttributePhysical
    | kActorDamageAttributeMagical
    | kActorDamageAttributeCritical
    | kActorDamageAttributeIce
    | kActorDamageAttributeFire
    | kActorDamageAttributeWind
    | 0;

  const unsigned long ACTOR_DAMAGE_MODIFY_ENERGY = 0
    | 0;


  
  
  ActorDamageData::ActorDamageData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }
  ActorDamageData::~ActorDamageData()
  {

  }


  void ActorDamageData::RegisterAddProcessActor(int actor_id)  //a way to share DamagePackage with Actor/Effect/Data
  {
    add_process_actor_id_list_.push_back(actor_id);
  }
  void ActorDamageData::UnRegisterAddProcessActor(int actor_id)
  {
    add_process_actor_id_list_.remove(actor_id);
  }
  void ActorDamageData::RegisterSubProcessActor(int actor_id)  //a way to share DamagePackage with Actor/Effect/Data
  {
    sub_process_actor_id_list_.push_back(actor_id);
  }
  void ActorDamageData::UnRegisterSubProcessActor(int actor_id)
  {
    sub_process_actor_id_list_.remove(actor_id);
  }


  DamagePackage* ActorDamageData::AddProcess(DamagePackage* damage_package) //
  {
    if (damage_package->GetIsActive() == false) return damage_package;

    damage_package->GetStatusData(kActorDamageStatusCountAddProcessActor)->StackTrue();

    //actor generate damage
    damage_package = GenerateDamage(damage_package);

    std::list<int>::iterator iterator = add_process_actor_id_list_.begin();
    while (iterator != add_process_actor_id_list_.end())
    {
      Actor* actor = GetActorExtEnv()->GetActorById(*iterator);
      if (actor)
      {
        damage_package = actor->GetActorData()->GetDamageData()->AddProcess(damage_package);
        if (damage_package->GetIsActive() == false) break; //damage_package vanished
      }

      iterator++;
    }

    return damage_package;
  }




  DamagePackage* ActorDamageData::SubProcess(DamagePackage* damage_package) //
  {
    if (damage_package->GetIsActive() == false) return damage_package;

    damage_package->GetStatusData(kActorDamageStatusCountSubProcessActor)->StackTrue();

    std::list<int>::iterator iterator = sub_process_actor_id_list_.begin();
    while (iterator != sub_process_actor_id_list_.end())
    {
      Actor* actor = GetActorExtEnv()->GetActorById(*iterator);
      if (actor)
      {
        damage_package = actor->GetActorData()->GetDamageData()->SubProcess(damage_package);
        if (damage_package->GetIsActive() == false) break; //damage_package vanished
      }

      iterator++;
    }

    //actor receive damage
    damage_package = ReceiveDamage(damage_package);
    return damage_package;
  }



  DamagePackage* ActorDamageData::GenerateDamage(DamagePackage* damage_package)
  {
    if (damage_package->GetIsActive() == false) return damage_package;

    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);
    eActorSkillType skill_type = eActorSkillType(damage_package->GetStatus(kActorDamageStatusSourceSkillType));

    //source actor
    if (source_actor_id == actor_data_->GetActorStatus(kActorStatusActorId) 
      && skill_id != ACTOR_INVALID_ID)
    {
      if (skill_type == kActorSkillNormal)
      {
        AddActorBasicDamage(damage_package);
      }
      else
      {
        AddActorSkillDamage(damage_package);
      }
    }
    else
    {
      //pre-process actor logic
    }

    return damage_package;
  }




  float quick_damage_sum_up(DamagePackage* damage_package, eActorDamageAttributeType damage_attribute_type, const unsigned long damage_type_flag)
  {
    if (damage_package->CheckAttribute(damage_attribute_type))
    {
      DamageAttributeData* damage_attribute_data = damage_package->GetAttributeData(damage_attribute_type);

      damage_package->InitAttribute(kActorDamageAttribute, 
        0, 
        damage_attribute_data->GetBase() + damage_attribute_data->GetAdd(), 
        damage_attribute_data->GetMultiplier(), 
        damage_attribute_data->GetExtra());

      if (damage_type_flag)
      {
        float raw_damage_value = damage_package->GetDamage(damage_type_flag);
        damage_package->AddAttribute(kActorDamageAttribute, raw_damage_value);
      }

      float damage_value = damage_package->GetAttribute(kActorDamageAttribute);
      
      damage_package->GetAttributeData(kActorDamageAttribute)->Reset();

      return damage_value;
    }
    else
    {
      return 0;
    }
  }

  float quick_damage_consume(DamagePackage* damage_package, eActorDamageAttributeType damage_attribute_type, ActorData* actor_data, eActorAttributeType data_key, float damage_value)
  {
    if (damage_value == 0) return damage_value; //fully consumed, sort of
    
    float actor_value = actor_data->GetActorAttribute(data_key);
    float consumed_value = (actor_value >= damage_value) ? damage_value : actor_value;

    actor_data->AddActorAttribute(data_key, - consumed_value);
    damage_package->AddAttribute(damage_attribute_type, 0, 0, - consumed_value);  //add consume_value to extra

    //notify ActorExtDamage
    GetActorExtEnv()->GetActorExtDamage()->DamageDealt(
      damage_package, 
      actor_data->GetActorStatus(kActorStatusActorId), 
      damage_value, 
      consumed_value, 
      damage_attribute_type, 
      data_key);

    return consumed_value;
  }

  //Damage Value Calculation:
  //  actor_value = actor_value - damage_value

  DamagePackage* ActorDamageData::ReceiveDamage(DamagePackage* damage_package)
  {
    if (damage_package->GetIsActive() == false) return damage_package;
    
    SubActorBasicDamage(damage_package);

    bool is_normal_attack = false;
    int damage_type = taomee::battle::kDamageTypePhysics;

    int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);
    if (skill_id != ACTOR_INVALID_ID)
    {
      eActorSkillType skill_type = eActorSkillType(damage_package->GetStatus(kActorDamageStatusSourceSkillType));
      is_normal_attack = skill_type == kActorSkillNormal;

      SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
      damage_type = skillData ? skillData->GetDamageType() : taomee::battle::kDamageTypePhysics;
    }
    else
    {
      is_normal_attack = false;
      
      if (damage_package->GetDamage(ACTOR_DAMAGE_MODIFY_HEALTH) < 0)
        damage_type = taomee::battle::kDamageTypeHeal;
      else if (damage_package->GetAttribute(kActorDamageAttributeHealth) > 0)
        damage_type = taomee::battle::kDamageTypeHoly;
      else if (damage_package->GetAttribute(kActorDamageAttributeMagical) > 0)
        damage_type = taomee::battle::kDamageTypeMagic;
      else if (damage_package->GetAttribute(kActorDamageAttributePhysical) > 0)
        damage_type = taomee::battle::kDamageTypePhysics;
      else 
        damage_type = taomee::battle::kDamageTypeUnkown;
    }


    float damage_value = 0;
    float consumed_value = 0;
    bool is_consumed = true;

    //process energy
    damage_value = quick_damage_sum_up(damage_package, kActorDamageAttributeEnergy, ACTOR_DAMAGE_MODIFY_ENERGY);
    consumed_value = quick_damage_consume(damage_package, kActorDamageAttributeEnergy, actor_data_, kActorAttributeEnergyCurrent, damage_value);
    is_consumed = is_consumed && damage_value <= consumed_value;



    if (actor_adapter_->check_battle_status_flag(taomee::battle::kDamageStatusImmune))
    {
      if (damage_type == taomee::battle::kDamageTypePhysics 
        && actor_adapter_->check_immune_status_flag(taomee::battle::kImmuneTypePhysicsHurt))
      {
        ShowStatusLabel(actor_data_->GetActorStatus(kActorStatusActorId), taomee::battle::eDamageLabelType_PhysicsImmune);
        damage_package->InitAttribute(kActorDamageAttributePhysical, 0);
      }
      else if (damage_type == taomee::battle::kDamageTypeMagic 
        && actor_adapter_->check_immune_status_flag(taomee::battle::kImmuneTypeMagicHurt))
      {
        ShowStatusLabel(actor_data_->GetActorStatus(kActorStatusActorId), taomee::battle::eDamageLabelType_MagicImmune);
        damage_package->InitAttribute(kActorDamageAttributeMagical, 0);
      }
    }



    //precess health
    damage_value = quick_damage_sum_up(damage_package, kActorDamageAttributeHealth, ACTOR_DAMAGE_MODIFY_HEALTH);
    
    if (damage_value >= 0) {
      //health reducing damage
      damage_value += rand() % 9 + 1; //add random (1 - 10)

      if (damage_package->GetStatusBool(kActorDamageStatusIsMissed)) 
      {
        damage_value = 0;
      }
      else
      {
        if (actor_adapter_->check_battle_status_flag(taomee::battle::kDamageInvincible) 
          && damage_type != taomee::battle::kDamageTypeSuicide)
        {
          ShowStatusLabel(actor_data_->GetActorStatus(kActorStatusActorId), taomee::battle::eDamageLabelType_Invincible);
          damage_value = 0;
        }
      }

      //Energy reward
      actor_data_->AddActorAttribute(kActorAttributeEnergyCurrent, taomee::army::kAddEnergy_ReceiveAttack);
    }
    else 
    {
      //health healing damage
      damage_value -= rand() % 9 + 1; //add random (1 - 10)
    }

    consumed_value = quick_damage_consume(damage_package, kActorDamageAttributeHealth, actor_data_, kActorAttributeHealthCurrent, damage_value);
    is_consumed = is_consumed && damage_value <= consumed_value;


    if (consumed_value > 0)
    {
      //add calc damage
      actor_adapter_->add_bear_damage(consumed_value);
    }

    if (is_consumed) damage_package->SetIsActive(false);  //will not be calculated
    
    return damage_package;
  }


  DamagePackage* ActorDamageData::NotifyDamageResult(DamagePackage* damage_package)
  {
    int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);

    if (damage_package->GetStatusBool(kActorDamageStatusIsMissed) == false) 
    {
      actor_data_->AddActorAttribute(kActorAttributeEnergyCurrent, taomee::army::kAddEnergy_CommitAttack);
    }

    if (damage_package->GetIsActive()) damage_package->SetIsActive(false);

    return damage_package;
  }





  //as damage releaser
  void ActorDamageData::AddActorBasicDamage(DamagePackage* damage_package)
  {
    //this will be calculated last
    damage_package->InitAttribute(kActorDamageAttributeHealth, 0);
    damage_package->InitAttribute(kActorDamageAttributeEnergy, 0);

    //basic
    damage_package->InitAttribute(kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeAttackPhysical));
    damage_package->InitAttribute(kActorDamageAttributeMagical, actor_data_->GetActorAttribute(kActorAttributeAttackMagical));
    damage_package->InitAttribute(kActorDamageAttributeCritical, actor_data_->GetActorAttribute(kActorAttributeAttackCritical));
    damage_package->InitAttribute(kActorDamageAttributeIce, 0);
    damage_package->InitAttribute(kActorDamageAttributeFire, 0);
    damage_package->InitAttribute(kActorDamageAttributeWind, 0);

    //addition
    damage_package->AddAttribute(kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionPhysical));
    damage_package->AddAttribute(kActorDamageAttributeMagical, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionMagical));
    damage_package->AddAttribute(kActorDamageAttributeCritical, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionCritical));
    damage_package->AddAttribute(kActorDamageAttributeIce, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionIce));
    damage_package->AddAttribute(kActorDamageAttributeFire, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionFire));
    damage_package->AddAttribute(kActorDamageAttributeWind, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionWind));

    //check Critical
    if (damage_package->GetStatusBool(kActorDamageStatusIsCritical)) 
    {
      damage_package->InitStatusBool(kActorDamageStatusIsCritical, true);
    }
    else
    {
      damage_package->InitStatusBool(kActorDamageStatusIsCritical, false);
      damage_package->GetAttributeData(kActorDamageAttributeCritical)->Reset();  //delete crtical damage
    }
  }

  void ActorDamageData::AddActorSkillDamage(DamagePackage* damage_package)
  {
    int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);

    ActorSkillInfo* skill_info = actor_data_->GetSkillData()->GetSkillInfoById(skill_id);
    SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);

    float skill_damage_value = skillData->GetSkillGrowDamage(skill_info ? skill_info->skill_level : 0);
    skill_damage_value += actor_data_->GetActorAttribute(kActorAttributeAttackPhysical) * skillData->GetPhyAddedMul();
    skill_damage_value += actor_data_->GetActorAttribute(kActorAttributeAttackMagical) * skillData->GetMagAddedMul();

    switch (skillData->GetDamageType())
    {
    case taomee::battle::kDamageTypePhysics:
      damage_package->AddAttribute(kActorDamageAttributePhysical, skill_damage_value);
      damage_package->InitAttribute(kActorDamageAttributeHealth, 0, 0, actor_adapter_->damage_boost_multiple(), actor_data_->GetActorAttribute(kActorAttributeDamageAddition));
      break;
    case taomee::battle::kDamageTypeMagic:
      damage_package->AddAttribute(kActorDamageAttributeMagical, skill_damage_value);
      damage_package->InitAttribute(kActorDamageAttributeHealth, 0, 0, actor_adapter_->damage_boost_multiple(), actor_data_->GetActorAttribute(kActorAttributeDamageAddition));
      break;
    case taomee::battle::kDamageTypeHoly:
      damage_package->AddAttribute(kActorDamageAttributeHealth, 0, 0, skill_damage_value);
      damage_package->InitAttribute(kActorDamageAttributeHealth, 0, 0, actor_adapter_->damage_boost_multiple(), actor_data_->GetActorAttribute(kActorAttributeDamageAddition));
      break;
    case taomee::battle::kDamageTypeSuicide:
      damage_package->AddAttribute(kActorDamageAttributeHealth, 0, 0, skill_damage_value);
      damage_package->InitStatusBool(kActorDamageStatusIsSuicide, true);
      break;
    case taomee::battle::kDamageTypeHeal:
      damage_package->InitAttribute(kActorDamageAttributeHealth, skill_damage_value, - taomee::army::kHealToDamageRadio * actor_adapter_->heal_boost_multiple());
      damage_package->InitStatusBool(kActorDamageStatusIsHeal, true);
      break;
    case taomee::battle::kDamageTypeUnkown:
      //tricky
      break;
    }
  }

  void quick_calc_damage_reduction(DamagePackage* damage_package, eActorDamageAttributeType damage_attribute_type, float reduction_value)
  {
    float damage_value = damage_package->GetAttribute(damage_attribute_type);

    float extra_value = ((damage_value <= reduction_value) ? - damage_value : - reduction_value);//max reduction to 0

    damage_package->AddAttribute(damage_attribute_type, 0, 0, extra_value);
  }

  void quick_calc_damage_defense(DamagePackage* damage_package, eActorDamageAttributeType damage_attribute_type, float defence_value)
  {
    float damage_value = damage_package->GetAttribute(damage_attribute_type);
    float extra_value = 0;

    if (damage_value <= defence_value) 
    {
      //DefenceCorrection in Lua "local defence_correction = 1.25; --�˺������������ϵ��"
      float correction = 1.25; //�˺������������ϵ��
      //full reduction to <Atka^2*(1-(1/C)^2)/(Atka+Defb)>
      float result_value = damage_value * damage_value  * (1 - 1 / correction / correction) / (damage_value + defence_value);
      result_value = result_value > 1 ? result_value : 1;
      extra_value = result_value - damage_value;
    }
    else 
    {
      extra_value = - defence_value;
    }

    damage_package->AddAttribute(damage_attribute_type, 0, 0, extra_value);
  }

  void ActorDamageData::SubActorBasicDamage(DamagePackage* damage_package)
  {
    //reduction
    quick_calc_damage_reduction(damage_package, kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeDamageReductionPhysical));
    quick_calc_damage_reduction(damage_package, kActorDamageAttributeMagical, actor_data_->GetActorAttribute(kActorAttributeDamageReductionMagical));
    quick_calc_damage_reduction(damage_package, kActorDamageAttributeCritical, actor_data_->GetActorAttribute(kActorAttributeDamageReductionCritical));
    quick_calc_damage_reduction(damage_package, kActorDamageAttributeIce, actor_data_->GetActorAttribute(kActorAttributeDamageReductionIce));
    quick_calc_damage_reduction(damage_package, kActorDamageAttributeFire, actor_data_->GetActorAttribute(kActorAttributeDamageReductionFire));
    quick_calc_damage_reduction(damage_package, kActorDamageAttributeWind, actor_data_->GetActorAttribute(kActorAttributeDamageReductionWind));

    //basic
    quick_calc_damage_defense(damage_package, kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeDefensePhysical));
    quick_calc_damage_defense(damage_package, kActorDamageAttributeMagical, actor_data_->GetActorAttribute(kActorAttributeDefenseMagical));
    quick_calc_damage_defense(damage_package, kActorDamageAttributeCritical, actor_data_->GetActorAttribute(kActorAttributeDefenseCritical));


    // heal boost
    if (damage_package->GetStatusBool(kActorDamageStatusIsHeal))
    {
      damage_package->GetAttributeData(kActorDamageAttributeHealth)->Scale(1, actor_adapter_->by_heal_boost_multiple());
    }
    else
    {
      // damage mod
      damage_package->GetAttributeData(kActorDamageAttributeHealth)->Scale(1, actor_adapter_->by_damage_boost_multiple());
      quick_calc_damage_defense(damage_package, kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeDamageReduction));
    }
  }


//   void Adding ()
//   {
      //����
      //��Ѫ
//   }

  //ActorDamageData

} // namespace actor