#include "actor_script_exporter.h"

#include "game/actor/actor.h"
#include "game/actor/control/actor_control.h"
#include "engine/script/lua_tinker_manager.h"

#define SCRIPT_OBJECT_LUA "script/actor/script_object.lua"
#define ACTOR_SCRIPT_LUA "script/actor/actor_script.lua"
#define EFFECT_SCRIPT_LUA "script/actor/effect_script.lua"
#define DATA_SCRIPT_LUA "script/actor/data_script.lua"
#define DEFAULT_UPDATE_MIN_DELTA_TIME 0.1

namespace actor {

  bool ActorScriptExporter::is_auto_control_ = false;
  
  ActorScriptExporter::ActorScriptExporter(Actor* actor)
    :actor_(actor),
    cached_delta_time_(0),
    update_min_delta_time_(DEFAULT_UPDATE_MIN_DELTA_TIME)
  {
    //first update don't delay
    cached_delta_time_ = update_min_delta_time_;

    //init Lua ActorScript and RegisterScriptObjectUpgrader
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>(ACTOR_SCRIPT_LUA, "InitActorScript");
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>(EFFECT_SCRIPT_LUA, "InitEffectScript");
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>(DATA_SCRIPT_LUA, "InitDataScript");
  }

  ActorScriptExporter::~ActorScriptExporter()
  {
    Clear();
  }

  void ActorScriptExporter::Init()
  {
    //must wait for ActorScriptExporter constructor finish, or GetActorScriptExporter() will return NULL
    actor_->UpgradeScriptObject();
  }

  void ActorScriptExporter::Clear()
  {
    cached_delta_time_ = 0;
    lua_signal_connection_map_.clear();
  }


  void ActorScriptExporter::Update(float delta_time)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;

    cached_delta_time_ += delta_time;
    if (cached_delta_time_ >= update_min_delta_time_)  //Lua update will be less often
    {
      actor_->CallScriptObjectFunction("Update", cached_delta_time_);
      cached_delta_time_ = 0;
    }
  }

  void ActorScriptExporter::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;

    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

    printf("[ActorScriptExporter][OnDataOperation] id: %d | get op: %d, c: %d, d: %d\n", actor_->GetScriptObjectId(), operation_type, data_class_type, actor_data_type);

    if (lua_signal_connection_map_.find(data_class_type) != lua_signal_connection_map_.end()
      && lua_signal_connection_map_[data_class_type].find(actor_data_type) != lua_signal_connection_map_[data_class_type].end())
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", 
        actor_->GetScriptObjectId(), "EmitDataSignal", operation_type, data_class_type, actor_data_type);
    }
  }



  void ActorScriptExporter::OnDamageDealt(int target_actor_id, int target_model_type, int damage_attribute_type, float damage_value)
  {
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "EmitScriptObject", 
      actor_->GetScriptObjectId(), "DamageDealt", target_actor_id, target_model_type, damage_attribute_type, damage_value);
  }



  // actor based
  void ActorScriptExporter::ActorDataSignalConnect(int data_class_type, int actor_data_type)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;
    ActorSignalConnection connection;
    if (data_class_type == kActorDataClassAttribute)
      connection = actor_->GetActorData()->GetActorAttributeData((eActorAttributeType)actor_data_type)->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnDataOperation);
    if (data_class_type == kActorDataClassStatus)
      connection = actor_->GetActorData()->GetActorStatusData((eActorStatusType)actor_data_type)->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnDataOperation);
    if (data_class_type == kActorDataClassPosition)
      connection = actor_->GetActorData()->GetActorPositionData((eActorPositionType)actor_data_type)->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnDataOperation);
    lua_signal_connection_map_[data_class_type][actor_data_type] = connection;
  }

  void ActorScriptExporter::ActorDataSignalDisconnect(int data_class_type, int actor_data_type)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;
    if (lua_signal_connection_map_.find(data_class_type) != lua_signal_connection_map_.end()
      && lua_signal_connection_map_[data_class_type].find(actor_data_type) != lua_signal_connection_map_[data_class_type].end())
    {
      if (data_class_type == kActorDataClassAttribute)
        actor_->GetActorData()->GetActorAttributeData((eActorAttributeType)actor_data_type)->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      if (data_class_type == kActorDataClassStatus)
        actor_->GetActorData()->GetActorStatusData((eActorStatusType)actor_data_type)->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      if (data_class_type == kActorDataClassPosition)
        actor_->GetActorData()->GetActorPositionData((eActorPositionType)actor_data_type)->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      lua_signal_connection_map_[data_class_type].erase(lua_signal_connection_map_[data_class_type].find(actor_data_type));
    }
  }

  //direct access to ActorAttributeData
  bool ActorScriptExporter::CheckActorAttribute(int data_key)
  { return actor_->GetActorData()->CheckActorAttribute((eActorAttributeType)data_key); }
  //normal access, with event
  void ActorScriptExporter::InitActorAttribute(int data_key, float base/* = 0*/, float add/* = 0*/, float multiplier/* = 1*/, float extra/* = 0*/)
  { actor_->GetActorData()->InitActorAttribute((eActorAttributeType)data_key, base, add, multiplier, extra); }
  void ActorScriptExporter::SetActorAttribute(int data_key, float add/* = 0*/, float multiplier/* = 1*/, float extra/* = 0*/)
  { actor_->GetActorData()->SetActorAttribute((eActorAttributeType)data_key, add, multiplier, extra); }
  void ActorScriptExporter::AddActorAttribute(int data_key, float add/* = 0*/, float multiplier/* = 0*/, float extra/* = 0*/)
  { actor_->GetActorData()->AddActorAttribute((eActorAttributeType)data_key, add, multiplier, extra); }
  float ActorScriptExporter::GetActorAttribute(int data_key)
  { return actor_->GetActorData()->GetActorAttribute((eActorAttributeType)data_key); }

  //direct access to ActorStatusData
  bool ActorScriptExporter::CheckActorStatus(int data_key)
  { return actor_->GetActorData()->CheckActorStatus((eActorStatusType)data_key); }
  //normal access, with event
  void ActorScriptExporter::InitActorStatus(int data_key, int status)
  { actor_->GetActorData()->InitActorStatus((eActorStatusType)data_key, status); }
  void ActorScriptExporter::SetActorStatus(int data_key, int status)
  { actor_->GetActorData()->SetActorStatus((eActorStatusType)data_key, status); }
  int ActorScriptExporter::GetActorStatus(int data_key)
  { return actor_->GetActorData()->GetActorStatus((eActorStatusType)data_key); }
  //normal access, with event
  void ActorScriptExporter::InitActorStatusBool(int data_key, bool bool_status)
  { actor_->GetActorData()->InitActorStatusBool((eActorStatusType)data_key, bool_status); }
  void ActorScriptExporter::SetActorStatusBool(int data_key, bool bool_status)
  { actor_->GetActorData()->SetActorStatusBool((eActorStatusType)data_key, bool_status); }
  bool ActorScriptExporter::GetActorStatusBool(int data_key)
  { return actor_->GetActorData()->GetActorStatusBool((eActorStatusType)data_key); }

  //direct access to ActorPositionData
  bool ActorScriptExporter::CheckActorPosition(int data_key)
  { return actor_->GetActorData()->CheckActorPosition((eActorPositionType)data_key); }
  void ActorScriptExporter::InitActorPosition(int data_key, cocos2d::CCPoint position)
  { actor_->GetActorData()->InitActorPosition((eActorPositionType)data_key, position); }
  void ActorScriptExporter::SetActorPosition(int data_key, cocos2d::CCPoint position)
  { actor_->GetActorData()->SetActorPosition((eActorPositionType)data_key, position); }
  cocos2d::CCPoint& ActorScriptExporter::GetActorPosition(int data_key)
  { return actor_->GetActorData()->GetActorPosition((eActorPositionType)data_key); }



  ActorControlData* ActorScriptExporter::GetActorControlData()
  {
    assert(actor_);
    return actor_->GetActorData()->GetControlData();
  }

  void ActorScriptExporter::SetActorIsAutoGuard(bool is_auto)
  {
    assert(actor_);
    if (is_auto == true) actor_->GetActorData()->GetActorStatusData(kActorControlStatusAutoGuardType)->Reset();
    else actor_->GetActorData()->SetActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardInvalid);
  }

  void ActorScriptExporter::UpdateSpecialGuard(int type)
  {
    assert(actor_);
    actor_->GetControl()->UpdateSpecialGuard(type);
  }

  void ActorScriptExporter::ShowActorLog(int max_line)
  {
    assert(actor_);
    actor_->GetActorData()->GetLog()->ShowLog(max_line);
  }

  void ActorScriptExporter::SetActorSkillCycleList(std::string& skill_cycle_string)
  {
    assert(actor_);
    actor_->GetActorData()->GetSkillData()->SetSkillCycleList(skill_cycle_string);
  }


  int ActorScriptExporter::RequestCreateActor(int desired_actor_id, int actor_model_type) //will return created actor_id
  {
    assert(actor_);
    eActorModelType model_type = eActorModelType(actor_model_type);
    if (model_type == kActorModel) return ACTOR_INVALID_ID;

    int actor_id = actor_->GetActorExtEnv()->GetValidId(desired_actor_id);
    Actor* created_actor = actor_->GetActorExtEnv()->CreateActor(actor_id);
    created_actor->Init(model_type);
    return actor_id;
  }

  void ActorScriptExporter::RequestRemoveActor(int actor_id, bool instant_remove/* = false*/)
  {
    assert(actor_);
    if (actor_->GetActorExtEnv()->GetActorById(actor_id))
    {
      if (instant_remove)
      {
        actor_->GetActorExtEnv()->RemoveActor(actor_id);
      }
      else
      {
        //more logical
        switch (actor_->GetActorExtEnv()->GetActorById(actor_id)->GetActorModelType())
        {
        case kActorModelActor:
          actor_->GetActorData()->SetActorAttribute(kActorAttributeHealthCurrent, 0);
          break; 
        case kActorModelEffect:
        case kActorModelData:
          actor_->GetActorExtEnv()->RemoveActor(actor_id);
          break;
        default:
          assert(false);
          break;
        }
      }
    }
  }








  //export to lua // common static
  cocos2d::CCPoint ActorScriptExporter::GetPositionFromGrid(int grid_x, int grid_y)
  {
    return actor::GetPositionFromGrid(grid_x, grid_y);
  }
  cocos2d::CCPoint ActorScriptExporter::GetGridFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridFromPosition(position);
  }
  int ActorScriptExporter::GetGridXFromPositionX(float position_x)
  {
    return actor::GetGridXFromPositionX(position_x);
  }
  int ActorScriptExporter::GetGridYFromPositionY(float position_y)
  {
    return actor::GetGridYFromPositionY(position_y);
  }


  //for debug
  void ActorScriptExporter::ScriptAssert(bool expression, const std::string& message)
  {
    printf("[ActorScriptExporter][Assert] <%s> %s\n", expression ? "True" : "False", message.c_str());

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    assert(expression);
#endif
  }


  //for debug
  void ActorScriptExporter::SimulateTouchAt(float x, float y)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);
    cocos2d::CCSet* touch_set = new cocos2d::CCSet;
    touch_set->addObject(touch);
    printf("[ActorScriptExporter][SimulateTouchAt] x:%f, y:%f\n", x, y);
    SimulateTouch(touch_set, CCTOUCHBEGAN);
    SimulateTouch(touch_set, CCTOUCHENDED);
    //delete touch;
    delete touch_set;
#endif
  }

  void ActorScriptExporter::SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    switch (touch_event_id)
    {
    case CCTOUCHBEGAN:
    case CCTOUCHMOVED:
    case CCTOUCHENDED:
    case CCTOUCHCANCELLED:
      CCDirector::sharedDirector()->getTouchDispatcher()->touches(touch_set, NULL, touch_event_id);
      break;
    default:
      assert(false); //touch_event_id error
      break;
    }
#endif
  }

  static CCSet* _touch_set = NULL;
  cocos2d::CCSet* ActorScriptExporter::GetTouchSet(float x, float y)
  {
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);
    if (_touch_set) delete _touch_set;
    _touch_set = new cocos2d::CCSet;
    _touch_set->addObject(touch);
    return _touch_set;
  }

  const static char* __DefaultSkeletonFilePath = "textures/skeleton/";
  bool ActorScriptExporter::TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node)
  {
    std::string skeleton_config = __DefaultSkeletonFilePath + animation_name + ".xml";
    std::string skeleton_plist = __DefaultSkeletonFilePath + animation_name + ".plist";
    std::string skeleton_texture = __DefaultSkeletonFilePath + animation_name + ".pvr.ccz";
    CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
    CCArmature* armature = CCArmature::create(animation_name.c_str());
    upper_node->addChild(armature);
    armature->getAnimation()->play("bsj", 0, -1, 0);
    return true;
  }


} // namespace actor