#include "actor_ext_grid.h"

#include "actor.h"

namespace actor {
  
  /*
       /  |  \
      /   |   \
     /    |    \
  */
  
  enum eSeparate2DResultType
  {
    kSeparate2DResultLeft   = 1 << 0,
    kSeparate2DResultRight  = 1 << 1,
    kSeparate2DResultUp     = 1 << 2,
    kSeparate2DResultDown   = 1 << 3,
    kSeparate2DResultFailed = 0  //given point is on the line
    //kSeparate2DResult,
  };

  class Separate2D
  {
  public:
    Separate2D();
    Separate2D(float a, float b, float c);

    void FromPoints(float x1, float y1, float x2, float y2);
    void Set(float a, float b, float c);

    unsigned int Separate(float x, float y);

    bool IsLeft(float x, float y);
    bool IsRight(float x, float y);
    bool IsUp(float x, float y);
    bool IsDown(float x, float y);

    float GetY(float x);
    float GetX(float y);

  private:
    //0 = a * x + b * y + c
    float a_;
    float b_;
    float c_;

    //cached for speed
    //a != 0 | 0 = x + x_b * y + x_c
    float cache_x_b_;
    float cache_x_c_;

    //b != 0 | 0 = y_a * x + y + y_c
    float cache_y_a_;
    float cache_y_c_;
  };
  
  Separate2D::Separate2D() { Set(0, 0, 0); }  //all is kSeparate2DResultFailed
  Separate2D::Separate2D(float a, float b, float c) { Set(a, b, c); }

  void Separate2D::FromPoints(float x1, float y1, float x2, float y2)
  {
    float a = y2 - y1;
    float b = x1 - x2;
    float c = x2 * y1 - x1 * y2;
    Set(a, b, c);
  }

  void Separate2D::Set(float a, float b, float c)
  {
    a_ = a;
    b_ = b;
    c_ = c;

    cache_x_b_ = (a != 0) ? (b / a) : 0;
    cache_x_c_ = (a != 0) ? (c / a) : 0;

    cache_y_a_ = (b != 0) ? (a / b) : 0;
    cache_y_c_ = (b != 0) ? (c / b) : 0;
  }


  unsigned int Separate2D::Separate(float x, float y)
  {
    unsigned int result = kSeparate2DResultFailed;
    
    if (a_ != 0)
    {
      //can separate left and right
      float res = (x + cache_x_b_ * y + cache_x_c_);
      if (res < 0) result |= kSeparate2DResultLeft;
      if (res > 0) result |= kSeparate2DResultRight;
    }

    if (b_ != 0)
    {
      //can separate down and up
      float res = (cache_y_a_ * x + y + cache_y_c_);
      if (res < 0) result |= kSeparate2DResultDown;
      if (res > 0) result |= kSeparate2DResultUp;
    }

    return result;
  }


  bool Separate2D::IsLeft(float x, float y)
  {
    assert(a_ != 0);  //no left and right
    return (Separate(x, y) & kSeparate2DResultLeft) != 0;
  }

  bool Separate2D::IsRight(float x, float y)
  {
    assert(a_ != 0);  //no left and right
    return (Separate(x, y) & kSeparate2DResultRight) != 0;
  }

  bool Separate2D::IsUp(float x, float y)
  {
    assert(b_ != 0);  //no down and up
    return (Separate(x, y) & kSeparate2DResultUp) != 0;
  }

  bool Separate2D::IsDown(float x, float y)
  {
    assert(b_ != 0);  //no down and up
    return (Separate(x, y) & kSeparate2DResultDown) != 0;
  }

  float Separate2D::GetY(float x)
  {
    assert(b_ != 0);
    return - (a_ * x + c_) / b_;
  }

  float Separate2D::GetX(float y)
  {
    assert(a_ != 0);
    return - (b_ * y + c_) / a_;
  }


  const static int grid_row_size = 6;
  const static int grid_col_size = 3;

  const static float grid_col_list[] = {96.700012, 237.57001, 370.44000, 495.31000}; //from bottom to top
  const static float grid_row_top_list[] = {109.84000, 262.56000, 415.28000, 568.00000, 720.71997, 873.44000, 1026.1600};
  const static float grid_row_bottom_list[] = {73.839996, 238.56000, 403.28000, 568.00000, 732.71997, 897.44000, 1062.1600};  //wider than top for the fake 3D effect

  //calculated
  static float grid_box_average_width;
  static float grid_box_average_height;

  static float grid_col_middle;
  static float grid_row_middle;

  static Separate2D grid_row_separate_line[grid_row_size + 1];
  static Separate2D grid_col_separate_line[grid_col_size + 1];

  static cocos2d::CCPoint grid_box_joint_list[grid_col_size + 1][grid_row_size + 1]; //used here only
  static cocos2d::CCPoint grid_box_center_list[grid_col_size][grid_row_size];
  static cocos2d::CCPoint grid_box_actor_position_list[grid_col_size][grid_row_size];



  class CalculateGridBox
  {
  public:
    CalculateGridBox()
    {
      grid_box_average_width = (grid_row_top_list[grid_row_size] - grid_row_top_list[0] + grid_row_bottom_list[grid_row_size] - grid_row_bottom_list[0]) / grid_row_size * 0.5;
      grid_box_average_height = (grid_col_list[grid_col_size] - grid_col_list[0]) / grid_col_size;

      grid_col_middle = grid_col_list[(grid_col_size + 1) / 2];
      grid_row_middle = grid_row_bottom_list[(grid_row_size + 1) / 2];
      

      int i, j;

      for (i = 0; i < grid_row_size + 1; i++) { //i: row separate line
        grid_row_separate_line[i].FromPoints(
          grid_row_bottom_list[i], grid_col_list[0], 
          grid_row_top_list[i], grid_col_list[grid_col_size]);
      }

      for (j = 0; j < grid_col_size + 1; j++) { //j: col separate line
        grid_col_separate_line[j].FromPoints(
          grid_row_bottom_list[0], grid_col_list[j], 
          grid_row_bottom_list[grid_row_size], grid_col_list[j]);
      }

      for (i = 0; i < grid_row_size + 1; i++) {
        for (j = 0; j < grid_col_size + 1; j++) { //i: row joint | j: col joint
          grid_box_joint_list[j][i].setPoint(grid_row_separate_line[i].GetX(grid_col_list[j]), grid_col_list[j]);
        }
      }

      for (i = 0; i < grid_row_size; i++) {
        for (j = 0; j < grid_col_size; j++) { //i: row | j: col
          cocos2d::CCPoint center_position_4 = ccpAdd(
            ccpAdd(grid_box_joint_list[j][i], grid_box_joint_list[j][i + 1]), 
            ccpAdd(grid_box_joint_list[j + 1][i], grid_box_joint_list[j + 1][i + 1]));

          grid_box_center_list[j][i].setPoint(center_position_4.x / 4, center_position_4.y / 4);
          grid_box_actor_position_list[j][i].setPoint(center_position_4.x / 4, center_position_4.y / 4 - 50);
        }
      }
    }
  };

  static CalculateGridBox calculate_grid_box; //for a one time init



  //     <The Battle field>		
  //     0    |  1   2   3      4   5   6   |    7  //   grid_x |                             | 
  //          |                             |    4
  //  --------|-----------------------------|--------
  //          |  0   1   2      3   4   5   |    3
  //          |  6   7   8      9   10  11  |    2
  //          |  12  13  14     15  16  17  |    1
  //  --------|-----------------------------|--------
  //          |                             |    0
  //          |  tile index                 |  grid_y

  cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y)
  {
    return grid_box_actor_position_list[grid_y - 1][grid_x - 1];
  }

  cocos2d::CCPoint GetPositionFromGrid(cocos2d::CCPoint grid_position) 
  { 
    return GetPositionFromGrid(grid_position.x, grid_position.y); 
  }


  cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position)
  {
    int i, j, grid_row = 0, grid_col = 0;
    for (i = 0; i < grid_row_size + 1; i++) { //i: row separate line
      if (grid_row_separate_line[i].IsLeft(position.x, position.y)) break;
      grid_row++;
    }
    for (j = 0; j < grid_col_size + 1; j++) { //j: col separate line
      if (grid_col_separate_line[j].IsDown(position.x, position.y)) break;
      grid_col++;
    }
    return ccp(grid_row, grid_col);
  }

  int GetGridXFromPositionX(float position_x)
  {
    int i, grid_row = 0;
    for (i = 0; i < grid_row_size + 1; i++) { //i: row separate line
      if (grid_row_separate_line[i].IsLeft(position_x, grid_col_middle)) break;
      grid_row++;
    }
    return grid_row;
  }

  int GetGridYFromPositionY(float position_y)
  {
    int j, grid_col = 0;
    for (j = 0; j < grid_col_size + 1; j++) { //j: col separate line
      if (grid_col_separate_line[j].IsDown(grid_row_middle, position_y)) break;
      grid_col++;
    }
    return grid_col;
  }

  float GetGridBoxAverageWidth()
  {
    return grid_box_average_width;
  }
  float GetGridBoxAverageHeight()
  {
    return grid_box_average_height;
  }


  bool IsPositionInGrid(cocos2d::CCPoint position)
  {    return (grid_row_separate_line[0].IsRight(position.x, position.y) 
      && grid_row_separate_line[grid_row_size].IsLeft(position.x, position.y)
      && grid_col_separate_line[0].IsUp(position.x, position.y) 
      && grid_col_separate_line[grid_col_size].IsDown(position.x, position.y));
  }

  bool IsPositionXInGrid(cocos2d::CCPoint position)
  {
    return (grid_row_separate_line[0].IsRight(position.x, position.y) 
      && grid_row_separate_line[grid_row_size].IsLeft(position.x, position.y));
  }

  bool IsPositionYInGrid(cocos2d::CCPoint position)
  {
    return (grid_col_separate_line[0].IsUp(position.x, position.y) 
      && grid_col_separate_line[grid_col_size].IsDown(position.x, position.y));
  }

  cocos2d::CCPoint SnapToGrid(cocos2d::CCPoint position)
  {    return GetPositionFromGrid(GetGridFromPosition(position));
  }

  cocos2d::CCPoint SnapYToGrid(cocos2d::CCPoint position)
  {
    position.y = min(position.y, grid_col_list[0]);
    position.y = max(position.y, grid_col_list[grid_col_size]);
    return position;
  }





  ActorExtGrid::ActorExtGrid(ActorExtEnv* actor_ext_env)
    :actor_ext_env_(actor_ext_env)
  {
    Clear();
  }

  ActorExtGrid::~ActorExtGrid()
  {
    Clear();
  }

  void ActorExtGrid::Clear()
  {
    actor_grid_list_.clear();
  }


  //position/animation related
  Actor* ActorExtGrid::GetActorByPosition(cocos2d::CCPoint target_position)
  {
    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor
        && actor->GetAnimation()->GetActorBox().containsPoint(target_position))
        return actor;

      ++iterator;
    }

    return NULL;
  }

  Actor* ActorExtGrid::GetActorByGrid(cocos2d::CCPoint target_grid_position)
  {
    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor)
      {
        cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
        if (IsPositionInGrid(actor_position))
        {
          cocos2d::CCPoint actor_grid_position = GetGridFromPosition(actor_position);
          if (actor_grid_position.equals(target_grid_position))
            return actor;
        }
      }

      ++iterator;
    }

    return NULL;
  }

  std::list<Actor*>*    ActorExtGrid::GetActorListByGrid(cocos2d::CCPoint target_grid_position)
  {
    std::list<Actor*>* result_actor_list = new std::list<Actor*>;

    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor)
      {
        cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
        if (IsPositionInGrid(actor_position))
        {
          cocos2d::CCPoint actor_grid_position = GetGridFromPosition(actor_position);
          if (actor_grid_position.equals(target_grid_position))
            result_actor_list->push_back(actor);
        }
      }

      ++iterator;
    }

    return result_actor_list;
  }

  std::list<Actor*>*    ActorExtGrid::GetActorListByPosition(cocos2d::CCPoint target_position)
  {
    std::list<Actor*>* result_actor_list = new std::list<Actor*>;

    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor
        && actor->GetAnimation() && actor->GetAnimation()->GetActorBox().containsPoint(target_position)) 
      {
        result_actor_list->push_back(actor);
      }

      ++iterator;
    }

    return result_actor_list;
  }
  //position/animation related



  //position decision

  std::list<cocos2d::CCPoint>* ActorExtGrid::GetValidGridList(Actor* actor)  //need delete after use
  {
    //record grid taken status
    int grid_position_taken[GRID_X_RANGE][GRID_Y_RANGE] = {0};
    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list_.begin();
    while (iterator != actor_grid_list_.end())
    {
      Actor* ref_actor = iterator->first;

      if (ref_actor != actor && ref_actor->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == actor->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection))
      {
        cocos2d::CCPoint ref_grid_position = iterator->second;
        grid_position_taken[(int)(ref_grid_position.x - 1)][(int)(ref_grid_position.y - 1)] += 1;
      }

      ++iterator;
    }

    //search and check valid grid
    std::list<cocos2d::CCPoint>* valid_grid_list = new std::list<cocos2d::CCPoint>;
    int i, j;
    for (i = GRID_X_RANGE_LEFT; i <= GRID_X_RANGE_RIGHT; i++) {
      for (j = GRID_Y_RANGE_TOP; j <= GRID_Y_RANGE_BOTTOM; j++) {
        cocos2d::CCPoint grid_position = ccp(i, j);
        if (grid_position_taken[i - 1][j - 1] == 0 
          && actor->GetActorData()->GetSpecifiedData()->IsGridIdleValid(grid_position)) 
        {
          valid_grid_list->push_back(grid_position);
        }
      }
    }

    return valid_grid_list;
  }

  cocos2d::CCPoint ActorExtGrid::GetValidGrid(Actor* actor, cocos2d::CCPoint preferred_grid_position)
  {
    std::list<cocos2d::CCPoint>* valid_grid_list = GetValidGridList(actor);

    bool is_backup_grid_position_valid = false;
    cocos2d::CCPoint backup_grid_position;
    float nearest_valid_grid_distance = 99999;

    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;

        if (actor->GetActorData()->GetSpecifiedData()->IsGridIdleValid(grid_position))
        {
          is_backup_grid_position_valid = true;
          float distance = preferred_grid_position.getDistance(grid_position);

          if (distance < nearest_valid_grid_distance)
          {
            nearest_valid_grid_distance = distance;
            backup_grid_position = grid_position;
            if (distance == 0) break;  //find nearest, stop searching
          }
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    if (is_backup_grid_position_valid)
    {
      actor_grid_list_.push_back(std::pair<Actor*, cocos2d::CCPoint>(actor, backup_grid_position));  //prevent another actor move to 
      return backup_grid_position;
    }
    else
    {
      if (actor->GetActorData()->GetSpecifiedData()->IsGridIdleValid(preferred_grid_position) == false)
      {
        float preferred_grid_x = actor->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT_MIDDLE : GRID_X_RANGE_RIGHT_MIDDLE;
        //so sad the lame makeshift position
        return ccp(preferred_grid_x, GRID_Y_RANGE_MIDDLE);
      }
      else
      {
        return preferred_grid_position;
      }
    }
  }

  cocos2d::CCPoint ActorExtGrid::GetValidGrid(Actor* actor)
  {
    return GetValidGrid(actor, GetGridFromPosition(actor->GetActorData()->GetActorPosition(kActorPositionAnimation))
      //actor_->GetActorData()->GetActorPosition(kActorSpecifiedPositionLastIdleGrid)
      );
  }
  //position decision




  //for actor grid need, update every Update()
  void ActorExtGrid::UpdateActorGridList()
  {
    actor_grid_list_.clear();

    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      int actor_id = iterator->first;
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor && actor->GetIsActorAlive())
      {
        cocos2d::CCPoint actor_position;
        if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationPositionMove))
        {  
          cocos2d::CCPoint actor_position = actor->GetActorData()->GetControlData()->GetPositionOperationData(kActorControlOperationPositionMove);
          if (IsPositionInGrid(actor_position))
            actor_grid_list_.push_back(std::pair<Actor*, cocos2d::CCPoint>(actor, GetGridFromPosition(actor_position)));
        }

        if (actor->GetActorData()->GetActorStatus(kActorMotionStatusIsBusy) == false)
        {
          cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
          if (IsPositionInGrid(actor_position))
            actor_grid_list_.push_back(std::pair<Actor*, cocos2d::CCPoint>(actor, GetGridFromPosition(actor_position)));
        }
      }

      ++iterator;
    }

    return;
  }

  bool ActorExtGrid::CheckActorGridOverlap(Actor* actor)
  {
    cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

    if (IsPositionInGrid(actor_position) == false) return false;
    else return CheckActorGridOverlap(actor, GetGridFromPosition(actor_position));
  }

  bool ActorExtGrid::CheckActorGridOverlap(Actor* actor, cocos2d::CCPoint grid_position)
  {
    int actor_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction);

    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list_.begin();
    while (iterator != actor_grid_list_.end())
    {
      Actor* ref_actor = iterator->first;
      cocos2d::CCPoint ref_actor_grid_position = iterator->second;

      if (actor != ref_actor 
        && grid_position.equals(ref_actor_grid_position) 
        && actor_faction == ref_actor->GetActorData()->GetActorStatus(kActorStatusFaction))
        return true;

      ++iterator;
    }

    return false;
  }


} // namespace actor