#include "actor_adapter.h"

#include "actor.h"
#include "actor_script_exporter.h"
#include "game/actor/control/actor_control.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/motion/actor_motion_state_machine.h"
#include "game/actor/trigger/actor_trigger_predefined.h"
#include "game/actor/animation/actor_animation_skeleton_animation.h"


#include "game/army/unit/monster.h"
#include "game/army/unit/character.h"

#include "game/battle/battle_controller.h"
#include "game/battle/level/levelbase.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "game/user_interface/battle_ui/battle_ui_constants.h"

#include "game/ago_skill/control/ASkillControl.h"

#include "game/battle/view/battle_view.h"
#include "game/battle/view/battle_layer.h"
#include "game/battle/view/aim_mark.h"
#include "game/battle/view/battle_view_constant.h"

#include "game/game_manager/data_manager.h"

#include "engine/base/random_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"
#include "base/utils_string.h"

namespace actor
{

  // TODO: remove
  //used only in this file
  //don't want tile index in actor system, used only:
  //  PositionCorrection (Primary)
  //  position (Secondary)
  //  grid x/y (Remedy, should be enough)
  //below only used for tile_index to grid_x/y
  const int tile_index_to_grid_x_list[18] = {
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6
  };
  const int tile_index_to_grid_y_list[18] = {
    3,  3,  3,      3,  3,  3,
    2,  2,  2,      2,  2,  2,
    1,  1,  1,      1,  1,  1
  };

  int GetGridXFromTileIndex(int tile_index) { return tile_index_to_grid_x_list[tile_index]; }
  int GetGridYFromTileIndex(int tile_index) { return tile_index_to_grid_y_list[tile_index]; }
  //used only in this file



  //Searches the string for the first character that matches any of the characters specified in delimiter_string.
  //delimiter can be ",|. " for multi-match
  std::list<std::string>* ActorStringSplit(std::string& source_string, std::string delimiter)
  {
    std::list<std::string>* result_list = new std::list<std::string>;
    std::string::size_type remain_string_index = 0, delimiter_index = std::string::npos, substr_count = 0;

    do {
      delimiter_index = source_string.find_first_of(delimiter, remain_string_index);
      substr_count = (delimiter_index == std::string::npos ? std::string::npos : delimiter_index - remain_string_index);
      result_list->push_back(source_string.substr(remain_string_index, substr_count));
      remain_string_index = delimiter_index + 1;  //skip delimiter
    } while (delimiter_index != std::string::npos);

    return result_list;
  }  




  void AutoReleaseSpecialSkill(int actor_id)
  {
    taomee::battle::BattleController::GetInstance().battle_ui()->SkillReleaseButtonSelected(actor_id);
  }
  
  bool GetIsAllyActorAuto()
  {
    return (ActorScriptExporter::GetIsAutoControl() || GetIsActorExtEnvPVPAuto());
  }
  
  bool GetIsActorExtEnvPVP()
  {
    return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_PVP_Manual
      || taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_PVP_Auto;  //same thing
  }
  bool GetIsActorExtEnvPVPAuto()
  {
    return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_PVP_Auto;
  }

  ActorExtEnv* GetActorExtEnv()
  {
    return taomee::battle::BattleController::GetInstance().GetActorExtEnv();
  }


  void ShowDamageLabel(int actor_id, int damage_type, float damage_value)
  {
    Actor* actor = GetActorExtEnv()->GetActorById(actor_id);

    if (actor && actor->GetIsActorAlive())
    {
      ShowDamageLabel(actor, damage_type, damage_value);
    }
  }


  void ShowStatusLabel(int actor_id, int status_type)
  {
    ShowDamageLabel(actor_id, status_type, 0);
  }


  void ShowDamageLabel(Actor* actor, int damage_type, float damage_value)
  {
    taomee::battle::eDamageLabelType damege_label_type = taomee::battle::eDamageLabelType(damage_type);
    bool is_user_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport;

    cocos2d::CCPoint label_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
    label_position.y += actor->GetAnimation()->GetActorVisualHeight();

    taomee::battle::DamageLabel* label = taomee::battle::DamageLabel::create(damege_label_type, damage_value, is_user_faction);
    label->ShowDamageValueOnBattleLayer(taomee::battle::BattleController::GetInstance().battle_view(), label_position);
  }


  void ShowStatusLabel(Actor* actor, int status_type)
  {
    ShowDamageLabel(actor, status_type, 0);
  }


  void AlertEnemyPassRightBorder(int actor_id)
  {
    battle::BattleController::GetInstance().notifyMonsterMoveToRightBorder(actor_id);
  }





  void InitDefaultActorAttribute(ActorAdapter* actor_adapter, Actor* actor);
  void InitDefaultActorStatus(ActorAdapter* actor_adapter, Actor* actor);
  void InitDefaultActorPosition(ActorAdapter* actor_adapter, Actor* actor);


  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter)
  {
    //actor_adapter->set_is_active(false);
    actor_adapter->GoDeadStation(actor_adapter->get_dead_reason());
  }


  void NastyActorInitAfterBasicDataInitAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    CharacterData* character_data = actor_adapter->character_card_data();

    InitDefaultActorAttribute(actor_adapter, actor);
    InitDefaultActorStatus(actor_adapter, actor);
    InitDefaultActorPosition(actor_adapter, actor);

    actor->SetScriptObjectName(character_data->GetName());

    //set data
    actor->GetActorData()->InitActorStatus(kActorStatusFaction, actor_adapter->IsPlayer() ? kActorFactionUserSupport : kActorFactionUserOppose);
    
    switch (character_data->GetEnemyGrade())
    {
    case kEnemyGradeSelf:
      actor->GetActorData()->InitActorStatus(kActorStatusAppearance, kActorAppearanceCharacter);
      break;
    case kEnemyGradeNormal:
      actor->GetActorData()->InitActorStatus(kActorStatusAppearance, kActorAppearanceEnemyPawn);
      break;
    case kEnemyGradeLowBoss:
    case kEnemyGradeHighBoss:
    case kEnemyGradeWorldBoss:
      actor->GetActorData()->InitActorStatus(kActorStatusAppearance, kActorAppearanceEnemyBoss);
      break;
    default:
      assert(false);
      break;
    }

    switch (taomee::army::eAttackType(character_data->GetAILogicType()))
    {
    case taomee::army::kAttackTypeAttack:
      actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackType, kActorAttackMelee);
      actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuardMelee);
      break;
    case taomee::army::kAttackTypeShot:
      actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackType, kActorAttackRanged);
      actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuardRanged);
      break;
    case taomee::army::kAttackTypeHeal:
      actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackType, kActorAttackHeal);
      actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuardRanged);
      break;
    default:
      actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackType, kActorAttack);  //not attack
      actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuard);
      break;
    }


    switch (taomee::army::eCareerType(character_data->GetJobType()))
    {
    case taomee::army::kCareerTypeWarrior:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerWarrior);
      break;
    case taomee::army::kCareerTypeArcher:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerArcher);
      break;
    case taomee::army::kCareerTypeWizard:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerWizard);
      break;
    case taomee::army::kCareerTypeMonk:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerPriest);
      break;
    case taomee::army::kCareerTypeKnight:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerKnight);
      break;
    default:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareer);
      break;
    }

    actor->GetActorData()->InitActorStatus(kActorAnimationStatusDirection, actor_adapter->IsPlayer() ? kActorAnimationDirectionLeft : kActorAnimationDirectionRight);
    actor->GetActorData()->InitActorStatus(kActorSpecifiedStatusHomeDirection, actor_adapter->IsPlayer() ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);


    

    if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter
      && actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport
      && GetIsActorExtEnvPVP() == false)
    {
      actor->GetActorData()->InitActorStatusBool(kActorSpecifiedStatusIsLimitGridX, true);
    }
    else
    {
      actor->GetActorData()->InitActorStatusBool(kActorSpecifiedStatusIsLimitGridX, false);
    }

    //control
    actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsManual, actor_adapter->IsPlayer());
    actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsAuto, !actor_adapter->IsPlayer());
  }



  void NastyActorInitAnimationInitAdapter(ActorAdapter* actor_adapter, Actor* actor, bool is_simple_init)
  {
    ActorData* actor_data = actor->GetActorData();
    int actor_id = actor->GetScriptObjectId();

    actor->GetAnimation()->Init(is_simple_init ? kActorAnimationModelActorLite : kActorAnimationModelActor);

    // TODO: remove? | Boss Effect
    if (actor_data->GetActorStatus(kActorStatusAppearance) == kActorAppearanceEnemyBoss)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/WarningUI.lua", "ShowBossWarningUIToBattleScene");
      //Add Boss Effect
      taomee::SkeletonAnimation* boss_effect = new taomee::SkeletonAnimation();
      boss_effect->Init("boss_bjtx", "boss_bjtx");
      boss_effect->Play("bsj");
      actor->GetAnimation()->GetActorNode()->addChild(boss_effect, -1);
    }
  }







  void NastyActorInitAfterAnimationInitAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    CharacterData* character_data = actor_adapter->character_card_data();
    
    //init trigger
    //init trigger

    float actor_attack_trigger_size_multiplier = 1.0f;
    switch (actor->GetActorData()->GetActorStatus(kActorSkillStatusAttackType))
    {
    case kActorAttackMelee:
      actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerCircle, actor, actor_attack_trigger_size_multiplier));
      break;
    case kActorAttackHeal:
      actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerHeal, actor, actor_attack_trigger_size_multiplier));
      break;
    case kActorAttackRanged:
      actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerRect, actor, actor_attack_trigger_size_multiplier));
      break;
    default:
      actor->GetActorData()->GetSkillData()->SetAttackTrigger(NULL);
      break;
    }


    float actor_guard_trigger_size_multiplier = 1.0f * character_data->GetPatrolScale();
    switch (actor->GetActorData()->GetActorStatus(kActorSkillStatusGuardType))
    {
    case kActorGuardMelee:
      actor->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerCircle, actor, actor_guard_trigger_size_multiplier));
      actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerCircle, actor));
      break;
    case kActorGuardRanged:
      actor->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerRect, actor, actor_guard_trigger_size_multiplier));
      actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerRect, actor));
      break;
    default:
      actor->GetActorData()->GetSkillData()->SetGuardTrigger(NULL);
      actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(NULL);
      break;
    }


    bool is_auto = true;
    if (is_auto)
    {
      switch (actor->GetActorData()->GetActorStatus(kActorSkillStatusGuardType))
      {
      case kActorGuardMelee:
        actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerCircle, actor));
        break;
      case kActorGuardRanged:
        actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerRect, actor));
        break;
      default:
        actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(NULL);
        break;
      }

      if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) != kActorAppearanceCharacter
        && actor->GetActorData()->GetSkillData()->GetGuardTriggerAuto())
      {
        //monster not auto guard by default
        actor->GetActorData()->GetSkillData()->GetGuardTriggerAuto()->SetIsPause(true);
      }
      

      //init control auto guard
      if ((GetIsActorExtEnvPVP() == true && actor_adapter->IsPlayer() == false) || (GetIsActorExtEnvPVPAuto() == true))
      {
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardPreferY);

        if (actor->GetActorData()->GetSkillData()->GetGuardTrigger())
        {
          delete actor->GetActorData()->GetSkillData()->GetGuardTrigger();
          actor->GetActorData()->GetSkillData()->SetGuardTrigger(NULL);
        }
      }
      else
      {
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardDefault);
      }
      //auto guard will be enabled in actor routine control
    }



    //init skill
    //init skill

    int skill_index_array[] = {
      kSkillNormal,
      kSkillPower1,
      kSkillPower2,
      kSkillSpecial
    };

    eActorSkillType skill_type_array[] = {
      kActorSkillNormal,
      kActorSkillPower,
      kActorSkillPower,
      kActorSkillSpecial
    };

    taomee::army::Character* actor_adapter_character = NULL;
    if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)
      actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);

    int skill_index = 0;
    for (skill_index = 0; skill_index < 4; skill_index++)
    {
      int skill_id = character_data->GetSkillId(skill_index_array[skill_index]);

      if (skill_id > 0)
      {
        bool is_sandbox = taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_SandBox;
        int skill_level = (actor_adapter_character && !is_sandbox) ? actor_adapter_character->getSkillLevel(skill_id) : 1;

        if (skill_level > 0)
        {
          eActorSkillType skill_type = skill_type_array[skill_index];
          actor->GetActorData()->GetSkillData()->AddSkillInfo(skill_id, skill_level, skill_type);
        }
        else
        {
          actor->GetActorData()->GetLog()->AddErrorLogF("[ActorAdapter] discard level %d skill: card_id:%d skill_id:%d", skill_level, actor_adapter->card_id(), skill_id);
        }
      }
    }

    //set attack cycle
    std::string attack_cycle = character_data->GetAttackCycle();
    if (attack_cycle == "")
    {
      actor->GetActorData()->GetLog()->AddErrorLogF("[ActorAdapter] empty skill cycle! default used");
      assert(false);
      attack_cycle = "0|0|0|1";
    }
    actor->GetActorData()->GetSkillData()->SetSkillCycleList(attack_cycle);


    //init control auto release skill
    if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)
    {
      if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport && GetIsActorExtEnvPVPAuto() == false)
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillWithPause);
      else
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillNoPause);
    }
    else
    {
      if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceEnemyPawn
        && character_data->GetSkillId(kSkillSpecial) > 0 && character_data->GetSkillRate() > 0)
      {
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillByAttackCount);
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillCount, character_data->GetSkillRate());
      }
      else
      {
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillInvalid);
      }
    }



    //init actor script
    //init actor script

    // �ƶ�Script����(�����ڲ��ɿ�����):
    // 0 - ���ƶ�AI
    // 1001 - �޹��� ԭ��ֹͣ
    // 1002 - �޹��� ǰ�� ��ͣ�� ����
    // 2001 - ���� ǰ�� ��ͣ�� ����
    // 2002 - ���� ǰ�� ������һ��ͣ�� ����
    // 2003 - ���� ǰ�� �����ڶ���ͣ�� ����
    // 3001 - BOSS ���� ǰ�� �����ڶ���ͣ�� ���������

    std::string routine_name = "";
    int born_grid_x = -1;
    int born_grid_y = -1;

    if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserOppose)
    {
      switch(character_data->GetAIMoveType())
      {
      case 1001: //�޹��� ԭ��ֹͣ
        routine_name = "routine_config_enemy_blind";
        born_grid_x = -1;
        actor->AddScriptObjectData(std::string("is_skip_exit"), 1);
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, false);
        break;
      case 1002: //�޹��� ǰ�� ��ͣ�� ����
        routine_name = "routine_config_enemy_blind";
        born_grid_x = -1;
        //actor->AddScriptObjectData(std::string("is_skip_exit"), 1);
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, false);
        break;

      case 2001: //���� ǰ�� ��ͣ�� ����
        routine_name = "routine_config_enemy_pawn";
        born_grid_x = -1;
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, true);
        break;
      case 2002: //���� ǰ�� ������һ��ͣ�� ����
        routine_name = "routine_config_enemy_pawn";
        born_grid_x = 1;
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, true);
        break;
      case 2003: //���� ǰ�� �����ڶ���ͣ�� ����
        routine_name = "routine_config_enemy_pawn";
        born_grid_x = 2;
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, true);
        break;

      case 3001: //BOSS ���� ǰ�� �����ڶ���ͣ�� ���������
        routine_name = "routine_config_boss_immobile";
        born_grid_x = 2;
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, false);
        break;
      case 3002: //BOSS GUARD NPC �޹��� ԭ��ֹͣ (x:3, y:2)��ͣ�� ���������
        routine_name = "routine_config_boss_guard_npc";
        born_grid_x = 2;
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, false);
        break;

      case 0: //���ƶ�AI
      default:
        routine_name = "routine_config_default";
        born_grid_x = -1;
        actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, false);
        break;
      }

      born_grid_y = GetGridYFromPositionY(actor_adapter->current_pos().y);
      actor->AddScriptObjectData(std::string("born_grid_x"), born_grid_x);
      actor->AddScriptObjectData(std::string("born_grid_y"), born_grid_y);
    }
    else
    {
      routine_name = "routine_config_character";

      taomee::army::Character* actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);
      if (actor_adapter_character)
      {
        int born_tile_index = actor_adapter_character->garrison_tile_index();
        born_grid_x = GetGridXFromTileIndex(born_tile_index);
        born_grid_y = GetGridYFromTileIndex(born_tile_index);
      }

      actor->AddScriptObjectData(std::string("born_grid_x"), born_grid_x);
      actor->AddScriptObjectData(std::string("born_grid_y"), born_grid_y);
      actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsCounterAttack, true);
    }

    actor->CallScriptObjectFunction("InitRoutineControl", routine_name);
    actor->CallScriptObjectFunction("InitBuffControl", routine_name);

    //first reset direction
    actor->GetActorData()->GetActorStatusData(kActorAnimationStatusDirection)->Reset();

    //initial logic state
    actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateBorn));

    actor->GetActorData()->GetLog()->AddErrorLogF("[NastyActorInitAfterAnimationInitAdapter] Ready");
  }



//   void NastyActorClearAnimationAdapter(ActorAdapter* actor_adapter, Actor* actor)
//   {
//     //clean up, for the data-reuse
//     actor->GetAnimation()->Clear();
//   }





  const std::string GetDeadAnimationName(ActorAdapter* actor_adapter)
  {
    const taomee::battle::eDeadReason dead_reason = actor_adapter->get_dead_reason();
    std::string animation_name = "";

    switch (dead_reason)
    {
    case taomee::battle::kDeadReason_Disappear:
      animation_name = taomee::army::kUnitAnimationIdle;
      break;
    case taomee::battle::kDeadReason_Suicide:
      animation_name = taomee::army::kUnitAnimationDead_2;
      break;
    case taomee::battle::kDeadReason_Normal:
    default:
      animation_name = taomee::army::kUnitAnimationDead;
      break;
    }

    if (actor_adapter->GetActor()->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->existedAnimationName(animation_name) == false)
      animation_name = taomee::army::kUnitAnimationDead;

    return animation_name;
  }

  const std::string GetSkeletonAnimationName(int card_id)
  {
    CharacterData* character_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    return character_data->GetName();
  }
  const float GetSkeletonAnimationScale(int card_id)
  {
    CharacterData* character_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    return character_data->GetSkeletonScale();
  }





  //add & experimental


  void InitDefaultActorAttribute(ActorAdapter* actor_adapter, Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();
    CharacterData* character_data = actor_adapter->character_card_data();

    actor_data->InitActorAttribute(kActorAttributeTimeActive, 0);

    actor_data->InitActorAttribute(kActorAttributeHealthCurrent, 0, actor_adapter->currnet_health_point());
    actor_data->InitActorAttribute(kActorAttributeEnergyCurrent, 0, actor_adapter->energy_value());
    actor_data->InitActorAttribute(kActorAttributeHealthMax, actor_adapter->total_health_point());
    actor_data->InitActorAttribute(kActorAttributeEnergyMax, taomee::ui::getKMaxAngry());

    actor_data->InitActorAttribute(kActorAttributeFactorCritical, character_data->GetInitPropertyByType(kAttrTypeCritRate));
    actor_data->InitActorAttribute(kActorAttributeFactorHit, character_data->GetInitPropertyByType(kAttrTypeHitRate), /*(lv-1)*/character_data->GetAddPropertyByType(kAttrTypeHitRate));
    actor_data->InitActorAttribute(kActorAttributeFactorDodge, character_data->GetInitPropertyByType(kAttrTypeDodgeRate), /*(lv-1)*/character_data->GetAddPropertyByType(kAttrTypeDodgeRate));

    actor_data->GetActorAttributeData(kActorAttributeFactorCritical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeFactorHit)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeFactorDodge)->SetLimit(0);

    actor_data->InitActorAttribute(kActorAttributeSpeedAttack, character_data->GetAtkSpeed());
    actor_data->InitActorAttribute(kActorAttributeSpeedMove, character_data->GetMovSpeed() * taomee::battle::kMapTileAverageLength);

    actor_data->GetActorAttributeData(kActorAttributeSpeedAttack)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeSpeedMove)->SetLimit(0);

    actor_data->InitActorAttribute(kActorAttributeAttackPhysical, actor_adapter->physics_attack());
    actor_data->InitActorAttribute(kActorAttributeAttackMagical, actor_adapter->magic_attack());
    actor_data->InitActorAttribute(kActorAttributeAttackCritical, character_data->GetInitPropertyByType(kAttrTypeCritDamage));

    actor_data->GetActorAttributeData(kActorAttributeAttackPhysical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeAttackMagical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeAttackCritical)->SetLimit(0);

    actor_data->InitActorAttribute(kActorAttributeDefensePhysical, actor_adapter->physics_defense());
    actor_data->InitActorAttribute(kActorAttributeDefenseMagical, actor_adapter->magic_defense());
    actor_data->InitActorAttribute(kActorAttributeDefenseCritical, 0);

    actor_data->GetActorAttributeData(kActorAttributeDefensePhysical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDefenseMagical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDefenseCritical)->SetLimit(0);

    actor_data->InitActorAttribute(kActorAttributeDamageAddition, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionPhysical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionMagical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionCritical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionIce, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionFire, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionWind, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionHealth, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionEnergy, 0);

    actor_data->GetActorAttributeData(kActorAttributeDamageAddition)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionPhysical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionMagical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionCritical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionIce)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionFire)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionWind)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionHealth)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageAdditionEnergy)->SetLimit(0);

    actor_data->InitActorAttribute(kActorAttributeDamageReduction, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionPhysical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionMagical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionCritical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionIce, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionFire, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionWind, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionHealth, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionEnergy, 0);

    actor_data->GetActorAttributeData(kActorAttributeDamageReduction)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionPhysical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionMagical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionCritical)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionIce)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionFire)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionWind)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionHealth)->SetLimit(0);
    actor_data->GetActorAttributeData(kActorAttributeDamageReductionEnergy)->SetLimit(0);

    actor_data->InitActorAttribute(kActorSkillAttributeAttackCount, 0);
    actor_data->InitActorAttribute(kActorSkillAttributeAttackNormalCount, 0);
    actor_data->InitActorAttribute(kActorSkillAttributeAttackPowerCount, 0);
    actor_data->InitActorAttribute(kActorSkillAttributeAttackSpecialCount, 0);
  }



  void InitDefaultActorStatus(ActorAdapter* actor_adapter, Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();
    CharacterData* character_data = actor_adapter->character_card_data();
    
    //actor_data->InitActorStatus(kActorStatusActorId, actor->GetActorId());
    actor_data->InitActorStatus(kActorStatusCardId, actor_adapter->card_id());
    actor_data->InitActorStatus(kActorStatusLevel, actor_adapter->level());

    //get above
//     actor_data->InitActorStatus(kActorStatusAppearance, 0);
//     actor_data->InitActorStatus(kActorStatusFaction, 0);
//     actor_data->InitActorStatus(kActorStatusCareer, 0);

    actor_data->InitActorStatusBool(kActorStatusAcceptDamage, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamagePhysical, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageMagical, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageCritical, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageIce, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageFire, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageWind, 1);

    actor_data->InitActorStatusBool(kActorControlStatusIsCounterAttack, false);


    actor_data->InitActorStatusBool(kActorLogicStatusIsIncontrollable, false);
    actor_data->InitActorStatusBool(kActorLogicStatusCanMove, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttack, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttackNormal, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttackPower, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttackSpecial, true);


    actor_data->InitActorStatusBool(kActorSkillStatusIsPaused, false);
    actor_data->InitActorStatusBool(kActorAnimationStatusIsPaused, false);
    actor_data->InitActorStatusBool(kActorAnimationStatusIsHealthChanged, false);

    actor_data->InitActorStatus(kActorStatusLogicState, kActorLogicStateInvalid);
    actor_data->InitActorStatus(kActorStatusMotionState, kActorMotionStateInvalid);

    actor_data->InitActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardInvalid);


    actor_data->InitActorStatusBool(kActorMotionStatusIsBusy, false);
    actor_data->InitActorStatusBool(kActorSkillStatusIsBusy, false);

    actor_data->InitActorStatus(kActorSkillStatusCurrentSkillId, ACTOR_INVALID_ID);

    
    actor_data->InitActorStatus(kActorBuffStatusShaderType, shader::kShaderDefault);
    actor_data->InitActorStatusBool(kActorBuffStatusIsPauseAnimation, false);
    actor_data->InitActorStatusBool(kActorBuffStatusIsChangeColor, false);
  }



  void InitDefaultActorPosition(ActorAdapter* actor_adapter, Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();
    CharacterData* character_data = actor_adapter->character_card_data();
    
    //apply animation position
    actor_data->InitActorPosition(kActorPositionAnimation, ccp(0, 0));
    actor_data->InitActorPosition(kActorMotionPositionMoveTarget, ccp(0, 0));
    actor_data->InitActorPosition(kActorMotionPositionMoveSpeedUnit, ccp(0, 0));

  }
}