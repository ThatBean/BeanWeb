#include "actor_animation_effect.h"

#include "game/actor/actor.h"

#include "game/actor/actor_adapter.h"

#include "engine/script/lua_tinker_manager.h"

#include "game/army/unit/unit_constants.h"

namespace actor {

  //ActorAnimationEffect
  ActorAnimationEffect::ActorAnimationEffect(Actor* actor)
    :actor_(actor)
  {
    //
  }

  ActorAnimationEffect::~ActorAnimationEffect()
  {
    Clear();
  }

  void ActorAnimationEffect::Clear()
  {
    
  }

  void ActorAnimationEffect::Init()
  {
    
  }


  void ActorAnimationEffect::Update(float delta_time)
  {
    
  }

  //ActorAnimationEffect
} // namespace actor