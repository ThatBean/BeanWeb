#ifndef ACTOR_ANIMATION_H
#define ACTOR_ANIMATION_H

#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace taomee {
  class SkeletonAnimation;
  class ProjectileAnimation;
}


namespace actor {

  class Actor;
  class ActorAnimation;
  class ActorAnimationSkeletonAnimation;
  class ActorAnimationOverheadLayer;
  class ActorAnimationBottomSyncLayer;
  



  //record a Queue to play
  enum eActorAnimationQueueDataType {
    kActorAnimationQueueDataArmature,
    kActorAnimationQueueDataProjectile,
    kActorAnimationQueueData
  };

  typedef struct sActorAnimationQueueData{
    sActorAnimationQueueData()
      : animation_type(kActorAnimationQueueData)
      , loop_count(-1)
    {}

    eActorAnimationQueueDataType animation_type;
    cocos2d::CCPoint position;
    std::string animation_name;
    std::string armature_name;
    int loop_count;
  } ActorAnimationQueueData;

  class ActorAnimationQueue : public CCObject
  {
  public:
    ActorAnimationQueue();
    ~ActorAnimationQueue();
    void OnArmatureMovementEvent(cocos2d::extension::CCArmature* armature, cocos2d::extension::MovementEventType event_type, const char* movement_name);
    void Append(const ActorAnimationQueueData& animation_data); //add Animation you want to play next
    void Attach(ActorAnimation* actor_animation);
    void Detach();  //erase from attached ActorAnimation and delete self data
    void AutoPlayNext();  //may cause auto Detach
    void AutoPlayAndDetach(); //play on and detach if "CanAutoFinish == true", detach now if "CanAutoFinish == false"

    bool CheckCanAutoFinish();
    unsigned int GetId() { return this->m_uID; }

  protected:
    void PlayArmature();
    void PlayProjectile();
    void CleanCurrent();

  private:
    std::list<ActorAnimationQueueData> data_queue_;
    ActorAnimationQueueData current_data_;

    ActorAnimation* actor_animation_;
    
    cocos2d::extension::CCArmature* armature_;
    taomee::ProjectileAnimation* projectile_;
  };








  class ActorAnimation
  {
  public:
    ActorAnimation(Actor* actor_);
    ~ActorAnimation();

    void Clear();
    void Init(eActorAnimationModelType animation_model_type);

    void Update(float delta_time);

    ActorAnimationSkeletonAnimation*  GetAnimationSkeletonAnimation() { return animation_skeleton_animation_; }
    ActorAnimationOverheadLayer*      GetAnimationOverheadLayer() { return animation_overhead_layer_; }
    ActorAnimationBottomSyncLayer*    GetAnimationBottomSyncLayer() { return animation_bottom_sync_layer_; }

    cocos2d::CCNode* GetActorNode() { return actor_node_; }
    cocos2d::CCRect GetActorBox();
    float GetActorVisualHeight();

    bool ChangeAnimation(const std::string animation_name, const int cycle_count = -1, const float speed = 1.0f);
    void DeadAnimation(std::string animation_name);  //play dead cc action

    void SetColorShader(cocos2d::ccColor4F shader_color, float last_time);

    cocos2d::CCNode* AddArmatureAnimation(cocos2d::CCPoint position_offset, const std::string & armature_name, const std::string & animation_name);
    cocos2d::CCNode* AddProjectileAnimation(cocos2d::CCPoint position_offset, const std::string& projectile_name);
    void RemoveAnimationByTag(int tag);
    
    ActorAnimationQueue* CreateAnimationQueue();
    ActorAnimationQueue* GetAnimationQueue(unsigned int animation_queue_id);
    void RemoveAnimationQueue(unsigned int animation_queue_id);

  protected:
    void RemoveColorShader();
    void SetStatusShader(int shader_type);

  private:
    Actor* actor_;

    cocos2d::CCNode*  actor_node_;  //default CCSprite node or ActorAnimationSkeletonAnimation

    ActorAnimationSkeletonAnimation*  animation_skeleton_animation_;
    ActorAnimationOverheadLayer*      animation_overhead_layer_;
    ActorAnimationBottomSyncLayer*    animation_bottom_sync_layer_;

    cocos2d::CCLabelBMFont* label_debug_info_widget_;

    //selection shader
    cocos2d::ccColor4F shader_color_;
    cocos2d::CCGLProgram* program_shader_color_;  //actually taomee::shader::ProgramChangeColor*
    float shader_color_left_time_;
    float shader_color_total_time_;

    //status shader | will conflict with selection shader(use status shader only)
    int shader_type_; //default is kShaderDefault

    std::map<unsigned int, ActorAnimationQueue*> animation_queue_map_;
  };
} // namespace actor


#endif // ACTOR_ANIMATION_H