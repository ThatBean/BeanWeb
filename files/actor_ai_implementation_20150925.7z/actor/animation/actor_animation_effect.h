#ifndef ACTOR_ANIMATION_EFFECT_H
#define ACTOR_ANIMATION_EFFECT_H

#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;


  class ActorAnimationEffect
  {
  public:
    ActorAnimationEffect(Actor* actor_);
    ~ActorAnimationEffect();

    void Clear();
    void Init();

    void Update(float delta_time);

  private:
    Actor* actor_;
  };
} // namespace actor


#endif // ACTOR_ANIMATION_EFFECT_H