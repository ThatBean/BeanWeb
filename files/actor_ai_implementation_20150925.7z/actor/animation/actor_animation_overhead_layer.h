#ifndef ACTOR_ANIMATION_OVERHEAD_LAYER_H
#define ACTOR_ANIMATION_OVERHEAD_LAYER_H

#include "game/actor/actor_adapter.h"
#include "cocos2d.h"

namespace actor {

  class Actor;

  class ActorAnimationOverheadLayer
  {
  public:
    ActorAnimationOverheadLayer(Actor* actor_);
    ~ActorAnimationOverheadLayer();

    void Clear();
    void Init();

    void Update(float delta_time);

    cocos2d::extension::UILayer* GetOverheadLayer() { return overhead_layer_; };

  private:
    Actor* actor_;

    UILayer* overhead_layer_; //a UILayer mainly for actor health display, under skeleton animation, no need to clean up
    
    cocos2d::extension::UIWidget* health_bar_layer_;
    cocos2d::extension::UILoadingBar* health_bar_widget_;
    cocos2d::extension::UILoadingBar* health_bar_bg_widget_;
    float health_bar_left_time_;
  };

} // namespace actor


#endif // ACTOR_ANIMATION_OVERHEAD_LAYER_H