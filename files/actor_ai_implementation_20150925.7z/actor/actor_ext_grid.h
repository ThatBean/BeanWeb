#ifndef ACTOR_EXT_GRID_H
#define ACTOR_EXT_GRID_H

#include "cocos2d.h"
#include "engine/base/basictypes.h"

namespace actor {
  class Actor;
  class ActorExtEnv;


  //Position & Grid
  cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
  cocos2d::CCPoint GetPositionFromGrid(cocos2d::CCPoint grid_position);

  cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
  int GetGridXFromPositionX(float position_x);
  int GetGridYFromPositionY(float position_y);

  float GetGridBoxAverageWidth();
  float GetGridBoxAverageHeight();

  bool IsPositionInGrid(cocos2d::CCPoint position);
  bool IsPositionXInGrid(cocos2d::CCPoint position);
  bool IsPositionYInGrid(cocos2d::CCPoint position);
  cocos2d::CCPoint SnapToGrid(cocos2d::CCPoint position);
  cocos2d::CCPoint SnapYToGrid(cocos2d::CCPoint position);
  //Position & Grid



  // the geometry map where actors live in (Actor Pool)
  class ActorExtGrid  //ActorExternalGrid
  {
  public:
    ActorExtGrid(ActorExtEnv* actor_ext_env);
    ~ActorExtGrid();

    void Clear();

    //position/animation related
    Actor*    GetActorByPosition(cocos2d::CCPoint target_position);
    Actor*    GetActorByGrid(cocos2d::CCPoint target_grid_position);
    std::list<Actor*>*    GetActorListByGrid(cocos2d::CCPoint target_grid_position);
    std::list<Actor*>*    GetActorListByPosition(cocos2d::CCPoint target_position);
    //position/animation related

    //position decision
    std::list<cocos2d::CCPoint>* GetValidGridList(Actor* actor);  //need delete after use 
    cocos2d::CCPoint GetValidGrid(Actor* actor, cocos2d::CCPoint preferred_grid_position);
    cocos2d::CCPoint GetValidGrid(Actor* actor);  //for idle grid decision
    //position decision

    //for actor grid need, update every Update()
    void UpdateActorGridList();
    std::list< std::pair<Actor*, cocos2d::CCPoint> >* GetActorGridList() { return &actor_grid_list_; }
    bool CheckActorGridOverlap(Actor* actor);
    bool CheckActorGridOverlap(Actor* actor, cocos2d::CCPoint grid_position);
    //for actor grid need, update every Update()

  private:
    std::list< std::pair<Actor*, cocos2d::CCPoint> >     actor_grid_list_;

    ActorExtEnv* actor_ext_env_;
  };

} // namespace actor


#endif // ACTOR_EXT_GRID_H