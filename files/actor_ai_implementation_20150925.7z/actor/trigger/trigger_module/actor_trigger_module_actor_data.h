#ifndef ACTOR_TRIGGER_MODULE_ACTOR_DATA_H
#define ACTOR_TRIGGER_MODULE_ACTOR_DATA_H


#include "game/actor/trigger/actor_trigger_module.h"
#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"


namespace actor 
{
  enum eActorTriggerActorDataFlag
  {
    kActorTriggerActorDataFlagAttribute = 1 << 0,
    kActorTriggerActorDataFlagStatus    = 1 << 1,
    kActorTriggerActorDataFlagPosition  = 1 << 2,
    kActorTriggerActorDataFlagAliveActor  = 1 << 10, //special for attackable
    kActorTriggerActorDataFlag = 0
  };

  enum eActorTriggerActorDataFilterMethod
  {
    kActorTriggerActorDataFilterMethodEqual = 1,
    kActorTriggerActorDataFilterMethodEqualNot,
    kActorTriggerActorDataFilterMethodApproximate,
    kActorTriggerActorDataFilterMethod = 0
  };

  class ActorTriggerModuleDataActorData: public ActorTriggerModuleData
  {
  public:
    static const uint_32 TARGET_MODULE_TYPE;

    ActorTriggerModuleDataActorData() 
      : ActorTriggerModuleData(),
      filter_method_attribute_(kActorTriggerActorDataFilterMethod),
      filter_method_status_(kActorTriggerActorDataFilterMethod),
      filter_method_position_(kActorTriggerActorDataFilterMethod),
      tolerance_attribute_(0),
      tolerance_status_(0),
      tolerance_position_(0)
    {

    }

    void SetFilterAttribute(eActorTriggerActorDataFilterMethod filter_method, eActorAttributeType filter_data_type, float filter_value, float tolerance = 0); //tolerance = diff-ratio
    void SetFilterStatus(eActorTriggerActorDataFilterMethod filter_method, eActorStatusType filter_data_type, int filter_value, float tolerance = 0); //tolerance = diff-value
    void SetFilterPosition(eActorTriggerActorDataFilterMethod filter_method, eActorPositionType filter_data_type, cocos2d::CCPoint filter_value, float tolerance = 0);  //tolerance = distance

    //faster loop filter
    void ResetQuickFilter();
    bool InitQuickFilter(Actor* actor);  //return init result: true = need filter, false = keep all
    bool QuickFilter(Actor* ref_actor);  //return is_filtered: true = remove, false = keep

  private:
    eActorTriggerActorDataFilterMethod filter_method_attribute_;
    eActorTriggerActorDataFilterMethod filter_method_status_;
    eActorTriggerActorDataFilterMethod filter_method_position_;

    eActorAttributeType filter_data_type_attribute_;
    eActorStatusType filter_data_type_status_;
    eActorPositionType filter_data_type_position_;

    float filter_value_attribute_;
    int filter_value_status_;
    cocos2d::CCPoint filter_value_position_;

    float tolerance_attribute_;
    float tolerance_status_;
    float tolerance_position_;


    //quick filter data
    bool  _filter_is_use_attribute_;
    bool  _filter_is_use_status_;
    bool  _filter_is_use_position_;
    bool  _filter_is_use_alive_actor_;
  };

  class ActorTriggerModuleActorData: public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleActorData() {}

  public:
    static ActorTriggerModuleActorData* Instance();
    ~ActorTriggerModuleActorData() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateActorData(Actor* actor, ActorTriggerModuleDataActorData* trigger_module_data, std::list<Actor*>* actor_list);

  private:
    static const eActorTriggerModule trigger_module_type_;

  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_ACTOR_DATA_H