#include "actor_ext_damage.h"

#include "actor.h"

#include "game/actor/actor_script_exporter.h"

#include "engine/base/random_helper.h"
#include "game/game_manager/data_manager.h"
#include "game/event/event_battle/event_battle_obj.h"

namespace actor {


  DamagePackage::DamagePackage()
  {
    InitDamage();
  }
  DamagePackage::~DamagePackage()
  {
    //
  }


  //basic method
  void DamagePackage::InitDamage()
  {
    attribute_map_.GetDataMap()->clear();
    status_map_.GetDataMap()->clear();

    InitStatus(kActorDamageStatusCountAddProcessActor, 0);
    InitStatus(kActorDamageStatusCountSubProcessActor, 0);

    InitStatus(kActorDamageStatusSourceActorId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceSkillId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceBuffId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceEffectId, ACTOR_INVALID_ID);

    InitStatus(kActorDamageStatusTargetActorId, ACTOR_INVALID_ID);

    is_active_ = false;
  }

  void DamagePackage::AddDamage(
    eActorDamageAttributeType   damage_type,
    float   damage_add/* = 0*/,
    float   damage_multiplier/* = 1*/,
    float   damage_extra/* = 0*/
    )
  {
    if (damage_type == kActorDamageAttribute)
    {
      assert(false);
      return;
    }

    if (attribute_map_.Check(damage_type))
    {
      InitAttribute(damage_type);
    }

    attribute_map_.GetData(damage_type)->Add(damage_add, damage_multiplier, damage_extra);
  }

  float DamagePackage::GetDamage(unsigned long damage_type_filter)
  {
    if (!is_active_) 
    {
      assert(is_active_);
      return 0;
    }

    float result_damage = 0;

    std::map<eActorDamageAttributeType, DamageAttributeData>::iterator iterator = attribute_map_.GetDataMap()->begin();
    while (iterator != attribute_map_.GetDataMap()->end())
    {
      if (iterator->first & damage_type_filter)
        result_damage += iterator->second.Get();

      ++iterator;
    }

    return result_damage;
  }
  //DamagePackage






  //ActorExtDamage
  ActorExtDamage::ActorExtDamage(ActorExtEnv* actor_ext_env)
    :actor_ext_env_(actor_ext_env)
  {
    //
  }

  ActorExtDamage::~ActorExtDamage()
  {
    Clear();
  }

  void ActorExtDamage::Clear()
  {
    std::list<DamagePackage*>::iterator iterator = damage_package_list_.begin();

    while (iterator != damage_package_list_.end())
    {
      DamagePackage* damage_package = *iterator;

      *iterator = NULL;

      if (damage_package) delete damage_package;

      iterator++;
    }

    damage_package_list_.clear();
  }


  void ActorExtDamage::Update(float delta_time)
  {
    std::list<DamagePackage*> process_damage_package_list;

    //take a snapshot
    process_damage_package_list.assign(damage_package_list_.begin(), damage_package_list_.end());

    //ready for next row
    damage_package_list_.clear();

    std::list<DamagePackage*>::iterator iterator = process_damage_package_list.begin();
    while (iterator != process_damage_package_list.end())
    {
      DamagePackage* damage_package = *iterator;

      *iterator = NULL; //unlink damage package

      if (damage_package) ApplyDamagePackage(damage_package);
      else assert(damage_package);  //strange empty damage

      iterator++;
    }

    process_damage_package_list.clear();
  }



  void ActorExtDamage::DamageDealt(
    DamagePackage* damage_package,
    int target_actor_id, 
    float damage_value, 
    float consumed_value, 
    eActorDamageAttributeType damage_attribute_type, 
    eActorAttributeType data_key)
  {
    //target actor
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);
    if (target_actor && consumed_value > 0 && damage_attribute_type == kActorDamageAttributeHealth)
    {
      eActorSkillType skill_type = eActorSkillType(damage_package->GetStatus(kActorDamageStatusSourceSkillType));
      bool is_normal_attack = (skill_type == kActorSkillNormal);

      int damage_type = taomee::battle::kDamageTypePhysics;

      int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);
      if (skill_id != ACTOR_INVALID_ID)
      {
        SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
        damage_type = skillData ? skillData->GetDamageType() : taomee::battle::kDamageTypePhysics;
      }
      else
      {
        if (damage_value < 0)
          damage_type = taomee::battle::kDamageTypeHeal;
        else if (damage_package->GetAttribute(kActorDamageAttributeHealth) > 0)
          damage_type = taomee::battle::kDamageTypeHoly;
        else if (damage_package->GetAttribute(kActorDamageAttributeMagical) > 0)
          damage_type = taomee::battle::kDamageTypeMagic;
        else if (damage_package->GetAttribute(kActorDamageAttributePhysical) > 0)
          damage_type = taomee::battle::kDamageTypePhysics;
        else 
          damage_type = taomee::battle::kDamageTypeUnkown;
      }


      //pop damage label
      if (damage_package->GetStatusBool(kActorDamageStatusIsMissed)) 
      {
        ShowStatusLabel(target_actor, taomee::battle::eDamageLabelType_Dodge);
      }
      else if (damage_package->GetStatusBool(kActorDamageStatusIsHeal))
      {
        ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Heal, consumed_value);
      }
      else if (damage_package->GetStatusBool(kActorDamageStatusIsSuicide))
      {
        ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Physics, consumed_value);
      }
      else 
      {
        if (damage_package->GetStatusBool(kActorDamageStatusIsCritical))
        {
          ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_PhysicsCritical, consumed_value);
        }
        else
        {
          if (damage_type == taomee::battle::kDamageTypePhysics && is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Physics, consumed_value);
          else if (damage_type == taomee::battle::kDamageTypePhysics && !is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_PhysicsSkill, consumed_value);
          else if (damage_type == taomee::battle::kDamageTypeMagic && is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Magic, consumed_value);
          else if (damage_type == taomee::battle::kDamageTypeMagic && !is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_MagicSkill, consumed_value);
          else 
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Physics, consumed_value);
        }
      }

      //add color shader
      if (damage_package->GetStatusBool(kActorDamageStatusIsHeal))
      {
        // add healing green effect 
        target_actor->GetAnimation()->SetColorShader(ccc4f(0.0f, 0.5f, 0.0f, 0.5f), 0.5f);
      }
      else
      {
        // add hit red effect
        target_actor->GetAnimation()->SetColorShader(ccc4f(1.0f, 0.0f, 0.0f, 0.6f), 0.5f);
      }
    }



    //source actor
    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = GetActorExtEnv()->GetActorById(source_actor_id);
    if (source_actor && source_actor->GetIsActorAlive())
    {
      if (damage_package->GetStatusBool(kActorDamageStatusIsMissed)) 
      {
        ShowStatusLabel(source_actor, taomee::battle::eDamageLabelType_Dodge);
      }
      else
      {
        //Emit Damage Dealt Event
        source_actor->GetActorScriptExporter()->OnDamageDealt(
          target_actor->GetActorData()->GetActorStatus(kActorStatusActorId), 
          target_actor->GetActorData()->GetActorStatus(kActorStatusActorModel), 
          damage_attribute_type, 
          consumed_value);
      }
    }

  }





  void ActorExtDamage::AddDamagePackage(DamagePackage* damage_package, bool is_hold_till_next_update/* = true*/) //For later Send(in Update)
  {
    if (is_hold_till_next_update)
    {
      damage_package_list_.push_back(damage_package);
    }
    else
    {
      ApplyDamagePackage(damage_package);
    }
  }


  void ActorExtDamage::ApplyDamagePackage(DamagePackage* damage_package) //Consume instantly
  {
    damage_package = CalcTargetSubProcess(damage_package);


    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    if (source_actor && source_actor->GetIsActorAlive())
    {
      damage_package = source_actor->GetActorData()->GetDamageData()->NotifyDamageResult(damage_package);
    }

    //currently no other use...
    if (damage_package) delete damage_package;
  }



  DamagePackage* ActorExtDamage::CalcSourceAddProcess(DamagePackage* damage_package)
  {
    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);

    if (source_actor && source_actor->GetIsActorAlive())
    {
      //add up
      damage_package = source_actor->GetActorData()->GetDamageData()->AddProcess(damage_package);
    }
    else
    {
      CCLog("[CalcSourceAddProcess] DamagePackage source actor invalid, source_actor_id: %d", source_actor_id);
      damage_package->SetIsActive(false);
    }

    return damage_package;
  }


  DamagePackage* ActorExtDamage::CalcTargetSubProcess(DamagePackage* damage_package)
  {
    int target_actor_id = damage_package->GetStatus(kActorDamageStatusTargetActorId);
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);

    if (target_actor && target_actor->GetIsActorAlive())
    {
      //consume up
      damage_package = target_actor->GetActorData()->GetDamageData()->SubProcess(damage_package);

      int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
      int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);
      taomee::ByHitEvent::Emit(target_actor_id , source_actor_id, taomee::battle::kAttackResultNormalDamage);
      taomee::HitEvent::Emit(source_actor_id, target_actor_id, taomee::battle::kAttackResultNormalDamage, skill_id, false);
    }
    else
    {
      CCLog("[CalcTargetSubProcess] DamagePackage Target Missing! target_actor_id: %d", target_actor_id);
      damage_package->SetIsActive(false);
    }

    return damage_package;
  }






  DamagePackage* ActorExtDamage::QuickInitSkillDamage(int source_actor_id, int target_actor_id, int skill_id)
  {
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);

    if (source_actor/* && source_actor->GetIsActorAlive()*/
      && target_actor/* && target_actor->GetIsActorAlive()*/
      && skill_id != ACTOR_INVALID_ID)
    {
      DamagePackage* damage_package = new DamagePackage;

      damage_package->InitStatus(kActorDamageStatusTargetActorId, target_actor_id);

      damage_package->InitStatus(kActorDamageStatusSourceActorId, source_actor_id);
      damage_package->InitStatus(kActorDamageStatusSourceActorLevel, source_actor->GetActorData()->GetActorStatus(kActorStatusLevel));

      damage_package->InitStatus(kActorDamageStatusSourceSkillId, skill_id);

      ActorSkillInfo* skill_info = source_actor->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);

      eActorSkillType skill_type = source_actor->GetActorData()->GetSkillData()->GetSkillTypeById(skill_id);
      int skill_level = skill_info ? skill_info->skill_level : 0;

      damage_package->InitStatus(kActorDamageStatusSourceSkillLevel, skill_level);
      damage_package->InitStatus(kActorDamageStatusSourceSkillType, skill_type);
      

      //decide critical and miss, only for normal attack
      if (skill_type == kActorSkillNormal)
      {
        //decide Critical
        float factor_critical = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorCritical);

        int target_actor_level = source_actor->GetActorData()->GetActorStatus(kActorStatusLevel);

        if (target_actor_level > 100) target_actor_level = 100;
        if (factor_critical > 5000.0f) factor_critical = 5000.0f;
        float rate_critical = factor_critical / (factor_critical + target_actor_level * 15.0f + 200.0f);

        bool is_critical = taomee::random_0_1() <= rate_critical;
        if (is_critical) damage_package->InitStatusBool(kActorDamageStatusIsCritical, true);


        //decide Miss
        float factor_hit = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorHit);
        float factor_dodge = target_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorDodge);

        float rate_hit = 0.8f + ( factor_hit - factor_dodge ) / 1000.0f;
        if (rate_hit < 0.6f) rate_hit = 0.6f;
        if (rate_hit > 1.0f) rate_hit = 1.0f;

        bool is_hit = taomee::random_0_1() <= rate_hit;
        if (!is_hit) damage_package->InitStatusBool(kActorDamageStatusIsMissed, true);
      }

      damage_package->SetIsActive(true);

      return damage_package;
    }

    return NULL;
  }
} // namespace actor