#include "actor_logic_state_idle.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateIdle::STATE_TYPE = kActorLogicStateIdle;

  LogicStateIdle* LogicStateIdle::Instance()
  {
    static LogicStateIdle instance;
    return &instance;
  }


  void LogicStateIdle::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateIdle][OnEnter]");

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIdle));
    actor->GetActorData()->GetControlData()->SetCountdown(0);
  }

  void LogicStateIdle::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateIdle][OnExit]");

//     if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter
//       && IsPositionInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)))
//     {
//       actor->GetActorData()->SetActorPosition(kActorSpecifiedPositionLastIdleGrid, GetGridFromPosition(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)));
//     }
  }

  void LogicStateIdle::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[LogicStateIdle][Update]");
    //check trigger
    if (actor->GetActorData()->GetControlData()->IsSetOperation() == false
      && actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdownGuard();

      //reset direction
      actor->GetActorData()->GetActorStatusData(kActorAnimationStatusDirection)->Reset();
      
      if (IsPositionInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation))) //logic only run when actor entered grid
      {
        if (actor->GetActorData()->GetSkillData()->CheckAttackTrigger())
        {
          //goto Attack, commit attack
          //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
          return;
        }

        if (actor->GetActorData()->GetSkillData()->CheckGuardTrigger())
        {
          //goto Move, move closer and guard
          //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
          return;
        }

        //check overlap and off grid center
        if (CommonCheckGridPosition(actor))
        {
          //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
          return;
        }
      }

    }
  }
} // namespace actor