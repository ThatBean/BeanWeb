#ifndef DATA_LOG_H
#define DATA_LOG_H

#include "time.h"
#include "cocos2d.h"

namespace actor {

  class DataLog
  {
  public:
    DataLog();
    ~DataLog();

    void Clear();

    void AddErrorLogF(const char* format, ...);
    void AddLogF(const char* format, ...);
    void AddLog(const char* log, bool is_force_print = false);
    void ShowLog(int max_line = 20);
    std::string GetLogText(int max_line = 20);

    void SetId(int log_id);
    void SetMute(bool log_mute);
    void ResetStartTime();

  private:
    int log_id_;
    clock_t log_start_timestamp_;
    bool log_mute_;
    std::list<std::string> log_list_;
  };

} // namespace actor

#endif // DATA_LOG_H