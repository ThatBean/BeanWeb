#include "data_log.h"

namespace actor {

  DataLog::DataLog()
  {
    log_id_ = -1;
    log_mute_ = false;
    log_start_timestamp_ = clock();
  }

  DataLog::~DataLog() 
  {
    Clear();
  }


  void DataLog::Clear()
  {
    log_list_.clear();
  }

  void DataLog::AddErrorLogF(const char* format, ...)
  {
    char temp_text[1024];
    va_list ap;
    va_start(ap, format);
    vsnprintf(temp_text, 1024, format, ap);
    va_end(ap);
    AddLog(temp_text, true);
  }

  void DataLog::AddLogF(const char* format, ...)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    char temp_text[1024];
    va_list ap;
    va_start(ap, format);
    vsnprintf(temp_text, 1024, format, ap);
    va_end(ap);
    AddLog(temp_text, false);
#endif
  }


  void DataLog::AddLog(const char* log, bool is_force_print/* = false*/)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    std::string log_string;
    char time_text[255];
    sprintf(time_text, "<ID:%d|%.3fs|%.3fs>\t", 
      log_id_, 
      double(clock() - log_start_timestamp_) / CLOCKS_PER_SEC, 
      double(clock()) / CLOCKS_PER_SEC);
    log_string += time_text;
    log_string += log;

    log_list_.push_front(log_string + "\n");

    if (!log_mute_ || is_force_print) 
      cocos2d::CCLog(log_string.c_str());
#endif
  }

  void DataLog::ShowLog(int max_line/* = 20*/)
  {
    cocos2d::CCLog("%s",GetLogText(max_line).c_str());
  }

  std::string DataLog::GetLogText(int max_line/* = 20*/)
  {
    std::string log_text = "";
    int line_count = 0;
    std::list<std::string>::iterator iterator = log_list_.begin();
    while (iterator != log_list_.end() 
      && (max_line < 0 || line_count < max_line))
    {
      log_text += *iterator;
      line_count++;
      iterator++;
    }
    return log_text;
  }


  void DataLog::SetId(int log_id) { log_id_ = log_id; }
  void DataLog::SetMute(bool log_mute) { log_mute_ = log_mute; }
  void DataLog::ResetStartTime() { log_start_timestamp_ = clock(); }
} // namespace actor