			#include <iostream>
#include "SDKManager.h"
#import "account_manager.h"
#import "AppDelegate.h"
#import "engine/script/lua_tinker_manager.h"

#ifdef TargetForPP
#import "PPLoginMan.h"
#import "PPPayMan.h"
#endif
#ifdef TargetForItools
#import "HXPaymentMan.h"
#import "HXLoginMan.h"
#endif

#ifdef TargetFor91
//#import <NdComPlatform/NDComPlatform.h>
//#import <NdComPlatform/NdComPlatformAPIResponse.h>
//#import <NdComPlatform/NdCPNotifications.h>
#include "NdLoginMan.h"
#include "NdPayMan.h"
#endif


USING_NS_CC;
using namespace std;
using namespace taomee::account;

int SDKManager::reLoginFlag = 0;
SDKManager::SDKManager()
{
    reLoginFlag = 0;
}
SDKManager::~SDKManager()
{
    
}

//login
void SDKManager::doLogin()
{
#ifdef TargetForPP
    
    [[PPLoginMan sharedInstance] doLogin];
#endif
#ifdef TargetForItools
    
    [[HXLoginMan sharedInstance] doLogin];
#endif
#ifdef TargetFor91
    //[[HXLoginMan sharedInstance] doLogin];
    //[[NdComPlatform defaultPlatform] NdLogin:0];
    [[NdLoginMan sharedInstance] doLogin];
#endif
}

void SDKManager::initSDK()
{
    #ifdef TargetFor91
        [[NdLoginMan sharedInstance] initWithScreenOrientation:UIInterfaceOrientationLandscapeRight];
    #endif
    
    #ifdef TargetForPP
        [[PPLoginMan sharedInstance] initWithScreenOrientation];
    #endif

    
}


//for repeated login
void SDKManager::doLastUserLogin()
{
#ifdef TargetForPP
    //[[PPLoginMan sharedInstance] doLogout];
    [[PPLoginMan sharedInstance] doLogin];
#endif
#ifdef TargetForItools
    //[[HXLoginMan sharedInstance] doLogout];
    [[HXLoginMan sharedInstance] doLogin];
#endif
#ifdef TargetFor91
    //[[NdLoginMan sharedInstance] doLogout];
    [[NdLoginMan sharedInstance] doLogin];
#endif

}

bool SDKManager::isLogin()
{
#ifdef TargetForPP
   return [[PPLoginMan sharedInstance] isLogined];
#endif
#ifdef TargetForItools
    return [[HXLoginMan sharedInstance] isLogined];
#endif
#ifdef TargetFor91
    return [[NdLoginMan sharedInstance] isLogined];
    //return [[NdComPlatform defaultPlatform] isLogined];
#endif
    return false;
}

void SDKManager::doLogout()
{
    reLoginFlag = 2;
#ifdef TargetForPP
    [[PPLoginMan sharedInstance] doLogout];
#endif
#ifdef TargetForItools
    [[HXLoginMan sharedInstance] doLogout];
#endif
#ifdef TargetFor91
    [[NdLoginMan sharedInstance] doLogout];
    //[[NdComPlatform defaultPlatform] NdLogout:1];
#endif

}

void SDKManager::didLogout()
{
    if(reLoginFlag != 2)
    {
        reLoginFlag = 1;
        LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "hadLoginOutAlert");
    }
    else
    {
        reLoginFlag = 0;
    }
}

void SDKManager::reSetReLoginFlag(int loginFlag)
{
    reLoginFlag = loginFlag;
}

void SDKManager::doPay(const char *productid, const char *userid, const char *serverid, const char *moneyType, const char *price, const char *userRegistTime, const char *level)
{
    NSString* pid = [NSString stringWithCString:productid encoding:[NSString defaultCStringEncoding]];
    NSString* uid = [NSString stringWithCString:userid encoding:[NSString defaultCStringEncoding]];
    
    //int channelx = [[LoginController sharedInstance] getChannelId];
    int channelx = 1;
    NSString* cid = [NSString stringWithFormat:@"%d",channelx];
    
    NSString* sid = [NSString stringWithCString:serverid encoding:[NSString defaultCStringEncoding]];
    NSString* cashType = [NSString stringWithCString:moneyType encoding:[NSString defaultCStringEncoding]];
    
    //NSDate *localDate = [NSDate date];
    //NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[localDate timeIntervalSince1970]];
    NSString* timeSp = [NSString stringWithCString:userRegistTime encoding:[NSString defaultCStringEncoding]];
    
#ifdef TargetForPP
    [PPPayMan sharedInstance].isInnerMode = NO;
    [[PPPayMan sharedInstance] doPayWithProductId:pid userId:uid channelId:@"25" serverId:sid currency:@"CNY" andUserCreateTime:timeSp];
#endif
#ifdef TargetFor91
    [NdPayMan sharedInstance].isInnerMode = NO;
    [[NdPayMan sharedInstance] doPayWithProductId:pid userId:uid channelId:@"24" serverId:sid currency:@"CNY" andUserCreateTime:timeSp];
#endif
}

void SDKManager::loginFrom3d(string userid,string userName,string userToken)
{
    
    if(reLoginFlag == 1)
    {
        reLoginFlag = 2;
        LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "hadReLoginInAlert");
        return;
    }
    reLoginFlag = 0;
#ifdef TargetForPP
    AccountManager::GetInstance().hasLoginFrom3rd = false;
    AccountManager::GetInstance().sendLogin3rdRequest(userid ,userName,userToken,25);
#endif
#ifdef TargetForItools
    AccountManager::GetInstance().hasLoginFrom3rd = false;
    AccountManager::GetInstance().sendLogin3rdRequest(userid ,userName,userToken,38);
#endif
#ifdef TargetFor91
    AccountManager::GetInstance().hasLoginFrom3rd = false;
    AccountManager::GetInstance().sendLogin3rdRequest(userid ,userName,userToken,24);
#endif
    
   
}

void SDKManager::showUserCenter()
{
    #ifdef TargetForPP
        [[PPLoginMan sharedInstance] showUserCenter];
    #endif
}










