#ifndef SDKManager_h
#define SDKManager_h

#include <string>
#include "cocos2d.h"
USING_NS_CC;
using namespace std;

class SDKManager:public cocos2d::CCObject
{
public:
    SDKManager();
    virtual ~SDKManager();
    // for login
    static void doLogin();
    static void doLogout();
    static void doLastUserLogin();
    static bool isLogin();
    static void didLogout();
    static void showUserCenter();
    static void initSDK();
    
    // for pay
    static void doPay(const char* productid, const char* userid  ="", const char* serverid = "", const char* moneyType = "", const char* price = "", const char* userRegistTime = "", const char* level = "");
    static void loginFrom3d(string userid,string userName,string userToken);
    
    static void reSetReLoginFlag(int loginFlag);
    
    static int reLoginFlag;
};



#endif
