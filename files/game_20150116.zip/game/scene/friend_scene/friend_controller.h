//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: friend_controller.h
//        Author: Sachin
//          Date: 2013/11/26 16:25
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Sachin    2013/11/26      add
//////////////////////////////////////////////////////////////

#ifndef FRIEND_CONTROLLER_H
#define FRIEND_CONTROLLER_H
#include "engine/base/basictypes.h"

#include <boost/shared_ptr.hpp>
#include <boost/signal.hpp>

#include "engine/platform/SingleInstance.h"

namespace cocos2d
{
class CCScene;
class CCArray;
}
using namespace cocos2d;

namespace taomee
{
class TouchHelper;
class LoadHelper;
class IHandleDelegate;

namespace net
{
class BaseSession;
template <typename MessageIn, typename MessageOut>
class NetSession;

namespace search_friend_by_userid_in
{
  class Search_friend_by_userid_in;
}

namespace search_friend_by_userid_out
{
  class Search_friend_by_userid_out;
}

namespace search_friend_by_nick_in
{
  class Search_friend_by_nick_in;
}

namespace search_friend_by_nick_out
{
  class Search_friend_by_nick_out;
}

namespace send_add_friend_in
{
  class Send_add_friend_in;
}

namespace send_add_friend_in
{
  class Send_add_friend_in;
}

namespace get_friend_list_in
{
  class Get_friend_list_in;
}

namespace get_friend_list_out
{
  class Get_friend_list_out;
}

namespace get_friend_req_list_in
{
  class Get_friend_req_list_in;
}

namespace get_friend_req_list_out
{
  class Get_friend_req_list_out;
}

namespace resp_friend_req_in
{
  class Resp_friend_req_in;
}

namespace delete_friend_in
{
  class Delete_friend_in;
}

namespace get_helper_list_in
{
  class Get_helper_list_in;
}

namespace get_helper_list_out 
{
  class Get_helper_list_out;
}

namespace send_set_assist_card_in
{
  class Send_set_assist_card_in;
}

namespace get_strange_list_in
{
  class Get_strange_list_in;
}

namespace get_strange_list_out
{
  class Get_strange_list_out;
}

namespace del_stranger_helper_in
{
  class Del_stranger_helper_in;
}

} // namespace net

namespace data
{
  class FriendInfo;
}

class FriendController : public SingleInstanceObj
{
 public:
  FriendController();
  ~FriendController();
  static FriendController& GetInstance()
  {
    static FriendController* X = NULL;
    if (!X)
    {
      X = new FriendController();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }   

  void Prepare(LoadHelper* load_helper);

  void UpdateEachFrame(float delta);
  void Start();
  void End();

  void SendSearchFriendRequest(const char* friend_name); 
  void SendRequestFriendRequest(const std::string& friend_uid);
  void SendGetRequestListRequest();
  void SendGetStrangeListRequest();
  void SendGetFriendListRequest();
  void SendRespFriendReq(const std::string& friend_uid, bool result);
  void SendDelFriendReq(const std::string& friend_uid);
  void SendDelStrangeHelperReq(const std::string& friend_uid);
  void SendGetHelperReq();

  bool  isAssistCard(int sid) { return sid == mAssendCardSID; };

  void  InitAssistCard(int card_sid) { mAssendCardSID = card_sid; };
  void  SendSetAssendCardRequest(int card_sid);
  int   GetAssendCardSID() { return mAssendCardSID; }
  void  CheckAssistCardValid();

  void OpenFriendHelperUI();
  void UpdateFriendData();
  uint_32 GetUpdateInterval();

  data::FriendInfo* GetSearchFriendInfo();

  uint_32 GetStrangeListCount();
  data::FriendInfo* GetStrangeByIndex(int_32 index);
  void  RemoveStrangeByUid(const std::string& friend_uid);
  void  RemoveStrangeList();

  uint_32 GetReqListCount();
  data::FriendInfo* GetReqFriendByIndex(int_32 index);
  data::FriendInfo* GetReqFriendByUid(const std::string& friend_uid);
  void RemoveReqFriendByUid(const std::string& friend_uid);
  void RemoveReqFriendList();

  uint_32 GetHelperListCount();
  data::FriendInfo* GetHelperByIndex(int_32 index);
  data::FriendInfo* GetHelperByUid(const std::string& helper_uid);
  data::FriendInfo* GetHelperByLeaderSeqid(uint_32 seq_id);
  void RemoveHelperByUid(const std::string& helper_uid);
  void RemoveHelperList();

  void SetBattleHelperInfo(const std::string& helper_uid,const std::string& helper_nick, bool isFriend);
  void SetBattleHelperCardInfo(const int card_sid,const int card_id,const int card_level,const int break_time);
  void SetBattleHelperAttrInfo(const int hp,const int attack,const int pdef,const int mdef,const int fdam,const int fundam,const int mag_attack);

  typedef net::NetSession<net::get_friend_req_list_in::Get_friend_req_list_in, net::get_friend_req_list_out::Get_friend_req_list_out> FriendGetRequestListSession;
  void FriendGetRequestListComplete(int error_code, boost::shared_ptr<FriendGetRequestListSession> friend_get_request_list_session);
  bool battleHelpIsFriend();
 private:
typedef net::NetSession<net::search_friend_by_userid_in::Search_friend_by_userid_in, net::search_friend_by_userid_out::Search_friend_by_userid_out> FriendSearchSession;
  typedef net::NetSession<net::search_friend_by_nick_in::Search_friend_by_nick_in, net::search_friend_by_nick_out::Search_friend_by_nick_out> FriendSearchByNickSession;
  typedef net::NetSession<net::send_add_friend_in::Send_add_friend_in,void> FriendRequestSession;  
  typedef net::NetSession<net::get_friend_list_in::Get_friend_list_in, net::get_friend_list_out::Get_friend_list_out> FriendGetListSession;
  typedef net::NetSession<net::resp_friend_req_in::Resp_friend_req_in,void> FriendRespRequestSession;
  typedef net::NetSession<net::delete_friend_in::Delete_friend_in,void> FriendDelRequestSession;
  typedef net::NetSession<net::get_helper_list_in::Get_helper_list_in, net::get_helper_list_out::Get_helper_list_out> FriendGetHelperSession;
  typedef net::NetSession<net::send_set_assist_card_in::Send_set_assist_card_in, void> SetAssistCardSession;
  typedef net::NetSession<net::get_strange_list_in::Get_strange_list_in, net::get_strange_list_out::Get_strange_list_out> GetStrangeListSession;
  typedef net::NetSession<net::del_stranger_helper_in::Del_stranger_helper_in, void> DelStrangerHelperSession;

  void init();
  void prepareComplete();

  void sendGetRequestListRequestIntelnal(boost::shared_ptr<FriendGetRequestListSession> friend_get_request_list_session);

  void friendSearchByUserUIDNameRequestComplete(int error_code, boost::shared_ptr<FriendSearchByNickSession> friend_search_session); 
  void friendAddRequestComplete(int error_code, boost::shared_ptr<FriendRequestSession> friend_request_session);
  
  void friendRespRequestComplete(int error_code, boost::shared_ptr<FriendRespRequestSession> friend_resp_request_session);
  void friendDelRequestComplete(int error_code, boost::shared_ptr<FriendDelRequestSession> friend_del_request_session);
  void friendGetListComplete( int error_code, boost::shared_ptr<FriendGetListSession> friend_get_list_session );
  void friendGetHelperComplete( int error_code, boost::shared_ptr<FriendGetHelperSession> friend_get_helper_session );
  void friendSendSetAssistCardComplete(int error_code, boost::shared_ptr<SetAssistCardSession> friend_set_assist_card_session);
  
  void friendSendGetStrangeListComplete(int error_code, boost::shared_ptr<GetStrangeListSession> friend_get_strange_list_session);  
  void friendDelStrangeHelperComplete(int error_code, boost::shared_ptr<DelStrangerHelperSession> session);
 private:

  std::map<net::BaseSession*,
      boost::signal<void (boost::shared_ptr<IHandleDelegate>)> > request_complete_signal_;

  std::list<data::FriendInfo*> request_list_;
  data::FriendInfo*   search_friend_info_;
  std::list<data::FriendInfo*> helper_list_;
  std::list<data::FriendInfo*> mStrangeAssistList;

  // when server request list is change
  bool is_need_update_req_list;

  uint_32  last_update_time_;
  int       mAssendCardSID;
  int       mNextAssistCardSID;
  bool  helpIsFriend;
};
} // namespace taomee
#endif //FRIEND_CONTROLLER_H