#include "friend_controller.h"

#include "CCLuaEngine.h"

#include "game/account/account_manager.h"
#include "game/touch_helper/touch_helper.h"
#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"
#include "game/user_data/friend_info.h"
#include "game/user_interface/template_scene.h"

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/load_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/game_time.h"

#include "game/major_city/city_view/city_controller.h"

#include "network/net_manager.h"
#include "network/session/net_session.hpp"
#include "network/proto/search_friend_by_nick_in.h"
#include "network/proto/search_friend_by_nick_out.h"
#include "network/proto/search_friend_by_userid_in.h"
#include "network/proto/search_friend_by_userid_out.h"
#include "network/proto/get_friend_list_in.h"
#include "network/proto/get_friend_list_out.h"
#include "network/proto/send_add_friend_in.h"
#include "network/proto/get_friend_list_in.h"
#include "network/proto/get_friend_list_out.h"
#include "network/proto/resp_friend_req_in.h"
#include "network/proto/delete_friend_in.h"
#include "network/proto/get_friend_req_list_in.h"
#include "network/proto/get_friend_req_list_out.h"
#include "network/proto/get_helper_list_in.h"
#include "network/proto/get_helper_list_out.h"
#include "network/proto/send_set_assist_card_in.h"
#include "network/proto/get_strange_list_in.h"
#include "network/proto/get_strange_list_out.h"
#include "network/proto/del_stranger_helper_in.h"
#include "game/game_manager/game_manager.h"
#include <iostream>

using namespace  cocos2d;
namespace taomee
{

namespace
{
typedef net::NetSession<net::get_friend_req_list_in::Get_friend_req_list_in, net::get_friend_req_list_out::Get_friend_req_list_out> FriendGetRequestListSession;
boost::shared_ptr<FriendGetRequestListSession> CreateGetRequestListRequestSession()
{
  boost::shared_ptr<FriendGetRequestListSession> friend_get_req_list_session = boost::make_shared<FriendGetRequestListSession>();
  net::get_friend_req_list_in::Get_friend_req_list_in friend_get_req_list_in_msg;
  friend_get_req_list_in_msg.set_cmd(GetHttpActionIDByName("friend_getFriendReqList"));
  friend_get_req_list_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_get_req_list_in_msg.set_userid(os.str());

  friend_get_req_list_session->set_message_in(friend_get_req_list_in_msg);
  friend_get_req_list_session->SubscribeReciveBodyComplete(&FriendController::GetInstance(), &FriendController::FriendGetRequestListComplete);
  return friend_get_req_list_session;
}

} // namespace an

FriendController::FriendController()
  :search_friend_info_(NULL)
  ,is_need_update_req_list(false)
  ,last_update_time_(0)
  ,helpIsFriend(false)
{
  mAssendCardSID = -1;
  mNextAssistCardSID = -1;
}

FriendController::~FriendController()
{
  SAFE_DEL(search_friend_info_);
}

void FriendController::Prepare(LoadHelper* load_helper)
{
  
}

void FriendController::Start()
{
  init();
}

void FriendController::End()
{
  SAFE_DEL(search_friend_info_);
}

void FriendController::init()
{
}

void FriendController::prepareComplete()
{

}

void FriendController::CheckAssistCardValid()
{
  if (mAssendCardSID < 0)
  {
     mAssendCardSID = DataManager::GetInstance().user_info()->GetCharacterCardWithRole()->getSID();
  }
}

void FriendController::SendGetStrangeListRequest()
{
  boost::shared_ptr<GetStrangeListSession> friend_get_req_list_session = boost::make_shared<GetStrangeListSession>();
  net::get_strange_list_in::Get_strange_list_in friend_get_req_list_in_msg;
  friend_get_req_list_in_msg.set_cmd(GetHttpActionIDByName("friend_getFriendStrangeList"));
  friend_get_req_list_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_get_req_list_in_msg.set_userid(os.str());

  friend_get_req_list_session->set_message_in(friend_get_req_list_in_msg);
  friend_get_req_list_session->SubscribeReciveBodyComplete(&FriendController::GetInstance(), &FriendController::friendSendGetStrangeListComplete);
  net::NetManager::GetInstance().SendSession(friend_get_req_list_session);
}

void FriendController::friendSendGetStrangeListComplete(int error_code, boost::shared_ptr<GetStrangeListSession> friend_get_strange_list_session)
{
  if ( error_code != 0 )
  {
    return;
  }

  RemoveStrangeList();
  // set team info
  const std::vector<net::get_strange_list_out::Strangers> helper_list = friend_get_strange_list_session->get_message_out().get_strangers();
  for (std::vector<net::get_strange_list_out::Strangers>::const_iterator it = helper_list.begin();
    it != helper_list.end(); ++it)
  {
    data::FriendInfo* friend_unit = new data::FriendInfo();

    friend_unit->set_user_id_friend(it->get_userid().c_str());
    friend_unit->set_rank_friend(it->get_level());
    friend_unit->set_login_timestamp_friend(it->get_login_time_delta());
    friend_unit->set_nick_name_friend(it->get_nick());
    if ( it->get_is_friend() == false )
    {
      friend_unit->set_is_helper(true);
    }
    // set card basic info
    data::CharacterInfo* leader = new data::CharacterInfo(it->get_leader().get_id(),
      it->get_leader().get_cardid(),
      it->get_leader().get_level(),
      it->get_leader().get_xp(),                                                          
      it->get_leader().get_breaks());
    friend_unit->set_lead_character_friend(leader);
    SAFE_DEL(leader);

    mStrangeAssistList.push_back(friend_unit);
  }

  LuaTinkerManager::GetInstance()\
    .CallLuaFunc<bool>("script/framework/CPlusToLuaInterface.lua", "RequestStrangeListResult", error_code);
}  

void FriendController::SendDelStrangeHelperReq(const std::string& friend_uid)
{
  boost::shared_ptr<DelStrangerHelperSession> session = boost::make_shared<DelStrangerHelperSession>();
  net::del_stranger_helper_in::Del_stranger_helper_in msg;
  msg.set_cmd(GetHttpActionIDByName("friend_delStrangeHelper"));
  msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  msg.set_userid(os.str());

  msg.set_helper_uid(friend_uid);
  session->set_message_in(msg);
  session->SubscribeReciveBodyComplete(this, &FriendController::friendDelStrangeHelperComplete);
  net::NetManager::GetInstance().SendSession(session);
}

void FriendController::friendDelStrangeHelperComplete(int error_code, boost::shared_ptr<DelStrangerHelperSession> session)
{
  if (error_code == 0)
  {
    RemoveStrangeByUid(session->get_message_in().get_helper_uid());
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "OnDelStrangeHelperResult", error_code);
  }
}

void FriendController::SendSetAssendCardRequest(int card_sid)
{
  boost::shared_ptr<SetAssistCardSession> set_assist_card_session = boost::make_shared<SetAssistCardSession>();
  net::send_set_assist_card_in::Send_set_assist_card_in msg;
  msg.set_cmd(GetHttpActionIDByName("friend_setAssistCard"));
  msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  msg.set_userid(os.str());

  std::ostringstream os2;
  os2 << card_sid;  
  msg.set_assit_card_id(os2.str());
  set_assist_card_session->set_message_in(msg);
  set_assist_card_session->SubscribeReciveBodyComplete(this, &FriendController::friendSendSetAssistCardComplete);
  net::NetManager::GetInstance().SendSession(set_assist_card_session);
  mNextAssistCardSID = card_sid;
}

void FriendController::friendSendSetAssistCardComplete(int error_code, boost::shared_ptr<SetAssistCardSession> friend_set_assist_card_session)
{
  if (error_code == 0)
  {
    mAssendCardSID = mNextAssistCardSID;
    LuaTinkerManager::GetInstance()\
      .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "SetAssistCardResult", error_code);
  }
}

void FriendController::SendSearchFriendRequest( const char* friend_name )
{
  boost::shared_ptr<FriendSearchByNickSession> friend_search_session = boost::make_shared<FriendSearchByNickSession>();
  net::search_friend_by_nick_in::Search_friend_by_nick_in friend_search_in_msg;
  friend_search_in_msg.set_cmd(GetHttpActionIDByName("friend_searchByNick"));
  friend_search_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_search_in_msg.set_userid(os.str());

  //friend_search_in_msg.set_search_uid(friend_id);
  friend_search_in_msg.set_search_nick(friend_name);
  friend_search_session->set_message_in(friend_search_in_msg);
  friend_search_session->SubscribeReciveBodyComplete(this, &FriendController::friendSearchByUserUIDNameRequestComplete);
  net::NetManager::GetInstance().SendSession(friend_search_session);
}

void FriendController::friendSearchByUserUIDNameRequestComplete( int error_code, boost::shared_ptr<FriendSearchByNickSession> friend_search_session )
{
  if (error_code != 0)
  {
    LuaTinkerManager::GetInstance()\
      .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "SearchFriendResult", false);
 	  return;
  }

  if (search_friend_info_ != NULL) 
  {
    SAFE_DEL(search_friend_info_);
  }
  search_friend_info_ = new data::FriendInfo();

  const net::search_friend_by_nick_out::Search_friend_by_nick_out & friendInfo = friend_search_session->get_message_out();    
  search_friend_info_->set_user_id_friend(friendInfo.get_userid().c_str());
  search_friend_info_->set_rank_friend(friendInfo.get_level());
  search_friend_info_->set_login_timestamp_friend(friendInfo.get_login_time_delta());
  search_friend_info_->set_nick_name_friend(friendInfo.get_nick());

  // set card basic info
  data::CharacterInfo* leader = new data::CharacterInfo(friendInfo.get_leader().get_id(),
                                                        friendInfo.get_leader().get_cardid(),
                                                        friendInfo.get_leader().get_level(),
                                                        friendInfo.get_leader().get_xp(),
                                                        friendInfo.get_leader().get_breaks());
  search_friend_info_->set_lead_character_friend(leader); 
  SAFE_DEL(leader);

  LuaTinkerManager::GetInstance()\
    .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "SearchFriendResult", true);
}

data::FriendInfo* FriendController::GetSearchFriendInfo()
{
  return search_friend_info_;
}

void FriendController::SendRequestFriendRequest(const std::string& friend_name)
{
  boost::shared_ptr<FriendRequestSession> friend_request_session = boost::make_shared<FriendRequestSession>();
  net::send_add_friend_in::Send_add_friend_in friend_request_in_msg;
  friend_request_in_msg.set_cmd(GetHttpActionIDByName("friend_sendFriendReq"));
  friend_request_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_request_in_msg.set_userid(os.str());

  friend_request_in_msg.set_other_uid(friend_name);
  friend_request_session->set_message_in(friend_request_in_msg);
  friend_request_session->SubscribeReciveBodyComplete(this, &FriendController::friendAddRequestComplete);
  net::NetManager::GetInstance().SendSession(friend_request_session);
}

void FriendController::friendAddRequestComplete(int error_code, boost::shared_ptr<FriendRequestSession> friend_request_session)
{  
  if (error_code == 0)
  {
    RemoveStrangeByUid(friend_request_session->get_message_in().get_other_uid());
  }
  LuaTinkerManager::GetInstance()\
		.CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "RequestAddResult", error_code);
}

void FriendController::SendGetRequestListRequest()
{ 
  net::NetManager::GetInstance().SendSession(CreateGetRequestListRequestSession());
}

void FriendController::sendGetRequestListRequestIntelnal(boost::shared_ptr<FriendGetRequestListSession> friend_get_request_list_session)
{
  net::NetManager::GetInstance().SendSession(friend_get_request_list_session);
}

void FriendController::FriendGetRequestListComplete( int error_code, boost::shared_ptr<FriendGetRequestListSession> friend_get_request_list_session )
{
  for (std::list<data::FriendInfo*>::iterator it = request_list_.begin();
    it != request_list_.end(); ++it)
  {
    delete (*it);
  }
  request_list_.clear();
  // set team info
  const std::vector<net::get_friend_req_list_out::Req> req_list = friend_get_request_list_session->get_message_out().get_req(); 
  for (std::vector<net::get_friend_req_list_out::Req>::const_iterator it = req_list.begin();
    it != req_list.end(); ++it)
  {
    data::FriendInfo* friend_unit = new data::FriendInfo();
     
    friend_unit->set_user_id_friend(it->get_userid().c_str());
    friend_unit->set_rank_friend(it->get_level());
    friend_unit->set_login_timestamp_friend(it->get_login_time_delta());
    friend_unit->set_nick_name_friend(it->get_nick());

    // set card basic info
    data::CharacterInfo* leader = new data::CharacterInfo(it->get_leader().get_id(),
                                                          it->get_leader().get_cardid(),
                                                          it->get_leader().get_level(),
                                                          it->get_leader().get_xp(),
                                                          it->get_leader().get_breaks());
    friend_unit->set_lead_character_friend(leader);
    SAFE_DEL(leader);

    request_list_.push_back(friend_unit);
  }

  LuaTinkerManager::GetInstance()\
    .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "GetReqListResult", error_code);
}

void FriendController::SendGetFriendListRequest()
{
  boost::shared_ptr<FriendGetListSession> friend_get_list_session = boost::make_shared<FriendGetListSession>();
  net::get_friend_list_in::Get_friend_list_in friend_get_list_in_msg;
  friend_get_list_in_msg.set_cmd(GetHttpActionIDByName("friend_getFriendList"));
  friend_get_list_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_get_list_in_msg.set_userid(os.str());

  friend_get_list_session->set_message_in(friend_get_list_in_msg);
  friend_get_list_session->SubscribeReciveBodyComplete(this, &FriendController::friendGetListComplete);
  net::NetManager::GetInstance().SendSession(friend_get_list_session);
}

void FriendController::friendGetListComplete( int error_code, boost::shared_ptr<FriendGetListSession> friend_get_list_session )
{
  DataManager::GetInstance().user_info()->RemoveAllFriend();
  // set team info
  const std::vector<net::get_friend_list_out::Friends> fiends_list = friend_get_list_session->get_message_out().get_friends(); 
  for (std::vector<net::get_friend_list_out::Friends>::const_iterator it = fiends_list.begin();
    it != fiends_list.end(); ++it)
  {
    data::FriendInfo* friend_unit = new data::FriendInfo();

    friend_unit->set_user_id_friend(it->get_userid().c_str());
    friend_unit->set_rank_friend(it->get_level());
    friend_unit->set_login_timestamp_friend(it->get_login_time_delta());
    friend_unit->set_nick_name_friend(it->get_nick());

    // set card basic info
    data::CharacterInfo* leader = new data::CharacterInfo(it->get_leader().get_id(),
                                                          it->get_leader().get_cardid(),
                                                          it->get_leader().get_level(),
                                                          it->get_leader().get_xp(),
                                                          it->get_leader().get_breaks());
    friend_unit->set_lead_character_friend(leader);
    SAFE_DEL(leader);

    DataManager::GetInstance().user_info()->UpdateOneFriendInfo(friend_unit);
    SAFE_DEL(friend_unit);
  }

  LuaTinkerManager::GetInstance()\
    .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "GetFriendListResult", error_code);  
}
void FriendController::SendRespFriendReq(const std::string& friend_uid, bool result )
{
  boost::shared_ptr<FriendRespRequestSession> friend_resp_request_session = boost::make_shared<FriendRespRequestSession>();
  net::resp_friend_req_in::Resp_friend_req_in friend_resp_request_in_msg;
  friend_resp_request_in_msg.set_cmd(GetHttpActionIDByName("friend_respFriendReq"));
  friend_resp_request_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_resp_request_in_msg.set_userid(os.str());

  friend_resp_request_in_msg.set_other_uid(friend_uid);
  friend_resp_request_in_msg.set_is_accept(result);
  friend_resp_request_session->set_message_in(friend_resp_request_in_msg);
  friend_resp_request_session->SubscribeReciveBodyComplete(this, &FriendController::friendRespRequestComplete);
  net::NetManager::GetInstance().SendSession(friend_resp_request_session);
}

void FriendController::SendDelFriendReq(const std::string& friend_uid)
{
  boost::shared_ptr<FriendDelRequestSession> friend_del_request_session = boost::make_shared<FriendDelRequestSession>();
  net::delete_friend_in::Delete_friend_in friend_del_request_in_msg;
  friend_del_request_in_msg.set_cmd(GetHttpActionIDByName("friend_delFriend"));
  friend_del_request_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_del_request_in_msg.set_userid(os.str());

  friend_del_request_in_msg.set_other_uid(friend_uid);
  friend_del_request_session->set_message_in(friend_del_request_in_msg);
  friend_del_request_session->SubscribeReciveBodyComplete(this, &FriendController::friendDelRequestComplete);
  net::NetManager::GetInstance().SendSession(friend_del_request_session);
}

void FriendController::friendRespRequestComplete( int error_code, boost::shared_ptr<FriendRespRequestSession> friend_resp_request_session )
{
  bool is_accept = friend_resp_request_session->get_message_in().get_is_accept()?true:false;
  if (error_code == 0)
  {
    if (is_accept)
    {
      data::FriendInfo* data = GetReqFriendByUid(friend_resp_request_session->get_message_in().get_other_uid());
      if (data)
      {
        DataManager::GetInstance().user_info()->UpdateOneFriendInfo(data);
      }
    }
    RemoveReqFriendByUid(friend_resp_request_session->get_message_in().get_other_uid());
  }
  LuaTinkerManager::GetInstance()\
    .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "RespRequestResult", error_code, is_accept);
}

void FriendController::friendDelRequestComplete( int error_code, boost::shared_ptr<FriendDelRequestSession> friend_del_request_session )
{
   if (error_code == 0)
   {
      DataManager::GetInstance().user_info()->RemoveOneFriendById(friend_del_request_session->get_message_in().get_other_uid());
   }
   LuaTinkerManager::GetInstance()\
     .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "DelFriendResult", error_code);
}

uint_32 FriendController::GetReqListCount()
{
  return request_list_.size();
}

uint_32 FriendController::GetStrangeListCount()
{
  return mStrangeAssistList.size();
}

data::FriendInfo* FriendController::GetStrangeByIndex(int_32 index)
{
  if (index >= mStrangeAssistList.size())
  {
    return NULL;
  }

  int_32 idx = 0;
  for (std::list<data::FriendInfo*>::iterator it = mStrangeAssistList.begin();
    it != mStrangeAssistList.end(); ++it)
  {
    if (idx == index) 
    {
      return *it;
    }    
    idx++;
  }
  return NULL;
}

data::FriendInfo* FriendController::GetReqFriendByIndex( int_32 index )
{
  if (index >= request_list_.size()) 
  {
    return NULL;
  }
  int_32 idx = 0;
  for (std::list<data::FriendInfo*>::iterator it = request_list_.begin();
    it != request_list_.end(); ++it)
  {
    if (idx == index) 
    {
      return *it;
    }    
    idx++;
  }
  return NULL;
}

void FriendController::RemoveReqFriendByUid( const std::string& friend_uid )
{
  for (std::list<data::FriendInfo*>::iterator it = request_list_.begin();
    it != request_list_.end(); ++it)
  {
    if ((*it)->user_id_friend().compare(friend_uid.c_str()) == 0)
    {
      delete (*it);
      request_list_.erase(it);
      return;
    }
  }
}

void FriendController::RemoveStrangeByUid(const std::string& friend_uid)
{
  for (std::list<data::FriendInfo*>::iterator it = mStrangeAssistList.begin();
    it != mStrangeAssistList.end(); ++it)
  {
    if ((*it)->user_id_friend().compare(friend_uid.c_str()) == 0)
    {
      delete (*it);
      mStrangeAssistList.erase(it);
      return;
    }
  }
}

void FriendController::RemoveReqFriendList()
{

}

data::FriendInfo* FriendController::GetReqFriendByUid( const std::string& friend_uid )
{
  for (std::list<data::FriendInfo*>::iterator it = request_list_.begin();
    it != request_list_.end(); ++it)
  {
    if ((*it)->user_id_friend().compare(friend_uid.c_str()) == 0)
    {
      return (*it);
    }
  }
  return NULL;
}

void FriendController::SendGetHelperReq()
{
  boost::shared_ptr<FriendGetHelperSession> friend_get_helper_session = boost::make_shared<FriendGetHelperSession>();
  net::get_helper_list_in::Get_helper_list_in friend_get_helper_in_msg;
  friend_get_helper_in_msg.set_cmd(GetHttpActionIDByName("friend_getTeammateList"));
  friend_get_helper_in_msg.set_session(account::AccountManager::GetInstance().session());
  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();  
  friend_get_helper_in_msg.set_userid(os.str());
  
  friend_get_helper_session->set_message_in(friend_get_helper_in_msg);
  friend_get_helper_session->SubscribeReciveBodyComplete(this, &FriendController::friendGetHelperComplete);
  net::NetManager::GetInstance().SendSession(friend_get_helper_session);
}

void FriendController::friendGetHelperComplete( int error_code, boost::shared_ptr<FriendGetHelperSession> friend_get_helper_session )
{
  if ( error_code != 0 )
  {
    return;
  }

  RemoveHelperList();
  // set team info
  const std::vector<net::get_helper_list_out::Teammates> helper_list = friend_get_helper_session->get_message_out().get_teammates();
  for (std::vector<net::get_helper_list_out::Teammates>::const_iterator it = helper_list.begin();
    it != helper_list.end(); ++it)
  {
    data::FriendInfo* friend_unit = new data::FriendInfo();

    friend_unit->set_user_id_friend(it->get_userid().c_str());
    friend_unit->set_rank_friend(it->get_level());
    friend_unit->set_login_timestamp_friend(it->get_login_time_delta());
    friend_unit->set_nick_name_friend(it->get_nick());
    if ( it->get_is_friend() == false )
    {
      friend_unit->set_is_helper(true);
    }
    // set card basic info
    data::CharacterInfo* leader = new data::CharacterInfo(it->get_leader().get_id(),
                                                          it->get_leader().get_cardid(),
                                                          it->get_leader().get_level(),
                                                          it->get_leader().get_xp(),                                                          
                                                          it->get_leader().get_breaks());
    friend_unit->set_lead_character_friend(leader);
    SAFE_DEL(leader);

    helper_list_.push_back(friend_unit);
  }

  LuaTinkerManager::GetInstance()\
	  .CallLuaFunc<bool>("script/framework/CPlusToLuaInterface.lua", "RequestAssentFriendListResult", error_code);
}

uint_32 FriendController::GetHelperListCount()
{
  return helper_list_.size();
}

data::FriendInfo* FriendController::GetHelperByIndex( int_32 index )
{
  if (index >= helper_list_.size()) 
  {
    return NULL;
  }
  int_32 idx = 0;
  for (std::list<data::FriendInfo*>::iterator it = helper_list_.begin();
    it != helper_list_.end(); ++it)
  {
    if (idx == index) 
    {
      return *it;
    }    
    idx++;
  }
  return NULL;
}

data::FriendInfo* FriendController::GetHelperByUid( const std::string& helper_uid )
{
  for (std::list<data::FriendInfo*>::iterator it = helper_list_.begin();
    it != helper_list_.end(); ++it)
  {
    if ((*it)->user_id_friend().compare(helper_uid.c_str()) == 0)
    {
      return (*it);
    }
  }
  return NULL;
}

data::FriendInfo* FriendController::GetHelperByLeaderSeqid(uint_32 seq_id)
{
  for (std::list<data::FriendInfo*>::iterator it = helper_list_.begin();
    it != helper_list_.end(); ++it)
  {
    if ((*it)->lead_character_friend()->sequence_id() == seq_id)
    {
      return (*it);
    }
  }
  return NULL;
}

void FriendController::RemoveHelperByUid( const std::string& helper_uid )
{
  for (std::list<data::FriendInfo*>::iterator it = helper_list_.begin();
    it != helper_list_.end(); ++it)
  {
    if ((*it)->user_id_friend().compare(helper_uid.c_str()) == 0)
    {
      delete (*it);
      helper_list_.erase(it);
      return;
    }
  }
}

void FriendController::OpenFriendHelperUI()
{
/*
  if (GetHelperListCount() == 0 ) 
  {
    SendGetHelperReq();
	return;
  }
      LuaTinkerManager::GetInstance()\
     .CallLuaFunc<bool>("script/framework/CPlusToLuaInterface.lua", "openFriendHelpUI");
*/
}

void FriendController::RemoveStrangeList()
{
  for (std::list<data::FriendInfo*>::iterator it = mStrangeAssistList.begin();
    it != mStrangeAssistList.end(); ++it)
  {
    delete (*it);
  }
  mStrangeAssistList.clear();
}

void FriendController::RemoveHelperList()
{
  for (std::list<data::FriendInfo*>::iterator it = helper_list_.begin();
    it != helper_list_.end(); ++it)
  {
     delete (*it);
  }
  helper_list_.clear();
}

void FriendController::UpdateFriendData()
{
  //��ʱ�����ź���
  //if ( getServerTime() - last_update_time_ > 30 ) 
  //{
  //  SendGetRequestListRequest();
  //  SendGetFriendListRequest();
  //  last_update_time_ = getServerTime();
  //}
}

uint_32 FriendController::GetUpdateInterval()
{
  return getServerTime() - last_update_time_;
}

bool FriendController::battleHelpIsFriend()
{
  return helpIsFriend;
}

void FriendController::SetBattleHelperInfo( const std::string& helper_uid,const std::string& helper_nick, bool isFriend )
{
  RemoveHelperList();

  data::FriendInfo* friend_unit = new data::FriendInfo();

  friend_unit->set_user_id_friend(helper_uid);
  friend_unit->set_rank_friend(0);
  friend_unit->set_login_timestamp_friend(0);
  friend_unit->set_nick_name_friend(helper_nick);
  friend_unit->set_is_helper(true);

  helper_list_.push_back(friend_unit);

  helpIsFriend = isFriend;
}

void FriendController::SetBattleHelperCardInfo( const int card_sid,const int card_id,const int card_level,const int break_time )
{
  if (helper_list_.size() == 0)
    return;
  
  data::CharacterInfo* leader = new data::CharacterInfo(card_sid,card_id,card_level,0,break_time);
  helper_list_.front()->set_lead_character_friend(leader);
  SAFE_DEL(leader);
}

void FriendController::SetBattleHelperAttrInfo( const int hp,const int phy_attack,const int pdef,const int mdef,const int fdam,const int fundam,const int mag_attack)
{
  helper_list_.front()->set_leader_attr_info(hp,phy_attack,pdef,mdef,fdam,fundam, mag_attack);
}


} // namespace taomee
