//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: arena_controller.h
//        Author: Dylan.gu
//          Date: 2014/8/28 16:53
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/8/28      add
//////////////////////////////////////////////////////////////

#ifndef ARENA_CONTROLLER_H
#define ARENA_CONTROLLER_H


#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"

#include "engine/platform/SingleInstance.h"

using namespace cocos2d;
using namespace cocos2d::extension;
namespace taomee
{

class LoadHelper;

namespace ui
{
  class TemplateScene;
}


class ArenaController  : public SingleInstanceObj
{
public:
  ArenaController();
  ~ArenaController();

  static ArenaController& GetInstance()
  {
    static ArenaController* X = NULL;
    if (!X)
    {
      X = new ArenaController();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }

  void Prepare(LoadHelper* load_helper);

  void Start();
  void UpdateEachFrame(float delta);  
  void End();

  ui::TemplateScene* get_templeate_scene() {return root_scene_;}

private:
  void createScene();

private:
  ui::TemplateScene*   root_scene_;
};
} // namespace taomee

#endif