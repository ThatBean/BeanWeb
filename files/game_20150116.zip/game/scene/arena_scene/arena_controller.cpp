#include "arena_controller.h"
#include "engine/base/load_helper.h"
#include "engine/base/handle_delegate.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/user_interface/template_scene.h"

namespace taomee
{
ArenaController::ArenaController()
:root_scene_(NULL)
{

}

ArenaController::~ArenaController()
{
  CC_SAFE_RELEASE_NULL(root_scene_);
}

void ArenaController::Prepare(LoadHelper* load_helper)
{
  typedef HandleDelegate0<ArenaController*> DelegateType;
  boost::shared_ptr<DelegateType> create_scene_delegate = boost::make_shared<DelegateType>(
        this, &ArenaController::createScene);
  load_helper->RegisterLoadFunctionHandle(create_scene_delegate,1.0);
 
}

void ArenaController::Start()
{
  root_scene_->SwitchToThisScene();
}

void ArenaController::End()
{
  CC_SAFE_RELEASE_NULL(root_scene_);
}

void ArenaController::UpdateEachFrame(float delta)
{

}

void ArenaController::createScene()
{
  assert(root_scene_ == NULL);
  root_scene_ = ui::TemplateScene::Create();
  root_scene_->retain(); 
  UILayer* arena_layer = LuaTinkerManager::GetInstance().CallLuaFunc<UILayer*>(
      "script/ui/ui_arena.lua","OpenArenaUI"); 
  root_scene_->AddLayerOnUILayer(arena_layer, arena_layer->getTag());
}
} // namespace taomee