//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: update_controller.h
//        Author: peteryu
//          Date: 2014/1/15 18:22
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/1/15      add
//////////////////////////////////////////////////////////////

#ifndef UPDATE_CONTROLLER_H
#define UPDATE_CONTROLLER_H

#include "engine/base/basictypes.h"
#include "engine/base/handle_delegate.h"
#include <boost/shared_ptr.hpp>

#include "engine/platform/SingleInstance.h"

namespace cocos2d
{
class CCScene;
class CCArray;
class CCNode;
}
using namespace cocos2d;

namespace taomee
{

namespace ui
{
class TemplateScene;
}

enum eUpdateState
{
  kUpdateStateLoadPre,
  kUpdateStateLoadDownloadRes,
  kUpdateStateLoadUIJson,
  kUpdateStateLoadCSV,
  kUpdateStateLoadEnd
};

class UpdateController  : public SingleInstanceObj
{
public:
  UpdateController();
  ~UpdateController();
  
  static UpdateController& GetInstance()
  {
    static UpdateController* X = NULL;
    if (!X)
    {
      X = new UpdateController();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }

  void Start();
  void End();
  void UpdateEachFrame(float delta);

  void ReUpdate();

  void RegisterLoadFunctionHandle(boost::shared_ptr<IHandleDelegate> handle_delegate);

protected:
  void LoadUpdateLayer();

private:
  cocos2d::CCNode*     current_layer_;
  eUpdateState         update_state_;
  int                  load_fun_count_;
  int                  pre_load_ui_count_;
  int                  total_down_load_count_;
  
  float               calculateLoadingBarValue(float base_value);

  std::queue<boost::shared_ptr<IHandleDelegate> > load_fun_handle_queue_;
};
} // namespace taomee

#endif //LOADING_CONTROLLER_H