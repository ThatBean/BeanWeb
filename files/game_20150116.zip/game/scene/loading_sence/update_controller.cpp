//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: update_controller.cpp
//        Author: peteryu
//          Date: 2014/1/15 18:24
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/1/15      add
//////////////////////////////////////////////////////////////

#include "update_controller.h"

#include "engine/base/cocos2d_wrapper.h"
#include "engine/particle/particle_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/sound/sound_manager.h"
#include "game/update/update_manager.h"

#include "game/account/account_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/game_manager.h"
#include "game/user_interface/template_scene.h"

#include "network/proto/notify_login_prize.h"
#include "network/notifications/notify_manager.h"
#include "network/notifications/notify_contants.h"
#include "network/notifications/notify_session.h"
#include "game/scene/loading_sence/login_controller.h"
#if CC_TARGET_PLATFORM == CC_PLATFORM_IOS
#import "game/platform/SDKManager.h"
#endif
namespace taomee
{

UpdateController::UpdateController()
  : current_layer_(NULL),
    update_state_(kUpdateStateLoadPre),
    load_fun_count_(0),
    pre_load_ui_count_(0),
    total_down_load_count_(0)
{
}

UpdateController::~UpdateController()
{
}

void UpdateController::Start()
{
  DataManager::GetInstance().Init();
  ParticleManager::GetInstance().LoadAll();

  load_fun_count_ = load_fun_handle_queue_.size();
  pre_load_ui_count_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/preload_ui_config.lua", "GetPreLoadUICount");
	
  if(LuaTinkerManager::GetInstance()\
    .CallLuaFunc<bool>("script/config/debug_config.lua", "IsOpenUpdate"))
  {
    update_state_ = kUpdateStateLoadDownloadRes;
    UpdateManager::GetInstance().StartUpdate();

	LuaTinkerManager::GetInstance()\
		.CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua","beginUpdateVersion");//interface to lua.it will effect when the C++ is update error
  }
  else
  {
    update_state_ = kUpdateStateLoadUIJson;
    //End();
  }
}

    void UpdateController::End()
    {
        if(current_layer_)
        {
            current_layer_->removeAllChildrenWithCleanup(true);
            //CC_SAFE_RELEASE_NULL(current_layer_);
        }
        LoginController::GetInstance().OnUpdateEnd();
        
//        #ifdef PLATFORM_3RD
//        SDKManager::doLastUserLogin();
//        #endif
    }

float UpdateController::calculateLoadingBarValue(float base_value)
{
  float scale = base_value / (load_fun_count_ + pre_load_ui_count_);
  return  scale;
}

void UpdateController::UpdateEachFrame(float delta)
{
  //fix bug, cannot get running scene in the same frame when we first set scene
  if(!current_layer_)
  {
    LoadUpdateLayer();
  }

  if(update_state_ == kUpdateStateLoadDownloadRes)
  {
    //TODO peteryu, Add re-download tips, start download again
    if(UpdateManager::GetInstance().IsDownloadError())
    {
      CCLog("Download Failed!");
    }
    else
    {
      bool is_downloading = UpdateManager::GetInstance().IsDownloading();
      int total_count     = UpdateManager::GetInstance().GetTotalDownloadFile();
      int current_count   = UpdateManager::GetInstance().GetCurrentDownloadFile();
      total_down_load_count_ = total_count;
      if(is_downloading)
      {
        int percent = (float)current_count / total_count * 100;
		//string tempCurName = UpdateManager::GetInstance().getCurLoadFileName();
		//tempCurName = FileHelper::GetInstance().GetFileName(tempCurName);

		string loadShowStr = UpdateManager::GetInstance().getCurLoadShowStr();
		
		LuaTinkerManager::GetInstance()\
          .CallLuaFunc<int>("script/ui/ui_login_update.lua", "SetLoadingBarValue", percent, loadShowStr.c_str());
      }
      else
      {
        update_state_ = kUpdateStateLoadUIJson;
      }      
    }
  }

  if (update_state_ == kUpdateStateLoadUIJson)
  {
    int ui_percent = LuaTinkerManager::GetInstance()\
      .CallLuaFunc<int>("script/config/preload_ui_config.lua", "PreLoadNext");
    if (ui_percent < 0)
    {
      update_state_ = kUpdateStateLoadCSV;
    }
    else
    {
      int percent = (float)ui_percent / pre_load_ui_count_ * calculateLoadingBarValue(pre_load_ui_count_) * 100;
      percent += calculateLoadingBarValue(total_down_load_count_) * 100;
      LuaTinkerManager::GetInstance()\
        .CallLuaFunc<int>("script/ui/ui_login_update.lua", "SetLoadingBarValue", percent);
    }
  }

  if (update_state_ == kUpdateStateLoadCSV) 
  {
    if (!load_fun_handle_queue_.empty())
    {
      boost::shared_ptr<IHandleDelegate> handle_delegate = load_fun_handle_queue_.front();
      load_fun_handle_queue_.pop();
      handle_delegate->Invoke();
      int percent = (float)(load_fun_count_ - load_fun_handle_queue_.size()) / load_fun_count_ * calculateLoadingBarValue(load_fun_count_) * 100;
      percent += (calculateLoadingBarValue(pre_load_ui_count_) + calculateLoadingBarValue(total_down_load_count_)) * 100;
      LuaTinkerManager::GetInstance()\
        .CallLuaFunc<int>("script/ui/ui_login_update.lua", "SetLoadingBarValue", percent);
    } 
    else 
    {
      update_state_ = kUpdateStateLoadEnd;
      End();
    }
  }
}

void UpdateController::ReUpdate()
{
  UpdateManager::GetInstance().StartUpdate(true);
}

void UpdateController::RegisterLoadFunctionHandle(boost::shared_ptr<IHandleDelegate> handle_delegate)
{
  load_fun_handle_queue_.push(handle_delegate);
}

void UpdateController::LoadUpdateLayer()
{
  current_layer_ = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_update.lua", "CreateLoginUpdateLayer");
  cocos2d::CCScene* scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
  scene->getChildByTag(ui::kTemplateSceneUILayerTag)->addChild(current_layer_);
}

} // namespace taomee
