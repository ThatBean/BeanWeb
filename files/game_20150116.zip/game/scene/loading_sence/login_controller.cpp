//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: login_controller.cpp
//        Author: peteryu
//          Date: 2014/1/15 17:02
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/1/15      add
//////////////////////////////////////////////////////////////
#include "login_controller.h"

#include "CCLuaEngine.h"
#include "engine/base/utils_string.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/sound/sound_manager.h"
#include "network/net_constant.h"
#include "game/scene/loading_sence/update_controller.h"
#include "game/account/account_manager.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/data_sync_module.h"
#include "game/data_table/serverlist_data_table.h"
#include "game/user_interface/ui_first_show.h"
#include "game/user_interface/ui_constants.h"
#include "game/user_interface/template_scene.h"
#include "game/scene/loading_sence/login_server_sm.h"
#include "game/user_interface/ui_notification_node.h"
#if CC_TARGET_PLATFORM == CC_PLATFORM_IOS
#include "game/platform/SDKManager.h"
#endif
#include "game/update/update_manager.h"
namespace taomee
{
const std::string kDefaultLoginServerNameKey = "kDefaultLoginServerNameKey";
const std::string kDefaultLoginUserNameKey = "kDefaultLoginUserNameKey";
const std::string kLocalUserIdKey = "kLocalUserIdKey";
const std::string kLocalServerIdKey = "kLocalServerIdKey";
const std::string kLocalUserInfoCacheFirstShowKey = "is_first_show";
const std::string kLocalCoprightPageShowKey = "is_copright_show";

void CacheFirstShowDataToUserDefaultXml()
{
  cocos2d::CCUserDefault::sharedUserDefault()->setBoolForKey(kLocalUserInfoCacheFirstShowKey.c_str(), true); 
}

bool GetIsShowInCacheFirstShowData()
{
  return cocos2d::CCUserDefault::sharedUserDefault()->getBoolForKey(kLocalUserInfoCacheFirstShowKey.c_str());
  //return false;
}

void CacheCoprightShowDataToUserDefaultXml()
{
  cocos2d::CCUserDefault::sharedUserDefault()->setBoolForKey(kLocalCoprightPageShowKey.c_str(), true);
  cocos2d::CCUserDefault::sharedUserDefault()->flush();
}

bool GetIsCoprightPageHasShow()
{
  return cocos2d::CCUserDefault::sharedUserDefault()->getBoolForKey(kLocalCoprightPageShowKey.c_str(), false);
}

LoginController::LoginController()
  : root_scene_(NULL),
    login_state_(kLoginStateLoginPre),
		login_server_context_(new login_server_fsm::login_serverContext(*this)),
    is_new_player_(false),
    hasUpdate(false),
	hadShowLoginLayer(false)
{
    int id = cocos2d::CCUserDefault::sharedUserDefault()->getIntegerForKey(kLocalServerIdKey.c_str(), kServerIdDefault);
    net::constants::SetServerNetworkId(id);
}

LoginController::~LoginController()
{
  PurgeLoginController();
}

void LoginController::PurgeLoginController()
{
  CC_SAFE_RELEASE_NULL(root_scene_);
  login_state_ = kLoginStateLoginPre;
  login_layer_vector_.clear();
	CC_SAFE_DELETE(login_server_context_);
}

//���ȷ������
void LoginController::okClickBeginUpdate()
{
	UpdateManager::GetInstance().beginUpdateHdr();
}

//begin retry ckeckupdate..
void LoginController::reCheckUpdate()
{
  UpdateController::GetInstance().ReUpdate();
}

void LoginController::Start()
{
  hadShowLoginLayer = false;
  LoadLoginScene();
  login_state_ = kLoginStateLoginUpdate;
  OnUpdateStart();
}

void LoginController::End()
{
  PurgeLoginController();
}

void LoginController::UpdateEachFrame( float delta )
{
  if(login_state_ == kLoginStateLoginUpdate)
  {
    UpdateController::GetInstance().UpdateEachFrame(delta);
  }
}

void LoginController::OnUpdateStart()
{
  UpdateController::GetInstance().Start();
  //OnFirstShowStart();
    hasUpdate = false;
  OnShowLogoStart();

}

void LoginController::OnUpdateEnd()
{
    hasUpdate = true;
  OnLoginStart();
}

void LoginController::OnFirstShowStart()
{
  if (!::GetIsShowInCacheFirstShowData())
  {
    taomee::ui::UIFirstShow* layer = taomee::ui::CreateUIFirstShow();    
    layer->SubscribePlayComplete(this, &LoginController::OnFirstShowEnd);
    //root_scene_->AddLayerOnUILayer(layer, layer->getTag(),INT_MAX);
    UINotificationNode::GetInstance()->addChild(layer, INT_MAX - 2, layer->getTag());
    first_show_complete_ = false;
    layer->ignoreAnchorPointForPosition(false);
    layer->setAnchorPoint(ccp(0.5f, 0.5f));
    CCSize winSize = CCDirector::sharedDirector()->getWinSize();
    layer->setPosition(ccp(winSize.width * 0.5f, winSize.height * 0.5f));
    // play sound
    int music_id = GetLuaMusic("kSIDFirstShow_bgm");
    SoundManager::GetInstance().PlayBackgroundMusic(music_id, true);
  } 
  else 
  {
    int sound_id = GetLuaMusic("kSIDLogin_bgm");
    taomee::SoundManager::GetInstance().PlayBackgroundMusic(sound_id, true);
    first_show_complete_ = true;

	CreateLoginLayer(kLoginStateLoginLogin, true);
  }
}

void LoginController::OnFirstShowEnd(ui::UIFirstShow* ui_first_show)
{
  first_show_complete_ = true;
  ::CacheFirstShowDataToUserDefaultXml();
  ui_first_show->removeFromParentAndCleanup(true);
  int sound_id = GetLuaMusic("kSIDLogin_bgm");
  taomee::SoundManager::GetInstance().PlayBackgroundMusic(sound_id, true);

//#ifdef PLATFORM_3RD
  
  if(hasUpdate)
  {
    is_first_login_ = false;
    CreateLoginLayer(kLoginStateLoginLogin, true);
    is_first_select_server_ = false;
  }
  return;
//#endif
}

void LoginController::OnShowLogoStart()
{
  //1.
  cocos2d::extension::UILayer* layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_logo_scene.lua", "CreateShowLogoScene");
  root_scene_->AddLayerOnUILayer(layer, layer->getTag(),INT_MAX);
}

void LoginController::OnShowLogoEnd(cocos2d::extension::UILayer* layer)
{
   layer->removeFromParentAndCleanup(true);
   if (::GetIsCoprightPageHasShow())
   {
      OnFirstShowStart();
   }
    else
    {
      OnShowCoprightPageStart();
    }

   UpdateManager::GetInstance().fadeCompleteCallFun();
}

void LoginController::OnShowCoprightPageStart()
{
  bool is_need_show = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/ui_copright_page.lua", "IsNeedShowCoprightPage");
  if (is_need_show)
  {
    cocos2d::extension::UILayer* layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_copright_page.lua", "CreateCoprightPage");
    root_scene_->AddLayerOnUILayer(layer, layer->getTag(),INT_MAX);  
  }
  else
  {
    OnShowCorightPageEnd();
  }
}

void LoginController::OnShowCorightPageEnd()
{
  CacheCoprightShowDataToUserDefaultXml();
  OnFirstShowStart();
}

void LoginController::OnLoginStart()
{

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32) || (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	first_show_server_ = false;
	CreateLoginLayer(kLoginStateLoginLogin, true);
	
	return;
#endif
    
#ifdef TargetForNor
    first_show_server_ = false;
    CreateLoginLayer(kLoginStateLoginLogin, true);
    return;
#endif
    
			
#ifdef PLATFORM_3RD
	if (::GetIsShowInCacheFirstShowData())
	{
		is_first_login_ = false;
		CreateLoginLayer(kLoginStateLoginLogin, true);
		is_first_select_server_ = false;
	}
	else
	{
		CreateLoginLayer(kLoginStateLoginLogin, true);
	}
    return;
#else   
    is_first_login_ = !GetIsCanLoginAsDefault();
#endif
  
  is_first_select_server_ = false;
  if(is_first_login_)
  {  
    is_first_select_server_ = true;
    CreateLoginLayer(kLoginStateLoginLogin, true);
  }
  else
  {
    CreateLoginLayer(kLoginStateLoginDefault, true);
  }
}

void LoginController::OnLoginEnd()
{
	
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32) || (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	if(!first_show_server_)
	{
		string _uid = account::AccountManager::GetInstance().user_id_str();
		account::AccountManager::GetInstance().sendLogin3rdRequest(_uid,"","userToken",1000);
		first_show_server_ = true;
		//is_first_login_ = false;
		return;
	}else
	{
		
	}
#endif
    
#ifdef TargetForNor
    if(!first_show_server_)
	{
        
		string _uid = account::AccountManager::GetInstance().user_id_str();
		account::AccountManager::GetInstance().sendLogin3rdRequest(_uid,"","userToken",1000);
		first_show_server_ = true;
		return;
	}
#endif


  if(is_first_login_ && is_first_select_server_)
  {
    CreateLoginLayer(kLoginStateLoginSelectServer, false);
  }
  else
  {
    GameManager::GetInstance().OnLoadResourceCompleted();
  }
}

void LoginController::LoadLoginScene()
{
  assert(root_scene_ == NULL);
  root_scene_ = ui::TemplateScene::Create();
  root_scene_->retain();
  root_scene_->SwitchToThisScene();
  cocos2d::extension::UILayer* ui_login_default_layer = LuaTinkerManager::GetInstance()\
    .CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_main.lua", "CreateLoginMainLayer");
  root_scene_->AddLayerOnUILayer(ui_login_default_layer, 234524);
}

void LoginController::CreateLoginLayer( eLoginState login_state, bool is_replace )
{//hasUpdate//first_show_complete_
	 
  cocos2d::CCLayer* layer = NULL;
  switch(login_state)
  {
  case kLoginStateLoginLogin:
    {
		if(first_show_complete_ != true || hasUpdate != true)//������ɣ���ʾlogoҲ���
		{
			return;
		}
		if(hadShowLoginLayer == true)
		{
			return;
		}
		hadShowLoginLayer = true;
#ifdef PLATFORM_3RD
        if(SDKManager::isLogin())
        {
            SDKManager::doLastUserLogin();
        }else
        {
            SDKManager::initSDK();
            SDKManager::doLogin();
        }
        
        //layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_default.lua", "CreateLoginDefaultLayer");
        //login_state_ = kLoginStateLoginDefault;
        login_state_ = kLoginStateLoginLogin;
		first_show_server_ = false;
		taomee::account::AccountManager::GetInstance().hasLoginFrom3rd = false;
        return;
#else
      layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_login.lua", "CreateLoginLoginLayer");
      login_state_ = kLoginStateLoginLogin;
	  first_show_server_ = false;
	  taomee::account::AccountManager::GetInstance().hasLoginFrom3rd = false;
        break;
#endif
      break;
        
    }
    case kLoginStateLoginDefault:
      {
#ifdef PLATFORM_3RD
          //SDKManager::doLastUserLogin();
          layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_default.lua", "CreateLoginDefaultLayer");
#else
          layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_default.lua", "CreateLoginDefaultLayer");
#endif
          login_state_ = kLoginStateLoginDefault;
          break;
      }
  case kLoginStateLoginRegister:
    {
      layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_register.lua", "CreateLoginRegisterLayer");
      login_state_ = kLoginStateLoginRegister;
      break;
    }
  case KLoginStateLoginEnterShow:
	  {
		  layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_default.lua", "CreateLoginDefaultLayer");
		  login_state_ = KLoginStateLoginEnterShow;
		  break;
	  }
  case kLoginStateLoginSelectServer:
    {
      layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/ui_login_select_server.lua", "CreateLoginSelectServerLayer");
      login_state_ = kLoginStateLoginSelectServer;
      break;
    }
  }

  if(is_replace)
    ReplaceLayer(layer);
  else
    AddLayer(layer);
}

void LoginController::HandleFSMMessage(LoginFsmMessage msg_type)
{
	switch (msg_type)
	{
		case FSMSTART:
		{
			login_server_context_->enterStartState();
			break;
		}
		case AUTHOK:
		{
			login_server_context_->AuthOK();
			break;
		}	
		case AUTHERROR:
		{
			login_server_context_->AuthError();
			break;
		}
		case GETUSERDATACOMPLETE:
		{
			login_server_context_->GetUserDataComplete();
			break;
		}
		case NEEDSELECTROLE:
		{
			login_server_context_->NeedSelectRole();
			break;
		}
		case NOTNEEDSELECTROL:
		{
			login_server_context_->NotNeedSelectRole();
			break;
		}
		case  NETRESPONDSELECTSUCESS:
		{
			login_server_context_->NetRespondSelectSucess();
			break;
		}
		case NETRESPONDSELECTFAIL:
		{
			login_server_context_->NetRespondSelectFail();
		}
		default:
			assert(false);
	}
}
//impl SMC FSM Action	
// LoginAuthState action
void LoginController::SendAuthRequest()
{
	account::AccountManager::GetInstance().Login();
}

void LoginController::SetAccountInfo()
{

}

void LoginController::ShowAuthDialog()
{

}
// GetUserDataState action
void LoginController::SendGetUserData()
{
	DataManager::GetInstance().data_sync_module()->UpdateUserDataFromServer();
}

void LoginController::SetUserData()
{

}
// CheckNeedSelectRoleState
void LoginController::CheckNeedSelectRole() 
{
  if (is_new_player_)
  {
	  HandleFSMMessage(LoginController::NEEDSELECTROLE);
  }
  else
  {
    HandleFSMMessage(LoginController::NOTNEEDSELECTROL);
  }
}
// SelectRoleState
void LoginController::ShowSelectRoleDialog()
{
	cocos2d::CCLayer* layer = LuaTinkerManager::GetInstance().CallLuaFunc<cocos2d::extension::UILayer*>("script/ui/CreateRoleUI.lua", "GlobalOpenCreateRoleUIRedirector");
	cocos2d::CCScene* scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
	scene->getChildByTag(ui::kTemplateSceneUILayerTag)->addChild(layer);
}

void LoginController::DismissSelectRoleDialog() 
{
  
}

void LoginController::SetSelectRole() 
{

}

void LoginController::SendSelectRequest()
{
}

void LoginController::ShowSelectRoleFailDialog()
{

}

// EnterMainMapState
void LoginController::EntryMainMap()
{	
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/main_mission_util.lua","InitMainMission");
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/main_mission_navigation.lua","InitMainMissionNavigation");
	GameManager::GetInstance().OnLoginCompleted();
  
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/CreateRoleUI.lua", "GlobalCloseCreateRoleUIRedirector");
}


void LoginController::CloseCurrentLayer()
{
  if(login_layer_vector_.size() == 1)
    return;
  if(login_layer_vector_.size() >= 2)
  {
    cocos2d::CCNode* layer = login_layer_vector_[login_layer_vector_.size() - 2];
    layer->setVisible(true);
  }
  cocos2d::CCNode* layer = login_layer_vector_.back();
  layer->removeFromParentAndCleanup(true);
  login_layer_vector_.pop_back();
}

int LoginController::GetCachedUserId()
{
  std::string user_id_str = cocos2d::CCUserDefault::sharedUserDefault()->getStringForKey(kLocalUserIdKey.c_str());
  return ConvertUserIdStr2UserId(user_id_str);
}

bool LoginController::SetUserId(string user_id_str)
{
  int user_id = ConvertUserIdStr2UserId(user_id_str);
  if(user_id == 0)
    return false;

  //std::ostringstream os;
  //os << user_id;
  //cocos2d::CCUserDefault::sharedUserDefault()->setStringForKey(kLocalUserIdKey.c_str(), os.str());
  account::AccountManager::GetInstance().set_user_id(user_id);
  return true;
}

void LoginController::CacheUserId()
{
  uint_64 user_id = account::AccountManager::GetInstance().user_id();

  if(user_id == 0)
    return;

  std::ostringstream os;
  os << user_id;
  cocos2d::CCUserDefault::sharedUserDefault()->setStringForKey(kLocalUserIdKey.c_str(), os.str());
}

void LoginController::SetNetworkServerId(int server_id)
{
  is_first_select_server_ = false;
  net::constants::SetServerNetworkId(server_id);
  cocos2d::CCUserDefault::sharedUserDefault()->setIntegerForKey(kLocalServerIdKey.c_str(), server_id);
}

int LoginController::GetCurrentNetworkServerId()
{
  if (!DataManager::GetInstance().GetServerListDataTable()->GetServerlist(net::constants::GetCurrentServerNetworkId()))
  {
    net::constants::SetServerNetworkId( ((CCInteger*)DataManager::GetInstance().GetServerListDataTable()->GetServerIdArray()->objectAtIndex(0))->getValue() );
    cocos2d::CCUserDefault::sharedUserDefault()->setIntegerForKey(kLocalServerIdKey.c_str(), kServerIdDefault);
  }
  return net::constants::GetCurrentServerNetworkId();
}

bool LoginController::GetIsCanLoginAsDefault()
{
  int user_id = GetCachedUserId();
  int server_id = cocos2d::CCUserDefault::sharedUserDefault()->getIntegerForKey(kLocalServerIdKey.c_str(), kServerIdInvalid);
  if(server_id != kServerIdInvalid)
    net::constants::SetServerNetworkId(server_id);

  if(user_id == taomee::account::kUserIdInValid)
    return false;

  account::AccountManager::GetInstance().set_user_id(user_id);
  return true;
}

void LoginController::AddLayer(cocos2d::CCNode* node)
{
  if(login_layer_vector_.size() > 0)
  {
    CCNode* top_layer = login_layer_vector_.back();
    top_layer->setVisible(false);
  }
  login_layer_vector_.push_back(node);
  cocos2d::CCScene* scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
  scene->getChildByTag(ui::kTemplateSceneUILayerTag)->addChild(node);
}

void LoginController::ReplaceLayer(cocos2d::CCNode* node)
{
  if(login_layer_vector_.size() > 0)
  {
    CCNode* top_layer = login_layer_vector_.back();
    top_layer->removeFromParentAndCleanup(true);
    login_layer_vector_.pop_back();
  }
  login_layer_vector_.push_back(node);
  //cocos2d::CCScene* scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
  //scene->getChildByTag(ui::kTemplateSceneUILayerTag)->addChild(node);
  root_scene_->AddLayerOnUILayer((CCLayer*)node, node->getTag());
}

int LoginController::ConvertUserIdStr2UserId( string& str )
{
  for(int i = 0; i < str.size(); ++i)
  {
    if(str[i] < '0' || str[i] > '9')
      return taomee::account::kUserIdInValid;
  }

  int user_id = atoi(str.c_str());

  if (user_id < 1000 || user_id > 9999)
    user_id = taomee::account::kUserIdInValid;

  return user_id;
}

void LoginController::set_is_new_player( bool is_new_player )
{
  is_new_player_ = is_new_player;
}

bool LoginController::get_is_new_player()
{
  return is_new_player_;
}

}