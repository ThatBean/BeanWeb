//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: login_controller.h
//        Author: peteryu
//          Date: 2014/1/15 17:02
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/1/15      add
//////////////////////////////////////////////////////////////

#ifndef LOGIN_CONTROLLER_H
#define LOGIN_CONTROLLER_H

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"
#include <vector>
#include <string>

#include "engine/platform/SingleInstance.h"

namespace taomee
{

namespace ui
{
  class TemplateScene;
  class UIFirstShow;
}

namespace login_server_fsm
{
class login_serverContext;
}

enum eLoginState
{
  kLoginStateLoginPre,
  kLoginStateLoginUpdate,
  kLoginStateLoginDefault,
  kLoginStateLoginLogin,
  kLoginStateLoginRegister,
  KLoginStateLoginEnterShow,
  kLoginStateLoginSelectServer
};

class LoginController : public SingleInstanceObj
{
private:
  LoginController();
  DISALLOW_COPY_AND_ASSIGN(LoginController);
public:
  ~LoginController();

public:
  static LoginController& GetInstance()
  {
    static LoginController* X = NULL;
    if (!X)
    {
      X = new LoginController();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }
  void PurgeLoginController();
  void okClickBeginUpdate();//���ȷ������
  void reCheckUpdate();
  void Start();
  void End();

  void UpdateEachFrame(float delta);

  // first, update resource from server
  void OnUpdateStart();
  void OnUpdateEnd();

  // at the same time, play start movie when first login
  void OnFirstShowStart();
  void OnFirstShowEnd(ui::UIFirstShow* ui_first_show);

  void OnShowLogoStart();
  void OnShowLogoEnd(cocos2d::extension::UILayer* layer);

  void OnShowCoprightPageStart();
  void OnShowCorightPageEnd();
  // second, load login layer, enter username&password
  // register new user
  // select server
  void OnLoginStart();
  void OnLoginEnd();

  void CreateLoginLayer(eLoginState login_state, bool is_replace);
  void CloseCurrentLayer();
  
  // 0 is invaild user id
  int  GetCachedUserId();
  bool SetUserId(std::string user_id_str);
  void CacheUserId();

  void SetNetworkServerId(int server_id);
  int  GetCurrentNetworkServerId();
public:
  enum LoginFsmMessage
	{
		FSMSTART,
		AUTHOK,
		AUTHERROR,
		GETUSERDATACOMPLETE,
		NEEDSELECTROLE,
		NOTNEEDSELECTROL,
		NETRESPONDSELECTSUCESS,
		NETRESPONDSELECTFAIL,
	};
	void HandleFSMMessage(LoginFsmMessage msg_type);

	//impl SMC FSM Action	
  // LoginAuthState action
	void SendAuthRequest();
	void SetAccountInfo();
	void ShowAuthDialog();

	// GetUserDataState action
	void SendGetUserData() ;
	void SetUserData();
	
	// CheckNeedSelectRoleState
	void CheckNeedSelectRole() ;


	// SelectRoleState
	void ShowSelectRoleDialog();
  void ShowCreateNameDialog();
	void DismissSelectRoleDialog() ;
	void SetSelectRole();
	void SendSelectRequest();
	void ShowSelectRoleFailDialog();

	// EnterMainMapState
	void EntryMainMap();

  // is_new_player_
  void set_is_new_player(bool is_new_player);
  bool get_is_new_player();

  void set_is_first_login(bool is_first_login){is_first_login_ = is_first_login;}
  bool is_first_login(){return is_first_login_;}

  void set_is_first_select_server(bool is_first_select_server){is_first_select_server_ = is_first_select_server;}
  bool is_first_select_server(){return is_first_select_server_;}
private:
  void LoadLoginScene();
  bool GetIsCanLoginAsDefault();
  void AddLayer(cocos2d::CCNode* node);
  void ReplaceLayer(cocos2d::CCNode* node);
  int  ConvertUserIdStr2UserId(std::string& str);
  
private:
  ui::TemplateScene*            root_scene_;
  std::vector<cocos2d::CCNode*> login_layer_vector_;
  eLoginState                   login_state_;
	
  bool                          is_new_player_;
  bool                          is_first_login_;
  bool                          is_first_select_server_;
  bool                          first_show_complete_;
  bool                          first_show_server_;
  bool                          hasUpdate;
  bool							hadShowLoginLayer;

	login_server_fsm::login_serverContext* login_server_context_;
};

}
#endif