//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: account_manager.cpp
//        Author: leohou
//       Version:
//          Date: Nov 10, 2013
//          Time: 10:18:30 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     10:18:30 PM
//
//////////////////////////////////////////////////////////////

#include "game/account/account_manager.h"

#include "engine/base/cocos2d_wrapper.h"
#include "game/game_manager/game_manager.h"
#include "network/net_manager.h"
#include "network/net_client_tcp/sample_tcp_client.h"
#include "engine/base/utils_string.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/serverlist_data_table.h"
#include "network/net_constant.h"
#ifdef PLATFORM_3RD
#import "SDKManager.h"
#endif

#include <sstream>

using namespace cocos2d;

namespace {
const std::string kLocalUserInfoCacheKey = "user_info";

const taomee::account::UserID kInvalidUserID = 0;
const int kLoginDialogTag = 887788;
}

namespace taomee {
namespace account {

bool Valid(UserID user_id)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS || CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

  if (user_id >= 1000 && user_id <= 9999)
  {
    return true;
  }
  return false;
#else
  return true;
#endif
}


AccountManager& AccountManager::GetInstance()
{
  static AccountManager* X = NULL;
  if (!X)
  {
    X = new AccountManager();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
  }
  return *X;
}

AccountManager::AccountManager()
: user_id_(kInvalidUserID)
{

}

AccountManager::~AccountManager()
{

}

std::string AccountManager::user_id_str() const 
{

  return Uint642String(user_id_);
}

void AccountManager::sendLoginRequest()
{
  boost::shared_ptr<LoginSession> login_session = boost::make_shared<LoginSession>();
  login_session->SubscribeReciveBodyComplete(this, &AccountManager::onLoginRequestCompleted);

  net::User_login_in user_login_in;
  user_login_in.set_cmd(GetHttpActionIDByName("user_login"));
  user_login_in.set_session("session");
  //user_login_in.get_login_auth().set_sess_id("auth_session");

  std::ostringstream os;
  os << user_id_;
  user_login_in.set_userid(os.str());

  login_session->set_message_in(user_login_in);
  login_session->setForceSendUntilSuccessFlag(false);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(login_session);
//  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/ui_net_waitting.lua","OpenNetWaittingUI");
}

void AccountManager::onLoginRequestCompleted(int error_code,
                                             boost::shared_ptr<LoginSession> login_session)
{
  const net::User_login_out& user_login_out = login_session->get_message_out();
  const net::User_login_in& user_login_in = login_session->get_message_in();
  //账号被封
  if ( user_login_out.get_closure_time() != 0 )
  {
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua","ServerClosureAccount",user_login_out.get_closure_time());
    return;
  }
#ifdef PLATFORM_3RD
  session_ = user_login_out.get_session();
#else

  session_ = user_login_out.get_session();
#endif
  UserID id =String2UInt64(user_login_out.get_server_userid().c_str());
  set_user_id(id);

  bool is_new_player = user_login_out.get_is_new()?true:false;
  GameManager::GetInstance().OnLoginAuthCompleted(is_new_player);
  net::SampleTcpClient::GetInstance().RegisterAllEvent();
  //if(error_code != 0 || is_new_player == true)
  //  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/ui_net_waitting.lua","CloseNetWaittingUI");
}
    
void AccountManager::reStartTCPConnect()
{
  net::SampleTcpClient::GetInstance().StartConnect();
}

void AccountManager::sendLogin3rdRequest(std::string userid,std::string userName,std::string userToken,int channel_id)
{
    boost::shared_ptr<Login3rdSession> login3rd_session = boost::make_shared<Login3rdSession>();
    login3rd_session->SubscribeReciveBodyComplete(this, &AccountManager::onLogin3rdRequestCompleted);
    
    net::login3rd_login_in::Login3rd_login_in user_login3rd_in;

    user_login3rd_in.set_cmd(GetHttpActionIDByName("login3rd_login"));
    user_login3rd_in.set_sess_id(userToken);
    user_login3rd_in.set_channel_id(channel_id);
    user_login3rd_in.set_user_id(userid);
    user_login3rd_in.set_username(userName);

    UserID id =String2UInt64(userid.c_str());
    set_user_id(id);
    LoginController::GetInstance().CacheUserId();
    login3rd_session->set_message_in(user_login3rd_in);
    login3rd_session->setForceSendUntilSuccessFlag(false);
    net::NetManager& http_client = net::NetManager::GetInstance();
    http_client.SendSession(login3rd_session);
}
    
    
void AccountManager::onLogin3rdRequestCompleted(int error_code, boost::shared_ptr<Login3rdSession> Login3rd_Session)
{
    const net::login3rd_login_out::Login3rd_login_out& user_login3rd_out = Login3rd_Session->get_message_out();
    if(error_code > 0)
    {
        return;
    }
    //获取服务器列表
    //hasLoginFrom3rd = true;
	taomee::account::AccountManager::GetInstance().hasLoginFrom3rd = true;
    std::vector<net::login3rd_login_out::Server_list > server_list = user_login3rd_out.get_server_list();
    ServerListDataTable *table = new ServerListDataTable();
   
    CCLog("获取服务器列表start");
    for(std::vector<net::login3rd_login_out::Server_list >::iterator itr = server_list.begin(); itr != server_list.end();++itr)
    {
        string server_name = itr->get_title();
        CCLog("server_name==%s",server_name.c_str());
        int server_id = itr->get_server_id();
         CCLog("server_id==%d",server_id);
        string server_ip = itr->get_url();
        CCLog("server_ip==%s",server_ip.c_str());
        int state = itr->get_tag();
        CCLog("state==%d",state);
        string gateway_ip = itr->get_gateway_ip();
        int gateway_port = itr->get_gateway_port();
        uint_32 open_time = itr->get_op_time();
        table->addServerList(server_id, server_name, server_ip, state, gateway_ip, gateway_port,open_time);
    }
     DataManager::GetInstance().setServerList(table);
    
    CCLog("获取服务器列表end");
    
    std::string userid = user_login3rd_out.get_global_userid();
    std::string session = user_login3rd_out.get_session();
    CCLog("userid==%s",userid.c_str());
    CCLog("session==%s",session.c_str());
    
    UserID id =String2UInt64(userid.c_str());
    
    set_user_id(id);
    _token3rd = session;
    user_id_3rd = userid;

#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32) || (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)
	LoginController::GetInstance().CreateLoginLayer(KLoginStateLoginEnterShow, false);
#endif

#ifdef TargetForNor
    LoginController::GetInstance().CreateLoginLayer(KLoginStateLoginEnterShow, false);
#endif
    
#ifdef PLATFORM_3RD
    if (SDKManager::reLoginFlag != 1) {
        LoginController::GetInstance().CreateLoginLayer(KLoginStateLoginEnterShow, false);
    }
	
    
#endif
}
    
void AccountManager::sendLoginFrom3rd(std::string userid,std::string userToken)
{

    boost::shared_ptr<LoginSession> login_session = boost::make_shared<LoginSession>();
    login_session->SubscribeReciveBodyComplete(this, &AccountManager::onLoginRequestCompleted);
    
    net::User_login_in user_login_in;
    user_login_in.set_cmd(GetHttpActionIDByName("user_login"));
    user_login_in.set_session(userToken);
    
    user_login_in.set_userid(userid);

    login_session->set_message_in(user_login_in);
    login_session->setForceSendUntilSuccessFlag(false);
    
    net::NetManager& http_client = net::NetManager::GetInstance();
    http_client.SendSession(login_session);
    //LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/ui_net_waitting.lua","OpenNetWaittingUI");
}
void AccountManager::Login()
{
#ifdef TargetForPP
     this->sendLoginFrom3rd(user_id_3rd,_token3rd);
#elif TargetForItools
    this->sendLoginFrom3rd(user_id_3rd,_token3rd);
#elif TargetFor91
    this->sendLoginFrom3rd(user_id_3rd,_token3rd);
#else
    //this->sendLoginRequest();LoginController::GetInstance().CreateLoginLayer(KLoginStateLoginEnterShow, false);

	if(taomee::account::AccountManager::GetInstance().hasLoginFrom3rd == false)
	{

		LoginController::GetInstance().CreateLoginLayer(kLoginStateLoginLogin, false);
		return;
	}
	 this->sendLoginFrom3rd(user_id_3rd,_token3rd);
#endif
}


void AccountManager::sendBuyDiamondByProductId(const char* productID,const char* price)
{
#ifdef PLATFORM_3RD
	int server_id = net::constants::GetCurrentServerNetworkId();
	string strID = Int2String(server_id);
	CCLog("serverid==%s",strID.c_str());
	SDKManager::doPay(productID,user_id_str().c_str(),strID.c_str(),"0",price,"","");
#endif
}

} /* namespace account */
} /* namespace taomee */
