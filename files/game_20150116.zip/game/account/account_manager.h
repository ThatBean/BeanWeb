//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: account_manager.h
//        Author: leohou
//       Version:
//          Date: Nov 10, 2013
//          Time: 10:18:30 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     10:18:30 PM
//
//////////////////////////////////////////////////////////////

#ifndef ACCOUNT_MANAGER_H_
#define ACCOUNT_MANAGER_H_

#include "engine/base/basictypes.h"

#include "network/session/net_session.hpp"
#include "network/proto/user_login_in.h"
#include "network/proto/user_login_out.h"
#include "network/proto/login3rd_login_in.h"
#include "network/proto/login3rd_login_out.h"
#include "game/scene/loading_sence/login_controller.h"

#include "engine/platform/SingleInstance.h"

namespace taomee {


namespace account {

typedef uint_64 UserID;
bool Valid(UserID user_id);

enum eUserId
{
  kUserIdInValid = 0
};

class AccountManager : public SingleInstanceObj {
public:
  virtual ~AccountManager();

  static AccountManager& GetInstance();

  UserID user_id() const { return user_id_; }
  std::string user_id_str() const;
  void set_user_id(UserID user_id) {user_id_ = user_id;}
  const std::string session() const { return session_; }
  const std::string& getUserIDFromServer() { return mUserIDFromSever; }
  void setUserIDFromServer(const std::string& v) { mUserIDFromSever = v; }  

  void Login();
  void sendLogin3rdRequest(std::string userid,std::string userName,std::string userToken,int channel_id);
  bool hasLoginFrom3rd;
  void reStartTCPConnect();
  void sendBuyDiamondByProductId(const char* productID,const char* price);
private:
  bool localUserInfoCached(UserID& user_id);
  void cacheUserInfo(const UserID user_id);
  void purgeCachedUserInfo();

  void showLoginDialog();
  void removeLoginDialog();

  typedef net::NetSession<net::User_login_in, net::User_login_out> LoginSession;
  void sendLoginRequest();
  void onLoginRequestCompleted(int error_code, boost::shared_ptr<LoginSession> login_session);
    
  typedef net::NetSession<net::login3rd_login_in::Login3rd_login_in, net::login3rd_login_out::Login3rd_login_out> Login3rdSession;
  
  void onLogin3rdRequestCompleted(int error_code, boost::shared_ptr<Login3rdSession> Login3rd_Session);
  void sendLoginFrom3rd(std::string userid,std::string userToken);

  
    
private:
  AccountManager();
  DISALLOW_COPY_AND_ASSIGN(AccountManager);

private:
  UserID user_id_;
  std::string session_;
  std::string  user_id_3rd;
  std::string  _token3rd;
  std::string  mUserIDFromSever;
  
};

} /* namespace account */
} /* namespace taomee */
#endif /* ACCOUNT_MANAGER_H_ */
