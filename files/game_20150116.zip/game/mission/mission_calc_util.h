//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: mission_calc_util.h
//        Author: Sachin
//          Date: 2013/10/28 21:57
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Sachin    2013/10/28      add
//////////////////////////////////////////////////////////////

#ifndef MISSION_CALC_UTIL_H
#define MISSION_CALC_UTIL_H

#include "engine/base/cocos2d_wrapper.h"
#include "mission_contants.h"
#include <string>

using namespace  taomee::mission_contants;
using namespace cocos2d;

namespace taomee{
namespace mission_util{

/*
* Calc Interface 
*/

bool QueryMissionIsNew(int mission_id);

bool QueryMissionUnlocked(int mission_id);

bool QueryMissionCondComplete(int mission_id, int conditon_idx);

bool QueryMissionHidden(int mission_id);

bool QueryMissionComplete(int mission_id);

eMissionState QueryMissionState(int mission_id);

/*
* select  quest_table Interface
*/

eMissionType QueryMissionType(int mission_id);

std::string QueryMissionName(int mission_id);

int QueryMissionRewardid(int mission_id);

int QueryMissionCostAp(int mission_id);

int QueryMissionLevel(int mission_id);

CCArray* QueryAllMissionList(int castle_id);

} // namespace mission_util
} // namespace taomee
#endif //MISSION_CALC_UTIL_H