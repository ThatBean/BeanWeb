#include "mission_calc_util.h"

#include "game/game_manager/data_manager.h"

namespace taomee{
namespace mission_util{

bool QueryMissionIsNew(int mission_id) {
  return true;
}

bool QueryMissionUnlocked(int mission_id) {
  return true;
}

bool QueryMissionCondComplete(int mission_id, int conditon_idx) {
  return false;
}

bool QueryMissionHidden(int mission_id) {
  return false;
}

bool QueryMissionComplete(int mission_id) {
  return false;
}

eMissionState QueryMissionState(int mission_id) {
  return kMissionStateUnkown;
}

eMissionType QueryMissionType(int mission_id) {
  return kUnkownMission;
}

std::string QueryMissionName(int mission_id) {
  return "";
}

int QueryMissionRewardid(int mission_id) {
  return 0;
}

int QueryMissionCostAp(int mission_id) {
  return 0;
}

int QueryMissionLevel(int mission_id) {
  return 0;
}

int QueryDailyMissionRemainTime(int mission_id){
  return 0;
}

CCArray* QueryAllMissionList(int castle_id) {
  return NULL;
}

} // namespace mission_util
} // namespace taomee