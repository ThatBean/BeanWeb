//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: mission_contants.h
//        Author: Sachin
//          Date: 2013/10/29 10:22
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Sachin    2013/10/29      add
//////////////////////////////////////////////////////////////

#ifndef MISSION_CONTANTS_H
#define MISSION_CONTANTS_H

namespace taomee {
namespace mission_contants {

enum eMissionState
{
  kMissionStateUnkown = -1,
  kMissionStateLocked = 1, // missions which are lock cos conditions are unmeet
  kMissionStateNew,        // missions which are new unlocked
  kMissionStateProcessing, // some passway(s) but not all had been passed for these missions
  kMissionStateComplete    // all passways were passed for these missions
};

enum eMissionType
{
  kUnkownMission = -1,
  kMainMission = 1, // main story mission in checkpoints
  kRoleMission,     // release passive skill for all celected cards in current checkpoint
  kChainMission,    // 
  kDailyMission,    // refresh as a new one in every day
  kEventMission,    // exist in a certain days
  kFreeMission,      // random reward in total four different items for every pass. the final bonus will persent after all the four different reward items had been celected.
  kRoadMission
};


#define  MAX_MISSON_UNIT_COUNT  4 // four different items Or four checkpoint
} // namespace mission_contants
} // namespace taomee
#endif //MISSION_CONTANTS_H