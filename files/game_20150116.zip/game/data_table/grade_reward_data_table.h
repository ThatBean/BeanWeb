//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: grade_reward_data_table.h
//        Author: vic.tang
//          Date: 2014/10/27 17:05
//   Description: 
//
// History:
//     <author>    <time>        <descript>
//     vic.tang    2014/10/27      add
//////////////////////////////////////////////////////////////



#ifndef _GRADEREWARD_DATA_TABLE_H_
#define _GRADEREWARD_DATA_TABLE_H_

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"

#define Invalid_Aura_ID 0
#define Invalid_Ability_ID -1
#define Modifier_Max_Count (3)

class GradeRewardData
{
public:
	GradeRewardData();
	~GradeRewardData();

public:
	uint_32 get_ap() const
	{
		return ap;
	}

private:
	uint_32 cp_id;
	uint_32 grade;
	uint_32 item_id_0;
	uint_32 item_count_0;
	uint_32 item_id_1;
	uint_32 item_count_1;
	uint_32 item_id_2;
	uint_32 item_count_2;
	uint_32 item_id_3;
	uint_32 item_count_3;
	uint_32 ap;

	friend class GradeRewardDataDataTable;
};

class GradeRewardDataDataTable
{
public:
	GradeRewardDataDataTable();
	~GradeRewardDataDataTable();
	bool InitWithFileName(const char *file_name);
	const GradeRewardData* GetByID(int id);
protected:
	void parseRow(const std::vector<std::string> &row);
private:
	typedef std::map<int, GradeRewardData*> defGradeRewardDataMap;
	typedef defGradeRewardDataMap::iterator defGradeRewardDataMapIter;
	typedef defGradeRewardDataMap::const_iterator defGradeRewardDataMapConstIter;
	defGradeRewardDataMap data_table_;
};

#endif
