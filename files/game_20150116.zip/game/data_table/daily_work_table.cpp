#include "daily_work_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
DailyWorkDataTable::DailyWorkDataTable()
{
	dailyWork_data_table_ = new vector<DailyWorkData*>();
}

DailyWorkDataTable::~DailyWorkDataTable()
{
	for (vector<DailyWorkData*>::iterator itr = dailyWork_data_table_->begin();
		itr != dailyWork_data_table_->end(); ++itr)
	{
		delete *itr;
	}
	delete dailyWork_data_table_;
}

bool DailyWorkDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;
	cocos2d::CCLog("Loading csv file %s", file_name);

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}

DailyWorkData* DailyWorkDataTable::GetDailyWork(int id)
{
	map<int, int>::iterator index = index_map_.find(id);
	if(index == index_map_.end())
	{
		CCLOG("DailyWorkDataTable TypeId not found! Id: %d", id);
		assert(false);
		return NULL;
	}
	return dailyWork_data_table_->at(index->second);
}

CCArray* DailyWorkDataTable::GetAllDailyWorkId()
{
	CCArray* res_arr = CCArray::create();
	for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
	{
		CCInteger* obj_var = CCInteger::create(it->first);
		res_arr->addObject(obj_var);
	}
	return res_arr;
}
int DailyWorkDataTable::getDailyWorkAllCount()
{

	int count = GetAllDailyWorkId()->count();
	return count;
}

void DailyWorkDataTable::parseRow(vector<string> &row)
{
	int i = 0;
	DailyWorkData *data = new DailyWorkData();
	data->id = String2Int(row[i++]);
	data->level = String2Int(row[i++]);
	data->reqMissionId = String2Int(row[i++]);

	data->desc	=  LanguageDataTable::FormatLanguageKey("dailywork", "desc", data->id);//row[i++];
	i++;

	data->type  = String2Int(row[i++]);
	data->count  = String2Int(row[i++]);
	data->rewardType1  = String2Int(row[i++]);
	data->rewardType2  = String2Int(row[i++]);
	data->rewardType3  = String2Int(row[i++]);
	data->rewardItemId1  = String2Int(row[i++]);
	data->rewardItemId2  = String2Int(row[i++]);
	data->rewardItemId3  = String2Int(row[i++]);
	data->rewardItemCount1  = String2Int(row[i++]);
	data->rewardItemCount2  = String2Int(row[i++]);
	data->rewardItemCount3  = String2Int(row[i++]);
	data->exp				= String2Int(row[i++]);
	data->link  = String2Int(row[i++]);
	getIntListFromString(row[i++], data->weekFlag);
	data->starCount = String2Int(row[i++]);
	
	index_map_.insert(pair<int, int>(data->id, dailyWork_data_table_->size()));
	dailyWork_data_table_->push_back(data);
}


const string& DailyWorkData::GetDesc()
{
	return LanguageDataTable::GetInstance()->GetLanguage(desc);
}
