#ifndef FRAGMENT_DATA_TABLE_H
#define FRAGMENT_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_res_data_table.h"
using namespace std;

class FragmentData : public BaseResData
{
public:
  int           getID() { return fragmentid; }
  int           getType() { return kFragmentType; }
  const std::string&  getIconName() { return fragmenticon; }
  const std::string&  getName() { return GetFragmentname(); }
  int           getRarity() { return fragmentquality; }
  int           getSellMoney() { return GetSoldPrice(); }
public:
  
  int getUserHoldCount();

  /*碎片id*/
  int GetFragmentid()
  {
    return fragmentid;
  }
  /*碎片name*/
  const string& GetFragmentname();
  /*icon*/
  string& GetFragmenticon()
  {
    return fragmenticon;
  }
  /*碎片类型
0 装备
1 卡牌*/
  int GetFragmenttype()
  {
    return fragmenttype;
  }
  /*品质
1白色
2绿色
3蓝色
4紫色*/
  int GetFragmentquality()
  {
    return fragmentquality;
  }
  /*合成数量*/
  int GetFragmentcounts()
  {
    return fragmentcounts;
  }
  /*合成目标id*/
  int GetTargetid()
  {
    return targetid;
  }
  bool GetCanSold()
  {
    return canSold;
  }
  int GetSoldPrice()
  {
    return soldPrice;
  }
  /*掉落关卡*/
  std::list<int>& GetCheckpointid()
  {
    return checkpointid;
  }
  
  int GetCheckPointCount()
  {
    return checkpointid.size();
  }

  int GetCheckPointIdByIndex(int index)
  {
    std::list<int>::iterator it = checkpointid.begin();
    for (int i = 0; i < index; ++i)
    {
      ++it;
    }
    return *it;
  }

  const string& GetFragmentTips()
  {
    return fragment_tips;
  }

  const string& GetFragmentDesc();
  
private:
  int		fragmentid;
  string		fragmentname;
  string		fragmenticon;
  int		fragmenttype;
  int		fragmentquality;
  int		fragmentcounts;
  int		targetid;
  bool  canSold;
  int   soldPrice;
  std::list<int>		checkpointid;
  string fragment_tips;
  string fragment_desc;

  friend class FragmentDataTable;
};

class FragmentDataTable
{
public:
  FragmentDataTable();
  ~FragmentDataTable();
  bool InitWithFileName(const char *file_name);
  FragmentData* GetFragment(int fragmentid);
  int  GetFragmentIDByCardID(int card_id);
protected:
  void parseRow(vector<string> &row);

private:
  vector<FragmentData*> *fragment_data_table_;
  map<int,int> target_card_list_;

  map<int, int> index_map_;
};
#endif
