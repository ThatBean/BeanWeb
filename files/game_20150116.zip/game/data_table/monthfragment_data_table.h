﻿#ifndef MONTHFRAGMENT_DATA_TABLE_H
#define MONTHFRAGMENT_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class MonthfragmentData
{
public:
  /*月数*/
  int_8 GetMonth()
  {
    return month;
  }
  /*碎片ID*/
  int GetFragmentid()
  {
    return fragmentid;
  }
private:
  int_8		month;
  int		fragmentid;

  friend class MonthfragmentDataTable;
};

class MonthfragmentDataTable
{
public:
  MonthfragmentDataTable();
  ~MonthfragmentDataTable();
  bool InitWithFileName(const char *file_name);
  MonthfragmentData* GetMonthfragment(int_8 month);

  CCArray* GetAllMonthfragmentId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<MonthfragmentData*> *monthfragment_data_table_;

  map<int_8, int> index_map_;
};
#endif
