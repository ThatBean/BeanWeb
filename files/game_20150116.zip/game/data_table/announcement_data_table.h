﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: announcement_data_table.h
//        Author: Dylan.gu
//          Date: 2014/4/28 10:49
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/4/28      add
//////////////////////////////////////////////////////////////

#ifndef ANNOUNCEMENT_DATA_TABLE_H
#define ANNOUNCEMENT_DATA_TABLE_H

#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class AnnouncementData
{
public:
  /*id*/
  uint_16 GetId()
  {
    return id;
  }
  /*types*/
  uint_16 GetType()
  {
    return type;
  }
  /*description*/
  std::string GetDescription();
  /*times*/
  uint_8 GetTimes()
  {
    return times;
  }
  /*Priority*/
  uint_8 GetPriority()
  {
    return priority;
  }
  /*/showplace*/
  uint_8 GetShowplace()
  {
    return showplace;
  }
private:
  uint_16		id;
  uint_16		type;
  std::string 	description;
  uint_8		times;
  uint_8		priority;
  uint_8		showplace;

  friend class AnnouncementDataTable;
};

class AnnouncementDataTable
{
public:
  AnnouncementDataTable();
  ~AnnouncementDataTable();
  bool InitWithFileName(const char *file_name);
  AnnouncementData* GetAnnouncement(uint_16 id);
  uint_8  GetRankColumnCount() { return announcemen_data_table_->size(); }

protected:
  void parseRow(vector<string> &row);

private:
  vector<AnnouncementData*> *announcemen_data_table_;

  map<uint_16, int> index_map_;
};

#endif
