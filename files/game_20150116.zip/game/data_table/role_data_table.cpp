#include "role_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
RoleDataTable::RoleDataTable()
{
  role_data_table_ = new vector<RoleData*>();
}

RoleDataTable::~RoleDataTable()
{
  for (vector<RoleData*>::iterator itr = role_data_table_->begin();
  itr != role_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete role_data_table_;
}

bool RoleDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

RoleData* RoleDataTable::GetRole(int_8 id)
{
  map<int_8, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("RoleDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return role_data_table_->at(index->second);
}

CCArray* RoleDataTable::GetAllRoleId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int_8, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}

bool RoleDataTable::IsRoleCard(int cardID)
{
  vector<RoleData*>::iterator it = role_data_table_->begin();
  for ( ; it != role_data_table_->end() ; ++it)
  {
    int roleCardID = (*it)->GetCardID();
    if (roleCardID == cardID)
    {
      return true;
    }
  }
  return false;
}

void RoleDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  RoleData *data = new RoleData();
  data->ID = String2Int8(row[i++]);
  data->cid = String2Int32(row[i++]);
  data->jobType = String2Int8(row[i++]);
  data->jobText = LanguageDataTable::FormatLanguageKey("role", "jobText", data->ID);//row[i++];
  i++;
  data->gender = String2Int8(row[i++]);
  index_map_.insert(pair<int_8, int>(data->ID, role_data_table_->size()));
  role_data_table_->push_back(data);
}

const string& RoleData::GetJobText()
{
  return LanguageDataTable::GetInstance()->GetLanguage(jobText);
}