#ifndef PVPRANKAWARD_DATA_TABLE_H
#define PVPRANKAWARD_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class PvpRankAwardData
{
public:
  /*排位*/
  std::list<int> GetRankRange()
  {
    return rank_range_array;
  }
  /*奖励金钱*/
  int GetAwardMoney()
  {
    return awardMoney;
  }
  /*奖励功勋*/
  int GetAwardExploit()
  {
    return awardExploit;
  }
private:
  int   id;
  std::list<int>	rank_range_array;
  int		awardMoney;
  int		awardExploit;

  friend class PvpRankAwardDataTable;
};

class PvpRankAwardDataTable
{
public:
  PvpRankAwardDataTable();
  ~PvpRankAwardDataTable();
  bool InitWithFileName(const char *file_name);
  PvpRankAwardData* GetPvprankaward(int rank);

protected:
  void parseRow(vector<string> &row);

private:
  vector<PvpRankAwardData*> *pvprankaward_data_table_;

  map<int, int> index_map_;
};
#endif
