#ifndef CHALLENGE_DATA_TABLE_H
#define CHALLENGE_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class ChallengeData
{
public:
	/*id*/
	int GetDailyWorkId()
	{
		return id;
	}
	/*type*/
	int GetDailyType()
	{
		return type;
	}
	/*���ֵȼ�*/
	int GetAppearLevel()
	{
		return level;
	}
	/*Ŀ����������*/
	const string& GetDesc();
	
	/*��Ҫ��ɵĴ���*/
	int getMaxCount()
	{
		return count;
	}
	/*��������1�ĵ���id*/
	int getRewardItemId_1()
	{
		return rewardItemId1;
	}
	/*��������2�ĵ���id*/
	int getRewardItemId_2()
	{
		return rewardItemId2;
	}
	/*��������1�ĸ���*/
	int getRewardItemCount_1()
	{
		return rewardItemCount1;
	}
	/*��������2�ĸ���*/
	int getRewardItemCount_2()
	{
		return rewardItemCount2;
	}
	int getDailyWorkExp()
	{
		return exp;
	}
	int getReqMissionId()
	{

		return reqMissionId;
	}
	int getCondition()
	{

		return condition;
	}
private:
	int		id;
	int		level;
	string  desc;
	int     type;
	int     condition;//����
	int     count;
	int     rewardItemId1;
	int     rewardItemId2;
	int     rewardItemCount1;
	int     rewardItemCount2;
	int     exp;
	int     reqMissionId;

	friend class ChallengeDataTable;
};

class ChallengeDataTable
{
public:
	ChallengeDataTable();
	~ChallengeDataTable();
	bool InitWithFileName(const char *file_name);
	ChallengeData* GetChallengeData(int id);

	CCArray* GetAllChallengeId();
	int getChallengeAllCount();

protected:
	void parseRow(vector<string> &row);

private:
	vector<ChallengeData*> *challenge_data_table_;

	map<int, int> index_map_;
};
#endif
