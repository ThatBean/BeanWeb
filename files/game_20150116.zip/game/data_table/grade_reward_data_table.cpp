//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: grade_reward_data_table.h
//        Author: vic.tang
//          Date: 2014/10/27 17:05
//   Description: 
//
// History:
//     <author>    <time>        <descript>
//     vic.tang    2014/10/27      add
//////////////////////////////////////////////////////////////


#include "grade_reward_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>


GradeRewardData::GradeRewardData()
	: cp_id(0)
	, grade(0)
	, item_id_0(0)
	, item_count_0(0)
	, item_id_1(0)
	, item_count_1(0)
	, item_id_2(0)
	, item_count_2(0)
	, item_id_3(0)
	, item_count_3(0)
{
	
}

GradeRewardData::~GradeRewardData()
{

}

GradeRewardDataDataTable::GradeRewardDataDataTable()
{

}

GradeRewardDataDataTable::~GradeRewardDataDataTable()
{
	for ( defGradeRewardDataMapIter iter = data_table_.begin(); iter != data_table_.end(); ++iter )
	{
		GradeRewardData* obj = iter->second;
		delete obj;
	}
	data_table_.clear();
}

bool GradeRewardDataDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}
const GradeRewardData* GradeRewardDataDataTable::GetByID(int id)
{
	defGradeRewardDataMapConstIter iter = data_table_.find( id);
	if ( iter == data_table_.end())
	{
		assert(0);
		return NULL;
	}

	return iter->second;
}

void GradeRewardDataDataTable::parseRow(const std::vector<std::string> &row)
{
	GradeRewardData* data = new GradeRewardData();
	int i = 0;
	data->cp_id = String2Int(row[i++]);
	data->grade = String2Int(row[i++]);
	data->item_id_0 = String2Int(row[i++]);
	data->item_count_0 = String2Int(row[i++]);
	data->item_id_1 = String2Int(row[i++]);
	data->item_count_1 = String2Int(row[i++]);
	data->item_id_2 = String2Int(row[i++]);
	data->item_count_2 = String2Int(row[i++]);
	data->item_id_3 = String2Int(row[i++]);
	data->item_count_3 = String2Int(row[i++]);
	data->ap = String2Int(row[i++]);

	std::pair< defGradeRewardDataMapIter, bool> result = data_table_.insert(std::pair<int, GradeRewardData*>( data->cp_id, data));
	if ( !result.second )
	{
		assert(0);
	}
}