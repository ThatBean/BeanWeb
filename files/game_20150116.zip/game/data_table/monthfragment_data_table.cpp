﻿#include "monthfragment_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
MonthfragmentDataTable::MonthfragmentDataTable()
{
  monthfragment_data_table_ = new vector<MonthfragmentData*>();
}

MonthfragmentDataTable::~MonthfragmentDataTable()
{
  for (vector<MonthfragmentData*>::iterator itr = monthfragment_data_table_->begin();
  itr != monthfragment_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete monthfragment_data_table_;
}

bool MonthfragmentDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

MonthfragmentData* MonthfragmentDataTable::GetMonthfragment(int_8 month)
{
  map<int_8, int>::iterator index = index_map_.find(month);
  if(index == index_map_.end())
  {
    CCLOG("MonthfragmentDataTable TypeId not found! Id: %d", month);
    assert(false);
    return NULL;
  }
  return monthfragment_data_table_->at(index->second);
}

CCArray* MonthfragmentDataTable::GetAllMonthfragmentId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int_8, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void MonthfragmentDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  MonthfragmentData *data = new MonthfragmentData();
  data->month = String2Int8(row[i++]);
  data->fragmentid = String2Int(row[i++]);
  index_map_.insert(pair<int_8, int>(data->month, monthfragment_data_table_->size()));
  monthfragment_data_table_->push_back(data);
}

