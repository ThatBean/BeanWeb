#ifndef CHECKPOINTMAIN_DATA_TABLE_H
#define CHECKPOINTMAIN_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_checkpoint_data_table.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class CheckpointMainData : public BaseCheckpointData
{
public:
  int           getID() { return id; };
  int           getType() { return 3; };//�����ͼ��ݶ�������Lua:checkpoint_constant
  const string&       getName() { return GetName(); };
  bool          getLocalDropItemData(int index, int& out_id, int& out_count);
  bool          getLocalFirstDropItemData(int index, int& out_id, int& out_count, int& out_type);
  //��ǰ�ؿ��Ѷ�-- 1.��ͨ��
  int           getDifficultyType() { return mDifficultyType; }
public:
  int GetId()
  {
    return id;
  }
  int GetBattlebg()
  {
    return battlebg;
  }
  const string& GetName();
  string& GetIcon()
  {
    return icon;
  }
  string& GetBoss_icon()
  {
    return boss_icon;
  }
  int GetSection()
  {
    return section;
  }
  int GetType()
  {
    return type;
  }
  int GetFrequency()
  {
    return frequency;
  }
  int GetReceivelexp()
  {
    return receivelexp;
  }
  int GetCard_exp()
  {
    return card_exp;
  }
  int GetMoney()
  {
    return money;
  }
  int GetTime()
  {
    return time;
  }
  int GetBgm()
  {
    return bgm;
  }
  int GetCheckpoint_level()
  {
    return checkpoint_level;
  }
  int GetPrev_questid()
  {
    return prev_questid;
  }
  int GetRequire_ap()
  {
    return require_ap;
  }
  int GetMapid()
  {
    return mapid;
  }
  int GetFirst_money()
  {
    return first_money;
  }
  int GetFirst_rank_exp()
  {
    return first_rank_exp;
  }
  int GetFirst_item_type1()
  {
    return mFirstItemsType[0];
  }
  int GetFirst_item_type2()
  {
    return mFirstItemsType[1];
  }
  int GetFirst_item1()
  {
    return mFirstItemsID[0];
  }
  int GetFirst_item2()
  {
    return mFirstItemsID[1];
  }
  int GetFirst_item_count1()
  {
    return mFirstItemsCount[0];
  }
  int GetFirst_item_count2()
  {
    return mFirstItemsCount[1];
  }
  int GetItem_rate1()
  {
    return mItemsRate[0];
  }
  int GetItem_rate2()
  {
    return mItemsRate[1];
  }
  int GetItem_rate3()
  {
    return mItemsRate[2];
  }
  int GetItem_rate4()
  {
    return mItemsRate[3];
  }
  int GetItem_id1()
  {
    return mItemsID[0];
  }
  int GetItem_id2()
  {
    return mItemsID[1];
  }
  int GetItem_id3()
  {
    return mItemsID[2];
  }
  int GetItem_id4()
  {
    return mItemsID[3];
  }
  int GetItem_count1()
  {
    return mItemsCount[0];
  }
  int GetItem_count2()
  {
    return mItemsCount[1];
  }
  int GetItem_count3()
  {
    return mItemsCount[2];
  }
  int GetItem_count4()
  {
    return mItemsCount[3];
  }
  string& GetDetails()
  {
    return Details;
  }
  std::list<int>& GetCp_monster()
  {
	  return cp_monster;
  }
  int GetCp_monster_Num()
  {
	  std::list<int>::iterator itor = cp_monster.begin();
	  int tempIndex = 0;
	  while(itor!=cp_monster.end())
	  {
		  itor++;
		  tempIndex++;
	  } 
	  return tempIndex;
  }
  int getCp_monsterByIndex(int index)
  {
	  std::list<int>::iterator itor = cp_monster.begin();
	  int tempIndex = 0;
	  while(itor!=cp_monster.end())
	  {
		  if(index == tempIndex)
		  {
			  return *itor;
		  }
		  itor++;
		  tempIndex++;
	  } 
	  return NULL;
  }
  string& GetCp_tips()
  {
	  return cp_tips;
  }
private:
  int		id;
  int		battlebg;
  int       section;
  int       type;
  int       frequency;
  int		receivelexp;
  int		card_exp;
  int		money;
  int		time;
  int		bgm;
  int		checkpoint_level;
  int		prev_questid;
  int		require_ap;
  int		mapid;
  int		first_money;
  int		first_rank_exp;
  int   mFirstItemsID[2];
  int   mFirstItemsCount[2];
  int   mFirstItemsType[2];
  int   mItemsRate[4];
  int   mItemsID[4];
  int   mItemsCount[4];
  int   mDifficultyType;
  string		Details;
  string	cp_tips;
  string		name;
  string		icon;
  string		boss_icon;
  std::list<int>	cp_monster;
  friend class CheckpointMainDataTable;
};

class CheckpointMainDataTable
{
public:
  CheckpointMainDataTable();
  ~CheckpointMainDataTable();
  bool InitWithFileName(const char *file_name);
  CheckpointMainData* GetCheckpointmain(int id);

  CheckpointMainData* getCheckpointDataByIndex(int index) { return checkpointmain_data_table_->at(index); }

  CCArray* GetAllCheckpointmainId();
  
protected:
  void parseRow(vector<string> &row);

private:
  vector<CheckpointMainData*> *checkpointmain_data_table_;

  map<int, int> index_map_;
};
#endif
