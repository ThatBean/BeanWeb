#ifndef ACTIVITYNOTIFICATION_DATA_TABLE_H
#define ACTIVITYNOTIFICATION_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class ActivitynotificationData
{
public:

	uint_32 GetId()
	{
		return id;
	}

	string& GetName()
	{
		return name;
	}

	string& GetTitle()
	{
		return title;
	}

	string& GetText()
	{
		return text;
	}

	string& GetLink()
	{
		return link;
	}
private:
	uint_32		id;
	string		name;
	string		title;
	string		text;
	string		link;

	friend class ActivitynotificationDataTable;
};

class ActivitynotificationDataTable
{
public:
	ActivitynotificationDataTable();
	~ActivitynotificationDataTable();
	bool InitWithFileName(const char *file_name);
	ActivitynotificationData* GetActivitynotification(uint_32 id);
	ActivitynotificationData* GetActivitynotificationByIndex(int_32 idx);
	uint_32	GetDataSize() { return index_map_.size(); }

protected:
	void parseRow(vector<string> &row);

private:
	vector<ActivitynotificationData*> *activitynotification_data_table_;

	map<uint_32, int> index_map_;
};
#endif
