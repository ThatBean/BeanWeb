#ifndef PROJECTILES_DATA_TABLE_H
#define PROJECTILES_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class ProjectilesData
{
public:
  /*// name*/
  string GetName()
  {
    return Name;
  }
  /*// res name*/
  string GetExportName()
  {
    return ExportName;
  }
  /*// particle name*/
  string GetParticleEmitter()
  {
    return ParticleEmitter;
  }
  /*// PositionTyped*/
  int GetPositionType()
  {
    return PositionType;
  }
  /*// start height */
//   int GetStartHeight()
//   {
//     return StartHeight;
//   }
  /*// start offset */
//   int GetStartOffset()
//   {
//     return StartOffset;
//   }
  /*// shadow folder*/
  string GetShadowSWF()
  {
    return ShadowSWF;
  }
  /*// shadow res name*/
  string GetShadowExportName()
  {
    return ShadowExportName;
  }
  float GetScale()
  {
    return Scale;
  }
  bool GetIsAlphaBlend()
  {
    return IsAlphaBlend;
  }
private:
  string		Name;
  string		ExportName;
  string		ParticleEmitter;
  int_8		    PositionType;
//   int		StartHeight;
//   int		StartOffset;
  string		ShadowSWF;
  string		ShadowExportName;
  float         Scale;
  bool          IsAlphaBlend;

  friend class ProjectilesDataTable;
};

class ProjectilesDataTable
{
public:
  ProjectilesDataTable();
  ~ProjectilesDataTable();
  bool InitWithFileName(const char *file_name);
  ProjectilesData* GetProjectiles(string name);

protected:
  void parseRow(vector<string> &row);

private:
  vector<ProjectilesData*> *projectiles_data_table_;

  map<string, int> index_map_;
};
#endif
