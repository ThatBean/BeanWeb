#include "cardcapacity_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

CardcapacityDataTable::CardcapacityDataTable()
{
  cardcapacity_data_table_ = new vector<CardcapacityData*>();
}

CardcapacityDataTable::~CardcapacityDataTable()
{
  for (vector<CardcapacityData*>::iterator itr = cardcapacity_data_table_->begin();
  itr != cardcapacity_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete cardcapacity_data_table_;
}

bool CardcapacityDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

CardcapacityData* CardcapacityDataTable::GetCardcapacity(int count)
{
  map<int, int>::iterator index = index_map_.find(count);
  if(index == index_map_.end())
  {
    CCLOG("CardcapacityDataTable TypeId not found! Id: %d", count);
    assert(false);
    return NULL;
  }
  return cardcapacity_data_table_->at(index->second);
}

void CardcapacityDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  CardcapacityData *data = new CardcapacityData();
  data->count = String2Int(row[i++]);
  data->price = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->count, cardcapacity_data_table_->size()));
  cardcapacity_data_table_->push_back(data);
}

