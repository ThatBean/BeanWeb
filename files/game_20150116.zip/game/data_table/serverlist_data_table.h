﻿#ifndef SERVERLIST_DATA_TABLE_H
#define SERVERLIST_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
using namespace std;

/*服务器状态
1.新开服
2.流畅
3.火爆
4.爆满
5.推荐*/
enum eServerState
{
  kServerStateInvalid,
  kServerStateNew,
  kServerStateEmpty,
  kServerStateHot,
  kServerStateHotest,
  kServerStateRecommand
};

enum eServerId
{
  kServerIdInvalid = 0,
  kServerIdDefault = 1
};

class ServerListData
{
public:
  int GetId()
  {
    return id;
  }
  string& GetName()
  {
    return name;
  }
  string& GetIP()
  {
    return IP;
  }
  int GetState()
  {
    return state;
  }
  string& GetGateWayIp()
  {
	  return gateway_ip;
  }
  int GetGatePort()
  {
	  return gateway_port;
  }
  uint_32 GetServerOpenTime()
  {
    return open_server_time;
  }
private:
  int		id;
  string	name;
  string	IP;
  int		state;
  string	gateway_ip;
  int		gateway_port;
  uint_32 open_server_time;
  friend class ServerListDataTable;
  friend class ServerListDataTable3rd;
};

class ServerListDataTable
{
public:
  ServerListDataTable();
  ~ServerListDataTable();
  bool InitWithFileName(const char *file_name);
  ServerListData* GetServerlist(int id);
  int  GetRecommandServerId();
  cocos2d::CCArray* GetServerIdArray();
  void addServerList(int id, string name, string ip,int state,string gateway_ip,int gateway_port,uint_32 open_server_time);

protected:
  void parseRow(vector<string> &row);

private:
  vector<ServerListData*> *serverlist_data_table_;

  map<int, int> index_map_;
};
#endif
