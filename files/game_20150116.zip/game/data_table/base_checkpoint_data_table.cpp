//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: base_checkpoint_data_table.cpp
//        Author: coldouyang
//          Date: 2014/10/28 21:12
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/28      add
//////////////////////////////////////////////////////////////
#include "game/data_table/base_checkpoint_data_table.h"
#include "game/game_manager/data_manager.h"
using namespace std;

void BaseCheckpointDataTable::dump()
{
  std::map<int, BaseCheckpointData*>::iterator it = mDataMap.begin();
  for (; it != mDataMap.end(); ++it)
  {
    //it->second->dump();
  }
}

BaseCheckpointDataTable* BaseCheckpointDataTable::S_ = NULL;

BaseCheckpointDataTable* BaseCheckpointDataTable::GetInstance()
{
  if (!S_)
  {
    S_ = new BaseCheckpointDataTable();
    S_->init();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&S_);
  }
  return S_;
}

BaseCheckpointDataTable::BaseCheckpointDataTable()
{
}

BaseCheckpointDataTable::~BaseCheckpointDataTable()
{
  mDataMap.clear();
}

bool BaseCheckpointDataTable::init()
{
  //ItemlistDataTable* table = DataManager::GetInstance().GetItemlistDataTable();
  //table->GetItemlist()
  return true;
}

void BaseCheckpointDataTable::AddDataToTable(int id, BaseCheckpointData* data)
{
  if (mDataMap.find(id) == mDataMap.end())
  {
    mDataMap.insert(make_pair(id, data));
  }
  else
  {
    assert(false);
  }
}

BaseCheckpointData* BaseCheckpointDataTable::GetDataById(int id)
{
  std::map<int, BaseCheckpointData*>::iterator it = mDataMap.find(id);
  if (it != mDataMap.end())
  {
    return it->second;
  }
  //cocos2d::CCLog("Error BaseResDataTable [id=%d] not find.", id);
  return NULL;
}