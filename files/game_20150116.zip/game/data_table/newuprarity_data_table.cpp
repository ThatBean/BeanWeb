#include "newuprarity_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
NewuprarityDataTable::NewuprarityDataTable()
{
  newuprarity_data_table_ = new vector<NewuprarityData*>();
}

NewuprarityDataTable::~NewuprarityDataTable()
{
  for (vector<NewuprarityData*>::iterator itr = newuprarity_data_table_->begin();
  itr != newuprarity_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete newuprarity_data_table_;
}

bool NewuprarityDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}
 
NewuprarityData* NewuprarityDataTable::GetNewuprarity(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("NewuprarityDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return newuprarity_data_table_->at(index->second);
}

CCArray* NewuprarityDataTable::GetAllNewuprarityId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void NewuprarityDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  NewuprarityData *data = new NewuprarityData();
  data->id = String2Int(row[i++]);
  data->CharacterId = String2Int(row[i++]);
  data->star = String2Int(row[i++]);
  data->CostId1 = String2Int(row[i++]);
  data->CostValue1 = String2Int(row[i++]);
  data->CostId2 = String2Int(row[i++]);
  data->CostValue2 = String2Int(row[i++]);
  std::vector<int> temp;
  getIntVectorFromString(row[i++], temp);
  data->PropAdd.push_back(0);
  for (int i = 0; i < temp.size(); ++i)
  {
    data->PropAdd.push_back(temp.at(i));
  }

  index_map_.insert(pair<int, int>(data->id, newuprarity_data_table_->size()));
  newuprarity_data_table_->push_back(data);
}

