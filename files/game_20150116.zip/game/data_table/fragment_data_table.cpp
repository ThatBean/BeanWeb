#include "fragment_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"
#include "language_data_table.h"
#include <cocos2d.h>

int FragmentData::getUserHoldCount()
{
  data::FragmentInfo* info = DataManager::GetInstance().user_info()->GetFragmentInfoById(fragmentid);
  if (info)
  {
    return info->GetFragmentCount();
  }
  return 0;
}

FragmentDataTable::FragmentDataTable()
{
  fragment_data_table_ = new vector<FragmentData*>();
  target_card_list_.clear();
}

FragmentDataTable::~FragmentDataTable()
{
  for (vector<FragmentData*>::iterator itr = fragment_data_table_->begin();
  itr != fragment_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete fragment_data_table_;
  target_card_list_.clear();
}

bool FragmentDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

FragmentData* FragmentDataTable::GetFragment(int fragmentid)
{
  map<int, int>::iterator index = index_map_.find(fragmentid);
  if(index == index_map_.end())
  {
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(true);
    cocos2d::CCLog("FragmentDataTable TypeId not found! Id: %d", fragmentid);
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(false);
    assert(false);
    return NULL;
  }
  return fragment_data_table_->at(index->second);
}

int FragmentDataTable::GetFragmentIDByCardID(int card_id)
{
   map<int, int>::iterator fragmentIter = target_card_list_.find(card_id);
   if (fragmentIter == target_card_list_.end())
   {
     cocos2d::CCLog("find card fragment by card id %d failed!",card_id);
     //assert(false);
     return 0;
   }
   return fragmentIter->second;
}

void FragmentDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  FragmentData *data = new FragmentData();
  data->fragmentid = String2Int(row[i++]);
  data->fragmentname = LanguageDataTable::FormatLanguageKey("fragment", "fragmentname", data->fragmentid);//row[i++];
  i++;
  data->fragmenticon = row[i++];
  data->fragmenttype = String2Int(row[i++]);
  data->fragmentquality = String2Int(row[i++]);
  data->fragmentcounts = String2Int(row[i++]);
  data->targetid = String2Int(row[i++]);
  data->canSold = String2Bool(row[i++]);
  data->soldPrice = String2Int(row[i++]);
  getIntListFromString(row[i++], data->checkpointid);
  data->fragment_tips = row[i++];
  
  data->fragment_desc = LanguageDataTable::FormatLanguageKey("fragment", "desc", data->fragmentid);//row[i++];
  i++;
  //data->fragment_desc = row[i++];

  index_map_.insert(pair<int, int>(data->fragmentid, fragment_data_table_->size()));
  fragment_data_table_->push_back(data);
  BaseResDataTable::GetInstance()->AddResDataToTable(data->fragmentid, data);
  target_card_list_.insert(pair<int,int>(data->targetid,data->fragmentid));
}

const string& FragmentData::GetFragmentname()
{
  return LanguageDataTable::GetInstance()->GetLanguage(fragmentname);
}

const string& FragmentData::GetFragmentDesc()
{
  return LanguageDataTable::GetInstance()->GetLanguage(fragment_desc);
}