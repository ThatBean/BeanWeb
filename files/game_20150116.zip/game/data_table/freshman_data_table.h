﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: freshman_data_table.h
//        Author: Dylan.gu
//          Date: 2014/3/31 16:28
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/3/31      add
//////////////////////////////////////////////////////////////

#ifndef FRESHMAN_DATA_TABLE_H
#define FRESHMAN_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class FreshmanData
{
public:
  /*;剧情ID*/
  uint_32 GetStoryID()
  {
    return storyID;
  }
  /*UI类型 分为0,1  1表示不可以点穿*/
  uint_8 GetUIType()
  {
    return ui_type;
  }
  /*头像位置，分为0,1,2*/
  uint_8 GetPosition()
  {
    return position;
  }
  /*对话的人物头像ID，特殊符号表示“黑幕”*/
  uint_32 GetCid()
  {
    return cid;
  }
  /*对话人物半身像图片路径*/
  string& GetPNGPath()
  {
    return png_path;
  }
  /*台词*/
  const string& GetDialogue();
private:
  uint_32		storyID;
  uint_8        ui_type;
  uint_8		position;
  uint_32		cid;
  string        png_path;
  string		dialogue;

  friend class FreshmanDataTable;
};

typedef  vector<FreshmanData*> freshman_data_list;
typedef freshman_data_list::iterator freshman_data_list_setit_t;

class FreshmanDataTable
{
public:
  FreshmanDataTable();
  ~FreshmanDataTable();
  bool InitWithFileName(const char *file_name);
  FreshmanData* GetFreshmanData(uint_32 freshman_data_id);
protected:
  void parseRow(vector<string> &row);

private:
  int_32 curr_freshman_data_id_;
  std::map<uint_32,FreshmanData*> *freshman_data_table_;
};
#endif
