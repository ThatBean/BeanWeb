﻿#include "drama_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "language_drama_data_table.h"
#include <cocos2d.h>

/*台词*/
string& DramaData::GetDialogue()
{
  return LanguageDramaDataTable::GetInstance()->GetLanguage(dialogue);
}

DramaDataTable::DramaDataTable()
{
  drama_data_table_ = new vector<DramaData*>();
}

DramaDataTable::~DramaDataTable()
{
  for (vector<DramaData*>::iterator itr = drama_data_table_->begin();
  itr != drama_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete drama_data_table_;
}

bool DramaDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  CCLOG("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

DramaData* DramaDataTable::GetDrama(uint_32 dramaid, uint_32 nodeid)
{
  map<uint_32, drama_list>::iterator iter = index_map_.find(dramaid);
  if(iter == index_map_.end())
  {
    CCLOG("DramaDataTable TypeId not found! TypeId: %d", dramaid);
    assert(false);
    return NULL;
  }
  drama_list* drama_list_temp = &(iter->second);
  if ( nodeid > drama_list_temp->size() ) 
  {
    return NULL;
  }
  return drama_list_temp->at(nodeid);
}

void DramaDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  bool is_new = false;
  DramaData *data = new DramaData();
  data->id = String2UInt32(row[i++]);
  data->dramaID = String2UInt32(row[i++]);
  drama_list* drama_list_tmp; 
  if ( data->dramaID != curr_drama_id_ ) 
  {
    curr_drama_id_ = data->dramaID;
    curr_drama_node_id_ = 0;
    drama_list new_list;;
    index_map_.insert(pair<uint_32, drama_list>(data->dramaID, new_list));
  }

  map<uint_32, drama_list>::iterator index = index_map_.find(data->dramaID);
  if(index == index_map_.end())
  {
    return;
  }
  drama_list_tmp = &(index->second);  
  data->checkpointID = String2UInt32(row[i++]);
  data->type = String2UInt8(row[i++]);
  data->position = String2UInt8(row[i++]);
  data->cid = String2UInt32(row[i++]);
  data->name = row[i++];
  data->dialogue = LanguageDramaDataTable::FormatLanguageKey("drama", "dialogue", data->id);//row[i++];
  i++;
  data->music = String2UInt32(row[i++]);
  data->scene = row[i++];
  data->shake = String2Bool(row[i++]);
  drama_list_tmp->push_back(data);

}

uint_32 DramaDataTable::GetDramaCount( uint_32 dramaid )
{
  map<uint_32, drama_list>::iterator iter = index_map_.find(dramaid);
  if(iter == index_map_.end())
  {
    CCAssert(false, "DramaDataTable TypeId not found!");
    return 0;
  }
  drama_list* drama_list_temp = &(iter->second);
  return drama_list_temp->size();
}

uint_32 DramaDataTable::GetTalkIDByCheckPointID( uint_32 checkpoint_id, bool is_start )
{
  map<uint_32, drama_list>::iterator iter = index_map_.begin();
  for (; iter != index_map_.end(); ++iter)
  {
    drama_list* drama_list_temp = &(iter->second);
    DramaData *data = drama_list_temp->at(0);

    if (data->GetCheckpointID() == checkpoint_id && (data->GetType()?true:false) != is_start) 
    {
      return data->GetDramaID();
    }
  }
  return 0;
}
