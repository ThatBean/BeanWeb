﻿#include "activity_level_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

ActivityLevelDataTable::ActivityLevelDataTable()
{
  activity_level_data_table_ = new vector<ActivityLevelData*>();
}

ActivityLevelDataTable::~ActivityLevelDataTable()
{
  for (vector<ActivityLevelData*>::iterator itr = activity_level_data_table_->begin();
    itr != activity_level_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete activity_level_data_table_;
}

bool ActivityLevelDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ActivityLevelData* ActivityLevelDataTable::GetActivityLevelData(uint_16 id)
{
  map<uint_16, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("ActivityDataTable ID not found! ID: %d", id);
    assert(false);
    return NULL;
  }
  return activity_level_data_table_->at(index->second);
}

void ActivityLevelDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ActivityLevelData *data = new ActivityLevelData();
  data->id = String2UInt16(row[i++]);
  data->level = String2UInt16(row[i++]);
  data->activity_level_items[0].itemId = String2UInt32(row[i++]);
  data->activity_level_items[1].itemId = String2UInt32(row[i++]);
  data->activity_level_items[2].itemId = String2UInt32(row[i++]);
  data->activity_level_items[3].itemId = String2UInt32(row[i++]);
  data->activity_level_items[0].itemCount = String2UInt32(row[i++]);
  data->activity_level_items[1].itemCount = String2UInt32(row[i++]);
  data->activity_level_items[2].itemCount = String2UInt32(row[i++]);
  data->activity_level_items[3].itemCount = String2UInt32(row[i++]);

  index_map_.insert(pair<uint_16, int>(data->id, activity_level_data_table_->size()));
  activity_level_data_table_->push_back(data);
}