//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: shop_data_table.cpp
//        Author: coldouyang
//          Date: 2014/7/9 21:28
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/9      add
//////////////////////////////////////////////////////////////
#include "shop_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include "game/game_manager/data_manager.h"
#include <cocos2d.h>

ShopDataTable::ShopDataTable()
{
  shop_data_table_ = new vector<ShopData*>();
  shopShowItemCount = 0;
}

ShopDataTable::~ShopDataTable()
{
  for (vector<ShopData*>::iterator itr = shop_data_table_->begin();
    itr != shop_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete shop_data_table_;
}

bool ShopDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ShopData* ShopDataTable::GetShopById(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("ShopData TypeId not found! TypeId: %d", id);
    assert(false);
    return NULL;
  }
  return shop_data_table_->at(index->second);
}

ShopData* ShopDataTable::GetShopByIndex(int index)
{
  assert(index < shop_data_table_->size());
  return shop_data_table_->at(index);
}

int ShopDataTable::getShopDataIdByItemId(int item_id)
{
  std::map<int,int>::iterator it = itemID2ShopDataID_map.find(item_id);
  if (it == itemID2ShopDataID_map.end())
  {
    CCLog("ERROR : not shopdata for item %d", item_id);
    //assert(false);
    return 0;
  }
  return it->second;
}

int ShopDataTable::GetAllShopDataCount()
{
	if(shopShowItemCount != 0)
	{
		return shopShowItemCount;
	}
	std::vector<ShopData*>::iterator it;
	for(it = shop_data_table_->begin(); it != shop_data_table_->end(); it++)
	{
		if((*it)->getFuncType() == 1)
			shopShowItemCount++;
	}
	return shopShowItemCount;
}

void ShopDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ShopData *data = new ShopData();
//  id	name	itemType	limitType	limitCount	buycount itemId	icon	type	desc	goodsDesc	cashType	cashCount	sale	startTime	endTime
  data->limitCount = 0;//just for init...
  data->mMinVipLimit = -1;

  data->id = String2Int(row[i++]); 
  data->name = LanguageDataTable::FormatLanguageKey("shop", "name", data->id);//row[i++];
  //data->name = row[i++];
  ++i;
	
  data->functype = String2Int(row[i++]);

  data->itemType = String2Int(row[i++]);
  data->limitType = String2Int(row[i++]);
  data->limitCount = String2Int(row[i++]);
  data->buyCount = row[i++];
  data->itemId = String2Int(row[i++]);
  data->itemCount = String2Int(row[i++]);
  data->icon = row[i++];
  data->type = row[i++];
  data->desc = row[i++];
  i++;
  data->cashType = String2Int(row[i++]);
  data->cashCount = String2Int(row[i++]);
  data->cashAdd = String2Int(row[i++]);
  data->cashMax = String2Int(row[i++]);
  data->sale = String2Int(row[i++]);
  i++;//starttime
  i++;//endtime
  data->showType = String2Int(row[i++]);
  //----------------
  data->buildShopData();
  //----------------
  index_map_.insert(pair<int, int>(data->id, shop_data_table_->size()));
  itemID2ShopDataID_map.insert(pair<int, int>(data->itemId, data->id));
  shop_data_table_->push_back(data);
}

const string& ShopData::getName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}

void ShopData::buildShopData()
{
  mUseCount = 0;
  switch(limitType)
  {
  case 1:
    limitCount = -1;
    break;
  case 2:
    limitCount = -1;
    break;
  case 3:
    limitCount = -1;
    break;
  case 4:
    {
      int vip_level = DataManager::GetInstance().user_info()->vip();
      VipData* data = DataManager::GetInstance().GetVipDataTable()->GetVip(vip_level);
      limitCount = data->GetLimitCountByField(buyCount);
    }
    break;
  case 5:
    //--
    {
      int vip_level = DataManager::GetInstance().user_info()->vip();
      VipData* data = DataManager::GetInstance().GetVipDataTable()->GetVip(vip_level);
      limitCount = data->GetLimitCountByField(buyCount);
    }
    break;
  case 6:
    mMinVipLimit = itemId - 23;
    break;
  default:
    break;
  }
}

int ShopData::getLeftCount()
{
  switch(limitType)
  {
    case 1:
      return -1;
    case 2:
      return limitCount - mUseCount;
    case 3:
      return limitCount - mUseCount;
    case 4:
      /*{
        int vipLevel = DataManager::GetInstance().user_info()->vip();
        if (vipLevel < mMinVipLimit)
        {
          return 0;
        }
        if (buyCount.size() > 0)
        {
          VipData* data = DataManager::GetInstance().GetVipDataTable()->GetVip(vipLevel);
          limitCount = data->GetLimitCountByField(buyCount);
        }
        return limitCount - mUseCount;
      }*/
    case 5:
      {
        int vipLevel = DataManager::GetInstance().user_info()->vip();
        if (vipLevel < mMinVipLimit)
        {
          return 0;
        }
        if (buyCount.size() > 0)
        {
          VipData* data = DataManager::GetInstance().GetVipDataTable()->GetVip(vipLevel);
          limitCount = data->GetLimitCountByField(buyCount);
        }
        return limitCount - mUseCount;
      }
    case 6:
      {
		  return limitCount - mUseCount;
        /*int vipLevel = DataManager::GetInstance().user_info()->vip();
        if (vipLevel < mMinVipLimit)
        {
          return 0;
        }
        if (buyCount.size() > 0)
        {
          VipData* data = DataManager::GetInstance().GetVipDataTable()->GetVip(vipLevel);
          limitCount = data->GetLimitCountByField(buyCount);
        }
        return limitCount - mUseCount;*/
      }
  }
  return -1;
}

int ShopData::getCoolDownSecond()
{
  return 1000;//TODO
}

int ShopData::getPrice(int hadByTimes)
{
	if(hadByTimes == -1)
	{
		hadByTimes = mUseCount;
	}
	/* if (id == 1000)
	{
	int useCount = mUseCount > 15 ? 15 : mUseCount;
	return sale + useCount * 2;
	}*/
  if (limitType != 5)
  {
    return sale;
  }
  
  int addPrice = (hadByTimes)*cashAdd;
  if(addPrice < 0)
  {
	  addPrice = 0;
  }
  else if(addPrice > cashMax)
  {
	  addPrice = cashMax;
  }
  return sale + addPrice;
}


int ShopData::getPriceMultiple(int times)
{
  int start_count = mUseCount;
  int end_count = mUseCount + times;  // < end_count
  int price_sum = 0;
  int i = 0;
  for (i = start_count; i < end_count; ++i) {
    price_sum += getPrice(i);
    
  }
  return price_sum;
}

void ShopData::SuccessBuyItems(int count)
{
  CCLog("OK!!!!!");
/*
1.itemlist
2.character
3.experiencecard
4.fragment
5.equip
6.pet
7.jewellery
*/
  switch(itemType)
  {
    case 1:
      //--����
      DataManager::GetInstance().user_info()->UpdateItemCountWithType(itemId, itemCount * count);
      break;
    case 2:
      //--�ӹ�
      break;
    case 3:
      //--�ӹ�
      break;
    case 4:
      //��Ƭ
      DataManager::GetInstance().user_info()->AddFragmentToList(itemId, itemCount * count);
      break;
    case 5:
      //--�ӹ�
      break;
    case 6:
      break;
    case 7:
      break;
  }
}
/*
string& ShopDataTable::GetName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}
string& AbilityData::GetText()
{
  return LanguageDataTable::GetInstance()->GetLanguage(text);
}
*/

int ShopData::getShowType()
{
  if (id == 1000)
  {
    return 1000;
  }
  return showType;
}