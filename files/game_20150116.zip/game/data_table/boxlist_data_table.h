#ifndef BOXLIST_DATA_TABLE_H
#define BOXLIST_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

enum 
{
  kMaxBoxItemCount = 5,
};

class BoxlistData
{
public:
  /*物品类型
1.itemlist
2.character
3.experiencecard*/
  int GetItem_type()
  {
    return item_type;
  }
  /*物品id*/
  int GetItem_id()
  {
    return item_id;
  }
  /*物品数量*/
  int GetItem_count()
  {
    return item_count;
  }
private:
  int		item_type;
  int		item_id;
  int		item_count;

  friend class BoxlistDataTable;
};

class BoxlistDataTable
{
public:
  BoxlistDataTable();
  ~BoxlistDataTable();
  bool InitWithFileName(const char *file_name);

  BoxlistData* GetAllBoxlistById(int box_id, int idx);

  CCArray*     GetBoxItemList(int box_id);
  int          GetBoxItemCount(int box_id);
protected:
  void parseRow(vector<string> &row);

private:

  std::map<int, std::vector<BoxlistData*> > boxlist_data_table_;
  int last_box_id_;

};

#endif
