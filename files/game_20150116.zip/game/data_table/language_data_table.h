//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: language_data_table.h
//        Author: coldouyang
//          Date: 2014/7/9 15:02
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/9      add
//////////////////////////////////////////////////////////////

#ifndef LANGUAGE_DATA_TABLE_H
#define LANGUAGE_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"

#include "engine/platform/SingleInstance.h"

using namespace std;

class LanguageDataTable : public SingleInstanceObj
{
public:
  static void ResetLanguageDataTable();
  static LanguageDataTable* GetInstance();
  LanguageDataTable();
  ~LanguageDataTable();
  bool InitWithFileName(const char *file_name);
  const string& GetLanguage(string& key);
  static string FormatLanguageKey(const char* table, const char* field, int id);
protected:
  void parseRow(vector<string> &row);

private:
  string str_temp;
  map<string, string>*  strings_map_;
};

#endif