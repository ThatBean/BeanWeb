﻿#include "freshman_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "language_data_table.h"
#include <cocos2d.h>

FreshmanDataTable::FreshmanDataTable()
{
  freshman_data_table_ = new std::map<uint_32,FreshmanData*>();
}

FreshmanDataTable::~FreshmanDataTable()
{
  for (std::map<uint_32,FreshmanData*>::iterator it = freshman_data_table_->begin();
  it != freshman_data_table_->end(); ++it)
  {
    delete (it->second);
  }
  delete freshman_data_table_;
}

bool FreshmanDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  CCLOG("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

FreshmanData* FreshmanDataTable::GetFreshmanData(uint_32 freshman_data_id)
{
  std::map<uint_32, FreshmanData*>::iterator iter = freshman_data_table_->find(freshman_data_id);
  if(iter == freshman_data_table_->end())
  {
    CCLOG("FreshmanDataTable TypeId not found! TypeId: %d", freshman_data_id);
    assert(false);
    return NULL;
  }
  return (iter->second);
}

void FreshmanDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  bool is_new = false;
  FreshmanData *data = new FreshmanData();
  data->storyID = String2UInt32(row[i++]);
  if ( data->storyID != curr_freshman_data_id_ ) 
  {
    curr_freshman_data_id_ = data->storyID;
  }
  data->ui_type = String2UInt8(row[i++]);
  data->position = String2UInt8(row[i++]);
  data->cid = String2UInt32(row[i++]);
  data->png_path = row[i++];
  data->dialogue = LanguageDataTable::FormatLanguageKey("freshman", "dialogue", data->storyID);//row[i++];
  i++;
  freshman_data_table_->insert(std::make_pair(data->storyID,data));
}

const string& FreshmanData::GetDialogue()
{
  return LanguageDataTable::GetInstance()->GetLanguage(dialogue);
}