//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: data_constant.h
//        Author: coldouyang
//          Date: 2014/7/28 11:13
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/28      add
//////////////////////////////////////////////////////////////

#ifndef DATA_CONSTANT_H
#define DATA_CONSTANT_H

enum ItemsType
{
  kNormalItemType = 1,
  kCharacterType = 2,
  kExpCardType = 3,
  kFragmentType = 4,
  kEquipmentType = 5,
  kPetType = 6,
  kJewelleryType = 7
};

enum AttrType
{
  /*
 0��
 1HP
 2�﹥
 3����
 4����
 5����
 6����
 7����
 8���
 9����
 10����
 11�շ�
 12������
 13��Ѫ
 14����
 15ħ��
 16����
 17��͸
 18����
 19�غϻ�Ѫ
 20�غϻ���
 21նɱ
 */
  kAttrTypeNull = 0,
  kAttrTypeHp,
  kAttrTypePhyAtk,
  kAttrTypeMagAtk,
  kAttrTypeHitRate,
  kAttrTypeDodgeRate,
  kAttrTypeCritRate,
  kAttrTypeCritDamage,
  kAttrTypePDef,
  kAttrTypeMDef,
  kAttrTypeFDamage,
  kAttrTypeFUnDamage,
  kAttrTypeBeHeal,
  kAttrTypeSuck,
  kAttrTypePhyImmune,
  kAttrTypeMagImmune,
  kAttrTypeBounce,
  kAttrTypeThrough,
  kAttrTypeSpurting,
  kAttrTypeEachRoundAddHp,
  kAttrTypeEachRoundAddSp,
  kAttrTypeExecute,
  kAttrTypeMax
};
#endif