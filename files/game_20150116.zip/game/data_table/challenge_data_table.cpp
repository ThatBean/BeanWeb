#include "challenge_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
ChallengeDataTable::ChallengeDataTable()
{
	challenge_data_table_ = new vector<ChallengeData*>();
}

ChallengeDataTable::~ChallengeDataTable()
{
	for (vector<ChallengeData*>::iterator itr = challenge_data_table_->begin();
		itr != challenge_data_table_->end(); ++itr)
	{
		delete *itr;
	}
	delete challenge_data_table_;
}

bool ChallengeDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;
	cocos2d::CCLog("Loading csv file %s", file_name);

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}

ChallengeData* ChallengeDataTable::GetChallengeData(int id)
{
	map<int, int>::iterator index = index_map_.find(id);
	if(index == index_map_.end())
	{
		CCLOG("ChallengeDataTable TypeId not found! Id: %d", id);
		assert(false);
		return NULL;
	}
	return challenge_data_table_->at(index->second);
}

CCArray* ChallengeDataTable::GetAllChallengeId()
{
	CCArray* res_arr = CCArray::create();
	for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
	{
		CCInteger* obj_var = CCInteger::create(it->first);
		res_arr->addObject(obj_var);
	}
	return res_arr;
}



int ChallengeDataTable::getChallengeAllCount()
{
	int count = GetAllChallengeId()->count();
	return count;
}

void ChallengeDataTable::parseRow(vector<string> &row)
{
	int i = 0;
	ChallengeData *data = new ChallengeData();
	data->id = String2Int(row[i++]);
	data->level = String2Int(row[i++]);
	data->reqMissionId = String2Int(row[i++]);
	data->desc	=LanguageDataTable::FormatLanguageKey("challenge", "desc", data->id); //row[i++];
	i++;
	data->type  = String2Int(row[i++]);
	data->condition = String2Int(row[i++]);
	data->count  = String2Int(row[i++]);
	data->exp	 = String2Int(row[i++]);
	data->rewardItemId1  = String2Int(row[i++]);
	data->rewardItemCount1  = String2Int(row[i++]);
	data->rewardItemId2  = String2Int(row[i++]);
	data->rewardItemCount2  = String2Int(row[i++]);
	
	index_map_.insert(pair<int, int>(data->id, challenge_data_table_->size()));
	challenge_data_table_->push_back(data);
}

const string& ChallengeData::GetDesc()
{
	return  LanguageDataTable::GetInstance()->GetLanguage(desc);
}

