#ifndef EVOLVE_DATA_TABLE_H
#define EVOLVE_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class EvolveData
{
public:
  int GetId()
  {
    return Id;
  }
  int GetCardId()
  {
    return CardId;
  }
  int GetStepId()
  {
    return StepId;
  }
  std::list<int>& GetEquipIDs()
  {
    return equipIDs;
  }
  int GetEquipIDByIndex(int index)
  {	  
    std::list<int>::iterator itor = equipIDs.begin();
    int tempIndex = 0;
    while(itor!=equipIDs.end())
    {
      if(index == tempIndex)
      {
        return *itor;
      }
      itor++;
      tempIndex++;
    } 
    return 0;
  }
  CCArray* GetEquipID_List()
  {
    CCArray* res_arr = CCArray::create();
    for(std::list<int>::iterator it =  equipIDs.begin(); it !=equipIDs.end(); ++it)
    {
      CCInteger* obj_var = CCInteger::create(*it);
      res_arr->addObject(obj_var);
    }
    return res_arr;
  }
  std::vector<int>& GetPropAdd()
  {
    return propAdd;
  }
private:
  int		Id;
  int		CardId;
  int		StepId;
  std::list<int>		equipIDs;
  std::vector<int>		propAdd;

  friend class EvolveDataTable;
};

class EvolveDataTable
{
public:
  EvolveDataTable();
  ~EvolveDataTable();
  bool InitWithFileName(const char *file_name);
  EvolveData* GetEvolve(int id);

  CCArray* GetAllEvolveId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<EvolveData*> *evolve_data_table_;

  map<int, int> index_map_;
};
#endif
