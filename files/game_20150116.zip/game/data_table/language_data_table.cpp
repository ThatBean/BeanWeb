//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: language.cpp
//        Author: coldouyang
//          Date: 2014/7/9 14:59
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/9      add
//////////////////////////////////////////////////////////////
#include "language_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/data_manager.h"
#include <cocos2d.h>

static LanguageDataTable* _S_ = NULL;

LanguageDataTable* LanguageDataTable::GetInstance()
{
  if(!_S_)
  {
    _S_ = DataManager::GetInstance().GetLanguageDataTable();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&_S_);
  }
  return _S_;
}

void LanguageDataTable::ResetLanguageDataTable()
{
  _S_ = NULL;
}

LanguageDataTable::LanguageDataTable()
{
  strings_map_ = new map<string, string>();
}

LanguageDataTable::~LanguageDataTable()
{
  if (strings_map_)
  {
    strings_map_->clear();
  }
  delete strings_map_;
}

string LanguageDataTable::FormatLanguageKey(const char* table, const char* field, int id)
{
  string result;
  char buff[64];
  sprintf(buff, "%s_%s_%d", table, field, id);  
  result = buff;
  return result;
}

bool LanguageDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }
  return true;
}

const string& LanguageDataTable::GetLanguage(string& key)
{ 
  map<string, string>::iterator it = strings_map_->find(key);
  if (it == strings_map_->end())
  {
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(true);
    cocos2d::CCLog("ERROR Language not find key=%s", key.c_str());
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(false);
    //assert(false);
    return str_temp;
  }
  return it->second;
}

void LanguageDataTable::parseRow(vector<string> &row)
{
  int keyIndex = 0;
  int valueIndex = 1;
  switch (DataManager::getCurrentLanguageType())  
  {  
  case kLanguageEnglish:  
    valueIndex = 3;  
    break;  
  case kLanguageChinese:
    valueIndex = 1;  
    break;  
  case kLanguageFrench:  
    break;  
  case kLanguageGerman:  
    break;
  case kLanguageItalian:  
    break;
  case kLanguageRussian:  
    break;
  case kLanguageSpanish:   
    break;
  case kLanguageKorean:
    valueIndex = 2;
    break;  
  }
  string key = row[keyIndex];
  string value_cn = row[valueIndex];
  strings_map_->insert(std::make_pair(key, value_cn));
}

