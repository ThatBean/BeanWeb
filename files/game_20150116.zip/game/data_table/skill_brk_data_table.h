﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skill_brk_data_table.h
//        Author: robbiepan
//          Date: 2013/9/17 15:49
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/17      add
//////////////////////////////////////////////////////////////

#ifndef SKILL_BRK_DATA_TABLE_H
#define SKILL_BRK_DATA_TABLE_H

#include "engine/base/basictypes.h"
#include "game/skill/skill_constants.h"
using namespace std;



//定义的是一些,所有的MAGIC_BREAK共用的数据
struct skillBreakBase
{
  int_32			attr_id;           // 属性
  int_32		    o_x,o_y;       // 整个技能炸开效果的座标偏差

  skillBreakSet_t   skill_break_list;
};

class SkillBrkDataTable
{
public:
  SkillBrkDataTable();
  ~SkillBrkDataTable();
  bool InitWithFileName(const char *file_name);
  skillBreakBase* GetSkillBrk(int_32 id);
  skillBreakBase* TryGetSkillBrk(int_32 id);

protected:
  void parseRow(vector<string> &row);

private:
  skillBreakBase *skill_brk_data_table_[MAX_SKILL_BREAK];

  int_32          break_id_;
};
#endif
