#include "checkpointcha_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
CheckpointChaDataTable::CheckpointChaDataTable()
{
  checkpointcha_data_table_ = new vector<CheckpointChaData*>();
}

CheckpointChaDataTable::~CheckpointChaDataTable()
{
  for (vector<CheckpointChaData*>::iterator itr = checkpointcha_data_table_->begin();
  itr != checkpointcha_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete checkpointcha_data_table_;
}

bool CheckpointChaDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

CheckpointChaData* CheckpointChaDataTable::GetCheckpointcha(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("CheckpointChaDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return checkpointcha_data_table_->at(index->second);
}

CCArray* CheckpointChaDataTable::GetAllCheckpointchaId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void CheckpointChaDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  CheckpointChaData *data = new CheckpointChaData();
  data->id = String2Int(row[i++]);
  data->battlebg = String2Int(row[i++]);
  data->name = row[i++];
  data->receivelexp = String2Int(row[i++]);
  data->card_exp = String2Int(row[i++]);
  data->money = String2Int(row[i++]);
  data->time = String2Int(row[i++]);
  data->still = String2Int(row[i++]);
  data->bgm = String2Int(row[i++]);
  data->cid1 = String2Int(row[i++]);
  data->cid2 = String2Int(row[i++]);
  data->card_level1 = String2Int(row[i++]);
  data->card_level2 = String2Int(row[i++]);
  data->prev_id = String2Int(row[i++]);
  data->checkpoint_level = String2Int(row[i++]);
  data->require_ap = String2Int(row[i++]);
  data->item_rate1 = String2Int(row[i++]);
  data->item_rate2 = String2Int(row[i++]);
  data->item_rate3 = String2Int(row[i++]);
  data->item_rate4 = String2Int(row[i++]);
  data->item_type1 = String2Int(row[i++]);
  data->item_type2 = String2Int(row[i++]);
  data->item_type3 = String2Int(row[i++]);
  data->item_type4 = String2Int(row[i++]);
  data->item_id1 = String2Int(row[i++]);
  data->item_id2 = String2Int(row[i++]);
  data->item_id3 = String2Int(row[i++]);
  data->item_id4 = String2Int(row[i++]);
  data->item_count1 = String2Int(row[i++]);
  data->item_count2 = String2Int(row[i++]);
  data->item_count3 = String2Int(row[i++]);
  data->item_count4 = String2Int(row[i++]);
  data->Details = row[i++];
  index_map_.insert(pair<int, int>(data->id, checkpointcha_data_table_->size()));
  checkpointcha_data_table_->push_back(data);
}

