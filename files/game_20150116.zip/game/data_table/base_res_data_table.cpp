//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: base_res_data_table.cpp
//        Author: coldouyang
//          Date: 2014/7/24 14:13
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/24      add
//////////////////////////////////////////////////////////////
#include "game/data_table/base_res_data_table.h"
#include "game/data_table/itemlist_data_table.h"
#include "game/game_manager/data_manager.h"

using namespace std;

const string& BaseResData::getFullIconPath()
{
  switch(getType())
  {
    case kEquipmentType:
    case kFragmentType:
    case kNormalItemType:
    {
      if (res_icon_full_path_.empty())
      {
         res_icon_full_path_ = getIconName();
         res_icon_full_path_ += ".png";
      }
      return res_icon_full_path_;
    }
    case kExpCardType:
    case kCharacterType:
    {
      if (res_icon_full_path_.empty())
      {
        res_icon_full_path_ = "textures/card_info/";
        res_icon_full_path_ += getIconName();
      }
      return res_icon_full_path_;
    }
  }
  return res_icon_full_path_;
}

void BaseResData::dump()
{
  cocos2d::CCLog("id:%d, name:%s, type:%d, icon:%s, fullIcon:[%s]", getID(), getName().c_str(), getType(), getIconName().c_str(), getFullIconPath().c_str());
}

void BaseResDataTable::dump()
{
  std::map<int, BaseResData*>::iterator it = mDataMap.begin();
  for (; it != mDataMap.end(); ++it)
  {
    it->second->dump();
  }
}

BaseResDataTable* BaseResDataTable::S_ = NULL;

BaseResDataTable* BaseResDataTable::GetInstance()
{
  if (!S_)
  {
    S_ = new BaseResDataTable();
    S_->init();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&S_);
  }
  return S_;
}

BaseResDataTable::BaseResDataTable()
{
}

BaseResDataTable::~BaseResDataTable()
{
  mDataMap.clear();
}

bool BaseResDataTable::init()
{
  //ItemlistDataTable* table = DataManager::GetInstance().GetItemlistDataTable();
  //table->GetItemlist()
  return true;
}

void BaseResDataTable::AddResDataToTable(int id, BaseResData* data)
{
  if (mDataMap.find(id) == mDataMap.end())
  {
    mDataMap.insert(make_pair(id, data));
  }
  else
  {
    assert(false);
  }
}

BaseResData* BaseResDataTable::GetResDataById(int id)
{
  std::map<int, BaseResData*>::iterator it = mDataMap.find(id);
  if (it != mDataMap.end())
  {
    return it->second;
  }
  //cocos2d::CCLog("Error BaseResDataTable [id=%d] not find.", id);
  return NULL;
}

