//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: flop_data_table.cpp
//        Author: coldouyang
//          Date: 2014/5/15 11:23
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/5/15      add
//////////////////////////////////////////////////////////////

#include "flop_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

FlopDataTable::FlopDataTable()
{
  buff_data_table_ = new vector<FlopData*>();
}

FlopDataTable::~FlopDataTable()
{
  for (vector<FlopData*>::iterator itr = buff_data_table_->begin();
    itr != buff_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete buff_data_table_;
}

bool FlopDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

FlopData* FlopDataTable::GetBuff(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    cocos2d::CCLog("FlopDataTable Id not found!! Id: %d", id);
    assert(false);
    return NULL;
  }
  return buff_data_table_->at(index->second);
}

void FlopDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  FlopData *data = new FlopData();
  data->id = String2Int8(row[i++]);
  data->itemType = String2Int8(row[i++]);
  data->itemID = String2UInt32(row[i++]);
  data->name = row[i++];
  data->itemCount = String2UInt32(row[i++]);
  data->extractionRate = String2Int8(row[i++]);
  data->getRate = String2UInt32(row[i++]);
  data->min = String2Int8(row[i++]);
  data->max = String2Int8(row[i++]);
  index_map_.insert(pair<int, int>(data->id, buff_data_table_->size()));
  buff_data_table_->push_back(data);
}