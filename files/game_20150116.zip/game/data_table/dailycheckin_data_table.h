﻿#ifndef DAILYCHECKIN_DATA_TABLE_H
#define DAILYCHECKIN_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class DailycheckinData
{
public:
  /*;天数*/
  int_8 GetDayth()
  {
    return dayth;
  }
  /*奖励物品ID*/
  int GetItemid()
  {
    return itemid;
  }
  /*数量*/
  int GetCount1()
  {
    return count1;
  }
  /*exp数量*/
  int GetExp()
  {
    return exp;
  }
  /*vip双倍*/
  bool GetIs_vip()
  {
    return is_vip;
  }
  /*特殊物品*/
  bool GetIs_special()
  {
    return is_special;
  }
private:
  int_8		dayth;
  int		itemid;
  int		count1;
  int		exp;
  bool		is_vip;
  bool		is_special;

  friend class DailycheckinDataTable;
};

class DailycheckinDataTable
{
public:
  DailycheckinDataTable();
  ~DailycheckinDataTable();
  bool InitWithFileName(const char *file_name);
  DailycheckinData* GetDailycheckin(int_8 dayth);

  CCArray* GetAllDailycheckinId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<DailycheckinData*> *dailycheckin_data_table_;

  map<int_8, int> index_map_;
};
#endif
