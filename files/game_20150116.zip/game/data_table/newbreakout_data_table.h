#ifndef NEWBREAKOUT_DATA_TABLE_H
#define NEWBREAKOUT_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class NewbreakoutData
{
public:
  /*���*/
  int GetId()
  {
    return id;
  }
  /*ͻ�ƿ���id*/
  int GetCharacterId()
  {
    return CharacterId;
  }
  /*��ǰͻ�Ƶȼ�*/
  int GetStar()
  {
    return star;
  }
  /*ͻ������id*/
  int GetCostId1()
  {
    return CostId1;
  }
  /*ͻ����������*/
  int GetCostValue1()
  {
    return CostValue1;
  }
  /*ͻ��������*/
  int GetNeedExp()
  {
    return needExp;
  }
  /*ͻ����������*/
  std::list<int>& GetPropAdd()
  {
    return PropAdd;
  }
private:
  int		id;
  int		CharacterId;
  int		star;
  int		CostId1;
  int		CostValue1;
  int		needExp;
  std::list<int>		PropAdd;

  friend class NewbreakoutDataTable;
};

class NewbreakoutDataTable
{
public:
  NewbreakoutDataTable();
  ~NewbreakoutDataTable();
  bool InitWithFileName(const char *file_name);
  NewbreakoutData* GetNewbreakout(int id);

  CCArray* GetAllNewbreakoutId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<NewbreakoutData*> *newbreakout_data_table_;

  map<int, int> index_map_;
};
#endif
