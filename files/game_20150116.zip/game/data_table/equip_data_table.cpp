#include "equip_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"

int EquipData::getUserHoldCount()
{
  return DataManager::GetInstance().user_info()->GetEquipCountByID(equipId);
}

EquipDataTable::EquipDataTable()
{
  equip_data_table_ = new vector<EquipData*>();
}

EquipDataTable::~EquipDataTable()
{
  for (vector<EquipData*>::iterator itr = equip_data_table_->begin();
  itr != equip_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete equip_data_table_;
}

bool EquipDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }
  return true;
}

EquipData* EquipDataTable::GetEquip(int equipid)
{
  map<int, int>::iterator index = index_map_.find(equipid);
  if(index == index_map_.end())
  {
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(true);
    CCLOG("EquipDataTable TypeId not found! Id: %d", equipid);
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(false);
    assert(false);
    return NULL;
  }
  return equip_data_table_->at(index->second);
}

CCArray* EquipDataTable::GetAllEquipId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void EquipDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  EquipData *data = new EquipData();
  data->equipId = String2Int(row[i++]);
  data->icon = row[i++];
  data->name = LanguageDataTable::FormatLanguageKey("equip", "name", data->equipId);//row[i++];
  i++;
  data->quality = String2Int(row[i++]);
  data->EquipFlag1 = String2Int(row[i++]);
  data->flag1Value = String2Float(row[i++]);
  data->EquipFlag2 = String2Int(row[i++]);
  data->flag2Value = String2Float(row[i++]);
  data->EquipFlag3 = String2Int(row[i++]);
  data->flag3Value = String2Float(row[i++]);
  data->EquipFlag4 = String2Int(row[i++]);
  data->flag4Value = String2Float(row[i++]);
  data->EquipFlag5 = String2Int(row[i++]);
  data->flag5Value = String2Float(row[i++]);
  data->IsSold = String2Bool(row[i++]);
  data->soldMoney = String2Int(row[i++]);
  data->breakExp = String2Int(row[i++]);
  getIntVectorFromString(row[i++], data->checkpointid);
  data->needLv = String2Int(row[i++]);
  getIntVectorFromString(row[i++], data->fomularEquip);
  /*
  std::list<int> temp;
  temp.clear();
  for(std::list<int>::iterator it =  temp.begin(); it !=temp.end(); ++it)
  {
    data->fomularEquip.push_back(*it);
  }
  */
  index_map_.insert(pair<int, int>(data->equipId, equip_data_table_->size()));
  equip_data_table_->push_back(data);
  BaseResDataTable::GetInstance()->AddResDataToTable(data->equipId, data);
}

const string& EquipData::GetName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}

float EquipData::getPropertyByType( uint_8 property_type )
{
  float result_value = 0;
  if( EquipFlag1 == property_type )
  {
    result_value += flag1Value;
  }
  if( this->GetEquipFlag2() == property_type )
  {
    result_value += flag2Value;
  }
  if( this->GetEquipFlag3() == property_type )
  {
    result_value += flag3Value;
  }
  if( this->GetEquipFlag4() == property_type )
  {
    result_value += flag4Value;
  }
  if( this->GetEquipFlag5() == property_type )
  {
    result_value += flag5Value;
  }
  return result_value;
}
