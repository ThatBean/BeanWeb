﻿#include "itemlist_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

ItemlistDataTable::ItemlistDataTable()
{
  itemlist_data_table_ = new vector<ItemlistData*>();
}

ItemlistDataTable::~ItemlistDataTable()
{
  for (vector<ItemlistData*>::iterator itr = itemlist_data_table_->begin();
  itr != itemlist_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete itemlist_data_table_;
}

bool ItemlistDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ItemlistData* ItemlistDataTable::GetItemlist(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(true);
    CCLOG("ItemlistDataTable TypeId not found! TypeId: %d", id);
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(false);
    assert(false);
    return NULL;
  }
  return itemlist_data_table_->at(index->second);
}

void ItemlistDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ItemlistData *data = new ItemlistData();
  data->id = String2Int(row[i++]);
  data->name = LanguageDataTable::FormatLanguageKey("itemlist", "name", data->id);//row[i++];
  i++;
  data->subtype = String2Int(row[i++]);
  data->use_type = String2Bool(row[i++]);
  data->level = String2Int(row[i++]);
  data->icon = row[i++];
  data->rarity = String2Int(row[i++]);
  data->desc = LanguageDataTable::FormatLanguageKey("itemlist", "desc", data->id);//row[i++];
  i++;
  data->attribute = String2Int(row[i++]);
  data->conditionId = String2Int(row[i++]);
  data->conditionCount = String2Int(row[i++]);
  data->sell = String2Bool(row[i++]);
  data->sellPrice = String2Int(row[i++]);
  data->record = String2Bool(row[i++]);
  data->usedesc = row[i++];
  data->lua = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->id, itemlist_data_table_->size()));
  itemlist_data_table_->push_back(data);
  BaseResDataTable::GetInstance()->AddResDataToTable(data->id, data);
}

const string& ItemlistData::GetName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}

const string& ItemlistData::GetDesc()
{
  return LanguageDataTable::GetInstance()->GetLanguage(desc);
}