#include "newbreakout_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
NewbreakoutDataTable::NewbreakoutDataTable()
{
  newbreakout_data_table_ = new vector<NewbreakoutData*>();
}

NewbreakoutDataTable::~NewbreakoutDataTable()
{
  for (vector<NewbreakoutData*>::iterator itr = newbreakout_data_table_->begin();
  itr != newbreakout_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete newbreakout_data_table_;
}

bool NewbreakoutDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

NewbreakoutData* NewbreakoutDataTable::GetNewbreakout(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("NewbreakoutDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return newbreakout_data_table_->at(index->second);
}

CCArray* NewbreakoutDataTable::GetAllNewbreakoutId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void NewbreakoutDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  NewbreakoutData *data = new NewbreakoutData();
  data->id = String2Int(row[i++]);
  data->CharacterId = String2Int(row[i++]);
  data->star = String2Int(row[i++]);
  data->CostId1 = String2Int(row[i++]);
  data->CostValue1 = String2Int(row[i++]);
  data->needExp = String2Int(row[i++]);
  getIntListFromString(row[i++], data->PropAdd);
  index_map_.insert(pair<int, int>(data->id, newbreakout_data_table_->size()));
  newbreakout_data_table_->push_back(data);
}

