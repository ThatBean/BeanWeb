﻿#ifndef ROLE_DATA_TABLE_H
#define ROLE_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>
#include "game/user_data/user_data_constants.h"

using namespace std;
using namespace cocos2d;

class RoleData
{
public:
  RoleData(){};
  ~RoleData(){};
  int_8 GetID()
  {
    return ID;
  }
  int_32 GetCardID()
  {
    return cid;
  }
  int_8 GetJobType()
  {
    return jobType;
  }
  const string& GetJobText();
  int_8 GetGender()
  {
    return gender;
  }
private:
  int_8		  ID;
  int_32		cid;
  int_8		  jobType;
  string		jobText;
  int_8		  gender;
  friend class RoleDataTable;
};

class RoleDataTable
{
public:
  RoleDataTable();
  ~RoleDataTable();
  bool InitWithFileName(const char *file_name);
  RoleData* GetRole(int_8 id);

  CCArray* GetAllRoleId();
  bool     IsRoleCard(int cardID);
protected:
  void parseRow(vector<string> &row);

private:
  vector<RoleData*> *role_data_table_;

  map<int_8, int> index_map_;
};
#endif
