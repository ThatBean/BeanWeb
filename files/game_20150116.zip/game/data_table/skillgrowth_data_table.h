﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skillgrowth_data_table.h
//        Author: kira
//          Date: 2015/1/14 15:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     kira         2015/1/14      add
//////////////////////////////////////////////////////////////

#ifndef SKILLGROWTH_DATA_TABLE_H
#define SKILLGROWTH_DATA_TABLE_H

#include "engine/base/basictypes.h"
#include "game/skill/skill_constants.h"
using namespace std;

class SkillgrowthData
{
public:
	/*ID*/
	int GetId()
	{
		return id;
	}
	int getCostType()
	{
		return costType;
	}
	int getCostCount()
	{
		return  costCount;
	}
	int getLevelLimit()
	{

		return levellimit;
	}
	string& getSkillIcon()
	{

		return skillIcon;
	}

private:
	int		id;
	int     costType;
	int     costCount;
	int     levellimit;
	string     skillIcon;
	friend class SkillGrowthDataTable;
};

class SkillGrowthDataTable
{
public:
	SkillGrowthDataTable();
	~SkillGrowthDataTable();

	bool InitWithFileName(const char *file_name);
	SkillgrowthData* getSkillGrowth(int id);
protected:
	void parseRow(vector<string> &row);
private:
	vector<SkillgrowthData*> *skillgrowth_data_table_;

	map<int, int> index_map_;
};


#endif

