#ifndef LIMIT_GIFT_TABLE_H
#define LIMIT_GIFT_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class LimitGiftData
{
public:
	/*id*/
	int GetLimitGiftId()
	{
		return id;
	}
	/*Ŀ����������*/
	string GetDesc()
	{
		return desc;
	}
	int getTime()
	{
		return time_h;
	}
	/*��������1�ĵ���id*/
	int getRewardItemId_1()
	{
		return rewardItemId1;
	}
	/*��������2�ĵ���id*/
	int getRewardItemId_2()
	{
		return rewardItemId2;
	}
	/*��������1�ĸ���*/
	int getRewardItemCount_1()
	{
		return rewardItemCount1;
	}
	/*��������2�ĸ���*/
	int getRewardItemCount_2()
	{
		return rewardItemCount2;
	}
private:
	int		id;
	int		addCharge;
	int		time_h;
	string  desc;
	int     rewardItemId1;
	int     rewardItemId2;
	int     rewardItemCount1;
	int     rewardItemCount2;
	friend class LimitGiftDataTable;
};

class LimitGiftDataTable
{
public:
	LimitGiftDataTable();
	~LimitGiftDataTable();
	bool InitWithFileName(const char *file_name);
	LimitGiftData* GetLimitGiftById(int id);
	int getLimitGiftAllCount();

	CCArray* GetAllLimitGiftId();

protected:
	void parseRow(vector<string> &row);

private:
	vector<LimitGiftData*> *limit_gift_data_table_;

	map<int, int> index_map_;
};
#endif
