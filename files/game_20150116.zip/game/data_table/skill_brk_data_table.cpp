﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skillbrk_data_table.cpp
//        Author: robbiepan
//          Date: 2013/9/17 15:49
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/17      add
//////////////////////////////////////////////////////////////

#include "skill_brk_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/battle/tiled_map/map_constants.h"
#include "language_data_table.h"
#include <cocos2d.h>

SkillBrkDataTable::SkillBrkDataTable()
{
  break_id_ = -1;
  memset(skill_brk_data_table_, 0, sizeof(skill_brk_data_table_));
}

SkillBrkDataTable::~SkillBrkDataTable()
{
  for (int i = 0; i < MAX_SKILL_BREAK; ++i)
  {
    if (skill_brk_data_table_[i] != NULL)
    {
      skill_brk_data_table_[i]->skill_break_list.clear();
      SAFE_DEL(skill_brk_data_table_[i]);
    }
  }
}

bool SkillBrkDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

skillBreakBase* SkillBrkDataTable::GetSkillBrk(int_32 id)
{
  CCAssert((id >= 0 && id < MAX_SKILL_BREAK), "skill_break id is unvalued!");
  if (skill_brk_data_table_[id] == NULL)
  {    
    CCLOG("SkillBrkDataTable TypeId not found! TypeId: %ld", id);
    assert(false);
    return NULL;
  }
  return skill_brk_data_table_[id];
}

skillBreakBase* SkillBrkDataTable::TryGetSkillBrk(int_32 id)
{
  if (id < 0 || id >= MAX_SKILL_BREAK || skill_brk_data_table_[id] == NULL)
  {    
    CCLOG("SkillBrkDataTable TypeId not found, TypeId: %ld", id);
    return NULL;
  }
  return skill_brk_data_table_[id];
}

void SkillBrkDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  int_32 type_id = 0;
  
  type_id = String2Int32(row[i++]);
   
  if (type_id != 0) 
  {
    skillBreakBase *data = new skillBreakBase();    
    break_id_ = type_id;
    CCAssert((break_id_ >= 0 && break_id_ < MAX_SKILL_BREAK), "skill_break id is unvalued!");

    data->attr_id = String2Int32(row[i++]);
    data->o_x = String2Int32(row[i++]);
    data->o_y = String2Int32(row[i++]);
    skill_brk_data_table_[break_id_] = data;
  } 
  else if (type_id == 0)
  {
    CCAssert((break_id_ >= 0 && break_id_ < MAX_SKILL_BREAK), "skill_break id is unvalued!");
    skillBreak_t data;
    data.attr_id = String2Int32(row[i++]);
    data.x = String2Int32(row[i++]);
    data.y = String2Int32(row[i++]);
    data.dir = String2Int8(row[i++]);
    data.sleep_time = String2Int32(row[i++]);
    data.survival_time = String2Int32(row[i++]);
    data.move_dist = String2Float(row[i++]) * taomee::battle::kMapTileAverageLength * data.survival_time / 1000;
    data.proc_particle = row[i++];
    data.proc_armature = row[i++];
    data.ending_particle = row[i++];
    data.track = String2Int8(row[i++]);
    data.layer = String2Int8(row[i++]);
    data.is_shake = String2Bool(row[i++]);
    data.sound_id = String2UInt32(row[i++]);
    data.val_proc_unit = String2Int32(row[i++]);
    data.val_proc_count = String2Int8(row[i++]);
    skill_brk_data_table_[break_id_]->skill_break_list.push_back( data );
  }

}

