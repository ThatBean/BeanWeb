#ifndef SOUND_DATA_TABLE_H
#define SOUND_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class SoundData
{
public:
  /*ID*/
  uint_32 GetId()
  {
    return id;
  }
  /*资源名称*/
  string& GetResourceName()
  {
    return resourceName;
  }

private:
  uint_32		id;
  string		resourceName;
 
  friend class SoundDataTable;
};

class SoundDataTable
{
public:
  SoundDataTable();
  ~SoundDataTable();
  bool InitWithFileName(const char *file_name);
  SoundData* GetSound(uint_32 id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<SoundData*> *sound_data_table_;

  map<uint_32, int> index_map_;
};
#endif
