﻿#ifndef VIP_DATA_TABLE_H
#define VIP_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class VipData
{
public:
  /*ID*/
  uint_32 GetId()
  {
    return id;
  }
  /*资源名称*/
  uint_32 GetChargeNum()
  {
    return charge_num;
  }
  /*每天可购买金币次数*/
  int GetLimitbuygold()
  {
    return limitbuygold;
  }
  /*每天可购买黄金宝箱次数*/
  int GetLimitbuygoldbox()
  {
    return limitbuygoldbox;
  }
  /*每天购买三星经验卡次数*/
  int GetLimitbuyexpcard()
  {
    return limitbuyexpcard;
  }
  /*购买体力次数*/
  int GetLimitbuyap()
  {
    return limitbuyap;
  }
  /*购买竞技场次数*/
  int GetLimitbuypvp()
  {
    return limitbuypvp;
  }
  /*神秘商店刷新次数*/
  int GetLimitsecretshop()
  {
    return limitsecretshop;
  }
  /*突破果实次数*/
  int GetLimitBuyFruit()
  {
    return limitbuyfruit;
  }

  /*副本重置次数*/
  int GetPvereset();

  /*可领取7日vip礼包，1标识可以，0为默认不可以*/
  int GetCansevendaysreward()
  {
    return cansevendaysreward;
  }
  /*可购买通天塔门票，1标识可以，0为默认不可以*/
  int GetCanbuygamblingticket()
  {
    return canbuygamblingticket;
  }
  /*可副本自动战斗，1标识可以，0为默认不可以*/
  int GetCanautobattle()
  {
    return canautobattle;
  }
  /*可副本扫荡，1标识可以，0为默认不可以*/
  int GetCanraidbattle()
  {
    return canraidbattle;
  }
  /*精英副本可重置次数*/
  int GetLimitBuyElite()
  {
    return limitbuyelite;
  }
  //--can buy somthing....
  int GetLimitCountByField(std::string& field);

  int GetLuckyStar() { return luckystar; }
private:
  uint_32		id;
  uint_32		charge_num;
  int		limitbuygold;
  int		limitbuygoldbox;
  int		limitbuyexpcard;
  int		limitbuyap;
  int		limitbuypvp;
  int		limitsecretshop;
  int		pvereset;
  int		cansevendaysreward;
  int		canbuygamblingticket;
  int		canautobattle;
  int		canraidbattle;
  int   limitbuyelite;
  int   limitbuyfruit;
  int limitbag;
  int expgift;
  int luckystar;
 
  friend class VipDataTable;
};

class VipDataTable
{
public:
  VipDataTable();
  ~VipDataTable();

  bool InitWithFileName(const char *file_name);
  VipData* GetVip(uint_8 id);

  void     AddVipData(uint_8 id, uint_32 charge);

  int_8    GetVipByCharge(uint_32 charge);

  int getMaxLevel() { return mMaxVipLevel; }
protected:
  void parseRow(vector<string> &row);
private:
  vector<VipData*> *vip_data_table_;

  map<uint_32, int> index_map_;
  int mMaxVipLevel;
};
#endif
