﻿#ifndef FUNCTION_DATA_TABLE_H
#define FUNCTION_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class FunctionData
{
public:
  /*;系统id*/
  int GetId()
  {
    return id;
  }
  /*系统名称*/
  string& GetName()
  {
    return name;
  }
  /*icon*/
  string& GetIcon()
  {
    return icon;
  }
  /*背景图*/
  string& GetBackground()
  {
    return background;
  }
  /*完成任务解锁*/
  int GetQuestId()
  {
    return questId;
  }
  /*达到等级解锁*/
  int GetLevel()
  {
    return level;
  }

  string &GetProfile()
  {
	  return profile;
  }
private:
  int		id;
  string		name;
  string		icon;
  string		background;
  int		questId;
  int		level;
  string	profile;

  friend class FunctionDataTable;
};

class FunctionDataTable
{
public:
  FunctionDataTable();
  ~FunctionDataTable();
  bool InitWithFileName(const char *file_name);
  FunctionData* GetFunction(int id);

  CCArray* GetAllFunctionId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<FunctionData*> *function_data_table_;

  map<int, int> index_map_;
};
#endif
