//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: random_box_map_data_table.h
//        Author: coldouyang
//          Date: 2015/1/6 19:13
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2015/1/6      add
//////////////////////////////////////////////////////////////

#ifndef RANDOM_BOX_MAP_DATA_TABLE_H
#define RANDOM_BOX_MAP_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

#define MAX_RANDOM_BOX_COUNT 5
class RandomBoxMapDataTable;
class RandomBoxMapData
{
public:
  int getID() { return mID; }
  int getMapID() { return mMapID; }
  int getBoxByIndex(int index) { return mBoxs[index]; }
  int getRequiresByIndex(int index) { return mRequires[index]; }
private:
  int mID;
  int mMapID;
  int mLucklyRate;
  int mRareRate;
  int mMaxNormalRate;
  int mBoxs[MAX_RANDOM_BOX_COUNT];  
  int mRequires[MAX_RANDOM_BOX_COUNT];
  friend class RandomBoxMapDataTable;
};

class RandomBoxMapDataTable
{
public:
  RandomBoxMapDataTable();
  ~RandomBoxMapDataTable();
  bool InitWithFileName(const char *file_name);
  RandomBoxMapData* getDataByID(int id) { return mDataMap.find(id)->second; }
protected:
  void parseRow(vector<string> &row);

private:

  std::map<int, RandomBoxMapData*> mDataMap;
};


#endif