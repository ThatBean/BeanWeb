#include "sound_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

SoundDataTable::SoundDataTable()
{
  sound_data_table_ = new vector<SoundData*>();
}

SoundDataTable::~SoundDataTable()
{
  for (vector<SoundData*>::iterator itr = sound_data_table_->begin();
  itr != sound_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete sound_data_table_;
}

bool SoundDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

SoundData* SoundDataTable::GetSound(uint_32 id)
{
  map<uint_32, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("SoundDataTable TypeId not found! TypeId: %d", id);
    assert(false);
    return NULL;
  }
  return sound_data_table_->at(index->second);
}

void SoundDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  SoundData *data = new SoundData();
  data->id = String2UInt32(row[i++]);
  data->resourceName = row[i++];
  index_map_.insert(pair<uint_32, int>(data->id, sound_data_table_->size()));
  sound_data_table_->push_back(data);
}

