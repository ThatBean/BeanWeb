#include "checkpointdaily_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"

bool CheckpointDailyData::getLocalDropItemData(int index, int& out_id, int& out_count)
{
  if (index > 0 && index < 5)
  {
    --index;
    out_id = mItemId[index];
    out_count = mItemCount[index];
    return true;
  }
  return false;
}

CheckpointDailyDataTable::CheckpointDailyDataTable()
{
  checkpointdaily_data_table_ = new vector<CheckpointDailyData*>();
}

CheckpointDailyDataTable::~CheckpointDailyDataTable()
{
  for (vector<CheckpointDailyData*>::iterator itr = checkpointdaily_data_table_->begin();
  itr != checkpointdaily_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete checkpointdaily_data_table_;
}

bool CheckpointDailyDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

CheckpointDailyData* CheckpointDailyDataTable::GetCheckpointdaily(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("CheckpointDailyDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return checkpointdaily_data_table_->at(index->second);
}

CCArray* CheckpointDailyDataTable::GetAllCheckpointdailyId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void CheckpointDailyDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  CheckpointDailyData *data = new CheckpointDailyData();
  data->id = String2Int(row[i++]);
  data->battlebg = row[i++];
  data->name = LanguageDataTable::FormatLanguageKey("checkpointDaily", "name", data->id);
  i++;
  data->icon = row[i++];
  data->jobType = String2Int8(row[i++]);
  data->receivelexp = String2Int(row[i++]);
  data->card_exp = String2Int(row[i++]);
  data->money = String2Int(row[i++]);
  data->time = String2Int(row[i++]);
  data->bgm = String2Int(row[i++]);
  data->checkpoint_level = String2Int(row[i++]);
  data->require_ap = String2Int(row[i++]);
  
  data->mItemRate[0] = String2Int(row[i++]);
  data->mItemRate[1] = String2Int(row[i++]);
  data->mItemRate[2] = String2Int(row[i++]);
  data->mItemRate[3] = String2Int(row[i++]);
  data->mItemId[0] = String2Int(row[i++]);
  data->mItemId[1] = String2Int(row[i++]);
  data->mItemId[2] = String2Int(row[i++]);
  data->mItemId[3] = String2Int(row[i++]);
  data->mItemCount[0] = String2Int(row[i++]);
  data->mItemCount[1] = String2Int(row[i++]);
  data->mItemCount[2] = String2Int(row[i++]);
  data->mItemCount[3] = String2Int(row[i++]);
  getIntListFromString(row[i++], data->monster);
  i += 2;
  data->cp_type = String2Int(row[i++]);
  data->cp_tips = row[i++];
  data->Details = row[i++];
  data->ck_name = "";
  index_map_.insert(pair<int, int>(data->id, checkpointdaily_data_table_->size()));
  checkpointdaily_data_table_->push_back(data);
  BaseCheckpointDataTable::GetInstance()->AddDataToTable(data->id, data);
}

const string& CheckpointDailyData::GetName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}