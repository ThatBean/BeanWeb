#include "mailmessage_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

MailmessageDataTable::MailmessageDataTable()
{
  mailmessage_data_table_ = new vector<MailmessageData*>();
}

MailmessageDataTable::~MailmessageDataTable()
{
  for (vector<MailmessageData*>::iterator itr = mailmessage_data_table_->begin();
  itr != mailmessage_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete mailmessage_data_table_;
}

bool MailmessageDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  CCLOG("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

MailmessageData* MailmessageDataTable::GetMailmessage(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("MailmessageDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return mailmessage_data_table_->at(index->second);
}

void MailmessageDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  MailmessageData *data = new MailmessageData();
  data->id = String2Int(row[i++]);
  data->data = LanguageDataTable::FormatLanguageKey("mailmessage", "data", data->id);//row[i++];
  i++;
  index_map_.insert(pair<int, int>(data->id, mailmessage_data_table_->size()));
  mailmessage_data_table_->push_back(data);
}

const string& MailmessageData::GetData()
{
  return LanguageDataTable::GetInstance()->GetLanguage(data);
}