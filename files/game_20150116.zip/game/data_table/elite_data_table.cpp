﻿#include "elite_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/data_manager.h"
EliteDataTable::EliteDataTable()
{
  elite_data_table_ = new vector<EliteData*>();
}

EliteDataTable::~EliteDataTable()
{
  for (vector<EliteData*>::iterator itr = elite_data_table_->begin();
  itr != elite_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete elite_data_table_;
}

bool EliteDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

EliteData* EliteDataTable::GetEliteByCheckPointID(int cp_id)
{
  map<int, int>::iterator index = index_map_.find(cp_id);
  if(index == index_map_.end())
  {
    CCLOG("EliteDataTable TypeId not found! Id: %d", cp_id);
    assert(false);
    return NULL;
  }
  return elite_data_table_->at(index->second);
}

CCArray* EliteDataTable::GetAllEliteId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void EliteDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  EliteData *data = new EliteData();
  data->cp_id = String2Int(row[i++]);
  data->bossid = String2Int(row[i++]);
  data->cp_lv = String2Int(row[i++]);
  data->cp_count = String2Int(row[i++]);
  data->rankexp = String2Int(row[i++]);
  data->cardexp = String2Int(row[i++]);
  data->gold = String2Int(row[i++]);
  data->award1 = String2Int(row[i++]);
  data->rand1 = String2Int(row[i++]);
  data->award2 = String2Int(row[i++]);
  data->rand2 = String2Int(row[i++]);
  data->award3 = String2Int(row[i++]);
  data->rand3 = String2Int(row[i++]);
  data->award4 = String2Int(row[i++]);
  data->rand4 = String2Int(row[i++]);
  getIntListFromString(row[i++], data->show_icon);
  data->fAnimationScale = String2Float(row[i++]);
  data->battle_bg = String2Int(row[i++]);
  data->battle_bgm = String2Int(row[i++]);
  data->battle_time = String2Int(row[i++]);
  data->icon = row[i++];
  data->iconName = row[i++];
  data->mapId = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->cp_id, elite_data_table_->size()));
  elite_data_table_->push_back(data);
  BaseCheckpointDataTable::GetInstance()->AddDataToTable(data->cp_id, data);
}


const string& EliteData::getName()
{
   return DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(bossid)->GetShortName();
}
