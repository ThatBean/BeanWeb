#include "checkpointmain_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"

bool CheckpointMainData::getLocalDropItemData(int index, int& out_id, int& out_count)
{
  if (index > 0 && index < 5)
  {
    --index;
    out_id = mItemsID[index];
    out_count = mItemsCount[index];
    return true;
  }
  return false;
}
bool CheckpointMainData::getLocalFirstDropItemData(int index, int& out_id, int& out_count, int& out_type)
{
  if (index > 0 && index < 3)
  {
    --index;
    out_id = mFirstItemsID[index];
    out_count = mFirstItemsCount[index];
    out_type = mFirstItemsType[index];
    return true;
  }
  return false;
} 

const string& CheckpointMainData::GetName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}

CheckpointMainDataTable::CheckpointMainDataTable()
{
  checkpointmain_data_table_ = new vector<CheckpointMainData*>();
}

CheckpointMainDataTable::~CheckpointMainDataTable()
{
  for (vector<CheckpointMainData*>::iterator itr = checkpointmain_data_table_->begin();
  itr != checkpointmain_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete checkpointmain_data_table_;
}

bool CheckpointMainDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

CheckpointMainData* CheckpointMainDataTable::GetCheckpointmain(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    return NULL;
  }
  return checkpointmain_data_table_->at(index->second);
}

CCArray* CheckpointMainDataTable::GetAllCheckpointmainId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void CheckpointMainDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  CheckpointMainData *data = new CheckpointMainData();
  data->id = String2Int(row[i++]);
  data->battlebg = String2Int(row[i++]);
  data->name = LanguageDataTable::FormatLanguageKey("checkpointMain", "name", data->id);
  ++i;
  data->icon = row[i++];
  //data->boss_icon = row[i++];
  i++;
  i++;
  data->section = String2Int(row[i++]);
  data->type = String2Int(row[i++]);
  data->frequency = String2Int(row[i++]);
  data->receivelexp = String2Int(row[i++]);
  data->card_exp = String2Int(row[i++]);
  data->money = String2Int(row[i++]);
  data->time = String2Int(row[i++]);
  data->bgm = String2Int(row[i++]);
  data->checkpoint_level = String2Int(row[i++]);
  data->prev_questid = String2Int(row[i++]);
  data->require_ap = String2Int(row[i++]);
  data->mapid = String2Int(row[i++]);
  data->first_money = String2Int(row[i++]);
  data->first_rank_exp = String2Int(row[i++]);
  data->mFirstItemsType[0] = String2Int(row[i++]);
  data->mFirstItemsType[1] = String2Int(row[i++]);
  data->mFirstItemsID[0] = String2Int(row[i++]);
  data->mFirstItemsID[1] = String2Int(row[i++]);
  data->mFirstItemsCount[0] = String2Int(row[i++]);
  data->mFirstItemsCount[1] = String2Int(row[i++]);
  data->mItemsRate[0] = String2Int(row[i++]);
  data->mItemsRate[1] = String2Int(row[i++]);
  data->mItemsRate[2] = String2Int(row[i++]);
  data->mItemsRate[3] = String2Int(row[i++]);
  data->mItemsID[0] = String2Int(row[i++]);
  data->mItemsID[1] = String2Int(row[i++]);
  data->mItemsID[2] = String2Int(row[i++]);
  data->mItemsID[3] = String2Int(row[i++]);
  data->mItemsCount[0] = String2Int(row[i++]);
  data->mItemsCount[1] = String2Int(row[i++]);
  data->mItemsCount[2] = String2Int(row[i++]);
  data->mItemsCount[3] = String2Int(row[i++]);
  getIntListFromString(row[i++], data->cp_monster);
  data->cp_tips = row[i++];

  data->mDifficultyType = 0;
  if (data->id >= 1 && data->id <= 1999)
  {
    data->mDifficultyType = 1;
  }
  else if(data->id >= 11000 && data->id <= 12000)
  {
    data->mDifficultyType = 2;
  }
  else if (data->id >= 21000 && data->id <= 22000)
  {
    data->mDifficultyType = 3;
  }

  //data->Details = row[i++];
  index_map_.insert(pair<int, int>(data->id, checkpointmain_data_table_->size()));
  checkpointmain_data_table_->push_back(data);
  BaseCheckpointDataTable::GetInstance()->AddDataToTable(data->id, data);
}
