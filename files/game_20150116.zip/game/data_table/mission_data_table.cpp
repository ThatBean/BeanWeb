#include "mission_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
MissionDataTable::MissionDataTable()
{
  mission_data_table_ = new vector<MissionData*>();
}

MissionDataTable::~MissionDataTable()
{
  for (vector<MissionData*>::iterator itr = mission_data_table_->begin();
  itr != mission_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete mission_data_table_;
}

bool MissionDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  mMaxMissionID = -1;
  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  initDefaultMission();
  return true;
}

MissionData* MissionDataTable::GetMission(uint_32 quest_id)
{
  map<uint_32, int>::iterator index = index_map_.find(quest_id);
  if(index == index_map_.end())
  {
    CCLOG("MissionDataTable TypeId not found! Id: %d", quest_id);
    assert(false);
    return NULL;
  }
  return mission_data_table_->at(index->second);
}

CCArray* MissionDataTable::GetAllMissionId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<uint_32, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}

void MissionDataTable::initDefaultMission()
{
  MissionData *data = new MissionData();
  data->quest_id = 29990;
  data->prev_quest_id = mMaxMissionID;
  data->title = "";
  data->ReqConditionType = 1;
  data->ReqConditionParm1 = 1095;
  data->ReqCondition2Parm = 1;
  data->ReceiveExp = 0;
  data->ReceiveMoney = 0;
  data->ReceiveType1 = 0;
  data->ReceiveType2 = 0;

  data->ReceiveItemId2 = 0;
  data->ReceiveItemCount1 = 0;
  data->ReceiveItemCount2 = 0;
  index_map_.insert(pair<uint_32, int>(data->quest_id, mission_data_table_->size()));
  mission_data_table_->push_back(data);
}

void MissionDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  MissionData *data = new MissionData();
  data->quest_id = String2UInt32(row[i++]);
  data->prev_quest_id = String2UInt32(row[i++]);
  int temp_back_quest_id = String2UInt32(row[i++]);
  data->title = row[i++];
  data->ReqConditionType = String2UInt8(row[i++]);
  data->ReqConditionParm1 = String2UInt32(row[i++]);
  data->ReqCondition2Parm = String2UInt32(row[i++]);
  data->ReceiveExp = String2UInt32(row[i++]);
  data->ReceiveMoney = String2UInt32(row[i++]);
  data->ReceiveType1 = String2UInt32(row[i++]);
  data->ReceiveType2 = String2UInt32(row[i++]);
  getIntListFromString(row[i++], data->ReceiveItem1List);
  //data->ReceiveItemId1 = String2UInt32(row[i++]);
  data->ReceiveItemId2 = String2UInt32(row[i++]);
  data->ReceiveItemCount1 = String2UInt32(row[i++]);
  data->ReceiveItemCount2 = String2UInt32(row[i++]);
  data->Details = row[i++];
  index_map_.insert(pair<uint_32, int>(data->quest_id, mission_data_table_->size()));
  mission_data_table_->push_back(data);
  //mMaxMissionID = data->quest_id > mMaxMissionID ? data->quest_id : mMaxMissionID;
  if (temp_back_quest_id == 0)
  {
    mMaxMissionID = data->quest_id;
  }
}

