﻿#include "rank_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

RankDataTable::RankDataTable()
{
  rank_data_table_ = new vector<RankData*>();
}

RankDataTable::~RankDataTable()
{
  for (vector<RankData*>::iterator itr = rank_data_table_->begin();
  itr != rank_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete rank_data_table_;
}

bool RankDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

RankData* RankDataTable::GetRank(uint_16 rank)
{
  map<uint_16, int>::iterator index = index_map_.find(rank);
  if(index == index_map_.end())
  {
    CCLOG("RankDataTable TypeId not found! TypeId: %d", rank);
    assert(false);
    return NULL;
  }
  return rank_data_table_->at(index->second);
}

void RankDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  RankData *data = new RankData();
  data->rank = String2UInt16(row[i++]);
  data->cost = String2UInt16(row[i++]);
  data->activePoint = String2UInt16(row[i++]);
  data->friendsCount = String2UInt8(row[i++]);
  data->totalXp = String2UInt32(row[i++]);
  data->levelRequiredXp = String2UInt32(row[i++]);
  data->deck = String2UInt8(row[i++]);
  index_map_.insert(pair<uint_16, int>(data->rank, rank_data_table_->size()));
  rank_data_table_->push_back(data);
}

uint_32 RankDataTable::GetTeamPosUnlockLevel( uint_8 index )
{
  for (vector<RankData*>::iterator itr = rank_data_table_->begin();
    itr != rank_data_table_->end(); ++itr)
  {
    if ( (*itr)->deck >= index )
    {
      return (*itr)->rank;
    }
  }
  return 0;
}

