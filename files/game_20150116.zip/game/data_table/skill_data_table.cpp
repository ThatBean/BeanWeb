﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skill_data_table.cpp
//        Author: robbiepan
//          Date: 2013/9/17 16:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/17      add
//////////////////////////////////////////////////////////////
#include "skill_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/battle/tiled_map/map_constants.h"
#include "language_data_table.h"
#include <cocos2d.h>

SkillDataTable::SkillDataTable()
{
  skill_data_table_ = new vector<SkillBase*>();
}

SkillDataTable::~SkillDataTable()
{
  for (vector<SkillBase*>::iterator itr = skill_data_table_->begin();
    itr != skill_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete skill_data_table_;
}

bool SkillDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

SkillBase* SkillDataTable::GetSkill(int_32 id)
{
  map<int_32, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("SkillDataTable TypeId not found! TypeId: %ld", id);
    assert(false);
    return NULL;
  }
  return skill_data_table_->at(index->second);
}

void SkillDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  SkillBase *data = new SkillBase();

  int_32 skill_id = 0;  
  skill_id = String2Int32(row[i++]);
  data->skill_id = skill_id;
  data->name = LanguageDataTable::FormatLanguageKey("skill", "name", skill_id);//row[i++];
  ++i;
  ++i;  // unused for name_jp
  data->skill_desc = LanguageDataTable::FormatLanguageKey("skill", "skillDesc", skill_id);//row[i++];
  ++i;
  ++i;  // unused for skill_desc_jp
  data->icon_index = String2Int32(row[i++]);
  data->skill_type = String2Bool(row[i++]);
  data->casting_type = String2Int8(row[i++]);
  data->powerSkill = String2Bool(row[i++]);
  data->damage_type = String2Int32(row[i++]);
  data->use_target_type = String2Int32(row[i++]);
  data->penetrate = String2Bool(row[i++]);
  data->hit_type = String2Int32(row[i++]);
  data->cd_tick = String2Int32(row[i++]);
  data->powerEffect = row[i++];
  data->power2Effect = row[i++];
  data->self_break_id = String2Int32(row[i++]);
  data->target_break_id = String2Int32(row[i++]);
  data->eff_break_id = String2Int32(row[i++]);
  data->motion = row[i++];
  data->powerMotion1 = row[i++];
  data->powerMotion2 = row[i++];
  data->powerTime = String2Int32(row[i++]);
  data->highLight = String2Int32(row[i++]);
  data->powerMotion3 = row[i++];
  data->self_status = row[i++];
  data->self_status_ratio = String2Int32(row[i++]);
  data->target_player_status = row[i++];
  data->target_player_status_ratio = String2Int32(row[i++]);
  data->target_status = row[i++];
  data->target_status_ratio = String2Int32(row[i++]);

  data->iniDamage = String2Int32(row[i++]);
  data->addDamage = String2Int32(row[i++]);

  data->phyAddedMul = String2Float(row[i++]);
  data->magAddedMul = String2Float(row[i++]);


  data->beat_back_dist = String2Float(row[i++]) * taomee::battle::kMapTileAverageLength;
  data->damage_self_percent = String2Int32(row[i++]);
  data->damage_enemy_percent = String2Int32(row[i++]);
  data->charge_distance = String2Float(row[i++]) * taomee::battle::kMapTileAverageLength;
  data->motion_count = String2Int8(row[i++]);
  data->motion_speed_rate = String2Float(row[i++]);  
  data->damage_tick = String2Int32(row[i++]);
  data->beat_down = String2Bool(row[i++]);
  data->target_beat_back_ratio = String2Int32(row[i++]);

  index_map_.insert(pair<int_32, int>(skill_id, skill_data_table_->size()));
  skill_data_table_->push_back(data);
}

const string& SkillBase::GetName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(name);
}

const string& SkillBase::GetSkillDesc()
{
  return LanguageDataTable::GetInstance()->GetLanguage(skill_desc);
}

int_32 SkillBase::GetSkillGrowDamage(uint_8 skill_level)
{
	return iniDamage + ( skill_level - 1) * addDamage;
}