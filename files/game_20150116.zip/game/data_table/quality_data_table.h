#ifndef QUALITY_DATA_TABLE_H
#define QUALITY_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class QualityData
{
public:
  /*1*/
  int GetQuality()
  {
    return quality;
  }
  /*0*/
  int GetRingCount()
  {
    return ringCount;
  }
  /*0*/
  int GetSoldMoney()
  {
    return soldMoney;
  }
private:
  int		quality;
  int		ringCount;
  int		soldMoney;

  friend class QualityDataTable;
};

class QualityDataTable
{
public:
  QualityDataTable();
  ~QualityDataTable();
  bool InitWithFileName(const char *file_name);
  QualityData* GetQuality(int quality);

  CCArray* GetAllQualityId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<QualityData*> *quality_data_table_;

  map<int, int> index_map_;
};
#endif
