#ifndef DAILY_TASKS_TABLE_H
#define DAILY_TASKS_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class dailyTaskData
{
public:
	int getTypeId()
	{
		return type_id;
	}
	int getLimit()
	{
		return limit;
	}
	int getApcost()
	{
		return apcost;
	}
	string& getData()
	{
		return data;
	}
	string& getCheckPoint()
	{
		return checkpointId;
	}
private:
	int type_id;
	int limit;
	int apcost;
	string data;
	string checkpointId;

	friend class dailyTaskDataTable;
};


class dailyTaskDataTable
{
public:
	dailyTaskDataTable();
	~dailyTaskDataTable();
	bool InitWithFileName(const char *file_name);
	dailyTaskData* GetDailyTask(int id);

	CCArray* GetAllDailyTaskId();
	int getDailyTaskAllCount();

protected:
	void parseRow(vector<string> &row);

private:
	vector<dailyTaskData*> *dailyTask_data_table_;

	map<int, int> index_map_;
};
#endif

