//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: language_drama_data_table.cpp
//        Author: dylan
//          Date: 2014/7/9 14:59
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     dylan    2014/7/9      add
//////////////////////////////////////////////////////////////
#include "language_drama_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/data_manager.h"
#include <cocos2d.h>

static LanguageDramaDataTable* _S_ = NULL;

LanguageDramaDataTable* LanguageDramaDataTable::GetInstance()
{
  if(!_S_)
  {
    _S_ = DataManager::GetInstance().GetLanguageDramaDataTable();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&_S_);
  }
  return _S_;
}

void LanguageDramaDataTable::ResetLanguageDataTable()
{
  _S_ = NULL;
}

LanguageDramaDataTable::LanguageDramaDataTable()
{
  strings_map_ = new map<string, string>();
}

LanguageDramaDataTable::~LanguageDramaDataTable()
{
  if (strings_map_)
  {
    strings_map_->clear();
  }
  delete strings_map_;
}

string LanguageDramaDataTable::FormatLanguageKey(const char* table, const char* field, int id)
{
  string result;
  char buff[64];
  sprintf(buff, "%s_%s_%d", table, field, id);  
  result = buff;
  return result;
}

bool LanguageDramaDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }
  return true;
}

string& LanguageDramaDataTable::GetLanguage(string& key)
{ 
  map<string, string>::iterator it = strings_map_->find(key);
  if (it == strings_map_->end())
  {
    cocos2d::CCLog("ERROR LanguageDrama not find key=%s", key.c_str());
    //assert(false);
    return str_temp;
  }
  return it->second;
}

void LanguageDramaDataTable::parseRow(vector<string> &row)
{
  int keyIndex = 0;
  int valueIndex = 1;
  switch (DataManager::getCurrentLanguageType())  
  {  
  case kLanguageEnglish:  
    valueIndex = 3;  
    break;  
  case kLanguageChinese:
    valueIndex = 1;  
    break;  
  case kLanguageFrench:  
    break;  
  case kLanguageGerman:  
    break;
  case kLanguageItalian:  
    break;
  case kLanguageRussian:  
    break;
  case kLanguageSpanish:   
    break;
  case kLanguageKorean:
    valueIndex = 2;
    break;  
  }
  string key = row[keyIndex];
  string value_cn = row[valueIndex];
  strings_map_->insert(std::make_pair(key, value_cn));
}

