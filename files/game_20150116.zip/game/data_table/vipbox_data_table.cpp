//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: vipbox_data_table.cpp
//        Author: coldouyang
//          Date: 2014/5/22 15:32
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/5/22      add
//////////////////////////////////////////////////////////////

#include "game/data_table/vipbox_data_table.h"
#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/data_manager.h"
#include "language_data_table.h"
#include <cocos2d.h>

VipBoxDataTable::VipBoxDataTable()
{
  buff_data_table_ = new vector<VipBoxData*>();
}

VipBoxDataTable::~VipBoxDataTable()
{
  for (vector<VipBoxData*>::iterator itr = buff_data_table_->begin();
    itr != buff_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete buff_data_table_;
}

bool VipBoxDataTable::InitWithFileName(const char *file_name)
{
/*
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }
*/
  ItemlistDataTable* itemList = DataManager::GetInstance().GetItemlistDataTable();
  BoxlistDataTable*  boxList = DataManager::GetInstance().GetBoxlistDataTable();
  int itemStartID = 23;
  int shopStartID = 14;
  for (int i = 0; i < 11; ++i)
  {
      VipBoxData *data = new VipBoxData();
      ItemlistData* itemData = itemList->GetItemlist(itemStartID + i);
      int boxID = itemData->GetId();
      data->id = i;
      for (int index = 0; index < 4; ++index)
      {
        BoxlistData* boxData = boxList->GetAllBoxlistById(boxID, index);
        data->itemType[index] = boxData->GetItem_type();
        data->itemId[index] = boxData->GetItem_id();
        data->itemCount[index] = boxData->GetItem_count();
      }
      ShopData* shopData = DataManager::GetInstance().GetShopDataTable()->GetShopById(shopStartID + i);
      data->oriPrice = shopData->getCashCount();
      data->curPrice = shopData->getPrice();
      index_map_.insert(pair<int, int>(data->id, buff_data_table_->size()));
      buff_data_table_->push_back(data);
  }
  return true;
}

VipBoxData* VipBoxDataTable::GetBuff(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    cocos2d::CCLog("VipBoxDataTable Id not found!! Id: %d", id);
//    assert(false);
    return NULL;
  }
  return buff_data_table_->at(index->second);
}

void VipBoxDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  VipBoxData *data = new VipBoxData();
  data->id = String2Int8(row[i++]);
  for (int index = 0; index < 4; ++index)
  {
    data->itemType[index] = String2Int8(row[i++]);
  }
  
  for (int index = 0; index < 4; ++index)
  {
    data->itemId[index] = String2Int32(row[i++]);
  }

  for (int index = 0; index < 4; ++index)
  {
    data->itemCount[index] = String2Int32(row[i++]);
  }

  index_map_.insert(pair<int, int>(data->id, buff_data_table_->size()));
  buff_data_table_->push_back(data);
}