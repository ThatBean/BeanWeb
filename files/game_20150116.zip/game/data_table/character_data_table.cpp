﻿#include "character_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

CharacterDataTable::CharacterDataTable()
{
  character_data_table_ = new vector<CharacterData*>();
}

CharacterDataTable::~CharacterDataTable()
{
  for (vector<CharacterData*>::iterator itr = character_data_table_->begin();
    itr != character_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete character_data_table_;
}

bool CharacterDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    if(csv_row.size() == 0)
      continue;
    parseRow(csv_row);
  }

  return true;
}

CharacterData* CharacterDataTable::GetCharacter(int cid)
{
  map<int, int>::iterator index = index_map_.find(cid);
  if(index == index_map_.end())
  {
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(true);
    CCLOG("CharacterDataTable TypeId not found! TypeId: %d", cid);
    PlatformControl::GetPlatformControl()->SetConsoleErrorColor(false);
    assert(false);
    return NULL;
  }
  return character_data_table_->at(index->second);
}

CharacterData* CharacterDataTable::getCharacterByIndex(int index)
{
  if (index >= card_id_container_.size()) 
  {
    return NULL;
  }
  
  CharacterData* data = character_data_table_->at(index);
  return data;
}

cocos2d::CCArray* CharacterDataTable::GetOwnCharacterByRarity(int rarity)
{
  cocos2d::CCArray* character_id_arr = cocos2d::CCArray::create();
  for (vector<CharacterData*>::iterator itr = character_data_table_->begin();
    itr != character_data_table_->end(); ++itr)
  {
    if ( (*itr)->isEnemy == true )
      continue;
    if ((*itr)->GetRarity() == rarity)
      character_id_arr->addObject(cocos2d::CCInteger::create((*itr)->GetCid()));
  }
  return character_id_arr;
}

void CharacterDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  CharacterData *data = new CharacterData();
  data->cid = String2Int(row[i++]);
  data->name = row[i++];
  data->displayName = LanguageDataTable::FormatLanguageKey("character", "displayname", data->cid);//row[i++];
  i++;
  data->shortName = LanguageDataTable::FormatLanguageKey("character", "shortname", data->cid);//row[i++];
  i++;
  data->growth = String2Int8(row[i++]);
  data->rarity = String2Int8(row[i++]);
  data->quality = String2Int(row[i++]);
  data->isEnemy = String2Bool(row[i++]);
  data->monsterLevel = String2Int8(row[i++]);
  data->gender = String2Int8(row[i++]);
  data->jobType = String2Int8(row[i++]);
  data->moveType = String2Int8(row[i++]);
  data->battleType = String2Int8(row[i++]);
  data->limitBreak = String2Int8(row[i++]);
  data->iniHp = String2Int(row[i++]);
  data->iniPhysicsAttack = String2Int(row[i++]);
  data->iniMagicAttack = String2Int(row[i++]);
  data->addHp = String2Int(row[i++]);
  data->addPhysicsAttack = String2Int(row[i++]);
  data->addMagicAttack = String2Int(row[i++]);

  data->hitRate = String2Int(row[i++]);
  data->addHitRate = String2Int(row[i++]);
  data->dodge = String2Int(row[i++]);
  data->addDodge = String2Int(row[i++]);

  data->hpFlag = String2Int(row[i++]);
  data->atkSpeed = String2Float(row[i++]);
  data->movSpeed = String2Float(row[i++]);
  data->shotSpeed = String2Float(row[i++]);
  data->shotSpeedMultiple = String2Float(row[i++]);
  data->weakFlag = String2Int8(row[i++]);
  data->physicsDef = String2Int(row[i++]);
  data->magicDef = String2Int(row[i++]);
  data->defPhysicsRate = String2Float(row[i++]);
  data->defMagicRate = String2Float(row[i++]);
  data->critical = String2Float(row[i++]);
  data->critical_damage = String2Float(row[i++]);
  data->guard = String2Int(row[i++]);
  data->attackRange = String2Float(row[i++]);
  data->bodyRange = String2Float(row[i++]);
  data->bodyHeight = String2Int8(row[i++]);
  data->skeletonScale = String2Float(row[i++]);
  data->patrolType = String2Int8(row[i++]);
  data->patrolParam1 = String2Float(row[i++]);
  data->patrolParam2 = String2Float(row[i++]);
  data->motionId = String2Int(row[i++]);
  data->spmotName = row[i++];
  data->weaponId = String2Int(row[i++]);
  data->weaponId2 = String2Int(row[i++]);

  data->unlockSkill_1 = String2Int(row[i++]);
  data->unlockSkill_2 = String2Int(row[i++]);
  data->unlockSkill_3 = String2Int(row[i++]);

  //data->skillCost = String2Int(row[i++]);
  data->skillId[kSkillNormalHitNear] = String2Int(row[i++]);
  data->skillId[kSkillNormalHitFar] = String2Int(row[i++]);
  data->skillId[kSkillSkill] = String2Int(row[i++]);
  data->skillRate = String2Int(row[i++]);
  data->skillId[kSkillSkill_Little] = String2Int(row[i++]);
  data->skillId[kSkillPassive1] = String2Int(row[i++]);
  data->unlockLevel1 = String2Int(row[i++]);
  data->unlockQuest1 = String2Int(row[i++]);
  data->skillId[kSkillPassive2] = String2Int(row[i++]);
  data->unlockLevel2 = String2Int(row[i++]);
  data->unlockQuest2 = String2Int(row[i++]);
  data->skillId[kSkillWeapon] = String2Int(row[i++]);
  data->profile = LanguageDataTable::FormatLanguageKey("character", "profile", data->cid);//row[i++];
  ++i;
  data->talk_id = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->cid, character_data_table_->size()));
  card_id_container_.push_back(data->cid);
  character_data_table_->push_back(data);
  BaseResDataTable::GetInstance()->AddResDataToTable(data->cid, data);
}

/* 供ui显示的全称 */
const string& CharacterData::GetDisplayName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(displayName);
}

const string& CharacterData::GetShortName()
{
  return LanguageDataTable::GetInstance()->GetLanguage(shortName);
}

const string& CharacterData::GetProfile()
{
  return LanguageDataTable::GetInstance()->GetLanguage(profile);
}

float CharacterData::getInitPropertyByType( uint_8 property_type )
{
  switch(property_type)
  {
    case kAttrTypeHp:
      return iniHp;
      break;
    case kAttrTypePhyAtk:
      return iniPhysicsAttack;
      break;
    case kAttrTypeMagAtk:
      return iniMagicAttack;
      break;
    case kAttrTypeHitRate:
      return hitRate;
      break;
    case kAttrTypeDodgeRate:
      return dodge;
      break;
    case kAttrTypeCritRate:
      return critical;
      break;
    case kAttrTypeCritDamage:
      return critical_damage;
      break;
    case kAttrTypePDef:
      return physicsDef;
      break;
    case kAttrTypeMDef:
      return magicDef;
      break;
  }
  cocos2d::CCLog("This IniProperty is not exist in character.csv ID:%d",property_type);
  return 0;
}

float CharacterData::getAddPropertyByType( uint_8 property_type )
{
  switch(property_type)
  {
  case kAttrTypeHp:
    return addHp;
    break;
  case kAttrTypePhyAtk:
    return addPhysicsAttack;
    break;
  case kAttrTypeMagAtk:
    return addMagicAttack;
    break;
  case kAttrTypeHitRate:
    return addHitRate;
    break;
  case kAttrTypeDodgeRate:
    return addDodge;
    break;
  }
  cocos2d::CCLog("This AddProperty is not exist in character.csv ID:%d",property_type);
  return 0;
}
