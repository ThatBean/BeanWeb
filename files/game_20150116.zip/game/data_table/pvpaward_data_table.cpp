#include "pvpaward_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
PvpawardDataTable::PvpawardDataTable()
{
  pvpaward_data_table_ = new vector<PvpawardData*>();
}

PvpawardDataTable::~PvpawardDataTable()
{
  for (vector<PvpawardData*>::iterator itr = pvpaward_data_table_->begin();
  itr != pvpaward_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete pvpaward_data_table_;
}

bool PvpawardDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

PvpawardData* PvpawardDataTable::GetPvpaward(int rank)
{
  map<int, int>::iterator index = index_map_.find(rank);
  if(index == index_map_.end())
  {
    CCLOG("PvpawardDataTable TypeId not found! Id: %d", rank);
    assert(false);
    return NULL;
  }
  return pvpaward_data_table_->at(index->second);
}

CCArray* PvpawardDataTable::GetAllPvpawardId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void PvpawardDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  PvpawardData *data = new PvpawardData();
  data->rank = String2Int(row[i++]);
  data->win_card_exp = String2Int(row[i++]);
  data->win_rank_exp = String2Int(row[i++]);
  data->win_award1 = String2Int(row[i++]);
  data->win_award1_count = String2Int(row[i++]);
  data->win_award2 = String2Int(row[i++]);
  data->win_award2_count = String2Int(row[i++]);
  data->win_item1 = String2Int(row[i++]);
  data->win_item1_type = String2Int(row[i++]);
  data->win_item1_count = String2Int(row[i++]);
  data->win_item1_plus = String2Int(row[i++]);
  data->win_item1_rate = String2Int(row[i++]);
  data->win_item2 = String2Int(row[i++]);
  data->win_item2_type = String2Int(row[i++]);
  data->win_item2_count = String2Int(row[i++]);
  data->win_item2_plus = String2Int(row[i++]);
  data->win_item2_rate = String2Int(row[i++]);
  data->win_item3 = String2Int(row[i++]);
  data->win_item3_type = String2Int(row[i++]);
  data->win_item3_count = String2Int(row[i++]);
  data->win_item3_plus = String2Int(row[i++]);
  data->win_item3_rate = String2Int(row[i++]);
  data->win_item4 = String2Int(row[i++]);
  data->win_item4_type = String2Int(row[i++]);
  data->win_item4_count = String2Int(row[i++]);
  data->win_item4_plus = String2Int(row[i++]);
  data->win_item4_rate = String2Int(row[i++]);
  data->win_item5 = String2Int(row[i++]);
  data->win_item5_type = String2Int(row[i++]);
  data->win_item5_count = String2Int(row[i++]);
  data->win_item5_plus = String2Int(row[i++]);
  data->win_item5_rate = String2Int(row[i++]);
  data->lose_card_exp = String2Int(row[i++]);
  data->lose_rank_exp = String2Int(row[i++]);
  data->lose_award1 = String2Int(row[i++]);
  data->lose_award1_count = String2Int(row[i++]);
  data->lose_award2 = String2Int(row[i++]);
  data->lose_award2_count = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->rank, pvpaward_data_table_->size()));
  pvpaward_data_table_->push_back(data);
}

