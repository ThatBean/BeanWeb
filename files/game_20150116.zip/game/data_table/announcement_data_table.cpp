﻿#include "announcement_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

AnnouncementDataTable::AnnouncementDataTable()
{
  announcemen_data_table_ = new vector<AnnouncementData*>();
}

AnnouncementDataTable::~AnnouncementDataTable()
{
  for (vector<AnnouncementData*>::iterator itr = announcemen_data_table_->begin();
  itr != announcemen_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete announcemen_data_table_;
}

bool AnnouncementDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

AnnouncementData* AnnouncementDataTable::GetAnnouncement(uint_16 id)
{
  map<uint_16, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("AnnouncementDataTable TypeId not found! TypeId: %d", id);
    assert(false);
    return NULL;
  }
  return announcemen_data_table_->at(index->second);
}

void AnnouncementDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  AnnouncementData *data = new AnnouncementData();
  data->id = String2UInt16(row[i++]);
  data->type = String2UInt16(row[i++]);
  data->description = LanguageDataTable::FormatLanguageKey("announcement", "description", data->id);//row[i++];
  i++;
  data->times = String2UInt8(row[i++]);
  data->priority = String2UInt8(row[i++]);
  data->showplace = String2UInt8(row[i++]);
  index_map_.insert(pair<uint_16, int>(data->id, announcemen_data_table_->size()));
  announcemen_data_table_->push_back(data);
}

std::string AnnouncementData::GetDescription()
{
  return LanguageDataTable::GetInstance()->GetLanguage(description);
}