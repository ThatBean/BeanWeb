//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: aura_data_table.h
//        Author: vic.tang
//          Date: 2014/10/27 17:05
//   Description: 
//
// History:
//     <author>    <time>        <descript>
//     vic.tang    2014/10/27      add
//////////////////////////////////////////////////////////////


#include "aura_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>


AuraData::AuraData()
	: m_id(Invalid_Aura_ID)
	, m_effect_pos(0)
	, m_interrupt_type(1)
	, m_time(0)
	, m_gains(0)
	, replace_rule(0)
	, m_mod_count(0)
{
	
}

AuraData::~AuraData()
{

}

void AuraData::ResetData()
{
	m_id = Invalid_Aura_ID;
	m_name.clear();
	m_desc.clear();
	m_icon.clear();
	m_effect.clear();
	m_effect_stage1.clear();
	m_effect_stage2.clear();
	m_effect_stage3.clear();
	m_effect_pos = 0;
	m_interrupt_type =1;
	m_time = 0;

	m_aura_status.clear();
	m_gains = 0;
	replace_rule = 0;
	m_mod_count =0;
	for (int i = 0; i < Modifier_Max_Count; ++i)
	{
		m_mod_list[i].m_type = 0;
	}
}

void AuraData::InitWithData(const AuraData* data)
{
	this->m_id				= data->m_id;
	this->m_name			= data->m_name;
	this->m_desc			= data->m_desc;
	this->m_icon			= data->m_icon;
	this->m_effect			= data->m_effect;
	this->m_effect_stage1	= data->m_effect_stage1;
	this->m_effect_stage2	= data->m_effect_stage2;
	this->m_effect_stage3	= data->m_effect_stage3;
	this->m_effect_pos		= data->m_effect_pos;
	this->m_interrupt_type	= data->m_interrupt_type;
	this->m_time			= data->m_time;
	this->m_aura_status		= data->m_aura_status;
	this->m_gains			= data->m_gains;
	this->replace_rule		= data->replace_rule;
	this->m_mod_count		= data->m_mod_count;
	for (int i = 0; i < Modifier_Max_Count; ++i)
	{
		this->m_mod_list[i].Copy(data->m_mod_list[i]);
	}
}

AuraDataTable::AuraDataTable()
{

}

AuraDataTable::~AuraDataTable()
{
	for ( defAuraDataMapIter iter = data_table_.begin(); iter != data_table_.end(); ++iter )
	{
		AuraData* obj = iter->second;
		delete obj;
	}
	data_table_.clear();
}

bool AuraDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}
const AuraData* AuraDataTable::GetByID(int id)
{
	defAuraDataMapConstIter iter = data_table_.find( id);
	if ( iter == data_table_.end())
	{
		assert(0);
		return NULL;
	}

	return iter->second;
}

void AuraDataTable::parseRow(const std::vector<std::string> &row)
{
	AuraData* aura_data = new AuraData();
	int i =0;

	aura_data->m_id = String2Int(row[i++]);
	aura_data->m_name = LanguageDataTable::FormatLanguageKey("aura", "name", aura_data->m_id);
	i++;
	aura_data->m_desc = LanguageDataTable::FormatLanguageKey("aura", "Desc", aura_data->m_id);//row[i++];
	i++;
	aura_data->m_icon = row[i++];
	aura_data->m_effect = row[i++];
	aura_data->m_effect_stage1 = row[i++];
	aura_data->m_effect_stage2 = row[i++];
	aura_data->m_effect_stage3 = row[i++];
	aura_data->m_effect_pos = String2Int(row[i++]);
	aura_data->m_interrupt_type = String2Int(row[i++]);
	aura_data->m_time = String2Float(row[i++]);

	aura_data->m_aura_status = row[i++];
	aura_data->m_gains = String2Bool(row[i++]);
	aura_data->replace_rule = String2Int(row[i++]);

	for ( int index = 0; index < Modifier_Max_Count; ++index)
	{
		aura_data->m_mod_list[aura_data->m_mod_count].m_type = String2Int(row[i++]);
		aura_data->m_mod_list[aura_data->m_mod_count].m_param0 = (row[i++]);
		aura_data->m_mod_list[aura_data->m_mod_count].m_param1 = (row[i++]);
		aura_data->m_mod_list[aura_data->m_mod_count].m_param2 = (row[i++]);
		aura_data->m_mod_list[aura_data->m_mod_count].m_param3 = (row[i++]);
		if ( aura_data->m_mod_list[aura_data->m_mod_count].m_type != 0)
		{
			aura_data->m_mod_count++;
		}
	}

	std::pair< defAuraDataMapIter, bool> result = data_table_.insert(std::pair<int, AuraData*>(aura_data->m_id, aura_data));
	if ( !result.second )
	{
		assert(0);
	}
}