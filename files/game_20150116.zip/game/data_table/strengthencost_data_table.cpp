#include "strengthencost_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
StrengthencostDataTable::StrengthencostDataTable()
{
  strengthencost_data_table_ = new vector<StrengthencostData*>();
}

StrengthencostDataTable::~StrengthencostDataTable()
{
  for (vector<StrengthencostData*>::iterator itr = strengthencost_data_table_->begin();
  itr != strengthencost_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete strengthencost_data_table_;
}

bool StrengthencostDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

StrengthencostData* StrengthencostDataTable::GetStrengthencost(int elv)
{
  map<int, int>::iterator index = index_map_.find(elv);
  if(index == index_map_.end())
  {
    CCLOG("StrengthencostDataTable TypeId not found! Id: %d", elv);
    assert(false);
    return NULL;
  }
  return strengthencost_data_table_->at(index->second);
}

CCArray* StrengthencostDataTable::GetAllStrengthencostId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void StrengthencostDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  StrengthencostData *data = new StrengthencostData();
  data->elv = String2Int(row[i++]);
  data->q1cost = String2Int(row[i++]);
  data->q1count = String2Int(row[i++]);
  data->q2cost = String2Int(row[i++]);
  data->q2count = String2Int(row[i++]);
  data->q3cost = String2Int(row[i++]);
  data->q3count = String2Int(row[i++]);
  data->q4cost = String2Int(row[i++]);
  data->q4count = String2Int(row[i++]);
  data->q5cost = String2Int(row[i++]);
  data->q5count = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->elv, strengthencost_data_table_->size()));
  strengthencost_data_table_->push_back(data);
}

