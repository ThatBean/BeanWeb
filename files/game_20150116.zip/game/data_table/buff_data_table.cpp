#include "buff_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

BuffDataTable::BuffDataTable()
{
  buff_data_table_ = new vector<BuffData*>();
}

BuffDataTable::~BuffDataTable()
{
  for (vector<BuffData*>::iterator itr = buff_data_table_->begin();
  itr != buff_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete buff_data_table_;
}

bool BuffDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

BuffData* BuffDataTable::GetBuff(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("BuffDataTable TypeId not found!! TypeId: %d", id);
    assert(false);
    return NULL;
  }
  return buff_data_table_->at(index->second);
}

void BuffDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  BuffData *data = new BuffData();
  data->id = String2Int(row[i++]);
  data->name = LanguageDataTable::FormatLanguageKey("buff", "name", data->id);
  i++;
  data->description = LanguageDataTable::FormatLanguageKey("buff", "Desc", data->id);//row[i++];
  i++;
  data->flag = String2Int(row[i++]);
  data->flagSwitch = String2Bool(row[i++]);
  data->flagPlus = String2Int(row[i++]);
  data->type = String2Int(row[i++]);  
  data->attack_status_ = String2Int(row[i++]);
  data->effect = row[i++];
  data->interrupt = String2Int(row[i++]);
  data->immuneType = String2Int(row[i++]);
  data->flagAtkPlus = String2Float(row[i++]);
  data->hpmultiple = String2Float(row[i++]);
  data->attack_added_multiple_ = String2Float(row[i++]);
  data->defense_physics_multiple_ = String2Float(row[i++]);
  data->defense_magic_multiple_ = String2Float(row[i++]);
  
  data->by_damage_multiple = String2Float(row[i++]);
  data->absorbShieldMultiple = String2Float(row[i++]);
  data->absorbShieldCount = String2Int(row[i++]);
  data->time = String2Float(row[i++]);
  data->movespeed = String2Float(row[i++]);
  data->attackspeed = String2Float(row[i++]);
  data->byhealplus  = String2Float(row[i++]);
  data->hpparam = String2Float(row[i++]);
  data->hptime = String2Float(row[i++]);

  data->physics_hematophagia_multiple_ = String2Float(row[i++]);
  data->magic_hematophagia_multiple_ = String2Float(row[i++]);
  data->physics_thorns_multiple_ = String2Float(row[i++]);
  data->magic_thorns_multiple_ = String2Float(row[i++]);
  
  data->critical_multiple_ = String2Float(row[i++]);
  //data->critical_damage_multiple_ = String2Float(row[i++]); ���ﻹû��

  data->shieldparam = String2Float(row[i++]);
  data->skillparam = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->id, buff_data_table_->size()));
  buff_data_table_->push_back(data);
}

const string& BuffData::GetName()
{
  if (name.empty())
  {
    //name = LanguageDataTable::FormatLanguageKey("buff", "name", id);
    return name;
  }
  return LanguageDataTable::GetInstance()->GetLanguage(name);
} 

const string& BuffData::GetDescription()
{
  if (description.empty())
  {
    //description = LanguageDataTable::FormatLanguageKey("buff", "Desc", id);
    return description;
  }
  return LanguageDataTable::GetInstance()->GetLanguage(description);
}