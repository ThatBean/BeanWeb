#ifndef CARDCAPACITY_DATA_TABLE_H
#define CARDCAPACITY_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class CardcapacityData
{
public:
  /*extend times*/
  int GetCount()
  {
    return count;
  }
  /*current price*/
  int GetPrice()
  {
    return price;
  }
  
private:
  int		count;
  int		price;

  friend class CardcapacityDataTable;
};

class CardcapacityDataTable
{
public:
  CardcapacityDataTable();
  ~CardcapacityDataTable();
  bool InitWithFileName(const char *file_name);
  CardcapacityData* GetCardcapacity(int count);
  int GetTotalExtendTimesCount()
  {
    return cardcapacity_data_table_->size();
  }

protected:
  void parseRow(vector<string> &row);

private:
  vector<CardcapacityData*> *cardcapacity_data_table_;

  map<int, int> index_map_;
};
#endif
