#ifndef NEWUPRARITY_DATA_TABLE_H
#define NEWUPRARITY_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class NewuprarityData
{
public:
  /*���*/
  int GetId()
  {
    return id;
  }
  /*���ǿ���id*/
  int GetCharacterId()
  {
    return CharacterId;
  }
  /*��ǰ����*/
  int GetStar()
  {
    return star;
  }
  /*��������id*/
  int GetCostId1()
  {
    return CostId1;
  }
  /*������������*/
  int GetCostValue1()
  {
    return CostValue1;
  }
  /*��������id*/
  int GetCostId2()
  {
    return CostId2;
  }
  /*������������*/
  int GetCostValue2()
  {
    return CostValue2;
  }
  /*������������*/
  std::vector<int>& GetPropAdd()
  {
    return PropAdd;
  }
private:
  int		id;
  int		CharacterId;
  int		star;
  int		CostId1;
  int		CostValue1;
  int		CostId2;
  int		CostValue2;
  std::vector<int>		PropAdd;

  friend class NewuprarityDataTable;
};

class NewuprarityDataTable
{
public:
  NewuprarityDataTable();
  ~NewuprarityDataTable();
  bool InitWithFileName(const char *file_name);
  NewuprarityData* GetNewuprarity(int id);

  CCArray* GetAllNewuprarityId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<NewuprarityData*> *newuprarity_data_table_;

  map<int, int> index_map_;
};
#endif
