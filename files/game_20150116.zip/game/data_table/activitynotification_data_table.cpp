#include "activitynotification_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

ActivitynotificationDataTable::ActivitynotificationDataTable()
{
  activitynotification_data_table_ = new vector<ActivitynotificationData*>();
}

ActivitynotificationDataTable::~ActivitynotificationDataTable()
{
  for (vector<ActivitynotificationData*>::iterator itr = activitynotification_data_table_->begin();
  itr != activitynotification_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete activitynotification_data_table_;
}

bool ActivitynotificationDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  CCLOG("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ActivitynotificationData* ActivitynotificationDataTable::GetActivitynotification(uint_32 id)
{
  map<uint_32, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("ActivitynotificationDataTable TypeId not found! Id: %ld", id);
    assert(false);
    return NULL;
  }
  return activitynotification_data_table_->at(index->second);
}

ActivitynotificationData* ActivitynotificationDataTable::GetActivitynotificationByIndex(int_32 idx)
{
	int_32 cnt = 0;
	for ( map<uint_32, int>::iterator it = index_map_.begin(); it != index_map_.end(); ++it, ++cnt)
	{
		if (cnt == idx)
		{
			return activitynotification_data_table_->at(it->second);
		}
	}
	return NULL;
}

void ActivitynotificationDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ActivitynotificationData *data = new ActivitynotificationData();
  data->id = String2UInt32(row[i++]);
  data->name = row[i++];
  data->title = row[i++];
  data->text = row[i++];
  data->link = row[i++];
  index_map_.insert(pair<uint_32, int>(data->id, activitynotification_data_table_->size()));
  activitynotification_data_table_->push_back(data);
}

