#ifndef OBSTACLES_DATA_TABLE_H
#define OBSTACLES_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
using namespace std;

class CObstaclesData
{
public:
  //1004001
  int GetTypeID()
  {
    return TypeID;
  }
  //Pine Tree
  string GetName()
  {
    return Name;
  }
  //TID_OBSTACLE_TREE
  string GetTID()
  {
    return TID;
  }
  //res/textures/building/
  string GetSWF()
  {
    return SWF;
  }
  //env_pinetree_1
  string GetExportName()
  {
    return ExportName;
  }
  //env_pinetree_1
  string GetExportNameBase()
  {
    return ExportNameBase;
  }
  //npc_pine_tree2_base
  string GetExportNameBaseNpc()
  {
    return ExportNameBaseNpc;
  }
  //30
  int GetClearTimeSeconds()
  {
    return ClearTimeSeconds;
  }
  //2
  int GetWidth()
  {
    return Width;
  }
  //2
  int GetHeight()
  {
    return Height;
  }
  //Gold
  string GetResource()
  {
    return Resource;
  }
  //false
  bool GetPassable()
  {
    return Passable;
  }
  //Elixir
  string GetClearResource()
  {
    return ClearResource;
  }
  //2000
  int GetClearCost()
  {
    return ClearCost;
  }
  //Diamonds
  string GetLootResource()
  {
    return LootResource;
  }
  //1
  int GetLootCount()
  {
    return LootCount;
  }
  //
  string GetClearEffect()
  {
    return ClearEffect;
  }
  //Tree Pickup
  string GetPickUpEffect()
  {
    return PickUpEffect;
  }
  //20
  int GetRespawnWeight()
  {
    return RespawnWeight;
  }
private:
  int		TypeID;
  string		Name;
  string		TID;
  string		SWF;
  string		ExportName;
  string		ExportNameBase;
  string		ExportNameBaseNpc;
  int		ClearTimeSeconds;
  int		Width;
  int		Height;
  string		Resource;
  bool		Passable;
  string		ClearResource;
  int		ClearCost;
  string		LootResource;
  int		LootCount;
  string		ClearEffect;
  string		PickUpEffect;
  int		RespawnWeight;

  friend class CObstaclesDataTable;
};

class CObstaclesDataTable
{
public:
  CObstaclesDataTable();
  ~CObstaclesDataTable();
  bool InitWithFileName(const char *file_name);
  CObstaclesData* GetObstacles(int type_id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<CObstaclesData*> *obstacles_data_table_;

  map<int, int> index_map_;
};
#endif
