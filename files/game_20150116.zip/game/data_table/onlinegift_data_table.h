#ifndef ONLINEGIFT_DATA_TABLE_H
#define ONLINEGIFT_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class OnlinegiftData
{
public:
  int GetId() {return id;}
  string& GetName() {return name;}
  int GetExp() {return exp;}
  int GetId1() {return id1;}
  int GetCount1() {return count1;}
  int GetId2() {return id2;}
  int GetCount2() {return count2;}
  int GetId_vip() {return id_vip;}
  int GetCount_vip() {return count_vip;}
private:
  int		id;
  string		name;
  int		exp;
  int		id1;
  int		count1;
  int		id2;
  int		count2;
  int		id_vip;
  int		count_vip;

  friend class OnlinegiftDataTable;
};

class OnlinegiftDataTable
{
public:
  OnlinegiftDataTable();
  ~OnlinegiftDataTable();
  bool InitWithFileName(const char *file_name);
  OnlinegiftData* GetOnlinegift(int id);
  int GetOnlinegiftCount();

  CCArray* GetAllOnlinegiftId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<OnlinegiftData*> *onlinegift_data_table_;

  map<int, int> index_map_;
};
#endif
