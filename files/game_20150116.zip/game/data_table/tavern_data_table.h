﻿#ifndef TAVERN_DATA_TABLE_H
#define TAVERN_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class TavernData
{
public:
  /*;奖池ID*/
  int GetId()
  {
    return id;
  }
  /*奖池背景图*/
  string& GetBackground()
  {
    return background;
  }
  /*奖池需要消耗的道具1*/
  int GetRequired_item1()
  {
    return required_item1;
  }
  /*奖池需要消耗的道具2*/
  int GetRequired_item2()
  {
    return required_item2;
  }
  /*道具1的数量*/
  int GetRequired_cost1()
  {
    return required_cost1;
  }
  /*道具2的数量*/
  int GetRequired_cost2()
  {
    return required_cost2;
  }
private:
  int		id;
  string		background;
  int		required_item1;
  int		required_item2;
  int		required_cost1;
  int		required_cost2;

  friend class TavernDataTable;
};

class TavernDataTable
{
public:
  TavernDataTable();
  ~TavernDataTable();
  bool InitWithFileName(const char *file_name);
  TavernData* GetTavern(int id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<TavernData*> *tavern_data_table_;

  map<int, int> index_map_;
};

#endif

