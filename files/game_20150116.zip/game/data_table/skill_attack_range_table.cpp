﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skill_attack_range_table.cpp
//        Author: robbiepan
//          Date: 2013/9/23 13:58
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/23      add
//////////////////////////////////////////////////////////////
#include "skill_attack_range_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/battle/tiled_map/map_constants.h"
#include "language_data_table.h"
#include <cocos2d.h>

SkillAttackRangeTable::SkillAttackRangeTable()
{
  memset(skill_attack_range_table_, 0, sizeof(skill_attack_range_table_));
}

SkillAttackRangeTable::~SkillAttackRangeTable()
{
  for (int i = 0; i < MAX_SKILL_UNIT; ++i)
  {
    if (skill_attack_range_table_[i] != NULL)
    {
      SAFE_DEL(skill_attack_range_table_[i]);
    }
  }
}

bool SkillAttackRangeTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

skillAttackRange_t* SkillAttackRangeTable::GetSkillAttackRange(int_32 id)
{
  CCAssert((id >= 0 && id < MAX_SKILL_ATTACK_RANGE_UNIT), "skillValProc id is unvalued!");
  if (skill_attack_range_table_[id] == NULL)
  {
    CCLOG("SkillAttackRangeTable TypeId not found! TypeId: %d", id);
    assert(false);
    return NULL;
  }
  return skill_attack_range_table_[id]->GetData();
}

void SkillAttackRangeTable::parseRow(vector<string> &row)
{
  int i = 0;
  int_32 skill_attack_range_id = 0;  
  skill_attack_range_id = String2Int32(row[i++]);
  CCAssert((skill_attack_range_id >= 0 && skill_attack_range_id < MAX_SKILL_ATTACK_RANGE_UNIT), "skillValProc id is unvalued!");

  SkillAttackRangeData *data = new SkillAttackRangeData();
  data->GetData()->zone_type = String2Int8(row[i++]);
  int_32 offset_x = String2Int32(row[i++]);
  int_32 offset_y = String2Int32(row[i++]);
  int_32 width = String2Float(row[i++]) * taomee::battle::kMapTileAverageLength;
  int_32 height = String2Float(row[i++])* taomee::battle::kMapTileAverageLength;
  if (data->GetData()->zone_type == MW_SKILL_PROCESS_ZONE_TYPE_CIRCLE) 
  {
    data->GetData()->zone_data0 = offset_x;
    data->GetData()->zone_data1 = offset_y;
    data->GetData()->zone_data2 = width;
  }
  else
  {
    int_32 half_width = width/2;
    int_32 half_height = height/2;
    data->GetData()->zone_data0 = half_width + offset_x;
    data->GetData()->zone_data1 = -half_height + offset_y ;
    data->GetData()->zone_data2 = -half_width + offset_x;
    data->GetData()->zone_data3 = -half_height + offset_y;
    data->GetData()->zone_data4 = -half_width + offset_x;
    data->GetData()->zone_data5 = half_height + offset_y;
    data->GetData()->zone_data6 = half_width + offset_x;
    data->GetData()->zone_data7 = half_height + offset_y;
  }

  data->GetData()->val_proc_type = String2Int32(row[i++]);
  data->GetData()->survival_type = String2Int32(row[i++]);

  skill_attack_range_table_[skill_attack_range_id] = data;
}

