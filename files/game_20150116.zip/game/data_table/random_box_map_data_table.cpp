//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: random_box_map_data_table.cpp
//        Author: coldouyang
//          Date: 2015/1/6 18:55
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2015/1/6      add
//////////////////////////////////////////////////////////////
#include "random_box_map_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"


RandomBoxMapDataTable::RandomBoxMapDataTable()
{

}

RandomBoxMapDataTable::~RandomBoxMapDataTable()
{
  for (std::map<int, RandomBoxMapData*>::iterator itr = mDataMap.begin();
    itr != mDataMap.end(); ++itr)
  {
    delete itr->second;
  }
}

bool RandomBoxMapDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

void RandomBoxMapDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  RandomBoxMapData *data = new RandomBoxMapData();
  data->mID = String2Int(row[i++]);
  data->mMapID = String2Int(row[i++]);
  for (int index = 0; index < MAX_RANDOM_BOX_COUNT; ++index)
  {
    data->mBoxs[index] = String2Int(row[i++]);
  }

  data->mLucklyRate = String2Int(row[i++]);
  data->mRareRate = String2Int(row[i++]);
  data->mMaxNormalRate = String2Int(row[i++]);
  for (int index = 0; index < MAX_RANDOM_BOX_COUNT; ++index)
  {
    data->mRequires[index] = String2Int(row[i++]);
  }

  mDataMap.insert(std::make_pair(data->getID(), data));
}

