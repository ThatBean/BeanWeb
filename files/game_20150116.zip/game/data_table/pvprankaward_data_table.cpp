#include "pvprankaward_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
PvpRankAwardDataTable::PvpRankAwardDataTable()
{
  pvprankaward_data_table_ = new vector<PvpRankAwardData*>();
}

PvpRankAwardDataTable::~PvpRankAwardDataTable()
{
  for (vector<PvpRankAwardData*>::iterator itr = pvprankaward_data_table_->begin();
  itr != pvprankaward_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete pvprankaward_data_table_;
}

bool PvpRankAwardDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

PvpRankAwardData* PvpRankAwardDataTable::GetPvprankaward(int rank)
{
  vector<PvpRankAwardData*>::iterator it = pvprankaward_data_table_->begin();
  for ( ; it != pvprankaward_data_table_->end(); ++it)
  {
    if ( (*it)->GetRankRange().size() == 1 )
    {
      if ( (*it)->GetRankRange().front() == rank )
      {
        return (*it);
      }
    }
    else
    {
      if ( rank >= (*it)->GetRankRange().front() && rank <= (*it)->GetRankRange().back() )
      {
        return (*it);
      }
    }    
  }
  cocos2d::CCLog("GetPvpRankAwardError rank:%d", rank);
  return NULL;
}

void PvpRankAwardDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  PvpRankAwardData *data = new PvpRankAwardData();
  data->id = String2Int(row[i++]);
  getIntListFromString(row[i++], data->rank_range_array);
  data->awardMoney = String2Int(row[i++]);
  data->awardExploit = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->id, pvprankaward_data_table_->size()));
  pvprankaward_data_table_->push_back(data);
}

