//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: flop_data_table.h
//        Author: coldouyang
//          Date: 2014/5/15 11:22
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/5/15      add
//////////////////////////////////////////////////////////////

#ifndef FLOP_DATA_TABLE_H
#define FLOP_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class FlopData
{

public:
  FlopData()
  {
    id = 0;
    itemType = 0;
    itemID = 0;
    name.clear();
    itemCount = 0;
    extractionRate = 0;
    getRate = 0;
    min = 0;
    max = 0;
  }

  FlopData(uint_8  id,
           uint_8  itemType,
           uint_32 itemID,
           string  name,
           uint_32 itemCount,
           uint_8  extractionRate,
           uint_32 getRate,
           uint_8  min,
           uint_8  max)
  {
    this->id = id;
    this->itemType = itemType;
    this->itemID = itemID;
    this->name.clear();
    this->name = name;
    this->itemCount = itemCount;
    this->extractionRate = extractionRate;
    this->getRate = getRate;
    this->min = min;
    this->max = max;
  }

  uint_8 GetId() { return id; }
  void SetId(uint_8 newId) { id = newId; }

  uint_8 GetItemType() { return itemType; }
  void SetItemType(uint_8 newType) { itemType = newType; }

  uint_32 GetItemId() { return itemID; }
  void SetItemId(uint_32 value) { itemID = value; }

  string& GetName() { return name; }
  void SetName(const string& value)
  {
    name.clear();
    name = value;
  }  

  uint_32 GetItemCount() { return itemCount; }
  void SetItemCount(uint_32 value) { itemCount = value; }
  
  uint_8 GetExtractionRate() { return extractionRate; }
  void SetExtractionRate(uint_8 value) { extractionRate = value; }  
  
  uint_32 GetRate() { return getRate; }
  void SetGetRate(uint_32 value) { getRate = value; }

  uint_8 GetMin() { return min; }
  void SetMin(uint_8 value) { min = value; }

  uint_8 GetMax() { return max; }
  void SetMax(uint_8 value) { max = value; }

  void InitWithData(FlopData* data)
  {
    this->id = data->GetId();
    this->itemType = data->GetItemType();
    this->itemID = data->GetItemId();
    this->name.clear();
    this->name = data->GetName();
    this->itemCount = data->GetItemCount();
    this->extractionRate = data->GetExtractionRate();
    this->getRate = data->GetRate();
    this->min = data->GetMin();
    this->max = data->GetMax();
  }

private:
  uint_8  id;
  uint_8  itemType;
  uint_32 itemID;
  string  name;
  uint_32 itemCount;
  uint_8  extractionRate;
  uint_32 getRate;
  //unused
  uint_8  min;
  uint_8  max;

  friend class FlopDataTable;
};

class FlopDataTable
{
public:
  FlopDataTable();
  ~FlopDataTable();
  bool InitWithFileName(const char *file_name);
  FlopData* GetBuff(int id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<FlopData*> *buff_data_table_;

  map<int, int> index_map_;
};

#endif