#include "secretshop_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
SecretshopDataTable::SecretshopDataTable()
{
  secretshop_data_table_ = new vector<SecretshopData*>();
}

SecretshopDataTable::~SecretshopDataTable()
{
  for (vector<SecretshopData*>::iterator itr = secretshop_data_table_->begin();
  itr != secretshop_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete secretshop_data_table_;
}

bool SecretshopDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

SecretshopData* SecretshopDataTable::GetSecretshopById(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("SecretshopDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return secretshop_data_table_->at(index->second);
}

SecretshopData* SecretshopDataTable::GetSecretshopByIndex(int index)
{
  assert(index < secretshop_data_table_->size());
  return secretshop_data_table_->at(index);
}

CCArray* SecretshopDataTable::GetAllSecretshopId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void SecretshopDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  SecretshopData *data = new SecretshopData();
  data->id = String2Int(row[i++]);
  data->ItemId = String2Int(row[i++]);
  data->ItemCount = String2Int(row[i++]);
  data->Percent = String2Int(row[i++]);
  data->cashType = String2Int(row[i++]);
  data->cashCount = String2Int(row[i++]);
  data->showtype = row[i++];
  data->desc = row[i++];
  index_map_.insert(pair<int, int>(data->id, secretshop_data_table_->size()));
  secretshop_data_table_->push_back(data);
}

void SecretshopDataTable::ClearAllIsActivated()
{
  for(std::vector<SecretshopData*>::iterator it =  secretshop_data_table_->begin(); it !=secretshop_data_table_->end(); ++it)
  {
    (*it)->setIsActivated(false);
  }
  return;
}