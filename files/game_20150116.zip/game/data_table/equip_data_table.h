#ifndef EQUIP_DATA_TABLE_H
#define EQUIP_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_res_data_table.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;


class EquipData : public BaseResData
{
public:
  int           getID() { return equipId; }
  int           getType() { return kEquipmentType; }
  const std::string&  getIconName() { return icon; }
  const std::string&  getName() { return GetName(); }
  int           getRarity() { return GetQuality(); }
  int           getSellMoney() { return GetSoldMoney(); }
public:

  int getUserHoldCount();

  /*װ��id*/
  int GetEquipId()
  {
    return equipId;
  }
  /*��Ӧicon*/
  string& GetIcon()
  {
    return icon;
  }
  /*װ����*/
  const string& GetName();
  /*Ʒ��

1.��ɫ
2.��ɫ
3.��ɫ
4.��ɫ
5.��ɫ*/
  int GetQuality()
  {
    return quality;
  }
  /*��������1
0��
1HP
2�﹥
3����
4����
5����
6����
7����
8���
9����
10����
11�շ�
12������
13��Ѫ
14����
15ħ��
16����
17��͸
18����
19�غϻ�Ѫ
20�غϻ���
21նɱ*/
  int GetEquipFlag1()
  {
    return EquipFlag1;
  }
  /*����1��ʼֵ*/
  float GetFlag1Value()
  {
    return flag1Value;
  }
  int GetEquipFlag2()
  {
    return EquipFlag2;
  }
  /*����2��ʼֵ*/
  float GetFlag2Value()
  {
    return flag2Value;
  }
  int GetEquipFlag3()
  {
    return EquipFlag3;
  }
  /*����2��ʼֵ*/
  float GetFlag3Value()
  {
    return flag3Value;
  }
  int GetEquipFlag4()
  {
    return EquipFlag4;
  }
  /*����2��ʼֵ*/
  float GetFlag4Value()
  {
    return flag4Value;
  }
  int GetEquipFlag5()
  {
    return EquipFlag5;
  }
  /*����2��ʼֵ*/
  float GetFlag5Value()
  {
    return flag5Value;
  }
  /*�Ƿ�ɳ���*/
  bool GetIsSold()
  {
    return IsSold;
  }
  /*���ۼ۸�*/
  int GetSoldMoney()
  {
    return soldMoney;
  }
  /*ͻ��ʱ�һ��ľ���*/
  int GetBreakExp()
  {
    return breakExp;
  }
  /*����ؿ�*/
  std::vector<int>& GetCheckpointid()
  {
    return checkpointid;
  }

  int getProduceCheckpointCount()
  {
    return checkpointid.size();
  }

  int getProduceCheckpointIDByIndex(int index)
  {
    return checkpointid.at(index);
  }

  CCArray* GetCheckpointid_List()
  {
    CCArray* res_arr = CCArray::create();
    for(std::vector<int>::iterator it =  checkpointid.begin(); it !=checkpointid.end(); ++it)
    {
      CCInteger* obj_var = CCInteger::create(*it);
      res_arr->addObject(obj_var);
    }
    return res_arr;
  }

  /*װ������ȼ�*/
  int GetNeedLv()
  {
    return needLv;
  }
  CCArray* GetFomularEquip_List()
  {
    CCArray* res_arr = CCArray::create();
    for(std::vector<int>::iterator it =  fomularEquip.begin(); it !=fomularEquip.end(); ++it)
    {
      CCInteger* obj_var = CCInteger::create(*it);
      res_arr->addObject(obj_var);
    }
    return res_arr;
  }
  int getFormularCount()
  {
    return fomularEquip.size();
  }
  
  int getFormularIDByIndex(int index)
  {
    return fomularEquip.at(index);
  }
  float getPropertyByType(uint_8 property_type);  
private:
  int		equipId;
  string		icon;
  string		name;
  int		quality;
  int		EquipFlag1;
  float		flag1Value;
  int		EquipFlag2;
  float		flag2Value;
  int		EquipFlag3;
  float		flag3Value;
  int		EquipFlag4;
  float		flag4Value;
  int		EquipFlag5;
  float		flag5Value;
  bool		IsSold;
  int		soldMoney;
  int		breakExp;
  std::vector<int>		checkpointid;
  int		needLv;
  std::vector<int>		fomularEquip;

  friend class EquipDataTable;
};

class EquipDataTable
{
public:
  EquipDataTable();
  ~EquipDataTable();
  bool InitWithFileName(const char *file_name);
  EquipData* GetEquip(int equipid);

  CCArray* GetAllEquipId();
  int getEquipmentCount() { return equip_data_table_->size(); }
  EquipData* getEquipmentByIndex(int index) { return equip_data_table_->at(index); }
protected:
  void parseRow(vector<string> &row);

private:
  vector<EquipData*> *equip_data_table_;

  map<int, int> index_map_;
};
#endif
