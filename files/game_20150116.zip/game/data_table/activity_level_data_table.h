﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: activity_dayth_data_table.h
//        Author: Dylan.gu
//          Date: 2014/5/9 14:05
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/5/9      add
//////////////////////////////////////////////////////////////

#ifndef ACTIVITY_LEVEL_DATA_TABLE_H
#define ACTIVITY_LEVEL_DATA_TABLE_H

#include <map>
#include "engine/base/basictypes.h"
using namespace std;

#define   ACITIVITY_LEVEL_MAX_ITEM_COUNT   4

struct ActivityLevelOneItemInfo
{
  uint_32 itemId;
  uint_32 itemCount;
};

class ActivityLevelData
{
public:
  /*id*/
  uint_16 GetId()
  {
    return id;
  }
  uint_16 GetLevel()
  {
    return level;
  }
  ActivityLevelOneItemInfo GetOneItemInfo(uint_8 index)
  {
    if(index < ACITIVITY_LEVEL_MAX_ITEM_COUNT)
      return activity_level_items[index];
    return activity_level_items[0];
  }
private:
  uint_16       id;
  uint_16		level;
  ActivityLevelOneItemInfo activity_level_items[ACITIVITY_LEVEL_MAX_ITEM_COUNT];

  friend class ActivityLevelDataTable;
};

class ActivityLevelDataTable
{
public:
  ActivityLevelDataTable();
  ~ActivityLevelDataTable();
  bool InitWithFileName(const char *file_name);
  ActivityLevelData* GetActivityLevelData(uint_16 id);
  uint_8  GetActivityLevelColumnCount() { return activity_level_data_table_->size(); }

protected:
  void parseRow(vector<string> &row);

private:
  vector<ActivityLevelData*> *activity_level_data_table_;

  map<uint_16, int> index_map_;
};

#endif