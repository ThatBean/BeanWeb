#include "cdkey_reward_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
Cdkey_rewardDataTable::Cdkey_rewardDataTable()
{
  cdkey_reward_data_table_ = new vector<Cdkey_rewardData*>();
}

Cdkey_rewardDataTable::~Cdkey_rewardDataTable()
{
  for (vector<Cdkey_rewardData*>::iterator itr = cdkey_reward_data_table_->begin();
  itr != cdkey_reward_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete cdkey_reward_data_table_;
}

bool Cdkey_rewardDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

Cdkey_rewardData* Cdkey_rewardDataTable::GetCdkey_Reward(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("Cdkey_rewardDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return cdkey_reward_data_table_->at(index->second);
}

CCArray* Cdkey_rewardDataTable::GetAllCdkey_RewardId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void Cdkey_rewardDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  Cdkey_rewardData *data = new Cdkey_rewardData();
  data->id = String2Int(row[i++]);
  data->id1 = String2Int(row[i++]);
  data->number1 = String2Int(row[i++]);
  data->id2 = String2Int(row[i++]);
  data->number2 = String2Int(row[i++]);
  data->id3 = String2Int(row[i++]);
  data->number3 = String2Int(row[i++]);
  data->id4 = String2Int(row[i++]);
  data->number4 = String2Int(row[i++]);
  data->id5 = String2Int(row[i++]);
  data->number5 = String2Int(row[i++]);
  data->id6 = String2Int(row[i++]);
  data->number6 = String2Int(row[i++]);
  data->id7 = String2Int(row[i++]);
  data->number7 = String2Int(row[i++]);
  data->id8 = String2Int(row[i++]);
  data->number8 = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->id, cdkey_reward_data_table_->size()));
  cdkey_reward_data_table_->push_back(data);
}

