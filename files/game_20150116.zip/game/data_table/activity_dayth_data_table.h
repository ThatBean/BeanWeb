﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: activity_dayth_data_table.h
//        Author: Dylan.gu
//          Date: 2014/5/9 14:05
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/5/9      add
//////////////////////////////////////////////////////////////

#ifndef ACTIVITY_DAYTH_DATA_TABLE_H
#define ACTIVITY_DAYTH_DATA_TABLE_H

#include <map>
#include "engine/base/basictypes.h"
using namespace std;

#define   ACITIVITY_DAYTH_MAX_ITEM_COUNT   4

struct ActivityDaythOneItemInfo
{
  uint_32 itemId;
  uint_32 itemCount;
};

class ActivityDaythData
{
public:
  /*id*/
  uint_16 GetId()
  {
    return id;
  }
  uint_16 GetDayth()
  {
    return dayth;
  }
  ActivityDaythOneItemInfo GetOneItemInfo(uint_8 index)
  {
    if(index < ACITIVITY_DAYTH_MAX_ITEM_COUNT)
      return activity_dayth_items[index];
    return activity_dayth_items[0];
  }
private:
  uint_16       id;
  uint_16		dayth;
  ActivityDaythOneItemInfo activity_dayth_items[ACITIVITY_DAYTH_MAX_ITEM_COUNT];

  friend class ActivityDaythDataTable;
};

class ActivityDaythDataTable
{
public:
  ActivityDaythDataTable();
  ~ActivityDaythDataTable();
  bool InitWithFileName(const char *file_name);
  ActivityDaythData* GetActivityDaythData(uint_16 id);
  uint_8  GetActivityDaythColumnCount() { return activity_dayth_data_table_->size(); }

protected:
  void parseRow(vector<string> &row);

private:
  vector<ActivityDaythData*> *activity_dayth_data_table_;

  map<uint_16, int> index_map_;
};

#endif