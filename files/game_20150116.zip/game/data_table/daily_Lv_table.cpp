#include "daily_Lv_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
DailyLevelDataTable::DailyLevelDataTable()
{
	dailyLevel_data_table_ = new vector<DailyLevelData*>();
}

DailyLevelDataTable::~DailyLevelDataTable()
{
	for (vector<DailyLevelData*>::iterator itr = dailyLevel_data_table_->begin();
		itr != dailyLevel_data_table_->end(); ++itr)
	{
		delete *itr;
	}
	delete dailyLevel_data_table_;
}

bool DailyLevelDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;
	cocos2d::CCLog("Loading csv file %s", file_name);

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}

DailyLevelData* DailyLevelDataTable::GetDailyLevelById(int id)
{
	map<int, int>::iterator index = index_map_.find(id);
	if(index == index_map_.end())
	{
		CCLOG("DailyWorkDataTable TypeId not found! Id: %d", id);
		assert(false);
		return NULL;
	}
	return dailyLevel_data_table_->at(index->second);
}


void DailyLevelDataTable::parseRow(vector<string> &row)
{
	int i = 0;
	DailyLevelData *data = new DailyLevelData();
	data->id = String2Int(row[i++]);
	data->levelMin = String2Int(row[i++]);
	data->levelMax = String2Int(row[i++]);
	getIntListFromString(row[i++], data->dailyList);
	
	index_map_.insert(pair<int, int>(data->id, dailyLevel_data_table_->size()));
	dailyLevel_data_table_->push_back(data);
}


