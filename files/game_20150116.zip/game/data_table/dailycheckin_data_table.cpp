﻿#include "dailycheckin_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
DailycheckinDataTable::DailycheckinDataTable()
{
  dailycheckin_data_table_ = new vector<DailycheckinData*>();
}

DailycheckinDataTable::~DailycheckinDataTable()
{
  for (vector<DailycheckinData*>::iterator itr = dailycheckin_data_table_->begin();
  itr != dailycheckin_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete dailycheckin_data_table_;
}

bool DailycheckinDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

DailycheckinData* DailycheckinDataTable::GetDailycheckin(int_8 dayth)
{
  map<int_8, int>::iterator index = index_map_.find(dayth);
  if(index == index_map_.end())
  {
    CCLOG("DailycheckinDataTable TypeId not found! Id: %d", dayth);
    assert(false);
    return NULL;
  }
  return dailycheckin_data_table_->at(index->second);
}

CCArray* DailycheckinDataTable::GetAllDailycheckinId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int_8, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void DailycheckinDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  DailycheckinData *data = new DailycheckinData();
  data->dayth = String2Int8(row[i++]);
  data->itemid = String2Int(row[i++]);
  data->count1 = String2Int(row[i++]);
  data->exp = String2Int(row[i++]);
  data->is_vip = String2Bool(row[i++]);
  data->is_special = String2Bool(row[i++]);
  index_map_.insert(pair<int_8, int>(data->dayth, dailycheckin_data_table_->size()));
  dailycheckin_data_table_->push_back(data);
}

