#include "obstacles_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

CObstaclesDataTable::CObstaclesDataTable()
{
  obstacles_data_table_ = new vector<CObstaclesData*>();
}

CObstaclesDataTable::~CObstaclesDataTable()
{
  for (vector<CObstaclesData*>::iterator itr = obstacles_data_table_->begin();
    itr != obstacles_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete obstacles_data_table_;
}

bool CObstaclesDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

CObstaclesData* CObstaclesDataTable::GetObstacles(int type_id)
{
  map<int, int>::iterator index = index_map_.find(type_id);
  if(index == index_map_.end())
  {
    CCLOG("CObstaclesDataTable TypeId not found! TypeId: %d", type_id);
    assert(false);
    return NULL;
  }
  return obstacles_data_table_->at(index->second);
}

void CObstaclesDataTable::parseRow(vector<string> &row)
{
  CObstaclesData *data = new CObstaclesData();
  data->TypeID = String2Int(row[0]);
  data->Name = row[1];
  data->TID = row[2];
  data->SWF = row[3];
  data->ExportName = row[4];
  data->ExportNameBase = row[5];
  data->ExportNameBaseNpc = row[6];
  data->ClearTimeSeconds = String2Int(row[7]);
  data->Width = String2Int(row[8]);
  data->Height = String2Int(row[9]);
  data->Resource = row[10];
  data->Passable = String2Bool(row[11]);
  data->ClearResource = row[12];
  data->ClearCost = String2Int(row[13]);
  data->LootResource = row[14];
  data->LootCount = String2Int(row[15]);
  data->ClearEffect = row[16];
  data->PickUpEffect = row[17];
  data->RespawnWeight = String2Int(row[18]);
  index_map_.insert(pair<int, int>(data->TypeID, obstacles_data_table_->size()));
  obstacles_data_table_->push_back(data);
}

