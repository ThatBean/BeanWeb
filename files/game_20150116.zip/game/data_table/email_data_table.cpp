#include "email_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
EmailDataTable::EmailDataTable()
{
  email_data_table_ = new vector<EmailData*>();
}

EmailDataTable::~EmailDataTable()
{
  for (vector<EmailData*>::iterator itr = email_data_table_->begin();
  itr != email_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete email_data_table_;
}

bool EmailDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

EmailData* EmailDataTable::GetEmail(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("EmailDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return email_data_table_->at(index->second);
}

CCArray* EmailDataTable::GetAllEmailId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void EmailDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  EmailData *data = new EmailData();
  data->id = String2Int(row[i++]);
  data->name = row[i++];
  data->type = String2Int(row[i++]);
  data->description = row[i++];
  data->Receive = row[i++];
  data->sendtime = row[i++];
  data->saveTime = String2Int(row[i++]);
  data->despatcher = row[i++];
  index_map_.insert(pair<int, int>(data->id, email_data_table_->size()));
  email_data_table_->push_back(data);
}

