//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: aura_data_table.h
//        Author: vic.tang
//          Date: 2014/10/27 17:05
//   Description: 
//
// History:
//     <author>    <time>        <descript>
//     vic.tang    2014/10/27      add
//////////////////////////////////////////////////////////////



#ifndef _AURA_DATA_TABLE_H_
#define _AURA_DATA_TABLE_H_

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"

#define Invalid_Aura_ID 0
#define Invalid_Ability_ID -1
#define Modifier_Max_Count (3)

struct ModifierData
{
	int m_type; //eModifierType
	std::string m_param0;
	std::string m_param1;
	std::string m_param2;
	std::string m_param3;
	ModifierData()
		: m_type(0)
	{

	}

	void Copy( const ModifierData& other)
	{
		this->m_type = other.m_type;
		this->m_param0 = other.m_param0;
		this->m_param1 = other.m_param1;
		this->m_param2 = other.m_param2;
		this->m_param3 = other.m_param3;
	}
};

class AuraData
{
public:
	AuraData();
	~AuraData();

	void InitWithData(const AuraData* data);

	void ResetData();

	int get_id()
	{
		return m_id;
	}

	const std::string & get_icon() const
	{
		return m_icon;
	}

	const std::string& get_effect() const
	{
		return m_effect;
	}

	const std::string& get_effect_stage1() const
	{
		return m_effect_stage1;
	}

	const std::string& get_effect_stage2() const
	{
		return m_effect_stage2;
	}

	const std::string& get_effect_stage3() const
	{
		return m_effect_stage3;
	}

	int get_mod_count() const
	{
		return m_mod_count;
	}

	const ModifierData* getConstModifier( int index ) const
	{
		if ( index >= Modifier_Max_Count )
		{
			return NULL;
		}

		return &m_mod_list[index];
	}

	ModifierData* getModifier( int index )
	{
		if ( index >= Modifier_Max_Count )
		{
			return NULL;
		}

		return &m_mod_list[index];
	}

	float get_time()
	{
		return m_time;
	}

	int get_replace_rule() const
	{
		return replace_rule;
	}

	bool get_gains() const
	{
		return m_gains;
	}

	const std::string& get_aura_status() const
	{
		return m_aura_status;
	}

	int get_interrupt_type() const
	{
		return m_interrupt_type;
	}

	int get_effect_pos() const
	{
		return m_effect_pos;
	}
private:
	int m_id;
	std::string m_name;
	std::string m_desc;
	std::string m_icon;
	std::string m_effect;
	std::string m_effect_stage1;
	std::string m_effect_stage2;
	std::string m_effect_stage3;
	int m_effect_pos; //eEffectPositionType
	int m_interrupt_type;// eInterruptType
	float m_time;

	std::string m_aura_status;
	bool m_gains; // ���滹�Ǽ���
	int replace_rule; // eAuraReplaceRule

	int m_mod_count;
	ModifierData m_mod_list[Modifier_Max_Count];

	friend class AuraDataTable;
};

class AuraDataTable
{
public:
	AuraDataTable();
	~AuraDataTable();
	bool InitWithFileName(const char *file_name);
	const AuraData* GetByID(int id);
protected:
	void parseRow(const std::vector<std::string> &row);
private:
	typedef std::map<int, AuraData*> defAuraDataMap;
	typedef defAuraDataMap::iterator defAuraDataMapIter;
	typedef defAuraDataMap::const_iterator defAuraDataMapConstIter;
	defAuraDataMap data_table_;
};

#endif
