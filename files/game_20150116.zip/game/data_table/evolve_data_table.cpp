#include "evolve_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
EvolveDataTable::EvolveDataTable()
{
  evolve_data_table_ = new vector<EvolveData*>();
}

EvolveDataTable::~EvolveDataTable()
{
  for (vector<EvolveData*>::iterator itr = evolve_data_table_->begin();
  itr != evolve_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete evolve_data_table_;
}

bool EvolveDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

EvolveData* EvolveDataTable::GetEvolve(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("EvolveDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return evolve_data_table_->at(index->second);
}

CCArray* EvolveDataTable::GetAllEvolveId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void EvolveDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  EvolveData *data = new EvolveData();
  data->Id = String2Int(row[i++]);
  data->CardId = String2Int(row[i++]);
  data->StepId = String2Int(row[i++]);
  getIntListFromString(row[i++], data->equipIDs);
  std::vector<int> temp;
  getIntVectorFromString(row[i++], temp);
  data->propAdd.push_back(0);
  for (int i = 0; i < temp.size(); ++i)
  {
    data->propAdd.push_back(temp[i]);
  }
  index_map_.insert(pair<int, int>(data->Id, evolve_data_table_->size()));
  evolve_data_table_->push_back(data);
}

