﻿#ifndef DRAMA_DATA_TABLE_H
#define DRAMA_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class DramaData
{
public:
  uint_32 GetID()
  {
    return id;
  }
  /*;剧情ID*/
  uint_32 GetDramaID()
  {
    return dramaID;
  }
  /*任务ID*/
  uint_32 GetCheckpointID()
  {
    return checkpointID;
  }
  /*开始0，结束1，2表示该段结束*/
  uint_8 GetType()
  {
    return type;
  }
  /*头像位置，分为0,1,2*/
  uint_8 GetPosition()
  {
    return position;
  }
  /*对话的人物头像ID，特殊符号表示“黑幕”*/
  uint_32 GetCid()
  {
    return cid;
  }
  /*对话名称*/
  string& GetName()
  {
    return name;
  }
  /*台词*/
  string& GetDialogue();
  /*对话时的背景音乐*/
  uint_32 GetMusicID()
  {
    return music;
  }
  /*场景*/
  string& GetScene()
  {
    return scene;
  }
  bool GetShake()
  {
    return shake;
  }
private:
  uint_32   id;
  uint_32		dramaID;
  uint_32		checkpointID;
  uint_8		type;
  uint_8		position;
  uint_32		cid;
  string		name;
  string		dialogue;
  uint_32		music;
  string		scene;
  bool      shake;

  friend class DramaDataTable;
};

typedef  vector<DramaData*> drama_list;
typedef drama_list::iterator drama_list_setit_t;

class DramaDataTable
{
public:
  DramaDataTable();
  ~DramaDataTable();
  bool InitWithFileName(const char *file_name);
  DramaData* GetDrama(uint_32 dramaid, uint_32 nodeid);
  uint_32 GetDramaCount(uint_32 dramaid);
  uint_32 GetTalkIDByCheckPointID(uint_32 checkpoint_id, bool is_start);
protected:
  void parseRow(vector<string> &row);

private:
  vector<DramaData*> *drama_data_table_;

private:
  int_32 curr_drama_id_;
  int_32 curr_drama_node_id_;

  map<uint_32, drama_list> index_map_;
};
#endif
