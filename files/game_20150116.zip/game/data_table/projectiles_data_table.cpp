#include "projectiles_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

ProjectilesDataTable::ProjectilesDataTable()
{
  projectiles_data_table_ = new vector<ProjectilesData*>();
}

ProjectilesDataTable::~ProjectilesDataTable()
{
  for (vector<ProjectilesData*>::iterator itr = projectiles_data_table_->begin();
  itr != projectiles_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete projectiles_data_table_;
}

bool ProjectilesDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ProjectilesData* ProjectilesDataTable::GetProjectiles(string name)
{
  map<string, int>::iterator index = index_map_.find(name);
  if(index == index_map_.end())
  {
    CCLOG("ProjectilesDataTable TypeId not found! TypeId: %s", name.c_str());
    assert(false);
    return NULL;
  }
  return projectiles_data_table_->at(index->second);
}

void ProjectilesDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ProjectilesData *data = new ProjectilesData();
  data->Name = row[i++];
  data->ExportName = row[i++];
  data->ParticleEmitter = row[i++];
  data->PositionType = String2Int8(row[i++]);
//   data->Speed = String2Int(row[i++]);
//   data->StartHeight = String2Int(row[i++]);
//   data->StartOffset = String2Int(row[i++]);
  data->ShadowSWF = row[i++];
  data->ShadowExportName = row[i++];
  data->Scale = String2Float(row[i++]);
  data->IsAlphaBlend = String2Bool(row[i++]);
  index_map_.insert(pair<string, int>(data->Name, projectiles_data_table_->size()));
  projectiles_data_table_->push_back(data);
}

