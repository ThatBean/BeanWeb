﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skill_data_table.h
//        Author: robbiepan
//          Date: 2013/9/17 16:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/17      add
//////////////////////////////////////////////////////////////

#ifndef SKILL_DATA_TABLE_H
#define SKILL_DATA_TABLE_H

#include "engine/base/basictypes.h"
#include "game/skill/skill_constants.h"
using namespace std;

// 技能施法类型
enum eCastingType
{
	// 施法一次
	kCastingType_Once = 0,
	// 继续施法多次
	kCastingType_Continuous = 1,
	// 连招
	kCastingType_Combo = 2,
	// 唱歌跳舞（原来的43、44） - -！！！！！
	kCastingType_SingDance = 3,
};

const char skillIdSeparator[2] = "/";

//该结构定义的是一些技能组件..是最小的法术组件
class SkillBase
{
public:
  //名称
  const string& GetName();
  //图标编号
  int_32 GetIconIndex() const
  {
    return icon_index;
  }
  //技能类型
  bool GetSkillType() const
  {
    return skill_type;
  }
  
  // 技能施法类型
  int_8     GetCastingType() const
  {
	  return casting_type;
  }

  // 是否是蓄力技能
  bool      GetPowerSkill() const
  {
    return powerSkill;
  }
  //伤害属性
  int_32 GetDamageType() const
  {
    return damage_type;
  }  
  //适用目标类型
  int_32 GetUseTagType() const
  {
    return use_target_type;
  }
  //能否穿透
  bool GetPenetrate() const
  {
    return penetrate;
  }
  //法术攻击方式
  int_32 GetHitType() const
  {
    return hit_type;
  }
  //火墙类延时期
  int_32 GetDamageTick() const
  {
    return damage_tick;
  }
  //冷却时间
  int_32 GetCDTick() const
  {
    return cd_tick;
  }
  //起手特效骨骼动画
  const string& GetPowerEffect() const
  {
    return powerEffect;
  }
  //蓄力特效骨骼动画
  const string& GetPower2Effect() const
  {
    return power2Effect;
  }
  //自己身上的效果
  int_32 GetSelfBreakId() const
  {
    return self_break_id;
  }
  //飞出去的法术效果图(攻击帧触发)
  int_32 GetTagBreakId() const
  {
    return target_break_id;
  }
  //命中后npc身上的效果
  int_32 GetEffBreakId() const
  {
    return eff_break_id;
  }
  //动作
  const string& GetMotion()
  {
    return motion;
  }
  // 起手动作
  const string& GetPowerMotion1()
  {
    return powerMotion1;
  };    
  // 蓄力动作
  const string& GetPowerMotion2()
  {
    return powerMotion2;
  };        
  // 蓄力时间
  int GetPowerTime()
  {
    return powerTime;
  }               
  // 蓄力时人物颜色
  // 0 正常
  // 1 白色
  int GetHighLight()
  {
    return highLight;
  }
  // 攻击动作
  const string& GetPowerMotion3()
  {
    return powerMotion3;
  }
  //播放动作的次数
  int_8 GetMotionCount() const
  {
    return motion_count;
  }
  //动作速度播放调整
  float GetMotionSpeedRate() const
  {
    return motion_speed_rate;
  }

  //使用该技能自己会变成什么状态(索引fstate.csv内ID)
  const string& GetSelfStatus() const
  {
    return self_status;
  }
  //使用该技能自己会变成上述状态的几率
  int_32 GetSelfStatusRatio() const
  {
    return self_status_ratio;
  }
  //被击中的玩家变成什么状态(索引fstate.csv内ID)【PVP】
  const string& GetTagPlayerStatus() const
  {
    return target_player_status;
  }
  //被击中的目标玩家变成上述状态的几率【PVP】
  int_32 GetTagPlayerStatusRatio() const
  {
    return target_player_status_ratio;
  }
  //被击中的目标npc变成什么状态(索引fstate.csv内ID)【PVE】
  const string& GetTagStatus() const
  {
    return target_status;
  }
  //被击中的目标npc变成上述状态的几率【PVE】
  int_32 GetTagStatusRatio() const
  {
    return target_status_ratio;
  }
  //技能击退距离
  int_32 GetBeatBackDist() const
  {
    return beat_back_dist;
  }
  //被击中后,扣血达到自身血量的此(%)百分比值,产生技能击退效果
  int_32 GetTagBeatBackRatio()  const
  {
    return target_beat_back_ratio;
  }
  int_32    GetDamageSelfPercent() const
  {// 百分比伤害－－对自己
    return damage_self_percent;
  }
  int_32    GetDamgeEnemyPercent() const
  {// 百分比伤害－－对敌人
    return damage_enemy_percent;
  }
  //冲锋距离
  int_32 GetChargeDistance()  const
  {
    return charge_distance;
  }

  int_32 GetInitDamage() const
  {
	  return iniDamage;
  }

  int_32 GetAddDamage() const
  {
	  return addDamage;
  }

  float GetPhyAddedMul() const
  {
	  return phyAddedMul;
  }

  float GetMagAddedMul() const
  {
	  return magAddedMul;
  }

  // 是否倒地
  bool GetBeatDown() const
  {
    return beat_down;
  }
  //技能描述
  const string& GetSkillDesc();
  int_32    getSkillID() { return skill_id; }

  // 成长伤害
  int_32 GetSkillGrowDamage(uint_8 skill_level);
private:
  int_32    skill_id;
  string		name;                         // 名称    
  int_32		icon_index;                   // 图标编号    
  bool          skill_type;                   // 技能类型.false 普通攻击, true 技能攻击
  int_8     casting_type;                     // 技能攻击的技能类型 : for casting guide special(ogi_type = 43 or 44)
  bool      powerSkill;                   // 是否是蓄力技能 false 普通技能，true 蓄力技能
  int_32          damage_type;                  // 伤害类型 false 物理, true 魔法
  int_32		use_target_type;              // 法术适用是目标类型
  bool		    penetrate;                    // 穿透(0,1)
  int_32		hit_type;                     // 法术命中结算范围(多人0,单体一定命中1,单体可能会MISS 2)
  int_32		damage_tick;                  // 延时期(多次伤害的间隔时间,)
  int_32		cd_tick;                      // 技能冷去时间.(COOLINGDOWN)
  string    powerEffect;                // 起手骨骼动画名
  string    power2Effect;               // 蓄力骨骼动画名
  int_32		self_break_id;                // 从自己身上炸出的法术效果的编号
  int_32		target_break_id;              // 在目标点炸开的法术效果的编号( 攻击帧释放的 )     	
  int_32		eff_break_id;                 // 命中後的法术效果的编号	
  string        motion;                       // npc动作
  string    powerMotion1;                 // 起手动作
  string    powerMotion2;                 // 蓄力动作
  int       powerTime;                    // 蓄力时间
  int       highLight;                    // 蓄力时人物颜色
  string    powerMotion3;                 // 攻击动作
  int_8		    motion_count;                 // npc动作的播放次数       
  float		  motion_speed_rate;            // npc动作的播放速度的比率
  string		self_status;                  // 自己会改变的状态
  int_32		self_status_ratio;            // 自己会改变到该状态的机率
  string		target_player_status;         // 目标玩家会改变的状态
  int_32		target_player_status_ratio;   // 目标玩家会改变到该状态的机率
  string		target_status;                // 目标NPC会改变的状态     
  int_32		target_status_ratio;          // 目标NPC会改变到该状态的机率
  int_32		beat_back_dist;               // 技能击退距离
  int_32		target_beat_back_ratio;       // 产生击退动作的條件，被打？%的血
  int_32    damage_self_percent;          // 百分比伤害－－对自己
  int_32    damage_enemy_percent;         // 百分比伤害－－对敌人
  int_32        charge_distance;              // 冲锋距离
  int_32		iniDamage;//初始伤害
  int_32		addDamage;// 成长伤害
  float			phyAddedMul;//ad加成
  float			magAddedMul;//ap加成

  bool          beat_down;                    // 是否倒地
  string		skill_desc;                   // 技能描述	
                                                    
  friend class SkillDataTable;
};                                                  	
                                                        
class SkillDataTable
{
public:                                             	
  SkillDataTable();                                 	
  ~SkillDataTable();                                	
  bool InitWithFileName(const char *file_name);     	
  SkillBase* GetSkill(int_32 id);
  vector<SkillBase*> * getAllSkillArray() { return skill_data_table_; }
protected:                                          // 是否有效(是否存在)
  void parseRow(vector<string> &row);

private:
  vector<SkillBase*> *skill_data_table_;

  map<int_32, int> index_map_;
};
#endif
