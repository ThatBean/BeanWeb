#ifndef MAILMESSAGE_DATA_TABLE_H
#define MAILMESSAGE_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class MailmessageData
{
public:
  /*;邮件事件编号*/
  int GetId()
  {
    return id;
  }
  /*邮件内容*/
  const string& GetData();
private:
  int		id;
  string		data;

  friend class MailmessageDataTable;
};

class MailmessageDataTable
{
public:
  MailmessageDataTable();
  ~MailmessageDataTable();
  bool InitWithFileName(const char *file_name);
  MailmessageData* GetMailmessage(int id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<MailmessageData*> *mailmessage_data_table_;

  map<int, int> index_map_;
};
#endif
