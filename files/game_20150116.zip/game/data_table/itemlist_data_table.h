#ifndef ITEMLIST_DATA_TABLE_H
#define ITEMLIST_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_res_data_table.h"
using namespace std;

class ItemlistData : public BaseResData
{
public:
  int           getID() { return id; }
  int           getType() { return kNormalItemType; }
  const std::string&  getIconName() { return icon; }
  const std::string&  getName() { return GetName(); }
  int           getRarity() { return rarity; }
  int           getSellMoney() { return GetSellPrice(); }
public:
  /*;道具ID*/
  int GetId()
  {
    return id;
  }
  /*道具名称*/
  const string& GetName();

  int GetSubType()
  {
    return subtype;
  }

  bool GetUse_Type()
  {
    return use_type;
  }

  int GetLevel()
  {
    return level;
  }
  
  /*
  int_8 GetVisiableOrNot()
  {
    CCAssert(false, "Call Discard function");

    return 0;
  }
  */
  /*
  int GetType()
  {
    CCAssert(false, "Call Discard function");
    return 0;
  }
  */
  /*图标*/
  string& GetIcon()
  {
    return icon;
  }
  
  int GetRarity()
  {
    return rarity;	
  }

  /*描述*/
  const string& GetDesc();

  int GetAttribute()
  {
    return attribute;
  }

  int GetConditionId()
  {
    return conditionId;
  }

  int GetConditionCount()
  {
    return conditionCount;
  }
  /*lua脚本编号*/
  int GetLua()
  {
    return lua;
  }
  
  bool GetSell()
  {
    return sell;
  }

  int GetSellPrice()
  {
    return sellPrice;
  }

  bool GetRecord()
  {
    return record;
  }

  /*使用描述*/
  string& GetUsedesc()
  {
    return usedesc;
  }

private:
  int		id;
  string		name;
  int       subtype;
  bool      use_type;

  int   level;
  string  icon;
  int   rarity;
  string		desc;
  int   attribute;
  int   conditionId;
  int   conditionCount;
  bool   sell;
  int   sellPrice;
  bool   record;
  string usedesc;
  int		lua;

  friend class ItemlistDataTable;
};

class ItemlistDataTable
{
public:
  ItemlistDataTable();
  ~ItemlistDataTable();
  bool InitWithFileName(const char *file_name);
  ItemlistData* GetItemlist(int id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<ItemlistData*> *itemlist_data_table_;

  map<int, int> index_map_;
};
#endif
