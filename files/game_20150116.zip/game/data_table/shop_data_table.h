//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: shop_data_table.h
//        Author: coldouyang
//          Date: 2014/7/9 21:21
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/9      add
//////////////////////////////////////////////////////////////

#ifndef SHOP_DATA_TABLE_H
#define SHOP_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class ShopData
{
public:

  int getID() { return id; };
  const string& getName();// { return name; }
  int getFuncType(){return functype;};
  int getItemType() { return itemType; };
  int getLimitType() { return limitType; };
  int getLimitCount() { return limitCount; };
  int getItemId() { return itemId; };
  int getItemCount() { return itemCount; }
  string& getIcon() { return icon; };
  string& getType() { return type; };  
  string& getDesc() { return desc; };
  int getCashType() { return cashType; };
  int getCashCount() { return cashCount; };
  int getCashAdd() {return cashAdd;};
  int getCashMax(){return cashMax;};
  int getSale() { return sale; };
  int getShowType();
  //--C++ ���ж� ---------------------------------------------------

  void SuccessBuyItems(int count = 1);
  int getMinVipLimit() { return mMinVipLimit; };
  bool isCountLimit() { return limitType > 1; };
  void setUseCount(int count) { mUseCount = count; };
  void addUseCount(int count) { mUseCount += count; };
  int getHadUsedCount() {return mUseCount;};
  int getLeftCount();  
  void setCoolDownSecond(int second) { mCoolDownSecond = second; };
  int getCoolDownSecond();  
  int getPrice(int hadByTimes = -1);//����~
  int getPriceMultiple(int times);
  void buildShopData();
private:
  int id;
  string	name;
  int functype;
  string  buyCount;
  int	itemType;
  int limitType;
  int limitCount;
  int	itemId;
  int itemCount;
  string icon;
  string	type;
  string	desc;
  //goods
  int cashType;
  int	cashCount;
  int cashAdd;
  int cashMax;
  int	sale;
  
  int showType;
  friend class ShopDataTable;
private:
  int mUseCount;
  int mCoolDownSecond;
  int mMinVipLimit;//ֻ���VIP�����Ч
};

class ShopDataTable
{
public:
  ShopDataTable();
  ~ShopDataTable();
  bool InitWithFileName(const char *file_name);
  ShopData* GetShopById(int id);
  int GetAllShopDataCount();
  ShopData* GetShopByIndex(int index);
  int getShopDataIdByItemId(int item_id);
protected:
  void parseRow(vector<string> &row);

private:
  vector<ShopData*> *shop_data_table_;

  map<int, int> index_map_;
  map<int, int> itemID2ShopDataID_map;

  int shopShowItemCount;
};

#endif