//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: vipbox_data_table.h
//        Author: coldouyang
//          Date: 2014/5/22 15:32
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/5/22      add
//////////////////////////////////////////////////////////////

#ifndef VIPBOX_DATA_TABLE_H
#define VIPBOX_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class VipBoxData
{

public:
  VipBoxData()
  {
    id = 0;
    for (int i = 0; i < 4; ++i)
    {
      itemType[i] = itemId[i] = itemCount[i] = 0;
    }
  }

  VipBoxData(uint_8  id,
  uint_8  itemType1,
  uint_8  itemType2,
  uint_8  itemType3,
  uint_8  itemType4,
  uint_32 itemId1,
  uint_32 itemId2,
  uint_32 itemId3,  
  uint_32 itemId4,
  uint_32 itemCount1,
  uint_32 itemCount2,
  uint_32 itemCount3,
  uint_32 itemCount4)
  {
    this->id = id;
    this->itemType[0] = itemType1;
    this->itemType[1] = itemType2;
    this->itemType[2] = itemType3;
    this->itemType[3] = itemType4;

    this->itemId[0] = itemId1;
    this->itemId[1] = itemId2;
    this->itemId[2] = itemId3;
    this->itemId[3] = itemId4;

    this->itemCount[0] = itemCount1;
    this->itemCount[1] = itemCount2;
    this->itemCount[2] = itemCount3;
    this->itemCount[3] = itemCount4;
  }

  uint_8 GetId() { return id; }
  uint_8 GetItemType(int index) { return itemType[index]; }
  uint_32 GetItemId(int index) { return itemId[index]; }
  uint_32 GetItemCount(int index) { return itemCount[index]; }
  uint_32 GetOriPrice() { return oriPrice; }
  uint_32 GetCurPrice() { return curPrice; } 

  void InitWithData(VipBoxData* data)
  {
    this->id = data->GetId();
    for (int i = 0; i < 4; ++i)
    {
      itemId[i] = data->GetItemId(i);
      itemType[i] = data->GetItemType(i);
      itemCount[i] = data->GetItemCount(i);
    }
  }

private:
  uint_8  id;
  uint_8  itemType[4];
  uint_32 itemId[4];
  uint_32 itemCount[4];
  friend class VipBoxDataTable;
  uint_32 oriPrice;
  uint_32 curPrice;
};

class VipBoxDataTable
{
public:
  VipBoxDataTable();
  ~VipBoxDataTable();
  bool InitWithFileName(const char *file_name);
  VipBoxData* GetBuff(int id);

protected:
  void parseRow(vector<string> &row);
private:
  vector<VipBoxData*> *buff_data_table_;

  map<int, int> index_map_;
};


#endif