#ifndef CHECKPOINTCHA_DATA_TABLE_H
#define CHECKPOINTCHA_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class CheckpointChaData
{
public:
  int GetId()
  {
    return id;
  }
  int GetBattlebg()
  {
    return battlebg;
  }
  string& GetName()
  {
    return name;
  }
  int GetReceivelexp()
  {
    return receivelexp;
  }
  int GetCard_exp()
  {
    return card_exp;
  }
  int GetMoney()
  {
    return money;
  }
  int GetTime()
  {
    return time;
  }
  int GetStill()
  {
    return still;
  }
  int GetBgm()
  {
    return bgm;
  }
  int GetCid1()
  {
    return cid1;
  }
  int GetCid2()
  {
    return cid2;
  }
  int GetCard_level1()
  {
    return card_level1;
  }
  int GetCard_level2()
  {
    return card_level2;
  }
  int GetPrev_id()
  {
    return prev_id;
  }
  int GetCheckpoint_level()
  {
    return checkpoint_level;
  }
  int GetRequire_ap()
  {
    return require_ap;
  }
  int GetItem_rate1()
  {
    return item_rate1;
  }
  int GetItem_rate2()
  {
    return item_rate2;
  }
  int GetItem_rate3()
  {
    return item_rate3;
  }
  int GetItem_rate4()
  {
    return item_rate4;
  }
  int GetItem_type1()
  {
    return item_type1;
  }
  int GetItem_type2()
  {
    return item_type2;
  }
  int GetItem_type3()
  {
    return item_type3;
  }
  int GetItem_type4()
  {
    return item_type4;
  }
  int GetItem_id1()
  {
    return item_id1;
  }
  int GetItem_id2()
  {
    return item_id2;
  }
  int GetItem_id3()
  {
    return item_id3;
  }
  int GetItem_id4()
  {
    return item_id4;
  }
  int GetItem_count1()
  {
    return item_count1;
  }
  int GetItem_count2()
  {
    return item_count2;
  }
  int GetItem_count3()
  {
    return item_count3;
  }
  int GetItem_count4()
  {
    return item_count4;
  }
  string& GetDetails()
  {
    return Details;
  }
private:
  int		id;
  int		battlebg;
  string		name;
  int		receivelexp;
  int		card_exp;
  int		money;
  int		time;
  int		still;
  int		bgm;
  int		cid1;
  int		cid2;
  int		card_level1;
  int		card_level2;
  int		prev_id;
  int		checkpoint_level;
  int		require_ap;
  int		item_rate1;
  int		item_rate2;
  int		item_rate3;
  int		item_rate4;
  int		item_type1;
  int		item_type2;
  int		item_type3;
  int		item_type4;
  int		item_id1;
  int		item_id2;
  int		item_id3;
  int		item_id4;
  int		item_count1;
  int		item_count2;
  int		item_count3;
  int		item_count4;
  string		Details;

  friend class CheckpointChaDataTable;
};

class CheckpointChaDataTable
{
public:
  CheckpointChaDataTable();
  ~CheckpointChaDataTable();
  bool InitWithFileName(const char *file_name);
  CheckpointChaData* GetCheckpointcha(int id);

  CCArray* GetAllCheckpointchaId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<CheckpointChaData*> *checkpointcha_data_table_;

  map<int, int> index_map_;
};
#endif
