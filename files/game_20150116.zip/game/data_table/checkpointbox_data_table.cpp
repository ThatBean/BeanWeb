﻿#include "checkpointbox_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"


CheckpointBoxDataTable::CheckpointBoxDataTable()
{
  checkpointbox_data_table_ = new vector<CheckpointBoxData*>();
}

CheckpointBoxDataTable::~CheckpointBoxDataTable()
{
  for (vector<CheckpointBoxData*>::iterator itr = checkpointbox_data_table_->begin();
  itr != checkpointbox_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete checkpointbox_data_table_;
}

bool CheckpointBoxDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

CheckpointBoxData* CheckpointBoxDataTable::GetCheckpointbox(int box_id)
{
  map<int, int>::iterator index = index_map_.find(box_id);
  if(index == index_map_.end())
  {
    CCLOG("CheckpointBoxDataTable TypeId not found! Id: %d", box_id);
    assert(false);
    return NULL;
  }
  return checkpointbox_data_table_->at(index->second);
}

CCArray* CheckpointBoxDataTable::GetCheckpointboxIdBySection(int_32 section)
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    if (checkpointbox_data_table_->at(it->second)->GetSection() == section )
    {
      CCInteger* obj_var = CCInteger::create(it->first);
      res_arr->addObject(obj_var);
    }
  }
  return res_arr;
}

void CheckpointBoxDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  CheckpointBoxData *data = new CheckpointBoxData();
  data->box_id = String2Int(row[i++]);
  data->icon = String2Int(row[i++]);
  data->section = String2Int(row[i++]);
  data->cost = String2Int(row[i++]);
  data->item_id1 = String2Int(row[i++]);
  data->item_type1 = String2Int(row[i++]);
  data->item_count1 = String2Int(row[i++]);
  data->item_id2 = String2Int(row[i++]);
  data->item_type2 = String2Int(row[i++]);
  data->item_count2 = String2Int(row[i++]);
  data->item_id3 = String2Int(row[i++]);
  data->item_type3 = String2Int(row[i++]);
  data->item_count3 = String2Int(row[i++]);
  data->item_id4 = String2Int(row[i++]);
  data->item_type4 = String2Int(row[i++]);
  data->item_count4 = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->box_id, checkpointbox_data_table_->size()));
  checkpointbox_data_table_->push_back(data);
}

