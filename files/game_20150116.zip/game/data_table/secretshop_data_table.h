#ifndef SECRETSHOP_DATA_TABLE_H
#define SECRETSHOP_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class SecretshopData
{
public:
  /*序号*/
  int getId()
  {
    return id;
  }
  /*物品ID*/
  int getItemId()
  {
    return ItemId;
  }
  /*物品数量*/
  int getItemCount()
  {
    return ItemCount;
  }
  /*出现概率*/
  int getPercent()
  {
    return Percent;
  }
  /*代币ID*/
  int getCashType()
  {
    return cashType;
  }
  /*代币数量*/
  int getCashCount()
  {
    return cashCount;
  }
  /*显示角标
ui_local_text*/
  string& getShowtype()
  {
    return showtype;
  }
  /*道具描述*/
  string& getDesc()
  {
    return desc;
  }

  int getLeftCount()
  {
    return 1 - mUseCount;
  }

  int getUseCount()
  {
    return mUseCount;
  }

  void setUseCount(int count)
  {
    mUseCount = count;
  }

  void addUseCount(int count)
  {
    mUseCount += count;
  }

  bool getIsActivated()
  {
    return mIsActivated;
  }

  void setIsActivated(bool isActivated)
  {
    mIsActivated = isActivated;
  }

private:
  int		id;
  int		ItemId;
  int		ItemCount;
  int		Percent;
  int		cashType;
  int		cashCount;
  string		showtype;
  string		desc;

private:
  int		mUseCount;

  bool		mIsActivated;

  friend class SecretshopDataTable;
};

class SecretshopDataTable
{
public:
  SecretshopDataTable();
  ~SecretshopDataTable();
  bool InitWithFileName(const char *file_name);
  SecretshopData* GetSecretshopById(int id);
  SecretshopData* GetSecretshopByIndex(int index);
  int GetAllSecretshopDataCount() { return secretshop_data_table_->size(); };
  CCArray* GetAllSecretshopId();
  void ClearAllIsActivated();

  int getRefreshTime()
  {
    return mRefreshTime;
  }

  void setRefreshTime(int timestamp)
  {
    mRefreshTime = timestamp;
  }

protected:
  void parseRow(vector<string> &row);

private:
  vector<SecretshopData*> *secretshop_data_table_;

  map<int, int> index_map_;

  int		mRefreshTime;
};
#endif
