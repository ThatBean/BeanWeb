#ifndef CHECKPOINTDAILY_DATA_TABLE_H
#define CHECKPOINTDAILY_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_checkpoint_data_table.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class CheckpointDailyData : public BaseCheckpointData
{
public:
  int           getID() { return id; };
  int           getType() { return 2; };//�����ͼ��ݶ�������Lua:checkpoint_constant
  const string&       getName() { return ck_name; };
  bool          getLocalDropItemData(int index, int& out_id, int& out_count);
  bool          getLocalFirstDropItemData(int index, int& out_id, int& out_count, int& out_type) { return false; };

public:
  int GetId()
  {
    return id;
  }
  string& GetBattlebg()
  {
    return battlebg;
  }
  const string& GetName();
  string& GetIcon()
  {
    return icon;
  }
  int GetJobType()
  {
    return jobType;
  }
  int GetReceivelexp()
  {
    return receivelexp;
  }
  int GetCard_exp()
  {
    return card_exp;
  }
  int GetMoney()
  {
    return money;
  }
  int GetTime()
  {
    return time;
  }
  int GetBgm()
  {
    return bgm;
  }
  int GetCheckpoint_level()
  {
    return checkpoint_level;
  }
  int GetRequire_ap()
  {
    return require_ap;
  }
  int GetItem_rate1()
  {
    return mItemRate[0];
  }
  int GetItem_rate2()
  {
    return mItemRate[1];
  }
  int GetItem_rate3()
  {
    return mItemRate[2];
  }
  int GetItem_rate4()
  {
    return mItemRate[3];
  }
  int GetItem_id1()
  {
    return mItemId[0];
  }
  int GetItem_id2()
  {
    return mItemId[1];
  }
  int GetItem_id3()
  {
    return mItemId[2];
  }
  int GetItem_id4()
  {
    return mItemId[3];
  }
  int GetItem_count1()
  {
    return mItemCount[0];
  }
  int GetItem_count2()
  {
    return mItemCount[1];
  }
  int GetItem_count3()
  {
    return mItemCount[2];
  }
  int GetItem_count4()
  {
    return mItemCount[3];
  }
  std::list<int>& GetCp_monster()
  {
    return monster;
  }
  int GetCp_monster_Num()
  {
	  std::list<int>::iterator itor = monster.begin();
	  int tempIndex = 0;
	  while(itor!=monster.end())
	  {
		  itor++;
		  tempIndex++;
	  } 
	  return tempIndex;
  }
  int getCp_monsterByIndex(int index)
  {
	  std::list<int>::iterator itor = monster.begin();
	  int tempIndex = 0;
	  while(itor!=monster.end())
	  {
		  if(index == tempIndex)
		  {
			  return *itor;
		  }
		  itor++;
		  tempIndex++;
	  } 
	  return NULL;
  }
  int get_cp_type()
  {
	  return cp_type;
  }

  string &getCp_tips()
  {
	  return cp_tips;
  }
  string& GetDetails()
  {
    return Details;
  }
private:
  int		id;
  string		battlebg;
  string		name;
  string		icon;
  int_8     jobType;
  int		receivelexp;
  int		card_exp;
  int		money;
  int		time;
  int		bgm;
  int		checkpoint_level;
  int		require_ap;
  int   mItemRate[4];
  int   mItemId[4];
  int   mItemCount[4];
  std::list<int>	monster;
  int cp_type;
  string cp_tips;
  string		Details;
  string ck_name;

  friend class CheckpointDailyDataTable;
};

class CheckpointDailyDataTable
{
public:
  CheckpointDailyDataTable();
  ~CheckpointDailyDataTable();
  bool InitWithFileName(const char *file_name);
  CheckpointDailyData* GetCheckpointdaily(int id);

  CCArray* GetAllCheckpointdailyId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<CheckpointDailyData*> *checkpointdaily_data_table_;

  map<int, int> index_map_;
};
#endif
