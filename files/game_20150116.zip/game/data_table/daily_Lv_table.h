#ifndef DAILY_LEVEL_TABLE_H
#define DAILY_LEVEL_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class DailyLevelData
{
public:
	/*id*/
	int GetDailyLevelId()
	{
		return id;
	}

	 std::list<int>& GetDailyList()
	 {
		 return dailyList;
	 }
	 int GetDailyListNum()
	 {
		 std::list<int>::iterator itor = dailyList.begin();
		 int tempIndex = 0;
		 while(itor!=dailyList.end())
		 {
			 itor++;
			 tempIndex++;
		 } 
		 return tempIndex;
	 }
	 int GetDailyListByIndex(int index)
	 {
		 std::list<int>::iterator itor = dailyList.begin();
		 int tempIndex = 0;
		 while(itor!=dailyList.end())
		 {
			 if(index == tempIndex)
			 {
				 return *itor;
			 }
			 itor++;
			 tempIndex++;
		 } 
		 return NULL;
	 }
private:
	int		id;
	int		levelMin;
	int     levelMax;
	std::list<int>	dailyList;

	friend class DailyLevelDataTable;
};

class DailyLevelDataTable
{
public:
	DailyLevelDataTable();
	~DailyLevelDataTable();
	bool InitWithFileName(const char *file_name);
	DailyLevelData* GetDailyLevelById(int id);
protected:
	void parseRow(vector<string> &row);

private:
	vector<DailyLevelData*> *dailyLevel_data_table_;

	map<int, int> index_map_;
};
#endif
