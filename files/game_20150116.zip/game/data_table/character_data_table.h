﻿#ifndef CHARACTER_DATA_TABLE_H
#define CHARACTER_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_res_data_table.h"
using namespace std;

enum
{
  kSkillInvaild        = -1,
  kSkillNormalHitNear  = 0,
  kSkillNormalHitFar,
  kSkillSkill,
  kSkillSkill_Little,
  kSkillPassive1,
  kSkillPassive2,
  kSkillWeapon,
  kSkillMAx,
};

enum
{
  kPatrolAreaInvalid  = -1,
  kPatrolAreaCircle   = 0,
  kPatrolAreaTileRect = 1
};

enum
{
  kMonsterLevelNormal       = 0,
  kMonsterLevelLowBoss      = 1,
  kMonsterLevelHighBoss     = 2,
  kMonsterLevelWorldBoss    = 3
};

class CharacterData: public BaseResData
{
public:
  int           getID() { return cid; }
  int           getType() { return kCharacterType; }
  const std::string&  getIconName() { return name; }
  const std::string&  getFullName() { return GetDisplayName(); }
  const std::string&  getName() { return GetShortName(); }
  int           getRarity() { return GetRarity(); }
  int           getSellMoney() { return 0; }
public:
  /**/
  int GetCid()
  {
    return cid;
  }
  /*卡片名称*/
  const string& GetName()
  {
    return name;
  }
  /* 供ui显示的全称 */
  const string& GetDisplayName();

  /* 供ui显示的简称*/
  const string& GetShortName();
  
  /*0 早熟
  1 正常
  2 晚成*/
  int_8 GetGrowth()
  {
    return growth;
  }
  /*星级*/
  int_8 GetRarity()
  {
    return rarity;
  }
  /*资质*/
  int GetQuality()
  {
    return quality;
  }
  /*1 敌人
  0 玩家控制卡片*/
  bool GetIsEnemy()
  {
    return isEnemy;
  }
  /*enum
  {
  kMonsterLevelNormal       = 0,  小兵
  kMonsterLevelLowBoss      = 1,  低级Boss 小兵
  kMonsterLevelHighBoss     = 2,  高级Boss, 大Boss
  kMonsterLevelWorldBoss    = 3   世界Boss
  };*/
  int_8 GetMonsterLevel()
  {
    return monsterLevel;
  }
  /*种族
  0 卡片
  1 人类
  2 骷髅
  3 幽灵
  4 哥布林
  5 树人
  7 鬼族
  8 蜥蜴
  9 龙
  10 石像
  11 巨人
  12 兽人*/
  int_8 GetGender()
  {
    return gender;
  }
  /*职业
  0 战士
  1 弓箭手
  2 法师
  3 僧侣
  4 骑士*/
  int_8 GetJobType()
  {
    return jobType;
  }
  /*移动ai类型*/
  int_8 GetMoveType()
  {
    return moveType;
  }
  /*战斗ai类型*/
  int_8 GetBattleType()
  {
    return battleType;
  }
  /*突破次数*/
  int_8 GetLimitBreak()
  {
    return limitBreak;
  }
  /*初始生命值*/
  int GetIniHp()
  {
    return iniHp;
  }
  int GetAddPhysicsAttack()
  {
	  return addPhysicsAttack;
  }
  int GetAddMagicAttack()
  {
	  return addMagicAttack;
  }

  int	GetHitRate()
  {
	  return hitRate;
  }
  int	GetAddHitRate()
  {
	  return addHitRate;
  }
  int	GetDodge()
  {
	  return dodge;
  }

  int	GetAddDodge()
  {
	  return addDodge;
  }


  int GetAddHp()
  {
	  return addHp;
  }
  /*初始物理攻击力*/
  int GetIniPhysicsAttack()
  {
    return iniPhysicsAttack;
  }
  int GetIniMagicAttack()
  {
	  return iniMagicAttack;
  }

  /**/
  int GetHpFlag()
  {
    return hpFlag;
  }
  /*攻击速度
  （秒/下）*/
  float GetAtkSpeed()
  {
    return atkSpeed;
  }
  /*移动速度
  （格/秒）*/
  float GetMovSpeed()
  {
    return movSpeed;
  }
  /*远程攻击
  移动速度
  （格/秒）

  移进skill.csv*/
  float GetShotSpeed()
  {
    return shotSpeed;
  }
  /*远程攻击
  移动速度倍率*/
  float GetShotSpeedMultiple()
  {
    return shotSpeedMultiple;
  }
  /*1 弱点是炎属性（对冰属性有抗性）
  2 弱点是冰属性（对炎属性有抗性）*/
  int_8 GetWeakFlag()
  {
    return weakFlag;
  }
  /*物理防御力*/
  int GetPhysicsDef()
  {
    return physicsDef;
  }
  /*魔法防御力*/
  int GetMagicDef()
  {
    return magicDef;
  }
  /*物理防御倍率*/
  float GetDefPhysicsRate()
  {
    return defPhysicsRate;
  }
  /*魔法防御倍率*/
  float GetDefMagicRate()
  {
    return defMagicRate;
  }
  /*暴击*/
  float GetCritical()
  {
    return critical;
  }

  float GetCriticalDamage()
  {
	  return critical_damage;
  }

  /*防守？*/
  int GetGuard()
  {
    return guard;
  }
  /*攻击半径*/
  float GetAttackRange()
  {
    return attackRange;
  }
  /*身体半径*/
  float GetBodyRange()
  {
    return bodyRange;
  }
  /*身体高度，所占格子*/
  int_8 GetBodyHeight()
  {
    return bodyHeight;
  }
  float GetSkeletonScale()
  {
    return skeletonScale;
  }
  /*警戒类型
  0 圆形
  1 矩形*/
  int_8 GetPatrolType()
  {
    return patrolType;
  }
  /*警戒半径/宽*/
  float GetPatrolParam1()
  {
    return patrolParam1;
  }
  /*警戒高*/
  float GetPatrolParam2()
  {
    return patrolParam2;
  }
  /*调用动画id*/
  int GetMotionId()
  {
    return motionId;
  }
  /*必杀特写画面*/
  string& GetSpmotName()
  {
    return spmotName;
  }
  /*右手武器*/
  int GetWeaponId()
  {
    return weaponId;
  }
  /*左手武器*/
  int GetWeaponId2()
  {
    return weaponId2;
  }
  int GetSkillCost()
  {
    return skillCost;
  }
  int GetSkillId(int skill_type)
  {
    return skillId[skill_type];
  }
  /*必杀技释放比率*/
  int GetSkillRate()
  {
    return skillRate;
  }
  /*被动技能1解锁需要的等级*/
  int GetUnlockLevel1()
  {
    return unlockLevel1;
  }
  /*被动技能1解锁需要完成的任务id*/
  int GetUnlockQuest1()
  {
    return unlockQuest1;
  }
  /*被动技能2解锁需要的等级*/
  int GetUnlockLevel2()
  {
    return unlockLevel2;
  }
  /*被动技能2解锁需要完成的任务id*/
  int GetUnlockQuest2()
  {
    return unlockQuest2;
  }
  const string& GetProfile();
  
  int GetTalkID()
  {
    return talk_id;
  }
  int getUnlockSkill1()
  {

	  return unlockSkill_1;
  }
  int getUnlockSkill2()
  {
	  return unlockSkill_2;
  }
  int getUnlockSkill3()
  {
	  return unlockSkill_3;
  }

  float getInitPropertyByType(uint_8 property_type);
  float getAddPropertyByType(uint_8 property_type);
private:
  int		cid;
  string		name;
  string  displayName;
  string  shortName;
  int_8		growth;
  int_8		rarity;
  int		quality;
  bool		isEnemy;
  int_8   monsterLevel;
  int_8		gender;
  int_8		jobType;
  int_8		moveType;
  int_8		battleType;
  int_8		limitBreak;
  int		iniHp;
  int		iniPhysicsAttack;
  int		iniMagicAttack;
  int   addHp;
  int   addPhysicsAttack;
  int   addMagicAttack;

  int	hitRate;
  int	addHitRate;
  int	dodge;
  int	addDodge;

  int		hpFlag;
  float		atkSpeed;
  float		movSpeed;
  float		shotSpeed;
  float		shotSpeedMultiple;
  int_8		weakFlag;
  int		physicsDef;
  int   magicDef;
  float		defPhysicsRate;
  float		defMagicRate;
  float		critical;
  float		critical_damage;
  int		guard;
  float		attackRange;
  float		bodyRange;
  int_8		bodyHeight;
  float   skeletonScale;
  int_8		patrolType;
  float		patrolParam1;
  float		patrolParam2;
  int		motionId;
  string		spmotName;
  int		weaponId;
  int		weaponId2;
  int   skillCost;
  int   skillId[kSkillMAx];
  int		skillRate;
  int		unlockLevel1;
  int		unlockQuest1;
  int		unlockLevel2;
  int		unlockQuest2;
  string    profile;
  int_32	talk_id;
  int       unlockSkill_1;
  int		unlockSkill_2;
  int		unlockSkill_3;
  
  friend class CharacterDataTable;
};

class CharacterDataTable
{
public:
  CharacterDataTable();
  ~CharacterDataTable();
  bool InitWithFileName(const char *file_name);
  CharacterData* GetCharacter(int cid);
  const vector<int>& GetAllCharacterID() { return card_id_container_; }
  cocos2d::CCArray* GetOwnCharacterByRarity(int rarity);

  int getAllCharacterCount() { return card_id_container_.size(); }
  CharacterData* getCharacterByIndex(int index);

protected:
  void parseRow(vector<string> &row);

private:
  vector<CharacterData*> *character_data_table_;

  map<int, int> index_map_;
  vector<int> card_id_container_;
};
#endif

