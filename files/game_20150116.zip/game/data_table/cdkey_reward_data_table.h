#ifndef CDKEY_REWARD_DATA_TABLE_H
#define CDKEY_REWARD_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class Cdkey_rewardData
{
public:
  /*渠道id*/
  int GetId()
  {
    return id;
  }
  /*奖励id1*/
  int GetId1()
  {
    return id1;
  }
  /*奖励数量1*/
  int GetNumber1()
  {
    return number1;
  }
  /*奖励id2*/
  int GetId2()
  {
    return id2;
  }
  /*奖励数量2*/
  int GetNumber2()
  {
    return number2;
  }
  /*奖励id3*/
  int GetId3()
  {
    return id3;
  }
  /*奖励数量3*/
  int GetNumber3()
  {
    return number3;
  }
  /*奖励id4*/
  int GetId4()
  {
    return id4;
  }
  /*奖励数量4*/
  int GetNumber4()
  {
    return number4;
  }
  /*奖励id5*/
  int GetId5()
  {
    return id5;
  }
  /*奖励数量5*/
  int GetNumber5()
  {
    return number5;
  }
  /*奖励id6*/
  int GetId6()
  {
    return id6;
  }
  /*奖励数量6*/
  int GetNumber6()
  {
    return number6;
  }
  /*奖励id7*/
  int GetId7()
  {
    return id7;
  }
  /*奖励数量7*/
  int GetNumber7()
  {
    return number7;
  }
  /*奖励id8*/
  int GetId8()
  {
    return id8;
  }
  /*奖励数量8*/
  int GetNumber8()
  {
    return number8;
  }
private:
  int		id;
  int		id1;
  int		number1;
  int		id2;
  int		number2;
  int		id3;
  int		number3;
  int		id4;
  int		number4;
  int		id5;
  int		number5;
  int		id6;
  int		number6;
  int		id7;
  int		number7;
  int		id8;
  int		number8;

  friend class Cdkey_rewardDataTable;
};

class Cdkey_rewardDataTable
{
public:
  Cdkey_rewardDataTable();
  ~Cdkey_rewardDataTable();
  bool InitWithFileName(const char *file_name);
  Cdkey_rewardData* GetCdkey_Reward(int id);

  CCArray* GetAllCdkey_RewardId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<Cdkey_rewardData*> *cdkey_reward_data_table_;

  map<int, int> index_map_;
};
#endif
