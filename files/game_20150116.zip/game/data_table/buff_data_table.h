#ifndef BUFF_DATA_TABLE_H
#define BUFF_DATA_TABLE_H

#include <string>
#include <vector>
#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class BuffData
{
public:
  BuffData()
  {
    this->id = 0;
    name.clear();
    this->flag = 0;
    this->flagSwitch = true;
    this->flagPlus = 0;
    this->type = 0;
	this->attack_status_ = 0;
    effect.clear();
    this->interrupt = 1;
	this->immuneType = 0;
    this->flagAtkPlus = 0.0f;
    this->hpmultiple = 0.0f;
    this->attack_added_multiple_ = 0.0f;
	this->defense_physics_multiple_ = 0.0f;
	this->defense_magic_multiple_ = 0.0f;
    this->by_damage_multiple = 0.0f;
    this->absorbShieldMultiple = 0.0f;
    this->absorbShieldCount = 0;
    this->time = 0;
    this->movespeed = 0.0f;
	this->attackspeed = 0.0f;
	this->byhealplus = 0.0f;
    this->hpparam = 0.0f;
    this->hptime = 0.0f;
	this->physics_hematophagia_multiple_ = 0.0f;
	this->magic_hematophagia_multiple_ = 0.0f;
	this->physics_thorns_multiple_ = 0.0f;
	this->magic_thorns_multiple_ = 0.0f;
	this->critical_multiple_ = 0.0f;
	this->critical_damage_multiple_ = 0.0f;
    this->shieldparam = -1;
    this->skillparam = 0;
  }
  BuffData(int    bId,
           string bName,
           int		bFlag,
           bool   bSwitch,
           int    bFlagPlus,
           int    bType,
		   int    bAttackStatus,
           int		bEffect,
           int    bInterrupt,
		   int    bImmuneType,
           float  bFlagAtkPlus,
           float  bHpmutiple,
           float  bAtkAddedMul,
		   float  bDefensePhysicsMultiple,
		   float  bDefenseMagicMultiple,
           float  bByDamageMul,
           float  bAbsorbMul,
           int    bAbsorbCnt,
           int		bTime,
           float	bSpeedparam,
		   float	bAttackSpeed,
		   float	bByHealPlus,
           float	bHpparam,
           float	bHptime,
		   float	bPhysicsHematophagiaMultiple,
		   float	bMagicHematophagiaMultiple,
		   float	bPhysicsThornsMultiple,
		   float	bMagicThornsMultiple,
		   float	bCriticalMultiple,
		   float	bCriticalDamageMultiple,
           float	bShieldparam,
           int		bSkillparam)
  {
    this->id = bId;
    name.clear();
    this->name = bName;
    this->flag = bFlag;
    this->flagSwitch = bSwitch;
    this->flagPlus = bFlagPlus;
    this->type = bType;
	this->attack_status_ = bAttackStatus;
    this->effect = bEffect;
    this->interrupt = bInterrupt;
	this->immuneType = bImmuneType;
    this->flagAtkPlus = bFlagAtkPlus;
    this->hpmultiple = bHpmutiple;
    this->attack_added_multiple_ = bAtkAddedMul;
	this->defense_physics_multiple_ = bDefensePhysicsMultiple;
	this->defense_magic_multiple_ = bDefenseMagicMultiple;
    this->by_damage_multiple = bByDamageMul;
    this->absorbShieldMultiple = bAbsorbMul;
    this->absorbShieldCount = bAbsorbCnt;
    this->time = bTime;
    this->movespeed = bSpeedparam;
	this->attackspeed = bAttackSpeed;
	this->byhealplus = bByHealPlus;
    this->hpparam = bHpparam;
    this->hptime = bHptime;
	this->physics_hematophagia_multiple_ = bPhysicsHematophagiaMultiple;
	this->magic_hematophagia_multiple_ = bMagicHematophagiaMultiple;
	this->physics_thorns_multiple_ = bPhysicsThornsMultiple;
	this->magic_thorns_multiple_ = bMagicThornsMultiple;
	this->critical_multiple_ = bCriticalMultiple;
	this->critical_damage_multiple_ = bCriticalDamageMultiple;
    this->shieldparam = bShieldparam;
    this->skillparam = bSkillparam;
  }
  
  
  int GetId()
  {
    return id;
  }
  void SetId(int newId)
  {
    id = newId;
  }
  
  const string& GetName();
  
  const string& GetDescription();

  int GetFlag()
  {
    return flag;
  }
  void SetFlag(int newFlag)
  {
    flag = newFlag;
  }
  
  bool    GetFlagSwitch() { return flagSwitch; }
  void    SetFlagSwitch(bool s) { flagSwitch = s; }
  
  int     GetFlagPlus() { return flagPlus; }
  
  int     GetType() { return type; }
  
  uint_32       get_attack_status() 
  {
	  return attack_status_; 
  }
  void          set_attack_status(uint_32 flag) 
  {
	  attack_status_ = flag; 
  }

  const string& GetEffect()
  {
    return effect;
  }
  void SetEffect(const string& newEffect)
  {
    effect.clear();
    effect = newEffect;
  }
  
  int     GetInterrupt() { return interrupt; }

  int  GetImmuneType()
  {
	  return immuneType;
  }

  void SetImmuneType(int newImmuneType)
  {
	  immuneType = newImmuneType;
  }
  
  float   GetFlagAtkPlus() { return flagAtkPlus; }
  
  float   GetHpmultiple() { return hpmultiple; }
  void    SetHpmultiple(float mul) { hpmultiple = mul; }
  
  float         attack_added_multiple()
  {
	  return attack_added_multiple_; 
  }
  void          set_attack_added_multiple(float mul)
  {
    attack_added_multiple_ = mul;
  }

  float defense_physics_multiple()
  {
	  return defense_physics_multiple_;
  }
  void set_defense_physics_multiple(float newValue)
  {
	  defense_physics_multiple_ = newValue;
  }

  float defense_magic_multiple()
  {
	  return defense_magic_multiple_;
  }

  void set_defense_magic_multiple( float newValue)
  {
	  defense_magic_multiple_ = newValue;
  }

  
  float         GetByDamageMultiple() 
  { 
	  return by_damage_multiple; 
  }
  void          SetByDamageMultiple(float mul)
  {
    by_damage_multiple = mul;
  }
  
  float   GetAbsorbShieldMultiple() { return absorbShieldMultiple; }
  void    SetAbsorbShieldValue(float value) { absorbShieldMultiple = value; }
  
  float   GetAbsorbShieldCount() { return absorbShieldCount; }
  

  float GetTime()
  {
    return time;
  }
  void SetTime(float newTime)
  {
    time = newTime;
  }  

  float GetMoveSpeed()
  {
    return movespeed;
  }

  void SetMoveSpeed(float newMoveSpeed)
  {
    movespeed = newMoveSpeed;
  }

  float GetAttackSpeed()
  {
	  return attackspeed;
  }

  void SetAttackSpeed(float newAttackSpeed)
  {
	  attackspeed = newAttackSpeed;
  }

  float GetByHealPlus()
  {
	  return byhealplus;
  }

  void SetByHealPlus( float newHealPlus)
  {
	  byhealplus = newHealPlus;
  }

  float GetHpparam()
  {
    return hpparam;
  }
  void SetHpparam(float newHpparam)
  {
    hpparam = newHpparam;
  }

  float GetHptime()
  {
    return hptime;
  }
  void SetHptime(float newHpTime)
  {
    hptime = newHpTime;
  }

  float GetPhysicsHematophagiaMultiple()
  {
	  return physics_hematophagia_multiple_;
  }
  
  void SetPhysicsHematophagiaMultiple_( float newVlaue)
  {
	  physics_hematophagia_multiple_ = newVlaue;
  }

  float GetMagicHematophagiaMultiple()
  {
	  return magic_hematophagia_multiple_;
  }

  void SetMagicHematophagiaMultiple_(float newValue)
  {
	  magic_hematophagia_multiple_ = newValue;
  }

  float GetPhysicsThornsMultiple()
  {
	  return physics_thorns_multiple_;
  }

  void SetPhysicsThornsMultiple_(float newValue)
  {
	  physics_thorns_multiple_ = newValue;
  }

  float GetMagicThornsMultiple()
  {
	  return magic_thorns_multiple_;
  }

  void SetMagicThornsMultiple_(float newValue)
  {
	  magic_thorns_multiple_ = newValue;
  }

  float GetCriticalMultiple()
  {
	  return critical_multiple_;
  }

  void SetCriticalMultiple( float newValue)
  {
	  critical_multiple_ = newValue;
  }

  float GetCriticalDamageMultiple() 
  {
	  return critical_damage_multiple_;
  }

  void SetCriticalDamageMultiple(float mul)
  {
	  critical_damage_multiple_ = mul; 
  }

  float GetShieldparam()
  {
    return shieldparam;
  }
  
  int GetSkillparam()
  {
    return skillparam;
  }
  void SetSkillparam(int newSkillparam)
  {
    skillparam = newSkillparam;
  }
  
  void InitWithData(BuffData* data)
  {
    this->id = data->GetId();
    this->name.clear();
    this->name = data->name;//data->GetName();
    this->description = data->description;//data->GetDescription();
    this->flag = data->GetFlag();
    this->flagSwitch = data->GetFlagSwitch();
    this->flagPlus = data->GetFlagPlus();
    this->type = data->GetType();
	this->attack_status_ = data->get_attack_status();
    this->effect = data->GetEffect();
    this->interrupt = data->GetInterrupt();
	this->immuneType = data->GetImmuneType();
    this->flagAtkPlus = data->GetFlagAtkPlus();
    this->hpmultiple = data->GetHpmultiple();
    this->attack_added_multiple_ = data->attack_added_multiple();
	this->defense_physics_multiple_ = data->defense_physics_multiple();
	this->defense_magic_multiple_ = data->defense_magic_multiple();
    this->by_damage_multiple = data->GetByDamageMultiple();
    this->absorbShieldMultiple = data->GetAbsorbShieldMultiple();
    this->absorbShieldCount = data->GetAbsorbShieldCount();
    this->time = data->GetTime();    
    this->movespeed = data->GetMoveSpeed();
	this->attackspeed = data->GetAttackSpeed();
	this->byhealplus = data->GetByHealPlus();
    this->hpparam = data->GetHpparam();
    this->hptime = data->GetHptime();
	this->physics_hematophagia_multiple_ = data->GetPhysicsHematophagiaMultiple();
	this->magic_hematophagia_multiple_ = data->GetMagicHematophagiaMultiple();
	this->physics_thorns_multiple_ = data->GetPhysicsThornsMultiple();
	this->magic_thorns_multiple_ = data->GetMagicThornsMultiple();
	this->critical_multiple_ = data->GetCriticalMultiple();
	this->critical_damage_multiple_ = data->GetCriticalDamageMultiple();
    this->shieldparam = data->GetShieldparam();
    this->skillparam = data->GetSkillparam();
  }
  
private:
  int		id;
  string		name;
  string    description;
  int     flag;
  bool    flagSwitch;
  int     flagPlus;
  int     type;//enum eStatusType
  int     attack_status_;
  string     effect;
  int     interrupt;
  int	  immuneType;
  float   flagAtkPlus;
  float   hpmultiple;
  float         attack_added_multiple_;
  float         defense_physics_multiple_;
  float         defense_magic_multiple_;
  float         by_damage_multiple;
  float   absorbShieldMultiple;
  float   absorbShieldCount;
  float		time;
  float		movespeed;//�ƶ��ٶ�����
  float		attackspeed;
  float		byhealplus;
  float		hpparam;
  float		hptime;

  float		physics_hematophagia_multiple_;
  float		magic_hematophagia_multiple_;
  float		physics_thorns_multiple_;
  float		magic_thorns_multiple_;

  float		critical_multiple_;
  float     critical_damage_multiple_;

  // unsed
  float		shieldparam;
  int     skillparam;

  friend class BuffDataTable;
};

class BuffDataTable
{
public:
  BuffDataTable();
  ~BuffDataTable();
  bool InitWithFileName(const char *file_name);
  BuffData* GetBuff(int id);

protected:
  void parseRow(vector<string> &row);

private:
  vector<BuffData*> *buff_data_table_;

  map<int, int> index_map_;
};
#endif