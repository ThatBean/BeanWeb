#include "showactivity_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
ShowActivityDataTable::ShowActivityDataTable()
{
  showactivity_data_table_ = new vector<ShowActivityData*>();
}

ShowActivityDataTable::~ShowActivityDataTable()
{
  for (vector<ShowActivityData*>::iterator itr = showactivity_data_table_->begin();
  itr != showactivity_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete showactivity_data_table_;
}

bool ShowActivityDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ShowActivityData* ShowActivityDataTable::GetShowactivity(int index_ID)
{
  map<int, int>::iterator index = index_map_.find(index_ID);
  if(index == index_map_.end())
  {
    CCLOG("ShowActivityDataTable TypeId not found! Id: %d", index_ID);
    assert(false);
    return NULL;
  }
  return showactivity_data_table_->at(index->second);
}


CCArray* ShowActivityDataTable::GetAllShowactivityId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void ShowActivityDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ShowActivityData *data = new ShowActivityData();
  data->Activity_Show = String2Int(row[i++]);
  data->Index_ID = String2Int(row[i++]);
  data->Order = String2Int(row[i++]);
  data->Activity_Name = (row[i++]);
  data->Activity_Condition = String2Int(row[i++]);
  //data->ItemFlag = String2Int(row[i++]);
  data->ButtonID = String2Int(row[i++]);
  data->ButtonID_Text = row[i++];
  data->OpenLayerName = String2Int(row[i++]);
  data->Activity_Content = row[i++];
  i++;
  i++;
  i++;
  data->nameId = String2Int(row[i++]);
  data->blackbutton_text = row[i++];
  index_map_.insert(pair<int, int>(data->Index_ID, showactivity_data_table_->size()));
  showactivity_data_table_->push_back(data);
}

