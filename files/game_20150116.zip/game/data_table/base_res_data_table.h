//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: base_res_data_table.h
//        Author: coldouyang
//          Date: 2014/7/24 14:12
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/24      add
//////////////////////////////////////////////////////////////

#ifndef BASE_RES_DATA_TABLE_H
#define BASE_RES_DATA_TABLE_H

#include <string>
#include <map>
#include "engine/base/basictypes.h"
#include "engine/platform/platform_control.h"
#include "game/data_table/data_constant.h"
#include "engine/platform/SingleInstance.h"

using namespace std;

class BaseResData
{
public:
  virtual int           getID() = 0;
  virtual int           getType() = 0;
  virtual const std::string&  getIconName() = 0;//����ICON���ڱ��ڵ�����
  virtual const std::string&  getName() = 0;
  virtual int           getRarity() = 0;//Ʒ��
  //virtual std::string&  getDisplayDesc() = 0;//����,��Ʒ��Ч
  virtual const std::string&  getFullName() { return getName(); };//����ȫ����Ŀǰֻ��character ������ 
  virtual const std::string&  getFullIconPath();//�����ܼ��ص�icon��·����[1.��ͼ��2.pilistСͼ]
  virtual int           getSellMoney() = 0; //���ۼ۸�
  virtual void          dump();
private:
  std::string res_icon_full_path_;
};

class BaseResDataTable : public SingleInstanceObj
{
public:

  static BaseResDataTable* GetInstance();
  virtual ~BaseResDataTable();
  
  void AddResDataToTable(int id, BaseResData* data);
  BaseResData* GetResDataById(int id);  
  void dump();
protected:

  BaseResDataTable();
  bool init();

  std::map<int, BaseResData*> mDataMap;

  static BaseResDataTable* S_;
};

#endif