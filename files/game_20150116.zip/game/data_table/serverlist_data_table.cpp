﻿#include "serverlist_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

ServerListDataTable::ServerListDataTable()
{
  serverlist_data_table_ = new vector<ServerListData*>();
}

ServerListDataTable::~ServerListDataTable()
{
  for (vector<ServerListData*>::iterator itr = serverlist_data_table_->begin();
  itr != serverlist_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete serverlist_data_table_;
}

bool ServerListDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

ServerListData* ServerListDataTable::GetServerlist(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("ServerListDataTable TypeId not found! Id: %d", id);
    //assert(false);
    return NULL;
  }
  return serverlist_data_table_->at(index->second);
}

int ServerListDataTable::GetRecommandServerId()
{
  for(vector<ServerListData*>::iterator itr = serverlist_data_table_->begin();
    itr != serverlist_data_table_->end(); ++itr)
  {
    if((*itr)->GetState() == kServerStateRecommand)
    {
      return (*itr)->GetId();
    }
  }
  return kServerIdInvalid;
}

void ServerListDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  ServerListData *data = new ServerListData();
  data->id = String2Int(row[i++]);
  data->name = row[i++];
  data->IP = row[i++];
  data->state = String2Int(row[i++]);
  data->open_server_time = 0;
  index_map_.insert(pair<int, int>(data->id, serverlist_data_table_->size()));
  serverlist_data_table_->push_back(data);
  data->GetId();
}

void ServerListDataTable::addServerList(int id, string name, string ip,int state,string gateway_ip,int gateway_port,uint_32 open_server_time)
{
    ServerListData *data = new ServerListData();
    data->id = id;
    data->name = name;
    data->IP = ip;
    data->state = state;
    data->gateway_ip = gateway_ip;
    data->gateway_port = gateway_port;
    data->open_server_time = open_server_time;
    index_map_.insert(pair<int, int>(data->id, serverlist_data_table_->size()));
    serverlist_data_table_->push_back(data);
    data->GetId();
}

cocos2d::CCArray* ServerListDataTable::GetServerIdArray()
{
  cocos2d::CCArray *result = cocos2d::CCArray::create();

  for(vector<ServerListData*>::iterator itr = serverlist_data_table_->begin();
    itr != serverlist_data_table_->end(); ++itr)
  {
    result->addObject(cocos2d::CCInteger::create((*itr)->GetId()));
  }
  return result;
}
