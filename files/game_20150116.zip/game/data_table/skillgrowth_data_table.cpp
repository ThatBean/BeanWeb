﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skill_data_table.cpp
//        Author:  kira
//          Date: 2015/1/14 15:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     kira    2015/1/14       add
//////////////////////////////////////////////////////////////
#include "skillgrowth_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "game/battle/tiled_map/map_constants.h"
#include "language_data_table.h"
#include <cocos2d.h>





SkillgrowthData* SkillGrowthDataTable::getSkillGrowth(int id)
{
	map<int, int>::iterator index = index_map_.find(id);
	if(index == index_map_.end())
	{
		CCLOG("SkillGrowthDataTable TypeId not found! TypeId: %d", id);
		assert(false);
		return NULL;
	}
	return skillgrowth_data_table_->at(index->second);
}




SkillGrowthDataTable::SkillGrowthDataTable()
{
	skillgrowth_data_table_ = new vector<SkillgrowthData*>();
}

SkillGrowthDataTable::~SkillGrowthDataTable()
{
	for (vector<SkillgrowthData*>::iterator itr = skillgrowth_data_table_->begin();
		itr != skillgrowth_data_table_->end(); ++itr)
	{
		delete *itr;
	}
	delete skillgrowth_data_table_;
}

bool SkillGrowthDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;
	CCLOG("Loading vip csv file %s", file_name);

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}




void SkillGrowthDataTable::parseRow(vector<string> &row)
{
	int i = 0;
	SkillgrowthData *data = new SkillgrowthData();
	data->id = String2Int(row[i++]);
	data->costType = String2Int(row[i++]);
	data->costCount = String2Int(row[i++]);
	data->levellimit = String2Int(row[i++]);
	data->skillIcon = row[i++];
	index_map_.insert(pair<int, int>(data->id, skillgrowth_data_table_->size()));
	skillgrowth_data_table_->push_back(data);
}








