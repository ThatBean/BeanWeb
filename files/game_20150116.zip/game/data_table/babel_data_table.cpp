#include "babel_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"

bool  BabelData::getLocalDropItemData(int index, int& out_id, int& out_count)
{
  if (index > 0 && index < 5)
  {
    --index;
    out_id = mRewardItemsID[index];
    out_count = mRewardItemsCount[index];
    return true;
  }
  return false;
}
bool  BabelData::getLocalFirstDropItemData(int index, int& out_id, int& out_count, int& out_type)
{
  return false;
} 

BabelDataTable::BabelDataTable()
{
	babel_data_table_ = new vector<BabelData*>();
}

BabelDataTable::~BabelDataTable()
{
	for (vector<BabelData*>::iterator itr = babel_data_table_->begin();
		itr != babel_data_table_->end(); ++itr)
	{
		delete *itr;
	}
	delete babel_data_table_;
}

bool BabelDataTable::InitWithFileName(const char *file_name)
{
	CSVFileParser csv_file;
	CSVFileRow csv_row;
	cocos2d::CCLog("Loading csv file %s", file_name);

	if(!csv_file.InitWithFileName(file_name))
		return false;

	while(csv_file.IsHasMoreLine())
	{
		csv_file.GetNextRow(csv_row);
		parseRow(csv_row);
	}

	return true;
}

BabelData* BabelDataTable::GetBableByCheckPointID(int checkId)
{
	map<int, int>::iterator index = index_map_checkid.find(checkId);
	if(index == index_map_checkid.end())
	{
		CCLOG("BabelDataTable TypeId not found! checkId: %d", checkId);
		assert(false);
		return NULL;
	}
	return babel_data_table_->at(index->second);
}

BabelData*  BabelDataTable::GetBableByID(int id)
{
	map<int, int>::iterator index = index_map_id.find(id);
	if(index == index_map_id.end())
	{
		CCLOG("BabelDataTable TypeId not found! Id: %d", id);
		assert(false);
		return NULL;
	}
	return babel_data_table_->at(index->second);

}

CCArray* BabelDataTable::GetAllBabelId()
{
	CCArray* res_arr = CCArray::create();
	for(std::map<int, int>::iterator it =  index_map_checkid.begin(); it !=index_map_checkid.end(); ++it)
	{
		CCInteger* obj_var = CCInteger::create(it->first);
		res_arr->addObject(obj_var);
	}
	return res_arr;
}
int BabelDataTable::getBabelAllCount()
{
	int count = GetAllBabelId()->count();
	return count;
}

void BabelDataTable::parseRow(vector<string> &row)
{
	int i = 0;
	BabelData *data = new BabelData();
	data->id = String2Int(row[i++]);
	data->checkPointId = String2Int(row[i++]);
	data->battle_bg = String2Int(row[i++]);
	data->battle_bgm = String2Int(row[i++]);
	data->master_id = String2Int(row[i++]);
	data->power = String2Int(row[i++]);
	data->ConditionType = String2Int(row[i++]);
	data->ConditionValue = String2Int(row[i++]);
	data->desc =LanguageDataTable::FormatLanguageKey("babel", "ConditionDesc", data->id);
	i++;
	data->isBoss = String2Bool(row[i++]);
  for (int index = 0; index < 4; ++index)
  {
    data->mRewardItemsID[index] = String2Int(row[i++]);
    data->mRewardItemsCount[index] = String2Int(row[i++]);
    data->mRewardItemsRate[index] = String2Int(row[i++]);
  }
	data->master_act = row[i++];
  data->ck_name = "";
	
	index_map_id.insert(pair<int, int>(data->id, babel_data_table_->size()));
	index_map_checkid.insert(pair<int, int>(data->checkPointId, babel_data_table_->size()));
	babel_data_table_->push_back(data);
  BaseCheckpointDataTable::GetInstance()->AddDataToTable(data->checkPointId, data);
}

const string&	BabelData::getDesc()
{
  return LanguageDataTable::GetInstance()->GetLanguage(desc);
}