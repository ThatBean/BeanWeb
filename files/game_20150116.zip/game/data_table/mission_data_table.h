#ifndef MISSION_DATA_TABLE_H
#define MISSION_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class MissionData
{
public:
  uint_32 GetQuest_id()
  {
    return quest_id;
  }
  uint_32 GetPrev_quest_id()
  {
    return prev_quest_id;
  }
  string& GetTitle()
  {
    return title;
  }
  uint_8 GetReqConditionType()
  {
    return ReqConditionType;
  }
  uint_32 GetReqConditionParm1()
  {
    return ReqConditionParm1;
  }
  uint_32 GetReqCondition2Parm()
  {
    return ReqCondition2Parm;
  }
  uint_32 GetReceiveExp()
  {
    return ReceiveExp;
  }
  uint_32 GetReceiveMoney()
  {
    return ReceiveMoney;
  }
  uint_32 GetReceiveType1()
  {
    return ReceiveType1;
  }
  uint_32 GetReceiveType2()
  {
    return ReceiveType2;
  }
  uint_32 GetReceiveItemId1(int jobType)
  {
    if ( ReceiveItem1List.size() == 0 )
      return 0;
    std::list<int>::iterator it = ReceiveItem1List.begin();
    for (int i = 0; i < jobType && i < ReceiveItem1List.size(); ++i)
    {
      ++it;
    }
    if ( it == ReceiveItem1List.end())
    {
      return *(ReceiveItem1List.begin());
    }
    else
      return *it;
  }

  uint_32 GetReceiveItemId2()
  {
    return ReceiveItemId2;
  }
  uint_32 GetReceiveItemCount1()
  {
    return ReceiveItemCount1;
  }
  uint_32 GetReceiveItemCount2()
  {
    return ReceiveItemCount2;
  }
  string& GetDetails()
  {
    return Details;
  }
private:
  uint_32		quest_id;
  uint_32		prev_quest_id;
  string		title;
  uint_8		ReqConditionType;
  uint_32		ReqConditionParm1;
  uint_32		ReqCondition2Parm;
  uint_32		ReceiveExp;
  uint_32		ReceiveMoney;
  uint_32		ReceiveType1;
  uint_32		ReceiveType2;
  std::list<int> ReceiveItem1List;
  //uint_32		ReceiveItemId1;
  uint_32		ReceiveItemId2;
  uint_32		ReceiveItemCount1;
  uint_32		ReceiveItemCount2;
  string		Details;

  friend class MissionDataTable;
};

class MissionDataTable
{
public:
  MissionDataTable();
  ~MissionDataTable();
  bool InitWithFileName(const char *file_name);
  MissionData* GetMission(uint_32 quest_id);

  CCArray* GetAllMissionId();

protected:
  void initDefaultMission();
  void parseRow(vector<string> &row);

private:
  vector<MissionData*> *mission_data_table_;

  map<uint_32, int> index_map_;
  int mMaxMissionID;
};
#endif
