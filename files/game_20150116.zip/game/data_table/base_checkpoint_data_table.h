//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: base_checkpoint_data_table.h
//        Author: coldouyang
//          Date: 2014/10/28 21:12
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/28      add
//////////////////////////////////////////////////////////////

#ifndef BASE_CHECKPOINT_DATA_TABLE_H
#define BASE_CHECKPOINT_DATA_TABLE_H

#include <string>
#include <map>
#include "engine/base/basictypes.h"
#include "engine/platform/platform_control.h"
#include "game/data_table/data_constant.h"
#include "engine/platform/SingleInstance.h"

using namespace std;

class BaseCheckpointData
{
public:
  virtual int           getID() = 0;
  virtual int           getType() = 0;
  virtual const string&       getName() = 0;
//item_type, item_id, item_count
  //Index��1 ��ʼ���㣬Ϊ�˼�����ǰ����
  virtual bool          getLocalDropItemData(int index, int& out_id, int& out_count) { return false; }
  virtual bool          getLocalFirstDropItemData(int index, int& out_id, int& out_count, int& out_type) { return false; }
  virtual int           getDifficultyType() { return 0; }//�����Ѷ�����
};

class BaseCheckpointDataTable : public SingleInstanceObj
{
public:

  static BaseCheckpointDataTable* GetInstance();
  virtual ~BaseCheckpointDataTable();

  void AddDataToTable(int id, BaseCheckpointData* data);
  BaseCheckpointData* GetDataById(int id);  
  void dump();
protected:

  BaseCheckpointDataTable();
  bool init();

  std::map<int, BaseCheckpointData*> mDataMap;

  static BaseCheckpointDataTable* S_;
};

#endif