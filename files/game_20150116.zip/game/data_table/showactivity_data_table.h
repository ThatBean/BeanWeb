#ifndef SHOWACTIVITY_DATA_TABLE_H
#define SHOWACTIVITY_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class ShowActivityData
{
public:
  /**/
  int GetActivity_Show()
  {
    return Activity_Show;
  }
  /*�������ʾ*/
  int GetIndex_ID()
  {
    return Index_ID;
  }
  /*����ID*/
  int GetOrder()
  {
    return Order;
  }
  /*�˳��*/
  int GetActivity_Condition()
  {
    return Activity_Condition;
  }
  /*�״̬��ʾ*/
  string& GetActivity_Name()
  {
    return Activity_Name;
  }
  /*���*/
  int GetItemFlag()
  {
    return ItemFlag;
  }
  /*��ť����*/
  int GetButtonID()
  {
    return ButtonID;
  }
  /*��ť�ı�ID*/
  string& GetButtonID_Text()
  {
    return ButtonID_Text;
  }
  /*�����Ľ���ID*/
  int GetOpenLayerName()
  {
    return OpenLayerName;
  }
  /*�����*/
  string& GetActivity_Content()
  {
    return Activity_Content;
  }

  int getNameId()
  {
	  return nameId;
  }

  string& getBlackbutton_text()
  {
	  return blackbutton_text;
  }
private:
  int		Activity_Show;
  int		Index_ID;
  int		Order;
  int		Activity_Condition;
  string		Activity_Name;
  int		ItemFlag;
  int		ButtonID;
  string		ButtonID_Text;
  int		OpenLayerName;
  string		Activity_Content;

  int nameId;
  string blackbutton_text;

  friend class ShowActivityDataTable;
};

class ShowActivityDataTable
{
public:
  ShowActivityDataTable();
  ~ShowActivityDataTable();
  bool InitWithFileName(const char *file_name);
  ShowActivityData* GetShowactivity(int index_ID);

  CCArray* GetAllShowactivityId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<ShowActivityData*> *showactivity_data_table_;

  map<int, int> index_map_;
};
#endif
