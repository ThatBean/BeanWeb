#ifndef PVPSKILLINFO_DATA_TABLE_H
#define PVPSKILLINFO_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

enum ePvpSkillMoveType
{
  kPvpSkillMoveTypeNormal,
  kPvpSkillMoveTypeFlash,
  kPvpSkillMoveTypeNULL
};

class PvpSkillInfoData
{
public:
  /*���ܱ��*/
  uint_32 GetSkillId()
  {
    return skillId;
  }
  /*�ƶ�����
  0 ��ͨ�ƶ�
  1 ��
  2 ����*/
  uint_8 GetMoveType()
  {
    return moveType;
  }
  /*���ܳ���ʱ��*/
  float GetSkillTime()
  {
    return skillTime;
  }
  /*pvp���ܱ���*/
  float GetSkillMult()
  {
    return skillMult;
  }
  /*���ܽ������*/
  int GetSkillProcessTimes()
  {
    return skillProcessTimes;
  }
  /*�Ƿ�ΪԶ�̹���
  1��Զ�̹���
  0�����̹���*/
  bool GetIsRangAttack()
  {
    return isRangAttack;
  }
private:
  uint_32		skillId;
  uint_8		moveType;
  float		skillTime;
  float		skillMult;
  int     skillProcessTimes;
  bool		isRangAttack;

  friend class PvpSkillInfoDataTable;
};

class PvpSkillInfoDataTable
{
public:
  PvpSkillInfoDataTable();
  ~PvpSkillInfoDataTable();
  bool InitWithFileName(const char *file_name);
  PvpSkillInfoData* GetPvpskillinfo(uint_32 skillid);

  CCArray* GetAllPvpskillinfoId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<PvpSkillInfoData*> *pvpskillinfo_data_table_;

  map<uint_32, int> index_map_;
};
#endif