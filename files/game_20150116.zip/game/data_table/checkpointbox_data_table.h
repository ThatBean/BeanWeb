﻿#ifndef CHECKPOINTBOX_DATA_TABLE_H
#define CHECKPOINTBOX_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class CheckpointBoxData
{
public:
  /*宝箱id*/
  int GetBox_id()
  {
    return box_id;
  }
  /*宝箱icon*/
  int GetIcon()
  {
    return icon;
  }
  /*所属章节*/
  int GetSection()
  {
    return section;
  }
  /*需要的星星数量*/
  int GetCost()
  {
    return cost;
  }
  /*奖励的物品1*/
  int GetItem_id1()
  {
    return item_id1;
  }
  /*奖励的物品类型1
1.itemlist
2.character
3.experiencecard*/
  int GetItem_type1()
  {
    return item_type1;
  }
  /*奖励的物品数量1*/
  int GetItem_count1()
  {
    return item_count1;
  }
  /*奖励的物品2*/
  int GetItem_id2()
  {
    return item_id2;
  }
  /*奖励的物品类型2*/
  int GetItem_type2()
  {
    return item_type2;
  }
  /*奖励的物品数量2*/
  int GetItem_count2()
  {
    return item_count2;
  }
  /*奖励的物品3*/
  int GetItem_id3()
  {
    return item_id3;
  }
  /*奖励的物品类型3*/
  int GetItem_type3()
  {
    return item_type3;
  }
  /*奖励的物品数量3*/
  int GetItem_count3()
  {
    return item_count3;
  }
  /*奖励的物品4*/
  int GetItem_id4()
  {
    return item_id4;
  }
  /*奖励的物品类型4*/
  int GetItem_type4()
  {
    return item_type4;
  }
  /*奖励的物品数量4*/
  int GetItem_count4()
  {
    return item_count4;
  }
private:
  int		box_id;
  int		icon;
  int		section;
  int		cost;
  int		item_id1;
  int		item_type1;
  int		item_count1;
  int		item_id2;
  int		item_type2;
  int		item_count2;
  int		item_id3;
  int		item_type3;
  int		item_count3;
  int		item_id4;
  int		item_type4;
  int		item_count4;

  friend class CheckpointBoxDataTable;
};

class CheckpointBoxDataTable
{
public:
  CheckpointBoxDataTable();
  ~CheckpointBoxDataTable();
  bool InitWithFileName(const char *file_name);
  CheckpointBoxData* GetCheckpointbox(int box_id);

  CCArray* GetCheckpointboxIdBySection(int_32 section);

protected:
  void parseRow(vector<string> &row);

private:
  vector<CheckpointBoxData*> *checkpointbox_data_table_;

  map<int, int> index_map_;
};
#endif
