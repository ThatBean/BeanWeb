#include "boxlist_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
BoxlistDataTable::BoxlistDataTable()
{
  last_box_id_ = -1;
 }

BoxlistDataTable::~BoxlistDataTable()
{
  for ( map<int, std::vector<BoxlistData*> >::iterator itr = boxlist_data_table_.begin();
    itr != boxlist_data_table_.end(); ++itr)
  {
    for (vector<BoxlistData*>::iterator itr_item = itr->second.begin();
      itr_item != itr->second.end(); ++itr_item)
    {
      delete *itr_item;
    }   
  }
  boxlist_data_table_.clear();
}

bool BoxlistDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}


BoxlistData* BoxlistDataTable::GetAllBoxlistById(int box_id, int idx)
{
  map<int, std::vector<BoxlistData*> >::iterator index = boxlist_data_table_.find(box_id);
  if(index == boxlist_data_table_.end())
  {
    CCLOG("BoxlistDataTable TypeId not found! Id: %d", box_id);
    assert(false);
    return NULL;
  }

  int size_temp = index->second.size();
  if ( idx <= size_temp )
  {
    return index->second.at(idx);
  }

  return NULL;
}
void BoxlistDataTable::parseRow(vector<string> &row)
{
  int i = 1;
  BoxlistData *data = new BoxlistData();
  memset(data, 0, sizeof(data));

  int box_id = String2Int(row[i++]);
  if ( box_id != last_box_id_ )
  {
    last_box_id_ = box_id;
    vector<BoxlistData*> box_item_list;
    box_item_list.push_back(data);
    boxlist_data_table_.insert(pair<int, std::vector<BoxlistData*> >(box_id, box_item_list));    
  }
  else
  {
    map<int, std::vector<BoxlistData*> >::iterator index = boxlist_data_table_.find(box_id);
    index->second.push_back(data);
  }
  i++;
  data->item_type = String2Int(row[i++]);
  data->item_id = String2Int(row[i++]);
  i++;
  data->item_count = String2Int(row[i++]);

}

int BoxlistDataTable::GetBoxItemCount(int box_id)
{
  map<int, std::vector<BoxlistData*> >::iterator index = boxlist_data_table_.find(box_id);
  if(index == boxlist_data_table_.end())
  {
    CCLOG("BoxlistDataTable TypeId not found! Id: %d", box_id);
    assert(false);
    return 0;
  }
  return index->second.size();
}

CCArray* BoxlistDataTable::GetBoxItemList( int box_id )
{
  cocos2d::CCArray* item_array = cocos2d::CCArray::create();

  map<int, std::vector<BoxlistData*> >::iterator index = boxlist_data_table_.find(box_id);
  if(index == boxlist_data_table_.end())
  {
    CCLOG("BoxlistDataTable TypeId not found! Id: %d", box_id);
    assert(false);
    return NULL;
  }
  
  for (vector<BoxlistData*>::iterator itr_item = index->second.begin();
    itr_item != index->second.end(); ++itr_item)
  {
    item_array->addObject(cocos2d::CCInteger::create((*itr_item)->GetItem_type()));
    item_array->addObject(cocos2d::CCInteger::create((*itr_item)->GetItem_id()));
    item_array->addObject(cocos2d::CCInteger::create((*itr_item)->GetItem_count()));
  }
 
  return item_array;
}

