#ifndef STRENGTHENCOST_DATA_TABLE_H
#define STRENGTHENCOST_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class StrengthencostData
{
public:
  /*装备等级*/
  int GetElv()
  {
    return elv;
  }
  /*白色品质1装备*/
  int GetQ1cost()
  {
    return q1cost;
  }
  int GetQ1count()
  {
    return q1count;
  }
  /*白色品质2装备*/
  int GetQ2cost()
  {
    return q2cost;
  }
  int GetQ2count()
  {
    return q2count;
  }
  /*绿色品质装备*/
  int GetQ3cost()
  {
    return q3cost;
  }
  int GetQ3count()
  {
    return q3count;
  }
  /*蓝色品质装备*/
  int GetQ4cost()
  {
    return q4cost;
  }
  int GetQ4count()
  {
    return q4count;
  }
  /*紫色品质装备*/
  int GetQ5cost()
  {
    return q5cost;
  }
  int GetQ5count()
  {
    return q5count;
  }
private:
  int		elv;
  int		q1cost;
  int		q2cost;
  int		q3cost;
  int		q4cost;
  int		q5cost;
  int		q1count;
  int		q2count;
  int		q3count;
  int		q4count;
  int		q5count;

  friend class StrengthencostDataTable;
};

class StrengthencostDataTable
{
public:
  StrengthencostDataTable();
  ~StrengthencostDataTable();
  bool InitWithFileName(const char *file_name);
  StrengthencostData* GetStrengthencost(int elv);

  CCArray* GetAllStrengthencostId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<StrengthencostData*> *strengthencost_data_table_;

  map<int, int> index_map_;
};
#endif
