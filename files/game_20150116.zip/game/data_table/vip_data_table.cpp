﻿#include "vip_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
#include "language_data_table.h"
#include <cocos2d.h>

int VipData::GetPvereset()
{
  return pvereset;
}

VipDataTable::VipDataTable()
{
  mMaxVipLevel = -1;
  vip_data_table_ = new vector<VipData*>();
}

VipDataTable::~VipDataTable()
{
  for (vector<VipData*>::iterator itr = vip_data_table_->begin();
  itr != vip_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete vip_data_table_;
}

bool VipDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  CCLOG("Loading vip csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

VipData* VipDataTable::GetVip(uint_8 id)
{
  map<uint_32, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("VipDataTable TypeId not found! TypeId: %d", id);
    assert(false);
    return NULL;
  }
  return vip_data_table_->at(index->second);
}

void VipDataTable::AddVipData( uint_8 id, uint_32 charge )
{
  for (vector<VipData*>::iterator itr = vip_data_table_->begin();
    itr != vip_data_table_->end(); ++itr)
  {
    if( (*itr)->id == id )
    {
      (*itr)->charge_num = charge;
      break;
    }
  }
}

int_8 VipDataTable::GetVipByCharge( uint_32 charge )
{
  int_8 vip = 0;
  for (vector<VipData*>::iterator itr = vip_data_table_->begin();
    itr != vip_data_table_->end(); ++itr)
  {
    if ( charge < (*itr)->charge_num )
    {
      return vip;
    }
    else
    {
      vip = (*itr)->id;
    }
  }
  return vip;
}

void VipDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  VipData *data = new VipData();
  data->id = String2Int(row[i++]);
  int level = String2Int(row[i++]);
  if (data->id > mMaxVipLevel)
  {
    mMaxVipLevel = data->id;
  }
  data->limitbuygold = String2Int(row[i++]);
  data->limitbuygoldbox = String2Int(row[i++]);
  data->limitbuyexpcard = String2Int(row[i++]);
  data->limitbuyap = String2Int(row[i++]);
  data->limitbuypvp = String2Int(row[i++]);
  data->limitsecretshop = String2Int(row[i++]);
  data->pvereset = String2Int(row[i++]);
  data->cansevendaysreward = String2Int(row[i++]);
  data->canbuygamblingticket = String2Int(row[i++]);
  data->canautobattle = String2Int(row[i++]);
  data->canraidbattle = 0;
  data->limitbuyelite = String2Int(row[i++]);
  data->limitbuyfruit = String2Int(row[i++]);

  data->limitbag = String2Int(row[i++]);
  data->expgift = String2Int(row[i++]);
  data->luckystar = String2Int(row[i++]);

  index_map_.insert(pair<int, int>(data->id, vip_data_table_->size()));
  vip_data_table_->push_back(data);
}

int VipData::GetLimitCountByField(std::string& field)
{
  if (field == "limitbuyap")
  {
    return limitbuyap;
  }

  if (field == "limitbuyexpcard")
  {
    return limitbuyexpcard;
  }
  
  if (field == "limitbuygoldbox")
  {
    return limitbuygoldbox;
  }
  
  if (field == "limitbuygold")
  {
    return limitbuygold;
  }

  if (field == "limitbuyfruit")
  {
    return limitbuyfruit;
  }

  if (field == "pvereset")
  {
	  return pvereset;
  }

  if (field == "limitbag")
  {
	  return limitbag;
  }

  if (field == "expgift")
  {
	  return expgift;
  }

  if (field == "luckystar")
  {
	  return luckystar;
  }

  if (field == "limitbuypvp")
  {
	  return limitbuypvp;
  }

  if (field == "limitsecretshop")
  {
	  return limitsecretshop;
  }





  if (field == "cansevendaysreward")
  {
	  return cansevendaysreward;
  }
  if (field == "canbuygamblingticket")
  {
	  return canbuygamblingticket;
  }
  if (field == "canautobattle")
  {
	  return canautobattle;
  }
  if (field == "canraidbattle")
  {
	  return canraidbattle;
  }
  if (field == "limitbuyelite")
  {
	  return limitbuyelite;
  }
 
  
  
  
  assert(false);
  return 0;
}