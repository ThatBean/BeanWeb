﻿#ifndef RANK_DATA_TABLE_H
#define RANK_DATA_TABLE_H

#include <map>
#include "engine/base/basictypes.h"
using namespace std;

class RankData
{
public:
  /*//等级*/
  uint_16 GetRank()
  {
    return rank;
  }
  /*//总Cost*/
  uint_16 GetCost()
  {
    return cost;
  }
  /*//最大AP*/
  uint_16 GetActivePoint()
  {
    return activePoint;
  }
  /*//朋友数*/
  uint_8 GetFriendsCount()
  {
    return friendsCount;
  }
  /*//累积经验*/
  uint_32 GetTotalXp()
  {
    return totalXp;
  }
  /*//升级需经验*/
  uint_32 GetLevelRequiredXp()
  {
    return levelRequiredXp;
  }
  uint_8 GetDeck()
  {
    return deck;
  }
private:
  uint_16		rank;
  uint_16		cost;
  uint_16		activePoint;
  uint_8		friendsCount;
  uint_32		totalXp;
  uint_32		levelRequiredXp;
  uint_8		deck;

  friend class RankDataTable;
};

class RankDataTable
{
public:
  RankDataTable();
  ~RankDataTable();
  bool InitWithFileName(const char *file_name);
  RankData* GetRank(uint_16 rank);
  uint_8  GetRankColumnCount() { return rank_data_table_->size(); }

  uint_32  GetTeamPosUnlockLevel(uint_8 index);

protected:
  void parseRow(vector<string> &row);

private:
  vector<RankData*> *rank_data_table_;

  map<uint_16, int> index_map_;
};
#endif
