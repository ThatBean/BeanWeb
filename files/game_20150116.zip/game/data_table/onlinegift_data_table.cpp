#include "onlinegift_data_table.h"

#include "engine/csvparser/csv_file_parser.h"
#include "engine/base/utils_string.h"
OnlinegiftDataTable::OnlinegiftDataTable()
{
  onlinegift_data_table_ = new vector<OnlinegiftData*>();
}

OnlinegiftDataTable::~OnlinegiftDataTable()
{
  for (vector<OnlinegiftData*>::iterator itr = onlinegift_data_table_->begin();
  itr != onlinegift_data_table_->end(); ++itr)
  {
    delete *itr;
  }
  delete onlinegift_data_table_;
}

bool OnlinegiftDataTable::InitWithFileName(const char *file_name)
{
  CSVFileParser csv_file;
  CSVFileRow csv_row;
  cocos2d::CCLog("Loading csv file %s", file_name);

  if(!csv_file.InitWithFileName(file_name))
    return false;

  while(csv_file.IsHasMoreLine())
  {
    csv_file.GetNextRow(csv_row);
    parseRow(csv_row);
  }

  return true;
}

OnlinegiftData* OnlinegiftDataTable::GetOnlinegift(int id)
{
  map<int, int>::iterator index = index_map_.find(id);
  if(index == index_map_.end())
  {
    CCLOG("OnlinegiftDataTable TypeId not found! Id: %d", id);
    assert(false);
    return NULL;
  }
  return onlinegift_data_table_->at(index->second);
}

int OnlinegiftDataTable::GetOnlinegiftCount()
{
  return onlinegift_data_table_->size();
}

CCArray* OnlinegiftDataTable::GetAllOnlinegiftId()
{
  CCArray* res_arr = CCArray::create();
  for(std::map<int, int>::iterator it =  index_map_.begin(); it !=index_map_.end(); ++it)
  {
    CCInteger* obj_var = CCInteger::create(it->first);
    res_arr->addObject(obj_var);
  }
  return res_arr;
}
void OnlinegiftDataTable::parseRow(vector<string> &row)
{
  int i = 0;
  OnlinegiftData *data = new OnlinegiftData();
  data->id = String2Int(row[i++]);
  data->name = row[i++];
  data->exp = String2Int(row[i++]);
  data->id1 = String2Int(row[i++]);
  data->count1 = String2Int(row[i++]);
  data->id2 = String2Int(row[i++]);
  data->count2 = String2Int(row[i++]);
  data->id_vip = String2Int(row[i++]);
  data->count_vip = String2Int(row[i++]);
  index_map_.insert(pair<int, int>(data->id, onlinegift_data_table_->size()));
  onlinegift_data_table_->push_back(data);
}

