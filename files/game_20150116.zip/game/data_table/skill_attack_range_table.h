﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skill_attack_range_table.h
//        Author: robbiepan
//          Date: 2013/9/23 13:58
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/23      add
//////////////////////////////////////////////////////////////

#ifndef SKILL_ATTACK_RANGE_TABLE_H
#define SKILL_ATTACK_RANGE_TABLE_H


#include "engine/base/basictypes.h"
#include "game/skill/skill_constants.h"

using namespace std;

class SkillAttackRangeData
{
public:

  //类型 1圆 2四边形
  int_8 GetZoneType()
  {
    return data_.zone_type;
  }
  //数据0
  int_32 GetZoneData0()
  {
    return data_.zone_data0;
  }
  //数据1
  int_32 GetZoneData1()
  {
    return data_.zone_data1;
  }
  //数据2
  int_32 GetZoneData2()
  {
    return data_.zone_data2;
  }
  //数据3
  int_32 GetZoneData3()
  {
    return data_.zone_data3;
  }
  //数据4
  int_32 GetZoneData4()
  {
    return data_.zone_data4;
  }
  //数据5
  int_32 GetZoneData5()
  {
    return data_.zone_data5;
  }
  //数据6
  int_32 GetZoneData6()
  {
    return data_.zone_data6;
  }
  //数据7
  int_32 GetZoneData7()
  {
    return data_.zone_data7;
  }
  //数值结算的类型
  int_32 GetValProcType()
  {
    return data_.val_proc_type;
  }
  //结算区域生存类型
  int_32 GetSurvivalType()
  {
    return data_.survival_type;
  }
  skillAttackRange_t* GetData()
  {
    return &data_;
  }
private:

  skillAttackRange_t data_;
  friend class SkillvalprocDataTable;
};

class SkillAttackRangeTable
{
public:
  SkillAttackRangeTable();
  ~SkillAttackRangeTable();
  bool InitWithFileName(const char *file_name);
  skillAttackRange_t* GetSkillAttackRange(int_32 id);

protected:
  void parseRow(vector<string> &row);

private:
  SkillAttackRangeData* skill_attack_range_table_[MAX_SKILL_UNIT];
};


#endif
