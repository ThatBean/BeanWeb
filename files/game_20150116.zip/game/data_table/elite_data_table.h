﻿#ifndef ELITE_DATA_TABLE_H
#define ELITE_DATA_TABLE_H

#include <string>
#include <vector>
#include <list>
#include <map>
#include "engine/base/basictypes.h"
#include "game/data_table/base_checkpoint_data_table.h"
#include <cocos2d.h>

using namespace std;
using namespace cocos2d;

class DataManager;

class EliteData : public BaseCheckpointData
{
public:
  int           getID() { return cp_id; };
  int           getType() { return 4; };//该类型兼容定义在在Lua:checkpoint_constant
  const string&       getName();
public:
  /*关卡id*/
  int GetCp_id()
  {
    return cp_id;
  }
  /*bossid*/
  int GetBossid()
  {
    return bossid;
  }
  int GetCp_monster()//好通一去取
  {
	  return bossid;
  }
  /*开启等级*/
  int GetCp_lv()
  {
    return cp_lv;
  }
  /*次数控制*/
  int GetCp_count()
  {
    return cp_count;
  }
  /*exp奖励*/
  int GetRankexp()
  {
    return rankexp;
  }
  /*卡牌经验奖励*/
  int GetCardexp()
  {
    return cardexp;
  }
  /*金币奖励*/
  int GetMoney()
  {
    return gold;
  }
  int GetBattlebg()
  {
    return battle_bg;
  }
  int GetBgm()
  {
    return battle_bgm;
  }
  int GetTime()
  {
    return battle_time;
  }
  string& GetIcon()
  {

	  return icon;
  }
  string& GetIconName()
  {
	return iconName;
  }
  int getMapId()
  {
	  return mapId;
  }

  /*奖池1*/
  int GetAward1()
  {
    return award1;
  }
  /*掉落1概率*/
  int GetRand1()
  {
    return rand1;
  }
  /*奖池2*/
  int GetAward2()
  {
    return award2;
  }
  /*掉落2概率*/
  int GetRand2()
  {
    return rand2;
  }
  /*奖池3*/
  int GetAward3()
  {
    return award3;
  }
  /*掉落3概率*/
  int GetRand3()
  {
    return rand3;
  }
  /*奖池4*/
  int GetAward4()
  {
    return award4;
  }
  /*掉落4概率*/
  int GetRand4()
  {
    return rand4;
  }
  /*显示icon*/
  std::list<int>& GetShow_icon()
  {
    return show_icon;
  }
  int_8 Show_icon_Count()
  {
    return show_icon.size();
  }
  int GetShowIconByIndex(int_8 index)
  {
    assert(index >= 0 && index< show_icon.size());
    std::list<int>::iterator it = show_icon.begin();
    for (int i = 0; i < index; ++i)
    {
      ++it;
    }
    return *it;
  }
  float GetScale()
  {
    return fAnimationScale;
  }
private:
  int		cp_id;
  int		bossid;
  int		cp_lv;
  int		cp_count;
  int		rankexp;
  int		cardexp;
  int		gold;
  int		award1;
  int		rand1;
  int		award2;
  int		rand2;
  int		award3;
  int		rand3;
  int		award4;
  int		rand4;
  std::list<int>		show_icon;
  float fAnimationScale;
  int   battle_bg;
  int   battle_bgm;
  int   battle_time;
  string icon;
  string iconName;
  int	mapId;

  

  friend class EliteDataTable;
};

class EliteDataTable
{
public:
  EliteDataTable();
  ~EliteDataTable();
  bool InitWithFileName(const char *file_name);
  EliteData* GetEliteByCheckPointID(int cp_id);
  inline EliteData* GetEliteByIndex(int_8 index)
  {
    return elite_data_table_->at(index);
  }
  int_16  GetEliteCount(){ return elite_data_table_->size(); }

  CCArray* GetAllEliteId();

protected:
  void parseRow(vector<string> &row);

private:
  vector<EliteData*> *elite_data_table_;

  map<int, int> index_map_;
};
#endif
