//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_change_add_self_color.h
//        Author: peteryu
//          Date: 2014/4/21 11:38
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/21      add
//////////////////////////////////////////////////////////////

#ifndef ACTION_CHANGE_ADD_SELF_COLOR_H
#define ACTION_CHANGE_ADD_SELF_COLOR_H

#include "engine/base/cocos2d_wrapper.h"
#include "game/effect/action_shader_base.h"

using namespace cocos2d;

namespace taomee
{

class ActionChangeAddSelfColor : public ActionShaderBase
{
public:
  ActionChangeAddSelfColor();
  virtual ~ActionChangeAddSelfColor();

  /*
  * time:       single round time, time == 0.0 means all add selfcolor to scale_max
  * count:      round count
  * scale_min:  min color factor
  * scale_max:  max color factor
  */
  static ActionChangeAddSelfColor* create(float round_time, int round_count = -1, 
                                          float scale_min = 1.0, float scale_max = 1.5);

  virtual bool isDone(void);

  virtual void start(void);

  virtual void round_start(void);

  virtual void stop(void);

  virtual void step(float dt);

protected:
  float   scale_min_;
  float   scale_max_;
};

}
#endif