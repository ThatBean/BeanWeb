//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_change_color.cpp
//        Author: peteryu
//          Date: 2014/4/1 16:13
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/1      add
//////////////////////////////////////////////////////////////

#include "game/effect/action_change_color.h"
#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_color.h"

namespace taomee{

ActionChangeColor::ActionChangeColor()
{
}

ActionChangeColor::~ActionChangeColor()
{
  
}

ActionChangeColor* ActionChangeColor::create( float round_time, ccColor4F color, int round_count /* = -1*/)
{
  
  ActionChangeColor* action = new ActionChangeColor();
  action->autorelease();
  action->round_time_ = round_time;
  action->round_count_ = round_count;
  action->color_ = color;
  return action;
  
  return NULL;
}

bool ActionChangeColor::isDone( void )
{   
  return ActionShaderBase::isDone();
}

void ActionChangeColor::start(void)
{
  default_shader_program_ = m_pTarget->getShaderProgram();
  shader_program_ = (shader::ProgramChangeColor*)shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderChangeColorTime);
  m_pTarget->setShaderProgram(shader_program_);
  ((shader::ProgramChangeColor*)shader_program_)->SetColor(color_);
}

void ActionChangeColor::round_start(void)
{

}

void ActionChangeColor::stop( void )
{
  m_pTarget->setShaderProgram(default_shader_program_);
  ActionShaderBase::stop();
}

void ActionChangeColor::step(float dt)
{
  ActionShaderBase::step(dt);

  float half_round_time = round_time_ / 2.0f;

  if(cur_round_time_ <= half_round_time)
    ((shader::ProgramChangeColor*)shader_program_)->SetTime(cur_round_time_ / half_round_time);
  else
    ((shader::ProgramChangeColor*)shader_program_)->SetTime(2.0 - cur_round_time_ / half_round_time);
  ((shader::ProgramChangeColor*)shader_program_)->SetColor(color_);
}

}