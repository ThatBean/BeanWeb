//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: UISpriteClipWidget.cpp
//        Author: coldouyang
//          Date: 2014/10/21 18:03
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/21      add
//////////////////////////////////////////////////////////////
#include "game/effect/UISpriteClipWidget.h"
using namespace cocos2d;
using namespace cocos2d::extension;

UISpriteClipWidget::UISpriteClipWidget() : mInnerStencil(NULL)
{

}

UISpriteClipWidget::~UISpriteClipWidget()
{
  CC_SAFE_RELEASE(mInnerStencil);
  mInnerStencil = NULL;
}

UISpriteClipWidget* UISpriteClipWidget::create()
{
  UISpriteClipWidget* pRet = new UISpriteClipWidget();
  if (pRet && pRet->init())
  {
    pRet->autorelease();
    return pRet;
  }
}

void UISpriteClipWidget::setClippingEnabled(bool enable)
{
  static_cast<SpriteClippingNode*>(mClipNode)->setClippingEnabled(enable);
}

void UISpriteClipWidget::initRenderer()
{
  mClipNode = SpriteClippingNode::create();
  m_pRenderer = mClipNode;
  setClippingEnabled(true);
}

void UISpriteClipWidget::addStencilNode(cocos2d::CCNode* node)
{
  if (mInnerStencil == NULL)
  {
    mInnerStencil = CCNode::create();
    mInnerStencil->retain();
    mClipNode->setStencil(mInnerStencil);
  }
  mInnerStencil->addChild(node);
}

void UISpriteClipWidget::setAlphaThreshold(GLfloat fAlphaThreshold)
{
  mClipNode->setAlphaThreshold(fAlphaThreshold);
}

void UISpriteClipWidget::setInverted(bool bInverted)
{
  mClipNode->setInverted(bInverted);
}

//////////////////////////
bool UISpriteClipWidget::tranWidget2ClipWidget(cocos2d::extension::UIWidget* widget, UISpriteClipWidget* clipWidget)
{
  if (widget && clipWidget)
  {
    if (widget->getParent() != NULL)
    {
      UIWidget* parent = widget->getParent();
      widget->retain();
      widget->removeFromParent();
      parent->addChild(clipWidget);
      clipWidget->addChild(widget);
      clipWidget->setZOrder(widget->getZOrder());
      widget->release();
      //clipWidget->setAnchorPoint(widget->getAnchorPoint());
    }
    else
    {
      clipWidget->addChild(widget);
    }
    return true;
  }
  return false;
}

////////////////////////////////////////////////////////
SpriteClippingNode* SpriteClippingNode::create()
{
  SpriteClippingNode *pRet = new SpriteClippingNode();
  if (pRet && pRet->init())
  {
    pRet->autorelease();
  }
  else
  {
    CC_SAFE_DELETE(pRet);
  }

  return pRet;
}

SpriteClippingNode::~SpriteClippingNode()
{

}

void SpriteClippingNode::visit()
{
  if (m_bClippingEnabled)
  {
    CCClippingNode::visit();
  }
  else
  {
    CCNode::visit();
  }
}
