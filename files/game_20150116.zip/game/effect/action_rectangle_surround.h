//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: action_rectangle_surround.h
//        Author: coldouyang
//          Date: 2014/6/27 14:10
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/6/27      add
//////////////////////////////////////////////////////////////

#ifndef ACTION_RECTANGLE_SURROUND_H
#define ACTION_RECTANGLE_SURROUND_H

#include "cocos2d.h"

class RectangleSurroundAction
{
public: 
  
  static cocos2d::CCActionInterval* create(float dt, float bDT, const cocos2d::CCPoint& p0, const cocos2d::CCPoint& p1, float radium, bool is_clockwise);  
  static cocos2d::CCBezierTo* createBezierTo(float time, const cocos2d::CCPoint &end, const cocos2d::CCPoint &control);
}; 

#endif