//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: touch_area_node_factory.h
//        Author: peteryu
//          Date: 2013/10/15 13:57
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/15      add
//////////////////////////////////////////////////////////////

#ifndef TOUCH_AREA_NODE_FACTORY_H
#define TOUCH_AREA_NODE_FACTORY_H

#include <cocos2d.h>
#include "game/army/unit/move_object.h"

#include "game/effect/touch_area_layer.h"

using namespace cocos2d;

namespace taomee{
namespace effect
{
/*
enum eTouchAreaType
{
  kTouchAreaNearAttack,
  kTouchAreaGuard,
  kTouchAreaSkill
};
*/
class TouchAreaNodeFactory
{
private:
  TouchAreaNodeFactory();
  virtual ~TouchAreaNodeFactory();

public:
  static CCNode* CreateAreaNode(army::MoveObject *unit, eTouchAreaType type);
};

} //namespace taomee
} //namespace effect 

#endif