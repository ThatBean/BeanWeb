//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: UISpriteClipWidget.h
//        Author: coldouyang
//          Date: 2014/10/21 18:01
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/21      add
//////////////////////////////////////////////////////////////

#ifndef UISPRITECLIPWIDGET_H
#define UISPRITECLIPWIDGET_H

#include "cocos2d.h"
#include "cocos-ext.h"

class UISpriteClipWidget : public cocos2d::extension::UIWidget
{
public:
  UISpriteClipWidget();
  virtual ~UISpriteClipWidget();
  static UISpriteClipWidget* create();

  void setClippingEnabled(bool enable);

  void addStencilNode(cocos2d::CCNode* node);
  void setAlphaThreshold(GLfloat fAlphaThreshold);
  void setInverted(bool bInverted);

  static bool tranWidget2ClipWidget(cocos2d::extension::UIWidget* widget, UISpriteClipWidget* clipWidget);

protected:
    virtual void initRenderer();
protected:
    cocos2d::CCClippingNode* mClipNode;
    cocos2d::CCNode* mInnerStencil;
};

class SpriteClippingNode : public cocos2d::CCClippingNode
{
public:
  virtual ~SpriteClippingNode();
  static SpriteClippingNode* create();
  virtual void visit();
  void setClippingEnabled(bool enabled) { m_bClippingEnabled = enabled; };
protected:
  bool m_bClippingEnabled;
};

#endif