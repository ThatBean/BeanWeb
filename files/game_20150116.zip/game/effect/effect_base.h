//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: effect_base.h
//        Author: peteryu
//          Date: 2013/10/17 20:02
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/17      add
//////////////////////////////////////////////////////////////

#ifndef EFFECT_BASE_H
#define EFFECT_BASE_H

#include "engine/base/cocos2d_wrapper.h"

namespace taomee{
namespace army
{
  class MoveObject;
}

namespace effect
{

class EffectBase
{
public:
  EffectBase(army::MoveObject* unit): 
      total_time_(0.0f), last_time_(0.0f), unit_(unit){}
  virtual ~EffectBase(){}

public:
  virtual void Update(float delta){total_time_ += delta;}
  virtual bool IsRemoveable(){return total_time_ >= last_time_;}
  void SetLastTime(float last_time){ last_time_ = last_time;}
  
protected:
  float   total_time_;
  float   last_time_;
  army::MoveObject  *unit_;
};

} //namespace taomee
} //namespace effect 

#endif
