#ifndef __CC_CARD_FLOW_H__
#define __CC_CARD_FLOW_H__

#include "cocos2d.h"

using namespace cocos2d;

class CCCardFlow : public CCActionInterval
{
public:
  CCCardFlow();
  
  static CCCardFlow* create(float t, const ccColor3B& tint_change, int z_order_change, float perspective_ratio);
  bool initWithDuration(float t, const ccColor3B& tint_change, int z_order_change, float perspective_ratio);

  CCObject* copyWithZone(CCZone *pZone);
  virtual void startWithTarget(CCNode *pTarget);
  virtual void update(float time);
  virtual void stop(void);
  
protected:
  float m_action_progress;
  
  //change Color tint
  ccColor3B m_tint_to;

  //change Z order
  int m_z_order_to;

  //set perspective
  float m_perspective_ratio;
};

#endif //__CC_CARD_FLOW_H__