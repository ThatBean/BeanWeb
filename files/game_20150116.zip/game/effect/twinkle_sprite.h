//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: twinkle_sprite.h
//        Author: peteryu
//          Date: 2013/10/21 13:44
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/21      add
//////////////////////////////////////////////////////////////

#ifndef TWINKLE_SPRITE_H
#define TWINKLE_SPRITE_H

#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;

namespace taomee{
namespace effect
{

class TwinkeSprite : public CCSprite
{
public:
  TwinkeSprite();
  virtual ~TwinkeSprite();

  virtual void draw(void);

  static CCSprite* create();

protected:
  float       time_;
  ccColor4F   light_color_;
  ccColor4F   light_pos_;

  GLint  u_time_location_;
  GLint  u_light_color_location_;
  GLint  u_light_pos_location_;
  GLint  u_tcd_tl_location_;
  GLint  u_tcd_tr_location_;
  GLint  u_tcd_bl_location_;
  GLint  u_tcd_br_location_;

  cocos2d::CCGLProgram* shader_;
};

} //namespace taomee
} //namespace effect 

#endif