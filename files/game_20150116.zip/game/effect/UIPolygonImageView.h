#ifndef __UIPOLYGONIMAGEVIEW_H__
#define __UIPOLYGONIMAGEVIEW_H__

#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee{

enum ePolygonImageEffectType
{
  kPolygonImageEffectTypeHighLight,
  kPolygonImageEffectTypeDarkLight
};

/**
*   @js NA
*   @lua NA
*/
class UIPolygonImageView : public UIImageView
{
public:
    /**
     * Default constructor
     */
    UIPolygonImageView();
    
    /**
     * Default destructor
     */
    virtual ~UIPolygonImageView();
    
    /**
     * Allocates and initializes.
     */
    static UIPolygonImageView* create();
    
    void loadTexture(const char* fileName);

    virtual bool hitTest(const CCPoint &pt);

    //call back function called widget's state changed to normal.
    virtual void onPressStateChangedToNormal();

    //call back function called widget's state changed to selected.
    virtual void onPressStateChangedToPressed();

    void         setPressEffectType(ePolygonImageEffectType effect_type);

protected:
    void    loadMaskData(const char* fileName);
    void    setMaskData(unsigned int length, bool is_have_data)
    {
      unsigned int byte_pos        = length / 8;
      unsigned int byte_in_offset  = length - byte_pos * 8;
      unsigned char byte_data = *(m_pmask_data + byte_pos);
      if(is_have_data)
        *(m_pmask_data + byte_pos) = 
                      (unsigned char)(byte_data | (0x01 << byte_in_offset));
      else
        *(m_pmask_data + byte_pos) = 
                      (unsigned char)(byte_data & ( ~(0x01 << byte_in_offset)));
    }
    bool    getMaskData(unsigned int length)
    {
      unsigned int byte_pos        = length / 8;
      unsigned int byte_in_offset  = length - byte_pos * 8;
      unsigned char byte_data = *(m_pmask_data + byte_pos);
      return (byte_data & (0x01 << byte_in_offset)) ? true : false;
    }

private:
    unsigned char*   m_pmask_data;
    CCImage          *m_pimage_data;
    ePolygonImageEffectType   m_effect_type;
    int              m_ilast_zorder;
};

}

#endif /* defined(__CocoGUI__UIImageView__) */
