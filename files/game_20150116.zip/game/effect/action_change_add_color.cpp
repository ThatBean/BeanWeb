//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_change_add_color.cpp
//        Author: peteryu
//          Date: 2014/4/21 16:57
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/21      add
//////////////////////////////////////////////////////////////

#include "game/effect/action_change_add_color.h"
#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_add_color.h"

namespace taomee{

ActionChangeAddColor::ActionChangeAddColor()
{
}

ActionChangeAddColor::~ActionChangeAddColor()
{
  if(m_pTarget && default_shader_program_)
    m_pTarget->setShaderProgram(default_shader_program_);
}

ActionChangeAddColor* ActionChangeAddColor::create( float round_time, const ccColor4F& color,
                                            int round_count, float scale_min, float scale_max)
{ 
  ActionChangeAddColor* action = new ActionChangeAddColor();
  action->autorelease();
  action->round_time_ = round_time;
  action->color_ = color;
  action->round_count_ = round_count;
  action->scale_min_ = scale_min;
  action->scale_max_ = scale_max;
  return action;
}

bool ActionChangeAddColor::isDone( void )
{   
  return ActionShaderBase::isDone();
}

void ActionChangeAddColor::start(void)
{
  default_shader_program_ = m_pTarget->getShaderProgram();
  shader_program_ = (shader::ProgramChangeAddColor*)shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderChangeAddColor);
  m_pTarget->setShaderProgram(shader_program_);
  ((shader::ProgramChangeAddColor*)shader_program_)->SetTime(0.0f);
  ((shader::ProgramChangeAddColor*)shader_program_)->SetScale(scale_min_, scale_max_);
  ((shader::ProgramChangeAddColor*)shader_program_)->SetColor(color_);
}

void ActionChangeAddColor::round_start(void)
{
}

void ActionChangeAddColor::stop( void )
{
  m_pTarget->setShaderProgram(default_shader_program_);
  ActionShaderBase::stop();
}

void ActionChangeAddColor::step(float dt)
{
  ActionShaderBase::step(dt);

  float half_round_time = round_time_ / 2.0f;

  // round
  if(round_time_ <= 0.000001)
  {
    ((shader::ProgramChangeAddColor*)shader_program_)->SetTime(1.0f);
  }
  else if(cur_round_time_ <= half_round_time)
    ((shader::ProgramChangeAddColor*)shader_program_)->SetTime(cur_round_time_ / half_round_time);
  else
    ((shader::ProgramChangeAddColor*)shader_program_)->SetTime(2.0 - cur_round_time_ / half_round_time);
  ((shader::ProgramChangeAddColor*)shader_program_)->SetScale(scale_min_, scale_max_);
  ((shader::ProgramChangeAddColor*)shader_program_)->SetColor(color_);
}

}