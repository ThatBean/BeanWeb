//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: touch_area_node_factory.cpp
//        Author: peteryu
//          Date: 2013/10/15 14:04
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/15      add
//////////////////////////////////////////////////////////////

#include "game/effect/touch_area_node_factory.h"

#include "game/shader/shader_manager.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/battle_controller.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/character_data_table.h"
#include "game/battle/tiled_map/coordinate_helper.h"

namespace taomee
{
namespace effect
{

TouchAreaNodeFactory::TouchAreaNodeFactory()
{

}

TouchAreaNodeFactory::~TouchAreaNodeFactory()
{

}

CCNode* TouchAreaNodeFactory::CreateAreaNode( army::MoveObject *unit, eTouchAreaType type )
{
  //init sprite&stencil
  CCSprite        *sprite    = NULL; 
  CCClippingNode  *clip_node = CCClippingNode::create();
  CCDrawNode      *stencil   = CCDrawNode::create();

  if(type == kTouchAreaGuard)
  {
    sprite = CCSprite::create("textures/effect/select_fog_green.png");
  }
  else if(type == kTouchAreaNearAttack)
  {
    sprite = CCSprite::create("textures/effect/select_fog_red.png");
  }

  sprite->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderTargetArea));
  sprite->setAnchorPoint(ccp(0.0f, 0.0f));

  //add sprite&stencil
  clip_node->addChild(sprite);
  clip_node->setStencil(stencil);
  cocos2d::ccColor4F green = cocos2d::ccc4f(0.0f, 0.0f, 1.0f, 0.0f);
  int sprite_width = sprite->getContentSize().width;
  CharacterData *char_data = unit->character_card_data();

  if(type == kTouchAreaNearAttack || 
    (type == kTouchAreaGuard && char_data->GetPatrolType() == kPatrolAreaCircle))
  {
    //resize sprite size to hold circle
    float radius = (type == kTouchAreaNearAttack) ? char_data->GetAttackRange() :
      char_data->GetPatrolParam1();
    radius *= battle::kMapTileMinHeight;
    clip_node->setContentSize(ccp(radius * 2, radius * 2));
    clip_node->setAnchorPoint(ccp(0.5f, 0.5f));
    if(sprite_width < radius * 2)
    {
      sprite->setScale(radius * 2 / (float) sprite_width);
    }
    //generate circle stencil points
    CCPoint *points = new CCPoint[101];
    for(int i = 0; i < DEAULT_CIRCLE_POINT_COUNT; ++i)
    {
      points[i].x = radius * (DefaultCircleData[i * 2] + 1);
      points[i].y = radius * (DefaultCircleData[i * 2 + 1] + 1);
    }
    stencil->drawPolygon(points, DEAULT_CIRCLE_POINT_COUNT, green, 0, green);
    delete[] points;

    return clip_node;
  }
  else
  {
    int tileWidth = char_data->GetPatrolParam1() * battle::kMapTileMaxLength;
    int tileHeight = 1 * battle::kMapTileMaxHeight;
    //resize sprite size to hold circle
    clip_node->setContentSize(ccp(tileWidth, tileHeight));
    clip_node->setAnchorPoint(ccp(0.9f, 0.1f));
    int max_rect_length = tileWidth > tileHeight ? tileWidth : tileHeight;
    if(sprite_width < max_rect_length)
    {
      sprite->setScale((float) max_rect_length / (float) sprite_width);
    }

    //generate rect stencil points
    CCPoint *points = new CCPoint[4];

    std::vector<cocos2d::CCPoint> points_vec;
    int unit_tile_no = taomee::battle::GetTileIndexByCurrentPointPosition(unit->current_pos());
    taomee::battle::BattleController::GetInstance().tiled_map()->\
      GetRangeQuadrangleFourVertexPointInAnticlockwise(points_vec, 11, 
      char_data->GetPatrolParam1());

    int i = 0;
    cocos2d::CCPoint leftBottom;
    if(points_vec.size() >= 3)
      leftBottom = points_vec[3];
    for(std::vector<cocos2d::CCPoint>::iterator itr = points_vec.begin(); 
      itr != points_vec.end(); ++itr)
    {
      points[i].x = itr->x - leftBottom.x;
      points[i].y = itr->y - leftBottom.y;
      ++i;
    }

    stencil->drawPolygon(points, 4, green, 0, green);

    delete[] points;

    return clip_node;
  }
/*
  Eclipse*     touch_ellipse = dynamic_cast<Eclipse*>(touch_area);
  if(touch_ellipse)
  {
    //resize sprite size to hold circle
    clip_node->setContentSize(ccp(touch_ellipse->GetAAxis() * 2, touch_ellipse->GetBAxis() * 2));
    clip_node->setAnchorPoint(ccp(0.5f, 0.5f));
    float max_axis = touch_ellipse->GetAAxis() > touch_ellipse->GetBAxis() ? 
      touch_ellipse->GetAAxis() : touch_ellipse->GetBAxis();
    if(sprite_width < max_axis * 2)
    {
      sprite->setScale(max_axis * 2 / (float) sprite_width);
    }
    //generate circle stencil points
    CCPoint *points = new CCPoint[100];
    float b_div_a = touch_ellipse->GetAAxis() / touch_ellipse->GetBAxis();
    for(int i = 0; i < DEAULT_CIRCLE_POINT_COUNT; ++i)
    {
      points[i].x = touch_ellipse->GetAAxis() * (DefaultCircleData[i * 2] + 1);
      points[i].y = touch_ellipse->GetBAxis() * (DefaultCircleData[i * 2 + 1] + 1);
    }
    stencil->drawPolygon(points, DEAULT_CIRCLE_POINT_COUNT, green, 0, green);
    delete[] points;

    return clip_node;
  }

  HalfRect* touch_half_rect = dynamic_cast<HalfRect*>(touch_area);
  if(touch_half_rect)
  {
    //resize sprite size to hold circle
    clip_node->setContentSize(ccp(touch_half_rect->GetWidth(), touch_half_rect->GetHeight()));
    clip_node->setAnchorPoint(ccp(0.0f, 0.5f));
    int max_rect_length = touch_half_rect->GetWidth() > touch_half_rect->GetHeight() ?
      touch_half_rect->GetWidth() : touch_half_rect->GetHeight();
    if(sprite_width < max_rect_length)
    {
      sprite->setScale((float) max_rect_length / (float) sprite_width);
    }

    //generate rect stencil points
    CCPoint *points = new CCPoint[4];

    points[0].x = touch_half_rect->GetWidth();
    points[0].y = touch_half_rect->GetHeight();
    points[1].x = 0;
    points[1].y = touch_half_rect->GetHeight();
    points[2].x = 0;
    points[2].y = 0;
    points[3].x = touch_half_rect->GetWidth();
    points[3].y = 0;
    stencil->drawPolygon(points, 4, green, 0, green);

    delete[] points;

    return clip_node;
  }

  TileHalfRect* tileHalfRect = dynamic_cast<TileHalfRect*>(touch_area);
  if(tileHalfRect)
  {
    int tileWidth = tileHalfRect->GetTileWidth() * battle::kMapTileAverageLength;
    int tileHeight = tileHalfRect->GetTileHeight() * battle::kMapTileAverageLength;
    //resize sprite size to hold circle
    clip_node->setContentSize(ccp(tileWidth, tileHeight));
    clip_node->setAnchorPoint(ccp(0.9f, 0.0f));
    int max_rect_length = tileWidth > tileHeight ? tileWidth : tileHeight;
    if(sprite_width < max_rect_length)
    {
      sprite->setScale((float) max_rect_length / (float) sprite_width);
    }

    //generate rect stencil points
    CCPoint *points = new CCPoint[4];

    std::vector<cocos2d::CCPoint> points_vec;
    int unit_tile_no = taomee::battle::GetTileIndexByCurrentPointPosition(unit->current_pos());
    taomee::battle::BattleController::GetInstance().tiled_map()->\
      GetRangeQuadrangleFourVertexPointInAnticlockwise(points_vec, 5, 
      tileHalfRect->GetTileWidth());

    int i = 0;
    cocos2d::CCPoint leftBottom;
    if(points_vec.size() >= 3)
      leftBottom = points_vec[3];
    for(std::vector<cocos2d::CCPoint>::iterator itr = points_vec.begin(); 
      itr != points_vec.end(); ++itr)
    {
      points[i].x = itr->x - leftBottom.x;
      points[i].y = itr->y - leftBottom.y;
      ++i;
    }
    
    stencil->drawPolygon(points, 4, green, 0, green);

    delete[] points;

    return clip_node;
  }
  */
  return NULL;
}

}
}
