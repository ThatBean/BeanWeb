//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_brigthness_scale.cpp
//        Author: peteryu
//          Date: 2014/3/6 20:28
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/3/6      add
//////////////////////////////////////////////////////////////

#include "game/effect/action_change_add_self_color.h"
#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_add_self_color.h"

namespace taomee{

ActionChangeAddSelfColor::ActionChangeAddSelfColor()
{
}

ActionChangeAddSelfColor::~ActionChangeAddSelfColor()
{
  if(m_pTarget && default_shader_program_)
    m_pTarget->setShaderProgram(default_shader_program_);
}

ActionChangeAddSelfColor* ActionChangeAddSelfColor::create( float round_time, int round_count, 
                                                            float scale_min, float scale_max)
{ 
  ActionChangeAddSelfColor* action = new ActionChangeAddSelfColor();
  action->autorelease();
  action->round_time_ = round_time;
  action->round_count_ = round_count;
  action->scale_min_ = scale_min;
  action->scale_max_ = scale_max;
  return action;
}

bool ActionChangeAddSelfColor::isDone( void )
{   
  return ActionShaderBase::isDone();
}

void ActionChangeAddSelfColor::start(void)
{
  default_shader_program_ = m_pTarget->getShaderProgram();
  assert(default_shader_program_);
  shader_program_ = (shader::ProgramChangeAddSelfColor*)shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderChangeAddSelfColor);
  m_pTarget->setShaderProgram(shader_program_);
  ((shader::ProgramChangeAddSelfColor*)shader_program_)->SetTime(0.0f);
  ((shader::ProgramChangeAddSelfColor*)shader_program_)->SetScale(scale_min_, scale_max_);
}

void ActionChangeAddSelfColor::round_start(void)
{
  //CCLog("RoundCount: %d", cur_round_count_);
}

void ActionChangeAddSelfColor::stop( void )
{
  m_pTarget->setShaderProgram(default_shader_program_);
  ActionShaderBase::stop();
}

void ActionChangeAddSelfColor::step(float dt)
{
  ActionShaderBase::step(dt);

  float half_round_time = round_time_ / 2.0f;

  // round
  if(round_time_ <= 0.000001)
  {
    ((shader::ProgramChangeAddSelfColor*)shader_program_)->SetTime(1.0f);
  }
  else if(cur_round_time_ <= half_round_time)
    ((shader::ProgramChangeAddSelfColor*)shader_program_)->SetTime(cur_round_time_ / half_round_time);
  else
    ((shader::ProgramChangeAddSelfColor*)shader_program_)->SetTime(2.0 - cur_round_time_ / half_round_time);
  ((shader::ProgramChangeAddSelfColor*)shader_program_)->SetScale(scale_min_, scale_max_);
}

}