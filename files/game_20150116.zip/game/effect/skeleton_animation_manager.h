//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skeleton_animation_manager.h
//        Author: peteryu
//          Date: 2013/10/12 11:48
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/12      add
//////////////////////////////////////////////////////////////

#ifndef SKELETON_ANIMATION_MANAGER_H
#define SKELETON_ANIMATION_MANAGER_H

#include <list>

#include "engine/animation/skeleton_animation.h"
#include "game/shader/shader_manager.h"
#include "game/army/unit/move_object.h"
#include "game/effect/effect_base.h"

namespace taomee
{
namespace effect
{

enum eSkeletonAnimationPartType
{
  kSkeletonAnimationPartBody        = 0x01 << 0,
  kSkeletonAnimationPartBloodBar    = 0x01 << 1,
  kSkeletonAnimationPartRangeBox    = 0x01 << 2,
  kSkeletonAnimationPartGuardArea   = 0x01 << 3,
  kSkeletonAnimationPartSkillArea   = 0x01 << 4,
  kSkeletonAnimationPartCount       = 5
};
  
class SkeletonAnimationManager
{
public:
  SkeletonAnimationManager(army::MoveObject *unit);
  ~SkeletonAnimationManager();

  void  StartHitRedShader(float last_time);
  void  StartHealGreenShader(float last_time);
  void  StartGuardArea(float last_time);
  void  RemoveGuardArea();

  void  Update(float delta_time);

protected:
  void  PushEffectToList(EffectBase* effect){effect_list_.push_back(effect);}

protected:
  army::MoveObject        *unit_;
  std::list<EffectBase*>  effect_list_;

  float                   guard_area_total_time_;
  float                   guard_area_last_time_;
  bool                    guard_area_is_started_;
};

}// namespace effect
}// namespace taomee

#endif
