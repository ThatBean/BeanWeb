//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: circle_clipping_node.cpp
//        Author: peteryu
//          Date: 2013/12/19 14:14
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/12/19      add
//////////////////////////////////////////////////////////////
#ifndef CIRCLE_CLIPPING_NODE_H
#define CIRCLE_CLIPPING_NODE_H

#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;

namespace taomee
{
  class CircleClippingNode : public CCClippingNode
  {
  public:

  virtual ~CircleClippingNode();
  virtual bool  init();
  static        CircleClippingNode* create(const char* file_path);
  void          setClippingRadius(float radius);
  void          setClippingEnabled(bool enabled);
  virtual void  visit();
  void          setEnabled(bool enabled);
  bool          isEnabled() const;
  void          setClippingSpriteAnchorPoint(CCPoint anchorPoint);
  void setInverted(bool bInverted);
protected:
  CCSprite*     m_sprite;
  std::string   m_sSpritePath;
  CCDrawNode*   m_pInnerStencil;
  bool          m_bEnabled;
  void          setStencilData();

private:
  CircleClippingNode();
  float         m_radius;
  bool          m_bClippingEnabled;
};

}
#endif