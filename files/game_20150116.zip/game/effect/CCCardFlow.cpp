#include "cocos2d.h"
#include "CCCardFlow.h"


CCCardFlow::CCCardFlow()
{
  m_action_progress = 0;
}

CCCardFlow* CCCardFlow::create(float t, const ccColor3B& tint_change, int z_order_change, float perspective_ratio)
{
  CCCardFlow *p_action = new CCCardFlow();
  p_action->initWithDuration(t, tint_change, z_order_change, perspective_ratio);
  p_action->autorelease();
  
  return p_action;
}

bool CCCardFlow::initWithDuration(float t, const ccColor3B& tint_change, int z_order_change, float perspective_ratio)
{
  if (CCActionInterval::initWithDuration(t))
  {
    //change Color tint
    m_tint_to = ccColor3B(tint_change);
    
    //change Z order
    m_z_order_to = z_order_change;

    //set perspective
    m_perspective_ratio = perspective_ratio;

    return true;
  }
  
  return false;
}

/*

void set_perspective(CCSprite* tgt_node, float perspective_ratio)
{
  float bl_v_x = tgt_node->get_m_sQuad_info(1, 1, 1);
  float bl_v_y = tgt_node->get_m_sQuad_info(1, 1, 2);
  float bl_v_z = tgt_node->get_m_sQuad_info(1, 1, 3);

  float br_v_x = tgt_node->get_m_sQuad_info(2, 1, 1);
  float br_v_y = tgt_node->get_m_sQuad_info(2, 1, 2);
  float br_v_z = tgt_node->get_m_sQuad_info(2, 1, 3);

  float mid_x = (bl_v_x + br_v_x) * 0.5;
  float mid_y = (bl_v_y + br_v_y) * 0.5;
  float mid_z = (bl_v_z + br_v_z) * 0.5;

  tgt_node->set_m_sQuad_info(1, 1, 1, mid_x + (bl_v_x - mid_x) * perspective_ratio);
  tgt_node->set_m_sQuad_info(1, 1, 2, mid_y + (bl_v_y - mid_y) * perspective_ratio);
  tgt_node->set_m_sQuad_info(1, 1, 3, mid_z + (bl_v_z - mid_z) * perspective_ratio);

  tgt_node->set_m_sQuad_info(2, 1, 1, mid_x + (br_v_x - mid_x) * perspective_ratio);
  tgt_node->set_m_sQuad_info(2, 1, 2, mid_y + (br_v_y - mid_y) * perspective_ratio);
  tgt_node->set_m_sQuad_info(2, 1, 3, mid_z + (br_v_z - mid_z) * perspective_ratio);

  return;
}
*/



//void set_perspective_pro(CCSprite* tgt_node, float perspective_ratio, float x_degree, float y_degree, float z_degree)

void set_perspective(CCSprite* tgt_node, float perspective_ratio)
{
  
  
  /*float bl_v_x = tgt_node->get_m_sQuad_info(1, 1, 1);
  float bl_v_y = tgt_node->get_m_sQuad_info(1, 1, 2);
  float bl_v_z = tgt_node->get_m_sQuad_info(1, 1, 3);

  float br_v_x = tgt_node->get_m_sQuad_info(2, 1, 1);
  float br_v_y = tgt_node->get_m_sQuad_info(2, 1, 2);
  float br_v_z = tgt_node->get_m_sQuad_info(2, 1, 3);

  float tl_v_x = tgt_node->get_m_sQuad_info(3, 1, 1);
  float tl_v_y = tgt_node->get_m_sQuad_info(3, 1, 2);
  float tl_v_z = tgt_node->get_m_sQuad_info(3, 1, 3);

  float tr_v_x = tgt_node->get_m_sQuad_info(4, 1, 1);
  float tr_v_y = tgt_node->get_m_sQuad_info(4, 1, 2);
  float tr_v_z = tgt_node->get_m_sQuad_info(4, 1, 3);

  float mid_b_x = (bl_v_x + br_v_x) * 0.5;
  float mid_b_y = (bl_v_y + br_v_y) * 0.5;
  float mid_b_z = (bl_v_z + br_v_z) * 0.5;

  float mid_t_x = (tl_v_x + tr_v_x) * 0.5;
  float mid_t_y = (tl_v_y + tr_v_y) * 0.5;
  float mid_t_z = (tl_v_z + tr_v_z) * 0.5;

  float mid_x = (mid_b_x + mid_t_x) * 0.5;
  float mid_y = (mid_b_y + mid_t_y) * 0.5;
  float mid_z = (mid_b_z + mid_t_z) * 0.5;

  //average
  float avg_x_half = (bl_v_x - br_v_x + tl_v_x - tr_v_x) * 0.25;

  bl_v_x = mid_b_x + avg_x_half * perspective_ratio;
  br_v_x = mid_b_x - avg_x_half * perspective_ratio;
  tl_v_x = mid_t_x + avg_x_half / perspective_ratio;
  tr_v_x = mid_t_x - avg_x_half / perspective_ratio;


  tgt_node->set_m_sQuad_info(1, 1, 1, bl_v_x);
  tgt_node->set_m_sQuad_info(2, 1, 1, br_v_x);

  tgt_node->set_m_sQuad_info(3, 1, 1, tl_v_x);
  tgt_node->set_m_sQuad_info(4, 1, 1, tr_v_x);*/




/*


  tgt_node->set_m_sQuad_info(1, 1, 1, mid_b_x + (bl_v_x - mid_b_x) * perspective_ratio);
  tgt_node->set_m_sQuad_info(1, 1, 2, mid_b_y + (bl_v_y - mid_b_y) * perspective_ratio);
  tgt_node->set_m_sQuad_info(1, 1, 3, mid_b_z + (bl_v_z - mid_b_z) * perspective_ratio);

  tgt_node->set_m_sQuad_info(2, 1, 1, mid_b_x + (br_v_x - mid_b_x) * perspective_ratio);
  tgt_node->set_m_sQuad_info(2, 1, 2, mid_b_y + (br_v_y - mid_b_y) * perspective_ratio);
  tgt_node->set_m_sQuad_info(2, 1, 3, mid_b_z + (br_v_z - mid_b_z) * perspective_ratio);


  tgt_node->set_m_sQuad_info(3, 1, 1, mid_t_x + (tl_v_x - mid_t_x) / perspective_ratio);
  tgt_node->set_m_sQuad_info(3, 1, 2, mid_t_y + (tl_v_y - mid_t_y) / perspective_ratio);
  tgt_node->set_m_sQuad_info(3, 1, 3, mid_t_z + (tl_v_z - mid_t_z) / perspective_ratio);

  tgt_node->set_m_sQuad_info(4, 1, 1, mid_t_x + (tr_v_x - mid_t_x) / perspective_ratio);
  tgt_node->set_m_sQuad_info(4, 1, 2, mid_t_y + (tr_v_y - mid_t_y) / perspective_ratio);
  tgt_node->set_m_sQuad_info(4, 1, 3, mid_t_z + (tr_v_z - mid_t_z) / perspective_ratio);*/
/*

  tgt_node->set_m_sQuad_info(1, 1, 1, mid_x + (bl_v_x - mid_x) * perspective_ratio);
  tgt_node->set_m_sQuad_info(1, 1, 2, mid_y + (bl_v_y - mid_y) * perspective_ratio);
  tgt_node->set_m_sQuad_info(1, 1, 3, mid_z + (bl_v_z - mid_z) * perspective_ratio);

  tgt_node->set_m_sQuad_info(2, 1, 1, mid_x + (br_v_x - mid_x) * perspective_ratio);
  tgt_node->set_m_sQuad_info(2, 1, 2, mid_y + (br_v_y - mid_y) * perspective_ratio);
  tgt_node->set_m_sQuad_info(2, 1, 3, mid_z + (br_v_z - mid_z) * perspective_ratio);


  tgt_node->set_m_sQuad_info(3, 1, 1, mid_x + (tl_v_x - mid_x) / perspective_ratio);
  tgt_node->set_m_sQuad_info(3, 1, 2, mid_y + (tl_v_y - mid_y) / perspective_ratio);
  tgt_node->set_m_sQuad_info(3, 1, 3, mid_z + (tl_v_z - mid_z) / perspective_ratio);

  tgt_node->set_m_sQuad_info(4, 1, 1, mid_x + (tr_v_x - mid_x) / perspective_ratio);
  tgt_node->set_m_sQuad_info(4, 1, 2, mid_y + (tr_v_y - mid_y) / perspective_ratio);
  tgt_node->set_m_sQuad_info(4, 1, 3, mid_z + (tr_v_z - mid_z) / perspective_ratio);*/

  return;
}


void _recursive_update_tint(float current_step_progress, const ccColor3B& tint_color, CCNode *tgt_node)
{
  //color tint
  CCRGBAProtocol *pRGBAProtocol = dynamic_cast<CCRGBAProtocol*>(tgt_node);
  if (pRGBAProtocol)
  {
    ccColor3B tint_from = pRGBAProtocol->getColor();
    ccColor3B new_color = ccc3(GLubyte(tint_from.r + (tint_color.r - tint_from.r) * current_step_progress), 
      (GLbyte)(tint_from.g + (tint_color.g - tint_from.g) * current_step_progress),
      (GLbyte)(tint_from.b + (tint_color.b - tint_from.b) * current_step_progress));
    pRGBAProtocol->setColor(new_color);
  }    

  CCArray* child_node = tgt_node->getChildren();
  CCObject* pObj = NULL;
  CCARRAY_FOREACH(child_node, pObj)
  {
    CCNode* node = static_cast<CCNode*>(pObj);
    _recursive_update_tint(current_step_progress, tint_color, node);
  }
}


void _recursive_update_perspective(float current_step_progress, float perspective_ratio, CCNode *tgt_node)
{
  //set perspective
  CCSprite * transfered_node = dynamic_cast<CCSprite*>(tgt_node);
  if (transfered_node)
  {
    set_perspective(transfered_node, perspective_ratio);
  }

  CCArray* child_node = tgt_node->getChildren();
  CCObject* pObj = NULL;
  CCARRAY_FOREACH(child_node, pObj)
  {
    CCNode* node = static_cast<CCNode*>(pObj);
    _recursive_update_perspective(current_step_progress, perspective_ratio, node);
  }
}


void CCCardFlow::startWithTarget(CCNode *pTarget)
{
  CCActionInterval::startWithTarget( pTarget );
  
  //set perspective
  _recursive_update_perspective(0, m_perspective_ratio, m_pTarget);
}


void CCCardFlow::update(float time)
{
  float current_step_progress = (time - m_action_progress) / (1 - m_action_progress);
  m_action_progress = time;

  //tint
  _recursive_update_tint(current_step_progress, m_tint_to, m_pTarget);
  
  //Z order
  int z_order_from = m_pTarget->getZOrder();
  m_pTarget->setZOrder(z_order_from + (m_z_order_to - z_order_from) * current_step_progress);

}


void CCCardFlow::stop(void)
{
  //change Color tint
  _recursive_update_tint(1, m_tint_to, m_pTarget);

  //change Z order
  m_pTarget->setZOrder(m_z_order_to);

  //set perspective
  _recursive_update_perspective(1, m_perspective_ratio, m_pTarget);
  
  CCActionInterval::stop();
}


CCObject* CCCardFlow::copyWithZone(CCZone *pZone)
{
  CCZone* pNewZone = NULL;
  CCCardFlow* pCopy = NULL;
  if(pZone && pZone->m_pCopyObject) 
  {
    //in case of being called at sub class
    pCopy = (CCCardFlow*)(pZone->m_pCopyObject);
  }
  else
  {
    pCopy = new CCCardFlow();
    pZone = pNewZone = new CCZone(pCopy);
  }

  CCActionInterval::copyWithZone(pZone);

  pCopy->initWithDuration(m_fDuration, m_tint_to, m_z_order_to, m_perspective_ratio);

  CC_SAFE_DELETE(pNewZone);
  return pCopy;
}

