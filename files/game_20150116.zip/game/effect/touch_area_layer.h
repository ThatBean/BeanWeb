//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: touch_area_layer.h
//        Author: peteryu
//          Date: 2013/10/10 21:32
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/10      add
//////////////////////////////////////////////////////////////

#ifndef TOUCH_AREA_LAYER_H
#define TOUCH_AREA_LAYER_H

#include "engine/base/cocos2d_wrapper.h"
#include "game/army/unit/move_object.h"

using namespace cocos2d;

namespace taomee{
namespace effect
{

enum eTouchAreaType
{
  kTouchAreaNearAttack,
  kTouchAreaGuard,
  kTouchAreaSkill
};

class TouchAreaLayer : public CCLayer
{
public:
  TouchAreaLayer(army::MoveObject *unit, eTouchAreaType type = kTouchAreaGuard);
  virtual ~TouchAreaLayer();

  static TouchAreaLayer* create(army::MoveObject *unit, eTouchAreaType type);

  void FadeOut();
  void Remove();

protected:
  void            CreateTouchArea();
  void            OnFadeOut();

private:
  army::MoveObject      *unit_;
  CCSprite        *sprite_;
  CCClippingNode  *clip_node_;
  CCDrawNode      *stencil_;
  eTouchAreaType  type_;
};

} //namespace taomee
} //namespace effect 

#endif
