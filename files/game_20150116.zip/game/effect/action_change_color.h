//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_change_color.h
//        Author: peteryu
//          Date: 2014/4/1 16:11
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/1      add
//////////////////////////////////////////////////////////////

#ifndef ACTION_CHANGE_COLOR_H
#define ACTION_CHANGE_COLOR_H

#include "engine/base/cocos2d_wrapper.h"
#include "game/effect/action_shader_base.h"

using namespace cocos2d;

namespace taomee
{

namespace shader
{
class ProgramChangeColor;
}

class ActionChangeColor : public ActionShaderBase
{
public:
  ActionChangeColor();
  virtual ~ActionChangeColor();

  /*
  * time:   single round time
  * count:  round count
  * color:  target color
  */
  static ActionChangeColor* create(float round_time, ccColor4F color, int round_count = -1);

  virtual bool isDone(void);

  virtual void start(void);

  virtual void round_start(void);

  virtual void stop(void);

  virtual void step(float dt);

protected:
  ccColor4F                   color_;
};

}
#endif