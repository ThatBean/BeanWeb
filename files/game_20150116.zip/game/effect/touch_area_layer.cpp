//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: touch_area_layer.cpp
//        Author: peteryu
//          Date: 2013/10/11 13:34
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/11      add
//////////////////////////////////////////////////////////////

#include "game/effect/touch_area_layer.h"

#include "engine/base/random_helper.h"
#include "engine/geometry/geometry.h"
#include "engine/geometry/circle.h"
#include "engine/geometry/rect.h"
#include "game/shader/shader_manager.h"
#include "game/game_manager/data_manager.h"

using namespace cocos2d::extension;

namespace {

const std::string kTouchAreaTextureFolder = "textures/battle";
const std::string kTouchAreaTexturePath = "textures/battle/battle_ex.pvr.ccz";

// eAttackType as index
const std::string kCircleTouchAreaFrameArray[] = {
  "attack_range_red.png",
  "attack_range_red.png",
  "attack_range_red.png",
  "attack_range_green.png",
};

const std::string kRectTouchAreaFrameName = "attack_red.png";

const cocos2d::CCPoint kAnchorPointArray[] = {
  cocos2d::CCPoint(1, 0),
  cocos2d::CCPoint(0, 0),
  cocos2d::CCPoint(0, 1),
  cocos2d::CCPoint(1, 1)
};

const bool kFlipXArray[] = {
  false,
  true,
  true,
  false
};

const bool kFlipYArray[] = {
  false,
  false,
  true,
  true
};

const int kBatchNodeTag = 123;

}


namespace taomee{
namespace effect
{

taomee::effect::TouchAreaLayer::TouchAreaLayer(army::MoveObject *unit, eTouchAreaType type)
{
  unit_       = unit;
  type_       = type;

  CreateTouchArea();
}

taomee::effect::TouchAreaLayer::~TouchAreaLayer()
{

}


//void TouchAreaLayer::CreateTouchArea()
//{
//  if(unit_->move_object_id() == 3)
//    sprite_     = CCSprite::create("textures/effect/select_fog_green.png");
//  else
//    sprite_     = CCSprite::create("textures/effect/select_fog_red.png");
//  clip_node_  = CCClippingNode::create();
//  stencil_    = CCDrawNode::create();
//
//  sprite_->setAnchorPoint(ccp(0.0f, 0.0f));
//  sprite_->setShaderProgram(shader::ShaderManager::GetInstance()->
//    getShaderWithType(shader::kShaderTargetArea));
//  clip_node_->addChild(sprite_);
//  clip_node_->setStencil(stencil_);
//  clip_node_->setAnchorPoint(ccp(0.0f, 0.0f));
//  addChild(clip_node_);
//  ignoreAnchorPointForPosition(false);
//
//  static ccColor4F green = {0, 1, 0, 1};
//  Geometry*   touch_area = NULL;
//
//  if(type_ == kTouchAreaGuard)
//  {
//    touch_area = unit_->guard_area();
//  }
//  else
//    return;
//
//  CCSize sprite_size = sprite_->getContentSize();
//  Circle*     touch_circle = dynamic_cast<Circle*>(touch_area);
//  if(touch_circle)
//  {
//    //resize layer&sprite size to hold circle
//    clip_node_->setContentSize(ccp(touch_circle->GetRadius() * 2, touch_circle->GetRadius() * 2));
//    setContentSize(ccp(touch_circle->GetRadius() * 2, touch_circle->GetRadius() * 2));
//    setAnchorPoint(ccp(0.0f, 0.0f));
//    if(sprite_size.width < touch_circle->GetRadius() * 2)
//    {
//      sprite_->setScale(touch_circle->GetRadius() * 2 / (float) sprite_size.width);
//    }
//    //generate circle stencil points
//    CCPoint *points = new CCPoint[100];
//    for(int i = 0; i < DEAULT_CIRCLE_POINT_COUNT; ++i)
//    {
//      points[i].x = touch_circle->GetRadius() * (DefaultCircleData[i * 2] + 1);
//      points[i].y = touch_circle->GetRadius() * (DefaultCircleData[i * 2 + 1] + 1);
//    }
//    stencil_->drawPolygon(points, DEAULT_CIRCLE_POINT_COUNT, green, 0, green);
//    delete[] points;
//    //adjust circle pos
//    setPosition(ccp(-touch_circle->GetRadius(), -touch_circle->GetRadius()));
//    return;
//  }
//
//  HalfRect* touch_half_rect = dynamic_cast<HalfRect*>(touch_area);
//  if(touch_half_rect)
//  {
//    //resize layer&sprite size to hold circle
//    clip_node_->setContentSize(ccp(touch_half_rect->GetWidth(), touch_half_rect->GetHeight()));
//    setContentSize(ccp(touch_half_rect->GetWidth(), touch_half_rect->GetHeight()));
//    setAnchorPoint(ccp(0.0f, 0.5f));
//    int max_rect_length = touch_half_rect->GetWidth() > touch_half_rect->GetHeight() ?
//                          touch_half_rect->GetWidth() : touch_half_rect->GetHeight();
//    if(sprite_size.width < max_rect_length)
//    {
//      sprite_->setScaleX((float) max_rect_length / (float) sprite_size.width);
//    }
//
//    //generate rect stencil points
//    CCPoint *points = new CCPoint[4];
//    points[0].x = touch_half_rect->GetWidth();
//    points[0].y = touch_half_rect->GetHeight();
//    points[1].x = 0;
//    points[1].y = touch_half_rect->GetHeight();
//    points[2].x = 0;
//    points[2].y = 0;
//    points[3].x = touch_half_rect->GetWidth();
//    points[3].y = 0;
//    stencil_->drawPolygon(points, 4, green, 0, green);
//    delete[] points;
//
//    setPosition(ccp(0, -touch_half_rect->GetHeight()));
//  }
//}

void TouchAreaLayer::CreateTouchArea()
{
  if(type_ != kTouchAreaGuard)
  {
    return;
  }

  CharacterData* character_data = unit_->character_card_data();
  if (character_data->GetPatrolType() == 0)
  {
    army::eCareerType career_type = static_cast<army::eCareerType>(character_data->GetJobType());
    army::eAttackType attack_type = army::GetMoveObjectAttackTypeByCareerType(career_type);

    assert(attack_type >= 0 &&
           attack_type < sizeof (kCircleTouchAreaFrameArray) / sizeof (kCircleTouchAreaFrameArray[0]));

    std::string touch_area_frame_name = kCircleTouchAreaFrameArray[attack_type];

    CCSpriteBatchNode* batch_node = CCSpriteBatchNode::create(kTouchAreaTexturePath.c_str());

    CCSprite *sprite = NULL;
    for (int i = 0; i < 4; ++i)
    {
      sprite = CCSprite::createWithSpriteFrameName(touch_area_frame_name.c_str());
      sprite->setPosition(CCPointZero);
      sprite->setAnchorPoint(kAnchorPointArray[i]);
      sprite->setFlipX(kFlipXArray[i]);
      sprite->setFlipY(kFlipYArray[i]);

      batch_node->addChild(sprite);
    }

    float texture_width = sprite->getContentSize().width;
    float scale = unit_->guard_trigger()->circle_guard_radius() * battle::kMapTileAverageLength / texture_width;
    batch_node->setScaleX(scale);
    batch_node->setScaleY(scale * 0.75f);

    this->addChild(batch_node, kBatchNodeTag, kBatchNodeTag);
  }
  else
  {
    int tile_width = character_data->GetPatrolParam1();
    int tile_height = character_data->GetPatrolParam2();

    CCScale9Sprite* sprite = CCScale9Sprite::createWithSpriteFrameName(kRectTouchAreaFrameName.c_str());
    sprite->setInsetBottom(40);
    sprite->setInsetLeft(40);
    sprite->setInsetRight(40);
    sprite->setInsetTop(40);

    float width = tile_width * battle::kMapTileAverageLength;
    float height = tile_height * battle::kMapTileAverageLength;

    sprite->setPreferredSize(CCSizeMake(width, height));
    sprite->setAnchorPoint(ccp(11.0f / 12, 0.5f));

    this->addChild(sprite, kBatchNodeTag, kBatchNodeTag);
  }
}

void TouchAreaLayer::FadeOut()
{
  this->stopAllActions();

  CCNode* batch_node = this->getChildByTag(kBatchNodeTag);
  if (batch_node == NULL)
  {
    return;
  }

  const float fade_out_time = 0.1f;

  // cannot fadeout batchnode, should fadeout every sprite child
  CCObject* child = NULL;
  CCARRAY_FOREACH(batch_node->getChildren(), child)
  {
    CCSprite* sprite = dynamic_cast<CCSprite*>(child);
    if (sprite != NULL)
    {
      CCFadeOut* fade_out = CCFadeOut::create(fade_out_time);
      sprite->runAction(fade_out);
    }
  }

  CCDelayTime* delay = CCDelayTime::create(fade_out_time);
  CCCallFunc* fade_out_callback = CCCallFunc::create(this, callfunc_selector(TouchAreaLayer::OnFadeOut));

  batch_node->runAction(CCSequence::create(delay, fade_out_callback, NULL));
}

void TouchAreaLayer::Remove()
{
  this->removeFromParentAndCleanup(true);
}

void TouchAreaLayer::OnFadeOut()
{
  this->Remove();
}

TouchAreaLayer* TouchAreaLayer::create(army::MoveObject *unit, eTouchAreaType type )
{
  TouchAreaLayer *layer = new TouchAreaLayer(unit, type);
  if (layer)
  {
    layer->autorelease();
    return layer;
  }
  CC_SAFE_DELETE(layer);
  return NULL;
}

}
}
