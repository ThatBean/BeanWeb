//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_brigthness_scale.cpp
//        Author: peteryu
//          Date: 2014/3/6 20:28
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/3/6      add
//////////////////////////////////////////////////////////////

#include "game/effect/action_brigthness_scale.h"
#include "game/shader/shader_manager.h"

namespace taomee{

ActionBrightnessScale::ActionBrightnessScale()
  : total_time_(0.0f),
    is_set_shader_(false),
    is_remove_shader_(false)
{
}

ActionBrightnessScale::~ActionBrightnessScale()
{
}

ActionBrightnessScale* ActionBrightnessScale::create( float time )
{
  ActionBrightnessScale* action = new ActionBrightnessScale();
  action->autorelease();
  action->total_time_ = time;
  return action;
}

bool ActionBrightnessScale::isDone( void )
{   
  return (m_fDuration > total_time_);
}

void ActionBrightnessScale::stop( void )
{
  CCFiniteTimeAction::stop();
}

void ActionBrightnessScale::step(float dt)
{
  m_fDuration += dt;

  if(!is_set_shader_)
  {
    m_pTarget->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderBrightScaleWhite));
    is_set_shader_ = true;
  }

  bool is_done = (m_fDuration > total_time_);
  if(is_done && !is_remove_shader_)
  {
    m_pTarget->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderDefault));
    is_remove_shader_ = true;
  }
}

void ActionBrightnessScale::update(float time)
{

}

}