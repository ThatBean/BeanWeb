//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_brigthness_scale.h
//        Author: peteryu
//          Date: 2014/3/6 20:05
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/3/6      add
//////////////////////////////////////////////////////////////

#ifndef ACTION_BRIGTHNESS_SCALE_H
#define ACTION_BRIGTHNESS_SCALE_H

#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;

namespace taomee
{

class ActionBrightnessScale : public CCFiniteTimeAction
{
public:
  ActionBrightnessScale();
  virtual ~ActionBrightnessScale();

  static ActionBrightnessScale* create(float time);

  virtual bool isDone(void);

  virtual void stop(void);

  virtual void step(float dt);

  virtual void update(float time);

protected:
  float   total_time_;
  bool    is_set_shader_;
  bool    is_remove_shader_;
};

}
#endif