//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: EffectChangeColor.cpp
//        Author: peteryu
//          Date: 2013/10/17 20:45
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/17      add
//////////////////////////////////////////////////////////////

#include "game/effect/effect_change_color.h"

#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/move_object.h"

namespace taomee
{
namespace effect
{

EffectChangeColor::EffectChangeColor(army::MoveObject* unit)
  : EffectBase(unit)
{
  program_change_color_ = (shader::ProgramChangeColor*)shader::ShaderManager::GetInstance()->
    GetShaderWithType(shader::kShaderChangeColorTime);
  program_change_color_->SetTime(0.0f);
  program_change_color_->SetColor(changed_color_);
  shader::SetAllNodeWithShader(unit_->anima_node()->GetBodyNode(), program_change_color_);
}

EffectChangeColor::~EffectChangeColor()
{
  unit_->ChangeShaderType();
}

void EffectChangeColor::Update( float delta )
{
  EffectBase::Update(delta);

  float half_last_time = last_time_ / 2.0f;
  // use for shader_change color, u_time [0-1][1-0]
  float result_time = 0.0f;

  if(total_time_ <= half_last_time)
  {
    result_time = total_time_ / half_last_time;
  }
  else if(total_time_ <= last_time_)
  {
    result_time = (last_time_ - total_time_) / half_last_time;
  }
  else
  {
    result_time = 0.0f;
  }

  program_change_color_->SetTime(result_time);
}

}
}
