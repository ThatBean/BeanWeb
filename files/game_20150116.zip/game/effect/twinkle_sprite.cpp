//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: twinkle_sprite.cpp
//        Author: peteryu
//          Date: 2013/10/21 13:45
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/21      add
//////////////////////////////////////////////////////////////
#include "game/effect/twinkle_sprite.h"

#include "game/shader/shader_manager.h"

namespace taomee
{
namespace effect
{

TwinkeSprite::TwinkeSprite()
{
  shader_ = shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderTwinkle);

  u_time_location_        = shader_->getUniformLocationForName("u_time");
  u_light_color_location_ = shader_->getUniformLocationForName("u_light_color");
  u_light_pos_location_   = shader_->getUniformLocationForName("u_light_pos");
  u_tcd_tl_location_      = shader_->getUniformLocationForName("u_tcd_tl");
  u_tcd_tr_location_      = shader_->getUniformLocationForName("u_tcd_tr");
  u_tcd_bl_location_      = shader_->getUniformLocationForName("u_tcd_bl");
  u_tcd_br_location_      = shader_->getUniformLocationForName("u_tcd_br");

  light_color_ = ccc4f(1.0f, 1.0f, 1.0f, 0.0f);
  light_pos_  = ccc4f(0.5f, 0.5f, 1.0f, 0.0f);
}

TwinkeSprite::~TwinkeSprite()
{

}

void TwinkeSprite::draw( void )
{
  if(shader_ != getShaderProgram())
    setShaderProgram(shader_);

  shader_->use();

  shader_->setUniformLocationWith1f(u_time_location_, time_);
  shader_->setUniformLocationWith4f(u_light_color_location_, light_color_.r,
    light_color_.g, light_color_.b, light_color_.a);
  shader_->setUniformLocationWith3f(u_light_pos_location_, light_pos_.r,
    light_pos_.g, light_pos_.b);
  shader_->setUniformLocationWith2f(u_tcd_tl_location_, \
    m_sQuad.tl.texCoords.u, m_sQuad.tl.texCoords.v);
  shader_->setUniformLocationWith2f(u_tcd_tr_location_, \
    m_sQuad.tr.texCoords.u, m_sQuad.tr.texCoords.v);
  shader_->setUniformLocationWith2f(u_tcd_bl_location_, \
    m_sQuad.bl.texCoords.u, m_sQuad.bl.texCoords.v);
  shader_->setUniformLocationWith2f(u_tcd_br_location_, \
    m_sQuad.br.texCoords.u, m_sQuad.br.texCoords.v);

  CCSprite::draw();
}

CCSprite* TwinkeSprite::create()
{
  CCSprite *pSprite = new TwinkeSprite();
  if (pSprite && pSprite->init())
  {
    pSprite->autorelease();
    return pSprite;
  }
  CC_SAFE_DELETE(pSprite);
  return NULL;
}

}
}
