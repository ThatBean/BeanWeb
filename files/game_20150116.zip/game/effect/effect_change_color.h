//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: EffectChangeColor.h
//        Author: peteryu
//          Date: 2013/10/17 20:15
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/17      add
//////////////////////////////////////////////////////////////

#ifndef EFFECTCHANGECOLOR_H
#define EFFECTCHANGECOLOR_H

#include "game/effect/effect_base.h"

#include "engine/base/cocos2d_wrapper.h"
#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_color.h"

using namespace cocos2d;

namespace taomee{
namespace effect
{

class EffectChangeColor
  : public EffectBase
{
public:
  EffectChangeColor(army::MoveObject* unit);
  virtual ~EffectChangeColor();

  virtual void Update(float delta);
  virtual bool IsRemoveable(){return total_time_ >= last_time_;}
  void         SetChangeColor(ccColor4F changed_color)
  {
    changed_color_ = changed_color; 
    program_change_color_->SetColor(changed_color_);
  }

private:
  ccColor4F                   changed_color_;
  shader::ProgramChangeColor  *program_change_color_;
};

} //namespace taomee
} //namespace effect 

#endif