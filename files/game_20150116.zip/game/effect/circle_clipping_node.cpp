//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: circle_clipping_node.cpp
//        Author: peteryu
//          Date: 2013/12/19 14:14
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/12/19      add
//////////////////////////////////////////////////////////////
#include "game/effect/circle_clipping_node.h"

#include "engine/geometry/geometry_const.h"

namespace taomee
{

CircleClippingNode::CircleClippingNode():
  m_pInnerStencil(NULL),
  m_radius(0.0f),
  m_bEnabled(true),
  m_bClippingEnabled(true)
{

}

CircleClippingNode::~CircleClippingNode()
{

}

CircleClippingNode* CircleClippingNode::create(const char* file_path)
{
  CircleClippingNode *pRet = new CircleClippingNode();
  pRet->m_sSpritePath      = file_path;

  if (pRet && pRet->init())
  {
    pRet->autorelease();
  }
  else
  {
    CC_SAFE_DELETE(pRet);
  }

  return pRet;
}

bool CircleClippingNode::init()
{
  m_pInnerStencil = CCDrawNode::create();
  m_sprite        = CCSprite::create(m_sSpritePath.c_str());
  this->addChild(m_sprite);

  m_radius = m_sprite->getContentSize().width / 2;
  setContentSize(m_sprite->getContentSize());
  setStencilData();
  
  if (CCClippingNode::init(m_pInnerStencil))
  {
    return true;
  }
  return false;
}


void CircleClippingNode::setClippingRadius(float radius)
{
  m_radius = radius;
  setContentSize(CCSize(m_radius, m_radius));
  setStencilData();
}

void CircleClippingNode::setClippingEnabled(bool enabled)
{
  m_bClippingEnabled = enabled;
}

void CircleClippingNode::visit()
{
  if (!m_bEnabled)
  {
    return;
  }
  if (m_bClippingEnabled)
  {
    CCClippingNode::visit();
  }
  else
  {
    CCNode::visit();
  }
}

void CircleClippingNode::setEnabled(bool enabled)
{
  m_bEnabled = enabled;
}

bool CircleClippingNode::isEnabled() const
{
  return m_bEnabled;
}

void CircleClippingNode::setStencilData()
{
  ccColor4F green = {0, 1, 0, 1};
  m_pInnerStencil->clear();
  CCPoint points[DEAULT_CIRCLE_POINT_COUNT];
  for(int i = 0; i < DEAULT_CIRCLE_POINT_COUNT; ++i)
  {
    points[i].x = m_radius * (DefaultCircleData[i * 2]);
    points[i].y = m_radius * (DefaultCircleData[i * 2 + 1]);
  }
  m_pInnerStencil->drawPolygon(points, DEAULT_CIRCLE_POINT_COUNT, green, 0, green);
}

void CircleClippingNode::setClippingSpriteAnchorPoint(CCPoint anchorPoint )
{
  m_sprite->setAnchorPoint(anchorPoint);
}

void CircleClippingNode::setInverted(bool bInverted)
{
	m_bInverted = bInverted;
}


}