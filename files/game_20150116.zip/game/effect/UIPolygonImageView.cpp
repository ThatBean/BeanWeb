#include "game/effect/UIPolygonImageView.h"
#include <stdio.h>

#include "game/shader/shader_manager.h"

namespace taomee{


UIPolygonImageView::UIPolygonImageView():
  m_pmask_data(NULL),
  m_effect_type(kPolygonImageEffectTypeHighLight)
{

}

UIPolygonImageView::~UIPolygonImageView()
{
  CC_SAFE_DELETE_ARRAY(m_pmask_data);
}

UIPolygonImageView* UIPolygonImageView::create()
{
    UIPolygonImageView* widget = new UIPolygonImageView();
    if (widget && widget->init())
    {
        widget->autorelease();
        return widget;
    }
    CC_SAFE_DELETE(widget);
    return NULL;
}

void UIPolygonImageView::loadTexture(const char *fileName)
{
   UIImageView::loadTexture(fileName, UI_TEX_TYPE_LOCAL);
   loadMaskData(fileName);
}

void UIPolygonImageView::onPressStateChangedToNormal()
{
  if(m_effect_type == kPolygonImageEffectTypeHighLight)
  {
    m_pImageRenderer->setShaderProgram(
      shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderDefault));
  }
  else
  {
    setColor(ccc3(100, 100, 100));
  }
  setZOrder(m_ilast_zorder);
}

void UIPolygonImageView::onPressStateChangedToPressed()
{
  m_ilast_zorder = getZOrder();
  setZOrder(m_ilast_zorder + 1);
  if(m_effect_type == kPolygonImageEffectTypeHighLight)
  {
    m_pImageRenderer->setShaderProgram(
      shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderPolygonImageBright));
  }
  else
  {
    setColor(ccc3(255, 255, 255));
  }
}

void UIPolygonImageView::setPressEffectType( ePolygonImageEffectType effect_type )
{
  m_effect_type = effect_type;
}

bool UIPolygonImageView::hitTest( const CCPoint &pt )
{
  CCPoint nsp = m_pRenderer->convertToNodeSpace(pt);
  CCRect bb = CCRectMake(-m_size.width * m_anchorPoint.x, -m_size.height * m_anchorPoint.y, m_size.width, m_size.height);
  if (nsp.x >= bb.origin.x && nsp.x <= bb.origin.x + bb.size.width && nsp.y >= bb.origin.y && nsp.y <= bb.origin.y + bb.size.height)
  {
    CCPoint real_point(nsp.x - bb.origin.x, nsp.y - bb.origin.y);
    real_point.y = bb.size.height - real_point.y;
    int width = bb.size.width;
    int x = real_point.x;
    int y = real_point.y;
    //CCLog("x: %d, y: %d", x, y);
    /*
    unsigned int *temp_p = (unsigned int*)m_pimage_data->getData();
    unsigned int color = *(temp_p + width * y + x);
    unsigned char r = (color >> 0) & 0xFF;    // r
    unsigned char g = (color >> 8) & 0xFF;    // g
    unsigned char b = (color >> 16) & 0xFF;   // b
    unsigned char a = (color >> 24) & 0xFF;   // a

    CCLog("Color: %d, %d, %d, %d", (int)r, (int)g, (int)b, (int)a);
    */
    if(getMaskData((width * y + x)))
      return true;
    
  }
  
  return false;
}

void UIPolygonImageView::loadMaskData( const char* fileName )
{
  cocos2d::CCImage *image = new cocos2d::CCImage();
  image->initWithImageFile(fileName);

  unsigned char*            tempData = image->getData();
  unsigned int*             inPixel32  = NULL;
  unsigned char*            inPixel8 = NULL;
  unsigned short*           outPixel16 = NULL;
  bool                      hasAlpha = image->hasAlpha();
  CCSize                    imageSize = CCSizeMake((float)(image->getWidth()), (float)(image->getHeight()));
  CCTexture2DPixelFormat    pixelFormat;
  size_t                    bpp = image->getBitsPerComponent();

  // compute pixel format
  if (hasAlpha)
  {
    pixelFormat = kCCTexture2DPixelFormat_Default;
  }

  // Repack the pixel data into the right format
  unsigned int length = imageSize.width * imageSize.height;

  // init mask data
  m_pmask_data = new unsigned char[(length + 7) / 8];
  //m_pdata = new unsigned char[length];

  // Convert "RRRRRRRRRGGGGGGGGBBBBBBBBAAAAAAAA" to "A"
  unsigned char c;
  inPixel32 = (unsigned int*)image->getData();
  memset(m_pmask_data, 0, sizeof(unsigned char) * (length + 7) / 8);

  // pixel permutation
  // 012
  // 345
  // 678
  for(unsigned int i = 0; i < length; ++i, ++inPixel32)
  {
      c = (*inPixel32 >> 24) & 0xFF;  // A
      //if(c == 3)
      //  c = 3;
      if(c)
        setMaskData(i, c);
  }
  //m_pimage_data = image;
  CC_SAFE_RELEASE(image);
}

}