//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_shader_base.h
//        Author: peteryu
//          Date: 2014/4/2 15:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/2      add
//////////////////////////////////////////////////////////////

#ifndef ACTION_SHADER_BASE_H
#define ACTION_SHADER_BASE_H

#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;

namespace taomee
{

class ActionShaderBase : public CCFiniteTimeAction
{
public:
  ActionShaderBase()
    : round_time_(0.0f),
      round_count_(1),
      cur_round_count_(0),
      cur_round_time_(0.0),
      is_started_(false),
      default_shader_program_(NULL),
      shader_program_(NULL){}

  virtual ~ActionShaderBase(){}

  virtual bool isDone(void)
  { 
    return round_count_ == -1 ? false : (m_fDuration > round_time_ * round_count_);
  }

  virtual void start(void){}

  virtual void round_start(void){}

  virtual void stop(void){CCFiniteTimeAction::stop();}

  virtual void step(float dt)
  { 
    m_fDuration += dt; 
    
    if(!is_started_)
    {
      is_started_ = true;
      start();
    }
    else
    {
      if(m_pTarget->getShaderProgram() != shader_program_ && shader_program_ != NULL)
      {
        m_pTarget->setShaderProgram(shader_program_);
      }
    }

    if(m_fDuration >= round_time_ * cur_round_count_)
    {
      round_start();
      ++cur_round_count_;
      cur_round_time_ = 0.0f;
    }
    else
    {
      cur_round_time_ += dt;
    }
  }

protected:
  float     round_time_;
  int       round_count_;
  int       cur_round_count_;
  float     cur_round_time_;
  bool      is_started_;
  bool      is_force_end_;
  CCGLProgram   *default_shader_program_;
  CCGLProgram   *shader_program_;
};

}
#endif