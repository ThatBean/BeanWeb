//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: skeleton_animation_manager.cpp
//        Author: peteryu
//          Date: 2013/10/12 14:14
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/12      add
//////////////////////////////////////////////////////////////

#include "game/effect/skeleton_animation_manager.h"

#include "game/effect/touch_area_node_factory.h"
#include "game/effect/touch_area_layer.h"
#include "game/battle/battle_hub.h"
#include "game/battle/view/battle_view.h"

#include "game/shader/shader_manager.h"
#include "game/effect/effect_change_color.h"

namespace taomee
{
namespace effect{

SkeletonAnimationManager::SkeletonAnimationManager(army::MoveObject *unit)
  : unit_(unit)
  , guard_area_last_time_(0.0f)
  , guard_area_total_time_(0.0f)
  , guard_area_is_started_(false)
{

}

SkeletonAnimationManager::~SkeletonAnimationManager()
{
  for(std::list<EffectBase*>::iterator itr = effect_list_.begin();
    itr != effect_list_.end(); ++itr)
  {
    delete (*itr);
  }
  effect_list_.clear();
}

void SkeletonAnimationManager::StartHitRedShader( float last_time )
{
  effect::EffectChangeColor *effectChangeColor = new effect::EffectChangeColor(unit_);
  effectChangeColor->SetLastTime(last_time);
  effectChangeColor->SetChangeColor(ccc4f(1.0f, 0.0f, 0.0f, 0.6f));
  PushEffectToList(effectChangeColor);
}

void SkeletonAnimationManager::StartHealGreenShader( float last_time )
{
  effect::EffectChangeColor *effectChangeColor = new effect::EffectChangeColor(unit_);
  effectChangeColor->SetLastTime(last_time);
  effectChangeColor->SetChangeColor(ccc4f(0.0f, 0.5f, 0.0f, 0.5f));
  PushEffectToList(effectChangeColor);
}

void SkeletonAnimationManager::Update(float delta_time)
{
  for(std::list<EffectBase*>::iterator itr = effect_list_.begin();
    itr != effect_list_.end(); )
  {
    if((*itr)->IsRemoveable())
    {
      delete (*itr);
      itr = effect_list_.erase(itr);
      continue;
    }

    (*itr)->Update(delta_time);
    ++itr;
  }

  if(guard_area_is_started_)
  {
    guard_area_total_time_ += delta_time;
    if(guard_area_total_time_ > guard_area_last_time_)
    {
      cocos2d::CCNode *bind_node = unit_->owner_hub()->battle_view()->
        GetLayerBindNode(battle::kBottomLayer, unit_->move_object_id());

      effect::TouchAreaLayer* touch_area_layer = dynamic_cast<effect::TouchAreaLayer*>(bind_node->getChildByTag(234525344));
      if (touch_area_layer != NULL)
      {
        touch_area_layer->FadeOut();
      }

      guard_area_is_started_ = false;
    }
  }
}

void SkeletonAnimationManager::StartGuardArea( float last_time )
{
  if(guard_area_is_started_)
    return;
  guard_area_last_time_ = last_time;
  guard_area_total_time_ = 0.0f;
  guard_area_is_started_ = true;

  cocos2d::CCNode* node = effect::TouchAreaLayer::create(unit_, kTouchAreaGuard);
//  cocos2d::CCNode* node = effect::TouchAreaNodeFactory::CreateAreaNode(unit_, kTouchAreaGuard);
  node->setPosition(ccpSub(unit_->GetCenterPointOnGridNode(), unit_->current_pos()));
  node->setPosition(ccpSub(node->getPosition(), ccp(0, 15)));

//  cocos2d::CCNode* node = effect::TouchAreaNodeFactory::CreateAreaNode(unit_, effect::kTouchAreaGuard);
  cocos2d::CCNode *bind_node = unit_->owner_hub()->battle_view()->
    GetLayerBindNode(battle::kBottomLayer, unit_->move_object_id());
  bind_node->addChild(node, -10, 234525344);
}

void SkeletonAnimationManager::RemoveGuardArea()
{
  cocos2d::CCNode *bind_node = unit_->owner_hub()->battle_view()->
      GetLayerBindNode(battle::kBottomLayer, unit_->move_object_id());

  effect::TouchAreaLayer* touch_area_layer = dynamic_cast<effect::TouchAreaLayer*>(bind_node->getChildByTag(234525344));
  if (touch_area_layer != NULL)
  {
    touch_area_layer->Remove();
  }
  guard_area_is_started_ = false;
}

}// namespace effect
}// namespace taomee
