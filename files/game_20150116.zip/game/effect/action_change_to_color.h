//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: action_change_to_color.h
//        Author: peteryu
//          Date: 2014/4/21 18:43
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/21      add
//////////////////////////////////////////////////////////////

#ifndef ACTION_CHANGE_TO_COLOR_H
#define ACTION_CHANGE_TO_COLOR_H

#include "engine/base/cocos2d_wrapper.h"
#include "game/effect/action_shader_base.h"

using namespace cocos2d;

namespace taomee
{

class ActionChangeToColor : public ActionShaderBase
{
public:
  ActionChangeToColor();
  virtual ~ActionChangeToColor();

  /*
  * time:       single round time, time == 0.0 means all add selfcolor to scale_max
  * color:      added color
  * count:      round count
  * scale_max:  max color factor 0.0 means not change, 1.0 means change to color
  */
  static ActionChangeToColor* create( float round_time, const ccColor4F& color,
                                      int round_count = -1, float scale_max = 0.4);

  virtual bool isDone(void);

  virtual void start(void);

  virtual void round_start(void);

  virtual void stop(void);

  virtual void step(float dt);

protected:
  float     scale_min_;
  float     scale_max_;
  ccColor4F color_;
};

}
#endif