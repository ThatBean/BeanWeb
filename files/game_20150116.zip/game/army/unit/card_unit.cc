//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  card_unit.cc
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  3:01
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/card_unit.h"

namespace taomee {
namespace army {

CardUnit::CardUnit() {
  this->ClearAllProperties();
}
 
CardUnit::~CardUnit() {
  
}

void CardUnit::ClearAllProperties() {
  card_id_                  = 0;
  card_name_.clear();
  growth_type_              = kCardGrowthTypeUnkown;
  rarity_level_             = 1;
  housing_cost_             = 0;
  gender_type_              = kUnitRaceTypeUnkown;
  career_                   = kCareerTypeUnkown;
  motion_type_              = 0;
  attack_type_              = kAttackTypeUnkown;
  break_count_              = 0;
//  max_level_                = 0;
  init_hp_                  = 0;
  attack_damage_            = 0;
  skill_name_.clear();
  skill_text_.clear();
  skill_param1_             = 0.0f;
  skill_param2_             = 0.0f;
  skill_param3_             = 0.0f;
  skill_type_flag_          = 0;
  attack_speed_             = 0.0f;
  move_speed_               = 0.0f;
  bullet_fly_speed_         = 0.0f;
  attack_flag_              = 0;
  weak_flag_                = 0;
  defense_bonus_            = 0;
  defense_physics_damage_   = 1.0f;
  defense_magic_damage_     = 1.0f;
  critical_                 = 0.0f;
  guard_type_               = 0;
  attack_range_             = 0.0f;
  body_range_               = 0.0f;
  model_scale_              = 0.0f;
  effect_id_                = 0;
  sound_effect_name_.clear();
  first_quest_id_           = 0;
  first_scene_id_           = 0;
  first_meet_card_id_       = 0;
  meet_dialog_.clear();
  displayed_quest_id_       = 0;
  is_enemy_                 = false;
  for (int i = 0; i<4; ++i) {
    skill_ids_[i]           = 0;
  }
  release_cost_of_skill_count_ = 0;
}
  
} // army
} // taomee