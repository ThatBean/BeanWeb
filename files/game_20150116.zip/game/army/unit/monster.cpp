//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  monster.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/monster.h"

#include "game/battle/battle_controller.h"
#include "game/game_manager/data_manager.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/view/player_box.h"
#include "engine/ui_factory/ui_factory.h"

namespace taomee {
namespace army {
  
Monster::Monster( battle::BattleHub* owner, uint_32 global_id)
  : MoveObject(owner, global_id),
    intent_type_(ai::kAIStateInvalid),
    born_line_(ai::kAIBornRandom),
    timestamp_(0)
{
  move_object_type_ = army::kMoveObjectType_Monster;
}

Monster::~Monster()
{
  this->ClearAllProperties();
}

int_32 Monster::GetWeaponId()
{
  return -1;
}

uint_8 Monster::getSkillLevel(uint_32 skill_id)
{
	return level_;
}
  
void Monster::ClearAllProperties()
{
  MoveObject::ClearAllProperties();
  current_weapon_id_                      = -1;
  current_weapon_id_other_                = -1;
  intent_type_                            = ai::kAIStateInvalid;
  born_line_                              = ai::kAIBornRandom;
  timestamp_                              = 0;
}
  
bool Monster::Update(float delta)
{
  MoveObject::Update(delta);
  // battle failed cos monster go into right rectangle
  if (tile_index_ == battle::kBorderRightFailedTileIndex)
  {
	if (this->is_active())
	{
		battle::BattleController::GetInstance().notifyMonsterMoveToRightBorder(this->move_object_id());
	}
  }
  return true;
}
  
bool Monster::InitMoveObjectDataFromFile(bool needInitBattleData /* = true */)
{
  if (false == MoveObject::InitMoveObjectDataFromFile(needInitBattleData))
  {
    return false;
  }
  // calculation for level related data
  int hp = DataManager::GetInstance().calculator()->
                HPCalculatorForMonsterByCardIdAndLevel(card_id_, this->level(),this->des_hp_mult());
  this->set_base_total_health_point(hp);
  // currnet_health_point_ > 0 means undead monsters in battle revive
  if (this->currnet_health_point()==0)
  {
    this->set_currnet_health_point(hp);
  }

  int phy_attack = DataManager::GetInstance().calculator()->PhyAttackCalculatorForMonsterByCardIdAndLevel(card_id_, this->level(),this->des_att_mult());
  int mag_attack = DataManager::GetInstance().calculator()->MagAttackCalculatorForMonsterByCardIdAndLevel(card_id_, this->level(),this->des_att_mult());
  float hit_rate = DataManager::GetInstance().calculator()->PropertyCalculatorForCharacterByCardIdAndType(card_id_, kAttrTypeHitRate, this->level());
  float dodge = DataManager::GetInstance().calculator()->PropertyCalculatorForCharacterByCardIdAndType(card_id_,kAttrTypeDodgeRate, this->level());

  this->set_basic_physics_attack_(phy_attack);
  this->set_basic_magic_attack_(mag_attack);
  this->set_basic_hit_rate(hit_rate);
  this->set_basic_dodge(dodge);


  int current_weapon_id = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id_)->GetWeaponId();
  this->set_current_weapon_id(current_weapon_id);
  return true;
}
  
void Monster::addUnitAniamtion()
{
  // add common elements in base class
  MoveObject::addUnitAniamtion();
  // add health bar for monster
  UILayer* ui_layer = dynamic_cast<UILayer*>(anima_node_->getChildByTag(kHitPointBarFlag));
  assert(ui_layer);
  ui_layer->addWidget(UIFactory::createWidgetFromFile("ui/agoui_monster_hp.json"));  

  set_anima_direction(kDirectionRight);
  this->initHealthBarPercent();
}
  
} // army
} // taomee
