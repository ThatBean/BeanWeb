//
//  unit_constants.cpp
//  ChainChronicle
//
//  Created by gaven on 9/22/13.
//
//

#include "game/army/unit/unit_constants.h"

#include <cassert>

#include "game/game_manager/data_manager.h"

#include "engine/base/utils_string.h"

namespace taomee {
namespace army {

std::string GetMoveObjectNameByCardId(uint_32 card_id)
{ 
  CharacterData* cardData = DataManager::GetInstance().
    GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetName();
}

char* GetMoveObjectNameCStrByCardId(uint_32 card_id)
{
	return (char*)(GetMoveObjectNameByCardId(card_id).c_str());
}
  
std::string GetMoveObjectNameCNByCardId(uint_32 card_id)
{
  CharacterData* cardData = DataManager::GetInstance().
    GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetName();
}

eGender GetMoveObjectGenderByCardId(uint_32 card_id)
{
  CharacterData* cardData = DataManager::GetInstance().
    GetCharacterDataTable()->GetCharacter(card_id);
  return static_cast<eGender>(cardData->GetGender());
}
  
eCardGrowthType GetMoveObjectGrowthTypeByCardId(uint_32 card_id)
{
  CharacterData* cardData = DataManager::GetInstance().
  GetCharacterDataTable()->GetCharacter(card_id);
  return static_cast<eCardGrowthType>(cardData->GetGrowth());
}

uint_8 GetMoveObjectRarityCountByCardId(uint_32 card_id)
{
  CharacterData* cardData = DataManager::GetInstance().
  GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetRarity();
}
  
eCareerType GetMoveObjectCareerByCardId(uint_32 card_id)
{ 
  CharacterData* cardData = DataManager::GetInstance().
    GetCharacterDataTable()->GetCharacter(card_id);
  if (!cardData)
  {
	  return kCareerTypeUnkown;
  }
  
  return static_cast<eCareerType>(cardData->GetJobType());
}
  
uint_8      GetMoveObjectSkillCostNumByCardId(uint_32 card_id)
{
  CharacterData* cardData = DataManager::GetInstance().
    GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetSkillCost();
}

uint_32     GetMoveObjectSkillIdByCardId(uint_32 card_id)
{
  CharacterData* cardData = DataManager::GetInstance().
    GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetSkillId(kSkillSkill);
}
  
eAttackType GetMoveObjectAttackTypeByCareerType(eCareerType career)
{
  switch (career)
  {
    case kCareerTypeWarrior:
    case kCareerTypeKnight:
      return kAttackTypeAttack;
      break;
    
    case kCareerTypeArcher:
    case kCareerTypeWizard:
      return kAttackTypeShot;
      break;
      
    case kCareerTypeMonk:
      return kAttackTypeHeal;
      break;
      
    default:
      assert(false);
      return kAttackTypeUnkown;
      break;
  }
}

eAttackType GetMoveObjectAttackTypeByCardId(uint_32 card_id)
{
  return GetMoveObjectAttackTypeByCareerType(GetMoveObjectCareerByCardId(card_id));
}

int GetMoveObjectTroopsType(uint_32 unit_id)
{
	if ( unit_id >= army::kCharaterObject_StartId && unit_id <= army::kCharaterObject_EndId)
	{
		return army::kCharaterObject_StartId;
	}
	else if ( unit_id >= army::kMonsterObject_StartId && unit_id <= army::kMonsterObject_EndId)
	{
		return army::kMonsterObject_StartId;
	}
	else if ( unit_id >= army::kPvPCharaterObject_StartId && unit_id <= army::kPvPCharaterObject_EndId)
	{
		return army::kPvPCharaterObject_StartId;
	}
	else if ( unit_id >= army::kCharaterSummonObject_StartId && unit_id <= army::kCharaterSummonObject_EndId)
	{
		return army::kCharaterSummonObject_StartId;
	}
	else if ( unit_id >= army::kMonsterSummonObject_StartId && unit_id <= army::kMonsterSummonObject_EndId)
	{
		return army::kMonsterSummonObject_StartId;
	}

	return army::kUnexistTargetId;
}

bool AreTwoMoveObjectsInTheSameForceHub(uint_32 unit_id1, uint_32 unit_id2)
{
	int tt1 = GetMoveObjectTroopsType(unit_id1);
	int tt2 =GetMoveObjectTroopsType(unit_id2);
	if ( tt1 == tt2)
	{
		return true;
	}
	else if ( tt1 == army::kCharaterObject_StartId && tt2 == army::kCharaterSummonObject_StartId )
	{
		return true;
	}
	else if ( ( tt1 == army::kMonsterObject_StartId || tt1 == army::kPvPCharaterObject_StartId ) && tt2 == army::kMonsterSummonObject_StartId )
	{
		return true;
	}
	
	return false;
}

float GetMoveObjectCriticalByCardId( uint_32 card_id )
{
  CharacterData* cardData = DataManager::GetInstance(). \
    GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetCritical();
}

float GetMoveObjectShotSpeedMultipleByCardId( uint_32 card_id )
{
  CharacterData* cardData = DataManager::GetInstance(). \
    GetCharacterDataTable()->GetCharacter(card_id);
  return cardData->GetShotSpeedMultiple();
}

int getTagByName(const std::string& name)
{
	static std::map<std::string, unsigned int> string_bkd_hash_map;

	std::map<std::string, unsigned int>::iterator iter = string_bkd_hash_map.find(name);
	if ( iter != string_bkd_hash_map.end() )
	{
		return iter->second;
	}

	int hash_num = StringBKDRHash(name.c_str());

	string_bkd_hash_map[name] = hash_num;

	return hash_num;
}
  
} /* namespace army */
} /* namespace taomee */
