//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  monster.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/monster.h"

#ifndef ChainChronicle_summon_h
#define ChainChronicle_summon_h

namespace taomee {
namespace army {
  
class Summon : public Monster
{
public:
	Summon(battle::BattleHub* owner, uint_32 global_id);
	~Summon();

public:
	virtual bool Update(float delta);
public:
	void set_summoner_id( uint_32 summoner_id)
	{
		summoner_id_ = summoner_id;
	}

private:
	uint_32 summoner_id_;
};
  
} // army
} // taomee

#endif // ChainChronicle_monster_h
