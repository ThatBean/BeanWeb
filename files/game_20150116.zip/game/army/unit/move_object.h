//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  move_object.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-10
//          Time:  2:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-10        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_move_object_h
#define ChainChronicle_move_object_h

#include "engine/animation/animation_constant.h"
#include "engine/animation/skeleton_animation.h"
#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/geometry/geometry.h"
#include "game/army/unit/unit_constants.h"
#include "game/artificial_intelligence/trigger/target_selection.h"
#include "game/artificial_intelligence/trigger/trigger.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "game/artificial_intelligence/motion_state/motion_state_constants.h"
#include "game/battle/damage/damage_constants.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/view/battle_damage_label.h"
#include "game/effect/skeleton_animation_manager.h"
#include "game/passive_ability/passive_ability_constants.h"
#include "engine/base/loggermanager.h"
#include "game/passive_ability/shield.h"

namespace actor
{
  class Actor;
}


USING_NS_CC_EXT;

namespace taomee {
  
class SkeletonAnimation;
  
namespace battle {
  class BattleView;
  class BattleHub;
}
  
namespace ai {
  class AIStateMachine;
  class MotionStateMachine;    
  class Trigger;
}

namespace effect {
  class SkeletonAnimationManager;
}

namespace army {

class Summon;

enum eStageState
{
  kStageBorn,
  kStageAttack,
  kStageMoveEnd
};

enum eSkillTripleState
{
  kSkillTripleStateReady,
  kSkillTripleStateAccPower,
  kSkillTripleStateRelease,
  kSkillTripleStateEnd
};

struct DamageLabelParam{

	DamageLabelParam()
	{
		damage_value = 0;
		damege_label_type = battle::eDamageLabelType_Unknown;
	}

	int damage_value;
	battle::eDamageLabelType damege_label_type;
};

class MoveObject
{
public:  
  MoveObject(battle::BattleHub* owner, uint_32 global_id/* = army::kUnexistTargetId*/);
  virtual ~MoveObject();
    
public: 
  virtual bool Update(float delta);

  virtual void ClearAllProperties();
  // create passvie ability
  virtual void CreatePassiveAbilities(bool isBackStageNeed = false);
  // memeory malloc & initialize
  virtual bool InitMoveObjectDataFromFile(bool needInitBattleData = false);

  virtual Summon* SummonElement(uint_16 level, uint_32 card_id, int_8 tileIdx);
public: // getter & setter
  virtual int_32 GetWeaponId() { return 0; }
  
  // active flag
  virtual bool        is_active() {
	  return is_active_;
  }
  void set_is_active(bool flag)
  {
	  is_active_ = flag;
  }

  bool is_temp_dead()
  {
	  return is_temp_dead_;
  }
  void set_temp_dead(bool flag)
  {
	  is_temp_dead_ = flag;
  }
  
  // unique instance id for this move object
  virtual uint_32     move_object_id() {
	  return move_object_id_;
  }

  virtual uint_8 getSkillLevel(uint_32 skill_id)
  {
	  return 1;
  }


  army::kMoveObjectType move_object_type()
  {
	  return move_object_type_;
  }

  void                set_move_object_id(uint_32 obj_id) {
    move_object_id_ = obj_id;
  }
  
  std::vector<int>& skill_ids()
  {
    return passive_skill_ids_;
  }
  void AddOneUnlockedSkillId(uint_16 newId)
  {
    passive_skill_ids_.push_back(newId);
    assert(passive_skill_ids_.size()<kMaxPassiveSkillsCount);
  }
  void          set_skill_ids(std::vector<uint_16>& ids)
  {
    passive_skill_ids_.clear();
    passive_skill_ids_.assign(ids.begin(), ids.end());
    assert(passive_skill_ids_.size()<kMaxPassiveSkillsCount);
  }
  
  // card id : query static data from card units list by this id
  uint_32             card_id() {
    return card_id_;
  }
  void                set_card_id(uint_32 c_id) {
    card_id_ = c_id;
  }

  CharacterData* character_card_data()
  {
	  return character_card_data_;
  }

  eCareerType GetCareerType();

  const std::string& GetCardName();
  
  // range attacker's bullet run through damage percent
  float              run_through_damage_multiple()
  {
    return run_through_damage_multiple_;
  }
  void                set_run_through_damage_multiple(float mul)
  {
    run_through_damage_multiple_ = max(0.1f, mul);
  }
  
  uint_8              favorite_gender_target() { return favorite_gender_target_; }
  void                set_favorite_gender_target(uint_8 type)
  {
    favorite_gender_target_ = type;
  }
  
  // current attack status
  uint_32             attack_status();
  void                set_attack_status(uint_32 flag, eAttackElementsPropertyPriority priority = kAEPPPassiveAbilitySet);
  void                ResetAttackStatus(uint_32 flag, eAttackElementsPropertyPriority priority = kAEPPPassiveAbilitySet);
  
  // current immune status
  uint_32           immune_status_flag(){return immune_status_flag_;}

  bool				check_immune_status_flag(battle::eImmuneType flag);

  void				retain_immune_status_flag(uint_32 flag);
  void				retain_immune_status_flag(battle::eImmuneType flag);

  void				release_immune_status_flag(uint_32 flag);
  void				release_immune_status_flag(battle::eImmuneType flag);

  // current battle status
  uint_32           battle_status_flag()
  {
	  return battle_status_flag_;
  }

  bool				check_battle_status_flag(battle::eDamageStatus flag);
  
  void				retain_battle_status_flag(uint_32 flag);
  void				retain_battle_status_flag(battle::eDamageStatus flag);
  
  void				release_battle_status_flag(uint_32 flag);
  void				release_battle_status_flag(battle::eDamageStatus flag);
  
  //
  uint_32             favorite_target_status()
  { 
	  return favorite_target_status_; 
  }
  void                set_favorite_target_status(uint_32 status)
  {
    favorite_target_status_ = favorite_target_status_|status;
  }

  void                reset_favorite_target_status(uint_32 status)
  {
	  favorite_target_status_ = favorite_target_status_ & (~status);
  }

  void set_basic_critical_damage( float val);
  void set_critical_damage_added(float val);
  void set_critical_damage_multiple(float val);
  float critical_damage();

  float GetElementsDamageWeakenMultiple(battle::eDamageStatus type);
  void SetElementsDamageWeakenMultiple(uint_32 type, float addedMul);

	float GetElementsDamageAddedMultiple(battle::eDamageStatus type);
	void SetElementsDamageAddedMultiple(uint_32 type, float addedMul);
  
  float status_damage_boost_multiple()
  {
    return status_damage_boost_multiple_;
  }
  void set_status_damage_boost_multiple(float mul)
  {
    status_damage_boost_multiple_ += mul;
  }
  void reset_status_damage_boost_multiple(float mul)
  {
	  status_damage_boost_multiple_ -= mul;
  }
  
  float skill_damage_boost_multiple()
  {
	  if ( skill_damage_boost_multiple_ < 0.0f )
	  {
		  return 0.0f;
	  }

    return skill_damage_boost_multiple_;
  }
  void set_skill_damage_boost_multiple(float mul)
  {
    skill_damage_boost_multiple_ += mul;
  }

  void reset_skill_damage_boost_multiple(float mul)
  {
	  skill_damage_boost_multiple_ -= mul;
  }
  
  // shield damage boost
  float               shield_damage_boost_multiple()
  {
    return shield_damage_boost_multiple_;
  }
  void                set_shield_damage_boost_multiple(float mul)
  {
    shield_damage_boost_multiple_ = mul;
  }
  // range attacker's melee attack damage boost
  float               range_attacker_melee_damage_boost_multiple()
  {
    return range_attacker_melee_damage_boost_multiple_;
  }
  void                set_range_attacker_melee_damage_boost_multiple(float mul)
  {
    range_attacker_melee_damage_boost_multiple_ = mul;
  }
  
  // total health point of this move object
  int                 total_health_point() {
    return total_health_point_;
  }

  void set_base_total_health_point(int hp);
  void set_health_upperlimit_added(int added);
  void set_health_upperlimit_multiple(float mul);
  
  // current health point of this move object
  int                 currnet_health_point() {
    return currnet_health_point_;
  }
  void                set_currnet_health_point(int hp);

  float               GetCurrentHealthPointPercent()
  {
    return static_cast<float>(currnet_health_point_)/(total_health_point_);
  }

  void set_basic_physics_attack_( uint_32 vla);
  void set_physics_attack_added( int added );
  void set_physics_attack_multiple(float mul);
  int physics_attack();

  void set_basic_magic_attack_( uint_32 vla);
  void set_magic_attack_added( int added );
  void set_magic_attack_multiple(float mul);
  int magic_attack();

  
  // defense of physics damage : used as multiple
  float               defense_physics_mult() {
    return defense_physics_multiple_;
  }
  void                set_defense_physics_mult(float multiple) {
    defense_physics_multiple_ = multiple;
  }
  void                set_defense_physics_added_mult(float multiple);
  void                reset_defense_physics_added_mult(float multiple);
  
  // defense of migic damage : used as multiple
  float               defense_magic_mult() {
    return defense_magic_multiple_;
  }
  void                set_defense_magic_mult(float multiple) {
    defense_magic_multiple_ = multiple;
  }
  void                set_defense_magic_added_mult(float added);
  void                reset_defense_magic_added_mult(float added);
  
  void set_basic_critical(float val);
  void set_critical_added(float val);
  void set_critical_multiple(float val);
  float critical_probability( float target_level);
  
  
  //physics defense
  int_32 physics_defense();
  void set_basic_physics_defense(int_32 pyhsics_defense);

  void set_physics_defense_added( int_32 added);
  void reset_physics_defense_added( int_32 added);

  //magic_defense
  int_32 magic_defense();
  void set_basic_magic_defense( int_32 basic_magic_defense );

  void set_magic_defense_added(int_32 added);
  void reset_magic_defense_added(int_32 added);

  
  //final defence
  int_32              final_defense()
  {
	  return final_defense_;
  }
  void                set_final_defence(int_32 defence)
  {
    final_defense_ = defence;
  }

   //final damage
  int_32            final_damage()
  {
	  return final_damage_;
  }
  void              set_final_damage(int_32 damage)
  {
    final_damage_ = damage;
  }

  // animation added on battle field layer of this move object
  // special for Motion : do not invoke this node to get position&set position
  virtual SkeletonAnimation*  anima_node()
  {
    return anima_node_;
  }
  effect::SkeletonAnimationManager* anima_manager()
  {
    return anima_manager_; 
  }
  virtual AnimationDirection  anima_direction()
  {
    return anima_node_->GetDirection();
  }
  virtual void                set_anima_direction(AnimationDirection direction)
  {
    anima_node_->ChangeDirection(direction);
  }

  void ChangeSkeleton(bool activete);

  // Status exist time multiple & repeal distance mutiple
  float               repeal_distance_multiple()
  {
    return repeal_distance_multiple_;
  }
  void                set_repeal_distance_multiple(float mul)
  {
    repeal_distance_multiple_ = mul;
  }
  
  const std::map<battle::eDamageStatus, float>& status_exist_time_mutiple()
  {
    return status_exist_time_mutiple_;
  }
  void                 set_status_exist_time_mutiple(const std::map<battle::eDamageStatus, float>& timeMap)
  {
    status_exist_time_mutiple_.clear();
    for (std::map<battle::eDamageStatus, float>::const_iterator it = timeMap.begin();
         it != timeMap.end(); ++it)
    {
      status_exist_time_mutiple_.insert(std::pair<battle::eDamageStatus, float>(it->first, it->second));
    }
  }
  float GetTimeMutipleWithStatusType(battle::eDamageStatus type)
  {
    if (status_exist_time_mutiple_.find(type)!=status_exist_time_mutiple_.end())
    {
      return status_exist_time_mutiple_[type];
    }
    else
    {
      return 1.0f;
    }
  }  
  void SetTimeMutipleforStatusType(uint_32 type, float timeMul)
  {
    for (int i = 0; i<battle::kDamageMax; ++i)
    {
      battle::eDamageStatus singleType = static_cast<battle::eDamageStatus>(1<<i);
      // type not exist
      if (false == (singleType&type))
      {
        continue;
      }
      if (status_exist_time_mutiple_.find(singleType)!=status_exist_time_mutiple_.end())
      {
        status_exist_time_mutiple_[singleType] = status_exist_time_mutiple_[singleType]*timeMul;
      }
      else
      {
        status_exist_time_mutiple_.insert(std::pair<battle::eDamageStatus, float>(singleType, timeMul));
      }
    }
  }
  
  // current tile index of this move object
  int_8             tile_index()
  {
    return tile_index_;
  }
  void                set_tile_index(int_8 tile_idx)
  {
    tile_index_ = tile_idx;
  }
  
  // auto search tile index
  int_8             auto_search_tile_index()
  {
    return auto_search_tile_index_;
  }
  void              set_auto_search_tile_index(int_8 tile_idx)
  {
    auto_search_tile_index_ = tile_idx;
  }

  // current pos
  virtual cocos2d::CCPoint    current_pos() 
  {
    assert(anima_node());
    return anima_node()->getPosition();
  }
  virtual void                set_current_pos(cocos2d::CCPoint pos);

  // charge_dist_
  int_32              charge_dist() 
  {
    return charge_dist_;
  }
  void                set_charge_dist(int_32 dist)
  {
    charge_dist_ = dist;
  }
  
  // skill beatback
  int_32              be_skill_hitmove_offset() 
  {
    return be_skill_hitmove_offset_;
  }
  void                set_be_skill_hitmove_offset(int_32 dist)
  {
    be_skill_hitmove_offset_ = dist;
  }  
  int_32              be_skill_resetmove_offset() 
  {
    return be_skill_resetmove_offset_;
  }
  void                set_be_skill_resetmove_offset(int_32 dist)
  {
    be_skill_resetmove_offset_ = dist;
  }  

  float               damage_boost_multiple();
  void                set_damage_boost_multiple(float multiple);
  void                reset_damage_boost_multiple(float multiple);

  float               heal_boost_multiple();

  void                set_heal_boost_multiple(float mul);
  void                reset_heal_boost_multiple(float mul);

  float by_heal_boost_multiple();

  void set_by_heal_boost_multiple(float mul);
  void reset_by_heal_boost_multiple(float mul);

  void                set_move_speed_boost_multiple(float multiple);
  void                reset_move_speed_boost_multiple(float multiple);
  
  float               attack_speed_boost_multiple()
  {
    return attack_speed_boost_multiple_;
  }

  float physics_blood_boost_multiple();
  void set_physics_blood_boost_multiple(float multiple);
  void reset_physics_blood_boost_multiple(float multiple);

  float magic_blood_boost_multiple();
  void set_magic_blood_boost_multiple(float multiple);
  void reset_magic_blood_boost_multiple(float multiple);

  float physics_thorns_boost_multiple();
  void set_physics_thorns_boost_multiple(float multiple);
  void reset_physics_thorns_boost_multiple(float multiple);

  float magic_thorns_boost_multiple();
  void set_magic_thorns_boost_multiple(float multiple);
  void reset_magic_thorns_boost_multiple(float multiple);

  // attack speed
  float               attack_speed()
  {
	  return attack_speed_*attack_speed_boost_multiple_;
  }
  void                set_attack_speed(float speed) {
	  attack_speed_ = speed;
  }

  void set_energy_value( float vla )
  {
	  energy_value_ = vla;
  }

  void add_energy_value( float added )
  {
	  energy_value_ += added;
  }

  uint_32 energy_value()
  {
	  return energy_value_;
  }

  void set_basic_dodge(float vla);
  void set_dodge_added(float vla);
  void set_dodge_multiple(float mul);
  float get_dodge();

  void set_basic_hit_rate(float vla);
  void set_hit_rate_added(float vla);
  void set_hit_rate_multiple(float mul);
  float get_hit_rate(float target_dodge);

  int level()
  {
	  return level_;
  }
  void set_level(int level)
  {
	  level_ = level;
  }

  void                set_attack_speed_boost_multiple(float multiple);
  void                reset_attack_speed_boost_multiple(float multiple);

  float               by_damage_boost_multiple();
  void                set_by_damage_boost_multiple(float multiple);
  void                reset_by_damage_boost_multiple(float multiple);
      
  void                set_move_speed_value(float v)
  {
    move_speed_value_ = v;
    this->updateMoveSpeed();
  }
  float               mover_speed_value();

  void                set_move_speed(const cocos2d::CCPoint& speed);

  cocos2d::CCPoint    move_speed() {
    return move_speed_;
  }
  void                set_idle_time(float time) {
    idle_time_ = time;
  }
  float               idle_time() {
    return idle_time_;
  }
  void                set_stage_time(float time)
  {
    stage_time_ = time;
  }
  float               stage_time()
  {
    return stage_time_;
  }

  void set_slay_condition_rate(float rate)
  {
	  slay_condition_rate_ = rate;
  }
  float slay_condition_rate()
  {
	  return slay_condition_rate_;
  }

  float slay_damage_multiple()
  {
	  return slay_damage_multiple_;
  }

  

  void set_slay_damage_multiple(float mult)
  {
	  slay_damage_multiple_ = mult;
  }

  void                set_stage_state(eStageState state)
  {
    stage_state_ = state;
  }
  eStageState         stage_state()
  {
    return stage_state_;
  }
  void                set_stage_stay_column(int col)
  {
    state_stay_column_ = col;
  }
  int                 stage_stay_column()
  {
    return state_stay_column_;
  }
  bool                is_visible()
  {
    return is_visible_;
  }
  void                set_is_visible(bool is_visible)
  {
    is_visible_ = is_visible;
  }
  // id of current selected skill to release
  void                set_selected_skill_id(int_32 skill_id)
  {
    selected_skill_id_ = skill_id;
  }
  int_32              selected_skill_id()
  {
	  return selected_skill_id_;
  }

  void set_trigger_skill_id( int_32 skill_id )
  {
	  trigger_skill_id_ = skill_id;
  }

  int_32 trigger_skill_id()
  {
	  return trigger_skill_id_;
  }

  //normal skill cool time
  void                set_normal_skill_cool_time(float normal_skill_cool_time)
  {
    normal_skill_cool_time_ = normal_skill_cool_time;
  }
  float               normal_skill_cool_time()
  {
    return normal_skill_cool_time_;
  }
  //skill cool time
  void                set_skill_cool_time(float skill_cool_time)
  {
    skill_cool_time_ = skill_cool_time;
  }
  float               skill_cool_time()
  {
    return skill_cool_time_;
  }
  //skill cool time
  void                set_force_play_skill(bool force_play_skill)
  {
    force_play_skill_ = force_play_skill;
  }
  bool                get_force_play_skill()
  {
    return force_play_skill_;
  }

  int five_elements()
  {
	  return five_elements_;
  }

  bool is_five_elements_restraint(int five_ele);

  // setter getter for ai state
  ai::eAIStateType    ai_orig_state()
  {
    return ai_orig_state_; 
  }
  void                set_ai_orig_state(ai::eAIStateType ai_state)
  {
    ai_orig_state_ = ai_state;
  }

  ai::eAIStateType    ai_state()
  {
    return ai_state_; 
  }
  void                set_ai_state(ai::eAIStateType ai_state)
  {
    ai_state_ = ai_state;
  }
  // setter getter for last ai state
  ai::eAIStateType    last_ai_state()
  {
    return last_ai_state_;
  }
  // setter getter for target object
  ai::TargetSelection<MoveObject>* target_selection()
  {
    return target_selection_;
  }
  void                set_target_selection(ai::TargetSelection<MoveObject>* sel)
  {
    target_selection_->initWithTargetSelec(sel);
  }
  //seter getter for motion state
  ai::eMotionStateType motion_state()
  {
    return motion_state_;
  }
  ai::eMotionStateType last_motion_state()
  {
    return last_motion_state_;
  } 
  void                set_last_motion_state(ai::eMotionStateType last_motion_state)
  {
    last_motion_state_ = last_motion_state;
  }
  ai::eMotionUpdateResult current_animation_state()
  {
    return current_animation_state_;
  }
  void                    set_current_animation_state(ai::eMotionUpdateResult current_animation_state)
  {
    current_animation_state_ = current_animation_state;
  }
  eSkillTripleState       skill_triple_state()
  {
    return skill_triple_state_;
  }
  void                    set_skill_triple_state(eSkillTripleState state)
  {
    skill_triple_state_ = state;
  }

  void set_skill_hit_count(uint_32 skill_hit_count)
  {
    skill_hit_count_ = skill_hit_count;
  }
  uint_32 get_skill_hit_count()
  {
    return skill_hit_count_;
  }

  void add_normal_hit_count();

  // getter setter for triggers
  ai::Trigger*        guard_trigger()
  {
    return guard_trigger_;
  }
  ai::Trigger*        near_attack_trigger()
  {
    return near_attck_trigger_;
  }
  void                set_guard_trigger(ai::Trigger *trigger);

  void                set_near_attack_trigger(ai::Trigger *trigger)
  {
    near_attck_trigger_ = trigger;
  }

  void set_base_circle_guard_radius( float base_circle_guard_radius )
  {
	  base_circle_guard_radius_ = base_circle_guard_radius;
  }

  void set_circle_guard_radius_added(float added);
  void set_circle_guard_radius_multiple(float mul);

  ai::eWeakStateType  weak_state()
  {
    return weak_state_;
  }

  void                set_weak_state(ai::eWeakStateType type)
  {
    weak_state_ = type;
  }
  
  cocos2d::CCPoint    GetCenterPointOnUnitAnimationNode()
  {
    if (!is_active_) {
      return cocos2d::CCPointZero;
    }
    assert(anima_node_);
    cocos2d::CCPoint nodePos = anima_node_->getPosition();
    return ccp(nodePos.x,
               nodePos.y + 0.5f*anima_node_->GetBoundingBox().size.height);
  }
  
  cocos2d::CCPoint    GetCenterPointOnGridNode()
  {
    if (!is_active_) {
      return cocos2d::CCPointZero;
    }
    assert(anima_node_);
    cocos2d::CCPoint nodePos = anima_node_->getPosition();
    return ccp(nodePos.x,
               nodePos.y + 0.5f*battle::kMapTileAverageLength);
  }

  int_32             offset_points_count()
  {
    return offset_points_.size() + 1;
  }
  void               add_offset_point(cocos2d::CCPoint offset_point)
  {
    offset_points_.push_back(offset_point);
  }
  cocos2d::CCPoint   get_pos_by_offset(int_32 offset)
  {
    assert(offset >= 0 && offset < offset_points_.size() + 1);
    return ((offset==0) ? current_pos() : offset_points_[offset-1]+ current_pos());
    //���������λ��Ϊ�ж�
    //return ((offset==0) ? ccp(current_pos().x,current_pos().y+anima_node()->GetBoundingBox().size.height/2) 
    //  : (offset_points_[offset-1]+ccp(current_pos().x,current_pos().y+anima_node()->GetBoundingBox().size.height/2)));
  }

  bool is_Resurgence()
  {
	  return enable_resurgence_;
  }

  void set_enable_resurgence( bool enable )
  {
	  enable_resurgence_ = enable;
  }

  battle::BattleHub* owner_hub()
  {
	  return owner_hub_;
  }
  
  void add_bear_damage(int damage);
  int get_bear_damage()
  {
	  return bear_damage_;
  }

  virtual void        set_critical_hit(bool is_critical)
  { 
	  critical_hit_ = is_critical; 
  }
  virtual bool        is_critical_hit()
  {
	  return critical_hit_;
  }
  
  // calculate coordinate x axis by current tile index pos
  int_8 GetCurrentColumnIndex();
  // calculate coordinate y axis by current tile index pos
  int_8 GetCurrentRowIndex();
  
  // ckeck for bullet through property
  bool CanRangeAttackBulletThroughEmeny()
  {
	if (!is_active_)
	{
		return false;
	}
	eCareerType type = GetCareerType();
    if(type!=kCareerTypeArcher && type!=kCareerTypeWizard)
	{
	  return false;
	}
    return check_battle_status_flag(battle::kDamageRangeAttackMany);
  }
  
  void set_pos_in_last_update(const cocos2d::CCPoint& pos)	
  { 
	  pos_in_last_update_ = pos;
  }

  void addZOrderLock() { ++mZOrderLockCount; }
  void subZOrderLock() { --mZOrderLockCount; }

  battle::eDeadReason get_dead_reason()
  {
	  return dead_reason_;
  }

  int_32  play_skill_id();
  void    set_play_skill_id(int_32 skill_id);

  void PushDamageLabel(int damage_value, battle::eDamageLabelType damege_label_type, bool is_skill_damage);

  void AddShield(const ability::Shield& shield);

  void RemoveShieldByAura(int auta_id);

  bool ShieldWithstandSkill( int_32 master_id, int_32 skill_id);
  void ShieldSubtractDamage( int_32& outDamageVal, battle::eAttackDamageType damageType );

  void ChangeShaderType();
public:
  // check damage to self by suicide skill
  void DamageSelfBySuicideSkill();
  // attach unit's animation node into battle field view 
  void AttachUnitIntoBattleView(battle::BattleView* parent,
                                cocos2d::CCPoint attach_pos,
                                bool isSpecialForVictory = false);
  //Editor-Support
  void AttachUnitIntoNode(cocos2d::CCNode* node);

  // dettach unit's animation node form parent
  void DettachUnitFromBattleView();
  
  // play some new animtion by index
  void ChangeAnimationToIndex(std::string animation_name, 
                              const int cycle_count = -1,
                              const float speed = 1.0f);

  void StopAnimation();

  // set anima_node into invisbility
  void SetAnimationIntoInvisbilityAndMarkByStatus();
  void ResetAnimationOutOfInvisbilityAndMarkByStatus();
  
  // hide health bar
  void HideHealthBar();

  void setShowInfoOnSandBox(bool show, int x, int y);

  CCPoint getEffectPosition(int effect_pos_type);


  void ShowAuraEffectByArmature( const std::string & effectName, int effectPos, bool replace = false);
  void RemoveAuraEffectByArmature( const std::string & effectName);
  void RemoveAuraEffectByArmature( int tag);



  void ShowStatusEffectOnWithName(const std::string& effectName, int effectPos ,bool needFlipX = false);
  void ReplaceOneStatusEffectNewOneWithName(const std::string& effectName, int effectPos);
  void RemoveStatusEffectWithName(const std::string &effectName);
  

  // reset unit data for dead state
  void GoDeadStation( battle::eDeadReason dr);
  // remove only, no necessary to play dead animation
  void BeDestroyed();

protected:
  // fresh z order & scale for unit
  virtual void freshZOrder();
  // init the animation of unit by unit id & weapons ids
  virtual void addUnitAniamtion();
  // init the animation special for winning characters
  virtual void addWinningAnimation() {}
  // init skill ids
  virtual void initSkillIds();
  
protected:
  // init health bar percent
  void initHealthBarPercent();
  
  void updateMoveSpeed();

  void updateAttackSpeedBoostMultiple();
  void popDamageLabel();

  void updateShield(float delta);
protected:

	uint_32 move_object_id_;

	uint_32 card_id_;

	int level_;

	army::kMoveObjectType move_object_type_;

	bool is_active_;

	bool is_temp_dead_;
	int_32              selected_skill_id_;

	int_32 trigger_skill_id_;

	// originality ai state
	ai::eAIStateType    ai_orig_state_;
	// ai state
	ai::eAIStateType    ai_state_;
	// last ai state
	ai::eAIStateType    last_ai_state_;
	// motion state
	ai::eMotionStateType motion_state_;
	// last motion state
	ai::eMotionStateType last_motion_state_;

	CharacterData* character_card_data_;
protected:
  
  // ��͸�˺�ϵ��
  float              run_through_damage_multiple_;
  
  // favorite gender type
  uint_8              favorite_gender_target_;
  
  // ����״̬
  battle::eDamageStatus elements_attack_status_[kAEPPMax];
  uint_32             attack_status_;
 
  // ����״̬
  std::map<battle::eImmuneType, uint_32>             immune_status_flag_map_;
  uint_32             immune_status_flag_;

  // ս��״̬
  std::map<battle::eDamageStatus, uint_32>             battle_status_flag_map_;
  uint_32             battle_status_flag_;

  // Ŀ��ĳ��״̬�µ�Ŀ������˺��ӳ�-flag
  uint_32             favorite_target_status_;

  // Ŀ��ĳ��״̬�µ�Ŀ������˺��ӳ�-ϵ��
  float               status_damage_boost_multiple_;
  
  // ��ʿ����Զ�̹����˺�ϵ��
  float               shield_damage_boost_multiple_;

  // ��Χ�����˺�ϵ����Ĭ��=0.5f
  float               range_attacker_melee_damage_boost_multiple_;

  // ���˾���ӳ�
  float               repeal_distance_multiple_;

  // �ܵ������˺�ʱ�ļ���ϵ����Ĭ��=0.5
  std::map<battle::eDamageStatus, float> elements_damage_weaken_multiple_;

  // �����˺��ӳ�
  std::map<battle::eDamageStatus, float> elements_damage_added_multiple_;

  // buff�ļ���ʱ��ӳ�
  std::map<battle::eDamageStatus, float> status_exist_time_mutiple_;

  std::list<ability::Shield> _shidle_list;
  
protected:
	//-------------------------��ɫ���Զ���------------------------------begin
	
	// ��������
	float				basic_critical_; // ͨ����ʽ����ɱ�������
	float				critical_added_;
	float				critical_multiple_;
	float				critical_;
	
	// �����˺�
	float				basic_critical_damage_;
	float				critical_damage_added_;
	float				critical_damage_multiple_;
	float				critical_damage_;

	// ��������
	uint_32				basic_physics_attack_;
	int					physics_attack_added_;
	float				physics_attack_multiple_;
	int					physics_attack_;

	// ��������
	uint_32				basic_magic_attack_;
	int					magic_attack_added_;
	float				magic_attack_multiple_;
	int					magic_attack_;

	// ��������
	int_32				basic_physics_defense_;
	int					physics_defense_added_;
	float				defense_physics_multiple_;

	// ��������
	int_32				basic_magic_defense_;
	int				magic_defense_added_;
	float				defense_magic_multiple_;

	// �ƶ��ٶ�
	cocos2d::CCPoint	move_speed_;
	float				move_speed_value_;
	float				move_speed_added_multiple_;
	float				move_speed_lowered_multiple_;
	float				move_speed_boost_multiple_;

	// �����ٶ�//////////////////////////////////////////////////////////
	float				attack_speed_;
	float				attack_speed_added_multiple_;
	float				attack_speed_lowered_multiple_;
	float				attack_speed_boost_multiple_;

	// ����ֵ//////////////////////////////////////////////////////////
	int					base_total_health_point_;
	int					health_upperlimit_added;
	float				health_upperlimit_multiple;

	int					total_health_point_;
	int					currnet_health_point_;

	// նɱ////////////////////////////////////////////////////////////
	float				slay_condition_rate_;
	float				slay_damage_multiple_;

	// ����ֵ/////////////////////////////////////////////////////////
	float				basic_dodge_;
	float				dodge_added_;
	float				dodge_multiple_;
	float				dodge_;

	// ����ֵ////////////////////////////////////////////////////////
	float				basic_hit_rate_;
	float				hit_rate_added_;
	float				hit_rate_multiple_;
	float				hit_rate_;

	// ����/ŭ��/////////////////////////////////////////////////////
	uint_32				energy_value_;

	// ���䷶Χ/��ʦ�����Ʒ�Χ//////////////////////////////////////
	float				base_circle_guard_radius_;
	float				circle_guard_radius_added_;
	float				circle_guard_radius_multiple_;

	// ���Ƽӳ�
	float				heal_boost_multiple_;
	// �����Ƽӳ�
	float				by_heal_boost_multiple_;

	// �˺��ӳɣ�>1�˺����ӣ�<1�˺�����
	float				damage_boost_multiple_;
	// ���˺��ӳ�/������>1�ܵ����˺�����,<1����
	float				by_damage_boost_multiple_;

	// ������Ѫ
	float				physics_blood_boost_multiple_;
	// ������Ѫ
	float				magic_blood_boost_multiple_;

	// ��������
	float				physics_thorns_boost_multiple_;
	// ��������
	float				magic_thorns_boost_multiple_;

	// �����˺��ӳ�
	float				skill_damage_boost_multiple_;

	//��������
	int_32				final_defense_;

	//�����˺�
	int_32				final_damage_;

	//-------------------------��ɫ���Զ���------------------------------end
protected: // temporary data

  // current tile index of this move object
  int_8              tile_index_;
  //
  int_8               auto_search_tile_index_;
  // pos in last update
  cocos2d::CCPoint    pos_in_last_update_;
  
  // animation added on battle field layer of this move object
  SkeletonAnimation*  anima_node_;
  effect::SkeletonAnimationManager  *anima_manager_;
  
  // weak state flag for animation
  ai::eWeakStateType  weak_state_;

  // guard trigger : range & heal trigger
  ai::Trigger         *guard_trigger_;
  // near attack trigger
  ai::Trigger         *near_attck_trigger_;
  // selected target move_object info : id & position 
  ai::TargetSelection<MoveObject>* target_selection_;

  // charge dist 
  int_32              charge_dist_;
  // skill beatback
  int_32              be_skill_hitmove_offset_;		
  int_32              be_skill_resetmove_offset_;
  //body offset point, use for boss
  std::vector<cocos2d::CCPoint>  offset_points_;

  //Critical
  bool                critical_hit_;
  
protected:  // data for ai
  friend class ai::AIStateMachine;
  friend class ai::MotionStateMachine;

  // idle time count for idle motion motion
  float               idle_time_;
  // stage time for ai control
  float               stage_time_;    
  // stage type
  eStageState         stage_state_;
  // stay column
  int                 state_stay_column_;  
  // is visible 
  bool                is_visible_;
  
  // motion animation state, used in animation call back
  ai::eMotionUpdateResult current_animation_state_;
  // only use for three part skill
  eSkillTripleState   skill_triple_state_;

  uint_32             skill_hit_count_;

  uint_32 normal_hit_count_;
  
  int bear_damage_;

  int five_elements_;

  bool enable_resurgence_;

  std::vector<int>    passive_skill_ids_;
  float               normal_skill_cool_time_;
  float               skill_cool_time_;

protected:
  battle::BattleHub*  owner_hub_;
  UILoadingBar*       health_point_;
  UILoadingBar*       health_point_bg_;

  float pop_damage_label_time_;
  std::queue<DamageLabelParam> damage_label_queue_;
  // boss play skill
  int_32              play_skill_id_;
  int_32              mZOrderLockCount;
  //now used in ai intention default
  bool                force_play_skill_;

  battle::eDeadReason dead_reason_;

  // debug info
  cocos2d::CCLabelTTF *sandbox_unit_info_label_;

  private:
    actor::Actor*     actor_;
};
  
} // namespace army
} // namespace taomee

#endif // ChainChronicle_move_object_h