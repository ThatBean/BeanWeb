﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  move_object.cc
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:03
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/move_object.h"
#include "game/army/unit/summon.h"
#include <stdlib.h>
#include "engine/animation/skeleton_animation.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/animation/projectile_animation.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/army/unit/character.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/battle_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/view/aim_mark.h"
#include "game/effect/touch_area_layer.h"
#include "game/effect/touch_area_node_factory.h"
#include "game/game_manager/data_manager.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/view/battle_damage_label.h"
#include "game/passive_ability/auramanager.h"
#include "game/data_table/character_data_table.h"
#include "game/passive_ability/passive_ability_constants.h"
#include "engine/base/utils_string.h"

#include "cocos-ext.h"

// the furture of MoveObject (maybe)
#include "game/actor/actor.h"

USING_NS_CC_EXT;

namespace taomee {
namespace army {
  
MoveObject::MoveObject(battle::BattleHub* owner,
                       uint_32 global_id)
  : move_object_id_(global_id),
    anima_node_(NULL),
    anima_manager_(NULL),
    target_selection_(NULL),
    guard_trigger_(NULL),
    near_attck_trigger_(NULL),
    owner_hub_(owner),
    health_point_(NULL),
    health_point_bg_(NULL),
    play_skill_id_(0),
	move_object_type_(army::kMoveObjectType_Unknown),
    force_play_skill_(false)
{
  this->ClearAllProperties();
  actor_ = new actor::Actor;
  actor_->GetActorData()->SetActorAdapter(this);
}
  
MoveObject::~MoveObject()
{
  if (anima_node_)
  {
    anima_node_->removeFromParentAndCleanup(true);
    CC_SAFE_RELEASE(anima_node_);
    CC_SAFE_RELEASE_NULL(health_point_);
    CC_SAFE_RELEASE_NULL(health_point_bg_);
  }
  SAFE_DEL(target_selection_);
  SAFE_DEL(guard_trigger_);
  SAFE_DEL(near_attck_trigger_);
}

void MoveObject::ClearAllProperties()
{
	sandbox_unit_info_label_ = NULL;
  is_active_                              = false;
  is_temp_dead_ = false;
  card_id_                                = 0;
  character_card_data_ = NULL;

  run_through_damage_multiple_            = battle::kThroughDamageMultiple;
  favorite_gender_target_                 = kGenderNone;
  
  attack_status_                          = 0;
  memset(elements_attack_status_, 0, kAEPPMax*sizeof(uint_32));

  immune_status_flag_map_.clear();
  immune_status_flag_                     = 0;
  battle_status_flag_map_.clear();
  battle_status_flag_					  = 0;
  favorite_target_status_                 = 0;
  
  basic_critical_damage_ = 0;
  critical_damage_added_ = 0;
  critical_damage_multiple_ = 1.0f;
  critical_damage_ = 0.0f;

  shield_damage_boost_multiple_           = battle::kShieldRangeDamageMuiltiple;
  range_attacker_melee_damage_boost_multiple_= battle::kRangeAttackerMeleeDamageMultiple;
  //elements_damage_reinforce_multiple_     = battle::kElementsReinforceDamageMultiple;
  //elements_damage_weaken_multiple_        = battle::kElementsWeakenDamageMultiple;
  elements_damage_added_multiple_.clear();
  status_damage_boost_multiple_           = 1.0f;
  skill_damage_boost_multiple_            = 1.0f;
  
  base_total_health_point_                = 0;
  health_upperlimit_multiple              = 1.0f;
  health_upperlimit_added                 = 0.0;
  total_health_point_                     = 0;
  currnet_health_point_                   = 0;
  
  five_elements_ = 0;

  basic_critical_ = 0;
  critical_added_ = 0;
  critical_multiple_ = 1.0f;
  critical_ = 0.0f;

  normal_hit_count_ = 0;

  attack_speed_                           = 0.0f;

  basic_physics_attack_ = 0;
  physics_attack_added_ = 0;
  physics_attack_multiple_ = 1.0f;
  physics_attack_ = 0;

  basic_magic_attack_ = 0;
  magic_attack_added_ = 0;
  magic_attack_multiple_ = 1.0f;
  magic_attack_ = 0;

  basic_physics_defense_                  = 0;
  physics_defense_added_				  = 0;
  defense_physics_multiple_				  = 1.0f;

  basic_magic_defense_                    = 0;
  magic_defense_added_					  = 0;
  defense_magic_multiple_				  = 1.0f;

  move_speed_value_                         = 0.0f;
  final_defense_                          = 0;
  final_damage_                           = 0;  

  critical_hit_                           = false;
  
  damage_boost_multiple_                  = 1.0f;
  heal_boost_multiple_                    = 1.0f;
  by_heal_boost_multiple_				  = 1.0f;
  attack_speed_boost_multiple_            = 1.0f;
  
  move_speed_boost_multiple_              = 1.0f;
  by_damage_boost_multiple_		          = 1.0f;
  physics_blood_boost_multiple_	  = 0.0f;
  magic_blood_boost_multiple_	  = 0.0f;
  physics_thorns_boost_multiple_		  = 0.0f;
  magic_thorns_boost_multiple_			  = 0.0f;

  move_speed_added_multiple_              = 0.0f;
  move_speed_lowered_multiple_			  = 0.0f;
  attack_speed_added_multiple_			  = 0.0f;
  attack_speed_lowered_multiple_		  = 0.0f;

  basic_dodge_ = 0;
  dodge_added_ = 0;
  dodge_multiple_ = 1.0f;
  dodge_ = 0;

  basic_hit_rate_ = 0;
  hit_rate_added_ = 0;
  hit_rate_multiple_ = 1.0f;
  hit_rate_ = 0;

  energy_value_ = 0.0f;
  
  level_ = 0;

  enable_resurgence_ = false;

  play_skill_id_                          = kSkillInvaild;
  force_play_skill_                       = false;

  if (anima_node_)
  {
    anima_node_->ClearAnimation();
  }
  CC_SAFE_RELEASE_NULL(anima_node_);
  SAFE_DEL(anima_manager_);
  CC_SAFE_RELEASE_NULL(health_point_);
  CC_SAFE_RELEASE_NULL(health_point_bg_);
  
  repeal_distance_multiple_               = 1.0f;
  status_exist_time_mutiple_.clear();

  tile_index_                             = battle::kUnexistTileIndex;
  auto_search_tile_index_                 = battle::kUnexistTileIndex;
  pos_in_last_update_                     = battle::kUnexistCoordinatePoint;
  mZOrderLockCount                        = 0;  

  charge_dist_                            = 0;
  be_skill_hitmove_offset_                = 0;
  be_skill_resetmove_offset_              = 0;
  
  idle_time_                              = 0.0f;
  stage_time_                             = 0.0f;
  stage_state_                            = kStageBorn;
  state_stay_column_                      = -1;  
  is_visible_                             = true;
  
  selected_skill_id_                      = MW_INVALID_ID;
  trigger_skill_id_							= MW_INVALID_ID;
  normal_skill_cool_time_                 = 0.0f;
  skill_cool_time_                        = 0.0f;
  offset_points_.clear();
  passive_skill_ids_.clear();
  
  SAFE_DEL(guard_trigger_);
  SAFE_DEL(near_attck_trigger_);
  SAFE_DEL(target_selection_);

  ai_state_                               = ai::kAIStateInvalid;
  last_ai_state_                          = ai::kAIStateInvalid;
  motion_state_                           = ai::kMotionStateInvalid;
  last_motion_state_                      = ai::kMotionStateInvalid;
  current_animation_state_                = ai::kMotionResultInvalid;
  weak_state_                             = ai::kWeakStateStrong;

  bear_damage_ = 0;

  pop_damage_label_time_ = 0.0f;

  dead_reason_ = battle::kDeadReason_Normal;

  base_circle_guard_radius_ = 0.0f;
  circle_guard_radius_added_ = 0.0f;
  circle_guard_radius_multiple_ = 1.0f;

  slay_condition_rate_ = 0.0f;

  slay_damage_multiple_ = battle::kSlayDamageMultiple;

  _shidle_list.clear();
}

float MoveObject::physics_blood_boost_multiple()
{
	if ( physics_blood_boost_multiple_ < 0.0f ) // 下限
	{
		return 0.0f;
	}
// 	if ( physics_hematophagia_boost_multiple_ > 2.0f ) //上限
// 	{
// 		return 2.0f;
// 	}

	return physics_blood_boost_multiple_;
}

void MoveObject::set_physics_blood_boost_multiple(float multiple)
{
	physics_blood_boost_multiple_ += multiple;
}
void MoveObject::reset_physics_blood_boost_multiple(float multiple)
{
	physics_blood_boost_multiple_ -= multiple;	
}

float MoveObject::magic_blood_boost_multiple()
{
	if ( magic_blood_boost_multiple_ < 0.0f )
	{
		return 0.0f;
	}

	return magic_blood_boost_multiple_;
}

void MoveObject::set_magic_blood_boost_multiple(float multiple)
{
	magic_blood_boost_multiple_ += multiple;
}

void MoveObject::reset_magic_blood_boost_multiple(float multiple)
{
	magic_blood_boost_multiple_ -= multiple;
}

float MoveObject::physics_thorns_boost_multiple()
{
	if ( physics_thorns_boost_multiple_ < 0.0f )
	{
		return 0.0f;
	}

	return physics_thorns_boost_multiple_;
}
void MoveObject::set_physics_thorns_boost_multiple(float multiple)
{
	physics_thorns_boost_multiple_ += multiple;
}
void MoveObject::reset_physics_thorns_boost_multiple(float multiple)
{
	physics_thorns_boost_multiple_ -= multiple;
}

int_32 MoveObject::physics_defense() 
{
	int total_def = basic_physics_defense_ + physics_defense_added_;

	if ( total_def < 0.0f)
	{
		return total_def;
	}

	return total_def * defense_physics_mult();
}
void MoveObject::set_basic_physics_defense(int_32 pyhsics_defense)
{
	basic_physics_defense_ = pyhsics_defense;
}

void MoveObject::set_physics_defense_added( int_32 added)
{
	physics_defense_added_ += added;

	if ( added > 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_AddPhysicsDefense, false);
	}
	else if ( added < 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_SubPhysicsDefense, false);
	}
}

void MoveObject::reset_physics_defense_added( int_32 added)
{
	physics_defense_added_ -= added;
}

void MoveObject::set_defense_physics_added_mult(float added)
{
	defense_physics_multiple_ += added;

	if ( added > 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_AddPhysicsDefense, false);
	}
	else if ( added < 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_SubPhysicsDefense, false);
	}
}
void MoveObject::reset_defense_physics_added_mult(float added)
{
	defense_physics_multiple_ -= added;
}

void MoveObject::set_defense_magic_added_mult(float added)
{
	defense_magic_multiple_ += added;
	if ( added > 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_AddMagicDefense, false);
	}
	else if ( added < 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_SubMagicDefense, false);
	}
}
void MoveObject::reset_defense_magic_added_mult(float added)
{
	defense_magic_multiple_ -= added;
}

int_32 MoveObject::magic_defense()
{
	int total_def = basic_magic_defense_ + magic_defense_added_;
	if ( total_def < 0)
	{
		return total_def;
	}

	return total_def * defense_magic_mult();
}
void MoveObject::set_basic_magic_defense( int_32 basic_magic_defense )
{
	basic_magic_defense_ = basic_magic_defense;
}

void MoveObject::set_magic_defense_added(int_32 added)
{
	magic_defense_added_ -= added;
	if ( added > 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_AddMagicDefense, false);
	}
	else if ( added < 0)
	{
		PushDamageLabel(0, battle::eDamageLabelType_SubMagicDefense, false);
	}
}

void MoveObject::reset_magic_defense_added(int_32 added)
{
	magic_defense_added_ -= added;
}

float MoveObject::magic_thorns_boost_multiple()
{
	if ( magic_thorns_boost_multiple_ < 0.0f )
	{
		return 0.0f;
	}

	return magic_thorns_boost_multiple_;
}
void MoveObject::set_magic_thorns_boost_multiple(float multiple)
{
	magic_thorns_boost_multiple_ += multiple;
}

void MoveObject::reset_magic_thorns_boost_multiple(float multiple)
{
	magic_thorns_boost_multiple_ -= multiple;
}


bool MoveObject::check_immune_status_flag(battle::eImmuneType flag)
{
	return (bool)( immune_status_flag_ & flag );
}

void MoveObject::retain_immune_status_flag(uint_32 flag)
{
	if ( flag == 0) return;

	for(int i = 0; i < battle::kImmuneTypeMax, flag != 0; ++i)
	{
		if (flag&0x0001)
		{
			this->retain_immune_status_flag(static_cast<battle::eImmuneType>(1<<i));
		}
		flag = flag>>1;
	}
}

void MoveObject::retain_immune_status_flag(battle::eImmuneType flag)
{
	std::map<battle::eImmuneType, uint_32>::iterator iter = immune_status_flag_map_.find(flag);
	if ( iter != immune_status_flag_map_.end())
	{
		iter->second++;
	}
	else
	{
		immune_status_flag_map_[flag] = 1;
	}

	immune_status_flag_ = immune_status_flag_ | flag;
	if ( flag == battle::kImmuneTypeLowerAttackSpeed )
	{
		updateAttackSpeedBoostMultiple();
	}

	if ( flag == battle::kImmuneTypeLowerMoveSpeed)
	{
		updateMoveSpeed();
	}
}

void MoveObject::release_immune_status_flag(uint_32 flag)
{
	if ( flag == 0) return;

	for(int i = 0; i < battle::kImmuneTypeMax, flag != 0; ++i)
	{
		if (flag&0x0001)
		{
			this->release_immune_status_flag(static_cast<battle::eImmuneType>(1<<i));
		}
		flag = flag>>1;
	}
}

void MoveObject::release_immune_status_flag(battle::eImmuneType flag)
{
	std::map<battle::eImmuneType, uint_32>::iterator iter = immune_status_flag_map_.find(flag);
	if ( iter != immune_status_flag_map_.end())
	{
		iter->second--;
		if (iter->second <= 0)
		{
			iter->second = 0;
			immune_status_flag_ = immune_status_flag_ & (~flag);
			if ( flag & battle::kImmuneTypeLowerAttackSpeed )
			{
				updateAttackSpeedBoostMultiple();
			}

			if ( flag & battle::kImmuneTypeLowerMoveSpeed)
			{
				updateMoveSpeed();
			}
		}
	}
}

bool MoveObject::check_battle_status_flag(battle::eDamageStatus flag)
{
	return (bool)( battle_status_flag_ & flag );
}

void MoveObject::retain_battle_status_flag(uint_32 flag)
{
	if ( flag == 0) return;

	for(int i = 0; i < battle::kDamageMax, flag != 0; ++i)
	{
		if (flag&0x0001)
		{
			this->retain_battle_status_flag(static_cast<battle::eDamageStatus>(1<<i));
		}
		flag = flag>>1;
	}
}

void MoveObject::retain_battle_status_flag(battle::eDamageStatus flag)
{
	std::map<battle::eDamageStatus, uint_32>::iterator iter = battle_status_flag_map_.find(flag);
	if ( iter != battle_status_flag_map_.end())
	{
		iter->second++;
	}
	else
	{
		battle_status_flag_map_[flag] = 1;
	}

	battle_status_flag_ = battle_status_flag_ | flag;

	PushDamageLabel(0, battle::DamageLabel::toDamageLabelType(flag), false);

	if ( battle::kDamageLoweMoveSpeed == flag || battle::kDamagePetrifaction == flag)
	{
		ChangeShaderType();
	}
}

void MoveObject::release_battle_status_flag(uint_32 flag)
{
	if ( flag == 0) return;

	for(int i = 0; i < battle::kDamageMax, flag != 0; ++i)
	{
		if (flag&0x0001)
		{
			this->release_battle_status_flag(static_cast<battle::eDamageStatus>(1<<i));
		}
		flag = flag>>1;
	}
}

void MoveObject::release_battle_status_flag(battle::eDamageStatus flag)
{
	std::map<battle::eDamageStatus, uint_32>::iterator iter = battle_status_flag_map_.find(flag);
	if ( iter != battle_status_flag_map_.end())
	{
		iter->second--;
		if (iter->second <= 0)
		{
			iter->second = 0;
			battle_status_flag_ = battle_status_flag_ & (~flag);

			if ( battle::kDamageLoweMoveSpeed == flag || battle::kDamagePetrifaction == flag)
			{
				ChangeShaderType();
			}
		}
	}
}

void MoveObject::ChangeShaderType()
{
	if ( !anima_node_ || !anima_node_->GetBodyNode())
		return;

	if ( check_battle_status_flag(battle::kDamagePetrifaction) )
	{
		shader::SetAllNodeWithShaderType(anima_node_->GetBodyNode(), shader::kShaderGray);
		return ;
	}

	if ( check_battle_status_flag(battle::kDamageLoweMoveSpeed) )
	{
		shader::SetAllNodeWithShaderType(anima_node_->GetBodyNode(), shader::kShaderFrozen);
		return ;
	}

	shader::SetAllNodeWithShaderType(anima_node_->GetBodyNode(), shader::kShaderDefault);
}

void MoveObject::set_attack_speed_boost_multiple(float multiple)
{
	if ( multiple > 0.0f)
	{
		attack_speed_added_multiple_ += multiple;
	}
	else if ( multiple < 0.0f)
	{
		attack_speed_lowered_multiple_ += multiple;
	}
	else
	{
		return;
	}

	updateAttackSpeedBoostMultiple();
}

void MoveObject::reset_attack_speed_boost_multiple(float multiple)
{
	if ( multiple > 0.0f)
	{
		attack_speed_added_multiple_ -= multiple;
	}
	else if ( multiple < 0.0f)
	{
		attack_speed_lowered_multiple_ -= multiple;
	}
	else
	{
		return;
	}

	updateAttackSpeedBoostMultiple();
}

void MoveObject::updateAttackSpeedBoostMultiple()
{
	float curr_attack_speed_added = 0.0;

	if ( this->check_battle_status_flag(battle::kDamageStatusImmune) &&
		 this->check_immune_status_flag(battle::kImmuneTypeLowerAttackSpeed))
	{
		curr_attack_speed_added = attack_speed_added_multiple_;
	}
	else
	{
		curr_attack_speed_added = attack_speed_added_multiple_ + attack_speed_lowered_multiple_;
	}

	if ( curr_attack_speed_added > 0.0f) //
	{
		if ( curr_attack_speed_added > battle::ATTACK_SPEED_MULTIPLE_MAX)  
		{
			attack_speed_boost_multiple_ = 1 / (1 + battle::ATTACK_SPEED_MULTIPLE_MAX);
		}
		else
		{
			attack_speed_boost_multiple_ = 1 / (1 + curr_attack_speed_added);
		}
	}
	else if ( curr_attack_speed_added < 0.0f)
	{
		attack_speed_boost_multiple_ = 1 + abs(curr_attack_speed_added);
	}
	else
	{
		attack_speed_boost_multiple_ = 1;
	}
}

void MoveObject::set_move_speed_boost_multiple(float multiple)
{
	if ( multiple > 0.0f)
	{
		move_speed_added_multiple_ += multiple;
	}
	else if ( multiple < 0.0f)
	{
		move_speed_lowered_multiple_ += multiple;
	}
	else
	{
		return;
	}
	   
	this->updateMoveSpeed();
}

void MoveObject::reset_move_speed_boost_multiple(float multiple)
{
	if ( multiple > 0.0f)
	{
		move_speed_added_multiple_ -= multiple;
	}
	else if ( multiple < 0.0f)
	{
		move_speed_lowered_multiple_ -= multiple;
	}
	else
	{
		return;
	}

	this->updateMoveSpeed();
}

void MoveObject::set_move_speed(const cocos2d::CCPoint& speed)
{
	move_speed_.x = speed.x;
	move_speed_.y = speed.y;
	this->updateMoveSpeed();
}

void MoveObject::set_base_total_health_point(int hp)
{
	base_total_health_point_ = hp;
	total_health_point_ = (int)(base_total_health_point_ * health_upperlimit_multiple );
}

void MoveObject::set_health_upperlimit_added(int added)
{
	health_upperlimit_added += added;
	total_health_point_ = (int)(base_total_health_point_ * health_upperlimit_multiple );
	total_health_point_ += health_upperlimit_added;
	if ( added > 0)
	{
		set_currnet_health_point(currnet_health_point_ + added);
	}
	else if ( currnet_health_point_ > total_health_point_)
	{
		set_currnet_health_point(total_health_point_);
	}
}

void MoveObject::set_health_upperlimit_multiple(float mul)
{
	health_upperlimit_multiple += mul;
	int added = (int)(base_total_health_point_ * ( health_upperlimit_multiple - 1.0f ));
	total_health_point_ = base_total_health_point_ + added;
	total_health_point_ += health_upperlimit_added;
	if ( mul > 0.0f && added > 0)
	{
		set_currnet_health_point(currnet_health_point_ + added);
	}
	else if ( currnet_health_point_ > total_health_point_)
	{
		set_currnet_health_point(total_health_point_);
	}
}

float MoveObject::heal_boost_multiple()
{
	if ( heal_boost_multiple_ < 0.0f) // 下限
	{
		return 0.0f;
	}

	return heal_boost_multiple_;
}

void MoveObject::set_heal_boost_multiple(float mul)
{
	heal_boost_multiple_ += mul;	
}

void MoveObject::reset_heal_boost_multiple(float mul)
{
	heal_boost_multiple_ -= mul;
}

float MoveObject::by_heal_boost_multiple()
{
	if ( by_heal_boost_multiple_< 0.0f) // 下限
	{
		return 0.0f;
	}

	return by_heal_boost_multiple_;
}

void MoveObject::set_by_heal_boost_multiple(float mul)
{
	by_heal_boost_multiple_ += mul;
}

void MoveObject::reset_by_heal_boost_multiple(float mul)
{
	by_heal_boost_multiple_ -= mul;
}

float MoveObject::by_damage_boost_multiple()
{
	if ( by_damage_boost_multiple_ < 0.0f )
	{
		return 0.0f;
	}

	return by_damage_boost_multiple_;
}
void MoveObject::set_by_damage_boost_multiple(float multiple)
{
	by_damage_boost_multiple_ += multiple;
}
void MoveObject::reset_by_damage_boost_multiple(float multiple)
{
	by_damage_boost_multiple_ -= multiple;
}

float MoveObject::damage_boost_multiple()
{
	if (damage_boost_multiple_ < 0.0f)
	{
		return 0.0f;
	}

	return damage_boost_multiple_;
}

void MoveObject::set_damage_boost_multiple(float multiple)
{
	damage_boost_multiple_ += multiple;
}

void MoveObject::reset_damage_boost_multiple(float multiple)
{
	damage_boost_multiple_ -= multiple;
}

void MoveObject::set_currnet_health_point( int hp )
{
  // update health bar firstly
  if ( hp > total_health_point_)
  {
    hp = total_health_point_;
  }
  if (this->owner_hub()->IsCharacterHub())
  {
    int curr_rate = hp * 100 / total_health_point_;
    
    if (curr_rate > WEAK_RATE && weak_state_ == ai::kWeakStateWeak)
    {
      set_weak_state(ai::kWeakStateChangeStrong);
    }
    else if (curr_rate <= WEAK_RATE && weak_state_ == ai::kWeakStateStrong)
    {
      set_weak_state(ai::kWeakStateChangeWeak);
    }
  }
  // set hp then
  currnet_health_point_ = hp;
}
  
void MoveObject::set_current_pos(cocos2d::CCPoint pos)
{
  assert(anima_node());
  if (pos.x == anima_node()->getPosition().x &&
      pos.y == anima_node()->getPosition().y)
  {
    return;
  }

  //check y(row)
  if (pos.y < battle::GetMinYInTile() || pos.y > battle::GetMaxYInTile())
    return;

  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
    
    }
    break;
  case battle::kBattleType_Pvp:
  case battle::kBattleType_SandBox:
    {
      //check x(column)
      CCPoint tile_pos = battle::GetTileCoordinatePosByCurrentPointPosition(pos);
      if (owner_hub()->IsRightSideHub()) 
      {
        // can not repeal out of battle grids(left direction)
        if (battle::grid_position_x_y(tile_pos.y, 0).x>pos.x)
        {
          pos.x = battle::grid_position_x_y(tile_pos.y, 0).x;
        }
      }
      else
      {
        // can not repeal out of battle grids(right direction)
        if (battle::grid_position_x_y(tile_pos.y, battle::kMapColumnCount).x<pos.x)
        {
          pos.x = battle::grid_position_x_y(tile_pos.y, battle::kMapColumnCount).x;
        }
      }
    }
  default:
    break;
  }
  anima_node()->setPosition(pos);
  int_8 temp_tile_index = battle::GetTileIndexByCurrentPointPosition(pos);
  assert(temp_tile_index != -1);
//  if (originalTileIdx != tile_index_) {
//    this->owner_hub()->updateAttackerReference(originalTileIdx, this);
//  }    
}

float MoveObject::mover_speed_value()
{
  // NOTE : this condition can make sure that all BUFF boost velocity only
  // acting after characters moved into the battle grids in first born
/*
	if (owner_hub_->IsCharacterHub() && anima_node_ &&
		false == battle::BattleController::GetInstance().is_round_start())
	{
		return move_speed_value_; 
	} // NOTE END*/
	return move_speed_value_*move_speed_boost_multiple_;
}
  
bool MoveObject::InitMoveObjectDataFromFile(bool needInitBattleData /* = true */)
{
  // mark it as active
  this->set_is_active(true);
  // mollac
  target_selection_ = new ai::TargetSelection<MoveObject>(this, kUnexistTargetId);
  // init
  character_card_data_ = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter( card_id_ );
  if (!character_card_data_)
  {
    assert(character_card_data_);
    return false;
  }
  // set veloacity
  this->set_move_speed_value(character_card_data_->GetMovSpeed()*battle::kMapTileAverageLength);
  if (needInitBattleData==false)
  {
    return true;
  }

  // static data read form character.csv file
  this->set_attack_speed(character_card_data_->GetAtkSpeed());
  this->set_defense_magic_mult(character_card_data_->GetDefMagicRate());
  this->set_defense_physics_mult(character_card_data_->GetDefPhysicsRate());
  this->set_basic_physics_defense(character_card_data_->GetPhysicsDef());
  this->set_basic_magic_defense(character_card_data_->GetMagicDef());
  this->set_basic_critical(character_card_data_->GetCritical());
  this->set_basic_critical_damage(character_card_data_->GetCriticalDamage());

  // 火克冰， 冰克风，风克火
 if ( character_card_data_->GetWeakFlag() == 1 ) // 弱点是火, 自己是冰
  {
	  five_elements_ = battle::kDamageIceProperty;
	  this->SetElementsDamageWeakenMultiple( battle::kDamageIceProperty, battle::kElementsWeakenDamageMultiple );
  }
  else if ( character_card_data_->GetWeakFlag() == 2 )// 弱点是冰, 自己是风
  {
	  five_elements_ = battle::kDamageWindProperty;
	  this->SetElementsDamageWeakenMultiple( battle::kDamageWindProperty, battle::kElementsWeakenDamageMultiple );
  }
  else if ( character_card_data_->GetWeakFlag() == 3)// 弱点是风, 自己是火
  {
	  five_elements_ = battle::kDamageFireProperty;
	  this->SetElementsDamageWeakenMultiple( battle::kDamageFireProperty, battle::kElementsWeakenDamageMultiple );
  }

  this->initSkillIds();
  return true;
}
  
void MoveObject::DamageSelfBySuicideSkill()
{
	int selected_skill_id_ = selected_skill_id() > 0 ? selected_skill_id() : character_card_data_->GetSkillId(kSkillSkill);
  SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(selected_skill_id_);
  if (skillData->GetDamageSelfPercent()==0)
  {
    return;
  }
  this->owner_hub()->HitOneUnitInThisHub(this, this, selected_skill_id_, -1, false);
}

void MoveObject::AttachUnitIntoNode(cocos2d::CCNode* node)
{
  if (!anima_node_)
  {
    anima_node_       = new SkeletonAnimation();
    anima_manager_    = new effect::SkeletonAnimationManager(this);
    anima_node_->set_tag(move_object_id_);
    node->addChild(anima_node_);

    /////////////////////////////////////
    std::string cardName = GetMoveObjectNameByCardId(card_id_);
    float armature_scale = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id_)->GetSkeletonScale();
    anima_node_->Init(cardName.c_str(), cardName.c_str());
    CCString *str_card_id = CCString::create(Int2String(card_id_));
    anima_node_->GetArmatureNode()->setUserObject(str_card_id);
    anima_node_->GetArmatureNode()->setTag(card_id_);
    anima_node_->SetAnimationScale(armature_scale);
    //anima_node_->AddShadow();
    //battle::AimMark* aim_mark = battle::AimMark::Create(battle::kAimMarkFriend);
    //aim_mark->setPosition(ccp(0, battle::kSelectedBorderOffsetHight));
    //anima_node_->addChild(aim_mark, 10, kAimMarkTag);
    UILayer* ui_layer = UILayer::create();
    ui_layer->setPosition(anima_node_->GetBonePositionInSkeleton(kBoneTypeHealthBar));
    anima_node_->addChild(ui_layer, kHitPointBarFlag, kHitPointBarFlag);
  }
}

void MoveObject::ChangeSkeleton(bool activete)
{
	if ( anima_node_  == NULL)
		return;

	std::string effect_name = "cain_buff_bind_last";
	int tag = army::getTagByName(effect_name);
	if ( activete )
	{
		anima_node_->GetBodyNode()->setVisible( false);
		
		CCNode* armatureNode = anima_node()->getChildByTag(tag);
		if ( armatureNode == NULL )
		{
			ShowAuraEffectByArmature( effect_name, ability::kEffectPositionType_Bottom, false);
			armatureNode = anima_node()->getChildByTag(tag);
		}
		CCArmature* armature = dynamic_cast<CCArmature*>(armatureNode);
		if ( armature != NULL)
		{
			armature->getAnimation()->play("bsj", 0, -1, 1);
		}
	}
	else
	{
		anima_node_->GetBodyNode()->setVisible( true);
		RemoveAuraEffectByArmature(tag);
	}
}
  
void MoveObject::AttachUnitIntoBattleView(battle::BattleView* parent,
                                          cocos2d::CCPoint attach_pos,
                                          bool isSpecialForVictory /* = flase */)
{
  assert(!anima_node_);
  // new something in memory
  anima_node_       = new SkeletonAnimation();
  anima_manager_    = new effect::SkeletonAnimationManager(this);
  // set some properties
  anima_node_->set_tag(move_object_id_);
  this->set_current_pos(attach_pos);
  this->set_tile_index(battle::GetTileIndexByCurrentPointPosition(attach_pos));
  this->owner_hub()->insertAttackerReference(this);
  // create animation & attach it into battle_view
  if (isSpecialForVictory)
  {
    this->addWinningAnimation();
  }
  else
  {
    this->addUnitAniamtion();
  }
  
  MoveObjBornEvent::Emit( move_object_id_ );

  battle::BattleController::GetInstance().notifyMoveObjBorn( move_object_id_);


  parent->AddElementToScene(this->anima_node(), battle::kCharacterLayer);
}

// dettach unit's animation node form parent
void MoveObject::DettachUnitFromBattleView()
{
  if (!anima_node_ || false == anima_node_->getParent())
  {
    return;
  }
  anima_node_->removeFromParentAndCleanup(true);
  this->owner_hub()->battle_view()->ClearBindNode(move_object_id_);
}
  
void MoveObject::CreatePassiveAbilities(bool isBackStageNeed /* = false */)
{
  for (std::vector<int>::iterator it = passive_skill_ids_.begin(); it != passive_skill_ids_.end(); ++it)
  {
	  battle::BattleController::AuraMgr()->AddAura( this, *it, this->move_object_id_);
  }

  //battle::BattleController::AuraMgr()->AddAura( this, 10055, this->move_object_id_);
}

bool MoveObject::Update(float delta)
{
  // update z order & scale & tile coordinate pos by point pos
  this->freshZOrder();
  // update health bar
  float percent = 100.0f*this->currnet_health_point() /
                  static_cast<float>(this->total_health_point());
  health_point_->setPercent(percent);
  health_point_bg_->setPercent(percent);

  // update animation manager
  this->anima_manager_->Update(delta);
  // update bind node : character box, bind line & aim circle
  owner_hub()->battle_view()->UpdateBindNode(battle::kBottomLayer,
                                             move_object_id_,
                                             current_pos());
  //update info for triggers
  if(near_attck_trigger_)
  {
    near_attck_trigger_->Update(delta);
  }
  if(guard_trigger_)
  {
    guard_trigger_->Update(delta);
  }

  //update skill cool time
  skill_cool_time_ += delta;
  normal_skill_cool_time_ += delta;
  //update stage time
  stage_time_      += delta;
  pop_damage_label_time_ += delta;

  if ( pop_damage_label_time_ > 0.1f )
  {
	  pop_damage_label_time_ = 0.0f;
	  this->popDamageLabel();
  }

  updateShield(delta);

	if ( sandbox_unit_info_label_ && sandbox_unit_info_label_->isVisible() )
	{
		std::string label_content;
		label_content += "ID:" + Uint2String(move_object_id_);
		label_content += "    ";
		label_content += "HP:" + Int2String(currnet_health_point_) + " / " + Int2String(total_health_point_);
		label_content += "\n";
		label_content += "PhyAtt:" + Int2String(physics_attack_) + "_Mul-" + Float2String2f(physics_blood_boost_multiple_);
		label_content += "\n";
		label_content += "MagAtt:" + Int2String(magic_attack_) + "_Mul-" + Float2String2f(magic_blood_boost_multiple_);
		label_content += "\n";
		label_content += "PhyDef:" + Int2String(basic_physics_defense_) + "_add-"+ Float2String2f(physics_defense_added_) + "_Mul-" + Float2String2f(defense_physics_multiple_);
		label_content += "\n";
		label_content += "MagDef:" + Int2String(basic_magic_defense_) + "_add-"+ Float2String2f(magic_defense_added_) + "_Mul-" + Float2String2f(defense_magic_multiple_);
		label_content += "\n";
		label_content += "AttSpeed:" + Float2String2f(attack_speed_) + "_addm-"+ Float2String2f(attack_speed_added_multiple_) + "_subm-" + Float2String2f(attack_speed_lowered_multiple_);
		label_content += "\n";
		label_content += "MovSpeed:" + Float2String2f(move_speed_value_) + "_addm-"+ Float2String2f(move_speed_added_multiple_) + "_subm-" + Float2String2f(move_speed_lowered_multiple_);
		label_content += "\n";
		label_content += "ADThorns:" + Float2String2f(physics_thorns_boost_multiple_) + "_APThorns:" + Float2String2f(magic_thorns_boost_multiple_);
		label_content += "\n";
		label_content += "ADBlood:" + Float2String2f(physics_blood_boost_multiple_) + "_APBlood:" + Float2String2f(magic_blood_boost_multiple_);
		label_content += "\n";
		label_content += "DamageMul:" + Float2String2f(damage_boost_multiple_) + "_ByDamageMul:" + Float2String2f(by_damage_boost_multiple_);
		label_content += "\n";
		label_content += "HealMul:" + Float2String2f(heal_boost_multiple_) + "_ByHealMul:" + Float2String2f(by_heal_boost_multiple_);
		label_content += "\n";
		label_content += "CriPro:" + Float2String2f(critical_) + "_Mul:" + Float2String2f(critical_multiple_);
		label_content += "\n";
		label_content += "CriDamMul:" + Float2String2f(critical_damage_);
		label_content += "\n";

		sandbox_unit_info_label_->setString(label_content.c_str());
	}

  //actor
  actor_->Update(delta);

  return true;
}

void MoveObject::ChangeAnimationToIndex(std::string animation_name,
                                        const int cycle_count /* = -1 */,
                                        const float speed /* = 1.0f */)
{
  assert(anima_node_);
  anima_node_->Play(animation_name, cycle_count, speed);
}
  
void MoveObject::StopAnimation()
{
  assert(anima_node_);
  anima_node_->Stop();
}
  
// set anima_node into invisbility
void MoveObject::SetAnimationIntoInvisbilityAndMarkByStatus()
{
	if (check_battle_status_flag(battle::kDamageInvisbility))
	{
		return;
	}
  // set mark flag
	retain_battle_status_flag(battle::kDamageInvisbility);

  // fade out
  anima_node_->SetOpacity(125);
}

void MoveObject::ResetAnimationOutOfInvisbilityAndMarkByStatus()
{
	if (!check_battle_status_flag(battle::kDamageInvisbility))
	{
		return;
	}
  // erase mark flag
	release_battle_status_flag(battle::kDamageInvisbility);

  // fade in
  anima_node_->SetOpacity(255);
}

void MoveObject::BeDestroyed()
{
  CCLog("MoveObject::BeDestroyed() %ld", this->move_object_id());
  this->DettachUnitFromBattleView();
  this->ClearAllProperties();
}
  
// calculate coordinate x axis by current tile index pos
int_8 MoveObject::GetCurrentColumnIndex()
{
  return battle::GetTileCoordinatePosByTileIndex(tile_index_).x;
}
  
// calculate coordinate y axis by current tile index pos
int_8 MoveObject::GetCurrentRowIndex()
{
  return battle::GetTileCoordinatePosByTileIndex(tile_index_).y;
}
eCareerType MoveObject::GetCareerType()
{
	return static_cast<eCareerType>(character_card_data_->GetJobType());
}

const std::string& MoveObject::GetCardName()
{
	return character_card_data_->GetName();
}

void MoveObject::GoDeadStation(battle::eDeadReason dr)
{
	if ( false == is_active_)
		return;

	dead_reason_ = dr;
	if ( battle::kDeadReason_Suicide == dead_reason_)
	{
		if ( !anima_node_->existedAnimationName(army::kUnitAnimationDead_2))
		{
			dead_reason_ = battle::kDeadReason_Normal;
		}
	}

	MoveObjDeadEvent::Emit( move_object_id_);

	if ( is_Resurgence() )
	{
		// set AI state
		this->set_ai_state(ai::KAIStateDead);
		this->set_temp_dead(true);
	}
	else
	{
		CCLOG("Dead state for MoveObj: %ld", move_object_id_);
		// remove all status data
		battle::BattleController::AuraMgr()->RemoveAllAuraOnMoveObject(this);
		CCLOG("remove all status data");
		// remove map reference
		this->owner_hub()->removeAttackerReference(this);
		CCLOG("remove map reference");
		// send notification death
		this->owner_hub()->troops()->NotifyTargetDestroyed(this->move_object_id());
		CCLOG("send notification death");
		// move out of unit from active list
		this->owner_hub()->troops()->RemoveOneUnitIdFromActiveIdsList(this->move_object_id());
		CCLOG("move out of unit from active list");
		// set AI state
		this->set_ai_state(ai::KAIStateDead);
		// move to ms_dead
		// hide shadow
		//this->anima_node()->FadeOutShadow();
		// set active flag at LAST
		this->set_is_active(false);
		// reselect new character if current dead one is selected one
		battle::BattleController::GetInstance().CharacherDeadWithCharacterId(move_object_id_);
	}
}
  
// hide health bar
void MoveObject::HideHealthBar()
{
  // remove health bar
  anima_node_->removeChildByTag(kHitPointBarFlag, true);
}

void MoveObject::setShowInfoOnSandBox(bool show, int x, int y)
{
	if ( battle::BattleController::GetInstance().getBattleType() != battle::kBattleType_SandBox )
		return;

	if ( sandbox_unit_info_label_ == NULL)
	{
		sandbox_unit_info_label_ = cocos2d::CCLabelTTF::create("a\nb\nc", "Helvetica", 20);
		sandbox_unit_info_label_->setColor(ccGREEN);
		sandbox_unit_info_label_->setAnchorPoint(ccp(0.0f, 1.0f));
		sandbox_unit_info_label_->setPosition(cocos2d::CCPoint(x, y));
		sandbox_unit_info_label_->setRichLabelWidth(200.0f);
		sandbox_unit_info_label_->setHorizontalAlignment(kCCTextAlignmentLeft);
		battle::BattleController::GetInstance().battle_view()->AddElementToScene( sandbox_unit_info_label_, battle::kTopLayer);

	}

	sandbox_unit_info_label_->setVisible(show);
}

CCPoint MoveObject::getEffectPosition(int effect_pos_type)
{
	CCNode* hpBar =  anima_node()->getChildByTag(army::kHitPointBarFlag);
	if ( hpBar )
	{
		CCPoint hpPoint = hpBar->getPosition();

		if ( effect_pos_type == ability::kEffectPositionType_Top )
		{
			return ccp( 0, hpPoint.y + 50);
		}
		else if ( effect_pos_type == ability::kEffectPositionType_Mid )
		{
			return ccp( 0, 0.5f * hpPoint.y);
		}
	}

	return CCPointZero;
}

void MoveObject::ShowAuraEffectByArmature(const std::string & effectName, int effectPos, bool replace /* = false */)
{
	if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData( effectName.c_str()) == NULL)
	{
		std::string skeleton_config = kDefaultSkeletonFilePath+effectName+".xml";
		std::string skeleton_plist = kDefaultSkeletonFilePath+effectName+".plist";
		std::string skeleton_texture = kDefaultSkeletonFilePath+effectName+".pvr.ccz";
		CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(
			skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
	}

	int tag = getTagByName(effectName);
	if ( replace )
	{
		this->anima_node()->removeChildByTag(tag);
	}
	else
	{
		if (this->anima_node()->getChildByTag(tag))
		{
			return;
		}
	}
	
	CCArmature* armature_ = CCArmature::create(effectName.c_str());
	armature_->setPosition(ccpAdd(armature_->getPosition(), this->getEffectPosition(effectPos)));
	this->anima_node()->addChild(armature_,1,tag);
	if (this->anima_direction() == kDirectionRight)
		armature_->setRotationY(180);
	armature_->getAnimation()->play("bsj", 0, -1, 0);
	//armature_->release();
}

void MoveObject::RemoveAuraEffectByArmature( const std::string & effectName)
{
	if (effectName.size()==0)
	{
		return;
	}

	int tag = getTagByName(effectName);

	this->RemoveAuraEffectByArmature(tag);
}

void MoveObject::RemoveAuraEffectByArmature( int tag)
{
	this->anima_node()->removeChildByTag(tag);
}

void MoveObject::ShowStatusEffectOnWithName(const std::string& effectName, int effectPos ,bool needFlipX /* = false */)
{
  if (effectName.size()==0)
  {
    return;
  }

  int tag = getTagByName(effectName);
  if (this->anima_node()->getChildByTag(tag))
  {
	  return;
  }
  ProjectileAnimation* effect = new ProjectileAnimation();
  effect->initWithName(effectName.c_str());
  effect->setPositionType(kCCPositionTypeRelative);
  effect->setParticleFlipX(needFlipX);
  effect->setPosition(ccpAdd(effect->getPosition(), this->getEffectPosition(effectPos)));

  this->anima_node()->addChild(effect, 1, tag);
  effect->release();
}
  
void MoveObject::ReplaceOneStatusEffectNewOneWithName(const std::string& effectName, int effectPos)
{
  if (effectName.size()==0)
  {
    return;
  }
  int tag = getTagByName(effectName);
  this->anima_node()->removeChildByTag(tag);
  ProjectileAnimation* effect = new ProjectileAnimation();
  effect->setPosition(ccpAdd(effect->getPosition(),this->getEffectPosition(effectPos)));
  effect->initWithName(effectName.c_str());
  this->anima_node()->addChild(effect, 1, tag);
  effect->release();
}
  
void MoveObject::RemoveStatusEffectWithName(const std::string &effectName)
{
  if (effectName.size()==0)
  {
    return;
  }
  
  int tag = getTagByName(effectName);

  if (NULL==this->anima_node()->getChildByTag(tag))
  {
	  return;
  }
  if (effectName==kStatusEffectTagFreeze)
  {
	  this->ShowStatusEffectOnWithName(kStatusEffectTagFreezeBreak, ability::kEffectPositionType_Mid);
  }
  else if (effectName==kStatusEffectTagBuffplus)
  {
	  if (damage_boost_multiple_>1.0f)
	  {
		  return;
	  }
  }
  this->anima_node()->removeChildByTag(tag);
}

  
void MoveObject::freshZOrder()
{
  if (mZOrderLockCount > 0)
  {
    return;
  }
  cocos2d::CCPoint curPos = anima_node_->getPosition();
  // only update position / tile index / scale / z order / obj reference for one 
  // moveObject after it moved more then 5 pixel yet on the battle tiled map
  if ( fabsf(pos_in_last_update_.x-curPos.x)+
       fabsf(pos_in_last_update_.y-curPos.y) > kSmallestUpdatePosDistance)
  {
    pos_in_last_update_ = curPos;
    anima_node_->setZOrder(battle::GetZorderByPosition(this->get_pos_by_offset(this->offset_points_count() - 1),
                                                       this->move_object_id()));
    anima_node_->setScale(battle::GetScaleByPosition(anima_node_->getPosition()));
    int_8 originalTileIdx = tile_index_;
    tile_index_ = battle::GetTileIndexByCurrentPointPosition(curPos);
	  assert(tile_index_!=battle::kUnexistTileIndex);
    if (originalTileIdx != tile_index_) {
      this->owner_hub()->updateAttackerReference(originalTileIdx, this);
    }    
  }  
}

void MoveObject::addUnitAniamtion()
{
  // create animation node & shadow
  std::string cardName = GetMoveObjectNameByCardId(card_id_);
  float armature_scale = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id_)->GetSkeletonScale();

  //CCLog("Skeleton Weapon: id: %d, card_id: %d, skeleton_name: %s, r")

  anima_node_->Init(cardName.c_str(), cardName.c_str());
  CCString *str_card_id = CCString::create(Int2String(card_id_));
  //str_card_id->retain();
  anima_node_->GetArmatureNode()->setUserObject(str_card_id);
  anima_node_->GetArmatureNode()->setTag(card_id_);
  anima_node_->SetAnimationScale(armature_scale);
  anima_node_->AddShadow();
  // add aim target
  battle::AimMark* aim_mark = battle::AimMark::Create(battle::kAimMarkFriend);
  aim_mark->setPosition(ccp(0, battle::kSelectedBorderOffsetHight));
  anima_node_->addChild(aim_mark, 10, kAimMarkTag);
  //创建一个UILayer层
  UILayer* ui_layer = UILayer::create();
  //开启刷新函数
  ui_layer->scheduleUpdate();
  ui_layer->setPosition(anima_node_->GetBonePositionInSkeleton(kBoneTypeHealthBar));
  //将UILayer层加入到当前的场景
  anima_node_->addChild(ui_layer, kHitPointBarFlag, kHitPointBarFlag);

  // 如果需要画出obj_id
  if (LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "IsShowObjID"))
  { // NOTE : DEBUG ONLY
    char temp[20];
    sprintf(temp, "%ld, %ld", move_object_id_, card_id_);
    cocos2d::CCLabelTTF *label_id = cocos2d::CCLabelTTF::create(temp, "Helvetica", 20);
    label_id->setPosition(ccp(50.0f, anima_node_->GetBoundingBox().size.height+10));
    anima_node_->addChild(label_id, kHitPointBarFlag+1);
    
    cocos2d::CCNode *button_layer = owner_hub()->battle_view()->
                                       GetLayerBindNode(battle::kBottomLayer, move_object_id_);
    
    if(guard_trigger_ &&
       LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", \
                                                          "IsShowGuardArea"))
    {
      cocos2d::CCNode *node = effect::TouchAreaNodeFactory::\
                                CreateAreaNode(this,effect::kTouchAreaGuard);
      //node->setPositionY(GetCenterPointOnUnitAnimationNode().y);
      button_layer->addChild(node);

    }
    if(near_attck_trigger_ &&
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", \
                                                        "IsShowNearAttackArea"))
    {
      cocos2d::CCNode *node = effect::TouchAreaNodeFactory::\
                                CreateAreaNode(this,effect::kTouchAreaNearAttack);
      //node->setPositionY(GetCenterPointOnUnitAnimationNode().y);
      button_layer->addChild(node);
    }    
  }

  if (LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "IsShowCharacterBoundBox"))
  {
    CCDrawNode* bounxBox = CCDrawNode::create();
    anima_node_->addChild(bounxBox, 100000);
    ccColor4F yellow = {1, 1, 0, 1};
    ccColor4F white = {0, 0, 0, 0};
    CCRect bounx = anima_node_->GetArmatureNode()->boundingBox();
    //bounx.setRect();
    CCPoint rect[4]={ccp(bounx.getMinX(), bounx.getMinY()),ccp(bounx.getMaxX(), bounx.getMinY()),ccp(bounx.getMaxX(), bounx.getMaxY()),ccp(bounx.getMinX(), bounx.getMaxY()) };
    bounxBox->drawPolygon(rect, 4, white, 10, yellow);
  }
}
  
// init skill ids
void MoveObject::initSkillIds()
{
  passive_skill_ids_.clear();
  int addedId = character_card_data_->GetSkillId(kSkillPassive1);
  if (addedId>0) {
    passive_skill_ids_.push_back(addedId);
  }
  addedId = character_card_data_->GetSkillId(kSkillPassive2);
  if (addedId>0) {
    passive_skill_ids_.push_back(addedId);
  }
  addedId = character_card_data_->GetSkillId(kSkillWeapon);
  if (addedId>0) {
    passive_skill_ids_.push_back(addedId);
  }
}
  
void MoveObject::initHealthBarPercent()
{
  UILayer* ui_layer = dynamic_cast<UILayer*>(anima_node_->getChildByTag(kHitPointBarFlag));
  assert(ui_layer);
  
  health_point_ = dynamic_cast<UILoadingBar*>(ui_layer->getWidgetByName("progress_hp"));
  health_point_->setPercent(100);
  health_point_->retain();
  
  health_point_bg_ = dynamic_cast<UILoadingBar*>(ui_layer->getWidgetByName("progress_bg"));
  health_point_bg_->setPercent(100);
  health_point_bg_->setIsHaveAni(true);
  health_point_bg_->retain();
}

void MoveObject::updateMoveSpeed()
{
	//updateMoveSpeedBoostMultiple
	float curr_move_speed_added = 0.0;

	if ( this->check_battle_status_flag(battle::kDamageStatusImmune) &&
		this->check_immune_status_flag(battle::kImmuneTypeLowerMoveSpeed))
	{
		curr_move_speed_added = move_speed_added_multiple_;
	}
	else
	{
		curr_move_speed_added = move_speed_added_multiple_ + move_speed_lowered_multiple_;
	}

	if ( curr_move_speed_added > 2.0f) // 上限+200%
	{
		curr_move_speed_added = 2.0f;
	}
	else if ( curr_move_speed_added < -0.9f) // -10%
	{
		curr_move_speed_added = -0.9f;
	}

	move_speed_boost_multiple_ = 1.0f + curr_move_speed_added;


	// update move speed vector
  float orignalValue = sqrtf(move_speed_.x*move_speed_.x + move_speed_.y*move_speed_.y);
  if ( orignalValue!=0 )
  {
    move_speed_.x = move_speed_.x*this->mover_speed_value()/orignalValue;
    move_speed_.y = move_speed_.y*this->mover_speed_value()/orignalValue;
  }
}

int_32 MoveObject::play_skill_id()
{
  return play_skill_id_;
}

void MoveObject::set_play_skill_id( int_32 skill_id )
{
  play_skill_id_ = skill_id;
}

void MoveObject::add_bear_damage(int damage)
{
	if ( damage > 0)
	{
		bear_damage_ += damage;
	}
}
void MoveObject::set_guard_trigger(ai::Trigger *trigger)
{
	guard_trigger_ = trigger;
	float new_radius = ( base_circle_guard_radius_ + circle_guard_radius_added_ )* circle_guard_radius_multiple_;
	if ( guard_trigger_)
	{
		guard_trigger_->set_circle_guard_radius( new_radius);
	}
}

void MoveObject::set_circle_guard_radius_added(float added)
{
	circle_guard_radius_added_ += added;
	float new_radius = ( base_circle_guard_radius_ + circle_guard_radius_added_ )* circle_guard_radius_multiple_;
	if ( guard_trigger_)
	{
		guard_trigger_->set_circle_guard_radius( new_radius);
	}
}

void MoveObject::set_circle_guard_radius_multiple(float mul)
{
	circle_guard_radius_multiple_ += mul;
	float new_radius = ( base_circle_guard_radius_ + circle_guard_radius_added_ )* circle_guard_radius_multiple_;
	if ( guard_trigger_)
	{
		guard_trigger_->set_circle_guard_radius( new_radius);
	}
}

void MoveObject::PushDamageLabel(int damage_value , battle::eDamageLabelType damege_label_type, bool is_skill_damage)
{
	if ( damege_label_type == battle::eDamageLabelType_Unknown)
	{
		return;
	}

  if (is_skill_damage)
  {
    //1.技能伤害立刻显示
    bool  is_character_hub = this->owner_hub()->IsCharacterHub();

    battle::DamageLabel* label = battle::DamageLabel::create( damege_label_type, damage_value, is_character_hub );

    int body_height = this->anima_node()->GetBoundingBox().size.height;

    if(body_height > 550)
      body_height *= 0.8;

    cocos2d::CCPoint pos = ccp( this->current_pos().x, this->current_pos().y+ /*0.9f * body_height*/ 140 );

    label->ShowDamageValueOnBattleLayer( battle::BattleController::GetInstance().battle_view(), pos);
  }
  else
  {
    DamageLabelParam dl;
    dl.damage_value = damage_value;
    dl.damege_label_type = damege_label_type;

	  damage_label_queue_.push(dl);
  }
}
void MoveObject::popDamageLabel()
{
	while ( damage_label_queue_.size() > 0)
	{
		DamageLabelParam dl = damage_label_queue_.front();
		damage_label_queue_.pop();

		bool  is_character_hub = this->owner_hub()->IsCharacterHub();

		battle::DamageLabel* label = battle::DamageLabel::create( dl.damege_label_type, dl.damage_value, is_character_hub );

		int body_height = this->anima_node()->GetBoundingBox().size.height;

		if(body_height > 550)
			body_height *= 0.8;

		cocos2d::CCPoint pos = ccp( this->current_pos().x, this->current_pos().y+ /*0.9f * body_height*/ 140 );

		label->ShowDamageValueOnBattleLayer( battle::BattleController::GetInstance().battle_view(), pos);
		break;
	}
}

void MoveObject::AddShield(const ability::Shield& shield)
{
	_shidle_list.push_back(shield);
}

void MoveObject::RemoveShieldByAura(int auta_id)
{
	ability::Shield* pShield = NULL;
	std::list<ability::Shield>::iterator iter = _shidle_list.begin();
	for ( ;iter != _shidle_list.end(); ++iter )
	{
		pShield = &(*iter);
		if ( pShield->getAuraId() == auta_id)
		{
			pShield->set_invalided();
			return;
		}
	}
}

bool MoveObject::ShieldWithstandSkill( int_32 master_id, int_32 skill_id)
{
	if ( _shidle_list.size() == 0)
		return false;

	ability::Shield* pShield = NULL;
	std::list<ability::Shield>::iterator iter = _shidle_list.begin();
	for ( ;iter != _shidle_list.end(); ++iter )
	{
		pShield = &(*iter);
		if ( pShield->is_valid() &&pShield->is_withstand_skill_shield())
			break;
		//
		pShield = NULL;
	}

	if ( NULL == pShield)
	{
		return false;
	}

	SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
	if (!skillData->GetSkillType())
	{
		return false;
	}

	if ( master_id == move_object_id_ && skillData->GetDamageSelfPercent()>0)
	{
		// 自残不格挡
		return false;
	}
	
	pShield->subCount();
	PushDamageLabel(0, battle::eDamageLabelType_MagicImmune, false);
	return true;
}

void MoveObject::ShieldSubtractDamage( int_32& outDamageVal, battle::eAttackDamageType damageType )
{
	if ( outDamageVal <= 0)
		return;

	if ( _shidle_list.size() == 0)
		return;

	int remainDamage = outDamageVal;
	do 
	{
		ability::Shield* pShield = NULL;
		std::list<ability::Shield>::iterator iter = _shidle_list.begin();
		for ( ;iter != _shidle_list.end(); ++iter )
		{
			pShield = &(*iter);
			if ( pShield->is_valid() &&pShield->is_withstand_damage_and_heal_shield())
				break;
			//
			pShield = NULL;
		}
		if ( pShield == NULL)
		{
			iter = _shidle_list.begin();
			for ( ;iter != _shidle_list.end(); ++iter )
			{
				pShield = &(*iter);
				if ( pShield->is_valid())
				{
					if ( battle::kDamageTypePhysics == damageType && pShield->is_withstand_physics_damage_shield() )
					{
						break;
					}
					else if ( battle::kDamageTypeMagic == damageType && pShield->is_withstand_magic_damage_shield() )
					{
						break;
					}
				}
				pShield = NULL;
			}
		}

		if ( pShield == NULL )
			break;

		int subPer = pShield->subValue( outDamageVal );
		remainDamage -= subPer;
		if ( remainDamage == 0 )
		{
			break;
		}

		if ( pShield->is_withstand_damage_and_heal_shield() && !pShield->is_valid())
		{
			if ( abs(outDamageVal) > remainDamage )
			{
				outDamageVal += remainDamage;
				break;
			}
			else
			{
				remainDamage -= abs(outDamageVal);
			}
		}

		outDamageVal = remainDamage;

	} while (1);

	if ( 0 == outDamageVal )
	{
		if (damageType == battle::kDamageTypePhysics)
		{
			PushDamageLabel(0, battle::eDamageLabelType_PhysicsImmune, false);
		}
		else if (damageType == battle::kDamageTypeMagic)
		{
			PushDamageLabel(0, battle::eDamageLabelType_MagicImmune, false);
		}
	}
	else if ( 0 > outDamageVal)
	{
		// 吸收
		//PushDamageLabel(0, battle::eDamageLabelType_PhysicsImmune, false);
	}
}

void MoveObject::updateShield(float delta)
{
	std::list<ability::Shield>::iterator iter = _shidle_list.begin();
	while ( iter != _shidle_list.end() )
	{
		ability::Shield& shield = (*iter);
		if ( !shield.Update(delta))
		{
			battle::BattleController::AuraMgr()->RemoveShield( move_object_id_, shield.getAuraId());
			iter = _shidle_list.erase(iter);
		}
		else
		{
			++iter;
		}
	}
}

float MoveObject::GetElementsDamageWeakenMultiple(battle::eDamageStatus type)
{
	if (elements_damage_weaken_multiple_.find(type) != elements_damage_weaken_multiple_.end())
	{
		return elements_damage_weaken_multiple_[type];
	}
	else
	{
		return 0.0f;
	}
}

void MoveObject::SetElementsDamageWeakenMultiple(uint_32 type, float addedMul)
{
	for (int i = 0; i<battle::kDamageMax; ++i)
	{
		battle::eDamageStatus singleType = static_cast<battle::eDamageStatus>(1<<i);
		if ( singleType&type )
		{
			if (elements_damage_weaken_multiple_.find(singleType) != elements_damage_weaken_multiple_.end())
			{
				elements_damage_weaken_multiple_[singleType] = elements_damage_weaken_multiple_[singleType]+addedMul;
			}
			else
			{
				elements_damage_weaken_multiple_.insert(std::pair<battle::eDamageStatus, float>(singleType, addedMul));
			}
		}
	}
}

float MoveObject::GetElementsDamageAddedMultiple(battle::eDamageStatus type)
{
	if (elements_damage_added_multiple_.find(type)!=elements_damage_added_multiple_.end())
	{
		return elements_damage_added_multiple_[type];
	}
	else
	{
		return 1.0f;
	}
}
void MoveObject::SetElementsDamageAddedMultiple(uint_32 type, float addedMul)
{
	for (int i = 0; i<battle::kDamageMax; ++i)
	{
		battle::eDamageStatus singleType = static_cast<battle::eDamageStatus>(1<<i);
		if ( singleType&type )
		{
			if (elements_damage_added_multiple_.find(singleType)!=elements_damage_added_multiple_.end())
			{
				elements_damage_added_multiple_[singleType] = elements_damage_added_multiple_[singleType]+addedMul;
			}
			else
			{
				elements_damage_added_multiple_.insert(std::pair<battle::eDamageStatus, float>(singleType, addedMul));
			}
		}
	}
}

Summon* MoveObject::SummonElement(uint_16 level, uint_32 card_id, int_8 tileIdx)
{
	uint_32 unit_id = owner_hub_->AddImmediatelySummonAtIndex(level, card_id, tileIdx);

	Summon* summonObj = owner_hub_->GetSunmonUnitById( unit_id );
	
	assert(summonObj);
	summonObj->set_summoner_id(move_object_id_);

	return summonObj;
}

bool MoveObject::is_five_elements_restraint(int five_ele)
{
	return false; // 暂时不需要

	// 火克冰， 冰克风，风克火
	if (five_elements_ == battle::kDamageIceProperty && five_ele == battle::kDamageWindProperty )
	{
		return true;
	}
	else if ( five_elements_ == battle::kDamageFireProperty && five_ele == battle::kDamageIceProperty )
	{
		return true;
	}
	else if ( five_elements_ == battle::kDamageWindProperty && five_ele == battle::kDamageFireProperty )
	{
		return true;
	}

	return false;
}

void MoveObject::add_normal_hit_count()
{
	normal_hit_count_ ++;
	if ( normal_hit_count_ % 2 == 0)
	{
		set_trigger_skill_id(26211);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
uint_32 MoveObject::attack_status()
{
	uint_32 flag = 0;
	for ( int idx = kAEPPMax-1; idx >= 0; --idx)
	{
		flag = elements_attack_status_[idx];
		if (flag!=0)
		{         
			break;
		}
	}
	return ((attack_status_ & battle::kDamageProperty ) | flag);
}
void MoveObject::set_attack_status(uint_32 flag, eAttackElementsPropertyPriority priority)
{
	attack_status_ = attack_status_|flag;
	flag = flag & battle::kDamageProperty;
	assert(0==(flag&(flag-1))); // flag MUST NOT cantains more than one 1 bit value
	elements_attack_status_[priority] = static_cast<battle::eDamageStatus>(flag);
}
void MoveObject::ResetAttackStatus(uint_32 flag, eAttackElementsPropertyPriority priority)
{
	attack_status_ = attack_status_ & (~flag);
	flag = flag & battle::kDamageProperty;
	assert(0==(flag&(flag-1))); // flag MUST NOT cantains more than one 1 bit value
	flag = elements_attack_status_[priority] & (~flag);
	elements_attack_status_[priority] = static_cast<battle::eDamageStatus>(flag);
}

////////////////////////////////////////////////////////////////////////////////////////////////
void MoveObject::set_basic_physics_attack_( uint_32 vla)
{
	basic_physics_attack_ = vla;
	physics_attack_ = (basic_physics_attack_ + physics_attack_added_) * physics_attack_multiple_;
}
void MoveObject::set_physics_attack_added( int added )
{
	physics_attack_added_ += added;
	physics_attack_ = (basic_physics_attack_ + physics_attack_added_) * physics_attack_multiple_;
}
void MoveObject::set_physics_attack_multiple(float mul)
{
	physics_attack_multiple_ += mul;
	physics_attack_ = (basic_physics_attack_ + physics_attack_added_) * physics_attack_multiple_;
}
int MoveObject::physics_attack()
{
	if ( physics_attack_ > 0)
	{
		return physics_attack_;
	}

	return 0;
}
//////////////////////////////////////////////////////////////////////////////////////
void MoveObject::set_basic_magic_attack_( uint_32 vla)
{
	basic_magic_attack_ = vla;
	magic_attack_ = (basic_magic_attack_ + magic_attack_added_) * magic_attack_multiple_;
}
void MoveObject::set_magic_attack_added( int added )
{
	magic_attack_added_ += added;
	magic_attack_ = (basic_magic_attack_ + magic_attack_added_) * magic_attack_multiple_;
}
void MoveObject::set_magic_attack_multiple(float mul)
{
	magic_attack_multiple_ += mul;
	magic_attack_ = (basic_magic_attack_ + magic_attack_added_) * magic_attack_multiple_;
}

int MoveObject::magic_attack()
{
	if ( magic_attack_ > 0)
	{
		return magic_attack_;
	}

	return 0;
}
/////////////////////////////////////////////////////////////////////////////////////
void MoveObject::set_basic_critical_damage( float val)
{
	basic_critical_damage_ = val;
	critical_damage_ = ( basic_critical_damage_ + critical_damage_added_ ) * critical_damage_multiple_;
}
void MoveObject::set_critical_damage_added(float val)
{
	critical_damage_added_ += val;
	critical_damage_ = ( basic_critical_damage_ + critical_damage_added_ ) * critical_damage_multiple_;
}
void MoveObject::set_critical_damage_multiple(float val)
{
	critical_damage_multiple_ += val;
	critical_damage_ = ( basic_critical_damage_ + critical_damage_added_ ) * critical_damage_multiple_;
}
float MoveObject::critical_damage()
{
	if ( critical_damage_ < 0.0f)
	{
		return 0.0f;
	}

	return critical_damage_;
}
////////////////////////////////////////////////////////////////////////////////////////
/*
暴击：
暴击初始10~25，根据职业区分；
暴击上限5000（根据100级计算）；
暴击率=暴击/（暴击+lv*75）；
*/
void MoveObject::set_basic_critical(float val)
{
	basic_critical_ = val;
	critical_ = ( basic_critical_  + critical_added_ ) * critical_multiple_;
}
void MoveObject::set_critical_added(float val)
{
	critical_added_ += val;
	critical_ = ( basic_critical_  + critical_added_ ) * critical_multiple_;
}
void MoveObject::set_critical_multiple(float val)
{
	critical_multiple_ += val;
	critical_ = ( basic_critical_  + critical_added_ ) * critical_multiple_;
}
float MoveObject::critical_probability( float target_level)
{
	if ( critical_ == 0.0f)
		return 0.0f;

	float temp_critical_ = critical_;
	if ( temp_critical_ > 5000.0f )
		temp_critical_ = 5000.0f;

	float temp_level = target_level;
	if ( temp_level > 100)
		temp_level = 100;

	float ret = temp_critical_ / ( temp_critical_ + temp_level * 15.0f + 200.0f );
	return ret;
}
////////////////////////////////////////////////////////////////////////////////////////
void MoveObject::set_basic_hit_rate(float vla)
{
	basic_hit_rate_ = vla;
	hit_rate_ = (basic_hit_rate_ + hit_rate_added_) * hit_rate_multiple_;
}
void MoveObject::set_hit_rate_added(float vla)
{
	hit_rate_added_ += vla;
	hit_rate_ = (basic_hit_rate_ + hit_rate_added_) * hit_rate_multiple_;
}
void MoveObject::set_hit_rate_multiple(float mul)
{
	hit_rate_multiple_ += mul;
	hit_rate_ = (basic_hit_rate_ + hit_rate_added_) * hit_rate_multiple_;
}
float MoveObject::get_hit_rate(float target_dodge)
{
	/*
	命中/闪避：
	命中初始100，上限5000；
	闪避初始0，上限1000；
	命中率=命中/(命中+闪避)
	*/
	if ( hit_rate_ == 0.0f )
	{
		return 0.0f;
	}

	float temp_hit_rate_ = hit_rate_;
	if ( temp_hit_rate_ > 5000 )
		temp_hit_rate_ = 5000;

	float temp_dodge = target_dodge;
	if ( temp_dodge > 1000 )
		temp_dodge = 1000;

	float ret = temp_hit_rate_ / ( temp_hit_rate_ + temp_dodge);
	return ret;
}
////////////////////////////////////////////////////////////////////////////////////////
void MoveObject::set_basic_dodge(float vla)
{
	basic_dodge_ = vla;
	dodge_ = ( basic_dodge_ + dodge_added_) * dodge_multiple_;
}
void MoveObject::set_dodge_added(float vla)
{
	dodge_added_ += vla;
	dodge_ = ( basic_dodge_ + dodge_added_) * dodge_multiple_;
}
void MoveObject::set_dodge_multiple(float mul)
{
	dodge_multiple_ += mul;
	dodge_ = ( basic_dodge_ + dodge_added_) * dodge_multiple_;
}
float MoveObject::get_dodge()
{
	return dodge_;
}
////////////////////////////////////////////////////////////////////////////////////////
} // army
} // taomee