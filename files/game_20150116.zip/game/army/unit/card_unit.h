//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  move_object.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  10:25
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_card_unit_h
#define ChainChronicle_card_unit_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/army/unit/unit_constants.h"

namespace taomee {
namespace army {
  
class CardUnit {
public: // constructor & destructor & initialization
  CardUnit();
  virtual ~CardUnit();
  
  void ClearAllProperties();
  
public: // getter & setter
  // id
  void                  set_card_id(uint_32 card_id) { card_id_ = card_id; }
  uint_32               card_id() { return card_id_; }
  
  // name
  void                  set_card_name(std::string& name) {
    card_name_.clear();
    card_name_ = name;
  }
  std::string           card_name() { return card_name_; }
  
  // growth type
  void                  set_growth_type(eCardGrowthType type) {
    growth_type_ = type;
  }
  eCardGrowthType       growth_type() { return growth_type_; }

  // rarity stars count
  void                  set_rarity_level(uint_8 rarity) {
    rarity_level_ = rarity;
  }
  uint_8                rarity_level() { return rarity_level_; }
  
  // housing space cost
  void                  set_housing_cost(uint_16 cost) {
    housing_cost_ = cost;
  }
  uint_16               housing_cost() { return housing_cost_; }
  
  // race type for all characters & monsters
  void                  set_gender_type(eUnitRaceType type) {
    gender_type_ = type;
  }
  eUnitRaceType         gender_type() { return gender_type_; }
  
  // career type
  void                  set_career(eCareerType type) { career_ = type; }
  eCareerType           career() { return career_; }
  
  // motion type : for AI state controll
  void                  set_motion_type(uint_8 motion_type) {
    motion_type_ = motion_type;
  }
  uint_8                motion_type() { return motion_type_; }
  
  // attack type
  void                  set_attack_type(eAttackType type) {
    attack_type_ = type;
  }
  eAttackType           attack_type() { return attack_type_; }
  
  // break level upon : one break will uprisk the level up limit
  void                  set_break_count(uint_8 break_count) {
    break_count_ = break_count;
  }
  uint_8                break_count() { return break_count_; }
  
  // max level means the level up limit value after all break growth completed
//  void                  set_max_level(uint_8 level) { max_level_ = level; }
//  uint_8                max_level() { return max_level_; }
  
  // the init health point value
  void                  set_init_hp(int hp ) { init_hp_ = hp; }
  int                   init_hp() { return init_hp_; }
  
  // the init attack point value : should be divided by 100
  void                  set_attack_damage(int damage) { attack_damage_ = damage; }
  int                   attack_damage() { return attack_damage_; }
  
  // name of ability for this character
  void                  set_skill_name(std::string name) {
    skill_name_.clear();
    skill_name_ = name;
  }
  std::string           skill_name() {
    return skill_name_;
  }
  
  // discription text of ability for this character
  void                  set_skill_text(std::string text) {
    skill_text_.clear();
    skill_text_ = text;
  }
  std::string           skill_text() { return skill_text_; }
  
  // paramters of ability for this character
  void                  set_skill_param1(float skill_param1) {
    skill_param1_ = skill_param1;
  }
  float                 skill_param1() {
    return skill_param1_;
  }
  void                  set_skill_param2(float skill_param2) {
    skill_param2_ = skill_param2;
  }
  float                 skill_param2() {
    return skill_param2_;
  }
  void                  set_skill_param3(float skill_param3) {
    skill_param3_ = skill_param3;
  }
  float                 skill_param3() {
    return skill_param3_;
  }
  
  // skill type flag : mark the skill effect type
  void                  set_skill_type_flag(uint_32 flag) {
    skill_type_flag_ = flag;
  }
  uint_32               skill_type_flag() {
    return skill_type_flag_;
  }
  
  // attack speed
  void                  set_attack_speed(float speed) {
    attack_speed_ = speed;
  }
  float                 attack_speed() {
    return attack_speed_;
  }
  
  // move speed : measured by the length of grid in map
  void                  set_move_speed(float speed) {
    move_speed_ = speed;
  }
  float                 move_speed() {
    return move_speed_;
  }
  
  // ove speed of the bullet shot out by this character : measured by the length of grid in map
  void                  set_bullet_fly_speed(float speed) {
    bullet_fly_speed_ = speed;
  }
  float                 bullet_fly_speed() {
    return bullet_fly_speed_;
  }
  
  // attack flag
  void                  set_attack_flag(uint_32 flag) {
    attack_flag_ = flag;
  }
  uint_32               attack_flag() {
    return attack_flag_;
  }
  
  // weak flag :
  void                  set_weak_flag(uint_32 flag) {
    weak_flag_ = flag;
  }
  uint_32               weak_flag() {
    return weak_flag_;
  }
  
  // defense bonus :
  void                  set_defense_bonus(float defense_bonus) {
    defense_bonus_ = defense_bonus;
  }
  float                 defense_bonus() {
    return defense_bonus_;
  }
  
  // defense of physics damage : used as multiple
  void                  set_defense_physics_damage(float def_phy_damage) {
    defense_physics_damage_ = def_phy_damage;
  }
  float                 defense_physics_damage() {
    return defense_physics_damage_;
  }
  
  // defense of migic damage : used as multiple
  void                  set_defense_magic_damage(float def_mag_damage) {
    defense_magic_damage_ = def_mag_damage;
  }
  float                 defense_magic_damage() {
    return defense_magic_damage_;
  }
  
  // critical properbilty : used as multiple
  void                  set_critical(float critical) {
    critical_ = critical;
  }
  float                 critical() {
    return  critical_;
  }
  
  // guard type
  void                  set_guard_type(uint_32 guard_type) {
    guard_type_ = guard_type;
  }
  uint_32               guard_type() {
    return guard_type_;
  }
  
  // attack range : measured by the length of grid in map
  void                  set_attack_range(float range) {
    attack_range_ = range;
  }
  float                 attack_range() {
    return attack_range_;
  }
  
  // body range : measured by the length of grid in map
  void                  set_body_range(float range) {
    body_range_ = range;
  }
  float                 body_range() {
    return body_range_;
  }
  
  // scale of sprite node for this card : some cards use one same .PNG with different scale
  void                  set_model_scale(float scale) {
    model_scale_ = scale;
  }
  float                 model_scale() {
    return model_scale_;
  }
  
  // effect id
  void                  set_effect_id(uint_32 e_id) {
    effect_id_ = e_id;
  }
  uint_32               effect_id() {
    return effect_id_;
  }
  
  //  sound effect name
  void                  set_sound_effect_name(std::string name) {
    sound_effect_name_.clear();
    sound_effect_name_ = name;
  }
  std::string           sound_effect_name() {
    return sound_effect_name_;
  }
  // first appearance quest id
  void                  set_first_quest_id(uint_16 f_quest_id) {
    first_quest_id_ = f_quest_id;
  }
  uint_16               first_quest_id() {
    return first_quest_id_;
  }
  
  // first appearance scene id
  void                  set_first_scene_id(uint_8 f_scene_id) {
    first_scene_id_ = f_scene_id;
  }
  uint_8                first_scene_id() {
    return first_scene_id_;
  }
  
  // first appearance quest meet character id
  void                  set_first_meet_card_id(uint_32 f_card_id) {
    first_meet_card_id_ = f_card_id;
  }
  uint_32               first_meet_card_id() {
    return first_meet_card_id_;
  }
  
  // meet dialog
  void                  set_meet_dialog(std::string dialog) {
    meet_dialog_.clear();
    meet_dialog_ = dialog;
  }
  std::string           meet_dialog() {
    return meet_dialog_;
  }
  
  // dispalyed quest id
  void                  set_displayed_quest_id(uint_16 d_quest_id) {
    displayed_quest_id_ = d_quest_id;
  }
  uint_16               displayed_quest_id() {
    return displayed_quest_id_;
  }
  
  // is enemy flag
  void set_is_enemy(bool is_enemy) { is_enemy_ = is_enemy; }
  bool                  is_enemy() { return is_enemy_; }
  
  // skill ids array
  void set_skill_ids(const std::vector<uint_32>& ids) {
    CCAssert(ids.size() == SKILL_PARAMTERS_COUNT, "");
    std::vector<uint_32>::const_iterator it = ids.begin();
    for (int i = 0; i<SKILL_PARAMTERS_COUNT; ++i, ++it) {
      skill_ids_[i] = (*it);
    }
  }
  void get_skill_ids(std::vector<uint_32>& ids) {
    ids.clear();
    for (int i = 0; i<SKILL_PARAMTERS_COUNT; ++i) {
      ids.push_back(skill_ids_[i]);
    }
  }
  
  // skill cost skill point count : 1 / 2 / 3
  void                  set_release_cost_of_skill_count(uint_8 skill_cost) {
    release_cost_of_skill_count_ = skill_cost;
  }
  uint_8                release_cost_of_skill_count() {
    return release_cost_of_skill_count_;
  }
  
private: // card information
  // id
  uint_32               card_id_;
  // name 
  std::string           card_name_;
  // growth type
  eCardGrowthType       growth_type_;
  // rarity stars count
  uint_8                rarity_level_;
  // housing space cost
  uint_16               housing_cost_;
  // race type for all characters & monsters
  eUnitRaceType         gender_type_;
  // career type 
  eCareerType           career_;
  // motion type : for AI state controll
  uint_8                motion_type_;
  // attack type
  eAttackType           attack_type_;
  // break level upon : one break will uprisk the level up limit
  uint_8                break_count_;
  // max level means the level up limit value after all break growth completed  
//  uint_8                max_level_;
  // the init health point value
  int                   init_hp_;
  // the init attack point value : should be divided by 100 
  int                   attack_damage_;
  // name of ability for this character
  std::string           skill_name_;
  // discription text of ability for this character
  std::string           skill_text_;
  // paramters of ability for this character
  float                 skill_param1_;
  float                 skill_param2_;
  float                 skill_param3_;
  // skill type flag : mark the skill effect type
  uint_32               skill_type_flag_;
  // attack speed  
  float                 attack_speed_;
  // move speed : measured by the length of grid in map
  float                 move_speed_;
  // ove speed of the bullet shot out by this character : measured by the length of grid in map
  float                 bullet_fly_speed_;
  // attack flag 
  uint_32               attack_flag_;
  // weak flag :
  uint_32               weak_flag_;
  // defense bonus : 
  float                 defense_bonus_;
  // defense of physics damage : used as multiple
  float                 defense_physics_damage_;
  // defense of migic damage : used as multiple
  float                 defense_magic_damage_;
  // critical properbilty : used as multiple
  float                 critical_;
  // guard type
  uint_32               guard_type_;
  // attack range : measured by the length of grid in map
  float                 attack_range_;
  // body range : measured by the length of grid in map
  float                 body_range_;
  // scale of sprite node for this card : some cards use one same .PNG with different scale
  float                 model_scale_;
//  // id of motion : for 3D animation only; usless here.
//  uint_16               motion_id_;
  // effect id
  uint_32               effect_id_;
  //  sound effect name
  std::string           sound_effect_name_;
  /* description of sound effect 
  "illustrator": "HACCAN",
  "voice_artist"
  "sptext"
   */
  // first appearance quest id
  uint_16               first_quest_id_;
  // first appearance scene id
  uint_8                first_scene_id_;
  // first appearance quest meet character id
  uint_32               first_meet_card_id_;
  // meet dialog
  std::string           meet_dialog_;
  // dispalyed quest id
  uint_16               displayed_quest_id_;
  // is enemy flag
  bool                  is_enemy_;
  /* the meet type : is enemy or not 
  "chara_type": 0,
   */
  // skill ids array
  uint_32               skill_ids_[SKILL_PARAMTERS_COUNT];
  // skill cost skill point count : 1 / 2 / 3
  uint_8                release_cost_of_skill_count_;
  
};

} // namespace army
} // namespace taomee

#endif  // ChainChronicle_card_unit_h
