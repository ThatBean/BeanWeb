//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  monster.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/summon.h"

#include "game/battle/battle_controller.h"
#include "game/game_manager/data_manager.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/view/player_box.h"
#include "engine/ui_factory/ui_factory.h"

namespace taomee {
namespace army {

Summon::Summon(battle::BattleHub* owner, uint_32 global_id)
	: Monster(owner, global_id)
	, summoner_id_(army::kUnexistTargetId)
{
	move_object_type_ = army::kMoveObjectType_Summon;
}

Summon::~Summon()
{

}

bool Summon::Update(float delta)
{
	return MoveObject::Update(delta);
}

} // army
} // taomee
