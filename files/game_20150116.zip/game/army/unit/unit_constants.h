//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  unit_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  3:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_unit_constants_h
#define ChainChronicle_unit_constants_h

#include "engine/base/basictypes.h"

namespace taomee {
namespace army {

#define SKILL_PARAMTERS_COUNT 4
 
const uint_8  kMaxRarityCount   = 5;
const uint_8  kMaxPassiveSkillsCount    = 3;
const uint_8  kMaxCharacterLevel = 80;

enum eCardGrowthType {
  kCardGrowthTypeUnkown    =  -1,
  kCardGrowthTypePremature =   0,
  kCardGrowthTypeNormal    =   1,
  kCardGrowthTypeProfound  =   2,
  kCardGrowthTypeMax,
};

enum eUnitRaceType {
  kUnitRaceTypeUnkown      = -1,
  kUnitRaceTypeMax,
};

enum eCareerType {
  kCareerTypeUnkown        = -1,
  //0 սʿ
  kCareerTypeWarrior       = 0,
  //1 ������
  kCareerTypeArcher        = 1,
  //2 ��ʦ
  kCareerTypeWizard        = 2,
  //3 ɮ��
  kCareerTypeMonk          = 3,
  //4 ��ʿ
  kCareerTypeKnight        = 4,
  kCareerTypeMax,
};

enum eAttackType {
  kAttackTypeUnkown        = 0,
  kAttackTypeAttack        = 1,
  kAttackTypeShot          = 2,
  kAttackTypeHeal          = 3,
  kAttackTypeMax,
};
  
enum eGender
{
  kGenderNone       = -1,
  kGenderCard       = 0,
  kGenderHuman      = 1,
  kGenderSkeleton   = 2,
  kGenderSpecter    = 3,  // ghost with Invisbility ability
  kGenderGoblin     = 4,
  kGenderZombie     = 5,
  kGenderOrcishHorde= 6,
  kGenderDragon     = 7,
  kGenderGhost      = 8,  // other ghost
  kGendermax = 12,
};
  
enum eElementProperty
{
  kElementPropertyNone             = 0,
  kElementPropertyFire             = 1,
  kElementPropertyIce              = 2,
};

const std::string kBuffEffect_BloodHit = "cain_buff_blood_hit";//	��ѪDot����Ѫ����
const std::string kBuffEffect_BloodsuckBlast = "cain_buff_bloodsuck_blast";//	������Ѫ
const std::string kBuffEffect_Deadly_Last = "cain_buff_deadly_last";//	��������
// const std::string kBuffEffect_ = "cain_buff_deadly_start";//	������ʼ
// const std::string kBuffEffect_ = "cain_buff_ice_hit";//	�����Ա���������Dot
// const std::string kBuffEffect_ = "cain_buff_klight_hit";//	���������
const std::string kBuffEffect_Poison_Last = "cain_buff_poison_last";//	������
const std::string kBuffEffect_Poison_Start = "cain_buff_poison_start";//	����ʼ
// const std::string kBuffEffect_ = "cain_buff_sacrifice_start";//	�Բп�ʼ
// const std::string kBuffEffect_ = "cain_buff_sacrifice_last";//	�Բг���
// const std::string kBuffEffect_ = "cain_buff_sacrifice_blast";//	�Բв�������
 //const std::string kBuffEffect_ShiledStart = "cain_buff_shiled_start";//	�������նܿ�ʼ
const std::string kBuffEffect_Shiled_Last = "cain_buff_shiled_last";//	�������նܳ���
// const std::string kBuffEffect_ = "cain_buff_fire_hit";//	�����Ա���������Dot
// const std::string kBuffEffect_ = "cain_buff_wind_hit";//	�����Ա���
// const std::string kBuffEffect_ = "cain_buff_strong_last";//	���ӹ�������
// const std::string kBuffEffect_ = "cain_buff_thick_last";//	���ӹ�������
// const std::string kBuffEffect_ = "cain_buff_dispel_blast";//	��ɢ��Ч
// const std::string kBuffEffect_ = "cain_buff_bind_start";//	������ʼ
// const std::string kBuffEffect_ = "cain_buff_bind_last";//	��������
// const std::string kBuffEffect_ = "cain_buff_magicban_start";//	ħ�⿪ʼ
// const std::string kBuffEffect_ = "cain_buff_magicban_last";//	ħ�����
// const std::string kBuffEffect_ = "cain_buff_excited_start";//	������ʼ
// const std::string kBuffEffect_ = "cain_buff_excited_last";//	��������
const std::string kBuffEffect_BoundBlast = "cain_buff_bound_blast";//	�˺���������
// const std::string kBuffEffect_ = "cain_buff_magbrk_start";//	�Ʒ�����ʼ
// const std::string kBuffEffect_ = "cain_buff_magbrk_last";//	�Ʒ�������
// const std::string kBuffEffect_ = "cain_buff_phybrk_start";//	�������ʼ
// const std::string kBuffEffect_ = "cain_buff_phybrk_last";//	���������
// const std::string kBuffEffect_ = "cain_buff_pshiled_start";//	�������նܿ�ʼ
// const std::string kBuffEffect_ = "cain_buff_pshiled_last";//	�������նܳ���
const std::string kBuffEffect_Slay_Hit = "cain_buff_killing_hit";//	նɱЧ������
// const std::string kBuffEffect_ = "cain_buff_magresist_blast";//	�����ֿ�����
// const std::string kBuffEffect_ = "cain_buff_phyresist_blast";//	�����ֿ�����



// �����������
const uint_32 kMaxActiveCharactersCount  = 5;

enum
{
	//��ҽ�ɫ��ʼ
	kCharaterObject_StartId = 0,
	kCharaterObject_EndId = 5,
	//������ʼid
	kMonsterObject_StartId = 10,
	kMonsterObject_EndId = 100010,
	//pvp��ҽ�ɫ��ʼ
	kPvPCharaterObject_StartId,
	kPvPCharaterObject_EndId = kPvPCharaterObject_StartId + 7,
	//��ҽ�ɫ�л�������ʼ
	kCharaterSummonObject_StartId,
	kCharaterSummonObject_EndId = kCharaterSummonObject_StartId + 10000,
	//����л�������ʼ
	kMonsterSummonObject_StartId,
	kMonsterSummonObject_EndId = kCharaterSummonObject_StartId + 10000,


	//��ҽ�ɫ������
	kCharaterObject_Count = kCharaterObject_EndId - kCharaterObject_StartId,
	//pvp��ҽ�ɫ������
	kPvPCharaterObject_Count = kPvPCharaterObject_EndId - kPvPCharaterObject_StartId,
	//����������
	kMonsterObject_Count = kMonsterObject_EndId - kMonsterObject_StartId,
	//��ҽ�ɫ�л�����������
	kCharaterSummonObject_Count = kCharaterSummonObject_StartId - kCharaterSummonObject_EndId,
	//����л�����������
	kMonsterSummonObject_Count = kMonsterSummonObject_StartId - kMonsterSummonObject_EndId,
};



enum kMoveObjectType
{
	kMoveObjectType_Unknown = -1,
	kMoveObjectType_Character,
	kMoveObjectType_Monster,
	kMoveObjectType_Summon,
	kMoveObjectType_Count,
};





const uint_32 kSmallestUpdatePosDistance  = 5;
  
// muptiple for battle
const float   kDamageToAttackRadio        = 0.1f;

//����Ч����Թ����ı���
const float   kHealToDamageRadio          = 0.5f;
const float   kAttackBonusToDamageRadio   = 10.0f;
const float   kAttackBonusToHealRadio     = 3.34f;

enum {
  kUnexistSequenceId       = -1,
  kUnexistCardId           = -1,
  kUnexistTargetId         = -1,
};

const std::string kUnitAnimationIdle			= "idle";
const std::string kUnitAnimationIdle_2			= "idle02";
const std::string kUnitAnimationWalk			= "walk";
const std::string kUnitAnimationCure			= "cure";
const std::string kUnitAnimationAttack			= "attack";
const std::string kUnitAnimationDead			= "dead";
const std::string kUnitAnimationWeak			= "weak";
const std::string kUnitAnimationWeakWalk		= "weak_walk";
const std::string kUnitAnimationDown			= "down";
const std::string kUnitAnimationUp				= "up";
const std::string kUnitAnimationCritAttack		= "crit_attack";
const std::string kUnitAnimationPierceAttack	= "pierce_attack";
const std::string kUnitAnimationDead_2			= "dead_2"; // �Ա�
  
enum eAttackElementsPropertyPriority
{
  kAEPPPassiveAbilitySet    = 0,
//  kAEPPWeaponSet            = 1, NOTE: weapon skill id set after ability by code logic
  kAEPPBuffSet              = 1,
  kAEPPMax,
};
  
const int kHitPointBackFlag    = 0xbac7;
const int kHitPointBarFlag     = 0xbac8;
const int kPlayerBoxTag        = 0xbac9;
const int kAimMarkTag          = 0xbad0; 

const std::string kStatusEffectTagDizzy		= "dizzy";
const std::string kStatusEffectTagFreeze		= "freeze";
const std::string kStatusEffectTagPoison		= "poison";
const std::string kStatusEffectTagFireDot		= "fire_hit";// fire dot
const std::string kStatusEffectTagFreezeDot	= "freeze_break";//freeze dot
const std::string kStatusEffectTagSlow			= "slow";
const std::string kStatusEffectTagShieldBroken	= "lowdefence";
const std::string kStatusEffectTagBlind		= "blind";
const std::string kStatusEffectTagFreezeBreak	= "freeze_break";
const std::string kStatusEffectTagShield		= "shield";
const std::string kStatusEffectTagHeal			= "heal";
const std::string kStatusEffectTagBuffplus		= "buffplus";
const std::string kStatusEffectTagResist		= "resist";
const std::string kStatusEffectTagShieldDefense = "shielddefense";
const std::string kStatusEffectTagThornsShield	= "shielddefense";// thorns shield

const uint_8  kMaxBreakTimes   = 4;

const int_16  kRulelessLevelEnd = 4;
const float   kMonsterIncreasingMultiple = 1.042;

const uint_32 kNormalHitSkillId = 1;

const int kMoveObjectTag = 888;
// the min distance between two unit
#define UNIT_MIN_DISTANCE 70
// the min quadratic sum between two unit 
#define UNIT_MIN_DISTANCE_QS 4900
  
std::string GetMoveObjectNameByCardId(uint_32 card_id);
char* GetMoveObjectNameCStrByCardId(uint_32 card_id);
std::string GetMoveObjectNameCNByCardId(uint_32 card_id);
  
eGender GetMoveObjectGenderByCardId(uint_32 card_id);
  
eCardGrowthType GetMoveObjectGrowthTypeByCardId(uint_32 card_id);

uint_8 GetMoveObjectRarityCountByCardId(uint_32 card_id);
  
eCareerType GetMoveObjectCareerByCardId(uint_32 card_id);
  
uint_8      GetMoveObjectSkillCostNumByCardId(uint_32 card_id);
  
uint_32     GetMoveObjectSkillIdByCardId(uint_32 card_id);
  
float       GetMoveObjectCriticalByCardId(uint_32 card_id);

float       GetMoveObjectShotSpeedMultipleByCardId( uint_32 card_id );

eAttackType GetMoveObjectAttackTypeByCareerType(eCareerType career);
eAttackType GetMoveObjectAttackTypeByCardId(uint_32 card_id);
  
bool        AreTwoMoveObjectsInTheSameForceHub(uint_32 unit_id1, uint_32 unit_id2);

int GetMoveObjectTroopsType(uint_32 unit_id);

int getTagByName(const std::string& name);
  
} // army
} // taomee

#endif // ChainChronicle_unit_constants_h

