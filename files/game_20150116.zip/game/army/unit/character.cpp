﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  character.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/character.h"

#include <cstdlib>

#include "game/battle/battle_controller.h"
#include "game/battle/battle_hub.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/view/player_box.h"
#include "game/user_data/character_info.h"
#include "game/game_manager/data_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "game/battle/own_hub.h"
#include "engine/animation/projectile_animation.h"
#include "engine/particle/particle_manager.h"
#include "engine/particle/particle_group.h"
#include "engine/ui_factory/ui_factory.h"

namespace taomee {
namespace army {
 
Character::Character(battle::BattleHub* owner, uint_32 global_id)
  : MoveObject(owner, global_id),
    is_friend_(false),
    is_levelup_(false),
    sequence_id_(data::kUnexistCharacterId),
    added_xp_percent_(0),
    current_xp_percent_(0)
{
  move_object_type_ = army::kMoveObjectType_Character;
}

Character::~Character()
{
  this->ClearAllProperties();
  character_info_ = NULL;
}
  
bool Character::Update(float delta)
{
  MoveObject::Update(delta);
  return true;
}
  
void Character::ClearAllProperties()
{
  MoveObject::ClearAllProperties();
  is_friend_        = false;
  is_levelup_       = false;
  sequence_id_      = kUnexistTargetId;
  
  added_xp_percent_ = 0;
  current_xp_percent_ = 0;
}
  
void Character::CreatePassiveAbilities(bool isBackStageNeed /* default = false */)
{
  if (isBackStageNeed)
  {
    this->initSkillIds();
  }
  MoveObject::CreatePassiveAbilities(isBackStageNeed);
}
  
bool Character::InitMoveObjectAsPvpInfo(taomee::battle::PvpCharacterCreatationInfo& data)
{
  if (false == MoveObject::InitMoveObjectDataFromFile(true))
  {
    return false;
  }

  this->set_base_total_health_point(data.hp_ * 3);
  this->set_currnet_health_point(data.hp_ * 3);

  this->set_basic_physics_attack_(data.physics_attack_);
  this->set_basic_magic_attack_(data.magic_attack_);

  this->set_basic_dodge(data.dodge);
  this->set_basic_hit_rate(data.hit_rate);

  this->set_final_damage(data.fdamage_);

  this->set_final_defence(data.fundamage_);
  this->set_basic_physics_defense(data.pdef_);
  this->set_basic_magic_defense(data.mdef_);

  return true;
}

uint_8 Character::getSkillLevel(uint_32 skill_id)
{
	return character_info_->getSkillLvBySkillId( skill_id );
}

bool Character::InitMoveObjectDataFromFile(bool needInitBattleData /* = true */)
{
  if (false == MoveObject::InitMoveObjectDataFromFile(needInitBattleData))
  {
    return false;
  }
  
  BornCalculator* calculator = DataManager::GetInstance().calculator();
  
  float hp = 0;
  float phy_attack = 0;
  float mag_attack = 0;
  float fD = 0;
  float fDef = 0;
  float crtical = 0;
  float pDef = 0;
  float mDef = 0;
  float hit_rate = 0;
  float dodge = 0;

  // calculation for level / rarity / break times related data
  hp = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeHp);
 
  phy_attack = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypePhyAtk);
  
  mag_attack = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeMagAtk);

  hit_rate = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeHitRate);

  dodge = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeDodgeRate);

  //最终伤害-装备提供
  fD = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeFDamage);
  
  //最终免伤-装备提供
  fDef = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeFUnDamage);
  
  //暴击-TODO
  crtical = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeCritRate);
  
  //物理防御
  pDef = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypePDef);
  pDef += basic_physics_defense_;

  //法防
  mDef = calculator->PropertyCalculatorForCharacterByInfoAndType(character_info_, kAttrTypeMDef);
  mDef += basic_magic_defense_;
    
  this->set_base_total_health_point(hp);
  this->set_currnet_health_point(hp);

  this->set_basic_physics_attack_(phy_attack);
  this->set_basic_magic_attack_(mag_attack);

  this->set_basic_hit_rate(hit_rate);
  this->set_basic_dodge(dodge);

  this->set_final_damage(fD);

  this->set_final_defence(fDef);
  this->set_basic_physics_defense(pDef);
  this->set_basic_magic_defense(mDef);

  this->set_level(character_info_->level());

  return true;
}

void Character::InitXpData()
{
  if (false == MoveObject::InitMoveObjectDataFromFile(false))
  {
    return ;
  }
  // set current percent
  assert(character_info_->xp()<=character_info_->required_xp_to_next_level());
  current_xp_percent_ = 100 * character_info_->xp() /
                              character_info_->required_xp_to_next_level();
}
  
uint_8 Character::ShowXpBarForXpReward(uint_32 addedXp)
{
  // show bar first
  UILayer* ui_layer = dynamic_cast<UILayer*>(anima_node_->getChildByTag(kHitPointBarFlag));
  if (!ui_layer)
  {
    return 0;
  }
  ui_layer->setVisible(true);
  
  //calculate added percent
  uint_8  level = character_info_->level();
  int org_xp = character_info_->xp();


  int org_xp_percent = 100 * character_info_->xp() / character_info_->required_xp_to_next_level();

  uint_8  actor_level = DataManager::GetInstance().user_info()->rank();

  // add xp to character info
  character_info_->AddXp(addedXp);
  
  uint_8 new_level = character_info_->level();
  int new_xp = character_info_->xp();


  int new_xp_percent = 100 * character_info_->xp() / character_info_->required_xp_to_next_level();

  assert(new_level >= level);
  assert(new_xp_percent < 100);

  added_xp_percent_ = (new_level - level) * 100 + new_xp_percent - current_xp_percent_;
  //added_xp_percent_ = (new_level - level) * 100.0f + 100.0f * (new_xp - org_xp) / character_info_->required_xp_to_next_level();

  if (new_level == actor_level)
  {
    return actor_level;
  }
  else if (new_level > level)
  {
	  CCNode* pNode = CCNode::create();

	  cocos2d::CCSprite* sprite = cocos2d::CCSprite::create();
	  std::string particle_name = "fx_level";
	  ParticleGroup* particle_group = ParticleManager::GetInstance().\
		  GetParticleGroup(particle_name);
	  if (particle_group != NULL)
	  {
		  ParticleManager::GetInstance().TriggerParticle(particle_group,
			  sprite,
			  cocos2d::CCPointZero,
			  -1);
	  }
	  sprite->setPosition(ccp(0, 20 - anima_node_->GetBonePositionInSkeleton(kBoneTypeHealthBar).y));
	  sprite->setAnchorPoint(ccp(0.5f,0));
	  pNode->addChild(sprite);
    CCSprite* pSprite = CCSprite::create("ui/agoui_local_text/agoui_levelup_2.pvr.ccz");
	  pSprite->setPosition(ccp(0, 10));
	  pSprite->setAnchorPoint(ccp(0.5f,0));
	  CCSequence * seq = CCSequence::create(
		  CCSpawn::create(
		  CCFadeIn::create(0.1f),
		  CCScaleTo::create(0.1f, pSprite->getScaleX()*2.5f,
		  pSprite->getScaleY()*2.5),
		  NULL),
		  CCEaseOut::create(
		  CCScaleTo::create(0.1f, pSprite->getScaleX(),
		  pSprite->getScaleY()), 0.5f),
		  CCDelayTime::create(1.0f),
		  NULL);
	  pSprite->runAction(seq);
	  pNode->addChild(pSprite);
	  ui_layer->addChild(pNode);
	  //#####################################################################

    return new_level;
  }
  return 0;
}
  
void Character::UpdateXpBar(float delta)
{
  if (!health_point_)
  {
    return;
  }
  if (added_xp_percent_>0)
  {
    current_xp_percent_ %= 100;

    current_xp_percent_ ++;
    added_xp_percent_ --;
    
    health_point_->setPercent(current_xp_percent_);
  }
}
  
void Character::freshZOrder()
{
  cocos2d::CCPoint curPos = anima_node_->getPosition();
  // only update position / tile index / scale / z order / obj reference for one
  // moveObject after it moved more then 5 pixel yet on the battle tiled map
  if ( fabsf(pos_in_last_update_.x-curPos.x)+
       fabsf(pos_in_last_update_.y-curPos.y) > kSmallestUpdatePosDistance)
  {
    pos_in_last_update_ = curPos;
    anima_node_->setZOrder(battle::GetZorderByPosition(anima_node_->getPosition(),
                                                       this->move_object_id()));
    anima_node_->setScale(battle::GetScaleByPosition(anima_node_->getPosition()));
    int_8 originalTileIdx = tile_index_;
    tile_index_ = battle::GetTileIndexByCurrentPointPosition(curPos);
    if (originalTileIdx != tile_index_) {
      this->owner_hub()->updateAttackerReference(originalTileIdx, this);
      if (tile_index_ == garrison_tile_index_ && (ai_state_==ai::kAIStateGuard ||
                                                  ai_state_==ai::KAIStateCure))
      {
        battle::BattleController::GetInstance().CharacterBackToGarrisonTargetTile(
                                                 move_object_id(), tile_index());
      }
    }
  }
}
  
void Character::addUnitAniamtion()
{
  // add common elements in base class
  MoveObject::addUnitAniamtion();

  anima_node_->GetArmatureNode()->setTag(move_object_id_);
  CCNode* bind_node = this->owner_hub()->battle_view()->GetLayerBindNode(battle::kBottomLayer,move_object_id_);
  // add player box
  army::eCareerType type = GetCareerType();
  battle::PlayerBoxColor color = static_cast<battle::PlayerBoxColor>(type);
  battle::PlayerBox* player_box = battle::PlayerBox::Create(color);
  player_box->setPosition(ccp(0, battle::kSelectedBorderOffsetHight));
  bind_node->addChild(player_box, -10, kPlayerBoxTag);
  UILayer* ui_layer = dynamic_cast<UILayer*>(anima_node_->getChildByTag(kHitPointBarFlag));
  assert(ui_layer);
  //使用json文件给Layer层添加CocoStudio生成的控件
  UIWidget* ui_widget = UIFactory::createWidgetFromFile("ui/agoui_player_hp.json");
  ui_widget->setScale(0.8f);
  ui_layer->addWidget(ui_widget);
  if (!owner_hub()->IsRightSideHub())
  {
    UILoadingBar* progress_hp = dynamic_cast<UILoadingBar*>(ui_layer->getWidgetByName("progress_hp"));
    progress_hp->loadTexture("agoui_progress_bar_yellow.png", UI_TEX_TYPE_PLIST);
  }

  UILabelBMFont* friend_tips = dynamic_cast<UILabelBMFont*>(ui_layer->getWidgetByName("Label_Friend"));
  friend_tips->setVisible(false);
  if (!DataManager::GetInstance().user_info()->IsInTeamBySeqID(0,this->sequence_id())) 
  {
    data::FriendInfo* friend_info = FriendController::GetInstance().GetHelperByLeaderSeqid(this->sequence_id());
    if (friend_info) 
    {
      friend_tips->setVisible(true);
      if (friend_info->is_helper()) 
      {
        char* friend_text = LuaTinkerManager::GetInstance()\
          .GetLuaText<char*>( "player_hp_guest");
        friend_tips->setText(friend_text);
      }
      else
      {
        char* friend_text = LuaTinkerManager::GetInstance()\
          .GetLuaText<char*>( "player_hp_friend");
        friend_tips->setText(friend_text);
      }
    }
  }  

  this->initHealthBarPercent();
}
  
// init the animation special for winning characters
void Character::addWinningAnimation()
{
  assert(move_object_id_<(kMonsterObject_EndId));
  std::string cardName = GetMoveObjectNameByCardId(card_id_);
  anima_node_->Init(cardName.c_str(), cardName.c_str());

  anima_node_->AddShadow();

  // do not show xp bar for friend
  if (is_friend_)
  {
    return;
  }
  // add xp loading bar
  //创建一个UILayer层
  UILayer* ui_layer = UILayer::create();
  //开启刷新函数
  ui_layer->scheduleUpdate();
  ui_layer->setPosition(anima_node_->GetBonePositionInSkeleton(kBoneTypeHealthBar));
  //将UILayer层加入到当前的场景
  anima_node_->addChild(ui_layer, kHitPointBarFlag, kHitPointBarFlag);
  ui_layer->addWidget(UIFactory::createWidgetFromFile("ui/agoui_monster_hp.json"));
  ui_layer->setVisible(false);
  // init xp bar percent
  this->initXpBarPercent();
}
  
// init skill ids
void Character::initSkillIds()
{
  passive_skill_ids_.clear(); 
  int addedId = character_card_data_->GetSkillId(kSkillPassive1);
  if (addedId>0) 
  { 
    bool  is_checkpoint_complete = true;
    if ( character_card_data_->GetUnlockQuest1() > 0 )
    {
      is_checkpoint_complete = DataManager::GetInstance().user_info()->QueryCheckPointPassSucess(character_card_data_->GetUnlockQuest1());
    }
    
    if (is_checkpoint_complete)
    {
      passive_skill_ids_.push_back(addedId);
    }
  }
  addedId = character_card_data_->GetSkillId(kSkillPassive2);

  if (addedId>0)
  { 
    bool  is_checkpoint_complete = true;
    if ( character_card_data_->GetUnlockQuest2() > 0 )
    {
      is_checkpoint_complete = DataManager::GetInstance().user_info()->QueryCheckPointPassSucess(character_card_data_->GetUnlockQuest2());
    }

    if (is_checkpoint_complete)
    {
      passive_skill_ids_.push_back(addedId);
    }
  }
  addedId = character_card_data_->GetSkillId(kSkillWeapon);
  if (addedId>0)
  {
    passive_skill_ids_.push_back(addedId);
  }
}
  
// init xp bar percent
void Character::initXpBarPercent()
{
  UILayer* ui_layer = dynamic_cast<UILayer*>(anima_node_->getChildByTag(kHitPointBarFlag));
  assert(ui_layer);
  
  health_point_ = dynamic_cast<UILoadingBar*>(ui_layer->getWidgetByName("progress_hp"));
  dynamic_cast<UILoadingBar*>(ui_layer->getWidgetByName("progress_bg"))->setPercent(0);
  assert(current_xp_percent_>=0 && current_xp_percent_<=100);
  health_point_->setPercent(current_xp_percent_);
  health_point_->retain();
}
  
} // army
} // taomee  
