//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  character.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/move_object.h"
#include "engine/base/basictypes.h"

#ifndef ChainChronicle_character_h
#define ChainChronicle_character_h

namespace taomee {
  
namespace data
{
  class CharacterInfo;
}

namespace battle
{
  class PvpCharacterCreatationInfo;
}
namespace army {
  
class Character : public MoveObject
{
public:
  Character(battle::BattleHub* owner, uint_32 global_id);
  virtual ~Character();
 
public:
  virtual bool Update(float delta);
  virtual void ClearAllProperties();
  
  // create passvie ability
  virtual void CreatePassiveAbilities(bool isBackStageNeed = false);
  virtual bool InitMoveObjectDataFromFile(bool needInitBattleData = true);
  virtual bool InitMoveObjectAsPvpInfo(taomee::battle::PvpCharacterCreatationInfo& data);
  
    virtual uint_8 getSkillLevel(uint_32 skill_id);
public: // getter & setter

  // mark flag for level up
  bool                is_levelup() { return is_levelup_; }
  void                set_is_levelup(bool is) { is_levelup_ = is; }
  
  // sequence id saved in server
  uint_32             sequence_id()
  {
    return sequence_id_;
  }
  void                set_sequence_id(uint_32 sId)
  {
    sequence_id_ = sId;
  }
  
  // the setted garrison tile index
  uint_16             garrison_tile_index()
  {
	  return garrison_tile_index_;
  }

  void                set_garrison_tile_index(uint_16 tile_idx)
  {
    garrison_tile_index_ = tile_idx;
  }
  
  // character info reference
  data::CharacterInfo* character_info() {
	  return character_info_;
  }
  void                set_character_info(data::CharacterInfo* infoRef)
  {
    character_info_ = infoRef;
  }
  
  bool                 is_friend() { return is_friend_; }
  void                 set_is_friend(bool isFriend) { is_friend_ = isFriend; }
public: // special for battle win
  void InitXpData();
  uint_8 ShowXpBarForXpReward(uint_32 xp);
  void UpdateXpBar(float delta);
  
protected:
  // fresh z order & scale for unit
  virtual void freshZOrder();
  // init the animation of unit by unit id & weapons ids
  virtual void addUnitAniamtion();
  // init the animation special for winning characters
  virtual void addWinningAnimation();
  // init skill ids
  virtual void initSkillIds();
  
protected:
  // init xp bar percent
  void initXpBarPercent();
  
protected:
  // mark flag for level up
  bool                is_levelup_;
  // sequence id saved in server
  uint_32             sequence_id_; 
  
  // the setted garrison tile index
  uint_16             garrison_tile_index_;
  
  // character info reference
  data::CharacterInfo*      character_info_;

private:
  bool                 is_friend_;
  int_16               added_xp_percent_;
  int_16               current_xp_percent_;
};
  
} // army
} // taomee

#endif // ChainChronicle_character_h
