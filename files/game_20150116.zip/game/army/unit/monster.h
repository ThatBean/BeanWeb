//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  monster.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit/move_object.h"

#ifndef ChainChronicle_monster_h
#define ChainChronicle_monster_h

namespace taomee {
namespace army {
  
class Monster : public MoveObject
{
public:
  Monster(battle::BattleHub* owner, uint_32 global_id);
  virtual ~Monster(); 
  
public:
  virtual bool Update(float delta);
  
  virtual bool InitMoveObjectDataFromFile(bool needInitBattleData = true);
  
  virtual void ClearAllProperties();
  
public: // getter & setter

	virtual uint_8 getSkillLevel(uint_32 skill_id);

  virtual int_32      GetWeaponId();

  // main weapon's id of this move object
  int             current_weapon_id() {
    return current_weapon_id_;
  }
  void                set_current_weapon_id(int weapon_id) {
    current_weapon_id_ = weapon_id;
  }
  
  // other weapon id for character with tow weapons
  uint_16             current_weapon_id_other() {
    return current_weapon_id_other_;
  }
  void                set_current_weapon_id_other(uint_16 weapon_id) {
    current_weapon_id_other_ = weapon_id;
  }
  
  ai::eAIStateType    intent_type() { return intent_type_; }
  void                set_intent_type(ai::eAIStateType type)
  {
    intent_type_ = type;
  }
  
  ai::eAIBornLine     born_line() { return born_line_; }
  void                set_born_line(ai::eAIBornLine line)
  {
    born_line_ = line;
  }
  
  uint_32             timestamp() { return timestamp_; }
  void                set_timestamp(uint_32 time)
  {
    timestamp_ = time;
  }
  float               des_hp_mult() { return des_hp_mult_; }
  void                set_hp_des_mult(float des_hp_mult)
  {
    des_hp_mult_ = des_hp_mult;
  }

  float               des_att_mult() { return des_att_mult_; }
  void                set_att_des_mult(float des_att_mult)
  {
    des_att_mult_ = des_att_mult;
  }
  
protected:
  // init the animation of unit by unit id & weapons ids
  virtual void addUnitAniamtion();
  
protected:

  // main weapon's id of this move object
  int                 current_weapon_id_;
  // other weapon id for character with tow weapons
  int                 current_weapon_id_other_;
  
private: // born info
  ai::eAIStateType    intent_type_;
  ai::eAIBornLine     born_line_;
  uint_32             timestamp_;
  float               des_hp_mult_;
  float               des_att_mult_;
};
  
} // army
} // taomee

#endif // ChainChronicle_monster_h
