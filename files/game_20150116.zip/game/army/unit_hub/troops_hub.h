//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  troops_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_troops_hub_h
#define ChainChronicle_troops_hub_h

#include <assert.h>
#include "engine/base/basictypes.h"
#include "game/army/unit/unit_constants.h"

namespace taomee {
  
namespace battle {
  class BattleHub;
}
  
namespace army {
  
class MoveObject;
  
class TroopsHub
{
public:
  TroopsHub( battle::BattleHub* own, int start_id, uint_32 end_id);
  virtual ~TroopsHub();

protected:
  virtual MoveObject* createObjectImpl(uint_32 id) = 0;

public:  // getter & setter
  battle::BattleHub* owner_hub()
  {
	  return owner_hub_;
  }
  
  uint_32 active_ids_count() 
  {
	  return active_moveobj_map_.size();
  }
  
  uint_32 unremove_dead_ids()
  {
	  return unremove_dead_map_.size();
  }

  const std::vector<uint_32>& active_ids();
  
  MoveObject* CreateObjectById(uint_32 id, bool is_substitution);
  MoveObject* CreateUnitBySubstitution(int id);
  

  MoveObject* GetObjectById(int id);
  
  MoveObject* GetActiveObjectByIndex(int index);

  MoveObject* GetDeadObjectByIndex(int index);

  uint_32 GetSubstitutionObjectID();
  
  uint_32 GetWeakestMoveObjectId(int_32 ignore_id = -1);

  uint_32 GetRandomMoveObjectId(int_32 ignore_id = -1);
  
  uint_8 GetActiveMoveObjectsCountByAttackType(army::eAttackType type);
  
  // temp id mark the current used one
  uint_32 GetNextActiveObjectId()
  {
	  return global_id_;
  }
  
  // get all active troops in full kMapTilesCount
  void    GetAllActiveMoveObjectsIdsListInValidTiles(std::vector<uint_32>& moveObjIds);
  // get all active troops in full screen area
  void    GetAllActiveMoveObjectsIdsListInFullScreen(std::vector<uint_32>& moveObjIds);

  // get last enemy in selected row
  // if in monster hub, get the leftmost object
  // if in owner hub, get the rightmost object
  army::MoveObject* GetLastMoveObjectInSelectedRow(int_8 row_no);

  // random one active troops in full kMapTilesCount
  uint_32 RandomOneMoveObjectsIdsListInValidTiles();
  
  void RemoveDeadMoveOjectsAfterBattleEnd();
  
public: // update for all active units : AI state changed firstly,
  // then the animation node changed follow
  bool Update(float delta);
  // insert one unit id into active ids list
  //void InsertOneUnitIdIntoActiveIdsList(uint_32 unit_id);
  // remove one unit id from active ids list
  void RemoveOneUnitIdFromActiveIdsList(uint_32 unit_id);
  // notification on target death, reset target_selection on own&enemy hub
  void NotifyTargetDestroyed(uint_32 destroyed_unit_id);
  // update for victory celebration
  void UpdateVictoryCelebration(float delta);
  // set skill play or stop
  void SetSkillPlayingStatus(bool bPlay);

  void SwitchUnitToActiveIdsList(uint_32 unit_id);
public: // for revive
  void ChangeAllActiveToIdle();
  void ClearAllMoveObjects();
  
private:
	void removeUnit(MoveObject* unit);
	void destroyUnit(MoveObject* unit);
protected:
  battle::BattleHub*  owner_hub_;
  
protected:

  // the minimum unit id in this troops hub
  uint_32             start_id_;
  uint_32             end_id_;

  uint_32             global_id_;

  typedef std::map<uint_32, MoveObject*> defMoveObjMap;
   defMoveObjMap active_moveobj_map_;
   defMoveObjMap substitution_moveobj_map_;
   defMoveObjMap unremove_dead_map_;
   defMoveObjMap dead_map_;

   std::queue<MoveObject*> idle_loop_;
protected:
  bool                skill_anima_playing_;
};
  
} // army
} // taomee

#endif // ChainChronicle_troops_hub_h
