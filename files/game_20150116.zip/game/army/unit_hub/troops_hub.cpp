//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  troops_hub.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-24
//          Time:  6:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-24        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit_hub/troops_hub.h"

#include "game/battle/battle_hub.h"
#include "game/army/unit/monster.h"
#include "game/army/unit/character.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_data.h"
#include "game/battle/battle_pvp_data.h"
#include "game/battle/battle_data_default.h"
#include "game/battle/view/battle_view.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/battle/view/battle_view_constant.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "engine/base/random_helper.h"
#include "game/game_manager/data_manager.h"

namespace taomee {
namespace army {

TroopsHub::TroopsHub(battle::BattleHub* own, int start_id, uint_32 end_id)
  : start_id_(start_id),
    end_id_(end_id),
	global_id_(start_id),
    owner_hub_(own),
    skill_anima_playing_(false)
{

}

TroopsHub::~TroopsHub()
{
	for ( defMoveObjMap::iterator iter = active_moveobj_map_.begin(); iter != active_moveobj_map_.end(); ++iter)
	{
		MoveObject* unit = iter->second;
		delete unit;
	}
	active_moveobj_map_.clear();

	for ( defMoveObjMap::iterator iter = substitution_moveobj_map_.begin(); iter != substitution_moveobj_map_.end(); ++iter)
	{
		MoveObject* unit = iter->second;
		delete unit;
	}
	substitution_moveobj_map_.clear();

	for ( defMoveObjMap::iterator iter = unremove_dead_map_.begin(); iter != unremove_dead_map_.end(); ++iter)
	{
		MoveObject* unit = iter->second;
		delete unit;
	}
	unremove_dead_map_.clear();

	for ( defMoveObjMap::iterator iter = dead_map_.begin(); iter != dead_map_.end(); ++iter)
	{
		MoveObject* unit = iter->second;
		delete unit;
	}
	dead_map_.clear();

	while ( !idle_loop_.empty() )
	{
		MoveObject* unit = idle_loop_.front();
		delete unit;
		idle_loop_.pop();
	}
}

const std::vector<uint_32>& TroopsHub::active_ids()
{ 
	static std::vector<uint_32>  active_ids_;
	active_ids_.clear();
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		//assert(unit->is_active());
		active_ids_.push_back(unit->move_object_id());
	}
	return  active_ids_;
}

MoveObject* TroopsHub::CreateObjectById(uint_32 id, bool is_substitution)
{
	if ( id < start_id_ || id >end_id_ )
	{
		assert(0);
		return NULL;
	}

	MoveObject* newObj = NULL;
	if ( idle_loop_.empty() )
	{
		newObj = createObjectImpl(id);
	}
	else
	{
		newObj = idle_loop_.front();
		idle_loop_.pop();
	}
	newObj->ClearAllProperties();
	newObj->set_move_object_id(id);

	std::pair<defMoveObjMap::iterator, bool> insertRes;
	if (is_substitution)
	{
		insertRes = substitution_moveobj_map_.insert(std::pair<uint_32, MoveObject*>(id, newObj));
	}
	else
	{
		insertRes = active_moveobj_map_.insert(std::pair<uint_32, MoveObject*>(id, newObj));
	}
	if ( false == insertRes.second )
	{
		delete newObj;
		newObj = NULL;
		assert(0);
	}

	global_id_ = id + 1;

	return newObj;
}

MoveObject* TroopsHub::CreateUnitBySubstitution(int id)
{
	MoveObject* substitution = NULL;
	defMoveObjMap::iterator iter = substitution_moveobj_map_.find(id);
	if ( iter != substitution_moveobj_map_.end() )
	{
		substitution = iter->second;
		substitution_moveobj_map_.erase(iter);
		active_moveobj_map_.insert(std::pair<uint_32, MoveObject*>(id, substitution));
	}

	return substitution;
}

MoveObject* TroopsHub::GetObjectById(int id) 
{
	defMoveObjMap::iterator iter = active_moveobj_map_.find(id);
	if ( iter != active_moveobj_map_.end())
	{
		return iter->second;
	}

	iter = substitution_moveobj_map_.find(id);
	if ( iter != substitution_moveobj_map_.end())
	{
		return iter->second;
	}

	iter = unremove_dead_map_.find(id);
	if ( iter != unremove_dead_map_.end())
	{
		return iter->second;
	}

	iter = dead_map_.find(id);
	if ( iter != dead_map_.end())
	{
		return iter->second;
	}
	
	return NULL;
}

MoveObject* TroopsHub::GetActiveObjectByIndex(int index)
{
	uint_8 idx = 0;
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		if ( idx == index )
		{
			return unit;
		}
		++idx;
	}

	return NULL;
}

MoveObject* TroopsHub::GetDeadObjectByIndex(int index)
{
	uint_8 idx = 0;
	defMoveObjMap::iterator iter = unremove_dead_map_.begin();
	for ( ; iter != unremove_dead_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		if ( idx == index )
		{
			return unit;
		}
		++idx;
	}

	return NULL;
}

uint_32 TroopsHub::GetSubstitutionObjectID()
{
	defMoveObjMap::iterator iter = substitution_moveobj_map_.begin();
	for ( ; iter != substitution_moveobj_map_.end(); ++iter )
	{
		return iter->first;
	}

	return army::kUnexistTargetId;
}

uint_8 TroopsHub::GetActiveMoveObjectsCountByAttackType(army::eAttackType type)
{
	uint_8 count = 0;
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		if ( army::GetMoveObjectAttackTypeByCardId( unit->card_id() ) == type )
		{
			++count;
		}
		
	}
	return count;
}
  
uint_32 TroopsHub::GetWeakestMoveObjectId(int_32 ignore_id/* = -1*/)
{
	float hpPercent = 1.0f;
	uint_32 weakestId = 0;
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;

		if ( unit->move_object_id() == ignore_id )
			continue;

		float percent = 
			static_cast<float>(unit->currnet_health_point()) / static_cast<float>(unit->total_health_point());
		if (hpPercent>percent)
		{
			hpPercent = percent;
			weakestId = unit->move_object_id();
		}
	}
	return weakestId;
}

uint_32 TroopsHub::GetRandomMoveObjectId(int_32 ignore_id/* = -1*/)
{
	uint_32 randomId = 0;
	if ( active_moveobj_map_.size() > 0 )
	{
		uint_32 random_index = 0;
		if (ignore_id != 0) 
		{
			if (active_moveobj_map_.size() > 1)
			{
				random_index = random_int(active_moveobj_map_.size()-1);
			}
		}
		else
		{
			random_index = random_int(active_moveobj_map_.size());
		}

		uint_32 idx = 0;
		defMoveObjMap::iterator iter = active_moveobj_map_.begin();
		for ( ; iter != active_moveobj_map_.end(); ++iter )
		{
			MoveObject* unit = iter->second;

			if ( unit->move_object_id() == ignore_id )
			{
				continue;
			}
			if (random_index == idx) 
			{
				randomId = unit->move_object_id();
				break;
			}
			idx++;
		}
	}
	
	return randomId;
}
  
// get all active troops in full kMapTilesCount
void TroopsHub::GetAllActiveMoveObjectsIdsListInValidTiles(std::vector<uint_32>& moveObjIds)
{
	moveObjIds.clear();
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		cocos2d::CCPoint tilePos = battle::GetTileCoordinatePosByCurrentPointPosition(unit->current_pos());
		if (battle::IsTileCoordinateInValidBattleRectangle(tilePos))
		{
			moveObjIds.push_back(unit->move_object_id());
		}
	}
}
  
void TroopsHub::GetAllActiveMoveObjectsIdsListInFullScreen(std::vector<uint_32>& moveObjIds)
{
	moveObjIds.clear();
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		if (unit->current_pos().x>0.0f)
		{
			moveObjIds.push_back(unit->move_object_id());
		}
	}
}

army::MoveObject* TroopsHub::GetLastMoveObjectInSelectedRow(int_8 row_no)
{
  std::vector<int_8> tile_list;
  battle::GetAllTilesIndexListInRow(row_no, tile_list);
  std::list<uint_32> range_list;
  battle::BattleController::GetInstance().GetAllMoveObjectsInTilesWithIndexList(tile_list,
    range_list, owner_hub());

  army::MoveObject* obj = NULL;
  army::MoveObject* result = NULL;
  int temp_x = 0;
  
  //get rightmost owner on select row
  if(owner_hub()->IsRightSideHub())
  {
    temp_x = -1;
    for(std::list<uint_32>::iterator itr = range_list.begin(); itr != range_list.end(); ++itr)
    {
      obj = battle::BattleController::GetInstance().GetObjectById(*itr);
	  if ( obj )
	  {
		  if(obj->current_pos().x > temp_x)
		  {
			  temp_x = obj->current_pos().x;
			  result = obj;
		  }
	  }
    }
  }
  else // get leftmost monster on select row
  {
    temp_x = 10000;
    for(std::list<uint_32>::iterator itr = range_list.begin(); itr != range_list.end(); ++itr)
    {
      obj = battle::BattleController::GetInstance().GetObjectById(*itr);
	  if ( obj)
	  {
		  if(obj->current_pos().x < temp_x && obj->current_pos().x >= 0)
		  {
			  temp_x = obj->current_pos().x;
			  result = obj;
		  }
	  }
    }
  }

  return result;
}

// random one active troops in full kMapTilesCount
uint_32 TroopsHub::RandomOneMoveObjectsIdsListInValidTiles()
{
	std::vector<uint_32> tmp_list;
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter )
	{
		MoveObject* unit = iter->second;
		cocos2d::CCPoint tilePos = battle::GetTileCoordinatePosByCurrentPointPosition(unit->current_pos());
		if (battle::IsTileCoordinateInValidBattleRectangle(tilePos))
		{
			tmp_list.push_back(unit->move_object_id());
		}
	}
	if ( tmp_list.size() > 1 ) 
	{
		return tmp_list.at(random_int(tmp_list.size()));
	}
	else if( tmp_list.size() == 1 ) 
	{
		return tmp_list.at(0);
	}
	return kUnexistTargetId;
}
  
void TroopsHub::RemoveDeadMoveOjectsAfterBattleEnd()
{
	for ( defMoveObjMap::iterator iter = unremove_dead_map_.begin(); iter != unremove_dead_map_.end(); ++iter)
	{
		MoveObject* unit = iter->second;
		unit->BeDestroyed();
		destroyUnit(unit);
	}
	unremove_dead_map_.clear();
}

//Note: we must modify active an unremove_dead ids in this loop
bool TroopsHub::Update(float delta)
{
	defMoveObjMap::iterator act_curr_iter = active_moveobj_map_.begin();
	defMoveObjMap::iterator act_next_iter = act_curr_iter;
	while ( act_curr_iter != active_moveobj_map_.end())
	{
		act_next_iter = act_curr_iter;
		++act_next_iter;
		do 
		{
			MoveObject* unit = act_curr_iter->second;
			uint_32 cardId = unit->card_id();
			//�ͷż���ʱ ��ͣupdate
			if(skill_anima_playing_ == true )
			{
				if(unit->selected_skill_id() != kSkillInvaild)
				{
					if(DataManager::GetInstance().GetSkillDataTable()->GetSkill(unit->selected_skill_id())->GetSkillType() == 0)
					{
						unit->anima_node()->Pause();
						break;
					}
				}
				else if(DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(cardId)->GetIsEnemy())
				{
					unit->anima_node()->Pause();
					break;
				}
			}
			unit->anima_node()->Resume();
			// update the AI state for this active unit
			ai::AIStateMachine::GetInstance().Update(unit, delta);

			// then, update the animation sprite for this active unit
			unit->Update(delta);

		} while (0);
		
		act_curr_iter = act_next_iter;
	}

	defMoveObjMap::iterator unremove_curr_iter = unremove_dead_map_.begin();
	defMoveObjMap::iterator unremove_next_iter = unremove_curr_iter;
	while ( unremove_curr_iter != unremove_dead_map_.end() )
	{
		unremove_next_iter = unremove_curr_iter;
		++unremove_next_iter;
		do 
		{
			MoveObject* unit = unremove_curr_iter->second;
			if(!unit->is_active() && unit->motion_state() == ai::kMotionStateDead &&
				unit->current_animation_state() == ai::kMotionResultCompelted)
			{
				owner_hub_->NotifyOneUnitDead(unit->move_object_id());
				if ( owner_hub_->IsCharacterHub())
				{
					bool isLast = false;
					if ( active_moveobj_map_.size() == 0 && unremove_dead_map_.size() == 1 )
					{
						isLast = true;
					}
					if ( owner_hub_->IsRightSideHub() )
					{
						battle::BattleController::GetInstance().notifyPlayerDead(unit->move_object_id(), isLast);
					}
					else
					{
						battle::BattleController::GetInstance().notifyMonsterDead(unit->move_object_id(), isLast, true);
					}
				}

				unit->BeDestroyed();
				//delete uint;
				unremove_dead_map_.erase(unremove_curr_iter);
				destroyUnit(unit);
				break;
			}

			// update the AI state for this active unit
			ai::AIStateMachine::GetInstance().Update(unit, delta);

			// then, update the aniamtion sprite for this active unit
			unit->Update(delta);

		} while (0);

		unremove_curr_iter = unremove_next_iter;
	}

	if (active_moveobj_map_.size()==0 && unremove_dead_map_.size()==0)
	{
		return false;
	}
	return true;
}

void TroopsHub::SwitchUnitToActiveIdsList(uint_32 unit_id)
{
	defMoveObjMap::iterator iter = active_moveobj_map_.find(unit_id);
	if ( iter != active_moveobj_map_.end())
	{
		return;
	}

	iter = substitution_moveobj_map_.find(unit_id);
	if ( iter != substitution_moveobj_map_.end())
	{
		active_moveobj_map_[iter->first] = iter->second;
		substitution_moveobj_map_.erase(iter);
		return;
	}

	iter = unremove_dead_map_.find(unit_id);
	if ( iter != unremove_dead_map_.end())
	{
		active_moveobj_map_[iter->first] = iter->second;
		unremove_dead_map_.erase(iter);
		return;
	}

	iter = dead_map_.find(unit_id);
	if ( iter != dead_map_.end())
	{
		active_moveobj_map_[iter->first] = iter->second;
		dead_map_.erase(iter);
		return;
	}
}

void TroopsHub::RemoveOneUnitIdFromActiveIdsList( uint_32 unit_id )
{
	defMoveObjMap::iterator iter = active_moveobj_map_.find(unit_id);
	if ( iter != active_moveobj_map_.end())
	{
		MoveObject* unit = iter->second;
		active_moveobj_map_.erase(iter);
		removeUnit(unit);
	}
}

  
void TroopsHub::NotifyTargetDestroyed(uint_32 destroyed_unit_id)
{
  army::MoveObject  *obj = NULL;
  army::TroopsHub   *own_troops = this->owner_hub()->troops();
  const std::vector<uint_32>& own_active_ids = own_troops->active_ids();
  for(int i = 0; i < own_active_ids.size(); ++i )
  {
    obj = own_troops->GetObjectById(own_active_ids[i]);
    if(obj->target_selection()->target_id() == destroyed_unit_id)
    {
      obj->target_selection()->set_target_id(army::kUnexistTargetId);
    }
    if(obj->target_selection()->choosen_target_id() == destroyed_unit_id)
    {
      obj->target_selection()->set_is_forced_move_to(false);
      obj->target_selection()->set_choosen_target_id(army::kUnexistTargetId);
    }
    if(obj->target_selection()->previous_target_id() == destroyed_unit_id)
    {
      obj->target_selection()->set_previous_target_id(army::kUnexistTargetId);
    }
  }

  army::TroopsHub   *enemy_troops = this->owner_hub()->enemy_hub()->troops();
  const std::vector<uint_32>& enemy_active_ids = enemy_troops->active_ids();
  for(int i = 0; i < enemy_active_ids.size(); ++i )
  {
	obj = enemy_troops->GetObjectById(enemy_active_ids[i]);
    if(obj->target_selection()->target_id() == destroyed_unit_id)
    {
      obj->target_selection()->set_target_id(army::kUnexistTargetId);
    }
    if(obj->target_selection()->choosen_target_id() == destroyed_unit_id)
    {
      obj->target_selection()->set_is_forced_move_to(false);
      obj->target_selection()->set_choosen_target_id(army::kUnexistTargetId);
    }
    if(obj->target_selection()->previous_target_id() == destroyed_unit_id)
    {
      obj->target_selection()->set_previous_target_id(army::kUnexistTargetId);
    }
  }
}
  
// update for victory celebration
void TroopsHub::UpdateVictoryCelebration(float delta)
{
	defMoveObjMap::iterator act_curr_iter = active_moveobj_map_.begin();
	defMoveObjMap::iterator act_next_iter = act_curr_iter;
	while ( act_curr_iter != active_moveobj_map_.end())
	{
		act_next_iter = act_curr_iter;
		++act_next_iter;
		do 
		{
			MoveObject* unit = act_curr_iter->second;
			assert(unit);
			if(!unit->is_active())
			{
				active_moveobj_map_.erase(act_curr_iter);
				removeUnit(unit);

				if (active_moveobj_map_.size()==0)
				{
					// show xp bar increasing & label
					battle::BattleController::GetInstance().ShowBattleXpReward();
				}
				break;
			}
			// update the AI state for this active unit only
			ai::AIStateMachine::GetInstance().Update(unit, delta);

		} while (0);
		act_curr_iter = act_next_iter;
	}

	for ( defMoveObjMap::iterator act_curr_iter = unremove_dead_map_.begin(); act_curr_iter != unremove_dead_map_.end(); ++act_curr_iter)
	{
		Character* unit = dynamic_cast<Character*>(act_curr_iter->second);
		assert(unit);    
		// update the aniamtion sprite for this active unit
		unit->UpdateXpBar(delta);
	}
}

void TroopsHub::ChangeAllActiveToIdle()
{
	defMoveObjMap::iterator iter = active_moveobj_map_.begin();
	for ( ; iter != active_moveobj_map_.end(); ++iter)
	{
		MoveObject* unit = iter->second;
		//if (troops_[i]->is_active())
		//{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateIdle);
		//}
	}
}
  
void TroopsHub::ClearAllMoveObjects()
{
	global_id_ = start_id_;
	// clear dead ones firstly
	owner_hub()->troops()->RemoveDeadMoveOjectsAfterBattleEnd();

	// then active ones
	if (owner_hub()->IsCharacterHub())
	{
		for ( defMoveObjMap::iterator iter = active_moveobj_map_.begin(); iter != active_moveobj_map_.end(); ++iter)
		{
			MoveObject* unit = iter->second;
			delete unit;
		}
		active_moveobj_map_.clear();

		for ( defMoveObjMap::iterator iter = substitution_moveobj_map_.begin(); iter != substitution_moveobj_map_.end(); ++iter)
		{
			MoveObject* unit = iter->second;
			delete unit;
		}
		substitution_moveobj_map_.clear();

		for ( defMoveObjMap::iterator iter = unremove_dead_map_.begin(); iter != unremove_dead_map_.end(); ++iter)
		{
			MoveObject* unit = iter->second;
			delete unit;
		}
		unremove_dead_map_.clear();
	}
	else
	{
		for ( defMoveObjMap::iterator iter = active_moveobj_map_.begin(); iter != active_moveobj_map_.end(); ++iter)
		{
			MoveObject* unit = iter->second;
			delete unit;
		}
		active_moveobj_map_.clear();

		for ( defMoveObjMap::iterator iter = substitution_moveobj_map_.begin(); iter != substitution_moveobj_map_.end(); ++iter)
		{
			MoveObject* unit = iter->second;
			delete unit;
		}
		substitution_moveobj_map_.clear();

		for ( defMoveObjMap::iterator iter = unremove_dead_map_.begin(); iter != unremove_dead_map_.end(); ++iter)
		{
			MoveObject* unit = iter->second;
			delete unit;
		}
		unremove_dead_map_.clear();
	}

	active_moveobj_map_.clear();
	substitution_moveobj_map_.clear();
	unremove_dead_map_.clear();
}

void TroopsHub::SetSkillPlayingStatus( bool bPlay )
{
    skill_anima_playing_ = bPlay;
}

void TroopsHub::removeUnit(MoveObject* unit)
{
	if ( !unit)
		return;

	std::pair<defMoveObjMap::iterator, bool> insertRes;
	insertRes = unremove_dead_map_.insert(std::pair<uint_32, MoveObject*>(unit->move_object_id(), unit));
	if (insertRes.second == false)
	{
		delete unit;
		assert(0);
	}
}

void TroopsHub::destroyUnit(MoveObject* unit)
{
	if ( !unit)
		return;

	if ( owner_hub_->IsCharacterHub() )
	{
		std::pair<defMoveObjMap::iterator, bool> insertRes;
		insertRes = dead_map_.insert(std::pair<uint_32, MoveObject*>(unit->move_object_id(), unit));
		if (insertRes.second == false)
		{
			assert(0);
		}
	}
	else
	{
		unit->ClearAllProperties();
		unit->set_move_object_id( army::kUnexistTargetId );
		idle_loop_.push(unit);
	}
}

} // namespace army
} // namespace taomee
