//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  born_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-22
//          Time:  6:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-22        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_born_hub_h
#define ChainChronicle_born_hub_h

#include "engine/base/basictypes.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "game/army/unit/unit_constants.h"

namespace cocos2d {
  class CCPoint;
}

class CharacterData;

namespace taomee {

namespace battle {
  class BattleHub;
  class PvpCharacterCreatationInfo;
}

namespace army {
  class Character;
  class Monster;
  //enum eCareerType;
}
  
namespace data {
  class CharacterInfo;
}
  
  
namespace army {

class BornHub
{
public:
  BornHub(battle::BattleHub* own);
  virtual ~BornHub();
  
  battle::BattleHub* owner_hub() { return owner_hub_; }
  
public:
  // create five characters in right side
  //
  void CreateTeamByBattleType(int nBattleType = 0/*kTeamMainIndex*/);
  // create five characters special for new player's guide
  void CreateAvatorGroupForNewPlayersGuide();
  // create all characters for battle victory
  void CreateAllCharactersForBattleVictory();
  
  //Pvp
  void CreatePvpGroup();
  void CreateEditorGroup();
  int_8 _GetDestinationTileIndexByTileXY(uint_8 tileX, uint_8 tileY);
  int_8 _GetDestinationTileIndexById(int_32 unit_id, bool is_substitution);
  int_8 _CheckDestinationTileIndex(int_32 unit_id, int_8 dest_tile_idx, bool is_auto_garrison);


  void _SetCharacterAI(Character* unit, army::eCareerType career_type);
  void SetCharacterPosition(
    int_8             dest_tile_idx,
    Character*        unit, 
    int_32            unit_id,
    CharacterData*    char_data, 
    bool              is_substitution);

  void SetCharacterInfo(
    data::CharacterInfo*    info,
    CharacterData*          char_data,
    Character*              unit,
    float                   idle_time = 100.0f);

  void SetCharacterAIAndAddToList(
    int_32              card_id,
    CharacterData*      char_data,
    Character*          unit,
    uint_32             unit_id);
  
  // create one character with info
  void CreateOneCharacterWithPvpBornInfo(taomee::battle::PvpCharacterCreatationInfo& data);

  void CreateOneCharacterWithBornInfo(uint_32 unitId,
                                      uint_32 card_id,
                                      uint_32 sequence_id,
                                      bool    is_substitution = false);
  // create one special character for avator only
  void CreateOneCharacterWithBornInfo(uint_32 unitId,
                                      uint_32 cardId,
                                      uint_16 level,
                                      uint_8  tileX,
                                      uint_8  tileY,
                                      bool    isFriend);
  void CreateOneCharacterWithBornInfo(uint_32 unitId,
                                      data::CharacterInfo* info,
                                      bool    is_substitution = false);

  void CreateOneCharacterWithBornInfoNoTile(Character*              unit, 
                                            int_32                  unit_id,
                                            int_32                  card_id,
                                            CharacterData*          char_data,
                                            data::CharacterInfo*    info,
                                            float                   idle_time = 100.0f,
                                            bool                    is_substitution = false,
                                            bool                    is_auto_garrison = false);


  void CreateOneCharacterWithBornInfoForLua(uint_32 unitId,
    uint_32 card_id,
    uint_32 level);

  // create next character after one character's death
  void CreateNextCharacterForBattleWithDestroyedMoveObjectId(uint_32  unitId);

  // create character for lua
  void CreateNextCharacterForLua(uint_32  unitId, uint_32 card_id, uint_32 level);

  void CreateOneMonsterCommon(uint_32 unitId,
    uint_32 cardId,
    ai::eAIStateType intent_type,
    ai::eAIBornLine born_line,
    cocos2d::CCPoint bron_pos,
    int_8 tileIdx,
    uint_16 level,
    uint_32 timestamp,
    float des_hp_mult,
    float des_att_mult);


  // create one monster with info
  void CreateOneMonsterWithBornInfo(uint_32 unitId,
    uint_32 cardId,
    ai::eAIStateType intent_type,
    ai::eAIBornLine born_line,
    uint_16 level,
    uint_32 timestamp,
    float des_hp_mult,
    float des_att_mult);

  // create one monster with info
  void CreateOneMonsterWithBornInfoAtIndex(uint_32 unit_id,
    uint_32 card_id,
    ai::eAIStateType intent_type,
    int_8 tileIdx,
    uint_16 level,
    uint_32 timestamp,
    float des_hp_mult,
    float des_att_mult);

  // create one monster with info
  void CreateOneMonsterWithBornInfoAtPos(
	  uint_32 unitId, uint_32 cardId, ai::eAIStateType intent_type, cocos2d::CCPoint bron_pos, uint_16 level, uint_32 timestamp, float des_hp_mult, float des_att_mult);

  void CreateOneMonsterWithBornInfoAtPos(
	  Monster* unit, uint_32 cardId, ai::eAIStateType intent_type,cocos2d::CCPoint bron_pos, uint_16 level, uint_32 timestamp, float des_hp_mult, float des_att_mult);


  uint_32 CreateOneSummonWithBornInfoAtIndex(
	  uint_32 card_id, ai::eAIStateType intent_type, int_8 tileIdx, uint_16 level);

private:
  // choose the destination for new born character
  int_8 getNewBornDestinationTileIndexForCharacterById(uint_32 unitId);
  // choose the destination for new reserve character
  int_8 getNewBornDestinationTileIndexForReserveCharacterById(uint_32 unitId);
  // choose the celebrate destination for battle winner(characters)
  int_8 getCelebrateDestinationTileIndexForCharacterById(uint_32 unitId);
  
  // create passive ability for unit
  void createPassiveAbilities(uint_32 unitId);
  
private:
  battle::BattleHub* owner_hub_;
};
  
} // namespace army
} // namespace taomee

#endif // ChainChronicle_born_hub_h
