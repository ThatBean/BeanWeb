

#ifndef army_monster_troops_hub_h
#define army_monster_troops_hub_h

#include "game/army/unit_hub/troops_hub.h"

namespace taomee {
namespace army {


class MonsterTroopsHub : public TroopsHub
{
public:
	MonsterTroopsHub(battle::BattleHub* own, uint_32 start_id, uint_32 end_id);
	~MonsterTroopsHub();

protected:
	virtual MoveObject* createObjectImpl(uint_32 id);

};

}
}

#endif