

#ifndef army_character_troops_hub_h
#define army_character_troops_hub_h

#include "game/army/unit_hub/troops_hub.h"

namespace taomee {
namespace army {


class CharacterTroopsHub : public TroopsHub
{
public:
	CharacterTroopsHub(battle::BattleHub* own, uint_32 start_id, uint_32 count);
	~CharacterTroopsHub();

protected:
	virtual MoveObject* createObjectImpl(uint_32 id);

};

}
}

#endif