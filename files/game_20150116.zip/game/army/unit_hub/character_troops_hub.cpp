

#include "game/army/unit_hub/character_troops_hub.h"
#include "game/army/unit/character.h"

namespace taomee {
namespace army {

CharacterTroopsHub::CharacterTroopsHub(battle::BattleHub* own, uint_32 start_id, uint_32 count)
	: TroopsHub( own, start_id, count)
{
	for ( int i = 0; i < 7; ++i)
	{
		MoveObject* newObj = newObj = new Character(owner_hub_, army::kUnexistTargetId );
		idle_loop_.push(newObj);
	}
}

CharacterTroopsHub::~CharacterTroopsHub()
{

}

MoveObject* CharacterTroopsHub::createObjectImpl(uint_32 id)
{
	MoveObject* character = new Character(owner_hub_, id);
	return character;
}

}
}