//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  born_hub.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-22
//          Time:  6:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-22        1         create
//////////////////////////////////////////////////////////////

#include "game/army/unit_hub/born_hub.h"
#include "game/passive_ability/aura.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/character.h"
#include "game/army/unit/monster.h"
#include "game/army/unit/summon.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/artificial_intelligence/trigger/trigger.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "game/battle/own_hub.h"
#include "game/battle/monster_hub.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_data.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "game/passive_ability/passive_ability_constants.h"
#include "game/battle/battle_resource_loader.h"
#include "editor/handle/SCCheckpointHandle.h"

namespace taomee {
namespace army {
  
BornHub::BornHub(battle::BattleHub* own)
  : owner_hub_(own)
{
  
}
  
BornHub::~BornHub()
{
  owner_hub_ = NULL;
}
  
// create five characters in right side
void BornHub::CreateTeamByBattleType(int nBattleType)
{
  //snowcold for editor tool to test
  if (battle::BattleController::GetInstance().getIsInEditorMode())
  {
    CreateEditorGroup();
    return;
  }

  //get team character info by team index
  uint_32 team_sid_list[data::kMaxCharacterCountInOneTeam] = { data::kUnexistCharacterId };
  DataManager::GetInstance().user_info()->teams_ids(nBattleType, team_sid_list);

  uint_32 obj_id = 0;
  //create team character
  for ( obj_id = army::kCharaterObject_StartId; obj_id < army::kMaxActiveCharactersCount;++obj_id )
  {
    if (team_sid_list[obj_id]==data::kUnexistCharacterId)
    {
      continue;
    }
    uint_32 card_id = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(team_sid_list[obj_id])->card_id();
    this->CreateOneCharacterWithBornInfo(obj_id, card_id, team_sid_list[obj_id]);
    // mark it as active unit
    battle::BattleController::GetInstance().battle_data()->
      set_characters_status(data::kCharacterStatusActivated, team_sid_list[obj_id]);
  }

  //create friend character
  bool hasFriend = false;
  if ( obj_id < kMaxActiveCharactersCount-1 && battle::BattleController::GetInstance().getBattleType() == battle::kBattleType_Main)
  {
    std::string friendId = battle::BattleController::GetInstance().battle_data()->current_friend_id();
    if (friendId.size() > 0 && FriendController::GetInstance().GetHelperByUid(friendId) != NULL)
    {
      hasFriend = true;
      data::CharacterInfo* friendCard = FriendController::GetInstance().GetHelperByUid(friendId)->lead_character_friend();
      assert(friendCard);
      if ( friendCard != NULL )
      {
        this->CreateOneCharacterWithBornInfo(obj_id, friendCard);
        Character* unit = dynamic_cast<Character*>(owner_hub()->GetUnitById(obj_id));
        if (unit != NULL)
        {
          unit->set_base_total_health_point(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(0));
          unit->set_currnet_health_point(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(0));
          unit->set_basic_physics_attack_(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(1));
		  unit->set_basic_magic_attack_(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(1));
          unit->set_basic_physics_defense(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(2));
          unit->set_basic_magic_defense(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(3));
          unit->set_final_damage(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(4));
          unit->set_final_defence(FriendController::GetInstance().GetHelperByUid(friendId)->get_leader_attr_by_index(5));
        }
      }
    }
  }

  //create ability for active move object
  const std::vector<uint_32>& active_ids = this->owner_hub()->troops()->active_ids();
  for (int i = 0; i < active_ids.size(); ++i)
  {
	  army::MoveObject *move_obj = this->owner_hub()->troops()->GetObjectById(active_ids[i]);
	  if ( move_obj )
	  {
		  this->createPassiveAbilities(move_obj->move_object_id());
	  }
  }
}
  
// create five characters special for new player's guide
void BornHub::CreateAvatorGroupForNewPlayersGuide()
{
  if (battle::BattleController::GetInstance().getIsInEditorMode())
  {
    CreateEditorGroup();
    return;
  }
  
  int_32 id = army::kCharaterObject_StartId;
  battle::OwnHub* owner = dynamic_cast<battle::OwnHub*>(owner_hub_);
  assert(owner);
  //assert(owner->creatation_list().size()<=army::kMaxActiveCharactersCount);
  while (owner->creatation_list().size()>0)
  {
    battle::CharacterCreatationInfo info;
    owner->PopOneCreatationInfo(info);
    //snowcold
    //assert(info.unit_id_ == id);
    if (info.unit_id_ == id)
    {
      this->CreateOneCharacterWithBornInfo(id++, info.card_id_, info.level_,
        info.tile_x_, info.tile_y_, info.is_friend_); 
    }
    else
    {
      this->CreateOneCharacterWithBornInfo(info.unit_id_, info.card_id_, info.level_,
        info.tile_x_, info.tile_y_, info.is_friend_);
    }
  }
}

void BornHub::CreateEditorGroup()
{
  int_32 id = army::kCharaterObject_StartId;
  battle::OwnHub* owner = dynamic_cast<battle::OwnHub*>(owner_hub_);
  assert(owner);

  //Just for clean��~
  while (owner->creatation_list().size()>0)
  {
    battle::CharacterCreatationInfo info;
    owner->PopOneCreatationInfo(info);
  }
  
  int max_count = SCCheckpointTestDataCache::getInstance()->getCharacterCount();
  for (int i = 0; i < max_count; ++i)
  {
    battle::PvpCharacterCreatationInfo* info = SCCheckpointTestDataCache::getInstance()->getCharacterInfoByIndex(i);
    this->CreateOneCharacterWithPvpBornInfo(*info);
    this->createPassiveAbilities(this->owner_hub()->troops()->
      GetActiveObjectByIndex(i)->move_object_id());
  }
}

void BornHub::CreatePvpGroup()
{
  battle::OwnHub* owner = dynamic_cast<battle::OwnHub*>(owner_hub_);
  assert(owner);

  int i = 0;
  while (owner->pvp_creatation_list().size()>0)
  {
    battle::PvpCharacterCreatationInfo info;
    owner->PopOnePvpCreationInfo(info);
    this->CreateOneCharacterWithPvpBornInfo(info);
    this->createPassiveAbilities(this->owner_hub()->troops()->
      GetActiveObjectByIndex(i)->move_object_id());
    ++i;
  }
}


void BornHub::_SetCharacterAI(
  Character*          unit, 
  army::eCareerType   career_type)
{
  // set the default AI state for character
  unit->set_near_attack_trigger(new ai::Trigger(unit, kTriggerAttack, kTriggerTroopEnemey));

  // set the default AI state for character
  if(career_type == army::kCareerTypeMonk)
  {
    unit->set_guard_trigger(new ai::Trigger(unit, kTriggerGuard, kTriggerTroopSelf |
      kTriggerTroopTeamate, kTriggerConditionCure));
  }
  else
  {
    unit->set_guard_trigger(new ai::Trigger(unit, kTriggerGuard, kTriggerTroopEnemey));
  }

  // set the default AI state for character
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
  case battle::kBattleType_Pvp:
    { 
      if(career_type == army::kCareerTypeMonk)
      {
        unit->set_ai_orig_state(ai::KAIStateCure);
        unit->set_ai_state(ai::KAIStateCure);
      }
      else
      {
        unit->set_ai_orig_state(ai::kAIStateGuard);
        unit->set_ai_state(ai::kAIStateGuard);
      }
    }
    break;
  case battle::kBattleType_SandBox:
    {
      unit->set_ai_orig_state(ai::kAIStateDefault);
      unit->set_ai_state(ai::kAIStateDefault);
    }
    break;
  default:
    break;
  }

  return;
}



int_8 BornHub::_GetDestinationTileIndexByTileXY(uint_8 tileX, uint_8 tileY)
{
  int_8 dest_tile_idx = 0;
  
  dest_tile_idx = battle::GetTileIndexByTileCoordinatePos(ccp(tileX, tileY));
  
  return dest_tile_idx;
}

int_8 BornHub::_GetDestinationTileIndexById(int_32 unit_id, bool is_substitution)
{
  int_8 dest_tile_idx = 0;
  if (is_substitution)
  {
    // substitution's born position is default on last line
    dest_tile_idx = this->getNewBornDestinationTileIndexForReserveCharacterById(unit_id);
  }
  else
  {
    dest_tile_idx = this->getNewBornDestinationTileIndexForCharacterById(unit_id);
  }
  return dest_tile_idx;
}

int_8 BornHub::_CheckDestinationTileIndex(int_32 unit_id, int_8 dest_tile_idx, bool is_auto_garrison)
{
  bool garrison_successful = battle::BattleController::GetInstance().
    tiled_map()->DispatchCharacterGarrisonTile(unit_id, dest_tile_idx);

  // get the nearest tile when the current one is Garrisoned
  if (!garrison_successful && is_auto_garrison)
  {
    dest_tile_idx = battle::BattleController::GetInstance().
      tiled_map()->GetOneClosetEmptyTileNearby(dest_tile_idx);
    battle::BattleController::GetInstance().
      tiled_map()->DispatchCharacterGarrisonTile(unit_id, dest_tile_idx);
  }
  // get the nearest tile when the current one is Garrisoned
  assert(garrison_successful);
  return dest_tile_idx;
}


void BornHub::SetCharacterPosition(
  int_8             dest_tile_idx,
  Character*        unit, 
  int_32            unit_id,
  CharacterData*    char_data,
  bool              is_substitution)
{
  // mark the garrison tile
  (dynamic_cast<army::Character*>(unit))->set_garrison_tile_index(dest_tile_idx);
  // calculate born & destination point, mark it then.
  cocos2d::CCPoint dest_pos = battle::GetGarrisonPointForMoveObjectInTile(dest_tile_idx);
  unit->target_selection()->set_target_pos(dest_pos);
  unit->target_selection()->set_is_forced_move_to(true);
  
  if(char_data->GetBodyHeight() * 2 >= 1)
  {
    for(int i = 1; i < 2 *char_data->GetBodyHeight(); ++i)
    {
      unit->add_offset_point(ccp(0, i * (battle::kMapTileMaxHeight / 2)));
    }
  }

//             if(char_data->GetBodyHeight() > 1)
//             {
//               for(int i = 1; i < char_data->GetBodyHeight(); ++i)
//               {
//                 unit->add_offset_point(ccp(0, i * (battle::kMapTileMaxHeight + 10)));
//               }
//            

  // attach unit on battle field view
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
      cocos2d::CCPoint born_pos;
      if (owner_hub_->IsRightSideHub())
      {
        born_pos = ccp(dest_pos.x+iCC_DESIGN_SIZE.width/battle::kMapColumnCount, dest_pos.y);
        //born_pos = ccp(iCC_DESIGN_SIZE.width / battle::kMapColumnCount * 1.0 * (battle::kMapColumnCount + 1), dest_pos.y);
      }
      else
      {
        born_pos = ccp(dest_pos.x-iCC_DESIGN_SIZE.width/battle::kMapColumnCount, dest_pos.y);
        //born_pos = ccp(iCC_DESIGN_SIZE.width / battle::kMapColumnCount * 1.0 * (-1), dest_pos.y);
      }
      unit->AttachUnitIntoBattleView(owner_hub()->battle_view(), born_pos);
    }
    break;
  case battle::kBattleType_Pvp:
  case battle::kBattleType_SandBox:
    {
      unit->AttachUnitIntoBattleView(owner_hub()->battle_view(), dest_pos);

      if (!owner_hub()->IsRightSideHub())
      {
        unit->set_anima_direction(kDirectionRight);
      }
    }
    break;
  default:
    break;
  }
}

void BornHub::SetCharacterInfo(
  data::CharacterInfo*    info,
  CharacterData*          char_data,
  Character*              unit,
  float                   idle_time/* = 100.0f*/)
{
  int_32 card_id = info->card_id();
  uint_32 sequence_id = info->sequence_id();

  unit->set_card_id(card_id);
  unit->set_idle_time(idle_time);
  unit->set_sequence_id(sequence_id);
  unit->set_character_info(info);
}

void BornHub::SetCharacterAIAndAddToList(
  int_32              card_id,
  CharacterData*      char_data,
  Character*          unit,
  uint_32             unit_id)
{

  army::eCareerType career_type = army::GetMoveObjectCareerByCardId(card_id);

  _SetCharacterAI(unit, career_type);

  assert(char_data->GetPatrolType() != kPatrolAreaInvalid);
}

void BornHub::CreateOneCharacterWithPvpBornInfo(taomee::battle::PvpCharacterCreatationInfo& data)
{
  int_32 card_id = data.card_id_;
  uint_32 unit_id = data.unit_id_;
  float idle_time = 100.0f;
  bool is_substitution = false;
  bool is_auto_garrison = true;
  
  CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
  Character* unit = dynamic_cast<Character*>(owner_hub()->CreateUnitById(unit_id, false));
  assert(unit);
  
  data::CharacterInfo* info = new data::CharacterInfo(0, card_id, 1, 0, 0);

  // keep this memory to manager it
  (dynamic_cast<battle::OwnHub*>(owner_hub_))->AddOneCharacterInfo(info);

  CreateOneCharacterWithBornInfoNoTile(
    unit,         unit_id,            card_id,
    char_data,    info,               idle_time,
    is_substitution,    is_auto_garrison);
}

// create one character with info
void BornHub::CreateOneCharacterWithBornInfo(uint_32 unit_id,
                                             uint_32 card_id,
                                             uint_32 sequence_id,
                                             bool    is_substitution /* = false */)
{
  data::CharacterInfo* info = DataManager::GetInstance().user_info()->
                                      GetCharacterCardBySequenceId(sequence_id);
  this->CreateOneCharacterWithBornInfo(unit_id, info, is_substitution);
}

void BornHub::CreateOneCharacterWithBornInfo(uint_32 unit_id,
  data::CharacterInfo* info,
  bool    is_substitution /* = false */)
{
  int_32 card_id = info->card_id();

  BattleResourceLoader::GetInstance()->addLoadCardID(card_id);
  float idle_time = 100.0f;
  bool is_auto_garrison = true;

  CharacterData* char_data =
	  DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
  Character* unit;
  if ( is_substitution )
  {
	  unit = dynamic_cast<Character*>(owner_hub()->CreateUnitBySubstitution(unit_id));
  }
  else
  {
	  unit = dynamic_cast<Character*>(owner_hub()->CreateUnitById(unit_id, is_substitution));
  }
  
  assert(unit);

  CreateOneCharacterWithBornInfoNoTile(
    unit,         unit_id,            card_id,
    char_data,    info,               idle_time,
    is_substitution,    is_auto_garrison);
}
  
void BornHub::CreateOneCharacterWithBornInfoForLua(uint_32 unit_id,
                                             uint_32 card_id,
                                             uint_32 level)
{
  float idle_time = 100.0f;
  bool is_substitution = false;
  bool is_auto_garrison = true;
  
  CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()
    ->GetCharacter(card_id);
  BattleResourceLoader::GetInstance()->addLoadCardID(card_id);
  Character* unit = dynamic_cast<Character*>(owner_hub()->CreateUnitById(unit_id, false));
  assert(unit);
  data::CharacterInfo* info = new data::CharacterInfo(0, card_id, level,0, 0);

  CreateOneCharacterWithBornInfoNoTile(
    unit,         unit_id,            card_id,
    char_data,    info,               idle_time,
    is_substitution,    is_auto_garrison);
}
// create one special character for avator only
void BornHub::CreateOneCharacterWithBornInfo(uint_32 unit_id,
                                             uint_32 card_id,
                                             uint_16 level,
                                             uint_8  tileX,
                                             uint_8  tileY,
                                             bool    isFriend)
{
  float idle_time = 100.0f;
  bool is_substitution = false;
  bool is_auto_garrison = true;
  BattleResourceLoader::GetInstance()->addLoadCardID(card_id);
  CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);

  Character* unit = dynamic_cast<Character*>(owner_hub()->CreateUnitById(unit_id, false));
  assert(unit);
  data::CharacterInfo* info = new data::CharacterInfo(0, card_id, level, 0, 0);
  // keep this memory to manager it
  (dynamic_cast<battle::OwnHub*>(owner_hub_))->AddOneCharacterInfo(info);
  // set active flag with true value to mark unit is on battle scene
  
  SetCharacterInfo(
    info,
    char_data,
    unit,
    idle_time);

  unit->InitMoveObjectDataFromFile();
  
  SetCharacterAIAndAddToList(
    card_id,
    char_data,
    unit,
    unit_id);

  int_8 dest_tile_idx = _GetDestinationTileIndexByTileXY(tileX, tileY);
  dest_tile_idx = _CheckDestinationTileIndex(unit_id, dest_tile_idx, is_auto_garrison);

  SetCharacterPosition(
    dest_tile_idx, 
    unit, 
    card_id, 
    char_data,
    is_substitution);
}

void BornHub::CreateOneCharacterWithBornInfoNoTile(Character*              unit, 
                                                   int_32                  unit_id,
                                                   int_32                  card_id,
                                                   CharacterData*          char_data,
                                                   data::CharacterInfo*    info,
                                                   float                   idle_time/* = 100.0f*/,
                                                   bool                    is_substitution/* = false*/,
                                                   bool                    is_auto_garrison/* = false*/)
{
  BattleResourceLoader::GetInstance()->addLoadCardID(card_id);
  // set active flag with true value to mark unit is on battle scene
  SetCharacterInfo(
    info,
    char_data,
    unit,
    idle_time);

  unit->InitMoveObjectDataFromFile();

  SetCharacterAIAndAddToList(
    card_id,
    char_data,
    unit,
    unit_id);

  int_8 dest_tile_idx = _GetDestinationTileIndexById(unit_id, is_substitution);
  dest_tile_idx = _CheckDestinationTileIndex(unit_id, dest_tile_idx, is_auto_garrison);

  SetCharacterPosition(
    dest_tile_idx, 
    unit, 
    card_id, 
    char_data, 
    is_substitution);
}


// create one unit with info
void BornHub::CreateOneMonsterWithBornInfo(uint_32 unit_id,
  uint_32 card_id,
  ai::eAIStateType intent_type,
  ai::eAIBornLine born_line,
  uint_16 level,
  uint_32 timestamp,
  float des_hp_mult,
  float des_att_mult)
{
	if (born_line == ai::kAIBornRandom)
	{
		born_line = (ai::eAIBornLine)random_int(ai::kAIBornBottom);
	}

	CCPoint born_pos = 
		battle::BattleController::GetInstance().tiled_map()->GetBornPositionForMoveObjectsByRowIndex(born_line, true);

	CreateOneMonsterWithBornInfoAtPos(
		unit_id, 
		card_id, 
		intent_type, 
		born_pos, 
		level, 
		timestamp, 
		des_hp_mult, 
		des_att_mult);

	Monster* unit = dynamic_cast<Monster*>(owner_hub()->GetUnitById(unit_id));
	assert(unit);
	unit->set_born_line(born_line);
	// draw arrows
	battle::BattleController::GetInstance().battle_view()->CreateArrows(born_line);
}

// create one unit with info
void BornHub::CreateOneMonsterWithBornInfoAtIndex(uint_32 unit_id,
  uint_32 card_id,
  ai::eAIStateType intent_type,
  int_8 tileIdx,
  uint_16 level,
  uint_32 timestamp,
  float des_hp_mult,
  float des_att_mult)
{
  ai::eAIBornLine born_line = ai::eAIBornLine(tileIdx / battle::kMapColumnCount);
  if (born_line == ai::kAIBornRandom)
  {
    born_line = (ai::eAIBornLine)random_int(ai::kAIBornBottom);
  }

  cocos2d::CCPoint born_pos = battle::GetGarrisonPointForMoveObjectInTile(tileIdx);

  assert(battle::IsTileCoordinateInRange(battle::GetTileCoordinatePosByTileIndex(tileIdx)));

	CreateOneMonsterWithBornInfoAtPos(
		unit_id, 
		card_id, 
		intent_type, 
		born_pos, 
		level, 
		timestamp, 
		des_hp_mult, 
		des_att_mult);

	Monster* unit = dynamic_cast<Monster*>(owner_hub()->GetUnitById(unit_id));
	assert(unit);
	unit->set_born_line(born_line);

	// draw arrows
	//battle::BattleController::GetInstance().battle_view()->CreateArrows(born_line);
}

void BornHub::CreateOneMonsterWithBornInfoAtPos(
	uint_32 unitId, uint_32 cardId, ai::eAIStateType intent_type, cocos2d::CCPoint bron_pos, uint_16 level, uint_32 timestamp, float des_hp_mult, float des_att_mult)
{
	Monster* unit = dynamic_cast<Monster*>(owner_hub()->CreateUnitById(unitId, false));
	if ( unit == NULL)
	{
		assert(0);
		return;
	}

	CreateOneMonsterWithBornInfoAtPos( 
		unit, cardId, intent_type, bron_pos, level,timestamp, des_hp_mult, des_att_mult);
	
}

// create one unit with info
void BornHub::CreateOneMonsterWithBornInfoAtPos(
	Monster* unit, uint_32 card_id, ai::eAIStateType intent_type, CCPoint born_pos, uint_16 level, uint_32 timestamp, float des_hp_mult, float des_att_mult)
{
	assert(unit);
  // set info
  unit->set_card_id(card_id);
  unit->set_level(level);
  unit->set_intent_type(intent_type);
  //unit->set_born_line(born_line);
  unit->set_timestamp(timestamp);
  unit->set_hp_des_mult(des_hp_mult);
  unit->set_att_des_mult(des_att_mult);
  unit->set_ai_orig_state(intent_type);
  unit->set_ai_state(intent_type);
  unit->InitMoveObjectDataFromFile(); 

  CharacterData* pMonsterData = unit->character_card_data();
  assert(pMonsterData->GetIsEnemy());
  if (pMonsterData)
  {
    //���ݲ߻���ʽ�޸Ĺ������ ����
    /*
    ��� = ����Ѫ��/6 * ��Ӣϵ�� * ����ϵ��/100
    ���� = ����Ѫ��/6 * ��Ӣϵ�� * ����ϵ��/100
    */
    float hpPer = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/battle/lua_battle_monster_config.lua","GetMonsterHpPer");
    float eliteParam = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/battle/lua_battle_monster_config.lua","GetMonsterEliteParam",(pMonsterData->GetMonsterLevel()>0));
    int phdef_genderParam = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/battle/lua_battle_monster_config.lua","GetMonsterGenderParam",pMonsterData->GetGender(),true);
    int mgdef_genderParam = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/battle/lua_battle_monster_config.lua","GetMonsterGenderParam",pMonsterData->GetGender(),false);

    unit->set_physics_defense_added(unit->currnet_health_point()*hpPer*eliteParam*phdef_genderParam/100);
    unit->set_magic_defense_added(unit->currnet_health_point()*hpPer*eliteParam*mgdef_genderParam/100);
  }
  
  army::eCareerType career_type = unit->GetCareerType();

  unit->target_selection()->set_target_pos(ccpAdd(ccp(2000,0),born_pos));

  if (pMonsterData->GetMoveType()) 
  {
    unit->set_near_attack_trigger(new ai::Trigger(unit, kTriggerAttack, kTriggerTroopEnemey));

    if(pMonsterData->GetPatrolType() != kPatrolAreaInvalid)
    {
      if(career_type == army::kCareerTypeMonk)
      {
        unit->set_guard_trigger(new ai::Trigger(unit, kTriggerGuard, kTriggerTroopTeamate | kTriggerTroopSelf, kTriggerConditionCure));
      }
      else
        unit->set_guard_trigger(new ai::Trigger(unit, kTriggerGuard, kTriggerTroopEnemey));
    }
  }

  int stage_stay_col;
  ai::eAIStateType result_ai_type;
  switch(pMonsterData->GetMoveType())
  {
  case 1: //normal near attack warrior, need not stop
    stage_stay_col =  -1;
    result_ai_type = ai::kAIStateMonsterWarrior;
    break;
  case 2: //near attack warrior, need stay on column 1 for some seconds
    stage_stay_col = 1;
    result_ai_type = ai::kAIStateMonsterWarrior;
    break;
  case 3: //normal range attack archer, need stay on column 0 for some seconds
    stage_stay_col = 0;
    result_ai_type = ai::kAIStateMonsterArcher;
    break;
  case 4: //range attack archer, need stay on column 1 for some seconds
    stage_stay_col = 1;
    result_ai_type = ai::kAIStateMonsterArcher;
    break;
  case 5: //assassin, need stay on column 1 for some seconds to search suitable row path
    stage_stay_col = 0;
    result_ai_type = ai::kAIStateMonsterAssassin;
    break;
  case 6: //monk, singer, dancer, need stay on column 1 for some seconds util teammate dead
    stage_stay_col = 0;
    result_ai_type = ai::kAIStateMonsterSkiller;
    break;
  case 7: //big boss, stay on column x forever
    stage_stay_col = 1;
    result_ai_type = ai::kAIStateMonsterBigBoss;
    break;
  case 8: //blind, walk walk walk
    stage_stay_col =  -1;
    result_ai_type = ai::kAIStateMonsterWarrior;
    unit->set_guard_trigger(new ai::Trigger(unit, kTriggerGuard, kTriggerTroopNone));
    unit->set_near_attack_trigger(new ai::Trigger(unit, kTriggerAttack, kTriggerTroopNone));
    break;
  default:
    assert(false);
  }

  if (battle::BattleController::GetInstance().getBattleType() == battle::kBattleType_SandBox)
  {
    stage_stay_col = 1;
    result_ai_type = ai::kAIStateDefault;
    //unit->set_last_motion_state(ai::kMotionStateIdle);
    //ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateIdle);
  }

  unit->set_stage_stay_column(stage_stay_col);
  unit->set_ai_orig_state(result_ai_type);
  unit->set_ai_state(result_ai_type);


  if(pMonsterData->GetBodyHeight() > 1)
  {
    for(int i = 1; i < pMonsterData->GetBodyHeight(); ++i)
    {
      unit->add_offset_point(ccp(0, i * (battle::kMapTileMaxHeight + 10)));
    }
  }
  // insert new active monsters
  //(dynamic_cast<battle::MonsterHub*>(owner_hub_))->troops()->InsertOneUnitIdIntoActiveIdsList(unit_id);
  
  // add it on battle field view 
  unit->AttachUnitIntoBattleView(owner_hub()->battle_view(), born_pos);
  
  // create all passive abilities
  unit->CreatePassiveAbilities();
}
  
// create next character after one character's death
void BornHub::CreateNextCharacterForBattleWithDestroyedMoveObjectId(uint_32 unitId)
{
  // destoryed one's sequence id
  uint_32 sId = (dynamic_cast<Character*>(this->owner_hub()->
                               troops()->GetObjectById(unitId)))->sequence_id();
  battle::BattleController::GetInstance().battle_data()->
                    set_characters_status(data::kCharacterStatusDestroyed, sId);

  if (battle::BattleController::GetInstance().getIsInEditorMode())
  {
    return;
  }
  
  // next  Reserved one's sequence id
  sId = battle::BattleController::GetInstance().battle_data()->GetNextReservedCharacterSequenceId();
  data::CharacterInfo* cInfo = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(sId);
  if (cInfo)
  {
    uint_32 unitId = this->owner_hub()->troops()->GetSubstitutionObjectID();
	assert(unitId != army::kUnexistTargetId);

    // init move object data
    this->CreateOneCharacterWithBornInfo(unitId,
                                         cInfo->card_id(),
                                         cInfo->sequence_id(),
                                         true);
	MoveObjBornEvent::Emit(unitId);
    // mark it as active unit
    battle::BattleController::GetInstance().battle_data()->
      set_characters_status(data::kCharacterStatusActivated, cInfo->sequence_id());
    // create all passive abilities
    this->createPassiveAbilities(unitId);
  }
}

// create next character 
void BornHub::CreateNextCharacterForLua(uint_32 unitId, uint_32 card_id, uint_32 level)
{
  // init move object data
  this->CreateOneCharacterWithBornInfoForLua(unitId, card_id, level);
  // mark it as active unit
  battle::BattleController::GetInstance().battle_data()->
    set_characters_status(data::kCharacterStatusActivated, 0);
  // create all passive abilities
  this->createPassiveAbilities(unitId);

  MoveObjBornEvent::Emit(unitId);
}
  
// create all characters for battle victory
void BornHub::CreateAllCharactersForBattleVictory()
{
  // create own characters -- 6 at most, 1 at least
  uint_32 team[data::kMaxCharacterCountInOneTeam] = {data::kUnexistCharacterId};

  int default_team_index = DataManager::GetInstance().user_info()->default_team_index();
  DataManager::GetInstance().user_info()->teams_ids(default_team_index, team);

  bool need_show_friend = false;
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
      
    }
    break;
  case battle::kBattleType_Pvp:
  case battle::kBattleType_SandBox:
    {
      need_show_friend = false;
    }
    break;
  default:
    break;
  }

  bool friendCreate = false;
  int id = army::kCharaterObject_StartId;
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i, ++id)
  {
    if (team[i]==data::kUnexistCharacterId/* && (i!=army::kFriendCharacterIndex || friendCreate)*/)
    {
      --id;
      continue;
    }

	owner_hub()->SwitchUnitToActiveIdsList(i);
    Character* unit = dynamic_cast<Character*>(owner_hub()->GetUnitById(i));
    if (!unit)
    {
      continue;
    }
    

    data::CharacterInfo* info = NULL;
    info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(team[i]);
    if (!info)
    {
      continue;
    }
    
    unit->set_card_id(info->card_id());
    unit->set_sequence_id(info->sequence_id());
    unit->set_character_info(info);
    // set active flag with true value to mark unit is on battle scene
    unit->set_ai_state(ai::kAIStateCelebrate);
    unit->InitXpData();    

    // choose garrison tile & calculate the born/destination point
    int_8  dest_tile_idx = this->getCelebrateDestinationTileIndexForCharacterById(id);
    // mark the garrison tile
    (dynamic_cast<army::Character*>(unit))->set_garrison_tile_index(dest_tile_idx);
    // calculate born & destination point, mark it then.
    cocos2d::CCPoint dest_pos = battle::GetGarrisonPointForMoveObjectInTile(dest_tile_idx);
    if (dest_tile_idx<2*battle::kMapColumnCount)
    {
      dest_pos = ccpAdd(dest_pos, ccp(-0.5f*battle::kMapTileAverageLength, 0));
    }
    cocos2d::CCPoint born_pos = ccp(dest_pos.x+iCC_DESIGN_SIZE.width/battle::kMapColumnCount,
                                    dest_pos.y);
    // attach unit on battle field view
    unit->AttachUnitIntoBattleView(owner_hub()->battle_view(), born_pos, true);
    // init z order & scale
    unit->anima_node()->setZOrder(battle::GetZorderByPosition(dest_pos));
    unit->anima_node()->setScale(battle::GetScaleByPosition(dest_pos));
  } 
}
  
// choose the destination for new born character
int_8 BornHub::getNewBornDestinationTileIndexForCharacterById(uint_32 unit_id)
{
  eAttackType attack_type = GetMoveObjectAttackTypeByCardId(this->owner_hub()->troops()->GetObjectById(unit_id)->card_id());
  int_8 count = this->owner_hub()->troops()->GetActiveMoveObjectsCountByAttackType(attack_type);
  assert(count>0);
  int_8 rowIndex = 0;
  int_8 columnIndex = 0;
  switch (attack_type)
  {
    case kAttackTypeAttack: // in first line of right part
    {
      columnIndex = 0.5f*battle::kMapColumnCount + count/(battle::kMapRowCount+1);
      rowIndex = ((count>battle::kMapRowCount)?(count+1):(count-1))%battle::kMapRowCount;
    }
      break;
      
    case kAttackTypeHeal: // in middle tile of right tile
    {
      columnIndex = battle::kMapColumnCount-2 + count/(battle::kMapRowCount+1);
      rowIndex = count%battle::kMapRowCount;
    }
      break;
      
    case kAttackTypeShot: // in last line
    {
      columnIndex = battle::kMapColumnCount-1 - count/(battle::kMapRowCount+1);
      rowIndex = ((count>battle::kMapRowCount)?(count+1):(count-1))%battle::kMapRowCount;
    }
      break;
      
    default:
      assert(false);
      return battle::kUnexistTileIndex;
      break;
  }
  if (!owner_hub()->IsRightSideHub())
  {
    columnIndex = battle::kMapColumnCount - columnIndex - 1;
  }
  
  return battle::GetTileIndexByTileCoordinatePos(ccp(columnIndex, rowIndex));
}
  
// choose the destination for new reserve character
int_8 BornHub::getNewBornDestinationTileIndexForReserveCharacterById(uint_32 unit_id)
{
  for (int x = battle::kMapColumnCount-1; x>battle::kMapColumnCount/2; --x)
  {
    for (int y = battle::kMapRowCount-1; y>=0; --y)
    {
      int_8 tile_idx = battle::GetTileIndexByTileCoordinatePos(ccp(x, y));
      if (battle::BattleController::GetInstance().
          tiled_map()->DispatchCharacterGarrisonTile(unit_id, tile_idx))
      {
        return tile_idx;
      }
    }
  }
  assert(false);
  return battle::kUnexistTileIndex;
}
  
// choose the celebrate destination for battle winner(characters)
int_8 BornHub::getCelebrateDestinationTileIndexForCharacterById(uint_32 unit_id)
{
  int_8 startIdx = battle::kMapTilesCount-battle::kMapColumnCount+1;
  if (unit_id>3) {
    startIdx = startIdx-battle::kMapColumnCount-3;
  }
  return (startIdx+unit_id);
}
  
// create passive ability for unit
void BornHub::createPassiveAbilities(uint_32 unitId)
{
  MoveObject* unit = owner_hub()->GetUnitById(unitId);
  assert(unit);
  unit->CreatePassiveAbilities();
}

uint_32 BornHub::CreateOneSummonWithBornInfoAtIndex(
	uint_32 card_id, ai::eAIStateType intent_type, int_8 tileIdx, uint_16 level)
{
	ai::eAIBornLine born_line = ai::eAIBornLine(tileIdx / battle::kMapColumnCount);
	if (born_line == ai::kAIBornRandom)
	{
		born_line = (ai::eAIBornLine)random_int(ai::kAIBornBottom);
	}

	cocos2d::CCPoint born_pos = battle::GetGarrisonPointForMoveObjectInTile(tileIdx);

	assert(battle::IsTileCoordinateInRange(battle::GetTileCoordinatePosByTileIndex(tileIdx)));

	army::MoveObject* moveObj = owner_hub()->CreateSummonUnit();
	army::Summon* unit = dynamic_cast<army::Summon*>(moveObj);
	assert(unit);

	CreateOneMonsterWithBornInfoAtPos(
		unit, card_id, intent_type, born_pos, level, 0, 0, 0);

	unit->set_born_line(born_line);

	return unit->move_object_id();
}

} // namespace army
} // namespace taomee
