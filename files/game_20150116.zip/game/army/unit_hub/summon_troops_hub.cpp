

#include "game/army/unit_hub/summon_troops_hub.h"
#include "game/army/unit/summon.h"

namespace taomee {
namespace army {

SummonTroopsHub::SummonTroopsHub(battle::BattleHub* own, uint_32 start_id, uint_32 end_id)
	: TroopsHub( own, start_id, end_id)
{
	for ( int i = 0; i < 1; ++i)
	{
		Summon* newObj = newObj = new Summon(owner_hub_, army::kUnexistTargetId );
		idle_loop_.push(newObj);
	}
}

SummonTroopsHub::~SummonTroopsHub()
{

}

MoveObject* SummonTroopsHub::createObjectImpl(uint_32 id)
{
	Summon* summon = new Summon(owner_hub_, id);
	return summon;
}

}
}