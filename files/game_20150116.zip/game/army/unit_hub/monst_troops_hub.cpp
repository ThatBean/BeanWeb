

#include "game/army/unit_hub/monst_troops_hub.h"
#include "game/army/unit/monster.h"

namespace taomee {
namespace army {

MonsterTroopsHub::MonsterTroopsHub(battle::BattleHub* own, uint_32 start_id, uint_32 end_id)
	: TroopsHub( own, start_id, end_id)
{
	for ( int i = 0; i < 10; ++i)
	{
		MoveObject* newObj = newObj = new Monster(owner_hub_, army::kUnexistTargetId );
		idle_loop_.push(newObj);
	}
}

MonsterTroopsHub::~MonsterTroopsHub()
{

}

MoveObject* MonsterTroopsHub::createObjectImpl(uint_32 id)
{
	MoveObject* monster = new Monster(owner_hub_, id);
	return monster;
}

}
}