#ifndef ACTOR_TRIGGER_PREDEFINED_H
#define ACTOR_TRIGGER_PREDEFINED_H

#include "actor_trigger.h"
#include "actor_trigger_module.h"

namespace actor {

  ActorTrigger* GetPredefinedTrigger()
  {
    return 0;
  }

} // namespace actor


#endif // ACTOR_TRIGGER_PREDEFINED_H
