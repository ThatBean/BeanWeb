#ifndef ACTOR_TRIGGER_MODULE_H
#define ACTOR_TRIGGER_MODULE_H


#include "engine/base/basictypes.h"


namespace actor 
{
  
  class Actor;

  enum eActorTriggerModule
  {
    kActorTriggerModuleFraction,
    kActorTriggerModuleGeometry,
    kActorTriggerModuleStatus,
    kActorTriggerModuleScript,  //lua
    kActorTriggerModuleActive,  //will cause target status change, maybe a bad idea
    kActorTriggerModuleSort,  //
    kActorTriggerModule
  };

  enum eActorTriggerFactionFlag
  {
    kActorTriggerFactionFlagAlly  = 1 << 0,
    kActorTriggerFactionFlagEnemy = 1 << 1,
    kActorTriggerFactionFlagSelf  = 1 << 2,
    kActorTriggerFactionFlag
  };
  

  enum eActorTriggerStatusFlag
  {
    kActorTriggerStatusFlagWeak  = 1 << 0,
    kActorTriggerStatusFlagDead  = 1 << 1,
    kActorTriggerStatusFlagIdle  = 1 << 2,
    kActorTriggerStatusFlag
  };


  class  ActorTriggerModuleData
  {
  public:
    static const uint_32 TARGET_MODULE_TYPE;
    
    virtual ~ActorTriggerModuleData() {}

    void      SetTriggerFlag(uint_32 trigger_flag) { trigger_flag_ = trigger_flag; }
    uint_32   GetTriggerFlag() { return trigger_flag_; }

  private:
    uint_32 trigger_flag_; 
  };



  class ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  public:
    ActorTriggerModule() {}
    ~ActorTriggerModule() {}

    virtual bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data, std::list<Actor*>* actor_list) = 0;

    eActorTriggerModule   GetTriggerModuleType() { return trigger_module_type_; }

  private:
    static const eActorTriggerModule trigger_module_type_;
    
  };

  ActorTriggerModule* GetActorTriggerModule(eActorTriggerModule module_type);

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_H