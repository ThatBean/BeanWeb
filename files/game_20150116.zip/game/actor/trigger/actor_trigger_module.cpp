#include "actor_trigger_module.h"


#include "trigger_module/actor_trigger_module_geometry.h"

namespace actor 
{

  ActorTriggerModule* GetActorTriggerModule(eActorTriggerModule module_type)
  {
    switch(module_type)
    {
    case kActorTriggerModuleGeometry:
      return ActorTriggerModuleGeometry::Instance();
      break;
    default:
      return 0;
      break;
    }
  }

}  // namespace actor