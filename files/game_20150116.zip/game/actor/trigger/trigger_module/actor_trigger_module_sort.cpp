#include "actor_trigger_module_sort.h"

#include "game/actor/actor.h"

namespace actor 
{
  //const eActorTriggerModule ActorTriggerModuleSort::trigger_module_type_ = kActorTriggerModuleSort;
  //const uint_32 ActorTriggerModuleDataSort::TARGET_MODULE_TYPE = kActorTriggerModuleSort;
  
  ActorTriggerModuleSort* ActorTriggerModuleSort::Instance()
  {
    static ActorTriggerModuleSort instance;
    return &instance;
  }

  ActorTriggerModuleSort::ActorTriggerModuleSort()
  {

  }

  ActorTriggerModuleSort::~ActorTriggerModuleSort()
  {

  }

  bool ActorTriggerModuleSort::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataSort* trigger_module_data = dynamic_cast<ActorTriggerModuleDataSort*>(trigger_module_data_);

    assert(trigger_module_data);

    uint_32 trigger_flag = trigger_module_data->GetTriggerFlag();

    if (trigger_flag & kActorTriggerSortFlagDistance) UpdateDistance(actor, trigger_module_data, actor_list);
    if (trigger_flag & kActorTriggerSortFlagHealth) UpdateHealth(actor, trigger_module_data, actor_list);
    
    return (actor_list->size() > 0);
  }


  bool     SortByDistanceNearFirst(Actor* actor_1, Actor* actor_2)
  {
    //return actor_1->GetActorData()->GetMotionData()->GetPosition()
    return false;
  }







  template<class Comparable>
  class ActorListSort
  {
  public:
    virtual Comparable GetActorData(Actor* actor) = 0;

  public:
    typedef pair<Comparable, Actor*> SortPair;
    static bool Compare(SortPair p1, SortPair p2) { return p1.first < p2.first; }
    std::list<Actor*>* CreateSortList(std::list<Actor*>* actor_list)
    {
      CreateSortList(actor_list);
      SortList();
      return ResultList();
    }
  private:
    std::vector<SortPair>* sort_list_;
    void CreateSortList(std::list<Actor*>* actor_list)
    {
      std::list<Actor*>::iterator iterator = actor_list->begin();
      while (iterator != actor_list->end())
      {
        Actor* actor = *iterator;
        Comparable actor_data = GetActorData(actor);
        sort_list_->push_back(SortPair(actor_data, actor));
      }
    }
    std::list<Actor*>* ResultList()
    {
      std::list<Actor*>* result_actor_list = new std::list<Actor*>;
      std::vector<SortPair>::iterator iterator = sort_list_->begin();
      while (iterator != sort_list_->end())
        result_actor_list->push_back(*iterator->second);
      return result_actor_list;
    }
    void SortList() { sort(sort_list_->begin(), sort_list_->end(), Compare); }
  };

  class ActorListSortHyHealth : public ActorListSort<int>
  {
  public:
    virtual int GetActorData(Actor* actor) { return actor->GetActorData()->GetBasicData()->GetCurrentHealth(); }
  };





  void     ActorTriggerModuleSort::UpdateDistance(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list)
  {
    //sort by distance

    std::list<Actor*>*




    //actor_list->sort();

  }
  void     ActorTriggerModuleSort::UpdateHealth(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list)
  {
    //sort by health

  }

}  // namespace actor