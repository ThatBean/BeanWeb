#include "actor_trigger_module_geometry.h"

#include "game/actor/actor.h"

namespace actor 
{
  const eActorTriggerModule ActorTriggerModuleGeometry::trigger_module_type_ = kActorTriggerModuleGeometry;
  const uint_32 ActorTriggerModuleDataGeometry::TARGET_MODULE_TYPE = kActorTriggerModuleGeometry;
  
  ActorTriggerModuleGeometry* ActorTriggerModuleGeometry::Instance()
  {
    static ActorTriggerModuleGeometry instance;
    return &instance;
  }

  ActorTriggerModuleGeometry::ActorTriggerModuleGeometry()
  {

  }

  ActorTriggerModuleGeometry::~ActorTriggerModuleGeometry()
  {

  }

  bool ActorTriggerModuleGeometry::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataGeometry* trigger_module_data = dynamic_cast<ActorTriggerModuleDataGeometry*>(trigger_module_data_);

    assert(trigger_module_data);

    uint_32 trigger_flag = trigger_module_data->GetTriggerFlag();

    if (trigger_flag & kActorTriggerGeometryFlagDistance) UpdateDistance(actor, trigger_module_data, actor_list);
    if (trigger_flag & kActorTriggerGeometryFlagDirection) UpdateDirection(actor, trigger_module_data, actor_list);
    if (trigger_flag & kActorTriggerGeometryFlagLocation) UpdateLocation(actor, trigger_module_data, actor_list);
    
    return (actor_list->size() > 0);
  }

  void     ActorTriggerModuleGeometry::UpdateDistance(Actor* actor, ActorTriggerModuleDataGeometry* trigger_module_data, std::list<Actor*>* actor_list)
  {
    cocos2d::CCPoint actor_position = actor->GetActorData()->GetMotionData()->GetPosition();
    float distance_min = trigger_module_data->GetDistanceMin();
    float distance_max = trigger_module_data->GetDistanceMax();

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* ref_actor = *iterator;

      float distance = ref_actor->GetActorData()->GetMotionData()->GetPosition().getDistance(actor_position);
      bool is_filter = (distance >= distance_min && distance <= distance_max);

      if (is_filter)
        iterator = actor_list->erase(iterator);
      else
        ++iterator;
    }
  }
  void     ActorTriggerModuleGeometry::UpdateDirection(Actor* actor, ActorTriggerModuleDataGeometry* trigger_module_data, std::list<Actor*>* actor_list)
  {
  }
  void     ActorTriggerModuleGeometry::UpdateLocation(Actor* actor, ActorTriggerModuleDataGeometry* trigger_module_data, std::list<Actor*>* actor_list)
  {
  }

}  // namespace actor