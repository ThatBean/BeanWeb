#ifndef ACTOR_CONTROL_AUTO_DATA_H
#define ACTOR_CONTROL_AUTO_DATA_H

#include "game/actor/actor_adapter.h"

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;

  /*
    About Actor Control Auto:
  
    Auto control of an actor will be achieved by a system in Lua "routine"

    During Actor Exist Time:
    --  Routine Part: Package of routines
    --  --  Routine: Sets of checks and operations for actor logic data & state
  */


  class ActorControlAutoData  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    virtual void Update(float delta_time);

  private:
    int current_routine_part_id_;
    int current_routine_id_;

    //state data, may be used in current state
    uint_32          routine_part_start_timestamp_;
    uint_32          routine_start_timestamp_;
  };

} // namespace actor


#endif // ACTOR_CONTROL_AUTO_DATA_H