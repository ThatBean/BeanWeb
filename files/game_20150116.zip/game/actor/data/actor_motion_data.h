#ifndef ACTOR_MOTION_DATA_H
#define ACTOR_MOTION_DATA_H

#include "game/actor/actor_adapter.h"

#include "cocos2d.h"

namespace actor {

  class Actor;

  class ActorMotionData
  {
  public:
    ActorMotionData();
    ~ActorMotionData();

    void        SetIsMotionAnimationEnded(bool is_motion_animation_finished) { is_motion_animation_finished_ = is_motion_animation_finished; }
    bool        GetIsMotionAnimationEnded() { return is_motion_animation_finished_; }

    void        SetIsWeakStatusAnimation(bool is_weak_status_animation) { is_weak_status_animation_ = is_weak_status_animation; }
    bool        GetIsWeakStatusAnimation() { return is_weak_status_animation_; }

    void              SetCachedTargetPosition(cocos2d::CCPoint* target_position) { cached_target_position_ = target_position; } //no need to delete last target position, it's stored in control data
    cocos2d::CCPoint* GetCachedTargetPosition() { return cached_target_position_; }

    void              SetCachedMoveSpeedVector(cocos2d::CCPoint* move_speed_vector) { cached_move_speed_vector_ = *move_speed_vector; }
    cocos2d::CCPoint* GetCachedMoveSpeedVector() { return &cached_move_speed_vector_; }

    //currently in adapter
    void                 SetPosition(cocos2d::CCPoint position);
    cocos2d::CCPoint     GetPosition();

    void        SetMoveSpeedBase(float move_speed_base);
    float       GetMoveSpeedBase();

    taomee::SkeletonAnimation* GetAnimationNode();
    
    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }

  private:
    bool    is_motion_animation_finished_;
    
    bool    is_weak_status_animation_;

    //float                move_speed_base_;

    cocos2d::CCPoint*    cached_target_position_;  //current 
    cocos2d::CCPoint     cached_move_speed_vector_;  //current 

    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*        actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_MOTION_DATA_H