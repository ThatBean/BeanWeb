#ifndef ACTOR_DATA_H
#define ACTOR_DATA_H

#include "actor_basic_data.h"
#include "actor_specified_data.h"
#include "actor_control_data.h"
#include "actor_logic_data.h"
#include "actor_motion_data.h"

#include "game/actor/actor_adapter.h"

#include "cocos2d.h"



namespace actor {

  class Actor;
  class ActorTrigger;

  class ActorData
  {
  public:
    ActorData(Actor* actor);
    ~ActorData();

    void Init();

    void Update(float delta_time);

    ActorBasicData*   GetBasicData() { return basic_data_; }
    ActorSpecifiedData* GetSpecifiedData() { return specified_data_; }

    ActorControlDataBase* GetUserControlData() { return user_control_data_; };
    ActorControlData* GetControlData() { return control_data_; }
    ActorLogicData*   GetLogicData() { return logic_data_; }
    ActorMotionData*  GetMotionData() { return motion_data_; }

    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter);
  private:
    Actor*               actor_;

    ActorBasicData*       basic_data_;
    ActorSpecifiedData*   specified_data_;

    //Notice:
    // data in ActorData should avoid obtaining a direct pointer of Actor (Actor* actor_)
    ActorControlDataBase*     user_control_data_; //control data directly obtained by user operation(touch), processed by Control-Manual
    ActorControlData*     control_data_;  //processed control data to be used in logic / motion
    ActorLogicData*       logic_data_;  //logic input and output, (directly change this can affect logic in next Logic Update)
    ActorMotionData*      motion_data_;
    //ActorBuffData*        buff_data_; //store actor buff data
    //ActorSkillData*       skill_data_;  //
    
  };



} // namespace actor


#endif // ACTOR_DATA_H