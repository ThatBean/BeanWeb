#ifndef ACTOR_LOGIC_DATA_H
#define ACTOR_LOGIC_DATA_H

namespace actor {

  class Actor;
  class ActorTrigger;

  class ActorLogicData
  {
  public:
    ActorLogicData();
    ~ActorLogicData();
    
    void Init();


    void SetIsStateIdle(bool is_state_idle) { is_state_idle_ = is_state_idle; }
    bool GetIsStateIdle() { return is_state_idle_; }

    void SetIsMuteMove(bool is_mute_move) { is_mute_move_ = is_mute_move; }
    bool GetIsMuteMove() { return is_mute_move_; }
    
    void SetIsMuteAttack(bool is_mute_attack) { is_mute_attack_ = is_mute_attack; }
    bool GetIsMuteAttack() { return is_mute_attack_; }

    void SetIsImmuneAttack(bool is_immune_attack) { is_immune_attack = is_immune_attack_; }
    bool GetIsImmuneAttack() { return is_immune_attack_; }

    void SetGuardTrigger(ActorTrigger* trigger) { guard_trigger_ = trigger; }
    ActorTrigger* GetGuardTrigger() { return guard_trigger_; }

    void SetAttackTriggerMelee(ActorTrigger* trigger) { attack_trigger_melee_ = trigger; }
    ActorTrigger* GetAttackTriggerMelee() { return attack_trigger_melee_; }
    void SetAttackTriggerHeal(ActorTrigger* trigger) { attack_trigger_heal_ = trigger; }
    ActorTrigger* GetAttackTriggerHeal() { return attack_trigger_heal_; }
    void SetAttackTriggerRanged(ActorTrigger* trigger) { attack_trigger_ranged_ = trigger; }
    ActorTrigger* GetAttackTriggerRanged() { return attack_trigger_ranged_; }

    void SetAttackTriggerPower(ActorTrigger* trigger) { attack_trigger_power_ = trigger; }
    ActorTrigger* GetAttackTriggerPower() { return attack_trigger_power_; }
    void SetAttackTriggerSpecial(ActorTrigger* trigger) { attack_trigger_special_ = trigger; }
    ActorTrigger* GetAttackTriggerSpecial() { return attack_trigger_special_; }


  private:
    bool is_state_idle_;

    bool is_mute_move_;
    bool is_mute_attack_;

    bool is_immune_attack_;

    ActorTrigger*       guard_trigger_;  //target searching by guard range, mostly used in Idle/Move

    //below trigger used for logic attack state, target selection process
    ActorTrigger*       attack_trigger_melee_;  //normal attack, for warrior/knight
    ActorTrigger*       attack_trigger_heal_;  //normal attack, for priest
    ActorTrigger*       attack_trigger_ranged_;  //normal attack, for archer/wizard

    ActorTrigger*       attack_trigger_power_;  //powerful normal attack
    ActorTrigger*       attack_trigger_special_;  //special attack (The Skill of this Actor)
  };
} // namespace actor


#endif // ACTOR_LOGIC_DATA_H