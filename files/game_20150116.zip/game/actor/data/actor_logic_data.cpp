#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorLogicdata
  ActorLogicData::ActorLogicData()
    :is_state_idle_(true),
    
    is_mute_move_(false),
    is_mute_attack_(false),
    is_immune_attack_(false),
    
    guard_trigger_(NULL),
    attack_trigger_melee_(NULL),
    attack_trigger_heal_(NULL),
    attack_trigger_ranged_(NULL),
    attack_trigger_power_(NULL),
    attack_trigger_special_(NULL)
  {
    Init();
  }

  ActorLogicData::~ActorLogicData()
  {
    if (guard_trigger_) delete guard_trigger_;

    if (attack_trigger_melee_) delete attack_trigger_melee_;
    if (attack_trigger_heal_) delete attack_trigger_heal_;
    if (attack_trigger_ranged_) delete attack_trigger_ranged_;

    if (attack_trigger_power_) delete attack_trigger_power_;
    if (attack_trigger_special_) delete attack_trigger_special_;
  }

  void ActorLogicData::Init()
  {
  }


  //ActorLogicdata

} // namespace actor