#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorMotionData
  ActorMotionData::ActorMotionData()
    :is_weak_status_animation_(false),
    is_motion_animation_finished_(true),
    cached_target_position_(NULL)
  {

  }

  ActorMotionData::~ActorMotionData()
  {
    if (cached_target_position_) delete cached_target_position_;
  }

  void ActorMotionData::SetPosition(cocos2d::CCPoint position)
  {
    actor_adapter_->set_current_pos(position);
  }
  cocos2d::CCPoint ActorMotionData::GetPosition()
  {
    return actor_adapter_->current_pos();
  }

  void ActorMotionData::SetMoveSpeedBase(float move_speed_base)
  {
    assert(false);  //currently should not set this value
  }

  float ActorMotionData::GetMoveSpeedBase()
  {
    return actor_adapter_->mover_speed_value();
  }


  taomee::SkeletonAnimation* ActorMotionData::GetAnimationNode()
  {
    return actor_adapter_->anima_node();
  }

  //ActorMotionData


} // namespace actor