#ifndef ACTOR_SPECIFIED_DATA_H
#define ACTOR_SPECIFIED_DATA_H

#include "cocos2d.h"

namespace actor {

  class Actor;

  class ActorSpecifiedData  //a data class for each type of actor 
  {
  public:
    ActorSpecifiedData()
    {
    }

    virtual void Update(float delta_time) = 0;
  };

  //######################################################################################################
  //######################################################################################################
  //used in character logic control flow
  

  class ActorSpecifiedDataCharacter : public ActorSpecifiedData
  {
  public:
    virtual void Update(float delta_time) {}
  };




  //######################################################################################################
  //######################################################################################################

  class ActorSpecifiedDataEnemyPawn : public ActorSpecifiedData
  {
  public:
    virtual void Update(float delta_time) {}
  };




  //######################################################################################################
  //######################################################################################################


  class ActorSpecifiedDataEnemyBoss : public ActorSpecifiedData
  {
  public:
    virtual void Update(float delta_time) {}
  };

} // namespace actor


#endif // ACTOR_SPECIFIED_DATA_H