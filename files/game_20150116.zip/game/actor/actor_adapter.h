#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H

#include "game/army/unit/move_object.h"

namespace actor {

  typedef taomee::army::MoveObject ActorAdapter;

} // namespace actor


#endif // ACTOR_ADAPTER_H
