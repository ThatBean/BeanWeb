#ifndef ACTOR_LOGIC_STATE_H
#define ACTOR_LOGIC_STATE_H

#include "game/actor/template_class/state.h"

namespace actor {

  class Actor;

  enum eActorLogicState
  {
    kActorLogicStateIdle,
    kActorLogicStateMove,
    kActorLogicStateAttack,
    kActorLogicStateSpecial,
    kActorLogicStateBorn,
    kActorLogicStateDead,
    kActorLogicState
  };


  //-- near attacker ai stay time
  const int TIME_ENEMY_STAY_MELEE = 5;

  //-- range attacker ai stay time
  const int TIME_ENEMY_STAY_RANGED = 15;

  //-- assassin attacker ai search row time
  const int TIME_ENEMY_SEARCH_TARGET = 3;



  class LogicState : public State<Actor>
  {
  public:
    virtual ~LogicState() {}

    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }
  };

  LogicState* GetActorLogicState(eActorLogicState state_type);

  //{CONDITIONALLY} 
  //Update Attack/GuardTrigger
  bool CommonCheckGuardTrigger(Actor* actor);  //return is trigger triggered
  bool CommonCheckAttackTrigger(Actor* actor);  //return is trigger triggered

} // namespace actor


#endif // ACTOR_LOGIC_STATE_H
