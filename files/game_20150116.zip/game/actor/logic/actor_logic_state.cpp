#include "actor_logic_state.h"

#include "logic_state/actor_logic_state_idle.h"
#include "logic_state/actor_logic_state_move.h"

#include "game/actor/actor.h"

namespace actor {
  const int LogicState::STATE_TYPE = kActorLogicState;

  LogicState* GetActorLogicState(eActorLogicState state_type)
  {
    switch(state_type)
    {
    case kActorLogicStateIdle:
      return LogicStateIdle::Instance();
      break;
    case kActorLogicStateMove:
      return LogicStateMove::Instance();
      break;
    default:
      return 0;
      break;
    }
  }


  //{CONDITIONALLY} 
  //Update Attack/GuardTrigger
  bool CommonCheckGuardTrigger(Actor* actor)
  {
    bool is_triggered = false;
    //actor
    ActorLogicData* logic_data = actor->GetActorData()->GetLogicData();

    if(logic_data->GetGuardTrigger())
    {
      logic_data->GetGuardTrigger()->Update();
      is_triggered |= logic_data->GetGuardTrigger()->GetIsTriggered();
    }

    return is_triggered;
  }

  bool CommonCheckAttackTrigger(Actor* actor)
  {
    bool is_triggered = false;
    //actor
    ActorLogicData* logic_data = actor->GetActorData()->GetLogicData();

    if(logic_data->GetAttackTriggerMelee())
    {
      logic_data->GetAttackTriggerMelee()->Update();
      is_triggered |= logic_data->GetAttackTriggerMelee()->GetIsTriggered();
    }

    if(logic_data->GetAttackTriggerHeal())
    {
      logic_data->GetAttackTriggerHeal()->Update();
      is_triggered |= logic_data->GetAttackTriggerHeal()->GetIsTriggered();
    }

    if(logic_data->GetAttackTriggerRanged())
    {
      logic_data->GetAttackTriggerRanged()->Update();
      is_triggered |= logic_data->GetAttackTriggerRanged()->GetIsTriggered();
    }

    return is_triggered;
  }


} // namespace actor