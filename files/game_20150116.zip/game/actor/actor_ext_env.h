#ifndef ACTOR_EXT_ENV_H
#define ACTOR_EXT_ENV_H

#include "engine/base/basictypes.h"

namespace actor {

  class Actor;

  // the map / battlefield where actors live in (Actor Pool)
  class ActorExtEnv  //ActorExternalEnvironment
  {
  public:
    ActorExtEnv();
    ~ActorExtEnv();

    void      Update(float delta_time);

    int       AddActor(Actor* actor); //will return actor_id
    Actor*    GetActorById(int actor_id);
    Actor*    RemoveActorById(int actor_id);
    
    int                       GetActorCount();
    std::list<Actor*>*        GetActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }

    std::map<int, Actor*>*    GetActorMap() { return &actor_map_; }
    std::list<int>*           GetActorIdList() { return &actor_id_list_; }

    //std::map<int, Actor*>*    GetActorListByType(specific_actor_type actor_type);
    //std::list<int>*           GetActorIdListByType(specific_actor_type actor_type);

  private:
    std::map<int, Actor*>     actor_map_;
    std::list<int>            actor_id_list_;
    int                       actor_count_;
  };


} // namespace actor


#endif // ACTOR_EXT_ENV_H