#include "actor.h"

#include "logic/logic_state/actor_logic_state_idle.h"
#include "logic/logic_state/actor_logic_state_move.h"

#include "engine/base/basictypes.h"
//#include "engine/script/lua_tinker_manager.h"

namespace actor {


  Actor::Actor()
  {
    Init();
  }

  Actor::~Actor()
  {
    delete actor_data_;
    delete actor_control_;
    delete logic_state_machine_;
    delete motion_state_machine_;

  }

  void Actor::Init()
  {
    actor_data_ = new ActorData(this);
    
    actor_control_ = new ActorControl(this);

    logic_state_machine_ = new LogicStateMachine(this);
    motion_state_machine_ = new MotionStateMachine(this);
    //logic_state_machine_->ChangeState(LogicStateIdle::Instance());
    //printf("%d", logic_state_machine_->GetCurrentLogicStateType());
    //int near_attacker_ai_stay_time_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/ai_config.lua", "GetNearAttackerAIStayTime");
  }

  void Actor::Update(float delta_time)
  {
    //update mostly timers in ActorData
    actor_data_->Update(delta_time);

    
    //deal with user control and auto
    actor_control_->Update();
    
    //update actor-side buff data&logic
    //actor_buff_->Update(); 

    //update actor-side skill data&logic
    //actor_skill_->Update(); 
    
    //Manage Both Logic State & Motion State 
    logic_state_machine_->Update(delta_time);
    
    //Manage Position and Animation
    motion_state_machine_->Update(delta_time);
  }

} // namespace actor