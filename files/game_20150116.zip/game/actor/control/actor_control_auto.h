#ifndef ACTOR_CONTROL_AUTO_H
#define ACTOR_CONTROL_AUTO_H

namespace actor {
  class Actor;
  
  void UpdateAutoSpecified(Actor* actor, float delta_time);

  void UpdateAutoCharacter(Actor* actor, float delta_time);
  void UpdateAutoEnemyPawn(Actor* actor, float delta_time);
  void UpdateAutoEnemyBoss(Actor* actor, float delta_time);

} // namespace actor

#endif // ACTOR_CONTROL_AUTO_H
