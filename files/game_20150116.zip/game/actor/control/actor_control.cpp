#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"


namespace actor {

  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor),
    actor_control_type_(kActorControl)
  {

  }

  ActorControl::~ActorControl()
  {

  }

  void ActorControl::Update()
  {
    switch (actor_control_type_)
    {
    case kActorControlManual:
      UpdateManual();
      break;
    case kActorControlAuto:
      UpdateAuto();
      break;
    default:
      //strange...
      break;
    }

    result_logic_state_type_ = DecideLogicState();
    if (ControlLogicStateChange(result_logic_state_type_))
    {
      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type_));
    }

  }

  void ActorControl::UpdateManual()
  {
    ActorControlDataBase* user_control_data = actor_->GetActorData()->GetUserControlData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    if (user_control_data->IsSet())
    {
      if (user_control_data->GetPosition())
      {
        cocos2d::CCPoint* set_position = user_control_data->GetPosition();

        //check position

        control_data->SetPosition(set_position);
      }

      if (user_control_data->GetTarget() != -1)
      {
        int set_target = user_control_data->GetTarget();

        //check target

        control_data->SetTarget(set_target);
      }
      
      if (user_control_data->GetSkill() != -1)
      {
        int set_skill = user_control_data->GetSkill();

        //check skill

        control_data->SetSkill(set_skill);
      }
      
      user_control_data->Reset();
    }
  }

  void ActorControl::UpdateAuto()
  {
    //TODO
  }

  eActorLogicState ActorControl::DecideLogicState()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    bool is_set_position = control_data->IsSetPosition();
    bool is_set_skill = control_data->IsSetSkill();
    bool is_set_target = control_data->IsSetTarget();

    //skill > target > position
    if (is_set_skill)
      return kActorLogicStateAttack;
    if (is_set_target)
      return kActorLogicStateMove;
    if (is_set_position)
      return kActorLogicStateMove;
    
    return kActorLogicState;
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState new_logic_state)
  {
    if (new_logic_state == kActorLogicState)
      return false;

    ActorLogicData* logic_data = actor_->GetActorData()->GetLogicData();

    switch(new_logic_state)
    {
    case kActorLogicStateMove:
      if (logic_data->GetIsMuteMove())
        return false;
      break;
    case kActorLogicStateAttack:
      if (logic_data->GetIsMuteAttack())
        return false;
      break;
    default:
      break;
    }

    return true;
  }
} // namespace actor