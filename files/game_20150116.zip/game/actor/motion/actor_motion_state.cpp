#include "actor_motion_state.h"

namespace actor {

  const int MotionState::STATE_TYPE = kActorMotionState;
} // namespace actor