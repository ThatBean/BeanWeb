#ifndef ACTOR_MOTION_ANIMATION_OPERATION_H
#define ACTOR_MOTION_ANIMATION_OPERATION_H

#include "game/actor/template_class/state_machine.h"
#include "cocos2d.h"

namespace actor {
  class Actor;

  const float ACTOR_DIRECTION_CHANGE_THRESHOLD = 20;  //the minimum distance needed for a direction change


  //this is a collection of useful operations for quick set actor animation
  //all motion animation operation should be here, instead of ActorMotionData

  void ChangeAnimation(Actor* actor, std::string animation_name, const int cycle_count = -1, const float speed = 1.0f);
  void ResetAnimationDirection(Actor* actor);
  void SetAnimationPosition(Actor* actor, cocos2d::CCPoint position, bool is_change_direction = true);  //place actor at position, and set direction
  void UpdateMoveToPositionCached(Actor* actor, cocos2d::CCPoint* target_position, float delta_time, float move_speed_modifier = 1.0f);

} // namespace actor

#endif // ACTOR_MOTION_ANIMATION_OPERATION_H
