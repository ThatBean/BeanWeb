#ifndef ACTOR_MOTION_STATE_MACHINE_H
#define ACTOR_MOTION_STATE_MACHINE_H

#include "game/actor/template_class/state_machine.h"
#include "actor_motion_state.h"

namespace actor {
  class Actor;

  class MotionStateMachine : public StateMachine<Actor>
  {
  public:
    MotionStateMachine(Actor* actor) 
      : StateMachine<Actor>(actor) {}

    eActorMotionState GetCurrentMotionStateType();

    virtual void Update(float delta_time);

    virtual void ChangeState(State<Actor>* next_state);
  };

} // namespace actor

#endif // ACTOR_MOTION_STATE_MACHINE_H
