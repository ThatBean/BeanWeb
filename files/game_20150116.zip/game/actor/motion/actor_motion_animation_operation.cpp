﻿#include "actor_motion_animation_operation.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  //private method
  taomee::SkeletonAnimation* GetActorAnimationNode(Actor* actor)
  {
    taomee::SkeletonAnimation* actor_animation_node = actor->GetActorData()->GetMotionData()->GetAnimationNode();

    assert(actor_animation_node);

    return actor_animation_node;
  }

  void CheckAndCacheMoveToPosition(Actor* actor, cocos2d::CCPoint* target_position)
  {
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    taomee::SkeletonAnimation* actor_animation_node = GetActorAnimationNode(actor);
    bool is_change_direction = false;

    //check if target_position cached
    if (motion_data->GetCachedTargetPosition() != target_position)
    {
      motion_data->SetCachedTargetPosition(target_position);

      cocos2d::CCPoint move_speed_vector = ccpSub(*target_position, motion_data->GetPosition()).normalize();
      move_speed_vector.x *= motion_data->GetMoveSpeedBase();
      move_speed_vector.y *= motion_data->GetMoveSpeedBase();

      motion_data->SetCachedMoveSpeedVector(&move_speed_vector);
    }

    //check if direction change
    is_change_direction = motion_data->GetPosition().getDistance(*target_position) >= ACTOR_DIRECTION_CHANGE_THRESHOLD;

    //change direction
    if (is_change_direction)
    {
      if (target_position->x > motion_data->GetPosition().x)
        actor_animation_node->ChangeDirection(taomee::kDirectionRight);
      else
        actor_animation_node->ChangeDirection(taomee::kDirectionLeft);
    }
  }
  //private method


  //public method

  void ChangeAnimation(Actor* actor, std::string animation_name, const int cycle_count/* = -1 */, const float speed/* = 1.0f */)
  {
    taomee::SkeletonAnimation* actor_animation_node = GetActorAnimationNode(actor);
    actor_animation_node->Play(animation_name, cycle_count, speed);
  }


  void ResetAnimationDirection(Actor* actor)
  {
    taomee::SkeletonAnimation* actor_animation_node = GetActorAnimationNode(actor);
    actor_animation_node->ChangeDirection(taomee::kDirectionLeft);
  }


  void SetAnimationPosition(Actor* actor, cocos2d::CCPoint position, bool is_change_direction/* = true*/)
  {
    taomee::SkeletonAnimation* actor_animation_node = GetActorAnimationNode(actor);
    cocos2d::CCPoint actor_position = actor->GetActorData()->GetMotionData()->GetPosition();

    //change direction
    if (is_change_direction)
    {
      if (position.x > actor_position.x)
        actor_animation_node->ChangeDirection(taomee::kDirectionRight);
      else
        actor_animation_node->ChangeDirection(taomee::kDirectionLeft);
    }

    //set direction
    actor->GetActorData()->GetMotionData()->SetPosition(position);
  }


  void UpdateMoveToPositionCached(Actor* actor, cocos2d::CCPoint* target_position, float delta_time, float move_speed_modifier/* = 1.0f*/)
  {
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    bool is_change_direction = false;

    //check if needed to cache
    CheckAndCacheMoveToPosition(actor, target_position);

    //need move?
    //reduce enemy's speed and show warning
    if (actor->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionEnemy)
    {
      if (motion_data->GetPosition().x > taomee::battle::kMapRightMostX * 0.5)
      {
        move_speed_modifier *= 0.5;
        if (motion_data->GetPosition().x > taomee::battle::kMapRightMostX * 0.6)
          LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/WarningUI.lua", "AutoExtendWarningUIToBattleScene");
      }
    }

    //delta move
    cocos2d::CCPoint move_delta_vector = ccp(
      motion_data->GetCachedMoveSpeedVector()->x * delta_time * move_speed_modifier, 
      motion_data->GetCachedMoveSpeedVector()->y * delta_time * move_speed_modifier);

    SetAnimationPosition(actor, ccpAdd(motion_data->GetPosition(), move_delta_vector), is_change_direction);
  }

  //public method

} // namespace actor