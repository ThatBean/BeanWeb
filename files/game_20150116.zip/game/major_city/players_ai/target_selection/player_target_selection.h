//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_target_selection.h
//        Author: peteryu
//          Date: 2014/2/17 13:22
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/17      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_TARGET_SELECTION_H
#define PLAYER_TARGET_SELECTION_H

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/major_city/major_city_constants.h"

using namespace cocos2d;

namespace taomee {
namespace city {
namespace player_ai {

class PlayerTargetSelection
{
public:
  PlayerTargetSelection()
    : is_touched_(false),
      new_path_found_(false),
      target_pos_(CCPointZero),
      target_id_(kUnexistSimpleMoveObjectId),
      touch_pos_(CCPointZero)
  {}
  ~PlayerTargetSelection(){}

  void      set_is_touched(bool is_touched){is_touched_ = is_touched;}
  bool      is_touched(){return is_touched_;}
  
  bool      new_path_found() { return new_path_found_; }
  void      set_new_path_found(bool foundFlag) { new_path_found_ = foundFlag; }

  void      set_target_pos(CCPoint target_pos)
  {
    target_pos_ = target_pos;
  }
  CCPoint   target_pos(){return target_pos_;}
  bool      is_valid_target_pos(){return (target_pos_.x != 0 && target_pos_.y != 0);}

  void      set_target_id(uint_32 target_id){target_id_ = target_id;}
  uint_32   target_id(){return target_id_;}
  bool      is_valid_target_id(){return (target_id_ != kUnexistSimpleMoveObjectId);}

  void      set_touch_pos(CCPoint touch_pos){touch_pos_ = touch_pos;}
  CCPoint   touch_pos(){return touch_pos_;}
  bool      is_valid_touch_pos(){return (touch_pos_.x != 0 && touch_pos_.y != 0);}

private:
  bool      is_touched_;
  bool      new_path_found_;
  CCPoint   target_pos_;
  uint_32   target_id_;
  CCPoint   touch_pos_;
};

} // namespace player_ai
} // namespace city
} // namespace taomee


#endif
