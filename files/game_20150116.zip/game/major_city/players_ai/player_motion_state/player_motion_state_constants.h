//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_motion_state_constants.h
//        Author: peteryu
//          Date: 2014/2/13 13:18
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MOTION_STATE_CONSTANTS_H
#define PLAYER_MOTION_STATE_CONSTANTS_H


#include "engine/base/basictypes.h"

namespace taomee {
namespace city {
namespace player_ai {
  
enum ePlayerMotionStateType
{
  kPlayerMotionStateInvalid       = -1,
  kPlayerMotionStateIdle          = 1,
  kPlayerMotionStateMove          = 2,
  kPlayerMotionStateMoveWithPath  = 3,
  kPlayerMotionStateToNPC         = 4,
  kPlayerMotionStateMax
};

enum ePlayerMotionUpdateResult
{
  kPlayerMotionResultInvalid      = -1,
  kPlayerMotionResultActive       = 0,
  kPlayerMotionResultInactive     = 1,
  kPlayerMotionResultCompelted    = 2,
  kPlayerMotionResultFailed       = 3,
  kPlayerMotionResultMax
};  
  
#define IS_VALID_PLAYER_MOTION_STATE(state) (state > kPlayerMotionStateInvalid && state < kPlayerMotionStateMax)

static std::string GetPlayerMotionStateName(ePlayerMotionStateType type)
{
  switch(type)
  {
  case kPlayerMotionStateIdle:
    return "kPlayerMotionStateIdle";
  case kPlayerMotionStateMove:
    return "kPlayerMotionStateMove";
  case kPlayerMotionStateMoveWithPath:
    return "kPlayerMotionStateMoveWithPath";
  case kPlayerMotionStateToNPC:
    return "kPlayerMotionStateToNPC";
  default:
      return "kPlayerMotionError";
  }
  return "";
}

} // namespace player_ai
} // namespace city
} // namespace taomee

#endif
