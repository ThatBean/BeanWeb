//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ms_idle.cpp
//        Author: peteryu
//          Date: 2014/2/17 11:37
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/17      add
//////////////////////////////////////////////////////////////
#include "game/major_city/players_ai/player_motion_state/player_ms_idle.h"

#include "engine/base/random_helper.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/simple_move_object.h"

using namespace cocos2d;

namespace taomee {
namespace city {
namespace player_ai {

ePlayerMotionUpdateResult PlayerMotionStateIdle::OnEnter(SimpleMoveObject* unit)
{
  unit->ChangeAnimationToIndex(kPlayerAnimationTypeIdle);
  return kPlayerMotionResultActive;
}
    
ePlayerMotionUpdateResult PlayerMotionStateIdle::OnLeave(SimpleMoveObject* unit)
{
  return kPlayerMotionResultCompelted;
}

ePlayerMotionUpdateResult PlayerMotionStateIdle::Update(SimpleMoveObject* unit,
                                                        float delta_time)
{
  return kPlayerMotionResultCompelted;
}

} // namespace player_ai
} // namespace city
} // namespace taomee
