//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_motion_state.h
//        Author: peteryu
//          Date: 2014/2/13 13:16
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MOTION_STATE_H
#define PLAYER_MOTION_STATE_H

#include <assert.h>

#include "engine/base/basictypes.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"

namespace taomee {
namespace city { 

class SimpleMoveObject;

namespace player_ai {
  
class PlayerMotionState
{
public:
  PlayerMotionState() {}
  virtual ~PlayerMotionState() {}
  
public:
  virtual ePlayerMotionUpdateResult OnEnter(SimpleMoveObject* unit) = 0;
  virtual ePlayerMotionUpdateResult OnLeave(SimpleMoveObject* unit) = 0;
  virtual ePlayerMotionUpdateResult Update(SimpleMoveObject* unit, float delta_time) = 0;
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif // ChainChronicle_motion_state_h
