//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ms_move_with_path.cpp
//        Author: peteryu
//          Date: 2014/2/27 18:30
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/27      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_ai/player_motion_state/player_ms_move_with_path.h"

#include "engine/base/random_helper.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

using namespace cocos2d;

namespace taomee {
namespace city {
namespace player_ai {

ePlayerMotionUpdateResult PlayerMotionStateMoveWithPath::OnEnter( SimpleMoveObject* unit )
{
  if(unit->move_data()->is_have_path_point())
  {
    unit->move_data()->target_selection()->set_target_pos(unit->move_data()->get_next_path_point());
    PlayerMotionStateMove::OnEnter(unit);
  }
  else
  {
    assert(false);
  }
  return kPlayerMotionResultCompelted;
}

ePlayerMotionUpdateResult PlayerMotionStateMoveWithPath::Update(SimpleMoveObject* unit,
                                                                float delta_time)
{
  ePlayerMotionUpdateResult ret = PlayerMotionStateMove::Update(unit, delta_time);

  if(unit->move_data()->is_have_path_point())
  {
    // arrived on one path point or new path was setted, reset direction & speed
    if(ret == kPlayerMotionResultCompelted || unit->move_data()->target_selection()->new_path_found())
    {
      unit->move_data()->target_selection()->set_new_path_found(false);
      unit->move_data()->target_selection()->set_target_pos(unit->move_data()->get_next_path_point());
      ResetDirection(unit);
    }
    return kPlayerMotionResultActive;
  }

  return ret;
}

} // namespace player_ai
} // namespace city
} // namespace taomee
