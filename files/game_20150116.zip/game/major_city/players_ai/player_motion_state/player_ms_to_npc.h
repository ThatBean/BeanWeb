//
//  player_ms_to_npc.h
//  ChainChronicle
//
//  Created by gaven on 2/21/14.
//
//

#ifndef __ChainChronicle__player_ms_to_npc__
#define __ChainChronicle__player_ms_to_npc__

#include "game/major_city/players_ai/player_motion_state/player_ms_move_with_path.h"

namespace taomee {
namespace city {
  
class SimpleMoveObject;

namespace player_ai {

class PlayerMotionStateToNPC : public PlayerMotionStateMoveWithPath
{
public:
  PlayerMotionStateToNPC() {}
  virtual ~PlayerMotionStateToNPC() {}
  
public:
  virtual ePlayerMotionUpdateResult OnLeave(SimpleMoveObject* unit);
};

} // namespace player_ai
} // namespace city
} // namespace taomee

#endif /* defined(__ChainChronicle__player_ms_to_npc__) */
