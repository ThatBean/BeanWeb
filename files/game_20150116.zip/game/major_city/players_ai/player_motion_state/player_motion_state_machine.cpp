﻿//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_motion_state_machine.cpp
//        Author: peteryu
//          Date: 2014/2/13 13:26
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"

#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_ai/player_motion_state/player_ms_idle.h"
#include "game/major_city/players_ai/player_motion_state/player_ms_move.h"
#include "game/major_city/players_ai/player_motion_state/player_ms_move_with_path.h"
#include "game/major_city/players_ai/player_motion_state/player_ms_to_npc.h"

namespace taomee {
namespace city {
namespace player_ai {

PlayerMotionStateMachine::PlayerMotionStateMachine()
{
  memset(motionStates, 0, sizeof(PlayerMotionState*) * kPlayerMotionStateMax);
}
  
PlayerMotionStateMachine::~PlayerMotionStateMachine()
{
  this->ShutDown();
}
  
bool PlayerMotionStateMachine::Init()
{
  this->registerState(kPlayerMotionStateIdle, new PlayerMotionStateIdle);
  this->registerState(kPlayerMotionStateMove, new PlayerMotionStateMove);
  this->registerState(kPlayerMotionStateMoveWithPath, new PlayerMotionStateMoveWithPath);
  this->registerState(kPlayerMotionStateToNPC, new PlayerMotionStateToNPC);
  return true;
}
  
void PlayerMotionStateMachine::ShutDown()
{
  for (int i = 0; i<kPlayerMotionStateMax; ++i)
  {
    if (motionStates[i])
    {
      delete motionStates[i];
      motionStates[i] = NULL;
    }
  }
}
  
ePlayerMotionUpdateResult PlayerMotionStateMachine::Update(SimpleMoveObject *unit,
                                                           float delta_time)
{
  ePlayerMotionStateType motion_state = unit->move_data()->motion_state();
  ePlayerMotionUpdateResult ret;
  if(IS_VALID_PLAYER_MOTION_STATE(motion_state) && motionStates[motion_state])
  {
    ret = motionStates[motion_state]->Update(unit, delta_time);
  }
  else
    ret = kPlayerMotionResultInactive;

  return ret;
}
  
ePlayerMotionUpdateResult PlayerMotionStateMachine::ChangeMotion(SimpleMoveObject* unit,
                                                                 ePlayerMotionStateType new_motion_type)
{
  ePlayerMotionStateType motion_state = unit->move_data()->motion_state();

  if(!IS_VALID_PLAYER_MOTION_STATE(new_motion_type) || !motionStates[new_motion_type])
  {
    return kPlayerMotionResultInvalid;
  }

  if(motion_state != new_motion_type)
  {
    if(IS_VALID_PLAYER_MOTION_STATE(motion_state) && motionStates[motion_state])
    {
      motionStates[motion_state]->OnLeave(unit);
    }

    //unit->set_current_animation_state(kMotionResultActive);
    motionStates[new_motion_type]->OnEnter(unit);

    unit->move_data()->motion_state_       = new_motion_type;
    unit->move_data()->last_motion_state_  = motion_state;

    //CCLOG("--ID: %ld, MotionState: %s", unit->move_object_id(), GetPlayerMotionStateName(unit->move_data()->motion_state()).c_str());
  }
  
  return kPlayerMotionResultActive;
}
  
void PlayerMotionStateMachine::StopAllMotions(SimpleMoveObject* unit)
{
  if(IS_VALID_PLAYER_MOTION_STATE(unit->move_data()->motion_state()))
    motionStates[unit->move_data()->motion_state()]->OnLeave(unit);
}

bool PlayerMotionStateMachine::registerState(ePlayerMotionStateType motion_type,
                                             PlayerMotionState *state)
{
  assert(motion_type > kPlayerMotionStateInvalid && motion_type < kPlayerMotionStateMax);
  // register yet
  if (motionStates[motion_type]) 
  {
    return false;
  }
  else 
  { 
    // empty one, register it
    motionStates[motion_type] = state;
    return true;
  }
}

} // namespace player_ai
} // namespace city
} // namespace taomee