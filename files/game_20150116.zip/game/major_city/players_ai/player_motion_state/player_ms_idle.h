//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ms_idle.h
//        Author: peteryu
//          Date: 2014/2/17 11:36
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/17      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MS_IDLE_H
#define PLAYER_MS_IDLE_H

#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {

class PlayerMotionStateIdle : public PlayerMotionState
{
public:
  PlayerMotionStateIdle() {}
  virtual ~PlayerMotionStateIdle() {}
  
public:
  virtual ePlayerMotionUpdateResult OnEnter(SimpleMoveObject* unit);
  virtual ePlayerMotionUpdateResult OnLeave(SimpleMoveObject* unit);
  virtual ePlayerMotionUpdateResult Update(SimpleMoveObject* unit, float delta_time);
};

} // namespace player_ai
} // namespace city
} // namespace taomee

#endif // 
