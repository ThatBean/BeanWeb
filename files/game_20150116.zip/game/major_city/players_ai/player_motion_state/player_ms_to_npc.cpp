//
//  player_ms_to_npc.cpp
//  ChainChronicle
//
//  Created by gaven on 2/21/14.
//
//

#include "game/major_city/players_ai/player_motion_state/player_ms_to_npc.h"

#include "engine/base/random_helper.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/player_move_object.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

namespace taomee {
namespace city {
namespace player_ai {
  
ePlayerMotionUpdateResult PlayerMotionStateToNPC::OnLeave(SimpleMoveObject* unit)
{
  // check distance bewteen NPC position & current position
  PlayerMoveObject* pObj = dynamic_cast<PlayerMoveObject*>(unit);
  assert(pObj);
  pObj->CheckDistanceToNPCAndActivateNPCDialog();
  return PlayerMotionStateMove::OnLeave(pObj);
}
  
} // namespace player_ai
} // namespace city
} // namespace taomee