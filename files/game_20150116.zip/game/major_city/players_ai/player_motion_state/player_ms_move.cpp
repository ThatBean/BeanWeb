//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ms_move.cpp
//        Author: peteryu
//          Date: 2014/2/13 13:43
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////
#include "game/major_city/players_ai/player_motion_state/player_ms_move.h"

#include "engine/base/random_helper.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_data/pet_move_object.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

using namespace cocos2d;

namespace taomee {
namespace city {
namespace player_ai {

ePlayerMotionUpdateResult PlayerMotionStateMove::OnEnter(SimpleMoveObject* unit)
{
  ResetDirection(unit);
  unit->ChangeAnimationToIndex(kPlayerAnimationTypeRun);
  return kPlayerMotionResultActive;
}
    
ePlayerMotionUpdateResult PlayerMotionStateMove::OnLeave(SimpleMoveObject* unit)
{
  unit->move_data()->set_move_speed(CCPointZero);
  return kPlayerMotionResultCompelted;
}

ePlayerMotionUpdateResult PlayerMotionStateMove::Update(SimpleMoveObject* unit,
                                                        float delta_time)
{
  if(ccpDistanceSQ(unit->move_data()->current_pos(),
                   unit->move_data()->target_selection()->target_pos()) <=
     (unit->move_data()->velocity_value() * delta_time *
      unit->move_data()->velocity_value() * delta_time))
  {
    unit->move_data()->set_current_pos(unit->move_data()->target_selection()->target_pos());
    return kPlayerMotionResultCompelted;
  }
  
  CCPoint direction = ccpSub(unit->move_data()->target_selection()->target_pos(),
                             unit->move_data()->current_pos());
  CCPoint speed = unit->move_data()->move_speed();
  if(direction.x * speed.x + direction.y * speed.y < 0)
  {
    return kPlayerMotionResultCompelted;
  }
  
  cocos2d::CCPoint move_vec = ccp(unit->move_data()->move_speed().x * delta_time,
                                  unit->move_data()->move_speed().y * delta_time);
  unit->move_data()->set_current_pos(cocos2d::ccpAdd(move_vec, unit->move_data()->current_pos()));

  return kPlayerMotionResultActive;
}

void PlayerMotionStateMove::ResetDirection( SimpleMoveObject* unit )
{
  cocos2d::CCPoint new_des_pos = unit->move_data()->target_selection()->target_pos();
  cocos2d::CCPoint current_pos = unit->move_data()->current_pos();

  float del_x = new_des_pos.x - current_pos.x;
  float del_y = new_des_pos.y - current_pos.y;

  float distance = sqrt(del_x*del_x + del_y*del_y);

  if (fabsf(distance)<0.00001f)
  {
    unit->move_data()->set_move_speed(cocos2d::CCPointZero);
  }
  else
  {
    del_x = del_x / distance;
    del_y = del_y / distance;
    unit->move_data()->set_move_speed(ccp(del_x * unit->move_data()->velocity_value(),
      del_y * unit->move_data()->velocity_value()));
  }  

  //Note: pet has two direction
  if(dynamic_cast<PetMoveObject*>(unit) != NULL)
  {
    if (new_des_pos.x > current_pos.x) 
      unit->animation()->ChangeDirection(kPlayerAnimationDirectionRight);
    else
      unit->animation()->ChangeDirection(kPlayerAnimationDirectionLeft);
  }
  else
  {
    if (new_des_pos.x > current_pos.x) 
    {
      if(fabsf(del_x) >= fabsf(del_y))
        unit->animation()->ChangeDirection(kPlayerAnimationDirectionRight);
      else if(del_y >= 0)
        unit->animation()->ChangeDirection(kPlayerAnimationDirectionBack);
      else
        unit->animation()->ChangeDirection(kPlayerAnimationDirectionFront);
    }
    else 
    {
      if(fabsf(del_x) >= fabsf(del_y))
        unit->animation()->ChangeDirection(kPlayerAnimationDirectionLeft);
      else if(del_y >= 0)
        unit->animation()->ChangeDirection(kPlayerAnimationDirectionBack);
      else
        unit->animation()->ChangeDirection(kPlayerAnimationDirectionFront);
    }
  }
}


} // namespace player_ai
} // namespace city
} // namespace taomee
