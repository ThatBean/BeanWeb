//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_motion_state_machine.h
//        Author: peteryu
//          Date: 2014/2/13 13:23
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MOTION_STATE_MACHINE_H
#define PLAYER_MOTION_STATE_MACHINE_H

#include "engine/base/basictypes.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {
  
class PlayerMotionState;
  
class PlayerMotionStateMachine
{
public:
  PlayerMotionStateMachine();
  virtual ~PlayerMotionStateMachine();
  
public:
  bool            Init();
  void            ShutDown();
  ePlayerMotionUpdateResult ChangeMotion(SimpleMoveObject* unit,ePlayerMotionStateType new_motion_type);
  ePlayerMotionUpdateResult Update(SimpleMoveObject* unit, float delta_time);
  void                      StopAllMotions(SimpleMoveObject* unit);
  
private:
  bool            registerState(ePlayerMotionStateType motion_type,
                                PlayerMotionState* state);
private:
  PlayerMotionState*    motionStates[kPlayerMotionStateMax];
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif // ChainChronicle_motion_state_machine_h
