//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ms_move_with_path.h
//        Author: peteryu
//          Date: 2014/2/27 18:29
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/27      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MS_MOVE_WITH_PATH_H
#define PLAYER_MS_MOVE_WITH_PATH_H

#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state.h"
#include "game/major_city/players_ai/player_motion_state/player_ms_move.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {

class PlayerMotionStateMoveWithPath : public PlayerMotionStateMove
{
public:
  PlayerMotionStateMoveWithPath() {}
  virtual ~PlayerMotionStateMoveWithPath() {}
  
public:
  virtual ePlayerMotionUpdateResult OnEnter(SimpleMoveObject* unit);
  virtual ePlayerMotionUpdateResult Update(SimpleMoveObject* unit, float delta_time);
};

} // namespace player_ai
} // namespace city
} // namespace taomee

#endif // 
