//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ms_move.h
//        Author: peteryu
//          Date: 2014/2/13 13:43
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MS_MOVE_H
#define PLAYER_MS_MOVE_H

#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {

class PlayerMotionStateMove : public PlayerMotionState
{
public:
  PlayerMotionStateMove() {}
  virtual ~PlayerMotionStateMove() {}
  
public:
  virtual ePlayerMotionUpdateResult OnEnter(SimpleMoveObject* unit);
  virtual ePlayerMotionUpdateResult OnLeave(SimpleMoveObject* unit);
  virtual ePlayerMotionUpdateResult Update(SimpleMoveObject* unit, float delta_time);

  void    ResetDirection(SimpleMoveObject* unit);
};

} // namespace player_ai
} // namespace city
} // namespace taomee

#endif // 
