//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: pet_intent_follow.h
//        Author: peteryu
//          Date: 2014/2/27 21:10
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/27      add
//////////////////////////////////////////////////////////////

#ifndef PET_INTENT_FOLLOW_H
#define PET_INTENT_FOLLOW_H

#include "game/major_city/players_ai/player_intent_state/player_ai_state.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {
  
class PetIntentFollow :public PlayerAIState
{
public:
  PetIntentFollow() {}
  virtual ~PetIntentFollow() {}

  virtual uint_32 OnEnter(SimpleMoveObject* unit);
  virtual uint_32 OnLeave(SimpleMoveObject* unit);

  virtual uint_32 Update(SimpleMoveObject* unit, float delta_time);
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif
