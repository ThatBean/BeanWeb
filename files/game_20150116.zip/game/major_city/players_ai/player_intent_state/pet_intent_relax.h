//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: pet_intent_relax.h
//        Author: peteryu
//          Date: 2014/2/27 21:13
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/27      add
//////////////////////////////////////////////////////////////

#ifndef PET_INTENT_RELAX_H
#define PET_INTENT_RELAX_H

#include "game/major_city/players_ai/player_intent_state/player_ai_state.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"

#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace city {

class SimpleMoveObject;
class PetMoveObject;

namespace player_ai {
  
class PetIntentRelax :public PlayerAIState
{
public:
  PetIntentRelax() {}
  virtual ~PetIntentRelax() {}

  virtual uint_32 OnEnter(SimpleMoveObject* unit);
  virtual uint_32 OnLeave(SimpleMoveObject* unit);

  virtual uint_32 Update(SimpleMoveObject* unit, float delta_time);

  cocos2d::CCPoint  GetRandomPointAroundRole(PetMoveObject *pet);
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif
