//
//  pet_intent_common.cpp
//  ChainChronicle
//
//  Created by gaven on 2/21/14.
//
//

#include "game/major_city/players_ai/player_intent_state/pet_intent_common.h"

#include "engine/animation/player_skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/pet_move_object.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

namespace taomee {
namespace city {
namespace player_ai {
  
uint_32 PetIntentCommon::OnEnter(SimpleMoveObject *unit)
{
  PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateIdle);
  PetMoveObject* pet = dynamic_cast<PetMoveObject*>(unit);
  assert(pet);
  pet->set_relax_time(0.0f);
  //pet->set_need_force_follow_role_player(false);
  return kPlayerAIResultSuccess;
}

uint_32 PetIntentCommon::OnLeave(SimpleMoveObject *unit)
{
  return kPlayerAIResultSuccess;
}

uint_32 PetIntentCommon::Update(SimpleMoveObject *unit, float delta_time)
{
  ePlayerMotionUpdateResult ret = PlayerAIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  
  PetMoveObject* pet = dynamic_cast<PetMoveObject*>(unit);
  assert(pet);

  // follow role player
  if(pet->need_force_follow_role_player())
  {
    unit->move_data()->set_ai_state(kPetAIStateFollow);
  }
  else
  {
    // relax
    if(pet->relax_time() > 5.0f)
      unit->move_data()->set_ai_state(kPetAIStateRelax);
    else
      PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateIdle);
  }

  return kPlayerAIResultSuccess;
}
  
} // namespace player_ai
} // namespace city
} // namespace taomee