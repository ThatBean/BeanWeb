//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: pet_intent_follow.cpp
//        Author: peteryu
//          Date: 2014/2/27 21:10
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/27      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_ai/player_intent_state/pet_intent_follow.h"

#include "engine/animation/player_skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/pet_move_object.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

namespace taomee {
namespace city {
namespace player_ai {
  
uint_32 PetIntentFollow::OnEnter(SimpleMoveObject *unit)
{
  unit->move_data()->clean_path_list();
  PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateIdle);
  return kPlayerAIResultSuccess;
}

uint_32 PetIntentFollow::OnLeave(SimpleMoveObject *unit)
{
  PetMoveObject* pet = dynamic_cast<PetMoveObject*>(unit);
  assert(pet);
  pet->set_need_force_follow_role_player(false);
  return kPlayerAIResultSuccess;
}

uint_32 PetIntentFollow::Update(SimpleMoveObject *unit, float delta_time)
{
  ePlayerMotionUpdateResult ret = PlayerAIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  
  PetMoveObject* pet = dynamic_cast<PetMoveObject*>(unit);
  assert(pet);

  // move to follow target end
  if( unit->move_data()->is_have_path_point() == false && // 1.make sure all path list are empty
      ((pet->move_data()->motion_state() == kPlayerMotionStateMoveWithPath ||
       pet->move_data()->motion_state() == kPlayerMotionStateIdle) &&
       ret == kPlayerMotionResultCompelted) && // 2.make sure the last path traverse finished
      (false == pet->need_force_follow_role_player() ||
       false == pet->IsCurrentTargetPositionTooFarAwayFromOwnerRole())) // 3.make sure no necessary to find new path
  {
    pet->move_data()->set_ai_state(player_ai::kPetAIStateCommon);
    return kPlayerAIResultSuccess;
  }

  //moving
  if( pet->move_data()->motion_state() == kPlayerMotionStateMoveWithPath &&
      ret != kPlayerMotionResultCompelted)
  {  
    // last path edge has not been traverse finished
    if (pet->IsTooFarAwayFromOwnerRoleToWakeupForceRedirection() &&
        pet->need_force_follow_role_player())
    { 
      // the exist path is not to latest destination, need search new one -- stop current move motion firstly
      pet->SendFollowPathfindingRequest();
      return kPlayerAIResultSuccess;
    }
    else
    {
      // do nothing, stay in move state -- waiting for pet's moving
      // pet will move to its target point witch can be near it role target pos, or
      // pet will be reset pathfinding request after IsCurrentTargetPositionTooFarAwayFromOwnerRole() retrun true 
    }
  }
  else if(pet->move_data()->is_have_path_point())
  { 
    // path list exist yet, just moving
    PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateMoveWithPath);
  }
  else if(pet->IsTooFarAwayFromOwnerRole())
  { 
    // no path edges exist in follow path list -- send follow pathfinding request directly
    pet->SendFollowPathfindingRequest();
  }
  else
  { 
    // do nothing here, stay in idle state -- waiting for owner's moving
  }

  return kPlayerAIResultSuccess;
}
  
} // namespace player_ai
} // namespace city
} // namespace taomee