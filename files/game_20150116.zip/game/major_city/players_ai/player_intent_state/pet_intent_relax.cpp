//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: pet_intent_relax.cpp
//        Author: peteryu
//          Date: 2014/2/27 21:14
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/27      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_ai/player_intent_state/pet_intent_relax.h"

#include "engine/animation/player_skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "engine/geometry/geometry_const.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/players_data/pet_move_object.h"
#include "game/major_city/players_data/player_move_object.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/pathfinding/city_tiled_map.h"

using namespace cocos2d;

namespace taomee {
namespace city {
namespace player_ai {
  
uint_32 PetIntentRelax::OnEnter(SimpleMoveObject *unit)
{
  unit->move_data()->set_velocity_value(unit->move_data()->velocity_value() * 0.5);
  return kPlayerAIResultSuccess;
}

uint_32 PetIntentRelax::OnLeave(SimpleMoveObject *unit)
{
  unit->move_data()->set_velocity_value(unit->move_data()->velocity_value() * 2.0);
  return kPlayerAIResultSuccess;
}

uint_32 PetIntentRelax::Update(SimpleMoveObject *unit, float delta_time)
{
  ePlayerMotionUpdateResult ret = PlayerAIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  
  PetMoveObject* pet = dynamic_cast<PetMoveObject*>(unit);
  assert(pet);

  if(pet->need_force_follow_role_player())
  {
    pet->move_data()->set_ai_state(kPetAIStateCommon);
  }

  // moving to random pos
  if(pet->move_data()->motion_state() == kPlayerMotionStateMove && ret != kPlayerMotionResultCompelted)
  {
    pet->set_relax_time(0.0f);
  }
  // move end or start relax
  else
  {
    // search new random pos after 5s
    if(pet->relax_time() < 5.0f)
    {
      PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateIdle);
      return kPlayerAIResultSuccess;
    }

    // get new random pos around role player
    CCPoint pos = GetRandomPointAroundRole(pet);
    CCPoint tile_pos = TiledCoordinateFromLocation(pos);
    if( IsTileCoordinateInRange(tile_pos) &&
        CityController::GetInstance().tiled_map()->CanUnitTraverseTileAtPos(tile_pos))
    {
      if(CityController::GetInstance().tiled_map()->CanWalkableBetween(pos, unit->move_data()->current_pos()))
      {
        unit->move_data()->target_selection()->set_target_pos(pos);
        PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateMove);
      }
    }
  }

  return kPlayerAIResultSuccess;
}

CCPoint PetIntentRelax::GetRandomPointAroundRole( PetMoveObject *pet )
{
  float radius = kMaxDistanceRadiusFromOwnerRoleOfPet * random_0_1();
  float angle = random_0_1() * 2 * PI;

  float x = radius * cosf(angle);
  float y = radius * sinf(angle);

  CCPoint random_pos = pet->owner_role()->move_data()->current_pos();
  random_pos.x += x;
  random_pos.y += y;

  return random_pos;
}


} // namespace player_ai
} // namespace city
} // namespace taomee