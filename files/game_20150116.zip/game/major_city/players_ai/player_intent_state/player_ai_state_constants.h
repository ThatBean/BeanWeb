//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ai_state_constants.h
//        Author: peteryu
//          Date: 2014/2/12 15:24
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_AI_STATE_CONSTANTS_H
#define PLAYER_AI_STATE_CONSTANTS_H

#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace city {
namespace player_ai {

enum ePlayerAIStateType
{
  kPlayerAIStateInvalid = -1,
  kPlayerAIStateCommon  = 0,
  kPlayerAIStateGoNPC   = 1,
  kPetAIStateCommon     = 2,
  kPetAIStateFollow     = 3,
  kPetAIStateRelax      = 4,
  kPlayerAIStateMax
};

enum ePlayerAIUpdateResult
{
  kPlayerAIResultInvalid      = -1,
  kPlayerAIResultSuccess      = 0,
  kPlayerAIResultFailed       = 1,
  kPlayerAIResultMax,
};
  
const cocos2d::CCPoint kPetDistanceOffsetToOwner = cocos2d::CCPoint(-15, -15);
const float            kMaxDistanceRadiusFromOwnerRoleOfPet = 96.0f;

#define IS_VALID_PLAYER_AI_STATE(state) (state > kPlayerAIStateInvalid && state < kPlayerAIStateMax)

// get AIStateName by AIStateType, for debug output
static std::string GetPlayerAIStateName(ePlayerAIStateType type)
{
  switch(type)
  {
  case kPlayerAIStateCommon:
    return "kPlayerAIStateCommon";
  case kPlayerAIStateGoNPC:
    return "kPlayerAIStateGoNPC";
  case kPetAIStateCommon:
    return "kPetAIStateCommon";
  case kPetAIStateFollow:
    return "kPetAIStateFollow";
  case kPetAIStateRelax:
    return "kPetAIStateRelax";
  default:
    return "kPlayerAIStateError";
  }
  return "";
}

} // namespace player_ai
} // namespace city
} // namespace taomee

#endif 
