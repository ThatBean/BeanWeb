//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ai_state.cpp
//        Author: peteryu
//          Date: 2014/2/12 15:23
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////
#include "game/major_city/players_ai/player_intent_state/player_ai_state.h"

#include "game/major_city/players_data/simple_move_object.h"


namespace taomee {
namespace city {
namespace player_ai {

} // namespace player_ai
} // namespace city
} // namespace taomee


