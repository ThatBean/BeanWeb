//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ai_state_machine.cpp
//        Author: peteryu
//          Date: 2014/2/13 10:12
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"

#include <assert.h>
#include "game/major_city/players_data/player_move_object.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state.h"
#include "game/major_city/players_ai/player_intent_state/player_intent_common.h"
#include "game/major_city/players_ai/player_intent_state/player_intent_go_pnc.h"
#include "game/major_city/players_ai/player_intent_state/pet_intent_common.h"
#include "game/major_city/players_ai/player_intent_state/pet_intent_follow.h"
#include "game/major_city/players_ai/player_intent_state/pet_intent_relax.h"


namespace taomee {
namespace city {
namespace player_ai {
  
PlayerAIStateMachine& PlayerAIStateMachine::GetInstance()
{
  static PlayerAIStateMachine player_ai_state_machine;
  return player_ai_state_machine;
}

PlayerAIStateMachine::PlayerAIStateMachine()
{
  memset(intentStates, 0, sizeof(PlayerAIState*) * kPlayerAIStateMax);
  this->Init();
  motion_machine_ = new PlayerMotionStateMachine();
  motion_machine_->Init();
}
  
PlayerAIStateMachine::~PlayerAIStateMachine()
{
  this->ShutDown();
  delete motion_machine_;
}
  
bool PlayerAIStateMachine::Init()
{
  this->registerState(kPlayerAIStateCommon, new PlayerIntentCommon);
  this->registerState(kPlayerAIStateGoNPC, new PlayerIntentGoNPC);
  this->registerState(kPetAIStateCommon, new PetIntentCommon);
  this->registerState(kPetAIStateFollow, new PetIntentFollow);
  this->registerState(kPetAIStateRelax, new PetIntentRelax);
  return true;
}
  
void PlayerAIStateMachine::ShutDown()
{
  for (int i = 0; i < kPlayerAIStateMax; ++i)
  {
    if (intentStates[i])
    {
      delete intentStates[i];
      intentStates[i] = NULL;
    }
  }
}
  
bool PlayerAIStateMachine::registerState(ePlayerAIStateType ai_type,
                                         PlayerAIState *state)
{
  assert(ai_type > kPlayerAIStateInvalid && ai_type < kPlayerAIStateMax);
  // register yet
  if (intentStates[ai_type]) 
  {
    return false;
  }
  else 
  { 
    // empty one, register it
    intentStates[ai_type] = state;
    return true;
  }
}
  
// update all move objects on battle field with delta time  
uint_32 PlayerAIStateMachine::Update(float delta_time)
{
  return kPlayerAIResultSuccess;
}
  
// update one single unit on battle filed with delta time
uint_32 PlayerAIStateMachine::Update(SimpleMoveObject* unit, float delta_time)
{
  ePlayerAIStateType ai_state = unit->move_data()->ai_state();
  ePlayerAIStateType last_ai_state = unit->move_data()->last_ai_state();
  
  if(!IS_VALID_PLAYER_AI_STATE(ai_state) || !intentStates[ai_state])
  {
    return kPlayerAIResultInvalid;
  }

  if(ai_state != last_ai_state)
  {
    if(IS_VALID_PLAYER_AI_STATE(last_ai_state) && intentStates[last_ai_state])
    {
      intentStates[last_ai_state]->OnLeave(unit);
    }

    if(intentStates[ai_state])
    {
      intentStates[ai_state]->OnEnter(unit);
    }

    unit->move_data()->last_ai_state_ = ai_state;

    //CCLOG("ID: %ld, AIState: %s", unit->move_object_id(), GetPlayerAIStateName(unit->move_data()->ai_state()).c_str());
  }
  
  intentStates[ai_state]->Update(unit, delta_time);

  return kPlayerAIResultSuccess;
}
  
} // namespace player_ai
} // namespace city
} // namespace taomee
