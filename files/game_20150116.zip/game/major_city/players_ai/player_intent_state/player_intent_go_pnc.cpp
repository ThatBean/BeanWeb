//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_intent_go_pnc.cpp
//        Author: peteryu
//          Date: 2014/3/3 17:02
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/3/3      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_ai/player_intent_state/player_intent_go_pnc.h"

#include "engine/animation/player_skeleton_animation.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_data/player_move_object.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/players_data/npc_object.h"
#include "engine/script/lua_tinker_manager.h"
namespace taomee {
namespace city {
namespace player_ai {
  
uint_32 PlayerIntentGoNPC::OnEnter(SimpleMoveObject *unit)
{
	//LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/newbie_guide_manager.lua", "showNewbieBlackPanel",true);
    return kPlayerAIResultSuccess;
}  

uint_32 PlayerIntentGoNPC::OnLeave(SimpleMoveObject *unit)
{
  PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateIdle);
  //call npc script
  PlayerMoveObject* pObj = dynamic_cast<PlayerMoveObject*>(unit);
  assert(pObj);
  //LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/newbie_guide_manager.lua", "showNewbieBlackPanel",false);
  //unit->move_data()->clean_path_list();
  pObj->CheckDistanceToNPCAndActivateNPCDialog();
  
  return kPlayerAIResultSuccess;
}

uint_32 PlayerIntentGoNPC::Update(SimpleMoveObject *unit, float delta_time)
{
  ePlayerMotionUpdateResult ret = PlayerAIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  PlayerMoveObject *player = dynamic_cast<PlayerMoveObject*>(unit);
  assert(player);

  if(unit->move_data()->target_selection()->target_id() == kUnexistNpcId)
  {
    unit->move_data()->set_ai_state(kPlayerAIStateCommon);
    return kPlayerAIResultSuccess;
  }

  CCPoint npc_pos = CityController::GetInstance().GetNPCById(unit->move_data()->target_selection()->target_id())->animation()->getPosition();
  // close with npc
  if(ccpDistanceSQ(unit->move_data()->current_pos(), unit->move_data()->destination_pos()) < 4.0f)
  {
    unit->move_data()->set_ai_state(kPlayerAIStateCommon);
    return kPlayerAIResultSuccess;
  }

  // moving
  if(unit->move_data()->is_have_path_point())
  {
    PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateMoveWithPath);
  }
  else
  {
    player->SendFindPathRequest(npc_pos);
  }

  return kPlayerAIResultSuccess;
}
  
} // namespace player_ai
} // namespace city
} // namespace taomee
