//
//  pet_intent_common.h
//  ChainChronicle
//
//  Created by gaven on 2/21/14.
//
//

#ifndef __ChainChronicle__pet_intent_common__
#define __ChainChronicle__pet_intent_common__

#include "game/major_city/players_ai/player_intent_state/player_ai_state.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {
  
class PetIntentCommon :public PlayerAIState
{
public:
  PetIntentCommon() {}
  virtual ~PetIntentCommon() {}

  virtual uint_32 OnEnter(SimpleMoveObject* unit);
  virtual uint_32 OnLeave(SimpleMoveObject* unit);

  virtual uint_32 Update(SimpleMoveObject* unit, float delta_time);
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif /* defined(__ChainChronicle__pet_intent_common__) */
