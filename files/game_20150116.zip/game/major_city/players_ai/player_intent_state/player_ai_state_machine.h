//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ai_state_machine.h
//        Author: peteryu
//          Date: 2014/2/12 18:39
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_AI_STATE_MACHINE_H
#define PLAYER_AI_STATE_MACHINE_H

#include "engine/base/basictypes.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {
 
class PlayerAIState;
class PlayerMotionStateMachine;

class PlayerAIStateMachine
{
public:
  virtual ~PlayerAIStateMachine();
  
  static PlayerAIStateMachine& GetInstance();

public:
  bool            Init();
  void            ShutDown();
  
  // update all move objects on battle field with delta time
  uint_32         Update(float delta_time);
  // update one single unit on battle filed with delta time
  uint_32         Update(SimpleMoveObject* unit, float delta_time);
  
  PlayerMotionStateMachine* MotionMachine()
  {
    return motion_machine_;
  }                      
  
private:
  PlayerAIStateMachine();

  DISALLOW_COPY_AND_ASSIGN(PlayerAIStateMachine);

  bool            registerState(ePlayerAIStateType intent_type, PlayerAIState* state);
  
private:  
  PlayerAIState*            intentStates[kPlayerAIStateMax];
  
  PlayerMotionStateMachine* motion_machine_;
};
    
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif // ChainChronicle_ai_state_machine_h
