//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_ai_state.h
//        Author: peteryu
//          Date: 2014/2/12 15:21
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_AI_STATE_H
#define PLAYER_AI_STATE_H

#include "engine/base/basictypes.h"

namespace taomee {
namespace city {
  
class SimpleMoveObject;

namespace player_ai {
  
class PlayerAIState
{
public:
  PlayerAIState() {}
  virtual ~PlayerAIState() {}
  
public:
  virtual uint_32 OnEnter(SimpleMoveObject* unit) = 0;
  virtual uint_32 OnLeave(SimpleMoveObject* unit) = 0;
  
  virtual uint_32 Update(SimpleMoveObject* unit, float delta_time) = 0;  
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee


#endif
