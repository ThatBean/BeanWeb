//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_intent_common.h
//        Author: peteryu
//          Date: 2014/2/13 13:09
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_INTENT_COMMON_H
#define PLAYER_INTENT_COMMON_H

#include "game/major_city/players_ai/player_intent_state/player_ai_state.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"

namespace taomee {
namespace city {

class SimpleMoveObject;

namespace player_ai {
  
class PlayerIntentCommon :public PlayerAIState
{
public:
  PlayerIntentCommon() {}
  virtual ~PlayerIntentCommon() {}
  
  virtual uint_32 OnEnter(SimpleMoveObject* unit);
  virtual uint_32 OnLeave(SimpleMoveObject* unit);
  
  virtual uint_32 Update(SimpleMoveObject* unit, float delta_time);
};
  
} // namespace player_ai
} // namespace city
} // namespace taomee

#endif
