//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_intent_common.cpp
//        Author: peteryu
//          Date: 2014/2/13 13:12
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/13      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_ai/player_intent_state/player_intent_common.h"

#include "engine/animation/player_skeleton_animation.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/army/unit/unit_constants.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

namespace taomee {
namespace city {
namespace player_ai {
  
uint_32 PlayerIntentCommon::OnEnter(SimpleMoveObject *unit)
{
  unit->ChangeAnimationToIndex(kPlayerAnimationTypeIdle);
  return kPlayerAIResultSuccess;
}  

uint_32 PlayerIntentCommon::OnLeave(SimpleMoveObject *unit)
{
  return kPlayerAIResultSuccess;
}

uint_32 PlayerIntentCommon::Update(SimpleMoveObject *unit, float delta_time)
{
  ePlayerMotionUpdateResult ret = PlayerAIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

  //walk with path list
  if(unit->move_data()->is_have_path_point())
  {
    if (kUnexistNpcId != unit->move_data()->target_selection()->target_id())
    {
      PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateToNPC);
    }
    else
    {
      PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateMoveWithPath);        
    }
  }
  // moving
  else if((unit->move_data()->motion_state() == kPlayerMotionStateMoveWithPath || unit->move_data()->motion_state() == kPlayerMotionStateToNPC)
    && ret != kPlayerMotionResultCompelted)
  {
    
  }
  // move over
  else
  {
    PlayerAIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kPlayerMotionStateIdle);
  }
  
  return kPlayerAIResultSuccess;
}
  
} // namespace player_ai
} // namespace city
} // namespace taomee
