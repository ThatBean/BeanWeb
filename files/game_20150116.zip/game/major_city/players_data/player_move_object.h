//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_move_object.h
//        Author: peteryu
//          Date: 2014/2/12 18:30
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef PLAYER_MOVE_OBJECT_H
#define PLAYER_MOVE_OBJECT_H

#include "game/major_city/players_data/simple_move_object.h"

using namespace cocos2d;

namespace taomee {
namespace city {
  
class PetMoveObject;

class PlayerBasicData
{
public:
  PlayerBasicData();
  PlayerBasicData(const PlayerBasicData* data);
  ~PlayerBasicData();
  
  void InitWithData(const PlayerBasicData* data);
  
public: // getter & setter
  const cocos2d::CCPoint& init_position() const { return init_position_; }
  void          set_init_position(const cocos2d::CCPoint& initPos)
  {
    init_position_ = initPos;
  }
  
  const std::string&   player_id() const { return player_id_; }
  void          set_player_id(const std::string& pId)
  {
    player_id_.clear();
    player_id_ = pId;
  }
  
  uint_8        rank() const { return rank_; }
  void          set_rank(uint_8 rank)
  {
    rank_ = rank;
  }
  
  uint_8        vip_level() const { return vip_level_; }
  void          set_vip_level(uint_8 vLevel)
  {
    vip_level_ = vLevel;
  }
  
  uint_32       role_id() const { return role_id_; }
  void          set_role_id(uint_32 rId)
  {
    if (rId > 6) // ���η�����������
      role_id_ = 1;
    else
      role_id_ = rId;
  }

  uint_32       up_star() const { return up_star_; }
  void          set_up_star(uint_32 up_star)
  {
    up_star_ = up_star;
  }
  
  uint_32       weapon_id() const { return weapon_id_; }
  void          set_weapon_id(uint_32 wId)
  {
    weapon_id_ = wId;
  }
  
  const std::string&   nick_name() const { return nick_name_; }
  void          set_nick_name(const std::string& name)
  {
    nick_name_ = name;
    //assert(!name.empty(), "WTF NO NAME");
  }
  
private:
  // this position is only useful for first attach to city view
  cocos2d::CCPoint init_position_;
  // palyer's unique identifier -- for local palyer player_id_ == user_id_ in local user_info data
  std::string   player_id_;
  // player's level
  uint_8        rank_;
  // player's VIP level
  uint_8        vip_level_;
  // role data id -- mapping into role.csv
  uint_32       role_id_;
  // upstar
  uint_8        up_star_;
  // weapon id
  uint_32       weapon_id_;
  // nick name
  std::string   nick_name_;
  // union logo
  
  // ranklist logo
  
  // visual equipment info
  
};
  
class PlayerMoveObject : public SimpleMoveObject
{
public:
  PlayerMoveObject();
  virtual ~PlayerMoveObject();
  
   virtual void Init(uint_32 move_object_id);
public: // getter & setter
  PlayerBasicData* basic_data() { return basic_data_; }
  void             set_basic_data(const PlayerBasicData* data)
  {
    if (NULL==basic_data_)
    {
      basic_data_ = new PlayerBasicData(data);
    }
  }
  
  void           set_pet_object(PetMoveObject* petRef)
  {
    pet_object_ = petRef;
  }
  PetMoveObject* pet_object() { return pet_object_; }

public:
  virtual void ResetLastDestinationPoint();
  
  void CheckDistanceToNPCAndActivateNPCDialog();

  virtual void SendFindPathRequest(CCPoint& p);

  void onBlinkFinished( CCNode* node );

  void showTalkBubble( const char* content_text );

  void onTalkBubbleOver( CCNode* node );

  void onRankUp();
  void onUpStar();
  void rankUpAllFinished( cocos2d::CCNode* pNode);
protected: // basic info
  PlayerBasicData* basic_data_;
  
protected: // reference to own pet object
  PetMoveObject* pet_object_; 
  cocos2d::extension::UILayer *head_layer;
private:
  cocos2d::CCLayer * pTalkBubbleLayer;
};

} // namespace city
} // namespace taomee

#endif