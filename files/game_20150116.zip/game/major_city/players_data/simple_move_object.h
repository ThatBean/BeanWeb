//
//  simple_move_object.h
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//

#ifndef __ChainChronicle__simple_move_object__
#define __ChainChronicle__simple_move_object__

#include <list>

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/players_data/move_data.h"
#include "game/army/unit/unit_constants.h"

using namespace std;

namespace taomee {
  
namespace city {
  
class PathPlannerBase;

class SimpleMoveObject
{
public:
  SimpleMoveObject();
  virtual ~SimpleMoveObject();
  
public: // virtual interface
  virtual void Init(uint_32 move_object_id);
  
  virtual bool Update(float delta);
  
  virtual void ResetLastDestinationPoint() {}
  
public: // getter & setter
  void      set_move_object_id(uint_32 newId)
  {
    move_object_id_ = newId;
  }
  uint_32   move_object_id() { return move_object_id_; }
  
  PlayerSkeletonAnimation   *animation() { return animation_; }

  virtual void ChangeAnimationToIndex(ePlayerAnimationType idx, 
                              const int cycle_count = -1,
                              const float speed = 1.0f);
  
  MoveData*     move_data() { return move_data_; }
  
  PathPlannerBase* path_planner() { return path_planner_; }
  
protected:
  // fresh z order move object
  virtual void freshZOrder();
  
  // set new destination for last edge in path list
  void setNewDestinationInLastEdgeOfPathList(float distRadius);
  
protected: // basic data
  // object id
  uint_32       move_object_id_;
  
protected: //animation & move
  // animation node
  PlayerSkeletonAnimation   *animation_;
  // move data
  MoveData*     move_data_;
  
protected: // path finding
  PathPlannerBase*  path_planner_;
  bool              is_searching_path_;
};

}
}

#endif /* defined(__ChainChronicle__simple_move_object__) */
