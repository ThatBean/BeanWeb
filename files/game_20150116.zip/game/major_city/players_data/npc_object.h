//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: npc_object.h
//        Author: robbiepan
//          Date: 2014/2/21 13:56
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2014/2/21      add
//////////////////////////////////////////////////////////////

#ifndef NPC_OBJECT_H
#define NPC_OBJECT_H

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/major_city/major_city_constants.h"
#include "game/army/unit/unit_constants.h"

using namespace cocos2d;

namespace taomee {

  class PlayerSkeletonAnimation;

namespace city {

class NpcObject
{
public:
  NpcObject();
  virtual ~NpcObject();

  void    Init(uint_32 npc_id, uint_32 char_id, uint_32 func_id,const std::string& func_res_name);
  
public: // virtual interface
  virtual bool Update(float delta);
  
public: // getter & setter

  uint_32   npc_id() { return npc_id_; }

  uint_32   func_id()  { return func_id_; }

  uint_32   char_id()  { return char_id_; }

  eNpcType  npc_type() { return npc_type_; }

  void      set_current_pos(const CCPoint& cPos);
  CCPoint   current_pos();

  void      set_head_icon();
  
  PlayerSkeletonAnimation   *animation() { return animation_; }

  
protected: // basic data
  // npc id
  uint_32       npc_id_;

  // charactor id    
  uint_32       char_id_;

  // func id    
  uint_32       func_id_;

  // npc type
  eNpcType      npc_type_;

  // nick name
  std::string   nick_name_;

  // head icon name
  std::string   icon_name_;
  
protected: //animation & move
  // animation node
  PlayerSkeletonAnimation   *animation_;

};

}
}

#endif /* defined(NPC_OBJECT_H) */
