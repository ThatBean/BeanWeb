//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: player_move_object.cpp
//        Author: peteryu
//          Date: 2014/2/12 18:30
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////
#include "game/major_city/players_data/player_move_object.h"

#include "game/major_city/players_data/pet_move_object.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/role_data_table.h"
#include "game/data_table/character_data_table.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/players_data/npc_object.h"
#include "engine/base/utils_string.h"
#include "engine/animation/projectile_animation.h"
#include "engine/particle/particle_group.h"
#include "engine/particle/particle_manager.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {
namespace city {

PlayerBasicData::PlayerBasicData()
  : init_position_(cocos2d::CCPointZero),
    rank_(1),
    vip_level_(0),
    weapon_id_(0),
    role_id_(0),
    up_star_(0)
{
  player_id_.clear();
  nick_name_.clear();
}

PlayerBasicData::~PlayerBasicData()
{
  
}
  
PlayerBasicData::PlayerBasicData(const PlayerBasicData* data)
{
  this->InitWithData(data);
}
  
void PlayerBasicData::InitWithData(const PlayerBasicData *data)
{
  this->set_init_position(data->init_position());
  this->set_player_id(data->player_id());
  this->set_rank(data->rank());
  this->set_vip_level(data->vip_level());
  this->set_role_id(data->role_id());
  this->set_weapon_id(data->weapon_id());
  this->set_nick_name(data->nick_name());
  this->set_up_star(data->up_star());
}
  
PlayerMoveObject::PlayerMoveObject()
  : SimpleMoveObject(),
    basic_data_(new PlayerBasicData),
    pet_object_(NULL),
    pTalkBubbleLayer(NULL),
    head_layer(NULL)
{
  
}

PlayerMoveObject::~PlayerMoveObject()
{
  CC_SAFE_RELEASE(head_layer);
  head_layer = NULL;
  CC_SAFE_DELETE(basic_data_);
  pet_object_ = NULL;
  pTalkBubbleLayer = NULL;
}
  
void PlayerMoveObject::ResetLastDestinationPoint()
{
  if (pet_object_)
  {
    pet_object_->set_need_force_follow_role_player(true);
  }
  // move to position only, does not need set new target position
  if (kUnexistNpcId == move_data_->target_selection()->target_id())
  { 
    return;
  }
  // move to NPC here, set new one
  this->setNewDestinationInLastEdgeOfPathList(player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet);
}
  
void PlayerMoveObject::CheckDistanceToNPCAndActivateNPCDialog()
{
  if(this->move_data()->target_selection()->target_id() == kUnexistNpcId)
    return;

  cocos2d::CCLog("Come to NPC, playerId: %ld, npcId: %ld", move_object_id_, 
                  this->move_data()->target_selection()->target_id());
  cocos2d::CCPoint currnetPos = this->move_data()->current_pos();
  //cocos2d::CCPoint targetPos = CityController::GetInstance().GetNpcPosById(this->move_data()->target_selection()->target_id());
  uint_32 npc_id = this->move_data()->target_selection()->target_id();
  cocos2d::CCPoint targetPos = CityController::GetInstance().GetNPCById(npc_id)->animation()->getPosition();
  // not arrived target point, interrupted by player
  if (ccpDistanceSQ(currnetPos, targetPos) > player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet *
                                             player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet)
  {
    return;
  }
  // arrived yet, activate NPC dialog
  string str_path = "script/city_map/city_map_" + Int2String(DataManager::GetInstance().user_info()->get_current_city_map_id()) + ".lua";
  LuaTinkerManager::GetInstance().CallLuaFunc<int>(str_path.c_str(),
                                                   "activateNPCWithId",
                                                   npc_id,
                                                   CityController::GetInstance().GetNPCById(npc_id)->char_id(),
                                                   CityController::GetInstance().GetNPCById(npc_id)->func_id());
}

void PlayerMoveObject::Init( uint_32 move_object_id )
{
  SimpleMoveObject::Init(move_object_id);

  RoleData* role_data = DataManager::GetInstance().GetRoleDataTable()->GetRole(basic_data_->role_id());
  assert(role_data);
  
  CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(role_data->GetCardID());
  animation_->Init(char_data->GetName(), char_data->GetName(), 1);
  //animation_->AddNodeOnBone(kPlayerBoneTypeHeadBar, label);

  /*
  //add head bar
  CCLayer *head_layer = CCLayer::create();
  cocos2d::CCLabelTTF* name_label = cocos2d::CCLabelTTF::create(basic_data_->nick_name().c_str(), "Arial", 18);
  cocos2d::CCLabelTTF* lv_label = cocos2d::CCLabelTTF::create(Int2String(basic_data_->rank()).c_str(), "Arial", 18);
  
  if(move_object_id == 1)
  {
    name_label->setColor(ccc3(1, 255, 252));
    basic_data_->set_vip_level(DataManager::GetInstance().user_info()->vip());
  }
  lv_label->setColor(ccYELLOW);
  
  CCScale9Sprite *name_back_ground = CCScale9Sprite::createWithSpriteFrameName("agoui_talk_bg.png");
  CCScale9Sprite *lv_back_ground = CCScale9Sprite::createWithSpriteFrameName("agoui_talk_bg.png");
  CCLabelTTF     *vip_sprite = NULL;

  int back_width = name_back_ground->getContentSize().width;
  int back_height = lv_back_ground->getContentSize().width;

  //basic_data_->set_vip_level(1);
  if(basic_data_->vip_level() != 0)
  {
    string vip_png = "V" + Int2String(basic_data_->vip_level()) + " ";
    //vip_sprite = CCSprite::createWithSpriteFrameName(vip_png.c_str());
    vip_sprite = CCLabelTTF::create(vip_png.c_str(), "Arial", 18);
  }

  name_back_ground->setInsetBottom(10);
  name_back_ground->setInsetLeft(10);
  name_back_ground->setInsetTop(10);
  name_back_ground->setInsetRight(10);
  name_back_ground->setContentSize(
    CCSize(name_label->getContentSize().width < back_width + 3 ? back_width : name_label->getContentSize().width + 3, 
           name_label->getContentSize().height < back_height ? back_height : name_label->getContentSize().height));
  
  lv_back_ground->setInsetBottom(10);
  lv_back_ground->setInsetLeft(10);
  lv_back_ground->setInsetTop(10);
  lv_back_ground->setInsetRight(10);
  lv_back_ground->setContentSize(
    CCSize(lv_label->getContentSize().width < back_width + 3 ? back_width : lv_label->getContentSize().width + 3, 
           lv_label->getContentSize().height < back_height ? back_height : lv_label->getContentSize().height));
  
  int vip_width = 0;
  int name_width = 0;
  int lv_width = 0;
  int layer_height = lv_label->getContentSize().height;

  if(basic_data_->vip_level() != 0)
    vip_width = vip_sprite->getContentSize().width;
  name_width = name_back_ground->getContentSize().width;
  lv_width = lv_back_ground->getContentSize().width;

  lv_label->setPosition(ccp(lv_back_ground->getContentSize().width / 2, lv_back_ground->getContentSize().height / 2));
  name_back_ground->addChild(name_label);
  name_label->setPosition(ccp(name_back_ground->getContentSize().width / 2, name_back_ground->getContentSize().height / 2));
  lv_back_ground->addChild(lv_label);

  if(vip_sprite)
  {
    vip_sprite->setPosition(ccp(0.0f, 0.0f));
    vip_sprite->setAnchorPoint(ccp(0.0, 0.5f));
    head_layer->addChild(vip_sprite);
  }

  name_back_ground->setAnchorPoint(ccp(0.0, 0.5f));
  name_back_ground->setPosition(ccp(vip_width, 0.0f));
  head_layer->addChild(name_back_ground);

  lv_back_ground->setAnchorPoint(ccp(0.0, 0.5f));
  lv_back_ground->setPosition(ccp(vip_width + name_width, 0.0f));
  head_layer->addChild(lv_back_ground);

  head_layer->ignoreAnchorPointForPosition(false);
  head_layer->setAnchorPoint(ccp(0.5, 0.0));
  head_layer->setContentSize(ccp(vip_width + name_width + lv_width, layer_height));

  animation_->AddNodeOnBone(kPlayerBoneTypeHeadBar, head_layer);
  */
  CC_SAFE_RELEASE(head_layer);
  head_layer = LuaTinkerManager::GetInstance().CallLuaFunc<UILayer*>("script/ui/ui_player_head_bar.lua", 
    "CreatePlayerHeadBar",
    basic_data_->vip_level(), basic_data_->nick_name().c_str(), basic_data_->rank(), move_object_id == 1);
  CC_SAFE_RETAIN(head_layer);
  animation_->AddNodeOnBone(kPlayerBoneTypeHeadBar, head_layer);

  pTalkBubbleLayer = CCLayer::create();
  pTalkBubbleLayer->ignoreAnchorPointForPosition(false);
  pTalkBubbleLayer->setAnchorPoint(ccp(0.5, 0.0));
  animation_->AddNodeOnBone(kPlayerBoneTypeHeadBar, pTalkBubbleLayer);
  pTalkBubbleLayer->setPosition(ccp(head_layer->getPositionX(),head_layer->getPositionY()+40));
  pTalkBubbleLayer->setVisible(false);
}
void PlayerMoveObject::onBlinkFinished( CCNode* node )
{
    assert(node != NULL);
    node->removeFromParentAndCleanup(true);
}
void PlayerMoveObject::SendFindPathRequest( CCPoint& p )
{
  
}
void PlayerMoveObject::showTalkBubble( const char* content_text )
{
    if( NULL == pTalkBubbleLayer)
        return;
    pTalkBubbleLayer->removeAllChildrenWithCleanup(true);
    cocos2d::CCLabelTTF* content_label = cocos2d::CCLabelTTF::create(content_text, "Helvetica", 16);
    if(content_label->getContentSize().width > 180)
        content_label->setDimensions(CCSizeMake(180,0));
    content_label->setColor(ccGREEN);
    content_label->setHorizontalAlignment(kCCTextAlignmentLeft);
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/agoui_common/agoui_common_ex.plist","ui/agoui_common/agoui_common_ex.pvr.ccz");
    CCScale9Sprite *back_ground = CCScale9Sprite::createWithSpriteFrameName("agoui_bg.png");
    back_ground->addChild(content_label);
    back_ground->setAnchorPoint(ccp(0,0));
    if(content_label->getContentSize().width > 80)
      back_ground->setContentSize(CCSizeMake(content_label->getContentSize().width,content_label->getContentSize().height+8));
    else
      back_ground->setContentSize(CCSizeMake(content_label->getContentSize().width+50,content_label->getContentSize().height+8));
    content_label->setPosition(ccp(back_ground->getContentSize().width / 2, back_ground->getContentSize().height / 2));
   
    //CCSprite* talk_arrow = CCSprite::createWithSpriteFrameName("agoui_talk_arrow.png");
    //if(content_label->getContentSize().width > 80)
    //  talk_arrow->setPosition(ccp(content_label->getContentSize().width/ 2 - 20,-8.5f));
    //else
    //  talk_arrow->setPosition(ccp((content_label->getContentSize().width+32)/ 2 - 10,-8.5f));
    //talk_arrow->setAnchorPoint(ccp(0,0));
    //pTalkBubbleLayer->addChild(talk_arrow);
    pTalkBubbleLayer->addChild(back_ground);
    pTalkBubbleLayer->setContentSize(back_ground->getContentSize());
    pTalkBubbleLayer->setVisible(true);

    //CCCallFuncN* callback = CCCallFuncN::create(pTalkBubbleLayer,callfuncN_selector(PlayerMoveObject::onTalkBubbleOver));
    //pTalkBubbleLayer->runAction(CCSequence::create(CCDelayTime::create(5.0f),callback,NULL));
}

void PlayerMoveObject::onTalkBubbleOver( CCNode* node )
{
    assert(node != NULL);
    node->setVisible(false);
}

void PlayerMoveObject::onUpStar()
{

}

void PlayerMoveObject::onRankUp()
{
  CCNode *pRankUpNode = CCNode::create();

  cocos2d::CCSprite* sprite = cocos2d::CCSprite::create();
  std::string particle_name = "fx_level";
  ParticleGroup* particle_group = ParticleManager::GetInstance().\
    GetParticleGroup(particle_name);
  if (particle_group != NULL)
  {
    ParticleManager::GetInstance().TriggerParticle(particle_group,
      sprite,
      cocos2d::CCPointZero,
      -1);
  }
  sprite->setPosition(ccp(0,22));
  sprite->setAnchorPoint(ccp(0.5f,0));
  pRankUpNode->addChild(sprite);

  //ProjectileAnimation* ani = new ProjectileAnimation();
  //ani->initWithName("levelup_1",true);
  //ani->setPosition(ccp(-2,-20));
  //ani->setAnchorPoint(ccp(0.5f,0));
  //pRankUpNode->addChild(ani);
  //ani->release();

  UILabelAtlas* label = static_cast<UILabelAtlas*>(head_layer->getWidgetByName("label_lv_"));
  CCString* value = CCString::createWithFormat("%d", basic_data_->rank());
  label->setStringValue(value->getCString());

  CCSprite* pSprite = CCSprite::create("ui/agoui_local_text/agoui_levelup_2.pvr.ccz");
  pSprite->setPosition(ccp(0,this->animation_->GetBoundingBox().size.height));
  pSprite->setAnchorPoint(ccp(0.5f,0));
  //CCCallFuncN* callback = CCCallFuncN::create(this, callfuncN_selector(PlayerMoveObject::rankUpAllFinished));
  CCRemoveSelf* removeSelf = CCRemoveSelf::create();
  CCSequence * seq = CCSequence::create(
    CCSpawn::create(
    CCFadeIn::create(0.1f),
    CCScaleTo::create(0.1f, pSprite->getScaleX()*2.5f,
    pSprite->getScaleY()*2.5),
    NULL),
    CCEaseOut::create(
    CCScaleTo::create(0.1f, pSprite->getScaleX(),
    pSprite->getScaleY()), 0.5f),
    CCDelayTime::create(1.0f),
    removeSelf,
    NULL);
  pSprite->runAction(seq);
  pRankUpNode->addChild(pSprite);
  this->animation_->addChild(pRankUpNode);
}

void PlayerMoveObject::rankUpAllFinished(cocos2d::CCNode* pNode)
{
  //assert(pNode != NULL && pNode->getParent() != NULL);
  //pNode->getParent()->removeFromParentAndCleanup(true);
}

} // namespace city
} // namespace taomee