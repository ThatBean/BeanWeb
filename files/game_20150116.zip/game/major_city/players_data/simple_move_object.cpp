//
//  simple_move_object.cpp
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//

#include "game/major_city/players_data/simple_move_object.h"

#include "engine/base/random_helper.h"
#include "game/major_city/players_data/move_data.h"
#include "game/major_city/pathfinding/pathfinding_planner.h"
#include "game/major_city/pathfinding/time_sliced_search.h"
#include "game/major_city/pathfinding/city_tiled_map.h"
#include "game/major_city/city_view/city_controller.h"

namespace taomee {
namespace city {
  
typedef TimeSlicedGraphSearch<GraphEdge, SimpleMoveObject> SearchAlgorithm;
  
SimpleMoveObject::SimpleMoveObject()
  : move_object_id_(kUnexistPlayerId),
    move_data_(NULL),
    animation_(NULL),
    path_planner_(NULL),
    is_searching_path_(false)
{
  path_planner_ = new PathPlanner<SimpleMoveObject, SearchAlgorithm>(this);
}
  
SimpleMoveObject::~SimpleMoveObject()
{
  CC_SAFE_DELETE(move_data_);
  CC_SAFE_DELETE(animation_);
  CC_SAFE_DELETE(path_planner_);
}

void SimpleMoveObject::Init(uint_32 move_object_id)
{
  move_object_id_ = move_object_id;
  
  move_data_ = new MoveData();
  animation_ = new PlayerSkeletonAnimation();
}
  
bool SimpleMoveObject::Update(float delta)
{
  move_data_->set_last_pos(animation_->getPosition());
  animation_->setPosition(move_data_->current_pos());
  this->freshZOrder();
  return true;
}

void SimpleMoveObject::ChangeAnimationToIndex(ePlayerAnimationType idx,
                                              const int cycle_count /*= -1*/,
                                              const float speed /*= 1.0f*/ )
{
  assert(animation_);
  animation_->Play(idx, cycle_count, speed);
}

void SimpleMoveObject::freshZOrder()
{
  // NOTE : last posiotion means last fresh z order's position, only fresh z order after 
  // move distance > 3.0 pixel
  if (fabsf(move_data_->current_pos().x-move_data_->last_z_fresh_pos().x) +
      fabsf(move_data_->current_pos().y-move_data_->last_z_fresh_pos().y) > 3.0f)
  {
    move_data_->set_last_z_fresh_pos(move_data_->current_pos());
    animation_->setZOrder(GetZorderByPosition(move_data_->current_pos()));
  }
}
  
void SimpleMoveObject::setNewDestinationInLastEdgeOfPathList(float distRadius)
{
  // path should be exist -- at least destination point MUST exist
  assert(move_data_->is_have_path_point());
  
  cocos2d::CCPoint sourcePos = cocos2d::CCPointZero;
  cocos2d::CCPoint targetPos = move_data_->path_list().back();
  
  // get source point for last edge
  std::list<CCPoint>::iterator it = move_data_->path_list().end();
  if (move_data_->path_list().size()==1)
  {
    it = move_data_->path_list().begin();
    sourcePos = move_data_->current_pos();
  }
  else
  {
    --it;
    --it;
    sourcePos = (*it);
    ++it;
  }
  
  // calculate new destination
  if (ccpDistanceSQ(sourcePos, targetPos) <= (distRadius * distRadius))
  {
    targetPos = sourcePos;
  }
  else
  {
    float xDis = targetPos.x - sourcePos.x;
    float yDis = targetPos.y - sourcePos.y;
    float dis = sqrtf(xDis*xDis + yDis*yDis)/random_lower_upper(50, 95)*100.0f;
    targetPos = ccp(targetPos.x-xDis*distRadius/dis,
                    targetPos.y-yDis*distRadius/dis);
  }
  
  // fresh destination point for last edge in path list
  (*it) = targetPos;
}

} // namespace city
} // namespace taomee