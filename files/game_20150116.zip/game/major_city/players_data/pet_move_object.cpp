//
//  pet_move_object.cpp
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//
#include "game/major_city/players_data/pet_move_object.h"

#include "game/major_city/players_data/player_move_object.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/pathfinding/city_tiled_map.h"

namespace taomee {
namespace city {

PetBasicData::PetBasicData()
  : pet_id_(0),
    pet_rank_(0)
{
  pet_name_.clear();
}

PetBasicData::PetBasicData(const PetBasicData* data)
{
  this->InitWithData(data);
}
  
void PetBasicData::InitWithData(const PetBasicData* data)
{
  this->set_pet_id(data->pet_id());
  this->set_pet_rank(data->pet_rank());
  this->set_pet_name(data->pet_name());
}
  
PetMoveObject::PetMoveObject(PlayerMoveObject* owner)
  : SimpleMoveObject(),
    need_force_follow_role_player_(false),
    pet_data_(new PetBasicData),
    owner_role_(owner),
    relax_time_(0.0f)
{
  owner_role_->set_pet_object(this);
}
  
PetMoveObject::~PetMoveObject()
{
  CC_SAFE_DELETE(pet_data_);
  owner_role_ = NULL;
}

bool PetMoveObject::Update( float delta )
{
  SimpleMoveObject::Update(delta);
  relax_time_ += delta;
  return true;
}

void PetMoveObject::Init(uint_32 move_object_id)
{
  SimpleMoveObject::Init(move_object_id);
  //std::string str[4] = { "lacks", "galen", "angus", "maggie"};
  //int idx = rand()%4;
  std::string str[1] = {"huanyan"};
  int idx = 0;
  animation_->Init(str[idx].c_str(), str[idx].c_str(), 0);
  this->move_data()->target_selection()->set_target_id(owner_role_->move_object_id());
}
  
void PetMoveObject::ResetLastDestinationPoint()
{
  // owner player id MUST exist
  assert(kUnexistPlayerId != move_data_->target_selection()->target_id());
  this->setNewDestinationInLastEdgeOfPathList(player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet);
}
  
bool PetMoveObject::IsCurrentTargetPositionTooFarAwayFromOwnerRole()
{
  assert(owner_role_);

  cocos2d::CCPoint selfPos = this->move_data()->destination_pos();
  cocos2d::CCPoint ownerPos = owner_role_->move_data()->destination_pos();
  return (ccpDistanceSQ(selfPos, ownerPos) >
          (player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet*
           player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet));
}
  
bool PetMoveObject::IsTooFarAwayFromOwnerRoleToWakeupForceRedirection()
{
  assert(owner_role_);
  
  cocos2d::CCPoint selfPos = this->move_data()->current_pos();
  cocos2d::CCPoint ownerPos = owner_role_->move_data()->current_pos();
  return (ccpDistanceSQ(selfPos, ownerPos) >
          2*(player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet*
             player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet));
}

bool PetMoveObject::IsTooFarAwayFromOwnerRole()
{
  assert(owner_role_);

  cocos2d::CCPoint selfPos = this->move_data()->current_pos();
  cocos2d::CCPoint ownerPos = owner_role_->move_data()->current_pos();
  return (ccpDistanceSQ(selfPos, ownerPos) >
          (player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet*
           player_ai::kMaxDistanceRadiusFromOwnerRoleOfPet));  
}
  
void PetMoveObject::SendFollowPathfindingRequest()
{
  if(move_data()->is_searching_path())
    return;

  //CCLog("Pet search follow path");
  need_force_follow_role_player_ = false;
  cocos2d::CCPoint desPos = owner_role_->move_data()->destination_pos();
  CityController::GetInstance().SendMoveObjectPathFindRequest(this, desPos);
}

void PetMoveObject::SendFindPathRequest( CCPoint& p )
{

}

void PetMoveObject::ChangeAnimationToIndex( ePlayerAnimationType idx, const int cycle_count /*= -1*/, const float speed /*= 1.0f*/ )
{
  assert(animation_);
  animation_->Play(kPlayerAnimationTypeIdle, cycle_count, speed);
}


} // namespace city
} // namespace taomee
