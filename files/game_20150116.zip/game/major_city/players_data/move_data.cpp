//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  move_data.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2014-2-12
//          Time:  11:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2014-2-12        1         create
//////////////////////////////////////////////////////////////

#include "game/major_city/players_data/move_data.h"

namespace taomee {
namespace city {
  
MoveData::MoveData()
  : velocity_factor_(1.0f),
    velocity_value_(200),
    move_speed_(cocos2d::CCPointZero),
    last_pos_(cocos2d::CCPointZero),
    current_pos_(cocos2d::CCPointZero),
    last_z_fresh_pos_(cocos2d::CCPointZero),
    is_searching_path_(false),
    ai_orig_state_(player_ai::kPlayerAIStateInvalid),
    ai_state_(player_ai::kPlayerAIStateInvalid),
    last_ai_state_(player_ai::kPlayerAIStateInvalid),
    motion_state_(player_ai::kPlayerMotionStateInvalid),
    last_motion_state_(player_ai::kPlayerMotionStateInvalid)
{
  
}

MoveData::~MoveData()
{
  
}
  
cocos2d::CCPoint MoveData::destination_pos()
{
  if (path_list_.size())
  {
    return path_list_.back();
  }
  return target_selection_.target_pos();
}

} // namespace major_city
} // namespace taomee