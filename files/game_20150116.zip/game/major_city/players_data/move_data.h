//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  move_data.h
//        Author:  Gaven
//       Version:  1
//          Date:  2014-2-12
//          Time:  11:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2014-2-12        1         create
//////////////////////////////////////////////////////////////

#ifndef __ChainChronicle__move_data__
#define __ChainChronicle__move_data__

#include <list>

#include "engine/base/cocos2d_wrapper.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"

using namespace cocos2d;
  
namespace taomee {
namespace city {

namespace player_ai
{
  class PlayerAIStateMachine;
  class PlayerMotionStateMachine;
};
  
class MoveData
{
 public:
  MoveData();
  ~MoveData();
  
 public:
  void        set_velocity_factor(float vFactor){velocity_factor_ = vFactor;}
  float       velocity_factor() { return velocity_factor_; }
  void        set_velocity_value(float value){velocity_value_ = value;}
  float       velocity_value(){return velocity_value_;}
  void        set_move_speed(const CCPoint& speed){move_speed_ = speed;}
  CCPoint     move_speed(){return move_speed_;}
  
  void        set_last_pos(const CCPoint& lPos)
  {
    last_pos_ = lPos;
  }
  CCPoint     last_pos() { return last_pos_; }
  
  void        set_current_pos(const CCPoint& cPos)
  {
    current_pos_ = cPos;
  }
  CCPoint     current_pos() 
  { 
    return current_pos_; 
  }
  
  CCPoint     last_z_fresh_pos() { return last_z_fresh_pos_; }
  void        set_last_z_fresh_pos(const CCPoint& zPos)
  {
    last_z_fresh_pos_ = zPos;
  }

  bool        is_searching_path(){return is_searching_path_;}
  void        set_is_searching_path(bool flag){is_searching_path_ = flag;}
  
  void        set_path_list(std::list<CCPoint>& path_list)
  {
    // mark new path found
    target_selection_.set_new_path_found(true);
    path_list_ = path_list;
  }
  std::list<CCPoint>&  path_list() { return path_list_; }
  bool        is_have_path_point(){return (path_list_.size() != 0);}
  CCPoint     get_next_path_point()
  {
    target_selection_.set_new_path_found(false);
    CCPoint p = path_list_.front();
    path_list_.pop_front();
    return p;
  }
  CCPoint     get_last_path_point(){return *(--path_list().end());}
  void        clean_path_list(){path_list_.clear();}

  player_ai::PlayerTargetSelection* target_selection(){return &target_selection_;}
  
  void        set_ai_orig_state(player_ai::ePlayerAIStateType origState)
  {
    ai_orig_state_ = origState;
  }
  player_ai::ePlayerAIStateType      ai_orig_state()
  {
    return ai_orig_state_;
  }
  
  void        set_ai_state(player_ai::ePlayerAIStateType currState)
  {
    ai_state_ = currState;
  }
  player_ai::ePlayerAIStateType      ai_state()
  {
    return ai_state_;
  }
  
  void        set_last_ai_state(player_ai::ePlayerAIStateType lastState)
  {
    last_ai_state_ = lastState;
  }
  player_ai::ePlayerAIStateType      last_ai_state()
  {
    return last_ai_state_;
  }
  
  void        set_motion_state(player_ai::ePlayerMotionStateType mState)
  {
    motion_state_ = mState;
  }
  player_ai::ePlayerMotionStateType  motion_state()
  {
    return motion_state_;
  }
  
  void        set_last_motion_state(player_ai::ePlayerMotionStateType lastMState)
  {
    last_motion_state_ = lastMState;
  }
  player_ai::ePlayerMotionStateType  last_motion_state()
  {
    return last_motion_state_;
  }
  
  cocos2d::CCPoint destination_pos();
  
 private: 
  // basic data
  // move velocity factor
  float       velocity_factor_;

  float       velocity_value_;

  CCPoint     move_speed_;
  // position in last update
  CCPoint     last_pos_;
  // current position
  CCPoint     current_pos_;
  // position for last z order fresh
  CCPoint     last_z_fresh_pos_;

  bool        is_searching_path_;

  std::list<CCPoint>  path_list_;

  player_ai::PlayerTargetSelection   target_selection_;
  
 private:// AI Data
  player_ai::ePlayerAIStateType      ai_orig_state_;
  player_ai::ePlayerAIStateType      ai_state_;
  player_ai::ePlayerAIStateType      last_ai_state_;
  player_ai::ePlayerMotionStateType  motion_state_;
  player_ai::ePlayerMotionStateType  last_motion_state_;

public:
  friend class player_ai::PlayerAIStateMachine;
  friend class player_ai::PlayerMotionStateMachine;
};
  
} // namespace city
} // namespace taomee

#endif /* defined(__ChainChronicle__move_data__) */
