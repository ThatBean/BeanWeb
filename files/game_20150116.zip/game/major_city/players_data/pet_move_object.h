//
//  pet_move_object.h
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//

#ifndef __ChainChronicle__pet_move_object__
#define __ChainChronicle__pet_move_object__

#include "game/major_city/players_data/simple_move_object.h"

namespace taomee {
namespace city {
  
class PlayerMoveObject;
  
class PetBasicData
{
public:
  PetBasicData();
  PetBasicData(const PetBasicData* data);
  ~PetBasicData() {}
  
  void InitWithData(const PetBasicData* data);
  
public: // getter & setter
  uint_32       pet_id() const { return pet_id_; }
  void          set_pet_id(uint_32 pId)
  {
    pet_id_ = pId;
  }
  
  uint_8        pet_rank() const { return pet_rank_; }
  void          set_pet_rank(uint_8 pRank)
  {
    pet_rank_ = pRank;
  }
  
  const std::string&   pet_name() const { return pet_name_; }
  void          set_pet_name(const std::string& pName)
  {
    pet_name_.clear();
    pet_name_ = pName;
  }
  
private:
  // pet data id -- mapping into pet.csv file
  uint_32       pet_id_;
  // player's level
  uint_8        pet_rank_;
  // nick name
  std::string   pet_name_;
};
  
class PetMoveObject : public SimpleMoveObject
{
public:
  PetMoveObject(PlayerMoveObject* owner);
  virtual ~PetMoveObject();
  
  virtual void Init(uint_32 move_object_id);

  virtual bool Update(float delta);
  
  virtual void ResetLastDestinationPoint();

  virtual void SendFindPathRequest(CCPoint& p);

  virtual void ChangeAnimationToIndex(ePlayerAnimationType idx, 
                                      const int cycle_count = -1,
                                      const float speed = 1.0f);
  
public:
  //this will be set as true when the role player (click) or (move)
  //this indicate pet should go to PetAIStateFollow
  //if pet in PetAIStateFollow send pathfind request once again
  bool               need_force_follow_role_player() { return need_force_follow_role_player_; }
  void               set_need_force_follow_role_player(bool refreshFlag)
  {
    need_force_follow_role_player_ = refreshFlag;
  }
  
  PlayerMoveObject*  owner_role() { return owner_role_; }
  
  PetBasicData*      pet_data() { return pet_data_; }

  float              relax_time() { return relax_time_; }
  void               set_relax_time(float relax_time) { relax_time_ = relax_time; }
  
public:
  bool IsCurrentTargetPositionTooFarAwayFromOwnerRole();
  bool IsTooFarAwayFromOwnerRoleToWakeupForceRedirection();
  bool IsTooFarAwayFromOwnerRole();
  
  //alway send follow request on AIPetFollowState
  void SendFollowPathfindingRequest();

protected:
  bool               need_force_follow_role_player_;
  PetBasicData*      pet_data_;
  PlayerMoveObject*  owner_role_;
  float              relax_time_;
};
  
} // namespace city
} // namespace taomee

#endif /* defined(__ChainChronicle__pet_move_object__) */
