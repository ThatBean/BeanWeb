//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: challenge_enemy_object.h
//        Author: robbiepan
//          Date: 2014/3/11 14:58
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2014/3/11      add
//////////////////////////////////////////////////////////////

#ifndef CHALLENGE_ENEMY_OBJECT_H
#define CHALLENGE_ENEMY_OBJECT_H

#include "engine/base/basictypes.h"
#include "game/user_data/user_data_constants.h"
#include "engine/base/cocos2d_wrapper.h"
namespace taomee {
namespace city {
  

class ChallengeEnemyTeamMemberData
{
public:
  ChallengeEnemyTeamMemberData();
  ~ChallengeEnemyTeamMemberData();
  
public: // getter & setter
  uint_32   card_id() const { return card_id_; }
  void          set_card_id(uint_32 card_id)
  {
    card_id_ = card_id;
  }
  
  uint_8       role_id() const { return role_id_; }
  void          set_role_id(uint_32 rId)
  {
    role_id_ = rId;
  }
  
  uint_32       level() const { return level_; }
  void          set_level(uint_32 level)
  {
    level_ = level;
  }
public:
  void          Clear();
private:
  uint_32      card_id_;
  // card's level
  uint_32      level_;
  // role data id -- team position id
  uint_8       role_id_;

  
};
  
class ChallengeEnemyObject
{
public:
  ChallengeEnemyObject();
  virtual ~ChallengeEnemyObject();
  
public: // getter & setter
  uint_32       user_id() const { return user_id_; }
  void          set_user_id(uint_32 user_id)
  {
    user_id_ = user_id;
  }

  uint_8        role_id() const { return role_id_; }
  void          set_role_id(uint_32 rId)
  {
    role_id_ = rId;
  }

  uint_8        up_star() const { return up_star_; }
  void          set_up_star(uint_32 up_star)
  {
    up_star_ = up_star;
  }

  uint_32       level() const { return level_; }
  void          set_level(uint_32 level)
  {
    level_ = level;
  }

  const std::string&   nick_name() const { return nick_name_; }
  void          set_nick_name(const std::string& name)
  {
    nick_name_ = name;
  }

  ChallengeEnemyTeamMemberData* team_member(uint_8 index);
public:
  void          Clear();
private:

  uint_32       user_id_;
  // card's level
  uint_32       level_;
  // role data id 
  uint_8        role_id_;
  // up_star
  uint_8        up_star_;
  // nick name
  std::string   nick_name_;

private:
  ChallengeEnemyTeamMemberData team_member_[data::kMaxCharacterCountInOneTeam];  

};

} // namespace city
} // namespace taomee

#endif