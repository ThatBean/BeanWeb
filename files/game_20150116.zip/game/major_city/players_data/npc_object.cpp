//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: npc_object.cpp
//        Author: robbiepan
//          Date: 2014/2/21 13:56
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2014/2/21      add
//////////////////////////////////////////////////////////////

#include "game/major_city/players_data/npc_object.h"
#include "engine/animation/player_skeleton_animation.h"
#include "game/game_manager/data_manager.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {
namespace city {
  
  
NpcObject::NpcObject()
  : npc_id_(kUnexistNpcId),
    npc_type_(kNpcTypeNone),
    animation_(NULL)
{
  nick_name_.clear();
}
  
NpcObject::~NpcObject()
{
  if(animation_) 
    delete animation_;
}

void NpcObject::Init(uint_32 npc_id, uint_32 char_id, uint_32 func_id,const std::string& func_res_name)
{
  npc_id_ = npc_id;
  func_id_ = func_id;
  char_id_ = char_id;
  icon_name_ = func_res_name;
  animation_ = new PlayerSkeletonAnimation();
  CharacterData* pData = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(char_id);
  assert(pData);
  animation_->Init(pData->GetName().c_str(), pData->GetName().c_str(), 0);
  animation_->ChangeDirection(kPlayerAnimationDirectionLeft);
  animation_->Play(kPlayerAnimationTypeIdle);
  set_head_icon();
}
  
bool NpcObject::Update(float delta)
{
  return true;
}

void NpcObject::set_current_pos( const CCPoint& cPos )
{
  if(animation_) 
  {
    animation_->setPosition(cPos);
  }
}

cocos2d::CCPoint NpcObject::current_pos()
{
  assert(animation_);
  return animation_->getPosition();
}

void NpcObject::set_head_icon()
{
  
  animation_->removeChildByTag(kNpcHeadIconTag);

  uint_32 npc_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>
    ("script/mission/main_mission_util.lua", "QueryNextMissionRelativeNpcId");

  string func_res_png;
  if ( npc_id == npc_id_ )
  {
    func_res_png = "ui/agoui_npc_func_icon/head_task.pvr.ccz"; 
  }
  else
  { 
    if( true == icon_name_.empty() )
    {
      return;
    }
    func_res_png = "ui/agoui_npc_func_icon/head_" + icon_name_ + ".pvr.ccz"; 
  }

  assert(animation_);
  CCLayer *head_layer = CCLayer::create();
  CCSprite* func_res_sprite = CCSprite::create(func_res_png.c_str());

  func_res_sprite->setPosition(ccp(0.0f, 0.0f));
  func_res_sprite->setAnchorPoint(ccp(0.0, 0.5f));
  head_layer->addChild(func_res_sprite);

  head_layer->ignoreAnchorPointForPosition(false);
  head_layer->setAnchorPoint(ccp(0.5, 0.0));
  head_layer->setContentSize(func_res_sprite->getContentSize());
  head_layer->setTag(kNpcHeadIconTag);

  animation_->AddNodeOnBone(kPlayerBoneTypeHeadBar, head_layer);
}

} // namespace city
} // namespace taomee