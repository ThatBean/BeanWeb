//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: challenge_enemy_object.h.cpp
//        Author: robbiepan
//          Date: 2014/3/11 14:58
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2014/3/11      add
//////////////////////////////////////////////////////////////
#include "game/major_city/players_data/challenge_enemy_object.h"
#include "engine/base/basictypes.h"
namespace taomee {
namespace city {

ChallengeEnemyTeamMemberData::ChallengeEnemyTeamMemberData()
  : card_id_(0),
    role_id_(0),
    level_(0)
{

}

ChallengeEnemyTeamMemberData::~ChallengeEnemyTeamMemberData()
{
  
}

void ChallengeEnemyTeamMemberData::Clear()
{
  card_id_ = 0;
  role_id_ = 0;
//  up_star_ = 0;
  level_ = 0;
}


  
ChallengeEnemyObject::ChallengeEnemyObject()  
  : user_id_(0),
  level_(0),
  role_id_(0),
  up_star_(0)
{
  nick_name_.clear();
}

ChallengeEnemyObject::~ChallengeEnemyObject()
{

}

void ChallengeEnemyObject::Clear()
{
  for (int i = 0; i <data::kMaxCharacterCountInOneTeam; ++i)
  {
    team_member_[i].Clear();
  }
  user_id_ = 0;
  level_ = 0;
  role_id_ = 0;
  up_star_ = 0;
  nick_name_.clear();
}

ChallengeEnemyTeamMemberData* ChallengeEnemyObject::team_member( uint_8 index )
{
  assert(index >=0 && index < data::kMaxCharacterCountInOneTeam);
  return &team_member_[index];
}



} // namespace city
} // namespace taomee