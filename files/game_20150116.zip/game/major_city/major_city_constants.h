//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  major_city_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2014-2-13
//          Time:  13:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2014-2-13        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_major_city_constants_h
#define ChainChronicle_major_city_constants_h

#include "engine/base/basictypes.h"
#include <string>

namespace taomee {
namespace city {
  
enum ePlayerDirection
{
  kPlayerDirectionNone        = 0,
  kPlayerDirectionLeft        = 1,
  kPlayerDirectionLeftFront   = 2,
  kPlayerDirectionLeftBack    = 3,
  kPlayerDirectionRight       = 4,
  kPlayerDirectionRightFront  = 5,
  kPlayerDirectionRightBack   = 6,
  kPlayerDirectionMax,
};
  
enum
{
  kUnexistSimpleMoveObjectId  = 0,
  kUnexistPlayerId            = 0,
  kUnexistNpcId               = 0,
  kUnexistPetId               = 0,
};
  
enum
{
  kInvalidNodeIndex           = -1,
};
  
enum eSearchResult
{
  kTargetNotFound             = 0,
  kTargetFound                = 1,
  kSearchIncomplete           = 2,
};

enum eNpcType
{
  kNpcTypeNone                = 0,
  kNpcTypeTalk                = 1,
  kNpcTypeShop                = 2,
};
  
const uint_32     kMaxNickNameLength            = 32;
const int         kMaxPlayerDistanceToNPC       = 80;
//// tiles count is not the same in different map instance 
//extern uint_32    kCityMapTiledGridRowCount;
//extern uint_32    kCityMapTiledGridCoulmnCount;
//const int_32      kCityMapTiledGridWidth        = 32;
//const int_32      kCityMapTiledGridHeight       = 32;

enum
{
  kRoleObjectIdForLocalPlayer = 1,
  kRolePetIdForLocalPlayer    = 2,
};
  
const uint_32     kMaxPlayerCount               = 20;


const uint_32     kMaxChallengeEnemyCount       = 4;

const uint_32     kNpcHeadIconTag                = 4323555;

#define DISTANCE_SQ_THRESHOLD 1.0
  
} // namespace city
} // namespace taomee

#endif /* ChainChronicle_major_city_constants_h */
