//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_layer_loader.cpp
//        Author: peteryu
//          Date: 2014/2/12 12:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////
#include "game/major_city/city_view/city_layer_loader.h"

#include "engine/script/lua_tinker_manager.h"
#include "game/major_city/city_view/city_layer.h"
#include "game/major_city/major_city_constants.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/pathfinding/city_tiled_map.h"
#include "game/major_city/city_view/city_map_constants.h"

using namespace cocos2d::extension;

namespace taomee {
namespace city {

/*  each grid's size in pixel == 32*32 
 (0,0)  (1,0)  (2,0) ... (107,0)
 (0,1)  (1,1)  (2,1) ... (107,1)
   .      .      .   ...    .
   .      .      .   ...    .
   .      .      .   ...    .
 (0,59) (1,59) (2,59) ...(107,59)
 */
  
CityLayerLoader::CityLayerLoader()
{

}

CityLayerLoader::~CityLayerLoader()
{

}

CityLayer* CityLayerLoader::CreateCityLayer(string map_name, bool is_create_tiledmap)
{
  map_name_ = map_name;
  CityLayer *city_layer = CityLayer::create();

  CCNode *scence_node = CCSSceneReader::sharedSceneReader()->createNodeWithSceneFile((kMapDirectory + map_name + "/" + map_name + ".json").c_str());
  CCNode *map_contain_node = scence_node->getChildByTag(kSceneNodeTagTiledMap);
  CCNode *map_node = map_contain_node->getComponent(kTiledMapComponentName.c_str())->getNode();
  city_layer->setContentSize(map_node->getContentSize());
  city_layer->setPosition(map_contain_node->getPosition());
  city_layer->ignoreAnchorPointForPosition(false);
  city_layer->setAnchorPoint(ccp(0.0, 0.0));
  city_layer->setPosition(ccp(568 - map_node->getContentSize().width / 2,
                              320 - map_node->getContentSize().height / 2));
  city_layer->AddSceneNode(scence_node);

  LoadNPCPostion(scence_node, city_layer);
  LoadBornArea(scence_node, city_layer);
  if(is_create_tiledmap)
    LoadPathTile(map_node);
  
  CreateBackgroundBatchNode(scence_node);
  CreateDecorationBatchNode(scence_node);

  return city_layer;
}

void CityLayerLoader::LoadNPCPostion(CCNode *scene_node, CityLayer *city_layer)
{
  CCArray *array = scene_node->getChildByTag(kSceneNodeTagCity)->getChildren();
  CCObject *object;
  CCNode   *node;
  CCArray *temp_array = CCArray::create();

  CCARRAY_FOREACH(array, object)
  {
    node = ((CCNode *)object);
    if(node->getTag() >= kSceneNodeTagCityNPCStart && node->getTag() <= kSceneNodeTagCityNPCEnd)
    {
      city_layer->AddNPCTagPos(node->getTag(), node->getPosition());
      temp_array->addObject(node);
    }
  }

  CCARRAY_FOREACH(temp_array, object)
  {
    node = ((CCNode *)object);
    node->removeFromParentAndCleanup(true);
  }

  temp_array->removeAllObjects();
}

void CityLayerLoader::LoadBornArea(CCNode *scene_node, CityLayer *city_layer)
{
  CCArray *array = scene_node->getChildByTag(kSceneNodeTagCity)->getChildren();
  CCObject *object;
  CCNode   *node;
  CCArray *temp_array = CCArray::create();

  CCARRAY_FOREACH(array, object)
  {
    node = ((CCNode *)object);
    if(node->getTag() >= kSceneNodeTagCityBornPosStart && node->getTag() <= kSceneNodeTagCityBornPosEnd)
    {
      city_layer->AddBornPos(node->getPosition());
      temp_array->addObject(node);
    }
  }

  CCARRAY_FOREACH(temp_array, object)
  {
    node = ((CCNode *)object);
    node->removeFromParentAndCleanup(true);
  }

  temp_array->removeAllObjects();
}

void CityLayerLoader::LoadPathTile(CCNode *map_node)
{
  CCTMXTiledMap *tile_map = (CCTMXTiledMap*)map_node;
  CCSize tile_size = tile_map->getTileSize();
  CCSize map_size = tile_map->getMapSize();
  // 1. create tiled map grids with tiles count & tile size
  CityController::GetInstance().CreateTiledMapWithMapSizeAndTileSize(map_size, tile_size);
  // 2. load all coverd tiles coordinate to mark unwalkable grids
  CCTMXLayer* path_layer = tile_map->layerNamed(kPathLayerNameInTiledMap.c_str());
  path_layer->removeFromParentAndCleanup(true);
  for(int h = 0; h < map_size.height; ++h)
  {
    for(int w = 0; w < map_size.width; ++w)
    {
      CCSprite* tile = path_layer->tileAt(ccp(w, h));
      if(tile)
      {
        cocos2d::CCPoint tilePos = TiledCoordinateFromLocation(ccp(tile->getPositionX(), tile->getPositionY() + tile_size.height));
        CityController::GetInstance().tiled_map()->CoverTileAtPos(tilePos);
      }
    }
  }
}

void CityLayerLoader::CreateBackgroundBatchNode( CCNode *scene_node )
{
  CCNode    *back_node = scene_node->getChildByTag(kSceneNodeTagBackground);
  CCArray   *child_array = back_node->getChildren();
  CCObject  *obj;
  CCNode    *node;
  CCComponent  *compoment;
  CCSprite  *sprite;
  CCSprite  *new_sprite;
  int       tag = 0;

  string    res_dir     = kMapDirectory + map_name_ + "/" + kMapResDirectory;
  string    plist_path  = res_dir + kMapResPListName;
  string    png_path    = res_dir + kMapResPNGName;

  CCSpriteBatchNode *batch_node = CCSpriteBatchNode::create(png_path.c_str());

  //normal sprite has user object
  //map do not have
  CCARRAY_FOREACH(child_array, obj)
  {
    node      = ((CCNode *)obj);
    compoment = node->getComponent(kCCSpriteComponentName.c_str());

    if(compoment == NULL)
      continue;

    sprite    = (CCSprite *)compoment->getNode();

    //do not batch node map
    if(sprite->getUserObject() == NULL)
      continue;
    
    string  png_name = ((CCString *)sprite->getUserObject())->getCString();
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile \
      (plist_path.c_str(), png_path.c_str());
    new_sprite = CCSprite::createWithSpriteFrameName(png_name.c_str());
    new_sprite->setPosition(node->getPosition());

    //node->removeFromParentAndCleanup(true);
    batch_node->addChild(new_sprite, 0, tag++);
  }

  CCARRAY_FOREACH(child_array, obj)
  {
    node      = ((CCNode *)obj);
    compoment = node->getComponent(kCCSpriteComponentName.c_str());

    if(compoment == NULL)
      continue;

    sprite    = (CCSprite *)compoment->getNode();

    //do not remove map node
    if(sprite->getUserObject() == NULL)
      continue;

    node->removeFromParentAndCleanup(true);
  }

  batch_node->setZOrder(0);
  back_node->addChild(batch_node);
}

void CityLayerLoader::CreateDecorationBatchNode( CCNode *scene_node )
{
  CCNode    *city_node = scene_node->getChildByTag(kSceneNodeTagCity);
  CCArray   *child_array = city_node->getChildren();
  CCObject  *obj;
  CCNode    *node;
  CCComponent  *compoment;
  CCSprite  *sprite;
  CCSprite  *new_sprite;

  string    res_dir     = kMapDirectory + map_name_ + "/" + kMapResDirectory;
  string    plist_path  = res_dir + kMapResPListName;
  string    png_path    = res_dir + kMapResPNGName;

  //CCSpriteBatchNode *batch_node = CCSpriteBatchNode::create(png_path.c_str());
  CCArray *temp_array = CCArray::create();

  //normal sprite has user object
  //create new sprite
  CCARRAY_FOREACH(child_array, obj)
  {
    node      = ((CCNode *)obj);
    compoment = node->getComponent(kCCSpriteComponentName.c_str());

    if(compoment == NULL)
      continue;

    sprite    = (CCSprite *)compoment->getNode();

    if(sprite->getUserObject() == NULL)
      continue;

    string  png_name = ((CCString *)sprite->getUserObject())->getCString();
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile \
      (plist_path.c_str(), png_path.c_str());
    new_sprite = CCSprite::createWithSpriteFrameName(png_name.c_str());
    new_sprite->setPosition(node->getPosition());
    new_sprite->setPositionY(node->getPositionY() - sprite->getContentSize().height * 0.5);
    new_sprite->setAnchorPoint(ccp(0.5, 0.0));
    temp_array->addObject(new_sprite);
  }

  //remove old sprite
  CCARRAY_FOREACH(child_array, obj)
  {
    node      = ((CCNode *)obj);
    compoment = node->getComponent(kCCSpriteComponentName.c_str());

    if(compoment == NULL)
      continue;

    sprite    = (CCSprite *)compoment->getNode();

    if(sprite->getUserObject() == NULL)
      continue;

    node->removeFromParentAndCleanup(true);
  }

  //add new sprite to city node
  CCARRAY_FOREACH(temp_array, obj)
  {
    node      = ((CCNode *)obj);
    city_node->addChild(node);
    node->setZOrder(GetZorderByPosition(node->getPosition()));
    CCLog("Decoration ZOrder: x:%f, y:%f, z:%d, add:%x", node->getPosition().x, \
      node->getPosition().y, node->getZOrder(), &node);
  }

  temp_array->removeAllObjects();
}

}
} // namespace taomee