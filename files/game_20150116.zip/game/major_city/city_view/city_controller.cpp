//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_controller.cpp
//        Author: peteryu
//          Date: 2014/2/12 12:01
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#include "game/major_city/city_view/city_controller.h"

#include <list>

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/random_helper.h"
#include "engine/base/utils_string.h"
#include "game/effect/action_brigthness_scale.h"
#include "game/major_city/city_view/city_view.h"
#include "game/major_city/city_view/city_layer.h"
#include "game/major_city/city_view/city_layer_loader.h"
#include "game/major_city/city_view/pos_reporter.h"
#include "game/major_city/city_view/touch/city_touch_handler.h"
#include "game/major_city/pathfinding/city_tiled_map.h"
#include "game/major_city/pathfinding/pathfinding_planner.h"
#include "game/major_city/players_data/player_move_object.h"
#include "game/major_city/players_data/pet_move_object.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_constants.h"
#include "game/major_city/players_ai/player_intent_state/player_ai_state_machine.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_constants.h"
#include "game/major_city/players_ai/player_motion_state/player_motion_state_machine.h"
#include "game/major_city/players_ai/target_selection/player_target_selection.h"
#include "game/major_city/city_view/touch/city_touch_point_animation.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/game_manager.h"
#include "game/user_data/user_info.h"
#include "network/net_client_tcp/protocol/cpp/login.pb.h"
#include "network/net_client_tcp/net_session_tcp.h"
#include "network/net_client_tcp/protocol/cpp/mcs.pb.h"
#include "network/net_client_tcp/protocol/cpp/switch.pb.h"
#include "game/account/account_manager.h"
#include "network/net_constant.h"
#include "engine/base/loggermanager.h"

using namespace cocos2d::extension;

namespace taomee{
namespace city{


CityControllerListener* CityControllerListener::create()
{
  CityControllerListener* pRet = new CityControllerListener();
  if (pRet)
  {
    pRet->autorelease();
    return pRet;
  }
  CC_SAFE_DELETE(pRet);
  return NULL;
}

CityControllerListener::~CityControllerListener()
{
  unRegisterEventListener();
}

CityControllerListener::CityControllerListener()
{

}

void  CityControllerListener::registerEventListener()
{
  CCNotificationCenter::sharedNotificationCenter()->addObserver(this, callfuncO_selector(CityControllerListener::onRankLevelUpEvent), "onRankLevelUp", NULL);
}

void  CityControllerListener::unRegisterEventListener()
{
  CCNotificationCenter::sharedNotificationCenter()->removeObserver(this,"onRankLevelUp");
}

void  CityControllerListener::onRankLevelUpEvent(cocos2d::CCObject* obj)
{
  CityController::GetInstance().onRankLevelUpEvent();
}


CityController::CityController()
  : global_object_index_(0),
    create_interval_(0.0f),
    tiled_map_(NULL),
    path_manager_(NULL),
    city_view_(NULL),
    city_touch_handler_(NULL),
    pos_reporter_(NULL),
//    pvp_connection_(NULL),
    announcement_connection_(NULL),
    chat_reporter_(NULL),
    root_scene_(NULL),
    role_move_object_(NULL),
    role_pet_(NULL),
    city_scene_change_state_(kCitySceneChangeStateNone),
    is_other_object_visable_(true),
    is_pos_sync_active_(false),
    is_switch_city_(false),
    is_waitting_switch_scene_response_(false)
{
    mEventListener = CityControllerListener::create();
    mEventListener->retain();
}

CityController::~CityController()
{
  mEventListener->release();
}

CityController& CityController::GetInstance()
{
  static CityController* X = NULL;
  if (!X)
  {
    X = new CityController();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
  }
  return *X;
}

/**************************State Manage****************************/
void CityController::Restart()
{
  city_scene_change_state_ = kCitySceneChangeStateNone;
}
void CityController::Start()
{
  CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/agoui_card/agoui_card_ex.plist","ui/agoui_card/agoui_card_ex.pvr.ccz");

  int BackTypeId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/main_mission_util.lua", "QueryIsNeedToGoBack");
  //�ж�����
  if (BackTypeId!=100&&!is_switch_city_)
  {
	   LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua", "OpenCheckpointSelectUI",BackTypeId);
  }


  //LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "exitFightSceneNotifyHdr");

  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "OpenOfflineExpMsgBox");

  switch(city_scene_change_state_)
  {
  case kCitySceneChangeStateNone:
    StartCitySceneFirstly();
    break;
  case kCitySceneChangeStateBattle:
    StartCitySceneBackFromBattle();
    break;
  case kCitySceneChangeStateOtherScene:
    StartCitySceneBackFromOtherScene();
    break;
  case kCitySceneChangeStateSwitchScene:
    StartCitySceneSwitchScene();
    break;
  }
  city_scene_change_state_ = kCitySceneChangeStateNone;

  CCTextureCache::sharedTextureCache()->printAllTextures();
}

void CityController::End()
{
  assert(city_scene_change_state_ != kCitySceneChangeStateNone);

  switch(city_scene_change_state_)
  {
  case kCitySceneChangeStateBattle:
    EndCitySceneToBattle();
    break;
  case kCitySceneChangeStateOtherScene:
    EndCitySceneToOtherScene();
    break;
  case kCitySceneChangeStateSwitchScene:
    EndCitySceneToSwithScene();
    break;
  }  
  GameManager::GetInstance().CityStateEnd();
}

void CityController::UpdateEachFrame( float delta )
{
  // 1.update zorder & AI for all added move objects on map view
  for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
    itr != move_objects_.end(); ++itr)
  {
    player_ai::PlayerAIStateMachine::GetInstance().Update(*itr, delta);
    (*itr)->Update(delta);
  }
  // 2.update for pathfinding
  path_manager_->UpdateSearches();
  // 3.update for city layer's position
  this->updateCityLayer();
  // 4.check for objects creatation
  this->createRemotePlayerAndPetByTimeInterval(delta);
  // 5. check for position report to server
  pos_reporter_->UpdatePositionReporter(delta);
}

/**************************Scene Manage****************************/

void CityController::onRankLevelUpEvent()
{
  if (role_move_object_)
  {
    int new_rank = DataManager::GetInstance().user_info()->rank();
    if (new_rank > role_move_object_->basic_data()->rank())
    {
      role_move_object_->basic_data()->set_rank(new_rank);
      PlayRankUpAnmi();
    }
  }
}

void CityController::StartCitySceneFirstly()
{
  net::SampleTcpClient::GetInstance().StartConnect();
  createCityScene();
  createNPCData();
  createPathPlanerAndPosRepoter();
  setNotifyAndChatConnectionToOnCityScene();
  createPlayerAndPetForLocalUser(false);
  createAllTCPConnection();

  //��ʱ��������
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/main.lua", "LoginSuccessHdr");//��һ�ε�¼�ɹ�
  mEventListener->registerEventListener();
}

void CityController::StartCitySceneBackFromBattle()
{
  createCityScene();
  createNPCData();
  createPathPlanerAndPosRepoter();
  setNotifyAndChatConnectionToOnCityScene();
  createPlayerAndPetForLocalUser(true);
  //createPvpTCPConnection();
  createAnnouncementTCPConnection();

  // need switch map if we do not enter default map
  if(DataManager::GetInstance().user_info()->get_current_city_map_id() != 0)
  {
    //is_waitting_switch_scene_response_ = true;
//     pvp_connection_->SwitchCityMapWithMapId(DataManager::GetInstance().user_info()->get_current_city_map_id(),
//                                             role_move_object_->move_data()->current_pos().x, 
//                                             role_move_object_->move_data()->current_pos().y);
    //is_switch_city_ = false;
    //pos_reporter_->set_is_ignore_next_pos(true);

    //CCLog("Switch New City Id: %ld, x: %f, y: %f",  DataManager::GetInstance().user_info()->get_current_city_map_id(),
    //                                                role_move_object_->move_data()->current_pos().x, 
    //                                                role_move_object_->move_data()->current_pos().y);
  }
  mEventListener->registerEventListener();
}

void CityController::StartCitySceneBackFromOtherScene()
{
  createCityScene(false);
  createNPCData();
  createPathPlanerAndPosRepoter();
  setNotifyAndChatConnectionToOnCityScene();
  createPlayerAndPetForLocalUser(true);
  mEventListener->registerEventListener();
}

void CityController::StartCitySceneSwitchScene()
{
  is_waitting_switch_scene_response_ = true;
  createCityScene();
  createNPCData();
  createPathPlanerAndPosRepoter();
  setNotifyAndChatConnectionToOnCityScene();
  createPlayerAndPetForLocalUser(false);
  
//   pvp_connection_->SwitchCityMapWithMapId(DataManager::GetInstance().user_info()->get_current_city_map_id(),
//                                           role_move_object_->move_data()->current_pos().x, 
//                                           role_move_object_->move_data()->current_pos().y);
  is_switch_city_ = false;
  pos_reporter_->set_is_ignore_next_pos(true);

  CCLog("Switch New City Id: %ld, x: %f, y: %f",  DataManager::GetInstance().user_info()->get_current_city_map_id(),
                                                  role_move_object_->move_data()->current_pos().x, 
                                                  role_move_object_->move_data()->current_pos().y);

  //for swich scene send proto dylan
  // set header
  boost::shared_ptr<net::NetSessionTcp> post_pos_requset = boost::make_shared<net::NetSessionTcp>();
  post_pos_requset->set_request_cmd(ACC::cli_switch_scene_cmd);
  post_pos_requset->set_request_ower(taomee::account::AccountManager::GetInstance().user_id_str().c_str());

  // set required paramters
  ACC::cli_switch_scene_in message_in;
  message_in.set_id(DataManager::GetInstance().user_info()->get_current_city_map_id());
  message_in.set_x(role_move_object_->move_data()->current_pos().x);
  message_in.set_y(role_move_object_->move_data()->current_pos().y);
  post_pos_requset->set_message_in<ACC::cli_switch_scene_in>(message_in);
  post_pos_requset->SubscribeReciveBodyComplete(this, &CityController::OnSwitchSceneCompleted);

  // send
  net::SampleTcpClient::GetInstance().SendRequest(post_pos_requset);
}

void CityController::EndCitySceneToBattle()
{
  //cleanPvpTCPConnection();
  cleanAnnouncementTCPConnection();
  cleanAllConnnection();
  setNotifyConnectionToRemovedCityScene();
  //cleanUncreateList();
  saveAllMoveObjectsBasicInfo();
  cleanPlayerAndNpcData();
  CityTouchPointAnimationManager::GetInstance().PurgeInstance();
  cleanPathPlanerAndPosRepoter();
  cleanCityScene();
  cleanTiledMap();
  LoggerManager::msCityPos->info("EndCitySceneToBattle");
  mEventListener->unRegisterEventListener();
}

void CityController::EndCitySceneToOtherScene()
{
  setNotifyConnectionToRemovedCityScene();
  saveAllMoveObjectsBasicInfo();
  cleanPlayerAndNpcData();
  CityTouchPointAnimationManager::GetInstance().PurgeInstance();
  cleanCityScene();
  //cleanTiledMap();
  cleanPathPlanerAndPosRepoter();
  LoggerManager::msCityPos->info("EndCitySceneToOtherScene");
  mEventListener->unRegisterEventListener();
}

void CityController::EndCitySceneToSwithScene()
{
  cleanAllConnnection();
  cleanUncreateList();
  cleanPlayerAndNpcData();
  CityTouchPointAnimationManager::GetInstance().PurgeInstance();
  cleanPathPlanerAndPosRepoter();
  cleanCityScene();
  cleanTiledMap();
  cleanPathPlanerAndPosRepoter();
  LoggerManager::msCityPos->info("EndCitySceneToSwithScene");
  mEventListener->unRegisterEventListener();
}

/**************************Touch & Path Finding****************************/

void CityController::SendMoveObjectPathFindRequest(SimpleMoveObject* object, CCPoint p)
{
  if (false==IsTileCoordinateInRange(TiledCoordinateFromLocation(p)) ||
    object->move_data()->is_searching_path())
  {
    return;
  }  
  if (this->tiled_map()->CanWalkableBetween(object->move_data()->current_pos(), p))
  {
    std::list<CCPoint> path_list;

    path_list.push_back(p);

    this->OnMoveObjectPathFound(object, path_list);
  }
  else
  {
    //CCLog("Can not move to destination directly, Find path.");
    object->move_data()->set_is_searching_path(true);
    object->path_planner()->requestPathToTarget(p);
  }
}

void CityController::OnMoveObjectPathNotFound(SimpleMoveObject *object)
{
  object->move_data()->set_is_searching_path(false);
  assert(false);
}

void CityController::OnMoveObjectPathFound(SimpleMoveObject* object)
{
  Path pathList;
  assert(object && object->path_planner());
  object->path_planner()->GetPath(&pathList);
  std::list<CCPoint> pointsList;
  for (Path::iterator it = pathList.begin(); it != pathList.end(); ++it)
  {
    pointsList.push_back((*it).source());
  }
  // erase current source point
  pointsList.pop_front();
  pointsList.push_back(pathList.back().destination());
  object->move_data()->set_is_searching_path(false);
  this->OnMoveObjectPathFound(object, pointsList);
}

void CityController::OnMoveObjectPathFound(SimpleMoveObject* object, list<CCPoint>& path_list)
{
  if(path_list.size() == 0)
  {
    return;
  }

  object->move_data()->set_path_list(path_list);
  object->ResetLastDestinationPoint();

  PlayerMoveObject* player = dynamic_cast<PlayerMoveObject*>(object);
  // role player need report new pos
  if(player == role_move_object_)
  {
    // set position reporter info -- switch on & position
    pos_reporter_->set_switch_flag(true);
    pos_reporter_->set_new_pos(object->move_data()->get_last_path_point());
    //CCLog("-----------------------Switch new pos x: %f, y: %f", object->move_data()->get_last_path_point().x, object->move_data()->get_last_path_point().y);
  }
}

void CityController::OnTouncNpcEvent( uint_32 npc_id )
{
  std::list<NpcObject*>::iterator it = npc_objects_.begin();
  for ( ; it != npc_objects_.end(); ++it)
  {
    if (npc_id == (*it)->npc_id())
    {
      break;
    }
  }
  if (it == npc_objects_.end())
  { // selected NPC is not exist
    assert(false);
    return;
  }
  role_move_object_->move_data()->target_selection()->set_target_pos((*it)->current_pos());
  // mark touch npc
  (*it)->animation()->GetArmature()->runAction(ActionBrightnessScale::create(1));
  role_move_object_->move_data()->target_selection()->set_target_id(npc_id);
  this->SendMoveObjectPathFindRequest(role_move_object_, (*it)->current_pos());
  CityController::GetInstance().role_move_object()->move_data()->set_ai_state(player_ai::kPlayerAIStateGoNPC);
}

/**************************Getter&Setter****************************/
  
void CityController::CreateTiledMapWithMapSizeAndTileSize(cocos2d::CCSize mapSize,
  cocos2d::CCSize tileSize)
{
  assert(!tiled_map_);
  tiled_map_ = new CityTiledMap(mapSize.width, mapSize.height, tileSize.width, tileSize.height);
}

void CityController::SetOtherObjectVisable( bool is_visable )
{
  is_other_object_visable_ = is_visable;

  for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
    itr != move_objects_.end(); ++itr)
  {
    if(*itr != role_move_object_ && *itr != role_pet_)
      (*itr)->animation()->setVisible(is_visable);
  }
}

CCPoint CityController::GetRandomBornPos()
{
  CCPoint pos;
  do 
  {    
    //assert(city_view_ && city_view_->GetCityLayer());
    if (city_view_ == NULL)
    {
      return ccp(0,0);
    }
    pos = city_view_->GetCityLayer()->GetRandomBornPos();
  } while (!tiled_map_->CanUnitTraverseTileAtPos(TiledCoordinateFromLocation(pos)));
  return pos;
}

bool CityController::hasBeenCreatedYet(const std::string& playerId)
{
  std::list<SimpleMoveObject*>::iterator it = move_objects_.begin();
  for ( ; it != move_objects_.end(); ++it)
  {
    PlayerMoveObject* player = dynamic_cast<PlayerMoveObject*>(*it);
    if (player && player->basic_data()->player_id().compare(playerId) == 0)
    {
      return true;
    }
  }
  std::map<PlayerBasicData*, PetBasicData*>::iterator uIt = uncreated_list_.begin();
  for ( ; uIt != uncreated_list_.end(); ++uIt)
  {
    if (uIt->first->player_id().compare(playerId) == 0)
    {
      return true;
    }
  }
  return false;
}

cocos2d::CCPoint CityController::getCurrentPosByPlayerId(const std::string& playerId)
{
  std::list<SimpleMoveObject*>::iterator it = move_objects_.begin();
  for ( ; it != move_objects_.end(); ++it)
  {
    if ((*it)->move_object_id()%kRolePetIdForLocalPlayer &&
      (dynamic_cast<PlayerMoveObject*>(*it))->basic_data()->player_id()==playerId)
    {
      return (*it)->move_data()->current_pos();
    }
  }
  return cocos2d::CCPointZero;
}

void CityController::AddNpc( uint_32 npc_id, uint_32 char_id, uint_32 func_id, const std::string& func_res_name,
  int tag, ePlayerAnimationDirection direction, float scale/*default = 1.0f*/)
{
  NpcObject* newNpc = new NpcObject();
  newNpc->Init(npc_id, char_id, func_id, func_res_name);
  newNpc->animation()->setPosition(GetCityView()->GetCityLayer()->GetNPCPosByTag(tag));
  newNpc->animation()->setZOrder(GetZorderByPosition(newNpc->animation()->getPosition()));
  newNpc->animation()->ChangeDirection(direction);
  newNpc->animation()->setScale(scale);
  npc_objects_.push_back(newNpc);
  city_view_->AddNpcObjectToView(newNpc);
  
  std::map<uint_32, NpcObject*>::iterator itr = npc_objects_map_.find(npc_id);
  assert(itr == npc_objects_map_.end());
  npc_objects_map_.insert(make_pair(npc_id, newNpc));
}

NpcObject* CityController::GetNPCById(uint_32 npc_id)
{
  std::map<uint_32, NpcObject*>::iterator itr = npc_objects_map_.find(npc_id);
  
  assert(itr != npc_objects_map_.end());
  return itr->second;
}

void CityController::UpdateNpcHeadIcon()
{
  std::list<NpcObject*>::iterator it = npc_objects_.begin();
  for ( ; it != npc_objects_.end(); ++it)
  {
    (*it)->set_head_icon();
  }
}

void CityController::PlayRankUpAnmi()
{
  assert(role_move_object_);
  role_move_object_->onRankUp();
}
/**************************Net Message****************************/

// void CityController::SendGetChallengeList()
// {
//   if (pvp_connection_)
//   {
//     pvp_connection_->GetChallengersList();
//   }  
// }
// 
// void CityController::SendChallengeRemotePlayerWithId(uint_32 user_id)
// {
//   if (pvp_connection_)
//   {
//     pvp_connection_->ChallengeRemotePlayerWithId(user_id);
//   }  
// }
// 
// void CityController::SendResponseRemotePlayerChallengeWithAcceptFlag(bool acceptOrNot)
// {
//   if (pvp_connection_)
//   {
//     pvp_connection_->ResponseRemotePlayerChallengeWithAcceptFlag(acceptOrNot);
//   }  
// }
// 
// ChallengeEnemyObject* CityController::GetChallangeEnemyInfo( uint_8 index )
// {
//   if (pvp_connection_)
//   {
//     return pvp_connection_->challenge_enemy_info(index);
//   }  
//   return NULL;
// }
// 
// ChallengeEnemyObject* CityController::GetChallangeRequestInfo()
// {
//   if (pvp_connection_)
//   {
//     return pvp_connection_->challenge_request_info();
//   }  
//   return NULL;
// }

void CityController::SendSwithCityMapRequest(uint_32 city_id)
{
  if(city_id != DataManager::GetInstance().user_info()->get_current_city_map_id())
  {
    CCLog("SendSwithCityMapRequest: %d", city_id);
    DataManager::GetInstance().user_info()->set_current_city_map_id(city_id);
    GameManager::GetInstance().OnSwitchCityMap();
    is_switch_city_ = true;
  }
}

void CityController::OnSwithCityMapRequestResponsed()
{
  //GameManager::GetInstance().OnSwitchCityMap();
  is_waitting_switch_scene_response_ = false;
  CCLog("OnSwithCityMapRequestResponsed: %d", DataManager::GetInstance().user_info()->get_current_city_map_id());
}

void CityController::SendChatMessage(uint_32 nChannel, std::string content )
{
  if ( chat_reporter_ )
  {
    chat_reporter_->postNewTalkMessage(nChannel,content);
  }
}

chatRecord* CityController::GetChatRecordByIndex(uint_32 nChannel,uint_32 nIndex)
{
  if ( chat_reporter_ )
  {
    return chat_reporter_->getChatRecordsByIndex(nChannel,nIndex);
  }
  return NULL;
}

uint_32 CityController::GetChatRecordsCount(uint_32 nChannel)
{
  if ( chat_reporter_ )
  {
    return chat_reporter_->getChatRecordsCount(nChannel);
  }
  return 0;
}

void CityController::UpdateChatLastThreeContent()
{
  if ( chat_reporter_ )
  {
    uint_32 count = chat_reporter_->getChatRecordsCount(kChannelAll);

    if (count == 0)
      return;

    std::vector<chatRecord*> three_content;

    for (int i = 1; i < 4; ++i)
    {
      chatRecord* pTemp = chat_reporter_->getChatRecordsByIndex(kChannelAll,count-i);
      if(pTemp==NULL)
        break;
      //char buf[255] = {0};
      //sprintf(buf, "[%d]%s:%s" , pTemp->nChannel,pTemp->nickName.c_str(),pTemp->content.c_str());

      three_content.push_back(pTemp);

    }

    for (int i = 0; i < three_content.size(); ++i)
    {
      chatRecord* pTemp = three_content[three_content.size()-i-1];
      LuaTinkerManager::GetInstance()\
        .CallLuaFunc<int>("script/ui/ui_main_menu.lua", "AddChatRecord", pTemp->nChannel,pTemp->nickName.c_str(),pTemp->content.c_str());
    }

  }
}

void CityController::OnSwitchSceneCompleted(int error_code,net::NetSessionTcp* session )
{
  if ( error_code != 0 )
  {
    CCLog("OnSwithCityMapRequestResponsedError:%d",error_code);
  }
  OnSwithCityMapRequestResponsed();
  mEventListener->registerEventListener();
}

/**************************Pos Sync Manage****************************/

void CityController::OnNotificationRemotePlayerMove(boost::shared_ptr<XPacket> pack)
{
  //assert(is_pos_sync_active_);
  if(is_waitting_switch_scene_response_)
    return;

  ACC::notify_scene_info_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  //  for position update
  int_32 pointCnt = message.infos_size();
  for (int_32 i = 0; i<pointCnt; ++i)
  {
    if (/*message.infos(i).has_nick()*/false==this->hasBeenCreatedYet(message.infos(i).uid()))
    {
      PlayerBasicData playerData;
      PetBasicData petData;
      playerData.set_player_id(message.infos(i).uid());
      playerData.set_nick_name(message.infos(i).nick());
      //playerData.set_vip_level(message.infos(i).)
      CCPoint tile_pos = TiledCoordinateFromLocation(ccp(message.infos(i).x(), message.infos(i).y()));
      if(IsTileCoordinateInRange(tile_pos) && tiled_map_->CanUnitTraverseTileAtPos(tile_pos))
      {
        playerData.set_init_position(ccp(message.infos(i).x(), message.infos(i).y()));
      }
      else
      {
        playerData.set_init_position(GetRandomBornPos());
      }
      playerData.set_rank(message.infos(i).lv());
      playerData.set_role_id(message.infos(i).role_id());
      playerData.set_up_star(message.infos(i).rarity_step());
      CCLog("Player Login player_id: %s, role_id: %u, is_set_role_id: %u, nick_name: %s, level: %d", 
        playerData.player_id().c_str(), playerData.role_id(), message.infos(i).has_role_id(), message.infos(i).nick().c_str(),message.infos(i).lv());
      if(playerData.role_id() == 0)
      {
        CCLog("ERROR ROLE ID IS 0!!!!!! playerId: %s", playerData.player_id().c_str());
        LoggerManager::msCityPos->info("ERROR ROLE ID IS 0!!!!!! playerId: %s", playerData.player_id().c_str());
        for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
            itr != move_objects_.end(); ++itr)
        {
          PlayerMoveObject *object = dynamic_cast<PlayerMoveObject*>((*itr));
          if(object)
          {
            CCLog("PlayerId: %s", object->basic_data()->player_id().c_str());
            char data[200];
            sprintf(data, "PlayerId: %s", object->basic_data()->player_id().c_str());
          }
        }
        assert(false);
      }
      
	  LoggerManager::msCityPos->info( "Player Login player_id: %s, role_id: %u, is_set_role_id: %u", 
		  playerData.player_id().c_str(), playerData.role_id(), message.infos(i).has_role_id());
      this->notificationRemotePlayerLoginCity(&playerData, &petData);
    }
    else
    {
      cocos2d::CCPoint targetPos = this->getCurrentPosByPlayerId(message.infos(i).uid());
      if (message.infos(i).has_x())
      {
        targetPos.x = message.infos(i).x();
      }
      if (message.infos(i).has_y())
      {
        targetPos.y = message.infos(i).y();
      }
      if (message.infos(i).has_lv())
      {
        this->notificationRemotePlayerLevelChange(message.infos(i).uid(), message.infos(i).lv());
      }
      if (message.infos(i).has_rarity_step())
      {
        this->notificationRemotePlayerUpStarChange(message.infos(i).uid(), message.infos(i).rarity_step());
      }
      

      CCLog("Player move player_id: %s, x: %u, y: %u", message.infos(i).uid().c_str(),
        message.infos(i).x(), message.infos(i).y());
      LoggerManager::msCityPos->info( "Player move player_id: %s, x: %u, y: %u",message.infos(i).uid().c_str(), message.infos(i).x(), message.infos(i).y());
      CCPoint tile_pos = TiledCoordinateFromLocation(targetPos);

      if(IsTileCoordinateInRange(tile_pos) && tiled_map_->CanUnitTraverseTileAtPos(tile_pos))
      {
        this->notificationRemotePlayerMove(message.infos(i).uid(), targetPos);
      }   
    }
  }
  // for logout
  pointCnt = message.exiters_size();
  for (int_32 i = 0; i<pointCnt; ++i)
  {
    CCLog("Player Logout: %s", message.exiters(i).c_str());
    LoggerManager::msCityPos->info("Player Logout: %s", message.exiters(i).c_str());

    this->notificationRemotePlayerLogout(message.exiters(i));
  }
}
  
void CityController::
  OnNotificationRemotePlayerMoveAfterCitySceneRemoved(boost::shared_ptr<XPacket> pack)
{
  if(is_waitting_switch_scene_response_)
    return;

  ACC::notify_scene_info_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  //  for position update
  int_32 pointCnt = message.infos_size();
  for (int_32 i = 0; i<pointCnt; ++i)
  {
    // new remote palyer's login
    if (false==this->hasBeenCreatedYet(message.infos(i).uid()))
    {
      cocos2d::CCPoint pos = ccp(message.infos(i).x(), message.infos(i).y());
      //CCPoint tile_pos = TiledCoordinateFromLocation(pos);
      //if(IsTileCoordinateInRange(tile_pos) && tiled_map_->CanUnitTraverseTileAtPos(tile_pos))
      //{

      //}
      //else
      //{
      //  pos = GetRandomBornPos();
      //}
      PlayerBasicData playerData;
      PetBasicData petData;
      playerData.set_player_id(message.infos(i).uid());
      playerData.set_nick_name(message.infos(i).nick());
      playerData.set_init_position(pos);
      playerData.set_rank(message.infos(i).lv());
      playerData.set_role_id(message.infos(i).role_id());
      playerData.set_up_star(message.infos(i).rarity_step());
      CCLog("Player Login player_id: %s, role_id: %u, is_set_role_id: %u, nick_name: %s, level: %d", 
      playerData.player_id().c_str(), playerData.role_id(), message.infos(i).has_role_id(),message.infos(i).nick().c_str(),message.infos(i).lv());
	    LoggerManager::msCityPos->info( "Player Login player_id: %s, role_id: %u, is_set_role_id: %u", 
		  playerData.player_id().c_str(), playerData.role_id(), message.infos(i).has_role_id());
      if(playerData.role_id() == 0)
      {
        CCLog("ERROR ROLE ID IS 0!!!!!! playerId: %s", playerData.player_id().c_str());
        LoggerManager::msCityPos->info("ERROR ROLE ID IS 0!!!!!! playerId: %s", playerData.player_id().c_str());

        for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
          itr != move_objects_.end(); ++itr)
        {
          PlayerMoveObject *object = dynamic_cast<PlayerMoveObject*>((*itr));
          if(object)
          {
            CCLog("PlayerId: %s", object->basic_data()->player_id().c_str());
            char data[200];
            sprintf(data, "PlayerId: %s", object->basic_data()->player_id().c_str());
          }
        }
        assert(false);
      }
      this->notificationRemotePlayerLoginCity(&playerData, &petData);
    }
    // fresh position only
    else
    {
      /**
      cocos2d::CCPoint targetPos = cocos2d::CCPointZero;
      for ( std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
           it != uncreated_list_.end(); ++it)
      {
        if (it->first->player_id() == message.infos(i).uid())
        {
          targetPos = it->first->init_position();
          break;
        }
      }
      if (message.infos(i).has_x())
      {
        targetPos.x = message.infos(i).x();
      }
      if (message.infos(i).has_y())
      {
        targetPos.y = message.infos(i).y();
      }

      CCLog("Player move player_id: %s, x: %u, y: %u", message.infos(i).uid().c_str(),
        message.infos(i).x(), message.infos(i).y());
      LoggerManager::msCityPos->info("Player move player_id: %s, x: %u, y: %u",message.infos(i).uid().c_str(), message.infos(i).x(), message.infos(i).y());

      CCPoint tile_pos = TiledCoordinateFromLocation(targetPos);
      if(IsTileCoordinateInRange(tile_pos) && tiled_map_->CanUnitTraverseTileAtPos(tile_pos))
      {
        this->notificationRemotePlayerMove(message.infos(i).uid(), targetPos);
      }
      **/
    }
  }
  // for logout
  pointCnt = message.exiters_size();
  for (int_32 i = 0; i<pointCnt; ++i)
  {
    CCLog("Player Logout: %s", message.exiters(i).c_str());
    LoggerManager::msCityPos->info( "Player Logout: %s", message.exiters(i).c_str());

    this->notificationRemotePlayerLogoutNotInCity(message.exiters(i));
  }
}

void CityController::OnNotificationSceneChat(boost::shared_ptr<XPacket> pack)
{
  ACC::notify_scene_chat_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  for (int i = 0; i < message.infos_size(); ++i)
  {
    CCLog("UserID: %s %s is talking, channel: 1, content: %s.",message.infos(i).uid().c_str(),message.infos(i).nick().c_str(),message.infos(i).content().c_str());
    std::list<SimpleMoveObject*>::iterator sIt = move_objects_.begin();
    for ( ; sIt != move_objects_.end(); ++sIt)
    {
      // pet index
      if (0==((*sIt)->move_object_id()%kRolePetIdForLocalPlayer))
      {
        assert(dynamic_cast<PetMoveObject*>(*sIt));
        continue;
      }
      // role index
      PlayerMoveObject* role = (dynamic_cast<PlayerMoveObject*>(*sIt));
      assert(role);
      if (role && role->basic_data()->player_id()==message.infos(i).uid())
      {
        role->showTalkBubble(message.infos(i).content().c_str());
        break;
      }
    }

    if(NULL != chat_reporter_)
    {
      AddAndShowChatRecord(1,message.infos(i).nick(),message.infos(i).content());
    }
  }
}

void CityController::OnNotificationWorldChat(boost::shared_ptr<XPacket> pack)
{
  ACC::notify_world_chat_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  for (int i = 0; i < message.infos_size(); ++i)
  {
    CCLog("UserID: %s %s is talking, channel: 2, content: %s.",message.infos(i).uid().c_str(),message.infos(i).nick().c_str(),message.infos(i).content().c_str());
    std::list<SimpleMoveObject*>::iterator sIt = move_objects_.begin();
    for ( ; sIt != move_objects_.end(); ++sIt)
    {
      // pet index
      if (0==((*sIt)->move_object_id()%kRolePetIdForLocalPlayer))
      {
        assert(dynamic_cast<PetMoveObject*>(*sIt));
        continue;
      }
      // role index
      PlayerMoveObject* role = (dynamic_cast<PlayerMoveObject*>(*sIt));
      assert(role);
      if (role && role->basic_data()->player_id()==message.infos(i).uid())
      {
        role->showTalkBubble(message.infos(i).content().c_str());
        break;
      }
    }

    if(NULL != chat_reporter_)
    {
      AddAndShowChatRecord(2,message.infos(i).nick(),message.infos(i).content());
    }
  }
}

// login & login out
void CityController::notificationRemotePlayerLoginCity(const PlayerBasicData* player,
                                                       const PetBasicData* pet)
{
  assert(player && pet);
  //CCLog("Player Login player_id: %s, role_id: %ld", player->player_id().c_str(), player->role_id());
  PlayerBasicData* playerInst = new PlayerBasicData(player);
  PetBasicData*    petInst    = new PetBasicData(pet);
  uncreated_list_.insert(std::pair<PlayerBasicData*, PetBasicData*>(playerInst, petInst));
}

void CityController::notificationRemotePlayerLogout(const std::string& playerId)
{
  CCLog("Player Logout: %s", playerId.c_str());
  LoggerManager::msCityPos->info("Player Logout: %s", playerId.c_str());
  // find firstly in uncreated map list
  std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
  for ( ; it != uncreated_list_.end(); ++it)
  {
    if (it->first->player_id() == playerId)
    {
      delete it->first;
      delete it->second;
      uncreated_list_.erase(it);
      CCLog("Erase player: %s", playerId.c_str());
      LoggerManager::msCityPos->info("Erase player: %s", playerId.c_str());
      return;
    }
  }
  // then in created list
  std::list<SimpleMoveObject*>::iterator sIt = move_objects_.begin();
  for ( ; sIt != move_objects_.end(); ++sIt)
  {
    // pet index
    if (0==((*sIt)->move_object_id()%kRolePetIdForLocalPlayer))
    {
      assert(dynamic_cast<PetMoveObject*>(*sIt));
      continue;
    }
    // role index
    PlayerMoveObject* role = (dynamic_cast<PlayerMoveObject*>(*sIt));
    assert(role);
    if (role && role->basic_data()->player_id()==playerId)
    {
      // dettach role animation
      city_view_->RemoveMoveOjbectFromView(*sIt);
      // release role object memory
      delete (*sIt);
      // earse role object from objects list
      sIt = move_objects_.erase(sIt);
      assert(sIt != move_objects_.end());
      // dettach pet animation
      city_view_->RemoveMoveOjbectFromView(*sIt);
      // release pet object memory
      delete (*sIt);
      // earse pet object from objects list
      sIt = move_objects_.erase(sIt);

      CCLog("Erase player: %s", playerId.c_str());
      LoggerManager::msCityPos->info("Erase player: %s", playerId.c_str());
      return;
    }
  }
  // unexist player id
}

void CityController::notificationRemotePlayerLogoutNotInCity(const std::string& playerId)
{
  for (std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
    it != uncreated_list_.end(); ++it)
  {
    if (it->first->player_id() == playerId)
    {
      delete it->first;
      delete it->second;
      uncreated_list_.erase(it);
      break;
    }
  }
}

void CityController::notificationRemotePlayerUpStarChange(const std::string& playerId, int new_level)
{
  CCLog("Player %s Up Star: %d", playerId.c_str(), new_level);
  std::list<SimpleMoveObject*>::iterator sIt = move_objects_.begin();
  for ( ; sIt != move_objects_.end(); ++sIt)
  {
    // pet index
    if (0==((*sIt)->move_object_id()%kRolePetIdForLocalPlayer))
    {
      assert(dynamic_cast<PetMoveObject*>(*sIt));
      continue;
    }
    // role index
    PlayerMoveObject* role = (dynamic_cast<PlayerMoveObject*>(*sIt));
    assert(role);
    if (role && role->basic_data()->player_id()==playerId)
    {
      // send pathfinding request
      role->basic_data()->set_up_star(new_level);
      role->onRankUp();
      break;
    }
  }
}

void CityController::notificationRemotePlayerLevelChange(const std::string& playerId, int new_level)
{
  CCLog("Player %s level up : %d", playerId.c_str(), new_level);
  std::list<SimpleMoveObject*>::iterator sIt = move_objects_.begin();
  for ( ; sIt != move_objects_.end(); ++sIt)
  {
    // pet index
    if (0==((*sIt)->move_object_id()%kRolePetIdForLocalPlayer))
    {
      assert(dynamic_cast<PetMoveObject*>(*sIt));
      continue;
    }
    // role index
    PlayerMoveObject* role = (dynamic_cast<PlayerMoveObject*>(*sIt));
    assert(role);
    if (role && role->basic_data()->player_id()==playerId)
    {
      // send pathfinding request
      role->basic_data()->set_rank(new_level);
      role->onRankUp();
      break;
    }
  }
}
// move notification from server
void CityController::notificationRemotePlayerMove(const std::string& playerId,
                                                  const cocos2d::CCPoint& nextDest)
{
  if (false == IsPointPositionInRange(nextDest) ||
      false == tiled_map_->CanUnitTraverseTileAtPos(TiledCoordinateFromLocation(nextDest)))
  {
    return;
  }

  CCLog("Player %s moved, new pos x: %f, y: %f", playerId.c_str(), nextDest.x, nextDest.y);
  std::list<SimpleMoveObject*>::iterator sIt = move_objects_.begin();
  for ( ; sIt != move_objects_.end(); ++sIt)
  {
    // pet index
    if (0==((*sIt)->move_object_id()%kRolePetIdForLocalPlayer))
    {
      assert(dynamic_cast<PetMoveObject*>(*sIt));
      continue;
    }
    // role index
    PlayerMoveObject* role = (dynamic_cast<PlayerMoveObject*>(*sIt));
    assert(role);
    if (role && role->basic_data()->player_id()==playerId)
    {
      // send pathfinding request
      this->SendMoveObjectPathFindRequest((*sIt), nextDest);
      break;
    }
  }
}
  
void CityController::notificationRemotePlayerMoveNotInCity(const std::string& playerId,
                                                           const cocos2d::CCPoint& nextDest)
{
  for (std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
       it != uncreated_list_.end(); ++it)
  {
    if (it->first->player_id() == playerId)
    {
      it->first->set_init_position(nextDest);
      break;
    }
  }
}
  
/**************************Player Data Manage****************************/

void CityController::createPlayerAndPetForLocalUser(bool is_need_restore_pos)
{
  resetMoveObjectId();

  data::UserInfo* user_info = DataManager::GetInstance().user_info();
  //account::AccountManager::GetInstance().user_id_str();
  //char pId[32] = {0};
  //sprintf(pId, "%ld", user_info->user_id());
  // default first born position
  cocos2d::CCPoint initPos = GetRandomBornPos();
  // get last leave position if exist, do note execute if switch city
  if(is_need_restore_pos)
  {
    for (std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
      it != uncreated_list_.end(); ++it)
    {
      if (it->first->player_id().compare(account::AccountManager::GetInstance().user_id_str()) == 0)
      {
        initPos = it->first->init_position();
        uncreated_list_.erase(it);
        break;
      }
    }
  }
  
  // create player object
  assert(!role_move_object_);
  role_move_object_ = new PlayerMoveObject();
  role_move_object_->basic_data()->set_role_id(user_info->role_id());
  //role_move_object_->basic_data()->set_up_star(user_info->up_star());
  role_move_object_->basic_data()->set_player_id(account::AccountManager::GetInstance().user_id_str());
  role_move_object_->basic_data()->set_nick_name(user_info->nick_name());
  role_move_object_->basic_data()->set_rank(user_info->rank());  
  role_move_object_->basic_data()->set_vip_level(user_info->vip());
  role_move_object_->Init(kRoleObjectIdForLocalPlayer);
  role_move_object_->move_data()->set_current_pos(initPos);
  role_move_object_->move_data()->set_last_pos(ccp(0.5f*tiled_map_->MapWidth(),
                                                   0.5f*tiled_map_->MapHeight()));
  role_move_object_->animation()->setPosition(initPos);
  role_move_object_->move_data()->target_selection()->set_target_pos(initPos);
  city_view_->AddMoveObjectToView(role_move_object_);
  role_move_object_->move_data()->set_ai_state(player_ai::kPlayerAIStateCommon);
  move_objects_.push_back(role_move_object_);

  // create pet object
  assert(!role_pet_);
  role_pet_ = new PetMoveObject(role_move_object_);
  role_pet_->Init(kRolePetIdForLocalPlayer);
  //role_pet_->animation()->setScale(0.5f);
  role_pet_->move_data()->set_current_pos(initPos);
  role_pet_->move_data()->target_selection()->set_target_pos(initPos);
  city_view_->AddMoveObjectToView(role_pet_);
  role_pet_->move_data()->set_ai_state(player_ai::kPetAIStateCommon);
  move_objects_.push_back(role_pet_);
  
  // init position-reporter & pos
  pos_reporter_->set_new_pos(role_move_object_->move_data()->current_pos());
  
  city_view_->GetCityLayer()->ResetLayerPos();
  this->updateCityLayer();
}

void CityController::createRemotePlayerAndPetByTimeInterval(float delta)
{
  assert(global_object_index_ >= 3);

  // no new data exist, do nothing here
  if (0==uncreated_list_.size())
  {
    return;
  }
  // time interval is not enough, increasing time delta only here
  create_interval_ += delta;
  if (create_interval_<0.1f)
  {
    return;
  }
  // reset time interval
  create_interval_ = 0.0f;
  // create new pair -- first data from uncreated_list_ map
  std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();

  if(!IsTileCoordinateInRange(TiledCoordinateFromLocation(it->first->init_position())))
  {
    it->first->set_init_position(GetRandomBornPos());
    //TODO peteryu, remove in release version
    assert(false);
  }
  
  // first for role
  PlayerMoveObject* role_obj = new PlayerMoveObject();
  role_obj->basic_data()->InitWithData(it->first);
  role_obj->Init(getMoveObjectId());
  role_obj->move_data()->set_current_pos(it->first->init_position());
  role_obj->move_data()->target_selection()->set_target_pos(it->first->init_position());
  city_view_->AddMoveObjectToView(role_obj);
  role_obj->move_data()->set_ai_state(player_ai::kPlayerAIStateCommon);
  move_objects_.push_back(role_obj);

  //get random direction
  float random_val = random_0_1();
  if(random_val < 0.33)
    role_obj->animation()->ChangeDirection(kPlayerAnimationDirectionLeft);
  else if(random_val < 0.66)
    role_obj->animation()->ChangeDirection(kPlayerAnimationDirectionRight);
  else
    role_obj->animation()->ChangeDirection(kPlayerAnimationDirectionFront);

  // then for pet
  PetMoveObject* pet_obj = new PetMoveObject(role_obj);
  pet_obj->pet_data()->InitWithData(it->second);
  pet_obj->Init(getMoveObjectId());
  cocos2d::CCPoint petPos = ccpAdd(it->first->init_position(),
    player_ai::kPetDistanceOffsetToOwner);
  if (false==IsPointPositionInRange(petPos) ||
    false==tiled_map_->CanUnitTraverseTileAtPos(TiledCoordinateFromLocation(petPos)))
  {
    petPos = it->first->init_position();
  }
  pet_obj->move_data()->set_current_pos(petPos);
  pet_obj->move_data()->target_selection()->set_target_pos(petPos);
  city_view_->AddMoveObjectToView(pet_obj);
  pet_obj->move_data()->set_ai_state(player_ai::kPetAIStateCommon);
  move_objects_.push_back(pet_obj);
  // release data memory
  delete (it->first);
  delete (it->second);
  // erase map list
  uncreated_list_.erase(it);

  // control all object visible 
  role_obj->animation()->setVisible(is_other_object_visable_);
  pet_obj->animation()->setVisible(is_other_object_visable_);
}

void CityController::cleanUncreateList()
{
  for (std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
    it != uncreated_list_.end(); ++it)
  {
    delete it->first;
    delete it->second;
  }
  uncreated_list_.clear();
}

void CityController::createNPCData()
{
  string str_path = "script/city_map/city_map_" + Int2String(DataManager::GetInstance().user_info()->get_current_city_map_id()) + ".lua";
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/main.lua", "reload_file", str_path.c_str());
  LuaTinkerManager::GetInstance().CallLuaFunc<int>(str_path.c_str(), "City_Init");
}

void CityController::cleanPlayerAndNpcData()
{
  role_move_object_ = NULL; 
  role_pet_ = NULL;

  for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
    itr != move_objects_.end(); ++itr)
  {
    city_view_->RemoveMoveOjbectFromView(*itr);
    delete (*itr);
  }
  move_objects_.clear();

  for(std::list<NpcObject*>::iterator itr = npc_objects_.begin();
    itr != npc_objects_.end(); ++itr)
  {
    city_view_->RemoveNpcOjbectFromView(*itr);
    delete (*itr);
  }
  npc_objects_.clear();
  npc_objects_map_.clear();
}

void  CityController::SetPlayAndNpcVisible(bool is_visible)
{
	for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
		itr != move_objects_.end(); ++itr)
	{
			(*itr)->animation()->setVisible(is_visible);
	}

	for(std::list<NpcObject*>::iterator itr = npc_objects_.begin();
		itr != npc_objects_.end(); ++itr)
	{
		(*itr)->animation()->setVisible(is_visible);

	}
}
  
/**************************City Scene Data Manage****************************/

void CityController::createCityScene(bool is_create_tiledmap /*defaule = true*/)
{
  assert(root_scene_ == NULL);
  assert(city_view_ == NULL);

  root_scene_ = ui::TemplateScene::Create();
  root_scene_->retain();
  root_scene_->SwitchToThisScene();

  char* map_info_name = LuaTinkerManager::GetInstance()\
    .CallLuaFunc<char*>("script/city_map/city_map_contants.lua", "GetCityMapMapInfoNameById",
    DataManager::GetInstance().user_info()->get_current_city_map_id());
  uint_16 map_id = DataManager::GetInstance().user_info()->get_current_city_map_id();

  CityLayer *city_layer = CityLayerLoader::GetInstance().CreateCityLayer(map_info_name, is_create_tiledmap);
  city_view_ = new CityView(city_layer);
  city_touch_handler_ = new CityTouchHandler();
  city_layer->SetCityTouchHandler(city_touch_handler_);

  root_scene_->AddLayerOnSceneLayer(city_view_->GetCityLayer());
	//LuaTinkerManager::GetInstance()\
	//	.CallLuaFunc<int>("script/ui/ui_main_menu.lua", "OpenUIMainMenu");


  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "exitFightSceneNotifyHdr");
}

void CityController::cleanCityScene()
{
  //release city_layer on the same time
	//LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/ui_main_menu.lua", "CloseMainMenu");
  CC_SAFE_DELETE(city_view_);
  CC_SAFE_DELETE(city_touch_handler_);
  CC_SAFE_RELEASE_NULL(root_scene_);
}

void CityController::cleanTiledMap()
{
  CC_SAFE_DELETE(tiled_map_);
}

void CityController::createPathPlanerAndPosRepoter()
{
  assert(!path_manager_);
  path_manager_ = new PathManager<PathPlannerBase>(2000);
  assert(!pos_reporter_);
  pos_reporter_ = new PosReporter();
}

void CityController::cleanPathPlanerAndPosRepoter()
{
  CC_SAFE_DELETE(path_manager_);
  CC_SAFE_DELETE(pos_reporter_);
}

/**************************Connection Manage****************************/

// void CityController::createPvpTCPConnection()
// {
//   assert(!pvp_connection_);
//   pvp_connection_ = new PvpNetConnection();
// }

void CityController::createAnnouncementTCPConnection()
{
  assert(!announcement_connection_);
  announcement_connection_ = new AnnouncementNetConnection();
}

void CityController::createAllTCPConnection()
{
  // create net notification for pvp for new TCP connection
  // only do this after first login, 
//   assert(!pvp_connection_);
//   pvp_connection_ = new PvpNetConnection();
  assert(!chat_reporter_);
  chat_reporter_ = new ChatReporter();
  assert(!announcement_connection_);
  announcement_connection_ = new AnnouncementNetConnection();
}

// void CityController::cleanPvpTCPConnection()
// {
//   //net::SampleTcpClient::GetInstance().Close();
//   CC_SAFE_DELETE(pvp_connection_);
// }

void CityController::cleanAnnouncementTCPConnection()
{
  //net::SampleTcpClient::GetInstance().Close();
  CC_SAFE_DELETE(announcement_connection_);
}

void CityController::setNotifyAndChatConnectionToOnCityScene()
{
  //net::SampleTcpClient::GetInstance().StartConnect();
  if (net_notify_connection_.connected())
  {
    net_notify_connection_.disconnect();
  }

  net_notify_connection_ = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<CityController>(static_cast<int>(ACC::notify_scene_info_cmd),
                                                      &CityController::GetInstance(),
                                                      &CityController::OnNotificationRemotePlayerMove);

  if ( net_notify_connection_scnen_chat_.connected())
  {
    net_notify_connection_scnen_chat_.disconnect();
  }
  if (net_notify_connection_world_chat_.connected())
  {
    net_notify_connection_world_chat_.disconnect();
  }

  net_notify_connection_scnen_chat_ = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<CityController>(static_cast<int>(ACC::notify_scene_chat_cmd),
                                                      &CityController::GetInstance(),
                                                      &CityController::OnNotificationSceneChat);

  net_notify_connection_world_chat_ = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<CityController>(static_cast<int>(ACC::notify_world_chat_cmd),
    &CityController::GetInstance(),
    &CityController::OnNotificationWorldChat);
}

void CityController::setNotifyConnectionToRemovedCityScene()
{
  // reconnect notification response function 
  // assert(net_notify_connection_.connected());
  if (net_notify_connection_.connected())
  {
    net_notify_connection_.disconnect();
  }
  net_notify_connection_ = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<CityController>(static_cast<int>(ACC::notify_scene_info_cmd),
                                                      &CityController::GetInstance(),
                                                      &CityController::OnNotificationRemotePlayerMoveAfterCitySceneRemoved);
}

void CityController::cleanAllConnnection()
{
  if (net_notify_connection_.connected())
  {
    net_notify_connection_.disconnect();
  }
  if ( net_notify_connection_scnen_chat_.connected())
  {
    net_notify_connection_scnen_chat_.disconnect();
  }
  if (net_notify_connection_world_chat_.connected())
  {
    net_notify_connection_world_chat_.disconnect();
  }
}

void CityController::updateCityLayer()
{
  CCPoint offset = ccpSub(role_move_object_->move_data()->last_pos(),
                          role_move_object_->move_data()->current_pos());
  CCPoint new_pos = ccpAdd(offset, city_view_->GetCityLayer()->getPosition());
  CCPoint temp_pos = new_pos;
  CCSize city_layer_size = city_view_->GetCityLayer()->getContentSize();
  CCPoint role_pos = role_move_object_->move_data()->current_pos();
  CCPoint left_buttom(1136 - city_layer_size.width, 640 - city_layer_size.height);
  
  if(new_pos.x < left_buttom.x)
    new_pos.x = left_buttom.x;
  
  if(new_pos.y < left_buttom.y)
    new_pos.y = left_buttom.y;
  
  if(new_pos.x > 0.0)
    new_pos.x = 0.0;
  
  if(new_pos.y > 0.0)
    new_pos.y = 0.0;
  
  if(fabsf(role_pos.x) < 568)
  {
    new_pos.x = 0;
  }
  else if(fabsf(city_layer_size.width - role_pos.x) <= 568)
  {
    new_pos.x = left_buttom.x;
  }
  
  if(fabsf(role_pos.y) < 320)
  {
    new_pos.y = 0;
  }
  else if(fabsf(city_layer_size.height - role_pos.y) <= 320)
  {
    new_pos.y = left_buttom.y;
  }

  city_view_->GetCityLayer()->setPosition(new_pos);
}
  
void CityController::clearAllBeforeCityInstancePurge()
{
  for (std::map<PlayerBasicData*, PetBasicData*>::iterator it = uncreated_list_.begin();
       it != uncreated_list_.end(); ++it)
  {
    delete it->first;
    delete it->second;
  }
  uncreated_list_.clear();
  if (net_notify_connection_.connected())
  {
    net_notify_connection_.disconnect();
  }
  if (net_notify_connection_scnen_chat_.connected())
  {
    net_notify_connection_scnen_chat_.disconnect();
  }
  if (net_notify_connection_world_chat_.connected())
  {
    net_notify_connection_world_chat_.disconnect();
  }
  CC_SAFE_DELETE(tiled_map_);
//  CC_SAFE_DELETE(pvp_connection_);
  CC_SAFE_DELETE(announcement_connection_);
  CC_SAFE_DELETE(chat_reporter_);
}

void CityController::saveAllMoveObjectsBasicInfo()
{
  for(std::list<SimpleMoveObject*>::iterator itr = move_objects_.begin();
    itr != move_objects_.end(); ++itr)
  {
    PlayerMoveObject* player = dynamic_cast<PlayerMoveObject*>(*itr);
    if (NULL==player)
    {
      continue;
    }
    PlayerBasicData* playerData = new PlayerBasicData;
    PetBasicData* petData = new PetBasicData;
    // init player info 
    playerData->set_player_id(player->basic_data()->player_id());
    playerData->set_nick_name(player->basic_data()->nick_name());
    playerData->set_init_position(player->move_data()->current_pos());
    playerData->set_rank(player->basic_data()->rank());
    playerData->set_role_id(player->basic_data()->role_id());
    playerData->set_up_star(player->basic_data()->up_star());
    // then pet info

    uncreated_list_.insert(std::pair<PlayerBasicData*, PetBasicData*>(playerData, petData));
  }
}

void CityController::AddAndShowChatRecord( uint_32 channel ,const std::string nick_name, const std::string content)
{
  //chat_reporter_->addChatRecord(channel,nick_name,content);
  //LuaTinkerManager::GetInstance()\
  //  .CallLuaFunc<int>("script/ui/ui_chat.lua", "AddRecordByIndex", channel,chat_reporter_->getChatRecordsCount(channel)-1);

  //LuaTinkerManager::GetInstance()\
  //  .CallLuaFunc<int>("script/ui/ui_main_menu.lua", "AddChatRecord",channel,nick_name.c_str(),content.c_str());
}


}
} // namespace taomee