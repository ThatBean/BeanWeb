//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_map_constants.h
//        Author: peteryu
//          Date: 2014/2/21 14:36
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/21      add
//////////////////////////////////////////////////////////////

#ifndef CITY_MAP_CONSTANTS_H
#define CITY_MAP_CONSTANTS_H

#include <string>

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

using namespace std;
using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {
namespace city {
 
  enum kSceneNodeTag
  {
    kSceneNodeTagTiledMap   = 11000,
    kSceneNodeTagBackground = 12000,
    kSceneNodeTagCity       = 13000,
    kSceneNodeTagCityNPCStart = 14000,
    kSceneNodeTagCityNPCEnd   = 14999,
    kSceneNodeTagCityBornPosStart = 15000,
    kSceneNodeTagCityBornPosEnd   = 15999
  };

  const string kTiledMapComponentName     = "CCTMXTiledMap";
  const string kCCSpriteComponentName     = "CCSprite";
  const string kPathLayerNameInTiledMap   = "path_layer";
  const string kMapLayerNameInTiledMap    = "map_layer";

  const string kMapDirectory          = "map/";
  const string kMapResDirectory       = "res/";
  const string kMapResPListName       = "res.plist";
  const string kMapResPNGName         = "res.png";

}
} // namespace taomee

#endif
