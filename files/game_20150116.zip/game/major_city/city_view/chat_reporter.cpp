﻿#include "game/major_city/city_view/chat_reporter.h"

#include "network/net_client_tcp/sample_tcp_client.h"
#include "network/net_client_tcp/net_session_tcp.h"
#include "network/net_client_tcp/protocol/cpp/mcs.pb.h"
#include "network/net_constant.h"
#include "base/utils_string.h"
#include "game/account/account_manager.h"

using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {
namespace city {


ChatReporter::ChatReporter()
{
  list_chatRecordsAll.clear();
}

ChatReporter::~ChatReporter()
{
  std::list<chatRecord*>::iterator it = list_chatRecordsAll.begin();
  for ( ; it != list_chatRecordsAll.end(); ++it )
  {
      delete(*it);
  }
  list_chatRecordsAll.clear();
  it = list_charRecordCurrent.begin();
  for ( ; it != list_charRecordCurrent.end(); ++it )
  {
      delete(*it);
  }
  list_charRecordCurrent.clear();
  it = list_charRecordWorld.begin();
  for ( ; it != list_charRecordWorld.end(); ++it )
  {
      delete(*it);
  }
  list_charRecordWorld.clear();
}

void ChatReporter::postNewTalkMessage(uint_32 nChannel,std::string strContent)
{
    boost::shared_ptr<net::NetSessionTcp> post_pos_requset = boost::make_shared<net::NetSessionTcp>();
    post_pos_requset->set_request_ower(taomee::account::AccountManager::GetInstance().user_id_str().c_str());

    if ( nChannel == 1)
    {
      post_pos_requset->set_request_cmd(ACC::cli_scene_chat_cmd);
      ACC::cli_scene_chat_in message_in;
      message_in.set_content(strContent);
      post_pos_requset->set_message_in<ACC::cli_scene_chat_in>(message_in);
      net::SampleTcpClient::GetInstance().SendRequest(post_pos_requset);
    }
    else if ( nChannel == 2)
    {
      post_pos_requset->set_request_cmd(ACC::cli_world_chat_cmd);
      ACC::cli_world_chat_in message_in;
      message_in.set_content(strContent);
      post_pos_requset->set_message_in<ACC::cli_world_chat_in>(message_in);
      net::SampleTcpClient::GetInstance().SendRequest(post_pos_requset);
    }
    //std::string unicode_content = ConvertUft8ToUnicodeString(strContent);
    //strContent.append(strContent);
    //strContent.append(strContent);
    //strContent.append(strContent);
}

void ChatReporter::addChatRecord( uint_32 nChannel,std::string strNickName,std::string strContent )
{
    chatRecord* pRecord = new chatRecord;
    pRecord->nChannel = nChannel;
    pRecord->nickName = strNickName;
    pRecord->content = strContent;
    if(list_chatRecordsAll.size() == 50)
    {
        std::list<chatRecord*>::iterator it = list_chatRecordsAll.begin();
        delete(*it);
        list_chatRecordsAll.pop_front();
    }
    assert(list_chatRecordsAll.size() <= 50);
    list_chatRecordsAll.push_back(pRecord);

    if( nChannel == kChannelCurrent )
    {
        chatRecord* pRecordCurrent = new chatRecord;
        pRecordCurrent->nChannel = nChannel;
        pRecordCurrent->nickName = strNickName;
        pRecordCurrent->content = strContent;
        if(list_charRecordCurrent.size() == 50)
        {
            std::list<chatRecord*>::iterator it = list_charRecordCurrent.begin();
            delete(*it);
            list_charRecordCurrent.pop_front();
        }
        assert(list_charRecordCurrent.size() <= 50);
        list_charRecordCurrent.push_back(pRecordCurrent);
    }
    else if ( nChannel == kChannelWorld )
    {
        chatRecord* pRecordWorld = new chatRecord;
        pRecordWorld->nChannel = nChannel;
        pRecordWorld->nickName = strNickName;
        pRecordWorld->content = strContent;
        if(list_charRecordWorld.size() == 50)
        {
            std::list<chatRecord*>::iterator it = list_charRecordWorld.begin();
            delete(*it);
            list_charRecordWorld.pop_front();
        }
        assert(list_charRecordWorld.size() <= 50);
        list_charRecordWorld.push_back(pRecordWorld);
    }
}

uint_32 ChatReporter::getChatRecordsCount(uint_32 nChannel)
{
   switch(nChannel)
   {
   case kChannelAll:
        return list_chatRecordsAll.size();
       break;
   case kChannelCurrent:
        return list_charRecordCurrent.size();
       break;
   case kChannelWorld:
        return list_charRecordWorld.size();
       break;
   }
   return 0;
}

chatRecord* ChatReporter::getChatRecordsByIndex(uint_32 nChannel,uint_32 nIndex)
{
    uint_32 nIdx = 0;
    switch(nChannel)
    {
    case kChannelAll:
        {
            std::list<chatRecord*>::iterator it = list_chatRecordsAll.begin();
            for(;it != list_chatRecordsAll.end();++it)
            {
                if(nIdx==nIndex)
                    return *it;
                ++nIdx;
            }
        }
        break;
    case kChannelCurrent:
        {
            std::list<chatRecord*>::iterator it = list_charRecordCurrent.begin();
            for(;it != list_charRecordCurrent.end();++it)
            {
                if(nIdx==nIndex)
                    return *it;
                ++nIdx;
            }
        }
        break;
    case kChannelWorld:
        {
            std::list<chatRecord*>::iterator it = list_charRecordWorld.begin();
            for(;it != list_charRecordWorld.end();++it)
            {
                if(nIdx==nIndex)
                    return *it;
                ++nIdx;
            }
        }
        break;
    }

    return NULL;
}

char* ChatReporter::cutChatString( const char* content )
{
    int len = cc_utf8_strlen(content, -1);
    bool bCut = false;
    unsigned short* str_new = cc_utf8_to_utf16(content);
    for(int i = 0; i < len; ++i)
    {
        unsigned short temp = str_new[i];
        if(i >= 23)
        {
            bCut = true;
            str_new[i] = 0;
        }
    }
    if(bCut)
    {
        str_new[21] = '.';
        str_new[22] = '.';
        str_new[23] = '.';
        len = 24;
    }

    return cc_utf16_to_utf8(str_new,len,NULL,NULL);
}


} // namespace city
} // namespace taomee