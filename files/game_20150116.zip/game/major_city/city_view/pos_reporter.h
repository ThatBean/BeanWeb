//
//  pos_reporter.h
//  ChainChronicle
//
//  Created by gaven on 2/26/14.
//
//

#ifndef __ChainChronicle__pos_reporter__
#define __ChainChronicle__pos_reporter__

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace city {
  
class PosReporter
{
public:
  PosReporter();
  ~PosReporter() {}
  
public: // getter & setter
  bool              switch_flag() const { return switch_flag_; }
  void              set_switch_flag(bool flag)
  {
    switch_flag_ = flag;
  }
  
  float             time_interval() const { return time_interval_; }
  void              set_time_interval(float interval)
  {
    time_interval_ = interval;
  }
  
  const cocos2d::CCPoint& new_pos() const { return new_pos_; }
  void              set_new_pos(const cocos2d::CCPoint& pos)
  {
    new_pos_ = pos;
    switch_flag_ = true;
  }

  void              set_is_ignore_next_pos(bool flag)
  {
    is_ignore_next_pos_ = flag;
  }
  
public: // update
  void  UpdatePositionReporter(float delta);
  
private:
  void postNewPositionToServer(uint_32 xPos, uint_32 yPos);
  
private:
  bool              switch_flag_;
  float             time_interval_;
  cocos2d::CCPoint  new_pos_;
  bool              is_ignore_next_pos_;
};
  
} // namespace city
} // namespace taomee

#endif /* defined(__ChainChronicle__pos_reporter__) */
