//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_layer.h
//        Author: peteryu
//          Date: 2014/2/12 15:39
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef CITY_LAYER_H
#define CITY_LAYER_H

#include <string>
#include <map>

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

using namespace std;
using namespace cocos2d;

namespace taomee {
namespace city {

class CityLayerLoader;
class CityTouchHandler;

enum eCityLayerType
{
  kCityLayerTypeMap,
  KCityLayerTypePlayers
};
 
class CityLayer : public cocos2d::CCLayer
{
private:
  CityLayer();
public:
  ~CityLayer();
  
  CREATE_FUNC(CityLayer);
  virtual bool init();

  virtual void draw();
  virtual void onEnter();

  // add node on player layer
  void    AddMoveNode(CCNode* child);
  // add node on background layer
  void    AddBackNode(CCNode* child);
  // only used in initializing map
  void    AddSceneNode(CCNode* scene_node);
  void    AddTouchPointAnimation(CCNode* animation, CCPoint pos);
  void    AddNPCTagPos(int tag, CCPoint pos);
  void    AddBornPos(const CCPoint &pos);
  CCPoint GetNPCPosByTag(int tag);
  void    SetCityTouchHandler(CityTouchHandler* handler){city_touch_handler_ = handler;}
  void    ResetLayerPos();
  CCPoint GetRandomBornPos();

public:
  // touch
  virtual bool ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent);
  virtual void ccTouchMoved(CCTouch *pTouch, CCEvent *pEvent);
  virtual void ccTouchEnded(CCTouch *pTouch, CCEvent *pEvent);
  virtual void ccTouchCancelled(CCTouch *pTouch, CCEvent *pEvent);

public:
  friend class CityLayerLoader;

private:
  void drawCoordinate();

private:
  CityTouchHandler*   city_touch_handler_;
  CCNode*             root_scene_node_;
  map<int, CCPoint>   npc_tag_point_map_;
  bool                is_show_debug_tile_line_;
  vector<CCPoint>     born_pos_vec_;
};

}
} // namespace taomee

#endif
