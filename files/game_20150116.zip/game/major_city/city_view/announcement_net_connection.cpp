#include "game/major_city/city_view/announcement_net_connection.h"

#include "engine/base/cocos2d_wrapper.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/account/account_manager.h"
#include "game/game_manager/game_manager.h"
#include "network/net_client_tcp/net_session_tcp.h"
#include "network/net_client_tcp/protocol/cpp/switch.pb.h"
#include "network/net_constant.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/announcement_data_table.h"

namespace taomee {
namespace city {
AnnouncementNetConnection::AnnouncementNetConnection()
{
  assert(!nnc_announcement_fivestar_card.connected());
  nnc_announcement_fivestar_card = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<AnnouncementNetConnection>(
      static_cast<int>(ACC::notify_announce_rarity_5_get_cmd), this,
      &AnnouncementNetConnection::onNotificationAnnGetFiveStarCard);
  assert(!nnc_announcement_ranklv_up.connected());
  nnc_announcement_ranklv_up = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<AnnouncementNetConnection>(
    static_cast<int>(ACC::notify_announce_rarity_promote_cmd), this,
    &AnnouncementNetConnection::onNotificationAnnCharacterRankLvUp);
  assert(!nnc_announcement_break.connected());
  nnc_announcement_break = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<AnnouncementNetConnection>(
    static_cast<int>(ACC::notify_announce_rarity_5_break_cmd), this,
    &AnnouncementNetConnection::onNotificationAnnCharacterBreak);
  assert(!nnc_announcement_break_max.connected());
  nnc_announcement_break_max = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<AnnouncementNetConnection>(
    static_cast<int>(ACC::notify_announce_rarity_5_break_max_cmd), this,
    &AnnouncementNetConnection::onNotificationAnnCharacterBreakMax);

  nnc_announcement_gmtool = net::SampleTcpClient::GetInstance().
	  SubscribeNotifyMsgReciverComplete<AnnouncementNetConnection>(
	  static_cast<int>(ACC::notify_announce_gmtool_cmd), this,
	  &AnnouncementNetConnection::onNotificationAnnGMInfoFromServer);

  nnc_announcement_all_logout = net::SampleTcpClient::GetInstance().
    SubscribeNotifyMsgReciverComplete<AnnouncementNetConnection>(
    static_cast<int>(ACC::notify_announce_alluser_logout_cmd), this,
    &AnnouncementNetConnection::onNotificationAnnAllLogou);

}

AnnouncementNetConnection::~AnnouncementNetConnection()
{
  nnc_announcement_fivestar_card.disconnect();
  nnc_announcement_ranklv_up.disconnect();
  nnc_announcement_break.disconnect();
  nnc_announcement_break_max.disconnect();
}

void AnnouncementNetConnection::Test()
{
  //AnnouncementNetData annNetData;
  //annNetData.nEventID = 1;
  //int i = rand()%10;
  //if ( i %2 )
  //  annNetData.stringParam1 = "Hero";
  //else
  //  annNetData.stringParam1 = "Hero2";
  //annNetData.intParam1 = 11001;
  //showAnnMsg(annNetData);
}

void AnnouncementNetConnection::onNotificationAnnGetFiveStarCard(boost::shared_ptr<XPacket> pack)
{
  ACC::notify_announce_rarity_5_get_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  CCLog("AnnMsg Get FiveStarCard nickname: %s ,cardId: %d.",message.nickname().c_str(),message.cardid());
  AnnouncementData* pAnInfo = DataManager::GetInstance().GetAnnouncementDataTable()->GetAnnouncement(kAnnMsgType_Get_Five_Star_Card);
  CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(message.cardid());
  assert(pAnInfo && pCharInfo);
  if(pAnInfo == NULL || pCharInfo == NULL)
    return;
  AnnouncementNetData annNetData;
  annNetData.nEventID = pAnInfo->GetId();
  annNetData.stringParam1 = message.nickname();
  annNetData.intParam1 = message.cardid();
  showAnnMsg(annNetData);
}

void AnnouncementNetConnection::onNotificationAnnCharacterRankLvUp(boost::shared_ptr<XPacket> pack)
{
  ACC::notify_announce_rarity_promote_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  CCLog("AnnMsg Role Rank Lv Up nickname: %s ,roleId:%d,rarity: %d.",message.nickname().c_str(),message.role_id(),message.rarity());
  AnnouncementData* pAnInfo = DataManager::GetInstance().GetAnnouncementDataTable()->GetAnnouncement(kAnnMsgType_Char_Rank_Lv_Up);
  RoleData* pRoleInfo = DataManager::GetInstance().GetRoleDataTable()->GetRole(message.role_id());
  assert(pAnInfo && pRoleInfo);
  if(pAnInfo == NULL || pRoleInfo == NULL)
    return;
  AnnouncementNetData annNetData;
  annNetData.nEventID = pAnInfo->GetId();
  annNetData.stringParam1 = message.nickname();
  annNetData.intParam1 = pRoleInfo->GetCardID();
  annNetData.intParam2 = message.rarity();
  showAnnMsg(annNetData);
}

void AnnouncementNetConnection::onNotificationAnnCharacterBreak(boost::shared_ptr<XPacket> pack)
{
  ACC::notify_announce_rarity_5_break_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  CCLog("AnnMsg Character Break nickname: %s cardid: %d, max_lv: %d",message.nickname().c_str(),message.cardid(),message.max_lv());
  AnnouncementData* pAnInfo = DataManager::GetInstance().GetAnnouncementDataTable()->GetAnnouncement(kAnnMsgType_Char_Break);
  CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(message.cardid());
  assert(pAnInfo && pCharInfo);
  if(pAnInfo == NULL || pCharInfo == NULL)
    return;
  AnnouncementNetData annNetData;
  annNetData.nEventID = pAnInfo->GetId();
  annNetData.stringParam1 = message.nickname();
  annNetData.intParam1 = message.cardid();
  annNetData.intParam2 = message.max_lv();
  showAnnMsg(annNetData);
}

void AnnouncementNetConnection::onNotificationAnnCharacterBreakMax(boost::shared_ptr<XPacket> pack)
{
  ACC::notify_announce_rarity_5_break_max_out message;
  net::ConverXpactetToNotifyMessage(pack, message);
  CCLog("AnnMsg Character Break Max nickname: %s cardid: %d",message.nickname().c_str(),message.cardid());
  AnnouncementData* pAnInfo = DataManager::GetInstance().GetAnnouncementDataTable()->GetAnnouncement(kAnnMsgType_Char_Break_Max);
  CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(message.cardid());
  assert(pAnInfo && pCharInfo);
  if(pAnInfo == NULL || pCharInfo == NULL)
    return;
  AnnouncementNetData annNetData;
  annNetData.nEventID = pAnInfo->GetId();
  annNetData.stringParam1 = message.nickname();
  annNetData.intParam1 = message.cardid();
  showAnnMsg(annNetData);
}

void AnnouncementNetConnection::onNotificationAnnGMInfoFromServer(boost::shared_ptr<XPacket> pack)
{
 	ACC::php_announce_gmtool_msg message;
 	net::ConverXpactetToNotifyMessage(pack, message);
	CCLog("AnnMsg from server msg : %s ",message.notice().c_str());
	AnnouncementNetData annNetData;
	annNetData.stringParam1 = message.notice();
	annNetData.intParam1 = message.times();
	annNetData.intParam2 =(int)message.type();
 	showAnnMsgEx(annNetData);
}

void AnnouncementNetConnection::onNotificationAnnAllLogou(boost::shared_ptr<XPacket> pack)
{
  showAllLogOut();
}

void AnnouncementNetConnection::showAnnMsgEx(AnnouncementNetData annNetData)
{
	LuaTinkerManager::GetInstance()\
		.CallLuaFunc<int>("script/ui/ui_scroll_tips.lua", "AddMessageSystemTipsEx"
		, annNetData.stringParam1.c_str(),annNetData.intParam1);
}

void AnnouncementNetConnection::showAllLogOut()
{
  LuaTinkerManager::GetInstance()\
    .CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "ServerShutDownLogOut");
}

void AnnouncementNetConnection::showAnnMsg(AnnouncementNetData annNetData)
{
  AnnouncementData* pAnInfo = DataManager::GetInstance().GetAnnouncementDataTable()->GetAnnouncement(annNetData.nEventID);
  std::string content = "";
  std::string ui_main_menu_content = "";
  assert(pAnInfo);
  switch(pAnInfo->GetId())
  {
  case kAnnMsgType_Get_Five_Star_Card:
    {
      char buf[255] = {0};
      CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(annNetData.intParam1);
      sprintf(buf,GetLuaText("announcement_event_1"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str());
      content = buf;
      sprintf(buf,GetLuaText("ui_chat_announcement_event_1"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str());
      ui_main_menu_content = buf;
    }
    break;
  case kAnnMsgType_Char_Rank_Lv_Up:
    {
      char buf[255] = {0};
      CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(annNetData.intParam1);
      sprintf(buf,GetLuaText("announcement_event_2"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str(),annNetData.intParam2);
      content = buf;
      sprintf(buf,GetLuaText("ui_chat_announcement_event_2"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str(),annNetData.intParam2);
      ui_main_menu_content = buf;
    }
    break;
  case kAnnMsgType_Char_Break:
    {
      char buf[255] = {0};
      CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(annNetData.intParam1);
      sprintf(buf,GetLuaText("announcement_event_3"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str(),annNetData.intParam2/10);
      content = buf;
      sprintf(buf,GetLuaText("ui_chat_announcement_event_3"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str(),annNetData.intParam2/10);
      ui_main_menu_content = buf;
    }
    break;
  case kAnnMsgType_Char_Break_Max:
    {
      char buf[255] = {0};
      CharacterData* pCharInfo = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(annNetData.intParam1);
      sprintf(buf,GetLuaText("announcement_event_4"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str());
      content = buf;
      sprintf(buf,GetLuaText("ui_chat_announcement_event_4"),annNetData.stringParam1.c_str(),pCharInfo->GetDisplayName().c_str());
      ui_main_menu_content = buf;
    }
    break;
  default:
    CCLog("system message client don't know!!!!!!!!!!!!!!!!!!!!");
    break;
  }


  int showPlace = pAnInfo->GetShowplace();
  if ( showPlace == kAnnMsgShow_Screen_Mid 
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Top+1) 
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Chat+1)
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Top+kAnnMsgShow_Screen_Chat+1))
  {
    //if(GameManager::GetInstance().is_in_city_state() == true)
    //{
    //  LuaTinkerManager::GetInstance()\
    //    .CallLuaFunc<int>("script/ui/ui_message_system_tips.lua", "CreateMessageSystemTips"
    //    , annNetData.nEventID,content.c_str());
    //}
  }
  if ( showPlace == kAnnMsgShow_Screen_Top
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Top+1)
    || showPlace == (kAnnMsgShow_Screen_Top+kAnnMsgShow_Screen_Chat+1)
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Top+kAnnMsgShow_Screen_Chat+1))
  {
    if(GameManager::GetInstance().is_in_city_state() == true)	
    {
      LuaTinkerManager::GetInstance()\
        .CallLuaFunc<int>("script/ui/ui_scroll_tips.lua", "AddMessageSystemTips"
        , annNetData.nEventID,content.c_str());
    }
  }
  if ( showPlace == kAnnMsgShow_Screen_Chat
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Chat+1)
    || showPlace == (kAnnMsgShow_Screen_Top+kAnnMsgShow_Screen_Chat+1)
    || showPlace == (kAnnMsgShow_Screen_Mid+kAnnMsgShow_Screen_Top+kAnnMsgShow_Screen_Chat+1))
  {
    CityController::GetInstance().AddAndShowChatRecord(0,"",ui_main_menu_content);
  }
}


} // namespace city
} // namespace taomee