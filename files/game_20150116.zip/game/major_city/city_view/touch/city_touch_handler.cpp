//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_touch_handler.cpp
//        Author: peteryu
//          Date: 2014/2/14 15:09
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/14      add
//////////////////////////////////////////////////////////////
#include "game/major_city/city_view/touch/city_touch_handler.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/animation/skeleton_animation.h"
#include "game/major_city/players_data/player_move_object.h"
#include "game/major_city/players_data/npc_object.h"
#include "game/major_city/city_view/city_layer.h"
#include "game/major_city/city_view/city_view.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/pathfinding/city_tiled_map.h"
#include "game/major_city/city_view/touch/city_touch_point_animation.h"

using namespace cocos2d;

namespace taomee
{
namespace city
{

CityTouchHandler::CityTouchHandler()
{

}

CityTouchHandler::~CityTouchHandler()
{

}

bool CityTouchHandler::ccTouchBegan( CCTouch *pTouch, CCLayer* target_layer )
{
  return true;
}

void CityTouchHandler::ccTouchMoved( CCTouch *pTouch, CCLayer* target_layer )
{

}

void CityTouchHandler::ccTouchEnded( CCTouch *pTouch, CCLayer* target_layer )
{ 
  //bool b = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/ui_main_menu.lua", "TouchMainCityLayer");
  //if(!b)
  //{
	 // return;
  //}
  CCPoint p = target_layer->convertToNodeSpace(pTouch->getLocation());
  // check p is valid point in map or not
  if (false == IsPointPositionInRange(p))
  {
    return;
  }
  
  // check p is in the same tile index with role object's current destination
  cocos2d::CCPoint currentDest = CityController::GetInstance().
                            role_move_object()->move_data()->destination_pos();
  if (TiledIndex(TiledCoordinateFromLocation(p)) ==
      TiledIndex(TiledCoordinateFromLocation(currentDest)))
  {
    return;
  }

  uint_32 npc_id = kUnexistNpcId;
  if (this->isTouchOnNpc(p, npc_id))
  {
    assert(kUnexistNpcId!=npc_id);
    CityController::GetInstance().OnTouncNpcEvent(npc_id);
    return;
  }
  CityController::GetInstance().GetCityView()->GetCityLayer()->AddTouchPointAnimation(
    CityTouchPointAnimationManager::GetInstance().GetTouchAnimation(), p);
  // mark touch point only
  CityController::GetInstance().role_move_object()->move_data()->target_selection()->set_target_id(kUnexistNpcId);
  p = CityController::GetInstance().tiled_map()->GetNearestReachableTileCenterPositionToCurrentPoint(p);
  CityController::GetInstance().SendMoveObjectPathFindRequest(CityController::GetInstance().role_move_object(), p);
  CityController::GetInstance().role_move_object()->move_data()->set_ai_state(player_ai::kPlayerAIStateCommon);
}

void CityTouchHandler::ccTouchCancelled( CCTouch *pTouch, CCLayer* target_layer )
{

}

bool CityTouchHandler::isTouchOnNpc(const cocos2d::CCPoint& touch_point, uint_32& npc_id)
{
  std::list<NpcObject*>& npc_objects = CityController::GetInstance().npc_objects();

  for (std::list<NpcObject*>::iterator unit_iter = npc_objects.begin();
    unit_iter != npc_objects.end(); ++unit_iter)
  {

    const cocos2d::CCRect rect = (*unit_iter)->animation()->GetBoundingBox();
    if (rect.containsPoint(touch_point))
    {
      // TODO(leohou): take unit's zorder into account
      npc_id = (*unit_iter)->npc_id();
      return true;
    }
  }

  return false;
}

}
}