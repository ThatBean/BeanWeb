//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_touch_point_animation.cpp
//        Author: peteryu
//          Date: 2014/2/25 11:37
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/25      add
//////////////////////////////////////////////////////////////

#include "game/major_city/city_view/touch/city_touch_point_animation.h"

using namespace cocos2d;

namespace taomee
{
namespace city
{

CityTouchPointAnimationManager* CityTouchPointAnimationManager::manager_ = NULL;

CityTouchPointAnimation::CityTouchPointAnimation()
{
  for(int i = 0; i < CIRCLE_COUNT; ++i)
  {
    sprite_circle_[i] = NULL;
  }

  sprite_point_ = NULL;
  batch_node_   = NULL;

  batch_node_ = CCSpriteBatchNode::create("map/map_ui/touch_circle.png");

  for(int i = 0; i < CIRCLE_COUNT; ++i)
  {
    sprite_circle_[i] = CCSprite::create("map/map_ui/touch_circle.png");
    sprite_circle_[i]->setScale(0.0f);
    batch_node_->addChild(sprite_circle_[i], 0, i + 1);
  }

  addChild(batch_node_);
  sprite_point_ = CCSprite::create("map/map_ui/touch_point.png");
  addChild(sprite_point_);
}

CityTouchPointAnimation::~CityTouchPointAnimation()
{

}

void CityTouchPointAnimation::ReleaseCallBack()
{
  this->removeFromParentAndCleanup(true);
}
  
void CityTouchPointAnimation::SetTouchAnimationAlpha(float alpha)
{
  for(int i = 0; i < CIRCLE_COUNT; ++i)
  {
    sprite_circle_[i]->setOpacity(alpha * 255);
    //sprite_circle_[i]->setColor(ccc3(alpha * 255, alpha * 255, alpha * 255));
  }
  //sprite_point_->setColor(ccc3(alpha * 255, alpha * 255, alpha * 255));
  sprite_point_->setOpacity(alpha * 255);
}

void CityTouchPointAnimation::StartAnimation()
{
  for(int i = 0; i < CIRCLE_COUNT; ++i)
  {
    sprite_circle_[i]->cleanup();
  }
  sprite_point_->cleanup();

  CCRepeat *action_repeat_circle[CIRCLE_COUNT];

  for(int i = 0; i < CIRCLE_COUNT; ++i)
  {
    CCArray *array = CCArray::create();
    array->addObject(CCScaleTo::create(0.0001, 0.0, 0.0));
    array->addObject(CCScaleTo::create(TOTAL_TIME, 1.0, 1.0));
    array->addObject(CCScaleTo::create(0.0001, 0.0, 0.0));

    action_repeat_circle[i] = CCRepeat::create(CCSequence::create(array), TOTAL_COUNT);
  }

  for(int i = 1; i < CIRCLE_COUNT; ++i)
  {
    sprite_circle_[i]->runAction(CCSequence::create(CCScaleTo::create(TOTAL_TIME / CIRCLE_COUNT * i, 0, 0), action_repeat_circle[i], NULL));
  }

  CCArray *call_back_array = CCArray::create();
  call_back_array->addObject(action_repeat_circle[0]);
  call_back_array->addObject(CCCallFunc::create(this, (SEL_CallFunc)&CityTouchPointAnimation::ReleaseCallBack));
  sprite_circle_[0]->runAction(CCSequence::create(call_back_array));

  CCArray *action_point_array = CCArray::create();
  sprite_point_->setPositionY(8);
  action_point_array->addObject(CCMoveBy::create(0.3, ccp(0, 15)));
  action_point_array->addObject(CCMoveBy::create(0.3, ccp(0, -15)));
  sprite_point_->runAction(CCRepeatForever::create(CCSequence::create(action_point_array)));
}

}
}