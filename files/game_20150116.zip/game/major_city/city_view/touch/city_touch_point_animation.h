//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_touch_point_animation.h
//        Author: peteryu
//          Date: 2014/2/25 11:18
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/25      add
//////////////////////////////////////////////////////////////

#ifndef CITY_TOUCH_POINT_ANIMATION_H
#define CITY_TOUCH_POINT_ANIMATION_H

#include <string>

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

#include "engine/platform/SingleInstance.h"

using namespace std;
using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {
namespace city {

#define CIRCLE_COUNT  3
#define TOTAL_TIME    1.0
#define TOTAL_COUNT   1
 
class CityTouchPointAnimation : public CCNode
{
public:
  CityTouchPointAnimation();
  ~CityTouchPointAnimation();

  CC_CREATE_NO_PARAM(CityTouchPointAnimation);

  void ReleaseCallBack();

  void StartAnimation();
  
  void SetTouchAnimationAlpha(float alpha);

private:
  CCSprite *sprite_circle_[CIRCLE_COUNT];
  CCSprite *sprite_point_;
  CCSpriteBatchNode *batch_node_;
};

#define TOUCH_POINT_ANIMATION_MAX_COUNT 3

class CityTouchPointAnimationManager : public SingleInstanceObj
{
private:
  CityTouchPointAnimationManager(): cur_index_(0)
  {
    for(int i = 0; i < TOUCH_POINT_ANIMATION_MAX_COUNT; ++i)
    {
      animation_array_[i] = CityTouchPointAnimation::create();
      animation_array_[i]->retain();
    }
  }
public:
  ~CityTouchPointAnimationManager()
  {
    for(int i = 0; i < TOUCH_POINT_ANIMATION_MAX_COUNT; ++i)
    {
      animation_array_[i]->release();
    }
  }

public:
  static CityTouchPointAnimationManager& GetInstance()
  {
    if(manager_ == NULL)
    {
      manager_ = new CityTouchPointAnimationManager();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&manager_);
    }
    return *manager_;
  }
  static void PurgeInstance()
  {
    CC_SAFE_DELETE(manager_);
  }

  CityTouchPointAnimation* GetTouchAnimation()
  {
    animation_array_[cur_index_ % TOUCH_POINT_ANIMATION_MAX_COUNT]->removeFromParentAndCleanup(true);
    animation_array_[cur_index_ % TOUCH_POINT_ANIMATION_MAX_COUNT]->SetTouchAnimationAlpha(1.0);
    animation_array_[cur_index_ % TOUCH_POINT_ANIMATION_MAX_COUNT]->StartAnimation();
    for(int i = 1; i < TOUCH_POINT_ANIMATION_MAX_COUNT; ++i)
    {
      int index = (cur_index_ - i + TOUCH_POINT_ANIMATION_MAX_COUNT) % TOUCH_POINT_ANIMATION_MAX_COUNT;
      animation_array_[index]->SetTouchAnimationAlpha(1.0 - 1.0 / TOUCH_POINT_ANIMATION_MAX_COUNT * i);
    }
    return animation_array_[cur_index_++ % TOUCH_POINT_ANIMATION_MAX_COUNT];
  }

private:
  static CityTouchPointAnimationManager *manager_;
  CityTouchPointAnimation *animation_array_[TOUCH_POINT_ANIMATION_MAX_COUNT];
  int                     cur_index_;
};

}
} // namespace taomee

#endif
