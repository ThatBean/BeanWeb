//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_touch_handler.h
//        Author: peteryu
//          Date: 2014/2/14 15:08
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/14      add
//////////////////////////////////////////////////////////////
#ifndef CITY_TOUCH_HANDLER_H
#define CITY_TOUCH_HANDLER_H

#include <string>

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

using namespace std;
using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {
namespace city {

class CityLayer;
class SimpleMoveObject;
 
class CityTouchHandler
{
public:
  CityTouchHandler();
  ~CityTouchHandler();

  virtual bool ccTouchBegan(CCTouch *pTouch, CCLayer* target_layer);
  virtual void ccTouchMoved(CCTouch *pTouch, CCLayer* target_layer);
  virtual void ccTouchEnded(CCTouch *pTouch, CCLayer* target_layer);
  virtual void ccTouchCancelled(CCTouch *pTouch, CCLayer* target_layer);

private:
  bool         isTouchOnNpc(const cocos2d::CCPoint& touch_point, uint_32& npc_id);
};

}
} // namespace taomee

#endif
