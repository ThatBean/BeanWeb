//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_view.h
//        Author: peteryu
//          Date: 2014/2/12 17:03
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef CITY_VIEW_H
#define CITY_VIEW_H

#include <string>

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

using namespace std;
using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {
namespace city {

class CityLayer;
class SimpleMoveObject;
class NpcObject;
 
class CityView
{
public:
  CityView(CityLayer *city_layer);
  ~CityView();

  void        SetCityLayer(CityLayer *city_layer){city_layer_ = city_layer;}
  CityLayer*  GetCityLayer(){return city_layer_;}
  void        AddMoveObjectToView(SimpleMoveObject* object);
  void        RemoveMoveOjbectFromView(SimpleMoveObject* object);

  void        AddNpcObjectToView(NpcObject* object);
  void        RemoveNpcOjbectFromView(NpcObject* object);

private:
  CityLayer   *city_layer_;
};

}
} // namespace taomee

#endif
