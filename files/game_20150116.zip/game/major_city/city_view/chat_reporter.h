//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: chat_reporter.h
//        Author: Dylan.gu
//          Date: 2014/3/13 16:38
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/3/13      add
//////////////////////////////////////////////////////////////

#ifndef CHAT_REPORTER_H
#define CHAT_REPORTER_H

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace city {
    
typedef struct
 {
   uint_32         nChannel;
   std::string     nickName;
   std::string     content;
 } chatRecord;

enum eChannelType{
    kChannelAll = 0,
    kChannelCurrent,
    kChannelWorld
};

class ChatReporter
{
  public:
  ChatReporter();
  ~ChatReporter();

 public:
   void postNewTalkMessage(uint_32 nChannel,std::string strContent);
   void addChatRecord(uint_32 nChannel,std::string strNickName,std::string strContent);
   uint_32 getChatRecordsCount(uint_32 nChannel);
   chatRecord* getChatRecordsByIndex(uint_32 nChannel,uint_32 nIndex);
   
   char* cutChatString(const char* content);
 private:
   std::list<chatRecord*> list_chatRecordsAll;
   std::list<chatRecord*> list_charRecordWorld;
   std::list<chatRecord*> list_charRecordCurrent;
 };

} // namespace city
} // namespace taomee



#endif
