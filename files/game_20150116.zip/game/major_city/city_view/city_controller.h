//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_controller.h
//        Author: peteryu
//          Date: 2014/2/12 12:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef CITY_CONTROLLER_H
#define CITY_CONTROLLER_H

#include <list>
#include <map>

#include "engine/animation/player_skeleton_animation.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"
#include "game/major_city/pathfinding/pathfinding_planner_base.h"
#include "game/major_city/pathfinding/pathfinding_manager.h"
#include "game/major_city/players_data/npc_object.h"
#include "game/user_interface/template_scene.h"
//#include "game/major_city/city_view/pvp_net_connection.h"
#include "game/major_city/city_view/chat_reporter.h"
#include "game/major_city/city_view/announcement_net_connection.h"
#include "game/major_city/players_data/challenge_enemy_object.h"

#include "engine/platform/SingleInstance.h"

using namespace std;
using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {
class LoadHelper;

namespace city{

class CityView;
class SimpleMoveObject;
class PetBasicData;
class PetMoveObject;
class PlayerBasicData;
class PlayerMoveObject;
class CityTiledMap;
class CityTouchHandler;
class PosReporter;

enum eCitySceneChangeState
{
  kCitySceneChangeStateNone,
  kCitySceneChangeStateBattle,
  kCitySceneChangeStateOtherScene,
  kCitySceneChangeStateSwitchScene
};

class CityControllerListener : public cocos2d::CCObject
{

public:
  static CityControllerListener* create();
  ~CityControllerListener();
  CityControllerListener();

public:
  void      registerEventListener();
  void      unRegisterEventListener();
  void      onRankLevelUpEvent(cocos2d::CCObject* obj);
};

class CityController : public SingleInstanceObj
{
private:
  CityController();

public:
  ~CityController();
  static CityController& GetInstance();
  
public:
  // state manage
	void Prepare(LoadHelper* load_helper) {}	
	void Start();
  void Restart();
	void End();
  void UpdateEachFrame(float delta);
  void      onRankLevelUpEvent();
private: 
  //scene & view manage
  void      StartCitySceneFirstly();
  void      StartCitySceneBackFromBattle();
  void      StartCitySceneBackFromOtherScene();
  void      StartCitySceneSwitchScene();

  void      EndCitySceneToBattle();
  void      EndCitySceneToOtherScene();
  void      EndCitySceneToSwithScene();
public:
  //touch & path finding
  void      SendMoveObjectPathFindRequest(SimpleMoveObject* object, CCPoint p);
  void      OnMoveObjectPathNotFound(SimpleMoveObject* object);
  void      OnMoveObjectPathFound(SimpleMoveObject* object);
  void      OnMoveObjectPathFound(SimpleMoveObject* object, list<CCPoint>& path_list);
  void      OnTouncNpcEvent(uint_32 npc_id);

public:
  // mapSize = CCSizeMake(columnCount, rowCount) tileSize = CCSizeMake(tileWidth, tileCoulmn)
  void      CreateTiledMapWithMapSizeAndTileSize(cocos2d::CCSize mapSize,
                                                 cocos2d::CCSize tileSize);

  CityTiledMap*                 tiled_map() { return tiled_map_; }
  PathManager<PathPlannerBase>* path_manager() { return path_manager_; }
  std::list<NpcObject*>&        npc_objects(){return npc_objects_;}
  PlayerMoveObject*             role_move_object() { return role_move_object_; }
  PetMoveObject*                role_pet() { return role_pet_; }
//  PvpNetConnection              *pvp_connection() const { return pvp_connection_; }
  AnnouncementNetConnection     *announcement_connection() const { return announcement_connection_; }
  CityView*                     GetCityView() { return city_view_; }

  void      SetOtherObjectVisable(bool is_visable);
  void      SetPlayAndNpcVisible(bool is_visible);
  void      SetPosSyncIsActive(bool flag) { is_pos_sync_active_ = flag; }
  bool      GetIsSwitchCity(){ return is_switch_city_; }
  CCPoint   GetRandomBornPos();
  void      AddUILayerOnCity(CCLayer *layer,int nZOrder = 0){ assert(root_scene_ != NULL); root_scene_->AddLayerOnUILayer(layer, 0,nZOrder);}
  bool      hasBeenCreatedYet(const std::string& playerId);
  CCPoint   getCurrentPosByPlayerId(const std::string& playerId);
  void      SetCitySceneChangeState(eCitySceneChangeState state){city_scene_change_state_ = state;}
  eCitySceneChangeState   GetCitySceneChangeState(){return city_scene_change_state_;}

  void                  AddNpc( uint_32 npc_id, uint_32 char_id, uint_32 func_id,const std::string& func_res_name,
                                int tag, ePlayerAnimationDirection direction, float scale = 1.0f);
  NpcObject*            GetNPCById(uint_32 npc_id);
  void                  UpdateNpcHeadIcon();
  //play rank up projectile
  void                  PlayRankUpAnmi();

  void      AddAndShowChatRecord(uint_32 channel ,const std::string nick_name, const std::string content);
public:
  // net message
  // challenge
//   void                  SendGetChallengeList();
//   void                  SendChallengeRemotePlayerWithId(uint_32 user_id);
//   void                  SendResponseRemotePlayerChallengeWithAcceptFlag(bool acceptOrNot);
//   ChallengeEnemyObject* GetChallangeEnemyInfo(uint_8 index);
//   ChallengeEnemyObject* GetChallangeRequestInfo();
  // switch map
  void                  SendSwithCityMapRequest(uint_32 city_id);
  void                  OnSwithCityMapRequestResponsed();
  // chat
  void                  SendChatMessage(uint_32 nChannel,std::string content);
  chatRecord*           GetChatRecordByIndex(uint_32 nChannel,uint_32 nIndex);
  uint_32               GetChatRecordsCount(uint_32 nChannel);
  void                  UpdateChatLastThreeContent();
public:
  // move notification from server
  void OnNotificationRemotePlayerMove(boost::shared_ptr<XPacket> pack);
  // move notification from server after city scene removed
  void OnNotificationRemotePlayerMoveAfterCitySceneRemoved(boost::shared_ptr<XPacket> pack);
  void OnNotificationSceneChat(boost::shared_ptr<XPacket> pack);
  void OnNotificationWorldChat(boost::shared_ptr<XPacket> pack);

  void OnSwitchSceneCompleted(int error_code,net::NetSessionTcp* session );
private:
  void notificationRemotePlayerLevelChange(const std::string& playerId, int new_level);
  void notificationRemotePlayerUpStarChange(const std::string& playerId, int new_level);
  // login & login out & move
  // login in city scene or other scene
  void notificationRemotePlayerLoginCity(const PlayerBasicData* player,
    const PetBasicData* pet);
  // logout in city scene only
  void notificationRemotePlayerLogout(const std::string& playerId);
  // logou in other scene(not in city scene)
  void notificationRemotePlayerLogoutNotInCity(const std::string& playerId);
  // move to new position in city scene only
  void notificationRemotePlayerMove(const std::string& playerId,
    const cocos2d::CCPoint& nextDest);
  // move to new position in other scene(not in city scene)
  void notificationRemotePlayerMoveNotInCity(const std::string& playerId,
    const cocos2d::CCPoint& nextDest);

private:
  // players
  void    createPlayerAndPetForLocalUser(bool is_need_restore_pos);
  void    createRemotePlayerAndPetByTimeInterval(float delta);
  void    cleanUncreateList();
  void    createNPCData();
  void    cleanPlayerAndNpcData();
  int     getMoveObjectId(){ return global_object_index_++;}
  void    resetMoveObjectId(){ global_object_index_ = 3;}

  // create scene & tiled map 
  void    createCityScene(bool is_create_tiledmap = true);
  void    cleanCityScene();
  // createTiledMapWithMapSizeAndTileSize()
  void    cleanTiledMap();
  void    createPathPlanerAndPosRepoter();
  void    cleanPathPlanerAndPosRepoter();

/*  void    createPvpTCPConnection();*/
  void    createAnnouncementTCPConnection();
  void    createAllTCPConnection();
//  void    cleanPvpTCPConnection();
  void    cleanAnnouncementTCPConnection();
  void    setNotifyAndChatConnectionToOnCityScene();
  void    setNotifyConnectionToRemovedCityScene();
  void    cleanAllConnnection();

  void    updateCityLayer();
  void    clearAllBeforeCityInstancePurge();
  void    saveAllMoveObjectsBasicInfo();

  void    rankUpAllFinished();
private: 
  // map & pathfinding
  CityTiledMap*                   tiled_map_;
  PathManager<PathPlannerBase>*   path_manager_;
  
private: 
  // touch & view & position
  ui::TemplateScene             *root_scene_;
  CityView                      *city_view_;
  CityTouchHandler              *city_touch_handler_;
/*  PvpNetConnection              *pvp_connection_;*/
  AnnouncementNetConnection     *announcement_connection_;
  PosReporter                   *pos_reporter_;
  ChatReporter                  *chat_reporter_;
  boost::BOOST_SIGNALS_NAMESPACE::connection net_notify_connection_;
  boost::BOOST_SIGNALS_NAMESPACE::connection net_notify_connection_scnen_chat_;
  boost::BOOST_SIGNALS_NAMESPACE::connection net_notify_connection_world_chat_;

private: 
  // objects
  int_32                        global_object_index_;
  float                         create_interval_;
  std::map<PlayerBasicData*, PetBasicData*> uncreated_list_;
  
  PlayerMoveObject*             role_move_object_;
  PetMoveObject*                role_pet_;
  std::list<SimpleMoveObject*>  move_objects_;
  std::list<NpcObject*>         npc_objects_;
  std::map<uint_32, NpcObject*> npc_objects_map_;

private:
  // flag for city state
  eCitySceneChangeState         city_scene_change_state_;
  bool                          is_other_object_visable_;
  bool                          is_pos_sync_active_;
  bool                          is_switch_city_;
  bool                          is_waitting_switch_scene_response_;

  CityControllerListener*       mEventListener;
};

}
} // namespace taomee

#endif
