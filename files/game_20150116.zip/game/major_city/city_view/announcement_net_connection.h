//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: announcement_net_connection.h
//        Author: Dylan.gu
//          Date: 2014/4/28 10:09
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Dylan.gu    2014/4/28      add
//////////////////////////////////////////////////////////////

#ifndef ANNOUNCEMENT_NET_CONNECTION_H
#define ANNOUNCEMENT_NET_CONNECTION_H

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "network/net_client_tcp/sample_tcp_client.h"
#include "game/major_city/major_city_constants.h"

namespace taomee {

namespace net {
  class NetSessionTcp;
}

namespace city {

enum eAnnMsgShowPlace
{
  kAnnMsgShow_Screen_Mid = 1,
  kAnnMsgShow_Screen_Top,
  kAnnMsgShow_Screen_Chat
};

enum eAnnMsgEventType
{
  kAnnMsgType = 0,
  kAnnMsgType_Get_Five_Star_Card,
  kAnnMsgType_Char_Rank_Lv_Up,
  kAnnMsgType_Char_Break,
  kAnnMsgType_Char_Break_Max,
};
  
struct AnnouncementNetData
{
  int         nEventID;
  std::string stringParam1;
  std::string stringParam2;
  int         intParam1;
  int         intParam2;
  AnnouncementNetData(){
    nEventID = 0;
    stringParam1 = "";
    stringParam2 = "";
    intParam1 = 0;
    intParam2 = 0;
  }
};

class AnnouncementNetConnection
{
public:
  AnnouncementNetConnection();
  ~AnnouncementNetConnection();
public:
  void Test();
private:
  void showAnnMsg(AnnouncementNetData annNetData);
  void showAnnMsgEx(AnnouncementNetData annNetData);
  void showAllLogOut();

  void onNotificationAnnGetFiveStarCard(boost::shared_ptr<XPacket> pack);
  void onNotificationAnnCharacterRankLvUp(boost::shared_ptr<XPacket> pack);
  void onNotificationAnnCharacterBreak(boost::shared_ptr<XPacket> pack);
  void onNotificationAnnCharacterBreakMax(boost::shared_ptr<XPacket> pack);
  void onNotificationAnnGMInfoFromServer(boost::shared_ptr<XPacket> pack);
  void onNotificationAnnAllLogou(boost::shared_ptr<XPacket> pack);

private:
  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_announcement_fivestar_card;
  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_announcement_ranklv_up;
  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_announcement_break;
  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_announcement_break_max;
  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_announcement_gmtool;
  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_announcement_all_logout;
};

} // namespace city
} // namespace taomee

#endif

