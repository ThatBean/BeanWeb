//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_layer.cpp
//        Author: peteryu
//          Date: 2014/2/12 15:40
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#include "game/major_city/city_view/city_layer.h"

#include "engine/base/random_helper.h"
#include "engine/script/lua_tinker_manager.h"  
#include "game/major_city/city_view/touch/city_touch_handler.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/pathfinding/city_tiled_map.h"
#include "game/major_city/city_view/city_map_constants.h"

#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_data/player_move_object.h"

using namespace cocos2d::extension;

namespace taomee {
namespace city {

CityLayer::CityLayer()
  : city_touch_handler_(NULL),
    root_scene_node_(NULL)
{
  is_show_debug_tile_line_ = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "IsShowDebugTileLine");
}

CityLayer::~CityLayer()
{

}

bool CityLayer::init()
{
  if(!CCLayer::init())
    return false;

  return true;
}

void CityLayer::onEnter()
{
  CCLayer::onEnter();
  //this->drawCoordinate();
}

void CityLayer::draw()
{
  CCLayer::draw(); return;

  if (!is_show_debug_tile_line_)
    return;

  if (CityController::GetInstance().tiled_map()==NULL)
  {
    return;
  }
  ccDrawColor4F(0.5f,0.5f,0.5f,0.5f);
  glLineWidth(3.0f);
  int_32 row = CityController::GetInstance().tiled_map()->RowCountInCurrentCityMap();
  int_32 column = CityController::GetInstance().tiled_map()->ColumnCountInCurrentCityMap();
  for (int_32 i = 0; i<row; ++i)
  {
    for ( int_32 j = 0; j<column; ++j)
    {	  
      if (CityController::GetInstance().tiled_map()->CanUnitTraverseTileAtPos(ccp(j,i)))
      {
        continue;
      }
      cocos2d::CCPoint lTop = GetTileTopLeftPoint(ccp(j,i));
      cocos2d::CCPoint rTop = GetTileTopRightPoint(ccp(j,i));
      cocos2d::CCPoint rBottom = GetTileBottomRightPoint(ccp(j,i));
      cocos2d::CCPoint lBottom = GetTileBottomLeftPoint(ccp(j,i));
      ccDrawLine(lTop,rTop);
      ccDrawLine(rTop,rBottom);
      ccDrawLine(rBottom,lBottom);
      ccDrawLine(lBottom,lTop);
    }
  }
  ccDrawColor4F(0.5f,0.0f,0.0f,1.0f);
  cocos2d::CCPoint sourcePoint = CityController::GetInstance().role_move_object()->animation()->getPosition();
  cocos2d::CCPoint destinationPoint = CityController::GetInstance().role_move_object()->move_data()->target_selection()->target_pos();
  ccDrawLine(sourcePoint, destinationPoint);
  sourcePoint = destinationPoint;
  std::list<cocos2d::CCPoint>& path = CityController::GetInstance().role_move_object()->move_data()->path_list();
  std::list<cocos2d::CCPoint>::const_iterator it = path.begin();
  for ( ; it != path.end(); ++it )
  {
    destinationPoint = (*it);
    ccDrawLine(sourcePoint, destinationPoint);
    sourcePoint = destinationPoint;
  }
}

bool CityLayer::ccTouchBegan(CCTouch *pTouch, CCEvent *pEvent)
{
  if(city_touch_handler_)
    return city_touch_handler_->ccTouchBegan(pTouch, this);

  return true;
}

void CityLayer::ccTouchMoved(CCTouch *pTouch, CCEvent *pEvent)
{
  if(city_touch_handler_)
    city_touch_handler_->ccTouchMoved(pTouch, this);
}

void CityLayer::ccTouchEnded(CCTouch *pTouch, CCEvent *pEvent)
{
  if(city_touch_handler_)
    city_touch_handler_->ccTouchEnded(pTouch, this);
}

void CityLayer::ccTouchCancelled(CCTouch *pTouch, CCEvent *pEvent)
{
  if(city_touch_handler_)
    city_touch_handler_->ccTouchCancelled(pTouch, this);
}

void CityLayer::AddMoveNode( CCNode* child )
{
  root_scene_node_->getChildByTag(kSceneNodeTagCity)->addChild(child);
}

void CityLayer::AddBackNode(CCNode* child)
{
  root_scene_node_->getChildByTag(kSceneNodeTagBackground)->addChild(child);
}

void CityLayer::AddSceneNode( CCNode* scene_node )
{
  assert(root_scene_node_ == NULL);
  this->addChild(scene_node, -1);
  root_scene_node_ = scene_node;
}

void CityLayer::AddTouchPointAnimation( CCNode* animation, CCPoint pos)
{
  animation->setPosition(pos);
  animation->setZOrder(INT_MAX);
  root_scene_node_->getChildByTag(kSceneNodeTagCity)->addChild(animation);
}

void CityLayer::AddNPCTagPos(int tag, CCPoint pos)
{
  npc_tag_point_map_.insert(make_pair<int, CCPoint>(tag, pos));
}

void CityLayer::AddBornPos( const CCPoint &pos )
{
  born_pos_vec_.push_back(pos);
}

cocos2d::CCPoint CityLayer::GetNPCPosByTag( int tag )
{
  map<int, CCPoint>::iterator itr = npc_tag_point_map_.find(tag);
  if(itr != npc_tag_point_map_.end())
    return itr->second;
  return CCPointZero;
}

void CityLayer::drawCoordinate()
{
  if (CityController::GetInstance().tiled_map()==NULL)
  {
    return;
  }
  int_32 row = CityController::GetInstance().tiled_map()->RowCountInCurrentCityMap();
  int_32 column = CityController::GetInstance().tiled_map()->ColumnCountInCurrentCityMap();
  for (int_32 i = 0; i<row; ++i)
  {
    for ( int_32 j = 0; j<column; ++j)
    {
      if (CityController::GetInstance().tiled_map()->CanUnitTraverseTileAtPos(ccp(j,i)))
      {
        continue;
      }
      cocos2d::CCPoint pos = GetTileCenterPoint(ccp(j,i));
      const CCString* coordinateStr = CCString::createWithFormat("(%ld,%ld)", j, i);
      CCLabelTTF* label = CCLabelTTF::create(coordinateStr->getCString(), "Arial", 12);
      label->setPosition(pos);
      label->setColor(ccBLUE);
      this->addChild(label,100);
    }
  }
}

void CityLayer::ResetLayerPos()
{
  this->setPosition(ccp(568 - getContentSize().width / 2,
                        320 - getContentSize().height / 2));
}

CCPoint CityLayer::GetRandomBornPos()
{
  assert(born_pos_vec_.size() >= 2 && born_pos_vec_.size() % 2 == 0);
  // one born area
  if(born_pos_vec_.size() / 2 == 1)
  {
    int width = born_pos_vec_[1].x - born_pos_vec_[0].x;
    int height = born_pos_vec_[1].y - born_pos_vec_[0].y;
    return ccp(born_pos_vec_[0].x + random_0_1() * width, born_pos_vec_[0].y + random_0_1() * height);
  }

  int area_index = random_lower_upper(0, born_pos_vec_.size() / 2 - 1);
  int width = born_pos_vec_[area_index * 2 + 1].x - born_pos_vec_[area_index].x;
  int height = born_pos_vec_[area_index * 2 + 1].y - born_pos_vec_[area_index].y;

  return ccp( born_pos_vec_[area_index].x + random_0_1() * width,
              born_pos_vec_[area_index].y + random_0_1() * height);
}

}
} // namespace taomee