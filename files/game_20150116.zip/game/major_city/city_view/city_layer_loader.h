//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_layer_loader.h
//        Author: peteryu
//          Date: 2014/2/12 11:59
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////

#ifndef CITY_LAYER_LOADER_H
#define CITY_LAYER_LOADER_H

#include <string>

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

#include "engine/platform/SingleInstance.h"

using namespace std;
using namespace cocos2d;

namespace taomee {
namespace city {

class CityLayer;
 
class CityLayerLoader : public SingleInstanceObj
{
private:
  CityLayerLoader();
public:
  ~CityLayerLoader();

  static CityLayerLoader& GetInstance(){
    static CityLayerLoader* X = NULL;
    if (!X)
    {
      X = new CityLayerLoader();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }
  
  CityLayer*  CreateCityLayer(string map_name, bool is_create_tiledmap);

private:
  void        LoadNPCPostion(CCNode *scene_node, CityLayer *city_layer);
  void        LoadBornArea(CCNode *scene_node, CityLayer *city_layer);
  void        LoadPathTile(CCNode *map_node);
  void        CreateBackgroundBatchNode(CCNode *scene_node);
  void        CreateDecorationBatchNode(CCNode *scene_node);

private:
  string      map_name_;
};

}
} // namespace taomee

#endif
