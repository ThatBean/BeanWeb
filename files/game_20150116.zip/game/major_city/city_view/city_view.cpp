//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: city_view.cpp
//        Author: peteryu
//          Date: 2014/2/12 17:03
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/2/12      add
//////////////////////////////////////////////////////////////
#include "game/major_city/city_view/city_view.h"

#include "engine/animation/player_skeleton_animation.h"
#include "engine/animation/skeleton_animation.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_data/npc_object.h"
#include "game/major_city/city_view/city_layer.h"

namespace taomee
{
namespace city
{

CityView::CityView(CityLayer *city_layer)
  : city_layer_(city_layer)
{
}

CityView::~CityView()
{
  city_layer_->removeFromParentAndCleanup(true);
}

void CityView::AddMoveObjectToView(SimpleMoveObject* object)
{
  assert(city_layer_);
  city_layer_->AddMoveNode(object->animation());
}

void CityView::RemoveMoveOjbectFromView(SimpleMoveObject* object)
{
  assert(city_layer_);
  object->animation()->removeFromParentAndCleanup(true);
}

void CityView::AddNpcObjectToView( NpcObject* object )
{
  assert(city_layer_);
  city_layer_->AddMoveNode(object->animation());
}

void CityView::RemoveNpcOjbectFromView( NpcObject* object )
{
  assert(city_layer_);
  object->animation()->removeFromParentAndCleanup(true);
}

}
}