//
//  pos_reporter.cpp
//  ChainChronicle
//
//  Created by gaven on 2/26/14.
//
//

#include "game/major_city/city_view/pos_reporter.h"

#include "network/net_client_tcp/sample_tcp_client.h"
#include "network/net_client_tcp/net_session_tcp.h"
#include "network/net_client_tcp/protocol/cpp/mcs.pb.h"
#include "game/account/account_manager.h"
#include "network/net_constant.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/major_city/city_view/city_controller.h"

namespace taomee {
namespace city {

const float DEFAULT_INTREVAL_TIME = 1.0f; 

PosReporter::PosReporter()
  : switch_flag_(false),
    time_interval_(0.0f),
    new_pos_(cocos2d::CCPointZero),
    is_ignore_next_pos_(false)
{
  
}
  
void PosReporter::UpdatePositionReporter(float delta)
{
  if (false==switch_flag_)
  {
    return;
  }
  time_interval_ += delta;
  if (time_interval_ < DEFAULT_INTREVAL_TIME)
  {
    return;
  }
  switch_flag_ = false;
  time_interval_ = 0.0f;
  this->postNewPositionToServer(new_pos_.x, new_pos_.y);
}
  
void PosReporter::postNewPositionToServer(uint_32 xPos, uint_32 yPos)
{
  if(is_ignore_next_pos_)
  {
    is_ignore_next_pos_ = false;
    return;
  }
  // set header
  boost::shared_ptr<net::NetSessionTcp> post_pos_requset = boost::make_shared<net::NetSessionTcp>();
  post_pos_requset->set_request_cmd(ACC::cli_post_pos_cmd);
  post_pos_requset->set_request_ower(taomee::account::AccountManager::GetInstance().user_id_str().c_str());
  
  // set required paramters
  ACC::cli_post_pos_in message_in;
  message_in.set_x(xPos);
  message_in.set_y(yPos);
  post_pos_requset->set_message_in<ACC::cli_post_pos_in>(message_in);
  
  // send
  net::SampleTcpClient::GetInstance().SendRequest(post_pos_requset);

  CityController::GetInstance().SetPosSyncIsActive(true);
  cocos2d::CCLog("Send Pos new pos x: %ld, y: %ld", xPos, yPos);
}
  
} // namespace city
} // namespace taomee