//
//  city_tiled_map.h
//  ChainChronicle
//
//  Created by gaven on 2/14/14.
//
//

#ifndef __ChainChronicle__city_tiled_map__
#define __ChainChronicle__city_tiled_map__

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/major_city/pathfinding/path_edge.h"
#include "game/major_city/city_view/city_controller.h"

namespace taomee {
namespace city {

const cocos2d::CCPoint  kInvalidTiledCoordinate = CCPoint(-1, -1);

/** NOTE : global public C methods for coordinate helper on city tiled map **/
cocos2d::CCPoint TiledCoordinateFromLocation(const cocos2d::CCPoint& location); 
cocos2d::CCPoint TiledCoordinateFromIndex(uint_32 tiled_index);

cocos2d::CCPoint GetTileTopLeftPoint(const cocos2d::CCPoint& coordinate);
cocos2d::CCPoint GetTileBottomLeftPoint(const cocos2d::CCPoint& coordinate);
cocos2d::CCPoint GetTileTopRightPoint(const cocos2d::CCPoint& coordinate);
cocos2d::CCPoint GetTileBottomRightPoint(const cocos2d::CCPoint& coordinate);
cocos2d::CCPoint GetTileCenterPoint(const cocos2d::CCPoint& coordinate);

uint_32 TiledIndex(const cocos2d::CCPoint& coordinate);
uint_32 TiledIndex(uint_32 columnIdx, uint_32 rowIdx);

bool IsPointPositionInRange(const cocos2d::CCPoint& pointPos);
bool IsTileCoordinateInRange(const cocos2d::CCPoint& coordinate);
bool IsTileCoordinateInRange(uint_32 columnIdx, uint_32 rowIdx);
bool AreTheseTwoTilesConecttedPairs(uint_32 vIdx, uint_32 neighborVIndex);

float DistanceBetweenTiles(const cocos2d::CCPoint& begin_tiled_coordinate,
                           const cocos2d::CCPoint& end_tiled_coordinate);
float RadiansBetweenTiles(const cocos2d::CCPoint& begin_tiled_coordinate,
                          const cocos2d::CCPoint& end_tiled_coordinate);
float RadiansBetweenPoint(const cocos2d::CCPoint& begin_pos,
                          const cocos2d::CCPoint& end_pos);
  
int_32 GetZorderByPosition(cocos2d::CCPoint pos, uint_32 objId = 0);
/** global public C methods END **/

class CityTiledMap
{
public:
  /* NOTE : tiles_ is a vector : tiles_[rowCnt][columnCnt]
            rowCnt is max value of y axis; columnCnt is max value of x axis
            eg. tiles_[y][x] maens tile coordinate point(x,y) in tiled map grids:
            tileIndex = columnCnt * y + x
         ---------------------------------------> X
         | (0,0)  (1,0)  (2,0) ... (107,0)
         | (0,1)  (1,1)  (2,1) ... (107,1)
         |   .      .      .   ...    .
         |   .      .      .   ...    .
         |   .      .      .   ...    .
      Y  | (0,59) (1,59) (2,59) ...(107,59)
        \|/            
   NOTE END*/
  CityTiledMap(uint_32 columnCnt, uint_32 rowCnt, float tileWidth, float tileHeight);
  ~CityTiledMap();
  
public: //  setter & getter
  void SetCoverageInfoForTileAtIndex(uint_32 tileIdx, bool isCoverd);
  void SetCoverageInfoForTileAtPos(uint_32 rowIdx, uint_32 columnIdx, bool isCoverd);
  void SetCoverageInfoForTileAtPos(const cocos2d::CCPoint& tilePos, bool isCoverd);
  void CoverTileAtIndex(uint_32 tileIdx);
  void CoverTileAtPos(uint_32 rowIdx, uint_32 columnIdx);
  void CoverTileAtPos(const cocos2d::CCPoint& tilePos);
  void CleanTileAtIndex(uint_32 tileIdx);
  void CleanTileAtPos(uint_32 rowIdx, uint_32 columnIdx);
  void CleanTileAtPos(const cocos2d::CCPoint& tilePos);
  
  bool CanUnitTraverseTileAtIndex(uint_32 tileIdx);
  bool CanUnitTraverseTileAtPos(uint_32 rowIdx, uint_32 columnIdx);
  bool CanUnitTraverseTileAtPos(const cocos2d::CCPoint& tilePos);
  
  bool CanWalkableBetween(cocos2d::CCPoint sourcePoint,
                          cocos2d::CCPoint destinationPoint);
  
  uint_32 RowCountInCurrentCityMap() { return tile_row_count_; }
  uint_32 ColumnCountInCurrentCityMap() { return tile_coulmn_count_; }
  float   TileWidthInCurrentCityMap() { return tile_width_; }
  float   TileHeightInCurrentCityMap() { return tile_height_; }
  
  float   MapWidth() { return tile_coulmn_count_*tile_width_; }
  float   MapHeight() { return tile_row_count_*tile_height_; }
  
  cocos2d::CCPoint GetNearestReachableTileCenterPositionToCurrentPoint(
    const cocos2d::CCPoint& curPos);
  
private:
  struct Tile
  {
    // has been coverd by building/barriers
    bool is_coverd;
  };
  
private:
  uint_32   tile_row_count_;
  uint_32   tile_coulmn_count_;
  float     tile_width_;
  float     tile_height_;
  Tile***   tiles_;  
  
public: // friend class
  // const version above
  class ConstEdgeIterator
  { 
  public:
    ConstEdgeIterator(int_32 vIdx);
    const GraphEdge* begin()
    {
      assert(currEdgeList.size());
      curEdge = currEdgeList.begin();
      return &(*curEdge);
    }
    const GraphEdge* next()
    {
      ++curEdge;
      if (end())
      {
        return NULL;
      }
      return &(*curEdge);
    }
    bool end()
    {
      return (curEdge == currEdgeList.end());
    }
  private:
    const int_32         vertexIdx;
    const CityTiledMap&  tiledMap;
    std::list<GraphEdge> currEdgeList;
    std::list<GraphEdge>::const_iterator curEdge;
  };
  friend class ConstEdgeIterator;
};
  
} // namespace city
} //namespace taomee

#endif /* defined(__ChainChronicle__city_tiled_map__) */
