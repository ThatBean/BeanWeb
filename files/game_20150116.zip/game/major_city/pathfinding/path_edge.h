//
//  path_edge.h
//  ChainChronicle
//
//  Created by gaven on 2/17/14.
//
//

#ifndef ChainChronicle_path_edge_h
#define ChainChronicle_path_edge_h

#include <assert.h>
#include "engine/base/basictypes.h"
#include "game/major_city/major_city_constants.h"

namespace taomee {
namespace city {
  
class GraphEdge
{
public:
  GraphEdge(int_32 source,
            int_32 destination,
            float  score = 1.0f)
  : from_(source),
    to_(destination),
    score_(score)
  {
  }
  GraphEdge(GraphEdge const &edge)
  {
    from_ = edge.getFrom();
    to_ = edge.getTo();
    score_ = edge.getScore();
  }
  
public: //getter & setter
  int_32 getFrom() const { return from_; }
  int_32 getTo() const { return to_; }
  float  getScore() const { return score_; }
  
  void   setFrom(int_32 _from) { from_ = _from; }
  void   setTo(int_32 _to) { to_ = _to; }
  void   setScore(float _score) { score_ = _score; }
  
private:
  int_32 from_;
  int_32 to_;
  float  score_;
};
  
class PathEdge
{
public:
  PathEdge(cocos2d::CCPoint source,
           cocos2d::CCPoint destination)
  : source_(source),
    destination_(destination)
  {
  }
  PathEdge(PathEdge const &edge)
  {
    source_ = edge.source();
    destination_ = edge.destination();
  }    
  
public: //getter & setter
  cocos2d::CCPoint source() const { return source_; }
  cocos2d::CCPoint destination() const { return destination_; }
  
  void setSource(cocos2d::CCPoint _source) { source_ = _source; }
  void setDestination(cocos2d::CCPoint _destination) { destination_ = _destination; }
  
private:
  cocos2d::CCPoint source_;
  cocos2d::CCPoint destination_;
};
  
} // namespace city
} // namespace taomee

#endif // ChainChronicle_path_edge_h
