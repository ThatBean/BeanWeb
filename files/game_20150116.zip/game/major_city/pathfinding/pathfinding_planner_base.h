//
//  pathfinding_planner_base.h
//  ChainChronicle
//
//  Created by gaven on 2/17/14.
//
//

#ifndef ChainChronicle_pathfinding_planner_base_h
#define ChainChronicle_pathfinding_planner_base_h

#include "game/major_city/major_city_constants.h"

namespace cocos2d
{
  class CCPoint;
}

namespace taomee {
namespace city {
  class PathEdge;
  typedef std::list<PathEdge> Path;
  
class PathPlannerBase {
public:
  virtual ~PathPlannerBase() {};
  
  virtual eSearchResult CycleOnce() = 0;
  virtual bool requestPathToTarget(const cocos2d::CCPoint& targetPos) = 0;
  
  virtual void GetPath(Path* path) = 0;
};
}
}
#endif // ChainChronicle_pathfinding_planner_base_h
