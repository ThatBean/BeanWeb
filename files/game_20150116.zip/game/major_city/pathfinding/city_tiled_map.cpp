//
//  city_tiled_map.cpp
//  ChainChronicle
//
//  Created by gaven on 2/14/14.
//
//

#include "game/major_city/pathfinding/city_tiled_map.h"

#include <assert.h>
#include "game/major_city/major_city_constants.h"
#include "game/major_city/city_view/city_controller.h"

namespace taomee {
namespace city {
  
/** NOTE : global public C methods for coordinate helper on city tiled map **/
// 108 * 60 is max map size, will be set new value during tiled map instace's creatation
static uint_32 kCityMapTiledGridRowCount    = 60;
static uint_32 kCityMapTiledGridCoulmnCount = 108;
static uint_32 kCityMapTiledGridWidth       = 32;
static uint_32 kCityMapTiledGridHeight      = 32;
// location is target point position on city view layer
cocos2d::CCPoint TiledCoordinateFromLocation(const cocos2d::CCPoint& location)
{
  assert(CityController::GetInstance().tiled_map());
  float locationY = kCityMapTiledGridHeight*kCityMapTiledGridRowCount - location.y;
  //Modify by peteryu, need not assert
  if(!(locationY>=0.0f && locationY<=kCityMapTiledGridHeight*kCityMapTiledGridRowCount &&
    location.x>=0.0f && location.x<=kCityMapTiledGridWidth*kCityMapTiledGridCoulmnCount))
    return kInvalidTiledCoordinate;
  //assert(locationY>=0.0f && locationY<=kCityMapTiledGridHeight*kCityMapTiledGridRowCount &&
  //       location.x>=0.0f && location.x<=kCityMapTiledGridWidth*kCityMapTiledGridCoulmnCount);
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = static_cast<uint_32>(floorf(location.x / kCityMapTiledGridWidth));
  tiledPos.y = static_cast<uint_32>(floorf(locationY / kCityMapTiledGridHeight));
  
  tiledPos.x = MIN(kCityMapTiledGridCoulmnCount-1, tiledPos.x);
  tiledPos.y = MIN(kCityMapTiledGridRowCount-1, tiledPos.y);
  return tiledPos;
}
cocos2d::CCPoint TiledCoordinateFromIndex(uint_32 tiled_index)
{
  assert(CityController::GetInstance().tiled_map() &&
         tiled_index>=0 && tiled_index<=kCityMapTiledGridRowCount*kCityMapTiledGridCoulmnCount);
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = tiled_index % kCityMapTiledGridCoulmnCount;
  tiledPos.y = static_cast<uint_32>(floorf(tiled_index / kCityMapTiledGridCoulmnCount));
  return tiledPos;
}

cocos2d::CCPoint GetTileTopLeftPoint(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(coordinate));
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = coordinate.x * kCityMapTiledGridWidth;
  tiledPos.y = kCityMapTiledGridHeight*kCityMapTiledGridRowCount -
               coordinate.y * kCityMapTiledGridHeight;
  return tiledPos;
}
cocos2d::CCPoint GetTileBottomLeftPoint(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(coordinate));
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = coordinate.x * kCityMapTiledGridWidth;
  tiledPos.y = kCityMapTiledGridHeight*kCityMapTiledGridRowCount -
               (coordinate.y+1) * kCityMapTiledGridHeight;
  return tiledPos;
}
cocos2d::CCPoint GetTileTopRightPoint(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(coordinate));
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = (coordinate.x+1) * kCityMapTiledGridWidth;
  tiledPos.y = kCityMapTiledGridHeight*kCityMapTiledGridRowCount -
               coordinate.y * kCityMapTiledGridHeight;
  return tiledPos;
}
cocos2d::CCPoint GetTileBottomRightPoint(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(coordinate));
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = (coordinate.x+1) * kCityMapTiledGridWidth;
  tiledPos.y = kCityMapTiledGridHeight*kCityMapTiledGridRowCount -
               (coordinate.y+1) * kCityMapTiledGridHeight;
  return tiledPos;
}
cocos2d::CCPoint GetTileCenterPoint(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(coordinate));
  cocos2d::CCPoint tiledPos = ccp(0,0);
  tiledPos.x = (coordinate.x+0.5f) * kCityMapTiledGridWidth;
  tiledPos.y = kCityMapTiledGridHeight*kCityMapTiledGridRowCount -
               (coordinate.y+0.5f) * kCityMapTiledGridHeight;
  return tiledPos;
}

uint_32 TiledIndex(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map()&&
         IsTileCoordinateInRange(coordinate));
  return static_cast<uint_32>(coordinate.y*kCityMapTiledGridCoulmnCount+coordinate.x);
}
uint_32 TiledIndex(uint_32 columnIdx, uint_32 rowIdx)
{
  assert(CityController::GetInstance().tiled_map());
  cocos2d::CCPoint coordinate = ccp(columnIdx, rowIdx);
  assert(IsTileCoordinateInRange(coordinate));
  return static_cast<uint_32>(coordinate.y*kCityMapTiledGridCoulmnCount+coordinate.x);
}

bool IsPointPositionInRange(const cocos2d::CCPoint& pointPos)
{
  assert(CityController::GetInstance().tiled_map());
  return (pointPos.x>=0.0f && pointPos.x<=kCityMapTiledGridWidth*kCityMapTiledGridCoulmnCount &&
          pointPos.y>=0.0f && pointPos.y<=kCityMapTiledGridHeight*kCityMapTiledGridRowCount);
}
bool IsTileCoordinateInRange(const cocos2d::CCPoint& coordinate)
{
  assert(CityController::GetInstance().tiled_map());
  return IsTileCoordinateInRange(coordinate.x, coordinate.y);
}
bool IsTileCoordinateInRange(uint_32 columnIdx, uint_32 rowIdx)
{
  assert(CityController::GetInstance().tiled_map());
  return (columnIdx<kCityMapTiledGridCoulmnCount && columnIdx >= 0 &&
          rowIdx<kCityMapTiledGridRowCount && rowIdx >= 0);
}
  
bool AreTheseTwoTilesConecttedPairs(uint_32 vIdx, uint_32 neighborVIndex)
{
  if (vIdx%kCityMapTiledGridCoulmnCount==0 &&
      ((neighborVIndex+1)%kCityMapTiledGridCoulmnCount==0))
  {
    return false;
  }
  else if((vIdx+1)%kCityMapTiledGridCoulmnCount==0 &&
          neighborVIndex%kCityMapTiledGridCoulmnCount==0)
  {
    return false;
  }
  return true;
}

float DistanceBetweenTiles(const cocos2d::CCPoint& begin_tiled_coordinate,
                           const cocos2d::CCPoint& end_tiled_coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(begin_tiled_coordinate) &&
         IsTileCoordinateInRange(end_tiled_coordinate));
  cocos2d::CCPoint begin_pos = GetTileCenterPoint(begin_tiled_coordinate);
  cocos2d::CCPoint end_pos = GetTileCenterPoint(end_tiled_coordinate);
  return ccpDistance(begin_pos, end_pos);
}
float RadiansBetweenTiles(const cocos2d::CCPoint& begin_tiled_coordinate,
                          const cocos2d::CCPoint& end_tiled_coordinate)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(begin_tiled_coordinate) &&
         IsTileCoordinateInRange(end_tiled_coordinate));
  cocos2d::CCPoint begin_pos = GetTileCenterPoint(begin_tiled_coordinate);
  cocos2d::CCPoint end_pos = GetTileCenterPoint(end_tiled_coordinate);
  return RadiansBetweenPoint(begin_pos, end_pos);
}
float RadiansBetweenPoint(const cocos2d::CCPoint& begin_pos,
                          const cocos2d::CCPoint& end_pos)
{
  assert(CityController::GetInstance().tiled_map() &&
         IsTileCoordinateInRange(TiledCoordinateFromLocation(begin_pos)) &&
         IsTileCoordinateInRange(TiledCoordinateFromLocation(end_pos)));
  float delta_x = end_pos.x - begin_pos.x;
  float delta_y = end_pos.y - begin_pos.y;
  if(delta_x == 0)
  {
    if (delta_y<=0)
    {
      return M_PI*1.5f;
    }
    else
    {
      return M_PI*0.5f;
    }
  }
  else
  {
    float radians = atanf(delta_y / delta_x);
    if (delta_y>0)
    {
      if (delta_x>0)
      {  // 1
        return radians;
      }
      else
      {  //  2
        return M_PI+radians;
      }
    }
    else
    {
      if (delta_x>0)
      { //  4
        return 2*M_PI+radians;
      }
      else
      {  // 3
        return M_PI+radians;
      }
    }
  }
}
  
int_32 GetZorderByPosition(cocos2d::CCPoint pos, uint_32 objId /* = 0 */ )
{
  int_32 mapHeight = kCityMapTiledGridRowCount*kCityMapTiledGridHeight;

  //Modify by peteryu, pos may exceed map area  
  if(pos.y <= 0)
    pos.y = 0;
  else if(pos.y >= mapHeight)
    pos.y = mapHeight;

  int_32 height = (mapHeight - static_cast<int>(pos.y));
  //assert(mapHeight>=0&&height<=mapHeight);
  //height = (height<<8) | objId;
  return height;
}
/** global public C methods END **/
  
CityTiledMap::CityTiledMap(uint_32 columnCnt, uint_32 rowCnt, float tileWidth, float tileHeight)
  : tile_row_count_(rowCnt),
    tile_coulmn_count_(columnCnt),
    tile_width_(tileWidth),
    tile_height_(tileHeight)
{
  //assert(tile_row_count_<=kCityMapTiledGridRowCount);
  //assert(tile_coulmn_count_<=kCityMapTiledGridCoulmnCount);
  kCityMapTiledGridRowCount = tile_row_count_;
  kCityMapTiledGridCoulmnCount = tile_coulmn_count_;
  kCityMapTiledGridWidth = tile_width_;
  kCityMapTiledGridHeight = tile_height_;
  tiles_ = static_cast<Tile***>(malloc(sizeof(Tile**)*rowCnt));
  for (uint_32 rowIdx = 0; rowIdx<rowCnt; ++rowIdx)
  {
    tiles_[rowIdx] = static_cast<Tile**>(malloc(sizeof(Tile*)*columnCnt));
    for (uint_32 columnIdx = 0; columnIdx<columnCnt; ++columnIdx)
    {
      tiles_[rowIdx][columnIdx] = static_cast<Tile*>(malloc(sizeof(Tile)));
	  // means new (tiles_[rowIdx][columnIdx])Tile;
      (tiles_[rowIdx][columnIdx])->is_coverd = false;
    } 
  }
}
  
CityTiledMap::~CityTiledMap()
{
  for (uint_32 rowIdx = 0; rowIdx<kCityMapTiledGridRowCount; ++rowIdx)
  {
    for (uint_32 columnIdx = 0; columnIdx<kCityMapTiledGridCoulmnCount; ++columnIdx)
    {
      free(tiles_[rowIdx][columnIdx]);
    }
    free(tiles_[rowIdx]);
  }
  free(tiles_);
}
  
void CityTiledMap::SetCoverageInfoForTileAtIndex(uint_32 tileIdx,
                                                 bool isCoverd)
{
  uint_32 rowIdx = tileIdx/kCityMapTiledGridCoulmnCount;
  uint_32 columnIdx = tileIdx%kCityMapTiledGridCoulmnCount;
  this->SetCoverageInfoForTileAtPos(rowIdx, columnIdx, isCoverd);
}
void CityTiledMap::SetCoverageInfoForTileAtPos(uint_32 rowIdx,
                                               uint_32 columnIdx,
                                               bool isCoverd)
{
  (tiles_[rowIdx][columnIdx])->is_coverd = isCoverd;
}
void CityTiledMap::SetCoverageInfoForTileAtPos(const cocos2d::CCPoint& tilePos,
                                               bool isCoverd)
{
  this->SetCoverageInfoForTileAtPos(tilePos.y, tilePos.x, isCoverd);
}
void CityTiledMap::CoverTileAtIndex(uint_32 tileIdx)
{
  this->SetCoverageInfoForTileAtIndex(tileIdx, true);
}
void CityTiledMap::CoverTileAtPos(uint_32 rowIdx, uint_32 columnIdx)
{
  this->SetCoverageInfoForTileAtPos(rowIdx, columnIdx, true);
}
void CityTiledMap::CoverTileAtPos(const cocos2d::CCPoint& tilePos)
{
  this->SetCoverageInfoForTileAtPos(tilePos, true);
}
void CityTiledMap::CleanTileAtIndex(uint_32 tileIdx)
{
  this->SetCoverageInfoForTileAtIndex(tileIdx, false);
}
void CityTiledMap::CleanTileAtPos(uint_32 rowIdx, uint_32 columnIdx)
{
  this->SetCoverageInfoForTileAtPos(rowIdx, columnIdx, false);
}
void CityTiledMap::CleanTileAtPos(const cocos2d::CCPoint& tilePos)
{
  this->SetCoverageInfoForTileAtPos(tilePos, false);
}

bool CityTiledMap::CanUnitTraverseTileAtIndex(uint_32 tileIdx)
{
  uint_32 rowIdx = tileIdx/kCityMapTiledGridCoulmnCount;
  uint_32 columnIdx = tileIdx%kCityMapTiledGridCoulmnCount;
  return ((tiles_[rowIdx][columnIdx])->is_coverd==false);
}
bool CityTiledMap::CanUnitTraverseTileAtPos(uint_32 rowIdx, uint_32 columnIdx)
{
  return ((tiles_[rowIdx][columnIdx])->is_coverd==false);
}
bool CityTiledMap::CanUnitTraverseTileAtPos(const cocos2d::CCPoint& tilePos)
{
  assert((tilePos.x >= 0));
  assert((tilePos.y >= 0));

  //tilePos.x = tilePos.x > 0 ? tilePos.y : 0.0f;
  //tilePos.y = tilePos.y > 0 ? tilePos.y : 0.0f;
  assert(tiles_[static_cast<uint_32>(tilePos.y)][static_cast<uint_32>(tilePos.x)]);
  if (tiles_[static_cast<uint_32>(tilePos.y)][static_cast<uint_32>(tilePos.x)] == NULL)
    return false;

  return ((tiles_[static_cast<uint_32>(tilePos.y)]
                 [static_cast<uint_32>(tilePos.x)])->is_coverd==false);
}
  
cocos2d::CCPoint CityTiledMap::
  GetNearestReachableTileCenterPositionToCurrentPoint(const cocos2d::CCPoint& curPos)
{
  cocos2d::CCPoint tilePos = TiledCoordinateFromLocation(curPos);
  if (this->CanUnitTraverseTileAtPos(tilePos))
  {
    return curPos;
  }
  
  uint_32 size = tile_row_count_*tile_coulmn_count_/8 + 1;
  std::list<cocos2d::CCPoint> tileList;
  tileList.push_back(tilePos);
  uint_8 *flag = new uint_8[size];
  memset(flag, 0, sizeof(uint_8)*size);
  bool hasFound = false;
  do {
    cocos2d::CCPoint neiborTiles[4] = {
      ccp(tilePos.x-1,tilePos.y),
      ccp(tilePos.x,tilePos.y-1),
      ccp(tilePos.x+1,tilePos.y),
      ccp(tilePos.x,tilePos.y+1)
    };
    for (int i = 0; i<4; ++i)
    {
      if(!IsTileCoordinateInRange(neiborTiles[i]))
      {
        continue;
      }
      uint_32 tileIdx = TiledIndex(neiborTiles[i]);
      uint_32 idx = tileIdx/8;
      uint_32 bitIdx = tileIdx%8;
      if (!(flag[idx] & 0x1<<(bitIdx)) && IsTileCoordinateInRange(neiborTiles[i]))
      {
        flag[idx] = flag[idx] | 0x1<<(bitIdx);
        if (this->CanUnitTraverseTileAtPos(neiborTiles[i]))
        {
          hasFound = true;
          tilePos = neiborTiles[i];
          break;
        }
        else
        {
          tileList.push_back(neiborTiles[i]);
        }
      }
    }
    if (hasFound)
    {
      break;
    }
    tilePos = tileList.front();
    tileList.pop_front();
  } while (tileList.size());
  delete [] flag;
  return GetTileCenterPoint(tilePos);
}
  
bool CityTiledMap::CanWalkableBetween(cocos2d::CCPoint sourcePoint,
                                      cocos2d::CCPoint destinationPoint)
{
  // same position do not need move
  if (sourcePoint.x == destinationPoint.x &&
      sourcePoint.y == destinationPoint.y)
  {
    return true;
  }
  // different position need check
  int_32 direction = 0;
  cocos2d::CCPoint sourceTilePos = TiledCoordinateFromLocation(sourcePoint);
  cocos2d::CCPoint destinationTilePos = TiledCoordinateFromLocation(destinationPoint);
  // source point & destination point are in same column
  if (sourceTilePos.x == destinationTilePos.x)
  {
    direction = (sourceTilePos.y>destinationTilePos.y) ? (-1) : 1;
    int_32 yIdx = static_cast<int_32>(sourceTilePos.y);
    while ((static_cast<int_32>(destinationTilePos.y)-yIdx)*direction>0)
    {
      if (false==this->CanUnitTraverseTileAtPos(yIdx, sourceTilePos.x))
      {
        return false;
      }
      yIdx += direction;
    }
    return true;
  }
  // source point & destination point are in same row
  if (sourceTilePos.y == destinationTilePos.y)
  {
    direction = (sourceTilePos.x>destinationTilePos.x) ? (-1) : 1;
    int_32 xIdx = static_cast<int_32>(sourceTilePos.x);
    while ((static_cast<int_32>(destinationTilePos.x)-xIdx)*direction>0)
    {
      if (false==this->CanUnitTraverseTileAtPos(sourceTilePos.y, xIdx))
      {
        return false;
      }
      xIdx += direction;
    }
    return true;
  }
  // other conditions
  assert(fabsf(sourcePoint.x-destinationPoint.x)>0.01f ||
         fabsf(sourcePoint.y-destinationPoint.y)>0.01f);
  float kValue = (sourcePoint.y-destinationPoint.y) / (sourcePoint.x-destinationPoint.x);
  std::list<cocos2d::CCPoint> xAxis, yAxis, allPoints;
  // calculate point by xPos firstly 
  direction = (sourceTilePos.x>destinationTilePos.x) ? (-1) : 1;
  for (int_32 xIdx = static_cast<int_32>(sourceTilePos.x);
       (static_cast<int_32>(destinationTilePos.x)-xIdx)*direction>0; )
  {
    float xPos = GetTileCenterPoint(ccp(xIdx, 0)).x + 0.5f*direction*tile_width_;
    float yPos = kValue*(xPos-sourcePoint.x)+sourcePoint.y;
    xAxis.push_back(ccp(xPos, yPos));
    xIdx += direction;
  }
  // then by yPos
  direction = (sourceTilePos.y>destinationTilePos.y) ? (-1) : 1;
  for (int_32 yIdx = static_cast<int_32>(sourceTilePos.y);
       (static_cast<int_32>(destinationTilePos.y)-yIdx)*direction>0; )
  {
    //  y axis in tile coordinate is oppsite to cocos coordinate
    float yPos = GetTileCenterPoint(ccp(0, yIdx)).y - 0.5f*direction*tile_height_;
    float xPos = (yPos - sourcePoint.y + kValue*sourcePoint.x)/kValue;
    yAxis.push_back(ccp(xPos, yPos));
    yIdx += direction;
  }
  // sort points list
  allPoints.push_back(sourcePoint);
  std::list<cocos2d::CCPoint>::iterator xIt = xAxis.begin(), yIt = yAxis.begin();
  while (xIt!=xAxis.end() || yIt!=yAxis.end())
  {
    if (xIt==xAxis.end())
    {
      allPoints.push_back(*yIt);
      ++yIt;
      continue;
    }
    if (yIt==yAxis.end())
    {
      allPoints.push_back(*xIt);
      ++xIt;
      continue;
    }
    if (((*xIt).y-(*yIt).y)*direction>0.0f)
    {
      allPoints.push_back(*xIt);
      ++xIt;      
    }
    else
    {
      allPoints.push_back(*yIt);
      ++yIt;
    }
  }
  allPoints.push_back(destinationPoint);
  assert(allPoints.size()>=2);
  // then check all tiles between each two points
  std::list<cocos2d::CCPoint>::iterator it = allPoints.begin();
  while (allPoints.size()>=2)
  {
    std::list<cocos2d::CCPoint>::iterator nextIt = it;
    ++nextIt;
    cocos2d::CCPoint midPoint = ccp(0.5f*((*it).x+(*nextIt).x), 0.5f*((*it).y+(*nextIt).y));
    if (false==this->CanUnitTraverseTileAtPos(TiledCoordinateFromLocation(midPoint)))
    {
      return false;
    }
    it = allPoints.erase(it);
  }
  return true;
}
  
CityTiledMap::ConstEdgeIterator::ConstEdgeIterator(int_32 vIdx)
  : vertexIdx(vIdx),
    tiledMap(*(CityController::GetInstance().tiled_map()))
{
  cocos2d::CCPoint tiledPos = TiledCoordinateFromIndex(vertexIdx);
  assert(IsTileCoordinateInRange(tiledPos));
  currEdgeList.clear();
  // add four edges if can traverse
  cocos2d::CCPoint neiborVertex[4] = {
    ccp(tiledPos.x-1,tiledPos.y),
    ccp(tiledPos.x,tiledPos.y-1),
    ccp(tiledPos.x+1,tiledPos.y),
    ccp(tiledPos.x,tiledPos.y+1)
  };
  for (int i = 0; i<4; ++i)
  {
    if (IsTileCoordinateInRange(neiborVertex[i].x, neiborVertex[i].y) &&
        CityController::GetInstance().tiled_map()->CanUnitTraverseTileAtPos(neiborVertex[i]))
    {
      int_32 destiIdx = TiledIndex(neiborVertex[i].x, neiborVertex[i].y);
      currEdgeList.push_back(GraphEdge(vIdx, destiIdx));
    }
  }
  curEdge = currEdgeList.begin();
}
  
} // namespace city
} //namespace taomee