//
//  time_sliced_search.h
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//

#ifndef ChainChronicle_time_sliced_search_h
#define ChainChronicle_time_sliced_search_h

#include "game/major_city/pathfinding/path_edge.h"
#include "game/major_city/pathfinding/priority_queue.h"
#include "game/major_city/pathfinding/city_tiled_map.h"

namespace taomee {
namespace city {
  
template <class edge_type, class owner_type>
class TimeSlicedGraphSearch
{  
public:
  TimeSlicedGraphSearch()
  {
  }
  virtual ~TimeSlicedGraphSearch()
  {
  }
  // one cycle called method, will return SearchResult enum
  virtual eSearchResult       cycleOnce() = 0;
  // get the shortest cost to the target
  virtual float               getCostToTarget() const = 0;
  // get shortest path as vertex indexes list
  virtual std::list<int_32>   getPathToTarget(int_32 foundIdx) const = 0;
  // get shortest path as edges list
  virtual std::list<PathEdge> getPathAsPathEdges() const = 0;
};
  
template <class edge_type, class heuristic, class owner_type>
class AStar_TSGraphSearch : public TimeSlicedGraphSearch<edge_type, owner_type>
{
private:
  typedef TimeSlicedGraphSearch<edge_type, owner_type> BaseClass;
  
public:
  AStar_TSGraphSearch(int_32       sourceTileIdx,
                      int_32       targetTileIdx,
                      uint_32      tilesCount)
  : TimeSlicedGraphSearch<edge_type, owner_type>(),
    shortestPathTree(tilesCount),
    searchFrontier(tilesCount),
    gCosts(tilesCount,0.0f),
    fCosts(tilesCount,0.0f),
    sourceIdx(sourceTileIdx),
    targetIdx(targetTileIdx)
  {
    iPQLow = new IndexedPriorityQueueLow<float>(fCosts, tilesCount);
    iPQLow->insert(sourceIdx);
  }
  ~AStar_TSGraphSearch()
  {
    for (typename std::vector<edge_type*>::iterator it = searchFrontier.begin();
         it != searchFrontier.end(); ++it)
    {
      if (*it != NULL)
      {
        delete (*it);
      }
    }
    searchFrontier.clear();
    shortestPathTree.clear();
    delete iPQLow;
  }
  virtual eSearchResult               cycleOnce();
  virtual std::list<int_32>           getPathToTarget(int_32 foundIdx) const;
  virtual std::list<PathEdge>         getPathAsPathEdges() const;
  virtual float                       getCostToTarget() const
  {
    return gCosts[targetIdx];
  }
  
private:
  // indexed into by all the vertexes, value is the cost from source to this vertex
  std::vector<float>              gCosts;
  // indexed into by all the vertexes, Contains the cost from adding m_GCosts[n] to
  // the heuristic cost from n to the target node
  std::vector<float>              fCosts;
  // search result & tag vector
  std::vector<const edge_type*>   shortestPathTree;
  std::vector<edge_type*>         searchFrontier;
  // source & target vertex index : targetIdx can be object typeId, too.
  int_32                          sourceIdx;
  int_32                          targetIdx;
  // priority queue
  IndexedPriorityQueueLow<float>* iPQLow;
};

template <class edge_type, class heuristic, class owner_type>
eSearchResult AStar_TSGraphSearch<edge_type, heuristic, owner_type>::cycleOnce()
{
  //if the PQ is empty the target has not been found
  if (iPQLow->empty())
  {
    return kTargetNotFound;
  }
  
  //get lowest cost node from the queue
  int_32 nextClosestNode = iPQLow->pop();
  
  //put the node on the SPT
  shortestPathTree[nextClosestNode] = searchFrontier[nextClosestNode];
  
  //if the target has been found exit
  if (targetIdx == nextClosestNode)
  {
    return kTargetFound;
  }
  
  //now to test all the edges attached to this node
  CityTiledMap::ConstEdgeIterator ConstEdgeItr(nextClosestNode);
  for (const GraphEdge* pE = ConstEdgeItr.begin(); false == ConstEdgeItr.end();
       pE=ConstEdgeItr.next())
  {
    //calculate the heuristic cost from this node to the target (H)
    double HCost = heuristic::EuclidHeuristics(targetIdx, pE->getTo());
    
    //calculate the 'real' cost to this node from the source (G)
    double GCost = gCosts[nextClosestNode] + pE->getScore();
    
    //if the node has not been added to the frontier, add it and update
    //the G and F costs
    if (searchFrontier[pE->getTo()] == NULL)
    {
      fCosts[pE->getTo()] = GCost + HCost;
      gCosts[pE->getTo()] = GCost;
      
      iPQLow->insert(pE->getTo());
      
      searchFrontier[pE->getTo()] = new GraphEdge(*pE);
    }
    
    //if this node is already on the frontier but the cost to get here
    //is cheaper than has been found previously, update the node
    //costs and frontier accordingly.
    else if ((GCost < gCosts[pE->getTo()]) &&
             (shortestPathTree[pE->getTo()]==NULL))
    {
      fCosts[pE->getTo()] = GCost + HCost;
      gCosts[pE->getTo()] = GCost;
      
      iPQLow->changePriority(pE->getTo());
      
      delete searchFrontier[pE->getTo()];
      searchFrontier[pE->getTo()] = new GraphEdge(*pE);
    }
  }
  
  //there are still nodes to explore
  return kSearchIncomplete;
}

template <class edge_type, class heuristic, class owner_type>
std::list<int_32> AStar_TSGraphSearch<edge_type, heuristic, owner_type>::
  getPathToTarget(int_32 foundIdx) const
{
  std::list<int_32> path;
  
  //just return an empty path if no target or no path found
  if (foundIdx < 0)  return path;
  
  int_32 nd = foundIdx;
  
  path.push_back(nd);
  
  while ((nd != sourceIdx) && (shortestPathTree[nd] != 0))
  {
    nd = shortestPathTree[nd]->getFrom();
    
    path.push_front(nd);
  }
  
  return path;
}

template <class edge_type, class heuristic, class owner_type>
std::list<PathEdge> AStar_TSGraphSearch<edge_type, heuristic, owner_type>::
  getPathAsPathEdges() const
{
  std::list<PathEdge> path;
  
  //just return an empty path if no target or no path found
  if (targetIdx < 0)  return path;
  
  int_32 nd = targetIdx;
  
  while ((nd != sourceIdx) && (shortestPathTree[nd] != 0))
  {
    path.push_front(PathEdge(GetTileCenterPoint(TiledCoordinateFromIndex(shortestPathTree[nd]->getFrom())),
                             GetTileCenterPoint(TiledCoordinateFromIndex(shortestPathTree[nd]->getTo()))));
    
    nd = shortestPathTree[nd]->getFrom();
  }
  return path;
}
  
} // namespace city
} // namespace taomee

#endif /* ChainChronicle_time_sliced_search_h */
