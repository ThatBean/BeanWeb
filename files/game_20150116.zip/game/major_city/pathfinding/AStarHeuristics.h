//
//  AStarHeuristics.h
//  ChainChronicle
//
//  Created by gaven on 2/17/14.
//
//

#ifndef ChainChronicle_AStarHeuristics_h
#define ChainChronicle_AStarHeuristics_h

#include <math.h>

#include "engine/base/basictypes.h"
#include "game/major_city/pathfinding/city_tiled_map.h"

namespace taomee {
namespace city {

class AStarHeuristics
{
public:
  AStarHeuristics(){}
  
  static float EuclidHeuristics(uint_32 sourceIdx, uint_32 destinationIdx)
  {
    cocos2d::CCPoint pos = GetTileCenterPoint(TiledCoordinateFromIndex(destinationIdx));
    cocos2d::CCPoint posAnother = GetTileCenterPoint(TiledCoordinateFromIndex(sourceIdx));
    return sqrt((pos.x-posAnother.x)*(pos.x-posAnother.x) + (pos.y-posAnother.y)*(pos.y-posAnother.y));
  }
};

} // namespace city
} // namespace taomee

#endif // ChainChronicle_AStarHeuristics_h
