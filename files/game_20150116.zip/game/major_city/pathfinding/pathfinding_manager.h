//
//  pathfinding_manager.h
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//

#ifndef ChainChronicle_pathfinding_manager_h
#define ChainChronicle_pathfinding_manager_h

#include "game/major_city/major_city_constants.h"

namespace taomee {
namespace city {
  
template <class path_planner>
class PathManager
{
public:
  PathManager(uint32_t search_cycles_per_update)
    : search_cycles_per_update_(search_cycles_per_update)
  {
  }
  
  void UpdateSearches();
  
  void Register(path_planner* planner);
  void UnRegister(path_planner* planner);
  
  int ActiveSearches() const
  {
    return search_requests_.size();
  }
  
private:
  // all the Path search requests will be classified into sets by the key of
  // (delegate source pos into tileIdex)*(max num of delegate type)+(delegate typeId).
  // Specifically, count(delegateTypeId<=13). So (delegateTileIdex*100+delegateTypeId)
  // can be a suitable key. Path search requests from two delegates with the same
  // type id always using the same search_strategy, and search_strategy is based on
  // the same graph_type
  std::vector<path_planner* > search_requests_;
  
  // Each update step these are divided equally amongst all registered path
  // requests.
  uint_32 search_cycles_per_update_;
};

template <class path_planner>
void PathManager<path_planner>::UpdateSearches()
{
  uint32_t cycles_remaining = search_cycles_per_update_;
  
  typename std::vector<path_planner*>::iterator it = search_requests_.begin();
  while (cycles_remaining-- && !search_requests_.empty())
  {
    int result = (*it)->CycleOnce();
    // path found SUCC or failed should move request
    if (result == kTargetFound)
    {
      it = search_requests_.erase(it);
    }
    else if(result == kTargetNotFound)
    {
      it = search_requests_.erase(it);
    }
    else
    {
      ++it;
    }
    
    if (it == search_requests_.end())
    {
      it = search_requests_.begin();
    }
  }
}

template <class path_planner>
void PathManager<path_planner>::Register(path_planner* planner)
{
  // new search request
  search_requests_.push_back(planner);
}

template <class path_planner>
void PathManager<path_planner>::UnRegister(path_planner* planner)
{
  typename std::vector<path_planner*>::iterator it = search_requests_.begin();
  for (; it!=search_requests_.end(); ++it)
  {
    it = search_requests_.erase(it);
    break;
  }
}
  
} // namespace city
} // namespace taomee

#endif /* ChainChronicle_pathfinding_planner_h */
