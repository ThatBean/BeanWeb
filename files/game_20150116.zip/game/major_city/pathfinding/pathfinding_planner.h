//
//  path_planner.h
//  ChainChronicle
//
//  Created by gaven on 2/13/14.
//
//

#ifndef ChainChronicle_pathfinding_planner_h
#define ChainChronicle_pathfinding_planner_h

#include "engine/base/cocos2d_wrapper.h"
#include "engine/animation/skeleton_animation.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/pathfinding/AStarHeuristics.h"
#include "game/major_city/pathfinding/city_tiled_map.h"
#include "game/major_city/pathfinding/pathfinding_manager.h"
#include "game/major_city/pathfinding/pathfinding_planner_base.h"
#include "game/major_city/pathfinding/path_edge.h"
#include "game/major_city/pathfinding/time_sliced_search.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/major_city/players_data/simple_move_object.h"
#include "game/major_city/players_data/move_data.h"

namespace taomee {
namespace city {

typedef std::list<PathEdge> Path;
  
template <class delegate, class search_strategy>
class PathPlanner : public PathPlannerBase
{
public:
  PathPlanner(delegate* _delegate)
  : delegate_(_delegate),
    search_strategy_(NULL),
    search_finished_flag_(false)
  {
  }
  
  virtual ~PathPlanner()
  {
    this->getReadyForNewSearch();
  }
  
  virtual eSearchResult CycleOnce();
  
  virtual bool requestPathToTarget(const cocos2d::CCPoint& targetPos);
  
  virtual void GetPath(Path* path);
  
public:   // setter & getter 
  cocos2d::CCPoint getVertexPoition(int_32 vIdx) const
  {
    uint_32 columnCnt = CityController::GetInstance().tiled_map()->ColumnCountInCurrentCityMap();
    return GetTileCenterPoint(cocos2d::CCPoint(vIdx/columnCnt, vIdx%columnCnt));
  }
  
  const cocos2d::CCPoint& destination() const
  {
    return destination_;
  }
  void setDestination(const cocos2d::CCPoint& destination)
  {
    destination_ = destination;
  }
  
  search_strategy* get_search_strategy() { return search_strategy_; }
  void set_search_strategy(search_strategy* new_strategy)
  {
    search_strategy_ = new_strategy;
  }
  
  delegate* get_delegate() { return delegate_; }
  
  void createBasicEdgesFromSearchStrategy(Path* path);
  void setSourceDestinationVertexAndSmoothPath(Path* path);
  
private:
  int_32 getClosetVertexToPosition(cocos2d::CCPoint pos) const;
  
  void smoothPathEdgesQuickly(Path* path);
  void smoothPathEdgesPrecisely(Path* path);
  
  void getReadyForNewSearch();
  
private:
  bool search_finished_flag_;
  cocos2d::CCPoint destination_;

private:
  delegate* delegate_;
  search_strategy* search_strategy_;
};


template <class delegate, class search_strategy>
void PathPlanner<delegate, search_strategy>::getReadyForNewSearch()
{
  // unregister current search planner from path search manager only for search unfinished
  // planner, cos the planner would be removed automatically from search list when search finished
  if(false == search_finished_flag_)
  {
    CityController::GetInstance().path_manager()->UnRegister(this);
  }
  CC_SAFE_DELETE(search_strategy_);
}

template <class delegate, class search_strategy>
int_32 PathPlanner<delegate, search_strategy>::
  getClosetVertexToPosition(cocos2d::CCPoint pos) const
{
  if (false==IsPointPositionInRange(pos))
  {
    return kInvalidNodeIndex;
  }
  return TiledIndex(TiledCoordinateFromLocation(pos));
}
  
template <class delegate, class search_strategy>
bool PathPlanner<delegate, search_strategy>::
  requestPathToTarget(const cocos2d::CCPoint& targetPos)
{ 
  if (search_strategy_)
  {
    this->getReadyForNewSearch();
  }
  int_32 sourceVertexIdx = this->getClosetVertexToPosition(delegate_->animation()->getPosition());
  if (sourceVertexIdx==kInvalidNodeIndex)
  {
    return false;
  }
  
  // keep destination first
  destination_ = targetPos;
  // destination_ must in map to make sure reachible
  int_32 destnationVertexIdx = this->getClosetVertexToPosition(destination_);
  if (destnationVertexIdx==kInvalidNodeIndex)
  {
    return false;
  }
  
  // create search strategy
  uint_32 tilesCnt = CityController::GetInstance().tiled_map()->RowCountInCurrentCityMap()*
                     CityController::GetInstance().tiled_map()->ColumnCountInCurrentCityMap();
  typedef AStar_TSGraphSearch<GraphEdge, AStarHeuristics, SimpleMoveObject> AStarSearch;
  search_strategy_ = new AStarSearch(sourceVertexIdx, destnationVertexIdx, tilesCnt);
  // register this planner
  CityController::GetInstance().path_manager()->Register(this);
  return true;
}

template <class delegate, class search_strategy>
eSearchResult PathPlanner<delegate, search_strategy>::CycleOnce()
{
  assert(search_strategy_ &&
         "PathPlanner<CycleOnce> : uninitialized search strategy");
  eSearchResult result = search_strategy_->cycleOnce();
  if (result == kTargetNotFound)
  {
    cocos2d::CCLog("PathPlanner<CycleOnce> : NO PATH FOUND!");
    search_finished_flag_ = true;
    CityController::GetInstance().OnMoveObjectPathNotFound(delegate_);
  }
  else if(result==kTargetFound)
  {
    search_finished_flag_ = true;
    CityController::GetInstance().OnMoveObjectPathFound(delegate_);
  }
  return result;
}

template <class delegate, class search_strategy>
void PathPlanner<delegate, search_strategy>::GetPath(Path* path)
{
  this->createBasicEdgesFromSearchStrategy(path);
  if(path->size())
  {
    path->back().setDestination(destination_);
  }
  this->setSourceDestinationVertexAndSmoothPath(path);
}

template <class delegate, class search_strategy>
void PathPlanner<delegate, search_strategy>::
  createBasicEdgesFromSearchStrategy(Path* path)
{
  assert(search_strategy_ && path);
  
  // clear old path list
  path->clear();
  // copy the path from search algorithms
  (*path) = search_strategy_->getPathAsPathEdges();
}

template <class delegate, class search_strategy>
void PathPlanner<delegate, search_strategy>::
  setSourceDestinationVertexAndSmoothPath(Path* path)
{
  cocos2d::CCPoint agent_pos = delegate_->animation()->getPosition();
  
  // reset the first edge's source position(instead tile center pos by AgentPosition)
  if(path->size()==0)
  {
    int_32 sourceVertexIdx = this->getClosetVertexToPosition(agent_pos);
    path->push_front(PathEdge(agent_pos, this->getVertexPoition(sourceVertexIdx)));
  }
  else
  {
    Path::iterator it = path->begin();
    it->setSource(agent_pos);
  }
  
  path->push_back(PathEdge(path->back().destination(), destination_));
  
  // path smooth
  if (path->size()>=CityController::GetInstance().tiled_map()->RowCountInCurrentCityMap())
  {
    this->smoothPathEdgesQuickly(path);
  }
  else
  {
    this->smoothPathEdgesPrecisely(path);
  }
}

template <class delegate, class search_strategy>
void PathPlanner<delegate, search_strategy>::smoothPathEdgesQuickly(Path* path)
{
  Path::iterator ePioneer(path->begin()),eTraining(path->begin());
  ++eTraining;
  while (eTraining!=path->end()) {
    bool canTraverse = CityController::GetInstance().tiled_map()->
                CanWalkableBetween(ePioneer->source(),eTraining->destination());
    if (canTraverse)
    {
      ePioneer->setDestination(eTraining->destination());
      eTraining = path->erase(eTraining);
    }
    else
    {
      ePioneer = eTraining;
      eTraining++;
    }
  }
}

template <class delegate, class search_strategy>
void PathPlanner<delegate, search_strategy>::smoothPathEdgesPrecisely(Path* path)
{
  Path::iterator ePioneer(path->begin()),eTraining;
  while (ePioneer!=path->end())
  {
    eTraining = ePioneer;
    ++eTraining;
    while (eTraining!=path->end())
    {
      bool canTraverse = CityController::GetInstance().tiled_map()->
                CanWalkableBetween(ePioneer->source(),eTraining->destination());
      if (canTraverse)
      {
        ePioneer->setDestination(eTraining->destination());
        eTraining = path->erase(++ePioneer, ++eTraining);
        ePioneer = eTraining;
        ePioneer--;
      }
      else
      {
        ++eTraining;
      }
    }
    ++ePioneer;
  }
}
  
} // namespace city
} // namespace taomee

#endif /* ChainChronicle_pathfinding_planner_h */
