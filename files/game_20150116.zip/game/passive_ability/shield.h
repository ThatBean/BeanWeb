
//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  shield.h
//        Author:  victang
//       Version:  1
//          Date:  2014-10-22
//          Time:  10:26
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//      victang     2014-10-22      1         create
//////////////////////////////////////////////////////////////

#ifndef TAOMEE_ABILITY_SHIELD_H_
#define TAOMEE_ABILITY_SHIELD_H_

#include "engine/base/basictypes.h"

namespace taomee {
namespace ability {

enum
{
	Shield_Infinite_Count = -1,
	Shield_Infinite_Time = -1,
	Shield_Infinite_Value = (uint_32)(-1),
};

enum eShieldType
{
	kShieldType_Unknown = -1,
	// �ֵ����Եз��ļ���
	kShieldType_WithStand_Skll = 0,
	// �ֵ������˺����ݻ���ֵ
	kShieldType_WithStand_PhysicsDamage = 1,
	// �ֵ�ħ���˺����ݻ���ֵ
	kShieldType_WithStand_MagicDamage = 2,
	// �����˺�&�ָ�hp
	kShieldType_WithStand_Damage_And_Heal = 3,


	kShieldType_Max,
};

class Shield
{
public:
	Shield();
	~Shield();

	void setType( eShieldType type )
	{
		m_shield_type = type;
	}

	void setCount(int count)
	{
		m_count = count;
	}

	void setTime(float time)
	{
		m_time = time;
	}

	void setValue(int_32 val)
	{
		m_value = val;
	}

	int getAuraId()
	{
		return m_aura_id;
	}
	void setAuraId( int aura_id)
	{
		m_aura_id = aura_id;
	}

	void setMoveObjId(uint_32 moveObjId)
	{
		m_move_obj_id = moveObjId;
	}

	bool is_withstand_skill_shield()
	{
		return m_shield_type == kShieldType_WithStand_Skll;
	}

	bool is_withstand_physics_damage_shield()
	{
		return m_shield_type == kShieldType_WithStand_PhysicsDamage;
	}

	bool is_withstand_magic_damage_shield()
	{
		return m_shield_type == kShieldType_WithStand_MagicDamage;
	}

	bool is_withstand_damage_and_heal_shield()
	{
		return m_shield_type == kShieldType_WithStand_Damage_And_Heal;
	}

	bool Update(float delta);

	void subCount();
	int_32 subValue(int_32& val);
	
	bool is_valid()
	{
		return m_valid;
	}

	void set_invalided();
protected:
	int m_aura_id;
	uint_32 m_move_obj_id;

	eShieldType m_shield_type;
	int m_count;
	float m_time;
	int_32 m_value;

	bool m_valid;
};


}
}

#endif//TAOMEE_ABILITY_SHIELD_H_