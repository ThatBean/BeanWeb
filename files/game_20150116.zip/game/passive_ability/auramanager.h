//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: auramanager.h
//        Author: vic.tang 
//       Version:
//          Date: 2014.11.05
//          Time: 18:20:00
//   Description: create
//
// History:
//      <author>    <time>      <version>   <descript>
//      vic.tang     18:20:00     1.0        create
//
//////////////////////////////////////////////////////////////

#ifndef _TAOMEE_ABILITY_AURAMANAGER_H_
#define _TAOMEE_ABILITY_AURAMANAGER_H_

#include "game/army/unit/move_object.h"
#include "game/data_table/aura_data_table.h"
#include "game/passive_ability/aura.h"
#include "game/skill/skill_constants.h"

namespace taomee
{
namespace ability
{

class AuraManager
{
public:
	AuraManager();
	~AuraManager();

	bool Update(float delta);
public:
	bool AddAura(army::MoveObject* owner, int aura_id, uint_32 caster_id, int_32 skill_id = MW_INVALID_ID);
	bool AddAura(uint_32 owner_id, int aura_id, uint_32 caster_id, int_32 skill_id = MW_INVALID_ID);
	void AddAuras(uint_32 move_obj_id, const std::string& auras, uint_32 caster_id, int_32 skill_id = MW_INVALID_ID);
	void AddAuras(const std::vector<uint_32>& move_obj_id_list, const std::string& auras, uint_32 caster_id, int_32 skill_id = MW_INVALID_ID);
	void AddAurasFromSkill(army::MoveObject* master_obj, army::MoveObject* target_obj, int_32 skill_id);

	bool RemoveAura( army::MoveObject* owner, int aura_id );
	bool RemoveAura( army::MoveObject* owner, eAuraStatusFlags auraStatus );
	bool RemoveAura( uint_32 owner_id, int aura_id );
	void RemoveAuras(uint_32 move_obj_id, const std::string& auras);
	void RemoveAuras(const std::vector<uint_32>& move_obj_id_list, const std::string& auras);
	bool RemoveAllDecreaseAura( army::MoveObject* owner );

	Aura* FindAura( uint_32 move_obj_id, int aura_id);

	void RemoveAllAuraOnMoveObject(army::MoveObject* owner);

	void RemoveAllAura();

	void RemoveShield(uint_32 owner_id, int aura_id);


private:
	Aura* createAura();
	void destroyAura(Aura* obj, bool clearup = true);
private:

	std::list<Aura*> aura_list_;
	std::list<Aura*> aura_del_list_;

	std::queue<Aura*> idle_loop_;
};

}//ability
}//taomee
#endif