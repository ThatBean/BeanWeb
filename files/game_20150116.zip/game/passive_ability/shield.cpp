//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  shield.c
//        Author:  victang
//       Version:  1
//          Date:  2014-10-22
//          Time:  10:26
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//      victang     2014-10-22      1         create
//////////////////////////////////////////////////////////////

#include "shield.h"
#include "cocos2d.h"
#include "game/data_table/aura_data_table.h"

namespace taomee {
namespace ability {

Shield::Shield()
	: m_shield_type( kShieldType_Unknown)
	, m_count(Shield_Infinite_Count)
	, m_time(Shield_Infinite_Time)
	, m_value(Shield_Infinite_Value)
	, m_aura_id(Invalid_Aura_ID)
	, m_move_obj_id(-1)
	, m_valid(true)
{
}

Shield::~Shield()
{

}

void Shield::subCount()
{
	if ( !m_valid )
	{
		CCAssert( m_valid, "m_valid = false");
		return;
	}

	if ( m_count != Shield_Infinite_Count)
	{
		--m_count;

		if ( m_count <= 0)
		{
			set_invalided();
		}
	}
}

int_32 Shield::subValue(int_32& val)
{
	int_32 subVal = 0;
	if ( val <= 0)
	{
		CCAssert( !m_valid, "val = 0");
		return subVal;
	}
	
	if ( !m_valid )
	{
		CCAssert( !m_valid, "m_valid = false");
		return subVal;
	}
	
	if ( m_value <= 0 )
	{
		CCAssert( m_value > 0, "m_value <= 0");
		return subVal;
	}

	subCount();
	
	m_value -= val;
	if ( m_value > 0)
	{
		subVal = val;
		if ( m_shield_type == kShieldType_WithStand_Damage_And_Heal)
		{
			val = -val;
		}
		else
		{
			val = 0;
		}
	}
	else
	{
		subVal = val + m_value;
		if ( m_shield_type == kShieldType_WithStand_Damage_And_Heal)
		{
			val = -subVal;
		}
		else
		{
			val = abs(m_value);
		}
		set_invalided();
	}

	return subVal;
}

void Shield::set_invalided()
{
	m_valid = false;
}

bool Shield::Update(float delta)
{
	if ( !m_valid)
	{
		return false;
	}


	if ( m_time > 0.0f )
	{
		m_time -= delta;
		if ( m_time <= 0.0f)
		{
			set_invalided();
		}
	}
	


	return true;
}

}
}