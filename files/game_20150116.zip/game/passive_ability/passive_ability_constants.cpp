//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  passive_ability_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-11-8
//          Time:  11:15
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-11-8        1         create
//////////////////////////////////////////////////////////////

#include "game/passive_ability/passive_ability_constants.h"

#include <math.h>

namespace taomee {
namespace ability {
  
bool CompareBySymbol(float leftParam, eCompareType symbol, float rightParam)
{
  switch (symbol)
  {
    case kCompareLessThan:
      return (leftParam<rightParam);
    case kCompareNoMoreThan:
      return (leftParam<=rightParam);
    case kCompareEqualTo:
      return fabsf(leftParam-rightParam)<0.00001;
    case kCompareNoLessThan:
      return (leftParam>=rightParam);
    case kCompareMoreThan:
      return (leftParam>rightParam);
    case kCompareBitAnd:
      return ((static_cast<uint_32>(leftParam)) & (static_cast<uint_32>(rightParam)));
    default:
      break;
  }
}
  
uint_32 GetStatusUniqueId(uint_16 buffId, uint_32 unitId)
{
  return ((buffId<<16) + unitId);
}
  
eAbilityCreation GetCreationByType(int type)
{
  switch (type)
  {
      // default activate types
    case kAbilityTypeFitableTarget:  // 5
    case kAbilityTypeFitableGender:  // 6
    case kAbilityTypeBattleStart:  // 8
    case kAbilityTypeThroughAll: // 9
    case kAbilityTypeStatusImmune:  // 12
    case kAbilityTypeFireImmune:  // 13
    case kAbilityTypeIceImmune:  // 14
    case kAbilityTypeHealByTime:  // 17
    case kAbilityTypeInspireFriends:  // 20
    case kAbilityTypeShield:  // 25
    case kAbilityTypeExtraSkillPoint:  // 26
    case kAbilityTypeSkillEnhanced:  // 29
    case kAbilityTypeTargetStatusSnipe:  // 32
    case kAbilityTypeCriticalEnhanced:  // 33
    case kAbilityTypeMeleeAttackEnhanced: // 37
    case kAbilityTypeStatusHoldup:  // 39
    case kAbilityTypeRepelHoldup:  // 40
    case kAbilityTypePropertyBoost: // 41
    case kAbilityTypeExtraGoldReward: // 100
    case kAbilityTypeExtraItemsReward: // 101
    case kAbilityTypeExtraXpReward: // 102
    case kAbilityTypeExtraApBackReward: // 103
      return kAbilityCreationDefault;
      
    case kAbilityTypeFitableMap: // 7
    case kAbilityTypeSameAbility: // 35
      return kAbilityCreationCheckOnce;
      
      // ability types which check conditions in each update
    case kAbilityTypeLessHp:  // 1
    case kAbilityTypeFullHp:  // 2
    case kAbilityTypeSelfStatusEnhanced: // 34
    case kAbilityTypeAmpleHp:  // 36
    case kAbilityTypeInvisbility:  // 42
      return kAbilityCreationUpdate;
      
      // ability types which trigger out by events
    case kAbilityTypeBossWave:  // 3
    case kAbilityTypeNewWave:  // 4
    case kAbilityTypeNewWaveSelfHeal:  // 16
    case kAbilityTypeKillOne: // 22
    case kAbilityTypeCounter: // 23
    case kAbilityTypeComradesKilled: // 24
    case kAbilityTypeExtraSkillProbability: // 27
    case kAbilityTypeExtraSkillByKillOne: // 28
    case kAbilityTypeNewWaveHealAll:  // 30
    case kAbilityTypeNewWaveHealWeakest: // 31
      return kAbilityCreationTriggerOut;
      
      // create extra data
    case kAbilityTypeCriticalEffect: // 10
    case kAbilityTypeHitEffect: // 11
    case kAbilityTypeAdvancedHeal: // 19
    case kAbilityTypeDamageHealSelf: // 21
    case kAbilityTypeSkillExtraStatus: // 38
      return kAbilityCreationExtraData;
      
    case kAbilityTypeBackstageInspire: //18
      return kAbilityCreationTriggerOff;
      
    default:
      return kAbilityCreationUnkown;
  }
}
  
bool IsStatusBindingWithAbilityInstanceType(eAbilityType type)
{
  return (type==kAbilityTypeInspireFriends || type==kAbilityTypeSameAbility ||
          type==kAbilityTypeBackstageInspire);
}
  
} // namespace ability
} // namespace taomee