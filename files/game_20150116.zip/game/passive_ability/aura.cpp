//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: aura.cpp
//        Author: vic.tang 
//       Version:
//          Date: 2014.11.05
//          Time: 18:20:00
//   Description: create
//
// History:
//      <author>    <time>      <version>   <descript>
//      vic.tang     18:20:00     1.0        create
//
//////////////////////////////////////////////////////////////

#include "aura.h"
#include "engine/base/utils_string.h"
#include "game/battle/battle_hub.h"
#include "game/game_manager/data_manager.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_data.h"
#include "game/passive_ability/auramanager.h"
#include "game/army/unit_hub/troops_hub.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/event_system/event_manager.h"
#include "engine/base/random_helper.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/event/event_battle/event_battle_obj.h"

namespace taomee
{
namespace ability
{

#define Invalid_Op_Index	-1

#define AuraProcessStage_Activate	0
#define AuraProcessStage_Updata		1
#define AuraProcessStage_Remove		2

#define AuraToLuaEventType_Begin 0
#define AuraToLuaEventType_PeriodicTrigger 1
#define AuraToLuaEventType_End 2

#define Aura_Effect_Stage_Start	1
#define Aura_Effect_Stage_Last	2
#define Aura_Effect_Stage_End	3

AuraAnimationEventListener::AuraAnimationEventListener(Aura* owner)
	: m_owner_(owner)
{
	CCAssert( m_owner_ != NULL , "AuraAnimationEventListener::m_owner_ != NULL");
}

AuraAnimationEventListener::~AuraAnimationEventListener()
{
	m_owner_ = NULL;
}

void AuraAnimationEventListener::OnMovementEvent(cocos2d::extension::CCArmature* armature,
	cocos2d::extension::MovementEventType event_type,const char* movement_name)
{
	if ( m_owner_)
	{
		m_owner_->notifyMovementEvent(armature, event_type, movement_name);
	}
}

AuraProcessFun AuraProcessFunHander[kModifierType_MaxCount] = 
{
	&Aura::ProcessNone,					//kAuraType_None = 0,
	&Aura::ProcessAddedPropertyDamage,	//kAuraType_AddedPropertyDamage = 1,
	&Aura::ProcessStunned,				//kAuraType_Stunned = 2,
	&Aura::ProcessFreeze,				//kAuraType_Freeze = 3,
	&Aura::ProcessBlinded,				//kAuraType_Blinded = 4,
	&Aura::ProcessSilence,				//kAuraType_Silence = 5,
	&Aura::ProcessInvisbility,			//kAuraType_Invisbility = 6,
	&Aura::ProcessInvincible,			//kAuraType_Invincible = 7,
	&Aura::ProcessImmune,				//kAuraType_Immune = 8,
	&Aura::ProcessModHealth,			//kAuraType_ModHealth = 9,
	&Aura::ProcessRemove,		//kAuraType_ModHealMultiple = 10,
	&Aura::ProcessModByHealMultiple,	//kAuraType_ModByHealMultiple = 11,
	&Aura::ProcessModAttack,			//kAuraType_ModAttack = 12,
	&Aura::ProcessModDamage,			//kAuraType_ModDamage = 13,	//eDamageType
	&Aura::ProcessModMoveSpeed,			//kAuraType_ModMoveSpeed = 14,
	&Aura::ProcessModAttackSpeed,		//kAuraType_ModAttackSpeed = 15,
	&Aura::ProcessModDefence,			//kAuraType_ModDefence = 16,	//eDamageType
	&Aura::ProcessRangeAttackMany,		//kAuraType_RangeAttackMany = 17,
	&Aura::ProcessModHematophagia,		//kAuraType_ModHematophagia = 18,
	&Aura::ProcessModCriticalProbability,	//kAuraType_ModCriticalProbability = 19,
	&Aura::ProcessModByDamage,			//kAuraType_ModByDamage = 20,	//eDamageType
	&Aura::ProcessModThorns,			//kAuraType_ModThorns = 21,//eDamageType
	&Aura::ProcessModStatusDamage,		//kModifierType_ModStatusDamage = 22,
	&Aura::ProcessBattleExtraReward,	//kAuraType_BattleExtraReward = 23,
	&Aura::ProcessAbilityMonitorHP,			//kAuraType_Ability_MonitorHP = 24,
	&Aura::ProcessAbilityMonitorHit,	// kAuraType_Ability_MonitorNormalHit = 25,
	&Aura::ProcessAbilityMonitorHit,	//kAuraType_Ability_MonitorCriticalHit = 26
	&Aura::ProcessAbilityMonitorHit,	//kAuraType_Ability_MonitorSkillHit = 27
	&Aura::ProcessAbilityTeamAuras,		//kModifierType_Ability_TeamAuras = 28,
	&Aura::ProcessPetrifaction,			//kModifierType_Petrifaction = 29
	&Aura::ProcessAbilityMonitorDead,	//kModifierType_Ability_MonitorDead = 30,
	&Aura::ProcessAbilitySlay,			//kModifierType_Ability_Slay = 31,
	&Aura::ProcessAbilityBattleSceneType,	//kModifierType_Ability_BattleSceneType = 32
	&Aura::ProcessAbilityTriggerEffect,	//kModifierType_Ability_TriggerEffect = 33
	&Aura::ProcessAbilityAppearanceSkill,	//kModifierType_Ability_AppearanceSkill = 34
	&Aura::ProcessIntertwine,				//kModifierType_Intertwine = 35,
	&Aura::ProcessAttachShield,				//kModifierType_AttachShield = 36,
	&Aura::ProcessAbilityMonitorByHit,			//kModifierType_Ability_MonitorByNormalHit = 37,
	&Aura::ProcessAbilityMonitorByHit,			//kModifierType_Ability_MonitorByCriticalHit = 38,
	&Aura::ProcessAbilityMonitorByHit,			//kModifierType_Ability_MonitorBySkillHit = 39,
	&Aura::ProcessModHealthLimit,			//kModifierType_ModHealthLimit = 40,
	&Aura::ProcessModGuardRadius,			//kModifierType_ModGuardRadius = 41,
	&Aura::ProcessModEnergy,			//kModifierType_ModEnergy = 42,
	&Aura::ProcessModSputtering,		//kModifierType_Sputtering = 43,
	&Aura::ProcessEnchantment,		//kModifierType_Enchantment = 44,
	&Aura::ProcessFear,					//kModifierType_Fear = 45,
	&Aura::ProcessResurgence,		//kModifierType_Resurgence = 46,
	&Aura::ProcessWitchcraft,		//kModifierType_Witchcraft = 47,
	&Aura::ProcessModHitRate,		//kModifierType_ModHitRate = 48,
	&Aura::ProcessModDodge,		//kModifierType_ModDodge = 49,
};


Aura::Aura()
	: m_owner(NULL)
	, m_aura_data(NULL)
	//, m_cdtion_adpter(NULL)
	, m_mod_op(NULL)
	, m_mod_op_index(Invalid_Op_Index)
	, m_over(false)
	, m_stack_times(0)
	, m_exist_time(0)
	, m_idle_time(0)
	, m_curr_exist_time(0)
	, m_aura_status_flag(kAuraStatusFlag_None)
	, m_effect_stage(Aura_Effect_Stage_Start)
	, m_skill_id(MW_INVALID_ID)
	, m_delta(0.0f)
{
	m_anim_listener = new AuraAnimationEventListener(this);
}

Aura::~Aura()
{
	m_anim_listener->m_owner_ = NULL;
	CC_SAFE_RELEASE(m_anim_listener);
	SAFE_DEL(m_aura_data);
}

void Aura::Initialize(army::MoveObject* owner, const AuraData* aura_data, uint_32 caster_id, int_32 skill_id)
{
	if ( m_aura_data == NULL )
	{
		m_aura_data = new AuraData();
	}
	m_aura_data->InitWithData(aura_data);
	m_owner = owner;
	m_skill_id = skill_id;
	m_exist_time = m_aura_data->get_time();
	m_aura_status_flag = static_cast<eAuraStatusFlags>(String2Int(m_aura_data->get_aura_status()));

	initAuraEventHandle();

	initOwnerEntity();

	initCasterEntity(caster_id);

	this->ActivateStatus();
}

void Aura::Initialize(army::MoveObject* owner, int aura_id, uint_32 caster_id, int_32 skill_id)
{
	const AuraData* auraData = DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id);
	this->Initialize(owner, auraData, caster_id, skill_id);
}

uint_32 Aura::owner_obj_id()
{
	return m_owner->move_object_id();
}

void Aura::Shutdown()
{
	if ( m_aura_data)
	{
		m_aura_data->ResetData();
	}
	m_owner = NULL;
	m_mod_op = NULL;
	m_mod_op_index = Invalid_Op_Index;
	m_over = false;
	m_stack_times = 0;
	m_exist_time = 0;
	m_idle_time = 0;
	m_curr_exist_time = 0;
	m_aura_status_flag = kAuraStatusFlag_None;
	m_effect_stage = Aura_Effect_Stage_Start;
	m_effect_stage_2_loop = true;
	m_skill_id = MW_INVALID_ID;
	m_delta = 0.0f;

	memset(&m_mod_value, 0, sizeof(float)*Modifier_Max_Count);

	m_owner_entity.reset();
	m_caster_entity.reset();

	UnSubscribeAllAuraEventHandle();

	m_filtered_mod_list.clear();
}

bool Aura::is_control_aura()
{
	if ( m_aura_status_flag == kAuraStatusFlag_Stunned || 
		 m_aura_status_flag == kAuraStatusFlag_Freeze ||
		 m_aura_status_flag == kAuraStatusFlag_Petrifaction ||
		 m_aura_status_flag == kAuraStatusFlag_Intertwine )
	{
		return true;
	}
	
	return false;
}

void Aura::FilterModifier()
{
	if ( is_control_aura() )
	{
		if ( m_owner->check_battle_status_flag(battle::kDamageStatusImmune) && m_owner->check_immune_status_flag(battle::kImmuneTypeControl))
		{
			int count = m_aura_data->get_mod_count();
			for ( int i = 0; i < count; ++i)
			{
				ModifierData* mod = m_aura_data->getModifier(i);
				if ( mod->m_type == kModifierType_Stunned || mod->m_type  == kModifierType_Freeze ||
					 mod->m_type == kModifierType_Petrifaction)
				{
					m_filtered_mod_list[m_stack_times] = i;
					m_owner->PushDamageLabel( 0, battle::eDamageLabelType_ImmuneControl, true);
				}
			}
		}
	}

	if ( m_aura_status_flag == kAuraStatusFlag_Blinded )
	{
		army::eCareerType careerType = m_owner->GetCareerType();
		if ( careerType == army::kCareerTypeWarrior || careerType == army::kCareerTypeKnight)
		{
			int count = m_aura_data->get_mod_count();
			for ( int i = 0; i < count; ++i)
			{
				ModifierData* mod = m_aura_data->getModifier(i);
				if ( mod->m_type == kModifierType_Blinded )
				{
					m_filtered_mod_list[m_stack_times] = i;
				}
			}
		}
	}

	if ( m_stack_times == 1 )
	{
		int count = m_aura_data->get_mod_count();
		if ( count == m_filtered_mod_list.size() )
		{
			// ȫ�������ߵ���
			over();
		}
	}
}

void Aura::EmitEventToLua(int evtType)
{
	LuaTinkerManager::GetInstance().CallLuaFunc<int>(
		"script/framework/CPlusToLuaInterface.lua",
		"BattleAuraEvent", 
		evtType, m_aura_data->get_id(), m_owner->move_object_id() , m_caster_entity.m_move_obj_id );
}

void Aura::over()
{
	m_over = true;
}

bool Aura::isFiltered(int index)
{
	if (m_filtered_mod_list.size() == 0)
	{
		return false;
	}

	std::map<int_8, int_8>::iterator iter = m_filtered_mod_list.find(m_stack_times);
	if ( iter != m_filtered_mod_list.end())
	{
		if ( iter->second == index )
		{
			return true;
		}
	}
	
	return false;
}

void Aura::setInternalVariate(const std::string& key, const std::string& val)
{
	assert( !key.empty() && !val.empty() );
	m_internal_variate[key] = val;
}
const std::string& Aura::getStringVlaue(const std::string& key)
{
	return m_internal_variate[key];
}

bool Aura::getBoolVlaue(const std::string& key)
{
	return String2Bool(m_internal_variate[key]);
}
int Aura::getIntVlaue(const std::string& key)
{
	return String2Int(m_internal_variate[key]);
}
float Aura::getFloatVlaue(const std::string& key)
{
	return String2Float(m_internal_variate[key]);
}

void Aura::initAuraEventHandle()
{
	if ( kInterruptType_SkillOver == m_aura_data->get_interrupt_type() && m_skill_id != MW_INVALID_ID )
	{
		SkillBase* skillData= DataManager::GetInstance().GetSkillDataTable()->GetSkill(m_skill_id);
		if ( skillData && skillData->GetSkillType())
		{
			SubscribeAuraEventHandle( Invalid_Op_Index, ReleaseSkillOverEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessReleaseSkillOverEvent));
		}
	}

	if ( m_aura_status_flag == kAuraStatusFlag_Freeze )
	{
		SubscribeAuraEventHandle( Invalid_Op_Index, ByHitEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessByHitEvent));
	}
}

void Aura::initOwnerEntity()
{
	m_owner_entity.reset();
	m_owner_entity.m_move_obj_id = m_owner->move_object_id();
	m_owner_entity.m_curr_hp = m_owner->currnet_health_point();
	m_owner_entity.m_total_hp = m_owner->total_health_point();
	m_owner_entity.m_curr_loss_hp = m_owner->total_health_point() - m_owner->currnet_health_point();
	m_owner_entity.m_phy_attack = m_owner->physics_attack();
	m_owner_entity.m_mag_attack = m_owner->magic_attack();
	m_owner_entity.m_physics_def = m_owner->physics_defense();
	m_owner_entity.m_magic_def = m_owner->magic_defense();
}

void Aura::initCasterEntity( uint_32 caster_id)
{
	m_caster_entity.reset();

 	if ( caster_id == m_owner->move_object_id() )
 	{
 		memcpy(&m_caster_entity, &m_owner_entity, sizeof(AuraMoveObjectEntity));
 	}
 	else
 	{
		if ( caster_id != army::kUnexistTargetId )
		{
			army::MoveObject* caster = battle::BattleController::GetInstance().GetObjectById(caster_id);
			if ( caster )
			{
				m_caster_entity.m_move_obj_id = caster_id;
				m_caster_entity.m_curr_hp = caster->currnet_health_point();
				m_caster_entity.m_total_hp = caster->total_health_point();
				m_caster_entity.m_curr_loss_hp = caster->total_health_point() - caster->currnet_health_point();
				m_caster_entity.m_phy_attack = caster->physics_attack();
				m_caster_entity.m_mag_attack = caster->magic_attack();
				m_caster_entity.m_physics_def = caster->physics_defense();
				m_caster_entity.m_magic_def = caster->magic_defense();
			}
		}
	}
}

bool Aura::isEqualModifierType( int type )
{
	int count = m_aura_data->get_mod_count();
	for ( int i = 0; i < count; ++i)
	{
		const ModifierData* mod = m_aura_data->getModifier(i);
		if ( mod->m_type == type)
		{
			return true;
		}
	}

	return false;
}

bool Aura::isEqualAuraStatus( int type )
{
	if ( type == 0)
	{
		return false;
	}

	int status = String2Int( m_aura_data->get_aura_status());
	return (status == type);
}

bool Aura::IsGains()
{
	return m_aura_data->get_gains();
}

void Aura::aura_replace()
{
	m_curr_exist_time = 0.0f;
	m_over = false;

	bool isPushDamageLable = true;

	std::map<int_8, int_8>::iterator iter = m_filtered_mod_list.begin();
	std::map<int_8, int_8>::iterator iterNext;
	while ( iter != m_filtered_mod_list.end() )
	{
		iterNext = iter;
		++iterNext;
		{
			m_mod_op = m_aura_data->getModifier(iter->second);
			if ( m_mod_op != NULL)
			{
				if ( is_control_aura() )
				{
					if ( m_mod_op->m_type == kModifierType_Stunned || m_mod_op->m_type  == kModifierType_Freeze )
					{
						if ( !m_owner->check_battle_status_flag(battle::kDamageStatusImmune) && !m_owner->check_immune_status_flag(battle::kImmuneTypeControl))
						{
							m_filtered_mod_list.erase(iter);

							isPushDamageLable = false;
							ChangeStauts(true);
							(*this.*AuraProcessFunHander[m_mod_op->m_type])(AuraProcessStage_Activate);
							if ( !m_aura_data->get_effect().empty() )
							{
								m_owner->ShowStatusEffectOnWithName(m_aura_data->get_effect(), m_aura_data->get_effect_pos());
							}
							else
							{
								this->ShowAuraEffectByArmature(Aura_Effect_Stage_Start, true);
							}
						}
					}
				}
				else
				{

				}
			}
		}
		iter = iterNext;
	}

	if ( isPushDamageLable )
	{
		battle::eDamageStatus damage_status = AuraStatus_To_DamageStatus( m_aura_status_flag);
		m_owner->PushDamageLabel(0, battle::DamageLabel::toDamageLabelType(damage_status), true);

		if ( !m_aura_data->get_effect().empty() )
		{
			m_owner->ReplaceOneStatusEffectNewOneWithName(m_aura_data->get_effect(), m_aura_data->get_effect_pos());
		}
		else
		{
			this->ShowAuraEffectByArmature(Aura_Effect_Stage_Start, true);
		}
	}
}

void Aura::aura_overlay_add()
{
	m_curr_exist_time = 0.0f;
	this->ActivateStatus();
}

void Aura::aura_overlay_sub()
{
	m_curr_exist_time = 0.0f;
	this->RemoveStatus();
}

bool Aura::ConditionCompare(float leftParam, eConditionCompareType condition, float rightParam)
{
	switch (condition)
	{
	case kConditionCompareType_Less:
		return (leftParam<rightParam);
	case kConditionCompareType_NoMore:
		return (leftParam<=rightParam);
	case kConditionCompareType_EqualTo:
		return fabsf(leftParam-rightParam)<0.00001;
	case kConditionCompareType_NoLess:
		return (leftParam>=rightParam);
	case kConditionCompareType_More:
		return (leftParam>rightParam);
	default:
		return false;
		break;
	}
}

battle::eDamageStatus Aura::AuraStatus_To_DamageStatus( eAuraStatusFlags asf )
{
	switch( asf )
	{
	case kAuraStatusFlag_Stunned:// ����
		return battle::kDamageStunned;
		break;
	case kAuraStatusFlag_Freeze: // ����
		return battle::kDamageFreeze;
		break;
	case kAuraStatusFlag_Blinded:// ��ä
		return battle::kDamageBlinded;
		break;
	case kAuraStatusFlag_Silence:// ��Ĭ/��ħ
		return battle::kDamageSilence;
		break;
	case kAuraStatusFlag_Invisbility:// ����
		return battle::kDamageInvisbility;
		break;
	case kAuraStatusFlag_Invincible://�޵�
		return battle::kDamageInvincible;
		break;
	case kAuraStatusFlag_Immune:// ����״̬
		return battle::kDamageStatusImmune;
		break;
	case kAuraStatusFlag_Poison:// �ж�
		return battle::kDamagePoison;
		break;
	case kAuraStatusFlag_SeriousInjury:// ����/����
		return battle::kDamageSeriousInjury;
		break;
// 	case kAuraStatusFlag_Weakness:// ����
// 		return battle::kDamageNone;
// 		break;
 	case kAuraStatusFlag_SlowdownMoveSpeed://������
 		return battle::kDamageLoweMoveSpeed;
 		break;
// 	case kAuraStatusFlag_Musth:// ��
// 		return battle::kDamageNone;
// 		break;
// 	case kAuraStatusFlag_Weathering:// �绯����
// 		return battle::kDamageNone;
// 		break;
// 	case kAuraStatusFlag_Frostbite:// ��������
// 		return battle::kDamageNone;
// 		break;
// 	case kAuraStatusFlag_Flammable:// ��ȼ����
// 		return battle::kDamageNone;
// 		break;
	case kAuraStatusFlag_Piercing:// ����
		return battle::kDamageRangeAttackMany;
		break;
	case kAuraStatusFlag_Petrifaction:// ʯ��
		return battle::kDamagePetrifaction;
		break;
	case kAuraStatusFlag_Slay:// նɱ
		return battle::kDamageSlay;
		break;
	case kAuraStatusFlag_SlowdownAttackSpeed://������
		return battle::kDamageLowerAttackSpeed;
		break;
	case kAuraStatusFlag_Intertwine:
		return battle::kDamageIntertwine;
		break;
	case kAuraStatusFlag_Enchantment:
		return battle::kDamageEnchantment;
		break;
	case kAuraStatusFlag_Fear:
		return battle::kDamageFear;
		break;
	case kAuraStatusFlag_Witchcraft:
		return battle::kDamageWitchcraft;
		break;
	}

	return battle::kDamageNone;
}

void Aura::ChangeStauts(bool activate)
{
	if ( m_aura_status_flag == kAuraStatusFlag_None )
	{
		return;
	}

	std::map<int_8, int_8>::iterator iter = m_filtered_mod_list.find(m_stack_times);
	if ( iter != m_filtered_mod_list.end())
	{
		//�����˺�aura_status_flagĿǰ��kAuraStatusFlag_None����
		return;
	}

	battle::eDamageStatus damage_status = AuraStatus_To_DamageStatus( m_aura_status_flag);

	if ( damage_status == battle::kDamageNone)
	{
		return;
	}

	if ( activate)
	{
		m_owner->retain_battle_status_flag( damage_status );
	}
	else
	{
		m_owner->release_battle_status_flag( damage_status );
	}
}

void Aura::ActivateStatus()
{
	m_stack_times++;

	FilterModifier();

	ChangeStauts(true);

	for ( int i = 0; i < m_aura_data->get_mod_count(); ++i)
	{
		if ( isFiltered(i))
			continue;

		m_mod_op_index = i;
		m_mod_op = m_aura_data->getModifier(i);
		(*this.*AuraProcessFunHander[m_mod_op->m_type])(AuraProcessStage_Activate);
	}

	std::map<int_8, int_8>::iterator iter = m_filtered_mod_list.find(m_stack_times);
	if ( iter == m_filtered_mod_list.end())
	{
		if ( !m_aura_data->get_effect().empty() )
		{
			m_owner->ShowStatusEffectOnWithName(m_aura_data->get_effect(), m_aura_data->get_effect_pos());
		}
		else
		{
			this->ShowAuraEffectByArmature(Aura_Effect_Stage_Start, true);
		}
	}

	EmitEventToLua(AuraToLuaEventType_Begin);
}

bool Aura::Update(float delta)
{
	if ( m_over )
	{
		return false;
	}

	m_delta = delta;
	m_curr_exist_time += delta;
	if ( m_exist_time > 0.0f && m_curr_exist_time >= m_exist_time )
	{
		m_over = true;
	}

	for ( int i = 0; i < m_aura_data->get_mod_count(); ++i)
	{
		if ( isFiltered(i))
			continue;

		m_mod_op_index = i;
		m_mod_op = m_aura_data->getModifier(i);
		(*this.*AuraProcessFunHander[m_mod_op->m_type])(AuraProcessStage_Updata);
	}

	return true;
}

void Aura::RemoveStatus()
{
	if ( m_stack_times <= 0 )
	{
		return;
	}

	ChangeStauts(false);

	for ( int i = 0; i < m_aura_data->get_mod_count(); ++i)
	{
		if ( isFiltered(i))
			continue;

		m_mod_op_index = i;
		m_mod_op = m_aura_data->getModifier(i);
		(*this.*AuraProcessFunHander[m_mod_op->m_type])(AuraProcessStage_Remove);
	}

	std::map<int_8, int_8>::iterator iter = m_filtered_mod_list.find(m_stack_times);
	if ( iter == m_filtered_mod_list.end())
	{
		if ( !m_aura_data->get_effect().empty() )
		{
			if ( m_aura_status_flag == kAuraStatusFlag_Freeze )
			{
				m_owner->RemoveStatusEffectWithName(army::kStatusEffectTagFreezeBreak);
			}
			m_owner->RemoveStatusEffectWithName(m_aura_data->get_effect());
		}
		else
		{
			this->ShowAuraEffectByArmature(Aura_Effect_Stage_End, true);
		}
	}

	m_stack_times--;
}

void Aura::ResetStatus()
{
	while ( m_stack_times > 0)
	{
		RemoveStatus();
	}

	this->RemoveAuraEffectByArmature(Aura_Effect_Stage_Start);
	this->RemoveAuraEffectByArmature(Aura_Effect_Stage_Last);

	EmitEventToLua(AuraToLuaEventType_End);
}

void Aura::notifyMovementEvent(cocos2d::extension::CCArmature* armature,
	cocos2d::extension::MovementEventType event_type,const char* movement_name)
{
	if ( m_effect_stage == Aura_Effect_Stage_Start )
	{
		this->RemoveAuraEffectByArmature(Aura_Effect_Stage_Start);
		this->ShowAuraEffectByArmature(Aura_Effect_Stage_Last, true);
	}
	if ( m_effect_stage == Aura_Effect_Stage_Last )
	{
		this->RemoveAuraEffectByArmature(Aura_Effect_Stage_Last);
		if ( m_effect_stage_2_loop )
		{
			this->ShowAuraEffectByArmature(Aura_Effect_Stage_Last, true);
		}
	}
}

void Aura::ShowAuraEffectByArmature(int stage, bool replace)
{
	std::string effect_name;
	if ( stage == Aura_Effect_Stage_Start )
	{
		effect_name = m_aura_data->get_effect_stage1();
		m_effect_stage = Aura_Effect_Stage_Start;
		if ( effect_name.empty() && m_effect_stage_2_loop )
		{
			effect_name = m_aura_data->get_effect_stage2();
			m_effect_stage = Aura_Effect_Stage_Last;
		}
	}
	else if ( stage == Aura_Effect_Stage_Last)
	{
		effect_name = m_aura_data->get_effect_stage2();
		m_effect_stage = Aura_Effect_Stage_Last;
	}
	else if ( stage == Aura_Effect_Stage_End)
	{
		effect_name = m_aura_data->get_effect_stage3();
		m_effect_stage = Aura_Effect_Stage_End;
	}

	if ( !effect_name.empty() )
	{
		if ( m_owner->is_active() && m_owner->anima_node() )
		{
			m_owner->ShowAuraEffectByArmature(effect_name, m_aura_data->get_effect_pos(),replace);
			if (stage == Aura_Effect_Stage_Start || stage == Aura_Effect_Stage_Last)
			{
				int tag = army::getTagByName(effect_name);
				CCNode* armatureNode = m_owner->anima_node()->getChildByTag(tag);
				CCArmature* armature = dynamic_cast<CCArmature*>(armatureNode);
				if ( armature != NULL)
				{
					armature->getAnimation()->setMovementEventCallFunc( m_anim_listener, (SEL_MovementEventCallFunc)(&AuraAnimationEventListener::OnMovementEvent));
				}
			}
		}
	}
}

void Aura::RemoveAuraEffectByArmature( int stage )
{
	std::string effect_name;
	if ( stage == Aura_Effect_Stage_Start )
	{
		effect_name = m_aura_data->get_effect_stage1();
	}
	else if ( stage == Aura_Effect_Stage_Last)
	{
		effect_name = m_aura_data->get_effect_stage2();
	}
	else if ( stage == Aura_Effect_Stage_End)
	{
		effect_name = m_aura_data->get_effect_stage3();
	}

	if ( effect_name.empty() )
		return;

	if ( m_owner->anima_node() )
	{
		int tag = army::getTagByName(effect_name);
		CCNode* armatureNode = m_owner->anima_node()->getChildByTag(tag);
		CCArmature* armature = dynamic_cast<CCArmature*>(armatureNode);
		if ( armature != NULL)
		{
			armature->getAnimation()->setMovementEventCallFunc( NULL, NULL);
			m_owner->RemoveAuraEffectByArmature( tag );
		}
	}
}

void Aura::AuraAssert( const std::string& info)
{
	CCLOGWARN("aura_id(%d)......unit_id(%d)....skill_id(%d)...info==>%s", m_aura_data->get_id(), m_owner->move_object_id(), m_skill_id, info.c_str());
	assert(0);
}

void Aura::ProcessNone(int stage)
{
	return;
}

float Aura::getValueByAttrModType(eAttributeModType amt, float val)
{
	switch( amt)
	{
	case kAttributeModType_FixedValue:
		return val;
	case kAttributeModType_FixedScale:
		return val;
		//
	case kAttributeModType_HealthScale:
		return val * m_owner->currnet_health_point();
	case kAttributeModType_MaxHealthScale:
		return val * m_owner->total_health_point();
	case kAttributeModType_LossHealthScale:
		return val * (m_owner->total_health_point() - m_owner->currnet_health_point());
	case kAttributeModType_PhysicsAttackScale:
		return val * m_owner->physics_attack();
	case kAttributeModType_MagicAttackScale:
		return val * m_owner->magic_attack();
	case kAttributeModType_PhysicsDefenceScale:
		return val * m_owner->physics_defense();
	case kAttributeModType_MagicDefenceScale:
		return val * m_owner->magic_defense();
	//
	case kAttributeModType_Caster_HealthScale:
		return val * m_caster_entity.m_curr_hp;
	case kAttributeModType_Caster_MaxHealthScale:
		return val * m_caster_entity.m_total_hp;
	case kAttributeModType_Caster_LossHealthScale:
		return val * m_caster_entity.m_curr_loss_hp;
	case kAttributeModType_Caster_PhysicsAttackScale:
		return val * m_caster_entity.m_phy_attack;
	case kAttributeModType_Caster_MagicAttackScale:
		return val * m_caster_entity.m_mag_attack;
	case kAttributeModType_Caster_PhysicsDefenceScale:
		return val * m_caster_entity.m_physics_def;
	case kAttributeModType_Caster_MagicDefenceScale:
		return val * m_caster_entity.m_magic_def;
	case kAttributeModType_Caster_SkillDamage:
		{
			float damage_value = 0.0f;
			m_skill_id = 1;
			if (  m_skill_id != MW_INVALID_ID )
			{
				int skill_level = m_owner->getSkillLevel(m_skill_id);
				SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(m_skill_id);
				damage_value = skillData->GetSkillGrowDamage(skill_level);
				damage_value = -1.0f * val * damage_value;
			}
			return damage_value;
		}
	}

	return 0;
}

void Aura::ProcessAddedPropertyDamage(int stage)
{
	assert( m_mod_op->m_type == kModifierType_AddedPropertyDamage );
	if ( AuraProcessStage_Activate == stage)
	{
		int dy = String2Int(m_mod_op->m_param0);
		int amt = String2Int( m_mod_op->m_param1);
		float val = String2Float( m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType( static_cast<eAttributeModType>(amt), val);
		
		m_owner->set_physics_attack_added(m_mod_value[m_mod_op_index] );
		m_owner->set_magic_attack_added(m_mod_value[m_mod_op_index] );

		if ( dy == kDamageType_Ice)
		{
			m_owner->retain_battle_status_flag(battle::kDamageIceProperty);
			m_owner->set_attack_status(battle::kDamageIceProperty, army::kAEPPBuffSet);
		}
		else if ( dy == kDamageType_Fire)
		{
			m_owner->retain_battle_status_flag(battle::kDamageFireProperty);
			m_owner->set_attack_status(battle::kDamageFireProperty, army::kAEPPBuffSet);
		}
		else if ( dy == kDamageType_Wind)
		{
			m_owner->retain_battle_status_flag(battle::kDamageWindProperty);
			m_owner->set_attack_status(battle::kDamageWindProperty, army::kAEPPBuffSet);
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		m_owner->set_physics_attack_added(-m_mod_value[m_mod_op_index] );
		m_owner->set_magic_attack_added(-m_mod_value[m_mod_op_index] );

		int dy = String2Int(m_mod_op->m_param0);
		if ( dy == kDamageType_Ice)
		{
			m_owner->release_battle_status_flag(battle::kDamageIceProperty);
			m_owner->ResetAttackStatus(battle::kDamageIceProperty, army::kAEPPBuffSet);
		}
		else if ( dy == kDamageType_Fire)
		{
			m_owner->release_battle_status_flag(battle::kDamageFireProperty);
			m_owner->ResetAttackStatus(battle::kDamageFireProperty, army::kAEPPBuffSet);
		}
		else if ( dy == kDamageType_Wind)
		{
			m_owner->release_battle_status_flag(battle::kDamageWindProperty);
			m_owner->ResetAttackStatus(battle::kDamageWindProperty, army::kAEPPBuffSet);
		}
	}
}

void Aura::ProcessStunned(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Stunned );
	if ( AuraProcessStage_Activate == stage)
	{
		if ( m_owner->motion_state() != ai::kMotionStateStunned )
		{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(m_owner, ai::kMotionStateStunned);
		}
	}
}

void Aura::ProcessFreeze(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Freeze );
	if ( AuraProcessStage_Activate == stage)
	{
		if ( m_owner->motion_state() != ai::kMotionStateStunned )
		{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(m_owner, ai::kMotionStateStunned);
		}
	}
}

void Aura::ProcessIntertwine(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Intertwine );
	if ( AuraProcessStage_Activate == stage)
	{
		ai::eMotionStateType mst = m_owner->motion_state();
		if ( mst == ai::kMotionStateMovePosition || mst == ai::kMotionStateMoveTarget)
		{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(m_owner, ai::kMotionStateIdle);
		}
		
	}
}

void Aura::ProcessPetrifaction(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Petrifaction );
	if ( AuraProcessStage_Activate == stage)
	{
		if ( m_owner->motion_state() != ai::kMotionStatePetrifaction )
		{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(m_owner, ai::kMotionStatePetrifaction);
		}
	}
}


void Aura::ProcessBlinded(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Blinded );
	if ( AuraProcessStage_Activate == stage)
	{
		if ( m_owner->guard_trigger() )
		{
			m_owner->guard_trigger()->set_is_active_except_healer(false);
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		if ( m_owner->guard_trigger() )
		{
			m_owner->guard_trigger()->set_is_active_except_healer(true);
		}
	}
}

void Aura::ProcessSilence(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Silence );
}

void Aura::ProcessInvisbility(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Invisbility );
}

void Aura::ProcessInvincible(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Invincible );
}

battle::eImmuneType Aura::AuraImmuneStatusType_To_BattleImmuneType(eImmuneStatusType aura_immune_status_type )
{
	if ( aura_immune_status_type == kImmuneStatusType_PhysicsHurt)
	{
		return battle::kImmuneTypePhysicsHurt;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_MagicHurt)
	{
		return battle::kImmuneTypeMagicHurt;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_LowerAttackSpeed)
	{
		return battle::kImmuneTypeLowerAttackSpeed;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_LowerMoveSpeed)
	{
		return battle::kImmuneTypeLowerMoveSpeed;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_Poison)
	{
		return battle::kImmuneTypePoison;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_FireDot)
	{
		return battle::kImmuneTypeFireDot;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_IceDot)
	{
		return battle::kImmuneTypeIceDot;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_WindDot)
	{
		return battle::kImmuneTypeWindDot;
	}
	else if ( aura_immune_status_type == kImmuneStatusType_Control)
	{
		return battle::kImmuneTypeControl;
	}

	return battle::kImmuneTypeNone;
}


void Aura::ProcessImmune(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Immune );
	if ( AuraProcessStage_Activate == stage)
	{
		//m_owner->retain_battle_status_flag( battle::kDamageStatusImmune );
		int aura_immune_status_type = String2Int(m_mod_op->m_param0);
		battle::eImmuneType battle_immune_type = AuraImmuneStatusType_To_BattleImmuneType( static_cast<eImmuneStatusType>(aura_immune_status_type));
		m_owner->retain_immune_status_flag(battle_immune_type);
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		//m_owner->release_battle_status_flag( battle::kDamageStatusImmune );
		int aura_immune_status_type = String2Int(m_mod_op->m_param0);
		battle::eImmuneType battle_immune_type = AuraImmuneStatusType_To_BattleImmuneType(static_cast<eImmuneStatusType>(aura_immune_status_type));
		m_owner->release_immune_status_flag(battle_immune_type);
	}
}

void Aura::ProcessModHealth(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModHealth );
	if ( AuraProcessStage_Updata == stage)
	{
		m_idle_time += m_delta;
		float dis = String2Float(m_mod_op->m_param2);
		if ( dis > 0 && m_idle_time > dis )
		{
			do 
			{
				if ((this->isEqualAuraStatus( kAuraStatusFlag_Poison ) && m_owner->check_immune_status_flag(battle::kImmuneTypePoison)) ||
					(this->isEqualAuraStatus( kAuraStatusFlag_FireDot ) && m_owner->check_immune_status_flag(battle::kImmuneTypeFireDot)) || 
					(this->isEqualAuraStatus( kAuraStatusFlag_IceDot ) && m_owner->check_immune_status_flag(battle::kImmuneTypeIceDot)) ||
					(this->isEqualAuraStatus( kAuraStatusFlag_WindDot ) && m_owner->check_immune_status_flag(battle::kImmuneTypeWindDot)))
				{
					// ����dot
					break;
				}
				
				int amt = String2Int(m_mod_op->m_param0);
				float val = String2Float(m_mod_op->m_param1);
				int dt = String2Int(m_mod_op->m_param3);
				
				float modHp = getValueByAttrModType( static_cast<eAttributeModType>(amt), val);
				if ( amt == kAttributeModType_Caster_SkillDamage )
				{
					modHp = modHp / m_exist_time / dis;
				}

				int real_mod_hp = (int)( -1 * modHp);
				if ( real_mod_hp != 0 )
				{
					battle::eAttackDamageType damageType = battle::kDamageTypePhysics;
					if ( dt == kDamageType_Heal)
						damageType = battle::kDamageTypeHeal;
					else if ( dt == kDamageType_Holy)
						damageType = battle::kDamageTypeHoly;

					m_owner->owner_hub()->AddDamageIntoHub(real_mod_hp, m_owner->move_object_id(), m_owner->move_object_id(), damageType);

					if ( !m_aura_data->get_effect().empty() )
					{
						m_owner->ReplaceOneStatusEffectNewOneWithName(m_aura_data->get_effect(), m_aura_data->get_effect_pos());
					}
					else
					{
						this->ShowAuraEffectByArmature(Aura_Effect_Stage_Last, true);
					}
				}
			} while (0);

			EmitEventToLua(AuraToLuaEventType_PeriodicTrigger);

			m_idle_time -= dis;
		}
	}
	else if ( AuraProcessStage_Activate == stage)
	{
		 m_effect_stage_2_loop = false;
	}
}

void Aura::ProcessRemove(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Remove );
	if ( AuraProcessStage_Activate == stage)
	{
		int remove_rule= String2Int(m_mod_op->m_param0);
		if ( remove_rule == kAuraRemoveRule_ByAuraStatus)
		{
			std::vector<std::string> auraTypes = split(m_mod_op->m_param1, "/");
			for (std::vector<std::string>::iterator it = auraTypes.begin(); it != auraTypes.end(); ++it)
			{
				int aura_type = atoi(it->c_str());
				battle::BattleController::AuraMgr()->RemoveAura( m_owner, static_cast<eAuraStatusFlags>(aura_type));
			}
		}
		else if ( remove_rule == kAuraRemoveRule_ByAuraID )
		{
			battle::BattleController::AuraMgr()->RemoveAura( m_owner, m_aura_data->get_id() );
		}
		else if ( remove_rule == kAuraRemoveRule_OfDecrease )
		{
			battle::BattleController::AuraMgr()->RemoveAllDecreaseAura( m_owner );
		}
		else if ( remove_rule == kAuraRemoveRule_OfIncrease )
		{

		}
		if ( m_exist_time <= 0.0f )
		{
			over();
		}
	}
}

void Aura::ProcessModByHealMultiple(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModByHealMultiple );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float by_heal_mul = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), by_heal_mul);

		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_by_heal_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModByHealMultiple.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->reset_by_heal_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModByHealMultiple.....m_param0 error");
		}
	}
}

void Aura::ProcessModAttack(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModAttack );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		int mod_attack_type = String2Int(m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( amt == ability::kAttributeModType_FixedScale )
		{
			if ( mod_attack_type == kModAttackType_Physics)
			{
				m_owner->set_physics_attack_multiple(m_mod_value[m_mod_op_index]);
			}
			else if ( mod_attack_type == kModAttackType_Magic)
			{
				m_owner->set_magic_attack_multiple(m_mod_value[m_mod_op_index]);
			}
		}
		else
		{
			if ( mod_attack_type == kModAttackType_Physics)
			{
				m_owner->set_physics_attack_added(m_mod_value[m_mod_op_index]);
			}
			else if ( mod_attack_type == kModAttackType_Magic)
			{
				m_owner->set_magic_attack_added(m_mod_value[m_mod_op_index]);
			}
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		int mod_attack_type = String2Int(m_mod_op->m_param2);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			if ( mod_attack_type == kModAttackType_Physics)
			{
				m_owner->set_physics_attack_multiple(-m_mod_value[m_mod_op_index]);
			}
			else if ( mod_attack_type == kModAttackType_Magic)
			{
				m_owner->set_magic_attack_multiple(-m_mod_value[m_mod_op_index]);
			}
		}
		else
		{
			if ( mod_attack_type == kModAttackType_Physics)
			{
				m_owner->set_physics_attack_added(-m_mod_value[m_mod_op_index]);
			}
			else if ( mod_attack_type == kModAttackType_Magic)
			{
				m_owner->set_magic_attack_added(-m_mod_value[m_mod_op_index]);
			}
		}
	}
}

void Aura::ProcessModDamage(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModDamage );
	if ( AuraProcessStage_Activate == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		float val = String2Float(m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( damage_type == kDamageType_None )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_damage_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if (damage_type == kDamageType_Critical)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_critical_damage_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->set_critical_damage_added(m_mod_value[m_mod_op_index]);
			}
		}
		else if ( damage_type == kDamageType_Heal )
		{
			army::eCareerType career_type = m_owner->GetCareerType();
			if ( army::kCareerTypeMonk ==  career_type)
			{
				if ( amt == kAttributeModType_FixedScale)
				{
					m_owner->set_damage_boost_multiple(m_mod_value[m_mod_op_index]);
				}
				else
				{
					AuraAssert("kModifierType_ModDamage.....m_param1 error");
				}
			}
		}
		else if ( damage_type == kDamageType_Fire )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->SetElementsDamageAddedMultiple(battle::kDamageFireProperty, m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Ice )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->SetElementsDamageAddedMultiple(battle::kDamageIceProperty, m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Wind )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->SetElementsDamageAddedMultiple(battle::kDamageWindProperty, m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Skill )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_skill_damage_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("kModifierType_ModDamage.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		if ( damage_type == kDamageType_None )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->reset_damage_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if (damage_type == kDamageType_Critical)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_critical_damage_multiple(-m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->set_critical_damage_multiple(-m_mod_value[m_mod_op_index]);
			}
		}
		else if ( damage_type == kDamageType_Heal )
		{
			army::eCareerType career_type = m_owner->GetCareerType();
			if ( army::kCareerTypeMonk ==  career_type)
			{
				if ( amt == kAttributeModType_FixedScale)
				{
					m_owner->reset_damage_boost_multiple(m_mod_value[m_mod_op_index]);
				}
				else
				{
					AuraAssert("kModifierType_ModDamage.....m_param1 error");
				}
			}
		}
		else if ( damage_type == kDamageType_Fire )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->SetElementsDamageAddedMultiple(battle::kDamageFireProperty, -m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Ice )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->SetElementsDamageAddedMultiple(battle::kDamageIceProperty, -m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Wind )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->SetElementsDamageAddedMultiple(battle::kDamageWindProperty, -m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Skill )
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->reset_skill_damage_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModDamage.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("kModifierType_ModDamage.....m_param0 error");
		}
	}
}

void Aura::ProcessModMoveSpeed(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModMoveSpeed );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_move_speed_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModMoveSpeed.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->reset_move_speed_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModMoveSpeed.....m_param0 error");
		}
	}
}

void Aura::ProcessModAttackSpeed(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModAttackSpeed );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_attack_speed_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModAttackSpeed.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->reset_attack_speed_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModAttackSpeed.....m_param0 error");
		}
	}
}

void Aura::ProcessModDefence(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModDefence );
	if ( AuraProcessStage_Activate == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		float val = String2Float(m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( damage_type == kDamageType_Physics )
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->set_defense_physics_added_mult(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->set_physics_defense_added(m_mod_value[m_mod_op_index] );
			}
		}
		else if ( damage_type == kDamageType_Magic)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->set_defense_magic_added_mult(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->set_magic_defense_added(m_mod_value[m_mod_op_index] );
			}
		}
		else if ( damage_type == kDamageType_None)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->set_defense_physics_added_mult(m_mod_value[m_mod_op_index]);
				m_owner->set_defense_magic_added_mult(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->set_physics_defense_added(m_mod_value[m_mod_op_index] );
				m_owner->set_magic_defense_added(m_mod_value[m_mod_op_index] );
			}
		}
		else
		{
			AuraAssert("kModifierType_ModDefence.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		if ( damage_type == kDamageType_Physics)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->reset_defense_physics_added_mult(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->reset_physics_defense_added(m_mod_value[m_mod_op_index] );
			}
		}
		else if ( damage_type == kDamageType_Magic)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->reset_defense_magic_added_mult(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->reset_magic_defense_added(m_mod_value[m_mod_op_index] );
			}
		}
		else if ( damage_type == kDamageType_None)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->reset_defense_physics_added_mult(m_mod_value[m_mod_op_index]);
				m_owner->reset_defense_magic_added_mult(m_mod_value[m_mod_op_index]);
			}
			else
			{
				m_owner->reset_physics_defense_added(m_mod_value[m_mod_op_index] );
				m_owner->reset_magic_defense_added(m_mod_value[m_mod_op_index] );
			}
		}
		else
		{
			AuraAssert("kModifierType_ModDefence.....m_param0 error");
		}
	}
}

void Aura::ProcessRangeAttackMany(int stage)
{
	assert( m_mod_op->m_type == kModifierType_RangeAttackMany );
	if ( AuraProcessStage_Activate == stage)
	{
		m_mod_value[m_mod_op_index] = String2Float(m_mod_op->m_param0);
		m_owner->set_run_through_damage_multiple(m_mod_value[m_mod_op_index]);
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		m_owner->set_run_through_damage_multiple( battle::kThroughDamageMultiple );
	}
}

void Aura::ProcessModHematophagia(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModHematophagia );
	if ( AuraProcessStage_Activate == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		float val = String2Float(m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( damage_type == kDamageType_Physics)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->set_physics_blood_boost_multiple( m_mod_value[m_mod_op_index] );
			}
			else
			{
				AuraAssert("kModifierType_ModHematophagia.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Magic)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->set_magic_blood_boost_multiple( m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModHematophagia.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("kModifierType_ModHematophagia.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		if ( damage_type == kDamageType_Physics)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->reset_physics_blood_boost_multiple( m_mod_value[m_mod_op_index] );
			}
			else
			{
				AuraAssert("kModifierType_ModHematophagia.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Magic)
		{
			if ( amt == kAttributeModType_FixedScale )
			{
				m_owner->reset_magic_blood_boost_multiple( m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModHematophagia.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("kModifierType_ModHematophagia.....m_param0 error");
		}
	}
}

void Aura::ProcessModCriticalProbability(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModCriticalProbability );
	if ( AuraProcessStage_Activate == stage )
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);
		if (  amt == kAttributeModType_FixedValue)
		{
			m_owner->set_critical_added(m_mod_value[m_mod_op_index]);
		}
		else if ( amt == kAttributeModType_FixedScale )
		{
			m_owner->set_critical_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModCriticalProbability.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if (  amt == kAttributeModType_FixedValue)
		{
			m_owner->set_critical_added(-m_mod_value[m_mod_op_index]);
		}
		else if ( amt == kAttributeModType_FixedScale )
		{
			m_owner->set_critical_multiple(-m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModCriticalProbability.....m_param0 error");
		}
	}
}

void Aura::ProcessModByDamage(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModByDamage );
	if ( AuraProcessStage_Activate == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		float val = String2Float(m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( damage_type == kDamageType_None)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_by_damage_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModByDamage.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("kModifierType_ModByDamage.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		if ( damage_type == kDamageType_None)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->reset_by_damage_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_ModByDamage.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("kModifierType_ModByDamage.....m_param0 error");
		}
	}
}

void Aura::ProcessModThorns(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModThorns );
	if ( AuraProcessStage_Activate == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		float val = String2Float(m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( damage_type == kDamageType_Physics)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_physics_thorns_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("ProcessModThorns.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Magic)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->set_magic_thorns_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("ProcessModThorns.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("ProcessModThorns.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int damage_type = String2Int(m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		if ( damage_type == kDamageType_Physics)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->reset_physics_thorns_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("ProcessModThorns.....m_param1 error");
			}
		}
		else if ( damage_type == kDamageType_Magic)
		{
			if ( amt == kAttributeModType_FixedScale)
			{
				m_owner->reset_magic_thorns_boost_multiple(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("ProcessModThorns.....m_param1 error");
			}
		}
		else
		{
			AuraAssert("ProcessModThorns.....m_param0 error");
		}
	}
}

void Aura::ProcessModStatusDamage(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModStatusDamage );
	if ( AuraProcessStage_Activate == stage )
	{
		int auta_status = String2Int( m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);
		float val = String2Float( m_mod_op->m_param2);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( amt == kAttributeModType_FixedScale)
		{
			battle::eDamageStatus damage_status = AuraStatus_To_DamageStatus( static_cast<eAuraStatusFlags>(auta_status));
			m_owner->set_favorite_target_status(damage_status);
			m_owner->set_status_damage_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModStatusDamage.....m_param1 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		int auta_status = String2Int( m_mod_op->m_param0);
		int amt = String2Int(m_mod_op->m_param1);

		if ( amt == kAttributeModType_FixedScale)
		{
			battle::eDamageStatus damage_status = AuraStatus_To_DamageStatus( static_cast<eAuraStatusFlags>(auta_status));
			m_owner->reset_favorite_target_status(damage_status);
			m_owner->reset_status_damage_boost_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			AuraAssert("kModifierType_ModStatusDamage.....m_param1 error");
		}
	}
}

void Aura::ProcessBattleExtraReward(int stage)
{
	assert( m_mod_op->m_type == kModifierType_BattleExtraReward );
	if ( stage == 0 )
	{
		float probabilty = String2Float(m_mod_op->m_param1);
		if (flipProbability(probabilty))
		{
			int ber_type = String2Int(m_mod_op->m_param0);
			int amt = String2Int(m_mod_op->m_param2);
			float val = String2Float(m_mod_op->m_param3);
			m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

			if ( ber_type == kBattleExtraRewardType_Gold)
			{
				if ( amt == kAttributeModType_FixedScale)
					battle::BattleController::GetInstance().battle_data()->add_gain_gold_multiple(m_mod_value[m_mod_op_index]);
			}
			else if ( ber_type == kBattleExtraRewardType_Items)
			{
				if ( amt == kAttributeModType_FixedScale)
					battle::BattleController::GetInstance().battle_data()->add_gain_item_multiple(m_mod_value[m_mod_op_index]);
			}
			else if ( ber_type == kBattleExtraRewardType_Xp)
			{
				if ( amt == kAttributeModType_FixedScale)
					battle::BattleController::GetInstance().battle_data()->add_gain_xp_multiple(m_mod_value[m_mod_op_index]);
			}
			else if ( ber_type == kBattleExtraRewardType_ApBack)
			{
				if ( amt == kAttributeModType_FixedScale)
					battle::BattleController::GetInstance().battle_data()->AddOneGainApWithRadio(m_mod_value[m_mod_op_index]);
			}
			else
			{
				AuraAssert("kModifierType_BattleExtraReward.....m_param0 error");
			}
		}

		over();
	}
}

#define InternalVariate_24_IsTriggered "24##IsTriggered"
void Aura::ProcessAbilityMonitorHP(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_MonitorHP );
	if ( AuraProcessStage_Updata == stage || AuraProcessStage_Activate == stage )
	{
		int compare_type = String2Int(m_mod_op->m_param0);
		float compare_param = String2Float(m_mod_op->m_param1);

		float leftHpPercent = m_owner->GetCurrentHealthPointPercent();
		bool res = ConditionCompare(leftHpPercent, static_cast<eConditionCompareType>(compare_type), compare_param);

		if ( res )
		{
			bool is_triggered = getBoolVlaue(InternalVariate_24_IsTriggered);
			if ( !is_triggered )
			{
				setInternalVariate(InternalVariate_24_IsTriggered, "1");
				battle::BattleController::AuraMgr()->AddAuras(m_owner->move_object_id(), m_mod_op->m_param2, m_owner->move_object_id());
				EmitEventToLua(AuraToLuaEventType_PeriodicTrigger);
			}
		}
		else
		{
			bool is_triggered = getBoolVlaue(InternalVariate_24_IsTriggered);
			if ( is_triggered )
			{
				setInternalVariate(InternalVariate_24_IsTriggered, "0");
				battle::BattleController::AuraMgr()->RemoveAuras(m_owner->move_object_id(), m_mod_op->m_param2);
			}
		}
	}
}

void Aura::SubscribeAuraEventHandle(int index, int event_id, EventHandleFunc handle)
{
	registerEventHandleWithID(event_id, handle);
	m_event_mod_map.insert(std::pair<int,int>(event_id, index));
}

void Aura::UnSubscribeAuraEventHandle(int event_id)
{
	unRegisterEventHandleWithID(event_id);
	std::map<int, int>::iterator iter = m_event_mod_map.find(event_id);
	if ( iter != m_event_mod_map.end())
	{
		m_event_mod_map.erase(iter);
	}
}

void Aura::UnSubscribeAllAuraEventHandle()
{
	for ( std::map<int, int>::iterator iter = m_event_mod_map.begin(); iter != m_event_mod_map.end(); ++iter )
	{
		unRegisterEventHandleWithID(iter->first);
	}
	m_event_mod_map.clear();
}

void Aura::ProcessAbilityMonitorHit(int stage)
{
	if ( m_mod_op->m_type != kModifierType_Ability_MonitorNormalHit &&
		 m_mod_op->m_type != kModifierType_Ability_MonitorCriticalHit &&
		 m_mod_op->m_type != kModifierType_Ability_MonitorSkillHit)
	{
		AuraAssert();
		return;
	}

	if ( AuraProcessStage_Activate == stage )
	{
		SubscribeAuraEventHandle( m_mod_op_index, HitEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessHitEvent));
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		UnSubscribeAuraEventHandle( HitEvent::getEventIDWithName());
	}
}

void Aura::ProcessAbilityMonitorByHit(int stage)
{
	if ( m_mod_op->m_type != kModifierType_Ability_MonitorByNormalHit &&
		m_mod_op->m_type != kModifierType_Ability_MonitorByCriticalHit &&
		m_mod_op->m_type != kModifierType_Ability_MonitorBySkillHit)
	{
		AuraAssert();
		return;
	}

	if ( AuraProcessStage_Activate == stage )
	{
		SubscribeAuraEventHandle( m_mod_op_index, ByHitEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessByHitEvent));
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		UnSubscribeAuraEventHandle( ByHitEvent::getEventIDWithName());
	}
}

void Aura::onProcessByHitEvent(const Event* evt)
{
	const ByHitEvent* hit_event = dynamic_cast<const ByHitEvent*>(evt);
	if ( hit_event == NULL )
	{
		AuraAssert();
		return;
	}

	if ( hit_event->m_owner_id_ != m_owner->move_object_id())
	{
		return;
	}

	if ((hit_event->m_attack_type_ & battle::kAttackResultSkillDamage)  ||
		(hit_event->m_attack_type_ & battle::kAttackResultCriticalDamage) ||
		(hit_event->m_attack_type_ & battle::kAttackResultNormalDamage) )
	{
		if ( m_aura_status_flag == kAuraStatusFlag_Freeze && m_owner->check_battle_status_flag( battle::kDamageFreeze ) )
		{
			over();
		}
	}

	std::map<int, int>::iterator iter = m_event_mod_map.find( evt->getEventId());
	if ( iter != m_event_mod_map.end())
	{
		m_mod_op = m_aura_data->getModifier(iter->second);
		if ( (m_mod_op->m_type == kModifierType_Ability_MonitorBySkillHit && (hit_event->m_attack_type_ & battle::kAttackResultSkillDamage) ) ||
			(m_mod_op->m_type == kModifierType_Ability_MonitorByCriticalHit && (hit_event->m_attack_type_ & battle::kAttackResultCriticalDamage) ) ||
			(m_mod_op->m_type == kModifierType_Ability_MonitorByNormalHit && (hit_event->m_attack_type_ & battle::kAttackResultNormalDamage)))
		{
			float probabilty = String2Float(m_mod_op->m_param0);
			if (flipProbability(probabilty))
			{
				int select_type = String2Int( m_mod_op->m_param1);
				if ( select_type == kSelectTargetType_Self )
				{
					battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param2, m_owner->move_object_id());
				}
				else if ( select_type == kSelectTargetType_Enemy )
				{
					battle::BattleController::AuraMgr()->AddAuras( hit_event->m_target_id_ , m_mod_op->m_param2, m_owner->move_object_id());
				}
				else
				{
					AuraAssert(".....m_param1 error");
				}
			}
		}
	}
}

void Aura::onProcessHitEvent(const Event* evt)
{
	const HitEvent* hit_event = dynamic_cast<const HitEvent*>(evt);
	if ( hit_event == NULL )
	{
		AuraAssert();
		return;
	}

	if ( hit_event->m_owner_id_ != m_owner->move_object_id())
	{
		return;
	}

	//
	std::map<int, int>::iterator iter = m_event_mod_map.find( evt->getEventId());
	if ( iter == m_event_mod_map.end())
	{
		AuraAssert();
		return;
	}
	m_mod_op = m_aura_data->getModifier(iter->second);

	process_Ability_25_26_27( hit_event->m_target_id_, hit_event->m_attack_type_ );

	process_Ability_43( hit_event->m_target_id_, hit_event->m_attack_type_, hit_event->m_skill_id_, hit_event->m_enable_infect);
	
	return;
}

void Aura::process_Ability_25_26_27(uint_32 target_id, int attack_type)
{
	if ( (m_mod_op->m_type == kModifierType_Ability_MonitorSkillHit && (attack_type & battle::kAttackResultSkillDamage) ) ||
		(m_mod_op->m_type == kModifierType_Ability_MonitorCriticalHit && (attack_type & battle::kAttackResultCriticalDamage) ) ||
		(m_mod_op->m_type == kModifierType_Ability_MonitorNormalHit && (attack_type & battle::kAttackResultNormalDamage)))
	{
		float probabilty = String2Float(m_mod_op->m_param0);
		if (flipProbability(probabilty))
		{
			int select_type = String2Int( m_mod_op->m_param1);
			if ( select_type == kSelectTargetType_Self )
			{
				battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param2, m_owner->move_object_id());
			}
			else if ( select_type == kSelectTargetType_Enemy )
			{
				battle::BattleController::AuraMgr()->AddAuras( target_id , m_mod_op->m_param2, m_owner->move_object_id());
			}
			else
			{
				AuraAssert(".....m_param1 error");
			}
		}
	}
}

void Aura::process_Ability_43(uint_32 target_id, int attack_type, uint_32 skill_id, bool enable_infect)
{
	if ( !enable_infect )
		return;

	if ( m_mod_op->m_type != kModifierType_Sputtering )
		return;

	if ( attack_type & battle::kAttackResultSkillDamage)
		return;

	army::MoveObject* target = battle::BattleController::GetInstance().GetObjectById(target_id);
	const std::vector<uint_32>& own_hub_ids = target->owner_hub()->troops()->active_ids();
	if ( own_hub_ids.size() == 0 )
		return;

	float radius = String2Float(m_mod_op->m_param0);
	radius = radius * battle::kMapTileMaxLength;
	float damaga_multiple = String2Float(m_mod_op->m_param1);
	int count = String2Float(m_mod_op->m_param2);;
	int curr_count = 0;
	
	
	cocos2d::CCPoint center_point = target->current_pos();
	for ( int i = 0; i < own_hub_ids.size(); ++i )
	{
		if ( count > 0 && curr_count >= count)
			break;

		if ( own_hub_ids[i] == target_id)
			continue;

		army::MoveObject* nearby = battle::BattleController::GetInstance().GetObjectById(own_hub_ids[i]);
		if ( nearby && nearby->is_active() )
		{
			cocos2d::CCPoint nearby_point = nearby->current_pos();
			float dis = ccpDistance(nearby_point, center_point );
			if ( dis < radius)
			{
				bool isAttack = nearby->owner_hub()->SputteringOneUnitInThisHub( m_owner->move_object_id(), own_hub_ids[i], skill_id, damaga_multiple);
				if ( isAttack)
				{
					nearby->anima_manager()->StartHitRedShader(0.5f);
				}
				curr_count ++;
			}
		}
	}
}

const std::vector<uint_32>& Aura::SelectActiveObjByCareer( const std::vector<int>& careers, bool isOwn)
{
	static std::vector<uint_32> return_list;
	return_list.clear();

	army::TroopsHub* troops  = NULL;
	if ( isOwn )
	{
		troops = m_owner->owner_hub()->troops();
	}
	else
	{
		troops = m_owner->owner_hub()->enemy_hub()->troops();
	}

	const std::vector<uint_32>& active_ids = troops->active_ids();
	if ( careers.size() == 0)
	{
		return active_ids;
	}

	for ( int i = 0 ; i < active_ids.size(); ++i )
	{
		army::MoveObject* moveObj = troops->GetObjectById(active_ids[i]);
		int career_type = m_owner->GetCareerType();
		std::vector<int>::const_iterator find_iter = std::find(careers.begin(), careers.end(), career_type);
		if ( find_iter != careers.end() )
		{
			return_list.push_back(moveObj->move_object_id());
		}
	}

	return return_list;
}

void Aura::ProcessAbilityTeamAuras(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_TeamAuras );
	if ( AuraProcessStage_Activate == stage )
	{
		int select_type = String2Int( m_mod_op->m_param0);
		std::vector<std::string> str_list = split(m_mod_op->m_param2 ,"/");
		std::vector<int> careers;
		for ( int i = 0; i < str_list.size(); ++i )
		{
			if ( !str_list[i].empty())
			{
				careers.push_back(String2Int(str_list[i]));
			}
		}
		
		if ( select_type == kSelectTargetType_Own_Hub )
		{
			const std::vector<uint_32>& own_hub_ids = SelectActiveObjByCareer(careers, true);
			battle::BattleController::AuraMgr()->AddAuras(own_hub_ids, m_mod_op->m_param1, m_owner->move_object_id());

			SubscribeAuraEventHandle( m_mod_op_index, MoveObjBornEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessMoveObjBornEvent));
		}
		else if ( select_type == kSelectTargetType_Enemy_Hub )
		{
			const std::vector<uint_32>& enemy_hub_ids = SelectActiveObjByCareer(careers, false);
			battle::BattleController::AuraMgr()->AddAuras(enemy_hub_ids, m_mod_op->m_param1, m_owner->move_object_id());

			SubscribeAuraEventHandle( m_mod_op_index, MoveObjBornEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessMoveObjBornEvent));
		}
		else if( select_type == kSelectTargetType_Friend )
		{
			std::vector<uint_32> ignore_self_ids = SelectActiveObjByCareer(careers, true);
			std::vector<uint_32>::iterator self_iter = std::find(ignore_self_ids.begin(), ignore_self_ids.end(), m_owner->move_object_id());
			if ( self_iter != ignore_self_ids.end() )
			{
				ignore_self_ids.erase(self_iter);
			}
			battle::BattleController::AuraMgr()->AddAuras(ignore_self_ids, m_mod_op->m_param1, m_owner->move_object_id());

			SubscribeAuraEventHandle( m_mod_op_index, MoveObjBornEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessMoveObjBornEvent));
		}
		else
		{
			AuraAssert("kModifierType_Ability_TeamAuras.....m_param0 error");
		}
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		int select_type = String2Int( m_mod_op->m_param0);
		std::vector<std::string> str_list = split(m_mod_op->m_param2 ,"/");
		std::vector<int> careers;
		for ( int i = 0; i < str_list.size(); ++i )
		{
			if ( !str_list[i].empty())
			{
				careers.push_back(String2Int(str_list[i]));
			}
		}

		if ( select_type == kSelectTargetType_Own_Hub )
		{
			const std::vector<uint_32>& own_hub_ids = SelectActiveObjByCareer(careers, true);
			battle::BattleController::AuraMgr()->RemoveAuras(own_hub_ids, m_mod_op->m_param1);

			UnSubscribeAuraEventHandle( MoveObjBornEvent::getEventIDWithName());
		}
		else if ( select_type == kSelectTargetType_Enemy_Hub )
		{
			const std::vector<uint_32>& enemy_hub_ids = SelectActiveObjByCareer(careers, false);
			battle::BattleController::AuraMgr()->RemoveAuras(enemy_hub_ids, m_mod_op->m_param1);

			UnSubscribeAuraEventHandle( MoveObjBornEvent::getEventIDWithName());
		}
		else if( select_type == kSelectTargetType_Friend )
		{
			std::vector<uint_32> ignore_self_ids = SelectActiveObjByCareer(careers, true);
			std::vector<uint_32>::iterator self_iter = std::find(ignore_self_ids.begin(), ignore_self_ids.end(), m_owner->move_object_id());
			if ( self_iter != ignore_self_ids.end() )
			{
				ignore_self_ids.erase(self_iter);
			}
			battle::BattleController::AuraMgr()->RemoveAuras(ignore_self_ids, m_mod_op->m_param1);

			UnSubscribeAuraEventHandle( MoveObjBornEvent::getEventIDWithName());
		}
		else
		{
			AuraAssert("kModifierType_Ability_TeamAuras.....m_param0 error");
		}
	}
}

void Aura::onProcessMoveObjBornEvent(const Event* evt)
{
	if ( evt->getEventId() != MoveObjBornEvent::getEventIDWithName())
	{
		return ;
	}

	const MoveObjBornEvent* moveobj_born_event = dynamic_cast<const MoveObjBornEvent*>(evt);
	if ( moveobj_born_event == NULL )
	{
		AuraAssert();
		return;
	}

	std::map<int, int>::iterator iter = m_event_mod_map.find( evt->getEventId());
	if ( iter == m_event_mod_map.end())
	{
		AuraAssert();
		return;
	}
	m_mod_op = m_aura_data->getModifier(iter->second);

	int select_type = String2Int( m_mod_op->m_param0);
	std::vector<std::string> str_list = split(m_mod_op->m_param2 ,"/");
	std::vector<int> careers;
	for ( int i = 0; i < str_list.size(); ++i )
	{
		if ( !str_list[i].empty())
		{
			careers.push_back(String2Int(str_list[i]));
		}
	}

	bool is_teammate = army::AreTwoMoveObjectsInTheSameForceHub(m_owner->move_object_id(), moveobj_born_event->m_move_obj_id_ );
	if ( is_teammate)
	{
		army::TroopsHub* troops = m_owner->owner_hub()->troops();
		army::MoveObject* moveObj = troops->GetObjectById(moveobj_born_event->m_move_obj_id_);
		int career_type = m_owner->GetCareerType();
		std::vector<int>::const_iterator find_iter = std::find(careers.begin(), careers.end(), career_type);
		if ( careers.size() == 0 || find_iter != careers.end() )
		{
			if ( select_type == kSelectTargetType_Own_Hub )
			{
				battle::BattleController::AuraMgr()->AddAuras( moveobj_born_event->m_move_obj_id_, m_mod_op->m_param1, m_owner->move_object_id());
			}
			else if ( select_type == kSelectTargetType_Friend )
			{
				if ( moveobj_born_event->m_move_obj_id_ != m_owner->move_object_id() )
				{
					battle::BattleController::AuraMgr()->AddAuras( moveobj_born_event->m_move_obj_id_, m_mod_op->m_param1, m_owner->move_object_id());
				}
			}
		}
	}
	else
	{
		army::TroopsHub* troops = m_owner->owner_hub()->enemy_hub()->troops();
		army::MoveObject* moveObj = troops->GetObjectById(moveobj_born_event->m_move_obj_id_);
		int career_type = m_owner->GetCareerType();
		std::vector<int>::const_iterator find_iter = std::find(careers.begin(), careers.end(), career_type);
		if ( careers.size() == 0 || find_iter != careers.end() )
		{
			if ( select_type == kSelectTargetType_Enemy_Hub )
			{
				battle::BattleController::AuraMgr()->AddAuras( moveobj_born_event->m_move_obj_id_, m_mod_op->m_param1, m_owner->move_object_id());
			}
		}
	}
}

void Aura::ProcessAbilityMonitorDead(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_MonitorDead );
	if ( AuraProcessStage_Activate == stage )
	{
		SubscribeAuraEventHandle( m_mod_op_index, MoveObjDeadEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessMoveObjDeadEvent));
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		UnSubscribeAuraEventHandle( MoveObjDeadEvent::getEventIDWithName());
	}
}

void Aura::ProcessAbilitySlay(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_Slay );
	if ( AuraProcessStage_Activate == stage )
	{
		float less_rate = String2Float( m_mod_op->m_param0);
		float damage_mul = String2Float( m_mod_op->m_param1);

		m_owner->set_slay_condition_rate(less_rate);
		m_owner->set_slay_damage_multiple(damage_mul);
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		m_owner->set_slay_condition_rate(0.0f);
		m_owner->set_slay_damage_multiple(battle::kSlayDamageMultiple);
	}
}

void Aura::ProcessAbilityBattleSceneType(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_BattleSceneType );
	if ( AuraProcessStage_Activate == stage )
	{
		SubscribeAuraEventHandle( m_mod_op_index, BattleSceneTypeEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessBattleSceneTypeEvent));
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		UnSubscribeAuraEventHandle( BattleSceneTypeEvent::getEventIDWithName());
	}
}

void Aura::onProcessMoveObjDeadEvent(const Event* evt)
{
	if ( evt->getEventId() != MoveObjDeadEvent::getEventIDWithName() )
	{
		AuraAssert();
		return ;
	}

	const MoveObjDeadEvent* moveobj_dead_event = dynamic_cast<const MoveObjDeadEvent*>(evt);
	if ( moveobj_dead_event == NULL )
	{
		AuraAssert();
		return;
	}

	std::map<int, int>::iterator iter = m_event_mod_map.find( evt->getEventId());
	if ( iter == m_event_mod_map.end())
	{
		AuraAssert();
		return;
	}
	m_mod_op = m_aura_data->getModifier(iter->second);

	process_Ability_30(moveobj_dead_event->m_move_obj_id_);

	process_Ability_46(moveobj_dead_event->m_move_obj_id_);
}

void Aura::process_Ability_30( uint_32 dead_unit_id )
{
	if ( m_mod_op->m_type != kModifierType_Ability_MonitorDead )
		return;

	int stt = String2Int(m_mod_op->m_param0);
	bool is_teammate = army::AreTwoMoveObjectsInTheSameForceHub(m_owner->move_object_id(), dead_unit_id );
	if ( is_teammate )
	{
		if ( stt == kSelectTargetType_Own_Hub )
		{
			battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param1, m_owner->move_object_id());
		}
	}
	else
	{
		if ( stt == kSelectTargetType_Enemy_Hub )
		{
			battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param1, m_owner->move_object_id());
		}
	}
}

void Aura::onProcessBattleSceneTypeEvent(const Event* evt)
{
	if ( evt->getEventId() != BattleSceneTypeEvent::getEventIDWithName() )
	{
		return ;
	}

	const BattleSceneTypeEvent* battle_round_event = dynamic_cast<const BattleSceneTypeEvent*>(evt);
	if ( battle_round_event == NULL )
	{
		AuraAssert();
		return;
	}

	std::map<int, int>::iterator iter = m_event_mod_map.find( evt->getEventId());
	if ( iter == m_event_mod_map.end())
	{
		AuraAssert();
		return;
	}
	m_mod_op = m_aura_data->getModifier(iter->second);

	int sceneType = String2Int(m_mod_op->m_param0);
	if ( battle_round_event->m_battle_scene_type == sceneType)
	{
		battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param1, m_owner->move_object_id());
	}
	else
	{
		battle::BattleController::AuraMgr()->RemoveAuras( m_owner->move_object_id(), m_mod_op->m_param1);
	}
}

void Aura::onProcessReleaseSkillOverEvent(const Event* evt)
{
	const ReleaseSkillOverEvent* skill_over_event = dynamic_cast<const ReleaseSkillOverEvent*>(evt);
	if ( skill_over_event == NULL )
	{
		AuraAssert();
		return;
	}

	if ( kInterruptType_SkillOver == m_aura_data->get_interrupt_type())
	{
		if ( skill_over_event->m_move_obj_id_ == m_owner->move_object_id() &&
			 skill_over_event->m_skill_id_ == m_skill_id )
		{
			over();
		}
	}
}

void Aura::ProcessAbilityTriggerEffect(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_TriggerEffect );
	if ( AuraProcessStage_Updata == stage )
	{
		int triggerType = String2Int(m_mod_op->m_param0);
		if ( triggerType == kTriggrEffectType_TriggerSkill_Periodic )
		{
			int dis = String2Int(m_mod_op->m_param2);
			if ( dis > 0 && m_idle_time > dis )
			{
				int trigger_skill = String2Int(m_mod_op->m_param1);
				//m_owner->set_trigger_skill_id(trigger_skill);

				m_idle_time -= dis;
			}
			EmitEventToLua(AuraToLuaEventType_PeriodicTrigger);
			m_idle_time += m_delta;
		}
		else if ( triggerType == kTriggrEffectType_TriggerAura_Periodic )
		{
			int dis = String2Int(m_mod_op->m_param2);
			if ( dis > 0 && m_idle_time > dis )
			{
				battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param1, m_owner->move_object_id());

				m_idle_time -= dis;
			}
			EmitEventToLua(AuraToLuaEventType_PeriodicTrigger);
			m_idle_time += m_delta;
		}
	}
	else if ( AuraProcessStage_Activate == stage )
	{
		int triggerType = String2Int(m_mod_op->m_param0);
		if ( triggerType == kTriggrEffectType_TriggerSkill_Begin )
		{
			int trigger_skill = String2Int(m_mod_op->m_param1);
			//m_owner->set_trigger_skill_id(trigger_skill);
		}
		else if ( triggerType == kTriggrEffectType_TriggerAura_Begin )
		{
			battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param1, m_owner->move_object_id());
		}
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		int triggerType = String2Int(m_mod_op->m_param0);
		if ( triggerType == kTriggrEffectType_TriggerSkill_End )
		{
			int trigger_skill = String2Int(m_mod_op->m_param1);
			//m_owner->set_trigger_skill_id(trigger_skill);
		}
		else if ( triggerType == kTriggrEffectType_TriggerAura_End )
		{
			battle::BattleController::AuraMgr()->AddAuras( m_owner->move_object_id(), m_mod_op->m_param1, m_owner->move_object_id());
		}
	}
}

void Aura::ProcessAbilityAppearanceSkill(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Ability_AppearanceSkill );
	if ( AuraProcessStage_Activate == stage )
	{
		SubscribeAuraEventHandle( m_mod_op_index, MoveObjFirstInPlace::getEventIDWithName(), event_handle_selector(Aura::onProcessAppearanceSkillEvent));
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		UnSubscribeAuraEventHandle( MoveObjFirstInPlace::getEventIDWithName());
	}
}

void Aura::onProcessAppearanceSkillEvent(const Event* evt)
{
	const MoveObjFirstInPlace* in_place_event = dynamic_cast<const MoveObjFirstInPlace*>(evt);
	if ( in_place_event == NULL )
	{
		AuraAssert();
		return;
	}

	if ( in_place_event->m_move_obj_id_ != m_owner->move_object_id())
	{
		return;
	}

	int trigger_skill = String2Int(m_mod_op->m_param0);
	m_owner->set_trigger_skill_id(trigger_skill);

	over();
}


void Aura::ProcessAttachShield(int stage)
{
	assert( m_mod_op->m_type == kModifierType_AttachShield );
	if ( AuraProcessStage_Activate == stage )
	{
		int shieldType = String2Int(m_mod_op->m_param0);
		int shieldCount = String2Int(m_mod_op->m_param1);
		int amt = String2Int(m_mod_op->m_param2);
		float val = String2Float(m_mod_op->m_param3);
		
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		ability::Shield shidle;
		shidle.setMoveObjId( m_owner->move_object_id());
		shidle.setAuraId(get_aurd_id());
		shidle.setType(static_cast<ability::eShieldType>(shieldType));
		shidle.setTime(m_exist_time);
		shidle.setCount(shieldCount);
		shidle.setValue(m_mod_value[m_mod_op_index]);

		m_owner->AddShield(shidle);
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		m_owner->RemoveShieldByAura(get_aurd_id());
	}
}

void Aura::ProcessModHealthLimit(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModHealthLimit );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_health_upperlimit_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_health_upperlimit_added(m_mod_value[m_mod_op_index]);
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_health_upperlimit_multiple(-m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_health_upperlimit_added(-m_mod_value[m_mod_op_index]);
		}
	}
}

void Aura::ProcessModGuardRadius(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModGuardRadius );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);

		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_circle_guard_radius_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_circle_guard_radius_added(m_mod_value[m_mod_op_index]);
		}
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_circle_guard_radius_multiple(-m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_circle_guard_radius_added(-m_mod_value[m_mod_op_index]);
		}
	}
}

void Aura::ProcessModEnergy(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModEnergy );
	if ( AuraProcessStage_Updata == stage)
	{
		m_idle_time += m_delta;
		float dis = String2Float(m_mod_op->m_param2);
		if ( dis > 0 && m_idle_time > dis )
		{
			int amt = String2Int(m_mod_op->m_param0);
			float val = String2Float(m_mod_op->m_param1);
			float addEnergy = getValueByAttrModType( static_cast<eAttributeModType>(amt), val);
			if ( addEnergy > 0.0f )
			{
				m_owner->add_energy_value(addEnergy);
				if ( !m_aura_data->get_effect().empty() )
				{
					m_owner->ReplaceOneStatusEffectNewOneWithName(m_aura_data->get_effect(), m_aura_data->get_effect_pos());
				}
				else
				{
					this->ShowAuraEffectByArmature(Aura_Effect_Stage_Last, true);
				}
			}
			EmitEventToLua(AuraToLuaEventType_PeriodicTrigger);

			m_idle_time -= dis;
		}
	}
	else if ( AuraProcessStage_Activate == stage)
	{
		m_effect_stage_2_loop = false;
	}
}
void Aura::ProcessModSputtering(int stage)
{
	assert( m_mod_op->m_type == kModifierType_Sputtering );
	if ( AuraProcessStage_Activate == stage)
	{
		SubscribeAuraEventHandle( m_mod_op_index, HitEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessHitEvent));
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		UnSubscribeAuraEventHandle( HitEvent::getEventIDWithName());
	}
}

void Aura::ProcessEnchantment(int stage)
{
	assert(m_mod_op->m_type == kModifierType_Enchantment);
	if ( AuraProcessStage_Activate == stage)
	{
		m_owner->set_circle_guard_radius_added(50.0f);
	}
	else if ( AuraProcessStage_Remove == stage)
	{
		m_owner->set_circle_guard_radius_added(-50.0f);
	}
}

void Aura::ProcessFear(int stage)
{
	assert(m_mod_op->m_type == kModifierType_Fear);
}

#define InternalVariate_46_ResurgenceCount "46##ResurgenceCount"
void Aura::ProcessResurgence(int stage)
{
	assert(m_mod_op->m_type == kModifierType_Resurgence);

	if ( AuraProcessStage_Activate == stage )
	{
		int resurgence_count = String2Int( m_mod_op->m_param2);
		if ( resurgence_count > 0)
		{
			setInternalVariate( InternalVariate_46_ResurgenceCount, Int2String(resurgence_count));

			int amt = String2Int(m_mod_op->m_param0);
			float val = String2Float(m_mod_op->m_param1);
			m_mod_value[m_mod_op_index] = getValueByAttrModType( static_cast<eAttributeModType>(amt), val);
		}
		SubscribeAuraEventHandle( m_mod_op_index, MoveObjDeadEvent::getEventIDWithName(), event_handle_selector(Aura::onProcessMoveObjDeadEvent));
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		UnSubscribeAuraEventHandle( MoveObjDeadEvent::getEventIDWithName());
	}
}

void Aura::process_Ability_46( uint_32 dead_unit_id )
{
	if (m_mod_op->m_type != kModifierType_Resurgence)
		return;

	if ( dead_unit_id != m_owner->move_object_id() )
		return;

	int resurgence_count = getIntVlaue(InternalVariate_46_ResurgenceCount);
	if ( resurgence_count > 0)
	{
		//m_owner->set_currnet_health_point(m_mod_value[m_mod_op_index]);
		m_owner->set_enable_resurgence(true);
		setInternalVariate( InternalVariate_46_ResurgenceCount, Int2String(resurgence_count - 1));
	}
	else 
	{
		m_owner->set_enable_resurgence(false);
	}
}

void Aura::ProcessWitchcraft(int stage)
{
	assert(m_mod_op->m_type == kModifierType_Witchcraft);
	if ( AuraProcessStage_Activate == stage )
	{
		m_owner->ChangeSkeleton(true);
	}
	else if ( AuraProcessStage_Remove == stage )
	{
		m_owner->ChangeSkeleton(false);
	}
}

void Aura::ProcessModHitRate(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModHitRate);
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_hit_rate_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_hit_rate_added(m_mod_value[m_mod_op_index]);
		}

	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_hit_rate_multiple(-m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_hit_rate_added(-m_mod_value[m_mod_op_index]);
		}
	}
}

void Aura::ProcessModDodge(int stage)
{
	assert( m_mod_op->m_type == kModifierType_ModDodge );
	if ( AuraProcessStage_Activate == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		float val = String2Float(m_mod_op->m_param1);
		m_mod_value[m_mod_op_index] = getValueByAttrModType(static_cast<eAttributeModType>(amt), val);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_dodge_multiple(m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_dodge_added(m_mod_value[m_mod_op_index]);
		}

	}
	else if ( AuraProcessStage_Remove == stage)
	{
		int amt = String2Int(m_mod_op->m_param0);
		if ( amt == ability::kAttributeModType_FixedScale )
		{
			m_owner->set_dodge_multiple(-m_mod_value[m_mod_op_index]);
		}
		else
		{
			m_owner->set_dodge_added(-m_mod_value[m_mod_op_index]);
		}
	}
}

}//ability
}//taomee