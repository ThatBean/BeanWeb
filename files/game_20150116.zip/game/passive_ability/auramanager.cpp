//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: auramanager.cpp
//        Author: vic.tang 
//       Version:
//          Date: 2014.11.05
//          Time: 18:20:00
//   Description: create
//
// History:
//      <author>    <time>      <version>   <descript>
//      vic.tang     18:20:00     1.0        create
//
//////////////////////////////////////////////////////////////

#include "auramanager.h"
#include "game/game_manager/data_manager.h"
#include "game/battle/battle_controller.h"
#include "engine/base/utils_string.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/unit_constants.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"

namespace taomee
{
namespace ability
{


AuraManager::AuraManager()
{
	aura_list_.clear();
}

AuraManager::~AuraManager()
{
	RemoveAllAura();
}

bool AuraManager::Update(float delta)
{
	if ( aura_del_list_.size() > 0 )
	{
		std::list<Aura*> aura_del_impl_list;
		aura_del_impl_list.assign(aura_del_list_.begin(), aura_del_list_.end());
		aura_del_list_.clear();

		for (std::list<Aura*>::iterator it = aura_del_impl_list.begin(); it != aura_del_impl_list.end(); ++it)
		{
			Aura* op = *it;
			op->ResetStatus();
			destroyAura(op, false);
		}
		aura_del_impl_list.clear();
	}
	

	for ( std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end();)
	{
		Aura* op = *it;
		if ( op->Update(delta)==false)
		{
			aura_del_list_.push_back(op);
			it = aura_list_.erase(it);
		}
		else
		{
			++it;
		}
	}

	return true;
}

Aura* AuraManager::createAura()
{
	Aura* obj = NULL;

	if ( idle_loop_.empty() )
	{
		obj = new Aura();
	}
	else
	{
		obj = idle_loop_.front();
		idle_loop_.pop();
	}

	return obj;
}
void AuraManager::destroyAura(Aura* obj, bool clearup)
{
	if ( clearup )
	{
		delete obj;
	}
	else
	{
		obj->Shutdown();
		idle_loop_.push( obj);
	}
}

bool AuraManager::AddAura(uint_32 owner_id, int aura_id, uint_32 caster_id,int_32 skill_id)
{
	army::MoveObject* owner = battle::BattleController::GetInstance().GetObjectById(owner_id);
	return AddAura( owner, aura_id, caster_id, skill_id);
}

bool AuraManager::AddAura(army::MoveObject* owner, int aura_id, uint_32 caster_id,int_32 skill_id)
{
	if ( owner == NULL )
	{
		return false;
	}

	const AuraData* auraData = DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id);
	if ( auraData == NULL )
	{
		return false;
	}

	if ( auraData->get_replace_rule() == kAuraReplaceRule_Coexist)
	{
		Aura* newAura = createAura();
		newAura->Initialize( owner, auraData, caster_id, skill_id);
		aura_list_.push_back( newAura );
	}
	else
	{
		Aura* findAura = FindAura( owner->move_object_id(), aura_id );
		if ( findAura == NULL )
		{
			findAura = createAura();
			findAura->Initialize( owner, auraData, caster_id, skill_id);
			aura_list_.push_back( findAura );
		}
		else
		{
			if (auraData->get_replace_rule() == kAuraReplaceRule_Replace)
			{
				findAura->aura_replace();
			}
			else if (auraData->get_replace_rule() == kAuraReplaceRule_Overlay)
			{
				findAura->aura_overlay_add();
			}
		}
	}

	return true;
}

void AuraManager::AddAuras(uint_32 move_obj_id, const std::string& auras, uint_32 caster_id, int_32 skill_id)
{
	std::vector<std::string> auraTypes = split(auras, "/");
	for (std::vector<std::string>::iterator it = auraTypes.begin(); it != auraTypes.end(); ++it)
	{
		int aura_id = atoi(it->c_str());
		this->AddAura( move_obj_id, aura_id, caster_id, skill_id);
	}
}

void AuraManager::AddAuras(const std::vector<uint_32>& move_obj_id_list, const std::string& auras, uint_32 caster_id, int_32 skill_id)
{
	for ( std::vector<uint_32>::const_iterator iter = move_obj_id_list.begin();
		iter != move_obj_id_list.end(); ++iter )
	{
		this->AddAuras(*iter, auras, caster_id, skill_id);
	}
}

void AuraManager::AddAurasFromSkill(army::MoveObject* master_obj, army::MoveObject* target_obj, int_32 skill_id)
{
	SkillBase* data = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
	std::string statusIdsString;
	int_32 succeed_rate = 0;
	// to self
	if (master_obj == target_obj)
	{
		succeed_rate = data->GetSelfStatusRatio();
		statusIdsString = data->GetSelfStatus();
	}
	// to friends
	else if (army::AreTwoMoveObjectsInTheSameForceHub(master_obj->move_object_id(),target_obj->move_object_id()))
	{
		succeed_rate = data->GetTagPlayerStatusRatio();
		statusIdsString = data->GetTagPlayerStatus();
	}
	// to enemy
	else
	{
		succeed_rate = data->GetTagStatusRatio();
		statusIdsString = data->GetTagStatus();
		if (data->GetBeatDown() && target_obj->repeal_distance_multiple()>0.0f)
		{
			if ( !target_obj->check_battle_status_flag(battle::kDamageStatusImmune) || 
				!target_obj->check_immune_status_flag(battle::kImmuneTypeControl))
			{
				if ( target_obj->motion_state() != ai::kMotionStateKO)
				{
					ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(target_obj, ai::kMotionStateKO);
				}
			}
		}
	}
	if ( !statusIdsString.empty() )
	{
		int rand_value = random_lower_upper(0,100);
		if ( succeed_rate > rand_value)
		{
			AddAuras(target_obj->move_object_id(), statusIdsString, master_obj->move_object_id(), skill_id);
		}
	}
}

void AuraManager::RemoveAuras(uint_32 move_obj_id, const std::string& auras)
{
	std::vector<std::string> auraTypes = split(auras, "/");
	for (std::vector<std::string>::iterator it = auraTypes.begin(); it != auraTypes.end(); ++it)
	{
		int aura_id = atoi(it->c_str());
		this->RemoveAura( move_obj_id, aura_id);
	}
}

void AuraManager::RemoveAuras(const std::vector<uint_32>& move_obj_id_list, const std::string& auras)
{
	for ( std::vector<uint_32>::const_iterator iter = move_obj_id_list.begin();
		iter != move_obj_id_list.end(); ++iter )
	{
		this->RemoveAuras(*iter, auras);
	}
}

bool AuraManager::RemoveAura( uint_32 owner_id, int aura_id )
{
	army::MoveObject* owner = battle::BattleController::GetInstance().GetObjectById(owner_id);
	return this->RemoveAura(owner, aura_id);
}

bool AuraManager::RemoveAura( army::MoveObject* owner, int aura_id )
{
	for ( std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end(); )
	{
		Aura* op = *it;
		if ( op->owner_obj_id() == owner->move_object_id() && op->get_aurd_id() == aura_id )
		{
			aura_del_list_.push_back(op);
			it = aura_list_.erase(it);
		}
		else
		{
			++it;
		}
	}

	return true;
}

bool AuraManager::RemoveAura(  army::MoveObject* owner, eAuraStatusFlags auraStatus )
{
	for ( std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end(); )
	{
		Aura* op = *it;
		if ( op->isEqualAuraStatus( auraStatus) )
		{
			aura_del_list_.push_back(op);
			it = aura_list_.erase(it);
		}
		else
		{
			++it;
		}
	}

	return true;
}

void AuraManager::RemoveShield(uint_32 owner_id, int aura_id)
{
	Aura* findAura = FindAura( owner_id, aura_id );
	if ( findAura )
	{
		findAura->over();
	}
}

bool AuraManager::RemoveAllDecreaseAura( army::MoveObject* owner )
{
	for ( std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end(); )
	{
		Aura* op = *it;
		if ( op->IsGains() == false )
		{
			aura_del_list_.push_back(op);
			it = aura_list_.erase(it);
		}
		else
		{
			++it;
		}
	}

	return true;
}

Aura* AuraManager::FindAura( uint_32 move_obj_id, int aura_id)
{
	for ( std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end(); ++it)
	{
		Aura* findAura = *it;
		if ( findAura->owner_obj_id() == move_obj_id && findAura->get_aurd_id() == aura_id )
		{
			return findAura;
		}
	}

	return NULL;
}

void AuraManager::RemoveAllAuraOnMoveObject(army::MoveObject* owner)
{
	for (std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end(); )
	{
		Aura* op = *it;
		if ( op->owner_obj_id() == owner->move_object_id())
		{
			aura_del_list_.push_back(op);
			it = aura_list_.erase(it);
		}
		else
		{
			++it;
		}
	}
} 

void AuraManager::RemoveAllAura()
{
	for (std::list<Aura*>::iterator it = aura_list_.begin(); it != aura_list_.end(); ++it)
	{
		Aura* op = *it;
		delete op;
	}
	aura_list_.clear();

	for (std::list<Aura*>::iterator it = aura_del_list_.begin(); it != aura_del_list_.end(); ++it)
	{
		Aura* op = *it;
		delete op;
	}
	aura_del_list_.clear();

	while ( !idle_loop_.empty() )
	{
		Aura* op = idle_loop_.front();
		delete op;
		idle_loop_.pop();
	}
}


}//ability
}//taomee