//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  passive_ability_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-11-7
//          Time:  11:03
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-11-7        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_passive_ability_constants_h
#define ChainChronicle_passive_ability_constants_h

#include "engine/base/basictypes.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
namespace ability {
  
enum eAbilityType
{
  kAbilityTypeNone          = 0,
  kAbilityTypeLessHp        = 1,
  kAbilityTypeFullHp        = 2,
  kAbilityTypeBossWave      = 3,
  kAbilityTypeNewWave       = 4,
  kAbilityTypeFitableTarget = 5,
  kAbilityTypeFitableGender = 6,
  kAbilityTypeFitableMap    = 7,
  kAbilityTypeBattleStart   = 8,
  kAbilityTypeThroughAll    = 9,  
  kAbilityTypeCriticalEffect= 10,
  kAbilityTypeHitEffect     = 11,
  kAbilityTypeStatusImmune  = 12,
  kAbilityTypeFireImmune    = 13,
  kAbilityTypeIceImmune     = 14,
  // miss 15
  kAbilityTypeNewWaveSelfHeal       = 16,
  kAbilityTypeHealByTime            = 17,
  kAbilityTypeBackstageInspire      = 18,
  kAbilityTypeAdvancedHeal          = 19,
  kAbilityTypeInspireFriends        = 20,
  kAbilityTypeDamageHealSelf        = 21,
  kAbilityTypeKillOne               = 22,
  kAbilityTypeCounter               = 23,
  kAbilityTypeComradesKilled        = 24,
  kAbilityTypeShield                = 25,
  kAbilityTypeExtraSkillPoint       = 26,
  kAbilityTypeExtraSkillProbability = 27,
  kAbilityTypeExtraSkillByKillOne   = 28,
  kAbilityTypeSkillEnhanced         = 29,
  kAbilityTypeNewWaveHealAll        = 30,
  kAbilityTypeNewWaveHealWeakest    = 31,
  kAbilityTypeTargetStatusSnipe     = 32,
  kAbilityTypeCriticalEnhanced      = 33,
  kAbilityTypeSelfStatusEnhanced    = 34,
  kAbilityTypeSameAbility           = 35,
  kAbilityTypeAmpleHp               = 36,
  kAbilityTypeMeleeAttackEnhanced   = 37,
  kAbilityTypeSkillExtraStatus      = 38,
  kAbilityTypeStatusHoldup          = 39,
  kAbilityTypeRepelHoldup           = 40,
  kAbilityTypePropertyBoost         = 41,
  kAbilityTypeInvisbility           = 42,
  // miss 43
  kAbilityTypeExtraGoldReward       = 100,
  kAbilityTypeExtraItemsReward      = 101,
  kAbilityTypeExtraXpReward         = 102,
  kAbilityTypeExtraApBackReward     = 103,
  kAbilityTypeMax,
};
  
enum eAbilityCreation
{
  kAbilityCreationUnkown,
  //Ĭ����Ч��
  kAbilityCreationDefault,
  //һ���Լ����Ч��
  kAbilityCreationCheckOnce,
  //ʵʱ�����Ч��
  kAbilityCreationUpdate,
  //����ʽ��Ч��
  kAbilityCreationTriggerOut,
  //����ʽʧЧ��
  kAbilityCreationTriggerOff,
  //����״̬��
  kAbilityCreationExtraData,
};
  
enum eStatusType
{
  kStatusTypeUnkown                 = -1,
  kStatusTypeCreatedByAbility       = 0,
  // ���Ӳ���״̬
  kStatusTypeAtomicAddition         = 1,
  // ��������״̬
  kStatusTypeAtomicElimination      = 2,
  // ���Թ�����ǿ
  kStatusTypePropertyDamageBoost    = 3,
  // ��ͨ������ǿ
  kStatusTypeNormalHitEnhance       = 4,
  // ����
  kStatusTypeAbsorbByTimes         = 5,
  // ����-�ָ�
  kStatusTypeHealWithValue         = 6,
  // ���ӹ���
  kStatusTypeAttackSpeedEnhance    = 7,
  // ��������
  kStatusTypeImmune					= 8,
  // ������Ѫ
  kStatusTypeHematophagia			= 9,
  // ���ӷ���
  kStatusTypeThorns					= 10,
  // ���ӱ�������
  kStatusTypeCriticalProbability	= 11,
  // ���ӷ���
  kStatusTypeDefense	= 12,
  kStatusTypeMax,
};
  
enum
{
  kUnexistAbilityId       = -1,
  kUnexistStatusId        = -1,
  kUnExistSequenceId      = -1,
};
  
enum eConditionsCheckSwitch
{
  kCheckNone              = 0x00,
  kCheckNormalWave        = 1<<1,
  kCheckEnemiesDeath      = 1<<2,
  kCheckFriendsDeath      = 1<<3,
  kCheckUnitDeath         = (1<<2)|(1<<3),
  kCheckSpecialStatus     = 1<<4,
  kCheckSameAbilityId     = 1<<5,
  kCheckFitableMapId      = 1<<6,
  kCheckCriticalHit       = 1<<7,
  kCheckNormalHit         = (1<<7)|(1<<8),
  kCheckSkillHit          = 1<<9,
  kCheckHurtedByEnemy     = 1<<10,
  kCheckBossWave          = (1<<11),
  kCheckNewWave           = (1<<11)|(1<<1),
  kCheckHealedByFriends   = 1<<12,
  kCheckActivateNewUnit   = 1<<13,
  kCheckMax,
};
  
enum eTargetSelectConditionType
{
  kTargetSelectTypeNone,
  kTargetSelectTypeAll,
  kTargetSelectTypeSpecialCareerExceptSelf,
  kTargetSelectTypeWeakest,
  kTargetSelectTypeStongest,
  kTargetSelectTypeMax,
};
  
enum eCompareType
{
  kCompareLessThan      = 0,
  kCompareNoMoreThan    = 1,
  kCompareEqualTo       = 2,
  kCompareNoLessThan    = 3,
  kCompareMoreThan      = 4,
  kCompareBitAnd        = 5,
};
  
struct sAborsbShield
{
  uint_32   buff_id_;
  int_32    absorb_value_;
  uint_32   flag_;
};

// (1-9999Ϊ������10000����Ϊbuffid)
const uint_16 kBuffIdStartIndex     = 0;
  
bool CompareBySymbol(float leftParam, eCompareType symbol, float rightParam);
  
uint_32 GetStatusUniqueId(uint_16 buffId, uint_32 unitId);
  
eAbilityCreation GetCreationByType(int type);
  
bool IsStatusBindingWithAbilityInstanceType(eAbilityType type);
  
} // namespace ability
} // namespace taomee

#endif // ChainChronicle_passive_ability_constants_h
