//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: EventBattle.h
//        Author: coldouyang
//          Date: 2014/11/12 14:05
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/11/12      add
//////////////////////////////////////////////////////////////

#ifndef EVENT_BATTLE_H
#define EVENT_BATTLE_H

#include "engine/event_system/receiver.h"
#include "engine/event_system/multi_receiver.h"
#include "engine/event_system/event.h"
#include "engine/event_system/event_manager.h"

namespace taomee
{

#define EventBattleConstruction(T) \
public:\
  T(int event_id):Event(event_id){}\
  virtual ~T(){}\
  static T* create(int event_id)\
  {\
  T *pRet = new T(event_id);\
  pRet->autorelease();\
  return pRet;\
}\

//����ս��״̬�л����¼�
class EventBattleStateChange : public Event
{
  EventBattleConstruction(EventBattleStateChange)
public:
};



}
#endif