//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: EventBattleObj.h
//        Author: coldouyang
//          Date: 2014/11/12 14:05
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/11/12      add
//////////////////////////////////////////////////////////////

#ifndef EVENT_BATTLE_OBJ_H
#define EVENT_BATTLE_OBJ_H

#include "engine/event_system/receiver.h"
#include "engine/event_system/event.h"
#include "engine/event_system/event_manager.h"

namespace taomee
{

#define EventSubclassConstruction(T) \
public:\
	T(int event_id):Event(event_id){}\
	virtual ~T(){}\
	static T* create(int event_id)\
	{\
	T *pRet = new T(event_id);\
	pRet->autorelease();\
	pRet->Reset();\
	return pRet;\
}\

//����ս����ɫ״̬�л����¼�
class EventBattleObj : public Event
{
  EventSubclassConstruction(EventBattleObj)
public:
	void Reset()
	{
	}
};

class EventBossReleaseSkill : public Event
{
  EventSubclassConstruction(EventBossReleaseSkill)
public:
	void Reset()
	{
		move_obj_id_ = army::kUnexistTargetId;
		skill_id_ = 0;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("EventBossReleaseSkill");
		}
		assert( event_id != 0);
		return event_id;
	}
	static void Emit(uint_32 move_obj_id, uint_32 skill_id)
	{
		EventBossReleaseSkill* evt = EventBossReleaseSkill::create(getEventIDWithName());
		evt->skill_id_ = skill_id;
		evt->move_obj_id_ = move_obj_id;
		EventManager::GetInstance().Emit(evt);
	}

  int skill_id_;
  int move_obj_id_;
};

// ���󹥻�
class HitEvent : public Event
{
	EventSubclassConstruction(HitEvent)
public:
	void Reset()
	{
		m_owner_id_ = army::kUnexistTargetId;
		m_target_id_ = army::kUnexistTargetId;
		m_attack_type_ = battle::kAttackResultUnkown;
		m_skill_id_ = 0;
		m_enable_infect = true;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("HitEvent");
		}
		assert( event_id != 0);
		return event_id;
	}
	static void Emit(uint_32 owner_id, uint_32 target_id, int attack_type, uint_32 skill_id, bool enable_fect)
	{
		HitEvent *evt = HitEvent::create(getEventIDWithName());
		evt->m_owner_id_ = owner_id;
		evt->m_target_id_ = target_id;
		evt->m_attack_type_ = attack_type;
		evt->m_skill_id_ = skill_id;
		evt->m_enable_infect = enable_fect;
		EventManager::GetInstance().Emit(evt);
	}

	uint_32 m_owner_id_;
	uint_32 m_target_id_;
	int m_attack_type_; // eAttackResult
	int m_skill_id_;
	bool m_enable_infect;
};

// ���󱻹���
class ByHitEvent : public Event
{
	EventSubclassConstruction(ByHitEvent)
public:
	void Reset()
	{
		m_owner_id_ = army::kUnexistTargetId;
		m_target_id_ = army::kUnexistTargetId;
		m_attack_type_ = battle::kAttackResultUnkown;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("ByHitEvent");
		}
		assert( event_id != 0);
		return event_id;
	}
	static void Emit(uint_32 owner_id, uint_32 target_id, int attack_type)
	{
		ByHitEvent *evt = ByHitEvent::create(getEventIDWithName());
		evt->m_owner_id_ = owner_id;
		evt->m_target_id_ = target_id;
		evt->m_attack_type_ = attack_type;
		EventManager::GetInstance().Emit(evt);
	}

	uint_32 m_owner_id_;
	uint_32 m_target_id_;
	int m_attack_type_; // eAttackResult
};

// �������
class MoveObjBornEvent : public Event
{
	EventSubclassConstruction(MoveObjBornEvent)
public:
	void Reset()
	{
		m_move_obj_id_ = army::kUnexistTargetId;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("MoveObjBornEvent");
		}
		assert( event_id != 0);
		return event_id;
	}
	static void Emit(uint_32 move_obj_id)
	{
		MoveObjBornEvent *evt = MoveObjBornEvent::create(getEventIDWithName());
		evt->m_move_obj_id_ = move_obj_id;
		EventManager::GetInstance().Emit(evt);
	}

	uint_32 m_move_obj_id_;
};

// ��������
class MoveObjDeadEvent : public Event
{
	EventSubclassConstruction(MoveObjDeadEvent)
public:
	void Reset()
	{
		m_move_obj_id_ = army::kUnexistTargetId;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("MoveObjDeadEvent");
		}
		assert( event_id != 0);
		return event_id;
	}

	static void Emit(uint_32 move_obj_id)
	{
		MoveObjDeadEvent *evt = MoveObjDeadEvent::create(getEventIDWithName());
		evt->m_move_obj_id_ = move_obj_id;
		EventManager::GetInstance().Emit(evt);
	}

	uint_32 m_move_obj_id_;
};

// ս���غ�
class BattleSceneTypeEvent : public Event
{
	EventSubclassConstruction(BattleSceneTypeEvent)
public:
	void Reset()
	{
		m_battle_scene_type = 0;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("BattleSceneTypeEvent");
		}
		assert( event_id != 0);
		return event_id;
	}
	static void Emit( int bst )
	{
		BattleSceneTypeEvent* evt = BattleSceneTypeEvent::create(getEventIDWithName());
		evt->m_battle_scene_type = bst;
		EventManager::GetInstance().Emit(evt);
	}

	int m_battle_scene_type; // eBattleSceneType
};

// �����ͷż��ܽ���
class ReleaseSkillOverEvent : public Event
{
	EventSubclassConstruction(ReleaseSkillOverEvent)
public:
	void Reset()
	{
		m_move_obj_id_ = army::kUnexistTargetId;
		m_skill_id_ = 0;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("ReleaseSkillOverEvent");
		}
		return event_id;
	}
	static void Emit(uint_32 move_obj_id, int_32 skill_id)
	{
		ReleaseSkillOverEvent* evt = ReleaseSkillOverEvent::create(getEventIDWithName());
		evt->m_move_obj_id_ = move_obj_id;
		evt->m_skill_id_ = skill_id;
		EventManager::GetInstance().Emit(evt);
	}

	uint_32 m_move_obj_id_;
	int_32 m_skill_id_;
};

// �������
class MoveObjFirstInPlace : public Event
{
	EventSubclassConstruction(MoveObjFirstInPlace)
public:
	void Reset()
	{
		m_move_obj_id_ = army::kUnexistTargetId;
	}
public:
	static int getEventIDWithName()
	{
		static int event_id = 0;
		if ( event_id == 0 )
		{
			event_id = EventManager::getEventIDWithName("MoveObjFirstInPlace");
		}
		return event_id;
	}
	static void Emit(uint_32 move_obj_id)
	{
		MoveObjFirstInPlace* evt = MoveObjFirstInPlace::create(getEventIDWithName());
		evt->m_move_obj_id_ = move_obj_id;
		EventManager::GetInstance().Emit(evt);
	}

	uint_32 m_move_obj_id_;
};

}
#endif