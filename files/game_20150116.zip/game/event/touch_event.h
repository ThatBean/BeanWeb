//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: touch_event.h
//        Author: Sachin
//          Date: 2014/3/3 11:40
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Sachin    2014/3/3      add
//////////////////////////////////////////////////////////////

#ifndef TOUCH_EVENT_H
#define TOUCH_EVENT_H

#include "engine/event_system/event.h"

namespace taomee
{
namespace event
{

class TouchEvent :public Event
{
public:
	TouchEvent(int event_id):Event(event_id){}
	static TouchEvent* create(int event_id)
	{
		TouchEvent *pRet = new TouchEvent(event_id);
		pRet->autorelease();
		return pRet;
	}
	virtual ~TouchEvent(){}
	int get_parm_id(){return parm_id_;}
	void set_parm_id(int parm_id) {parm_id_ = parm_id;}

private:
	int parm_id_;
};

} // namespace event
} // namespace taomee
#endif //TOUCH_EVENT_H