//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: universal_event.h
//        Author: Sachin
//          Date: 2014/3/4 20:35
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Sachin    2014/3/4      add
//////////////////////////////////////////////////////////////

#ifndef UNIVERSAL_EVENT_H
#define UNIVERSAL_EVENT_H
#include "engine/event_system/event.h"

namespace taomee
{
namespace event
{

class UniversalEventWithIdParm :public Event
{
public:
	UniversalEventWithIdParm(int event_id):Event(event_id){}
	virtual ~UniversalEventWithIdParm(){}
	
	static UniversalEventWithIdParm* create(int event_id)
	{
		UniversalEventWithIdParm *pRet = new UniversalEventWithIdParm(event_id);
		pRet->autorelease();
		return pRet;
	}
	int get_parm_id(){return parm_id_;}
	void set_parm_id(int parm_id) {parm_id_ = parm_id;}

private:
	int parm_id_;
};

class UniversalEventWithCCArryParm :public Event
{
public:
	UniversalEventWithCCArryParm(int event_id):Event(event_id), arr_parm_(NULL){};
	virtual ~UniversalEventWithCCArryParm(){CC_SAFE_RELEASE_NULL(arr_parm_);};
	static UniversalEventWithCCArryParm* create(int event_id)
	{
		UniversalEventWithCCArryParm *pRet = new UniversalEventWithCCArryParm(event_id);
		pRet->autorelease();
		return pRet;
	}
	CCArray* get_arr_parm(){return arr_parm_;}
	void set_arr_parm(CCArray* arr_parm) {CC_SAFE_RETAIN(arr_parm);arr_parm_ = arr_parm;}

private:
	CCArray* arr_parm_;
};


} // namespace event
} // namespace taomee

#endif //UNIVERSAL_EVENT_H