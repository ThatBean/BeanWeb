//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_state.h
//        Author: leohou
//       Version:
//          Date: Oct 20, 2013
//          Time: 10:18:30 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     10:18:30 PM
//
//////////////////////////////////////////////////////////////

#ifndef BATTLE_STATE_H_
#define BATTLE_STATE_H_

#include "engine/base/basictypes.h"
#include "engine/base/state_machine/state.h"

namespace taomee {
namespace battle {

class BattleController;

// state request session
class BattleStateRequestSession : public State<BattleController> {
public:
  virtual ~BattleStateRequestSession();

  static BattleStateRequestSession* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStateRequestSession();
  DISALLOW_COPY_AND_ASSIGN(BattleStateRequestSession);
};

// state prepare
class BattleStatePrepare : public State<BattleController> {
public:
  virtual ~BattleStatePrepare();

  static BattleStatePrepare* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStatePrepare();
  DISALLOW_COPY_AND_ASSIGN(BattleStatePrepare);

};

// state load resource
class BattleStateLoadResource : public State<BattleController> {
public:
  virtual ~BattleStateLoadResource();

  static BattleStateLoadResource* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);
private:
  BattleStateLoadResource();
  DISALLOW_COPY_AND_ASSIGN(BattleStateLoadResource);

};

// state drama
class BattleStateDrama : public State<BattleController> {
public:
  virtual ~BattleStateDrama();

  static BattleStateDrama* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStateDrama();
  DISALLOW_COPY_AND_ASSIGN(BattleStateDrama);

};

// state pvp_prepare
class BattleStatePvpPrepare : public State<BattleController> {
public:
  virtual ~BattleStatePvpPrepare();

  static BattleStatePvpPrepare* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  float time_delay_;
  BattleStatePvpPrepare();
  DISALLOW_COPY_AND_ASSIGN(BattleStatePvpPrepare);
};

// state battle
class BattleStateBattle : public State<BattleController> {
public:
  virtual ~BattleStateBattle();

  static BattleStateBattle* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStateBattle();
  DISALLOW_COPY_AND_ASSIGN(BattleStateBattle);

};

// state pause
class BattleStatePause : public State<BattleController> {
public:
  virtual ~BattleStatePause();

  static BattleStatePause* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStatePause();
  DISALLOW_COPY_AND_ASSIGN(BattleStatePause);
};

// state result session
class BattleStateResultSession : public State<BattleController> {
public:
  virtual ~BattleStateResultSession();

  static BattleStateResultSession* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStateResultSession();
  DISALLOW_COPY_AND_ASSIGN(BattleStateResultSession);
};

// state win
class BattleStateWin : public State<BattleController> {
public:
  virtual ~BattleStateWin();

  static BattleStateWin* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStateWin();
  DISALLOW_COPY_AND_ASSIGN(BattleStateWin);

};

// state lose
class BattleStatePvpLose : public State<BattleController> {
public:
  virtual ~BattleStatePvpLose();

  static BattleStatePvpLose* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStatePvpLose();
  DISALLOW_COPY_AND_ASSIGN(BattleStatePvpLose);

};

// state failed
class BattleStateFailed : public State<BattleController> {
public:
  virtual ~BattleStateFailed();

  static BattleStateFailed* Instance();

  virtual void Enter(BattleController* battle_controller);
  virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
  virtual void Exit(BattleController* battle_controller);

private:
  BattleStateFailed();
  DISALLOW_COPY_AND_ASSIGN(BattleStateFailed);

};

class BattleStateOver : public State<BattleController> {
public:
	virtual ~BattleStateOver();

	static BattleStateOver* Instance();

	virtual void Enter(BattleController* battle_controller);
	virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
	virtual void Exit(BattleController* battle_controller);

private:
	BattleStateOver();
	DISALLOW_COPY_AND_ASSIGN(BattleStateOver);

};

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_STATE_H_ */
