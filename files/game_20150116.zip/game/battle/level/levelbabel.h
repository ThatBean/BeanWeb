

#ifndef Battle_Level_Babel_H
#define Battle_Level_Babel_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelmission.h"

namespace taomee {

namespace battle {

class LevelBabel : public LevelMission
{
public:
	LevelBabel();
  virtual ~LevelBabel();

public:
  virtual void Initialize(int curr_checkpoint_id);
  virtual void createUnit();	
  virtual void notifyPlayerDead(uint_32 player_id, bool final);
  virtual void notifyBattleResultCompeleted();
public:

	virtual void Update(float delta);

protected:

	int m_dead_player;
};

}//namespace battle
}//namespace taomee

#endif