
#include "levelpvp.h"
#include "game/battle/battle_pvp_data.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_state.h"
#include "engine/base/state_machine/state_machine.h"
#include "game/game_manager/data_manager.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"

namespace taomee {
namespace battle {

LevelPvp::LevelPvp()
{
	m_battle_main_type = kBattleType_Pvp;
	battle_win_delay_time_ = 1.2f;
}

LevelPvp::~LevelPvp()
{

}
void LevelPvp::notifyBattleStart()
{
	m_battle_controller->GetStateMachine()->ChangeState(BattleStateRequestSession::Instance());
}

void LevelPvp::notifyBattleResourceLoadedEnd()
{
	m_battle_controller->GetStateMachine()->ChangeState(BattleStatePvpPrepare::Instance());
}

void LevelPvp::createUnit()
{
	m_own_hub->born_hub()->CreatePvpGroup();
	m_monster_hub->born_hub()->CreatePvpGroup();
}

BattleData* LevelPvp::createBattleData()
{
	BattleData* battle_data = new BattlePvpData();
	return battle_data;
}

BattleHub* LevelPvp::createMonsterHub()
{
	OwnHub* pvpEnemyHub = new OwnHub(false);
	return pvpEnemyHub;
}

void LevelPvp::InitBattleHubsData()
{
	BattlePvpData* battle_pvp_data_ = dynamic_cast<BattlePvpData*>(m_battle_data);
	const std::vector<taomee::net::arena_before_challenge_out::Self_team>& self_data = battle_pvp_data_->getSelfData();
	for (int i = 0;  i < self_data.size(); ++i)
	{
		const taomee::net::arena_before_challenge_out::Self_team& data = self_data.at(i);
		PvpCharacterCreatationInfo info;
		info.unit_id_ = army::kCharaterObject_StartId + i;
		info.card_id_ = data.get_cardid();
		info.level_ = 1;
		info.is_friend_ = false;
		info.hp_ = data.get_hp();
		info.physics_attack_ = data.get_attack();
		info.magic_attack_ = 0;////////////////////////////////////////////////
		info.dodge = 0;///////////////////////////////////////////////
		info.hit_rate = 0;////////////////////////////////////////////////
		info.pdef_ = data.get_pdef();
		info.mdef_ = data.get_mdef();
		info.fdamage_ = data.get_fdamage();
		info.fundamage_ = data.get_fundamage();
		dynamic_cast<OwnHub*>(m_own_hub)->CreateOnePvpCharacter(info.unit_id_, info);
	}

	const std::vector<taomee::net::arena_before_challenge_out::Oppo_team>& oppo_data = battle_pvp_data_->getOppoData();
	for (int i = 0;  i < oppo_data.size(); ++i)
	{
		const taomee::net::arena_before_challenge_out::Oppo_team& data = oppo_data.at(i);
		taomee::battle::PvpCharacterCreatationInfo info;
		info.unit_id_ = army::kPvPCharaterObject_StartId + i;
		info.card_id_ = data.get_cardid();
		info.level_ = 1;
		info.is_friend_ = false;
		info.hp_ = data.get_hp();
		info.physics_attack_ = data.get_attack();
		info.magic_attack_ = 0;//////////////////////////////////////
		info.dodge = 0;/////////////////////////////////////////////
		info.hit_rate = 0;////////////////////////////////////////
		info.pdef_ = data.get_pdef();
		info.mdef_ = data.get_mdef();
		info.fdamage_ = data.get_fdamage();
		info.fundamage_ = data.get_fundamage();
		dynamic_cast<OwnHub*>(m_monster_hub)->CreateOnePvpCharacter(info.unit_id_, info);
	}
}

void LevelPvp::Update(float delta)
{
	if ( m_battle_over )
	{
		if ( battle_win_delay_time_ >= 0.0f )
		{
			battle_win_delay_time_ -= delta;
			if ( battle_win_delay_time_ < 0.0f)
			{
				onFightResult();
			}
		}
		return;
	}

	LevelBase::Update(delta);

	float pvp_max_time_tick = m_battle_data->getPvpLimitTime();
	if ( m_time_tick > pvp_max_time_tick )
	{
		switchBattleState( kBattleStateFailed );
	}

	if ( isBattleWin())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(true);
		onFightEnd();
	}
	else if ( isBattleFailed() || isBattleQuit())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(false);
		onFightEnd();
	}
}

void LevelPvp::notifyBattleResultCompeleted()
{
	if (this->isBattleWin())
	{  //PVP��ս��Ʒ�Ѿ�����
		m_battle_controller->GetStateMachine()->ChangeState(BattleStateWin::Instance());
	}
	else if (this->isBattleFailed() || this->isBattleQuit())
	{
		//ʧ��ս��Ʒ����
		m_battle_controller->End();
	}
	else
	{
		assert(false);
	}
}

void LevelPvp::notifyAddAllGainDataIntoUserInfoAfterBattleWin()
{
	DataManager::GetInstance().user_info()->AddGold( m_battle_data->gain_gold() );
	DataManager::GetInstance().user_info()->AddXp(m_battle_data->gain_xp_for_player());  
	DataManager::GetInstance().user_info()->AddAp(m_battle_data->gain_ap());
}

void LevelPvp::notifyCharacterLevelupChecking()
{
	m_battle_controller->battle_ui()->ShowRewardForPlayer();
}

void LevelPvp::notifyPlayerRankUpChecking()
{
	uint_16 original_rank = m_battle_data->original_rank();
	assert( original_rank <= DataManager::GetInstance().user_info()->rank());
	// not rank up in this battle
	if ( original_rank == DataManager::GetInstance().user_info()->rank())
	{
		m_battle_controller->ShowNewCard();
	}
	else // rank up
	{
		m_battle_controller->battle_ui()->RankUpToNextLevelForPlayerWithOriginalRank( original_rank );
	}
}

void LevelPvp::onFightEnd()
{
	cocos2d::CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.0f);
	m_battle_controller->fightEnd();
	if ( isBattleFailed() || isBattleQuit())
	{
		m_battle_controller->GetStateMachine()->ChangeState(BattleStateFailed::Instance());
	}
}

void LevelPvp::onFightResult()
{
	m_battle_controller->GetStateMachine()->ChangeState(BattleStateResultSession::Instance());
}


}//namespace battle
}//namespace taomee