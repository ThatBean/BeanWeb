

#ifndef Battle_Level_Elite_H
#define Battle_Level_Elite_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelmission.h"

namespace taomee {

namespace battle {

class LevelElite : public LevelMission
{
public:
	LevelElite();
	virtual ~LevelElite();

public:

	virtual void Update(float delta);

protected:
};

}//namespace battle
}//namespace taomee

#endif