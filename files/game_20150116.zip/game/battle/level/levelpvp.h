

#ifndef Battle_Level_Pvp_H
#define Battle_Level_Pvp_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelbase.h"

namespace taomee {

namespace battle {

class LevelPvp : public LevelBase
{
public:
	LevelPvp();
	virtual ~LevelPvp();

public:
	virtual void createUnit();
public:
	virtual void notifyBattleStart();
	virtual void notifyBattleResourceLoadedEnd();
	virtual void notifyBattleResultCompeleted();
	virtual void notifyAddAllGainDataIntoUserInfoAfterBattleWin();
	virtual void notifyCharacterLevelupChecking();
	virtual void notifyPlayerRankUpChecking();
protected:
	virtual void onFightEnd();
	virtual void onFightResult();
protected:
	virtual BattleData* createBattleData();
	virtual BattleHub* createMonsterHub();
	virtual void InitBattleHubsData();
public:

public:

	virtual void Update(float delta);

protected:
	
};

}//namespace battle
}//namespace taomee

#endif