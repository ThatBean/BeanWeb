
#include "levelbreak.h"
#include "game/battle/battle_data.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_controller.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/army/unit/move_object.h"
#include "game/game_manager/data_manager.h"

namespace taomee {

namespace battle {

LevelBreak::LevelBreak()
	: m_world_boss_id(army::kUnexistTargetId)
{
	m_battle_main_type = kBattleType_Main;
	m_battle_sub_type = kBattleSubType_Break;
}

LevelBreak::~LevelBreak()
{

}

void LevelBreak::notifyMonsterBorn(uint_32 monster_id)
{
	if ( m_world_boss_id == army::kUnexistTargetId )
	{
		army::MoveObject* monster = m_monster_hub->GetUnitById(monster_id);
		if ( monster )
		{
			CharacterData* characData = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(monster->card_id());
			if ( characData && characData->GetMonsterLevel() > kMonsterLevelNormal/* == kMonsterLevelWorldBoss*/)
			{
				m_world_boss_id = monster_id;
			}
		}
	}
}

void LevelBreak::notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave)
{
	if ( last_wave)
	{
		if ( last_one )
		{
			switchBattleState(kBattleStateOver);
		}
	}
	else
	{
		if ( last_one)
		{
			MonsterHub* monster_hub = dynamic_cast<MonsterHub*>(m_monster_hub);
			monster_hub->emitNextWaveMonster();
		}
	}
}

void LevelBreak::notifyPlayerDead(uint_32 player_id, bool last_one)
{
	if ( last_one )
	{
		switchBattleState(kBattleStateOver);
	}
}

void LevelBreak::Update(float delta)
{
	if ( m_battle_over )
	{
		if ( battle_win_delay_time_ >= 0.0f )
		{
			battle_win_delay_time_ -= delta;
			if ( battle_win_delay_time_ < 0.0f)
			{
				onFightResult();
			}
		}
		return;
	}

	LevelBase::Update( delta);

	float battle_time_limit = m_battle_data->GetBattleTimeLimitForCurrnetCheckPoint();
	if ( m_time_tick >= battle_time_limit )
	{
		switchBattleState(kBattleStateOver);
	}
	
	if (isBattleOver())
	{
		if ( m_world_boss_id != army::kUnexistTargetId )
		{
			army::MoveObject* monster = m_monster_hub->GetUnitById(m_world_boss_id);
			if ( monster )
			{
				int bearDamage = monster->get_bear_damage();
				int grade = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
					"script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "GetBattleGrade",
					 bearDamage);
				m_battle_data->set_pass_grade(grade);
			}
		}

		m_battle_over = true;
		m_battle_data->set_battle_win(true);
		onFightEnd();
	}
	else if ( isBattleQuit())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(false);
		onFightEnd();
	}
}

}//namespace battle
}//namespace taomee