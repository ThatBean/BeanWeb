

#ifndef Battle_Level_Base_H
#define Battle_Level_Base_H

#include "game/battle/battle_constants.h"

namespace taomee {

namespace battle {

class BattleData;
class BattleHub;
class BattleController;

class LevelBase
{
public:
	LevelBase();
	virtual ~LevelBase() = 0;

	virtual void Initialize(int curr_checkpoint_id);

	virtual void createBattleHubs();
	virtual void createUnit();
	virtual void battleRevive();
	virtual void battleClearTroop();
public:
	
	virtual void notifyBattleResourceLoadedEnd();
	virtual void notifyQuitByPlayer();
	virtual void notifyMonsterMoveToRightBorder(uint_32 monster_id);
	virtual void notifyMoveObjBorn(uint_32 move_obj_id);
	virtual void notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave);
	virtual void notifyPlayerDead(uint_32 player_id, bool last_one);

	virtual void notifyBattleStart();
	virtual void notifyBattleEnd();
	virtual void notifyBattleResultCompeleted();
	virtual void notifyAddAllGainDataIntoUserInfoAfterBattleWin();
	virtual void notifyCharacterLevelupChecking();
	virtual void notifyPlayerRankUpChecking();
protected:
	virtual void onFightEnd();
	virtual void onFightResult();
protected:
	virtual BattleData* createBattleData() = 0;

	virtual BattleHub* createOwnHub();
	virtual BattleHub* createMonsterHub() = 0;
	virtual void InitBattleHubsData();
	
public:
	BattleHub* getOwnHub();
	BattleHub* getMonsterHub();

	BattleData* getBattleData();

	eBattleType getBattleType();

	eBattleSubType getBattleSubType();

	eBattleStateFlag getBattleStateFlag();

	void switchBattleState(eBattleStateFlag newState);
	
	bool isBattleWin();
	bool isBattleFailed();
	bool isBattleOver();
	bool isBattleTimeout();
	bool isBattleQuit();

public:

	virtual void Update(float delta);

protected:
	BattleController* m_battle_controller;

	BattleHub* m_own_hub;
	BattleHub* m_monster_hub;

	bool m_battle_over;

	eBattleType m_battle_main_type;

	eBattleSubType m_battle_sub_type;

	eBattleStateFlag    m_battle_state;

	BattleData* m_battle_data;

	float m_time_tick;
	float battle_win_delay_time_;
};

}//namespace battle
}//namespace taomee

#endif