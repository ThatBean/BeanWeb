

#ifndef Battle_Level_Sandbox_H
#define Battle_Level_Sandbox_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelbase.h"

namespace taomee {

namespace battle {

class LevelSandbox : public LevelBase
{
public:
	LevelSandbox();
	virtual ~LevelSandbox();

public:
	
protected:
	virtual BattleData* createBattleData();
	virtual BattleHub* createMonsterHub();
public:
	virtual void notifyBattleStart();
	virtual void notifyBattleResourceLoadedEnd();
public:

	virtual void Update(float delta);

protected:

};

}//namespace battle
}//namespace taomee

#endif