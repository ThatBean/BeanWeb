

#ifndef Battle_Level_Break_H
#define Battle_Level_Break_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelmission.h"

namespace taomee {

namespace battle {

class LevelBreak : public LevelMission
{
public:
	LevelBreak();
	virtual ~LevelBreak();

public:
	virtual void notifyMonsterBorn(uint_32 monster_id);
	virtual void notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave);
	virtual void notifyPlayerDead(uint_32 player_id, bool last_one);

public:

	virtual void Update(float delta);

protected:
	uint_32 m_world_boss_id;
};

}//namespace battle
}//namespace taomee

#endif