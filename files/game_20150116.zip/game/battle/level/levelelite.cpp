
#include "levelelite.h"
#include "game/battle/battle_data.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_controller.h"
#include "engine/script/lua_tinker_manager.h"


namespace taomee {

namespace battle {

LevelElite::LevelElite()
{
	m_battle_main_type = kBattleType_Main;
	m_battle_sub_type = kBattleSubType_Elite;
}

LevelElite::~LevelElite()
{

}

void LevelElite::Update(float delta)
{
	LevelMission::Update(delta);
	
}

}//namespace battle
}//namespace taomee