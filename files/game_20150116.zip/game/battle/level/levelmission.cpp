
#include "levelmission.h"
#include "game/battle/battle_data.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_controller.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/battle/battle_state.h"
#include "engine/base/state_machine/state_machine.h"
#include "game/event/universal_event.h"
#include "game/game_manager/data_manager.h"
#include "engine/event_system/event_manager.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"

namespace taomee {

namespace battle {

LevelMission::LevelMission()
{
	m_battle_main_type = kBattleType_Main;
	m_battle_sub_type = kBattleSubType_Mission;
	battle_win_delay_time_ = 1.2f;
}

LevelMission::~LevelMission()
{
	
}

void LevelMission::notifyBattleStart()
{
	m_battle_controller->GetStateMachine()->ChangeState(BattleStateRequestSession::Instance());
}

void LevelMission::notifyBattleResourceLoadedEnd()
{
	m_battle_controller->GetStateMachine()->ChangeState(BattleStateDrama::Instance());
}

BattleHub* LevelMission::createMonsterHub()
{
	MonsterHub* pvpEnemyHub = new MonsterHub();
	return pvpEnemyHub;
}

void LevelMission::createUnit()
{
	OwnHub* ownHub = dynamic_cast<OwnHub*>(m_own_hub);
	if ( ownHub )
	{
		if (ownHub->creatation_list().size())
		{
			ownHub->born_hub()->CreateAvatorGroupForNewPlayersGuide();
		} 
		else
		{
			ownHub->born_hub()->CreateTeamByBattleType(kBattleType_Main);
		}
	}
}

void LevelMission::battleRevive()
{
	LevelBase::battleRevive();

	MonsterHub* monster_hub = dynamic_cast<MonsterHub*>(m_monster_hub);
	monster_hub->SaveUnkilledMonstersIdList();
	monster_hub->troops()->ClearAllMoveObjects();
	monster_hub->Restart(); 
}

void LevelMission::battleClearTroop()
{
	LevelBase::battleClearTroop();

	MonsterHub* monster_hub = dynamic_cast<MonsterHub*>(m_monster_hub);
	//monster_hub_->SaveUnkilledMonstersIdList();
	monster_hub->troops()->ClearAllMoveObjects();
	monster_hub->Restart();
}

BattleData* LevelMission::createBattleData()
{
	BattleData* battle_data = new BattleData();
	return battle_data;
}

void LevelMission::Update(float delta)
{
	if ( m_battle_over )
	{
		if ( battle_win_delay_time_ >= 0.0f )
		{
			battle_win_delay_time_ -= delta;
			if ( battle_win_delay_time_ < 0.0f)
			{
				if ( m_time_tick <= m_battle_data->GetBattleTimeLimitForCurrnetCheckPoint())
				{
					m_battle_data->set_battle_constions_flag(kBattleWinTypeInTime);
				}
				onFightResult();
			}
		}
		return;
	}

	LevelBase::Update(delta);

	if ( isBattleWin())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(true);
		onFightEnd();
	}
	else if ( isBattleFailed() || isBattleQuit())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(false);
		onFightEnd();
	}
}

void LevelMission::notifyBattleResultCompeleted()
{
	if (this->isBattleWin() || isBattleOver())
	{
		event::UniversalEventWithIdParm* battle_win_event = event::UniversalEventWithIdParm::create(2000);
		int current_checkpoint_id = m_battle_data->current_checkpoint_id();
		// take out ap
		int_32 need_ap =  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua", "QueryCheckPointCostAp", current_checkpoint_id);
		if( need_ap>=0 )//�����Ҫ�����Ĺؿ� �۳����õ�
		{
			DataManager::GetInstance().user_info()->AddAp(0-need_ap);
		}

		battle_win_event->set_parm_id(current_checkpoint_id);
		EventManager::GetInstance().Emit(battle_win_event);

		m_battle_controller->GetStateMachine()->ChangeState(BattleStateWin::Instance());
		m_battle_controller->emitBattleWinEvent();
	}
	else if (this->isBattleFailed() || this->isBattleQuit() || isBattleTimeout())
	{
		event::UniversalEventWithIdParm* battle_fail_event = event::UniversalEventWithIdParm::create(2001);
		int current_checkpoint_id = m_battle_data->current_checkpoint_id();
		int_32 need_ap =  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua", "QueryCheckPointCostAp", current_checkpoint_id);
		if ( need_ap>=0 ) //�����Ҫ�����Ĺؿ� �۳�1��
		{
			DataManager::GetInstance().user_info()->AddAp(0-1);
		}
		battle_fail_event->set_parm_id(current_checkpoint_id);
		EventManager::GetInstance().Emit(battle_fail_event);
		m_battle_controller->End();
	}
	else
	{
		assert(false);
	}
}
void LevelMission::notifyAddAllGainDataIntoUserInfoAfterBattleWin()
{
	int_32 addgold = m_battle_data->gain_gold();
	DataManager::GetInstance().user_info()->AddXp(m_battle_data->gain_xp_for_player());  
	DataManager::GetInstance().user_info()->AddAp(m_battle_data->gain_ap());
	if (m_battle_data->is_checkpoint_frist_complete() )
	{
		int_32 checkpoint_id = m_battle_data->current_checkpoint_id();
		if (checkpoint_id > 0)
		{
			int_32 checkpoint_gold = LuaTinkerManager::GetInstance().CallLuaFunc<int_32>(
				"script/mission/checkpoint_data_util.lua", "QueryCheckPointFirstPassRewardMoney", checkpoint_id); 

			addgold += checkpoint_gold;
		}  
	}
	//��Ӣ���� ��������֪ͨ 
	if ( LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId") < 90000)
	{
		DataManager::GetInstance().user_info()->AddGold( addgold * ( m_battle_data->GetRewardRadio() + 1 ));
	}
}

void LevelMission::notifyCharacterLevelupChecking()
{
	OwnHub* ownHub = dynamic_cast<OwnHub*>(m_own_hub);
	std::vector<uint_32> levelupIds;
	ownHub->GetAllLevelupCharacterIds(levelupIds);
	if (levelupIds.size()>0)
	{
		// test 
		m_battle_controller->battle_ui()->ShowAddFriendOrRewardForPlayer();
	}
	else
	{
		m_battle_controller->battle_ui()->ShowAddFriendOrRewardForPlayer();
	}
}

void LevelMission::notifyPlayerRankUpChecking()
{
	uint_16 original_rank = m_battle_data->original_rank();
	assert( original_rank <= DataManager::GetInstance().user_info()->rank());
	// not rank up in this battle
	if ( original_rank == DataManager::GetInstance().user_info()->rank())
	{
		m_battle_controller->ShowNewCard();
	}
	else // rank up
	{
		m_battle_controller->battle_ui()->RankUpToNextLevelForPlayerWithOriginalRank( original_rank);
	}
}

void LevelMission::onFightEnd()
{
	cocos2d::CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.0f);
	m_battle_controller->fightEnd();
	if ( isBattleFailed() )
	{
		m_battle_controller->GetStateMachine()->ChangeState(BattleStateFailed::Instance());
	}
	else if ( isBattleQuit() )
	{
		m_battle_controller->GetStateMachine()->ChangeState(BattleStateResultSession::Instance());
	}
	else if ( isBattleOver() )
	{
		m_battle_controller->GetStateMachine()->ChangeState(BattleStateOver::Instance());
	}
}

void LevelMission::onFightResult()
{
	if ( isBattleWin() || isBattleOver())
	{
		m_battle_controller->GetStateMachine()->ChangeState(BattleStateResultSession::Instance());
	}
}

}//namespace battle
}//namespace taomee