
#include "levellimittimeko.h"
#include "game/battle/battle_data.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_controller.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/grade_reward_data_table.h"


namespace taomee {

namespace battle {

LevelLimitTimeKO::LevelLimitTimeKO()
	: m_dead_monster(0)
{
	m_battle_main_type = kBattleType_Main;
	m_battle_sub_type = kBattleSubType_LevelLimitTimeKO;
}

LevelLimitTimeKO::~LevelLimitTimeKO()
{

}

void LevelLimitTimeKO::notifyMonsterMoveToRightBorder(uint_32 monster_id)
{
	army::MoveObject* monster = m_monster_hub->GetUnitById(monster_id);
	if ( monster )
	{
		monster->GoDeadStation(battle::kDeadReason_Disappear);
	}
}

void LevelLimitTimeKO::notifyMonsterDead(uint_32 player_id, bool last_one, bool last_wave)
{
	++m_dead_monster;
	LevelMission::notifyMonsterDead(player_id, last_one, last_wave);
}

void LevelLimitTimeKO::notifyPlayerDead(uint_32 player_id, bool last_one)
{
	if ( last_one )
	{
		switchBattleState(kBattleStateOver);
	}
}

void LevelLimitTimeKO::Update(float delta)
{
	if ( m_battle_over )
	{
		if ( battle_win_delay_time_ >= 0.0f )
		{
			battle_win_delay_time_ -= delta;
			if ( battle_win_delay_time_ < 0.0f)
			{
				onFightResult();
			}
		}
		return;
	}

	LevelBase::Update( delta);
		
	float battle_time_limit = m_battle_data->GetBattleTimeLimitForCurrnetCheckPoint();
	if ( m_time_tick >= battle_time_limit )
	{
		switchBattleState(kBattleStateOver);
	}

	if (isBattleOver() || isBattleWin() )
	{
		int grade = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
			"script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "GetBattleGrade",
			m_dead_monster);
		m_battle_data->set_pass_grade(grade);

		int grade_reward_id = m_battle_data->current_checkpoint_id() * 100 + grade;
		const GradeRewardData* grade_reward_data = DataManager::GetInstance().GetGradeRewardDataDataTable()->GetByID(grade_reward_id);
		if (grade_reward_data )
		{
			DataManager::GetInstance().user_info()->AddAp(grade_reward_data->get_ap(), true);
		}
		m_battle_over = true;
		m_battle_data->set_battle_win(true);
		onFightEnd();
	}
	else if ( isBattleQuit())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(false);
		onFightEnd();
	}
}

}//namespace battle
}//namespace taomee