
#include "levelbabel.h"
#include "game/battle/battle_data.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_state.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/state_machine/state_machine.h"
#include "game/game_manager/data_manager.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"


namespace taomee {

namespace battle {

LevelBabel::LevelBabel()
	: m_dead_player(0)
{
	m_battle_main_type = kBattleType_Main;
	m_battle_sub_type = kBattleSubType_TongTianTa;
}

LevelBabel::~LevelBabel()
{

}

void LevelBabel::Initialize(int curr_checkpoint_id)
{
  m_battle_data = createBattleData();
  m_battle_data->set_current_checkpoint_id(curr_checkpoint_id);

  m_battle_data->syncOriRank();
  m_battle_data->InitDataForNewBattle();

  m_battle_data->set_team_id(data::kTeamBabelIndex);

  switchBattleState(kBattleStateCombat);
}

void LevelBabel::createUnit()
{
  OwnHub* ownHub = dynamic_cast<OwnHub*>(m_own_hub);
  if ( ownHub )
  {
    if (ownHub->creatation_list().size())
    {
      ownHub->born_hub()->CreateAvatorGroupForNewPlayersGuide();
    } 
    else
    {
      ownHub->born_hub()->CreateTeamByBattleType(data::kTeamBabelIndex);
    }
  }
}
void LevelBabel::notifyPlayerDead(uint_32 player_id, bool final)
{
	++m_dead_player;
	LevelMission::notifyPlayerDead(player_id, final);
}

void LevelBabel::notifyBattleResultCompeleted()
{
  if (this->isBattleWin())
  {
    m_battle_controller->GetStateMachine()->ChangeState(BattleStateWin::Instance());
  }
  else if (this->isBattleFailed() || this->isBattleQuit())
  {
    //ʧ��ս��Ʒ����
    m_battle_controller->End();
  }
  else
  {
    assert(false);
  }
}

void LevelBabel::Update(float delta)
{
	if ( m_battle_over )
	{
		if ( battle_win_delay_time_ >= 0.0f )
		{
			battle_win_delay_time_ -= delta;
			if ( battle_win_delay_time_ < 0.0f)
			{
				int check_point_id = m_battle_data->current_checkpoint_id();
				int canPass = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
					"script/framework/CPlusToLuaInterface.lua", "checkCurBabelCanPass",
					check_point_id,1,m_time_tick,m_dead_player);

				if(canPass == 1)
				{
					m_battle_data->set_battle_win(true);
				}
				else
				{
					m_battle_data->set_battle_win(false);
				}
				onFightResult();
			}
		}
		return;
	}

	LevelBase::Update(delta);

	if ( isBattleWin())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(true);
		onFightEnd();
	}
	else if ( isBattleFailed() || isBattleQuit())
	{
		m_battle_over = true;
		m_battle_data->set_battle_win(false);
		onFightEnd();
	}
}




}//namespace battle
}//namespace taomee