
#include "levelsandbox.h"
#include "game/battle/battle_data_default.h"
#include "game/battle/monster_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_state.h"
#include "engine/base/state_machine/state_machine.h"

namespace taomee {
namespace battle {

LevelSandbox::LevelSandbox()
{
	m_battle_main_type = kBattleType_SandBox;
}

LevelSandbox::~LevelSandbox()
{

}

void LevelSandbox::notifyBattleStart()
{
	m_battle_controller->StartForSandbox();
}

void LevelSandbox::notifyBattleResourceLoadedEnd()
{
	m_battle_controller->GetStateMachine()->ChangeState(BattleStateBattle::Instance());
}

BattleHub* LevelSandbox::createMonsterHub()
{
	MonsterHub* pvpEnemyHub = new MonsterHub();
	return pvpEnemyHub;
}

BattleData* LevelSandbox::createBattleData()
{
	BattleData* battle_data = new BattleDataDefault();
	return battle_data;
}

void LevelSandbox::Update(float delta)
{
	if ( m_battle_over )
	{
		return;
	}
}




}//namespace battle
}//namespace taomee