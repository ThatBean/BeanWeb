

#ifndef Battle_Level_LimitTimeKO_H
#define Battle_Level_LimitTimeKO_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelmission.h"

namespace taomee {

namespace battle {

class LevelLimitTimeKO : public LevelMission
{
public:
	LevelLimitTimeKO();
	virtual ~LevelLimitTimeKO();
public:
	
	virtual void notifyMonsterMoveToRightBorder(uint_32 monster_id);
	virtual void notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave);
	virtual void notifyPlayerDead(uint_32 player_id, bool last_one);
public:

	virtual void Update(float delta);

protected:

	int m_dead_monster;
};

}//namespace battle
}//namespace taomee

#endif