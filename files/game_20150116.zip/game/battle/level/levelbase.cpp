
#include "levelbase.h"
#include "game/battle/battle_data.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "engine/base/loggermanager.h"
#include "game/battle/battle_controller.h"
#include "game/battle/monster_hub.h"

namespace taomee {
namespace battle {

LevelBase::LevelBase()
	: m_battle_controller(NULL)
	, m_battle_main_type(kBattleType_Unknown)
	, m_battle_sub_type(kBattleSubType_Unknown)
	, m_battle_state(kBattleStateNone)
	, m_battle_over(false)
	, m_battle_data(NULL)
	, m_own_hub(NULL)
	, m_monster_hub(NULL)
	, m_time_tick(0.0f)
	, battle_win_delay_time_(0.0f)
{
	m_battle_controller = &(BattleController::GetInstance());
}

LevelBase::~LevelBase()
{
	SAFE_DEL(m_battle_data);
	SAFE_DEL(m_own_hub);
	SAFE_DEL(m_monster_hub);
}

void LevelBase::Initialize(int curr_checkpoint_id)
{
	m_battle_data = createBattleData();
	m_battle_data->set_current_checkpoint_id(curr_checkpoint_id);

	m_battle_data->syncOriRank();
	m_battle_data->InitDataForNewBattle();
	// ----NOTE---- : set team id with defult index in frist version
	// will be reset by fetch user info request from server
	m_battle_data->set_team_id(data::kDefaultTeamIndex);

	switchBattleState(kBattleStateCombat);
}

BattleHub* LevelBase::getOwnHub()
{
	return m_own_hub;
}

BattleHub* LevelBase::getMonsterHub()
{
	return m_monster_hub;
}

BattleData* LevelBase::getBattleData()
{
	return m_battle_data;
}

eBattleType LevelBase::getBattleType()
{
	return m_battle_main_type;
}

eBattleSubType LevelBase::getBattleSubType()
{
	return m_battle_sub_type;
}

eBattleStateFlag LevelBase::getBattleStateFlag()
{
	return m_battle_state;
}

void LevelBase::switchBattleState(eBattleStateFlag newState)
{
	if ( newState == m_battle_state)
		return;

	if ( m_battle_state > kBattleStateWin)
	{
		return;
	}

	m_battle_state = newState;
}

bool LevelBase::isBattleWin()
{
	return (m_battle_state==kBattleStateWin);
}
bool LevelBase::isBattleFailed()
{
	return (m_battle_state==kBattleStateFailed);
}
bool LevelBase::isBattleOver()
{
	return (m_battle_state==kBattleStateOver);
}
bool LevelBase::isBattleTimeout()
{
	return (m_battle_state==kBattleStateTimeout);
}
bool LevelBase::isBattleQuit()
{
	return (m_battle_state==kBattleStateQuitByPlayer);
}

void LevelBase::createBattleHubs()
{
	m_own_hub = createOwnHub();
	m_monster_hub = createMonsterHub();

	m_own_hub->set_enemy_hub( m_monster_hub );
	m_monster_hub->set_enemy_hub( m_own_hub );

	InitBattleHubsData();
}

void LevelBase::InitBattleHubsData()
{

}

void LevelBase::createUnit()
{

}

void LevelBase::battleRevive()
{
	// change battle state to start default value
	switchBattleState(kBattleStateCombat);
	// reset some battle data
	m_battle_data->set_battle_constions_flag(kBattleWinTypeNoLose);
	m_battle_data->ResetCharactersStatus();
	// remove all characters
	m_own_hub->troops()->ClearAllMoveObjects();
	// create default characters group
	m_own_hub->born_hub()->CreateTeamByBattleType();
}

void LevelBase::battleClearTroop()
{
	// change battle state to start default value
	switchBattleState(kBattleStateCombat);
	// reset some battle data
	m_battle_data->set_battle_constions_flag(kBattleWinTypeNoLose);
	m_battle_data->ResetCharactersStatus();
	// remove all characters
	m_own_hub->troops()->ClearAllMoveObjects();
	// create default characters group
	m_own_hub->born_hub()->CreateTeamByBattleType();
}

BattleHub* LevelBase::createOwnHub()
{
	OwnHub* own_hub_ = new OwnHub(true);
	return own_hub_;
}

void LevelBase::notifyQuitByPlayer()
{
	switchBattleState(kBattleStateQuitByPlayer);
}

void LevelBase::notifyMonsterMoveToRightBorder(uint_32 monster_id)
{
	switchBattleState(kBattleStateFailed);
}

void LevelBase::notifyMoveObjBorn(uint_32 move_obj_id)
{

}

void LevelBase::notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave)
{
	if ( last_wave)
	{
		if ( last_one )
		{
			if ( m_own_hub->troops()->active_ids_count() > 0)
			{
				switchBattleState(kBattleStateWin);
			}
			else
			{
				// �˺͹�ͬʱ��������
				switchBattleState(kBattleStateFailed);
			}
		}
	}
	else
	{
		if ( last_one)
		{
			MonsterHub* monster_hub = dynamic_cast<MonsterHub*>(m_monster_hub);
			monster_hub->emitNextWaveMonster();
		}
	}
}

void LevelBase::notifyPlayerDead(uint_32 player_id, bool last_one)
{
	if ( last_one )
	{
		switchBattleState(kBattleStateFailed);
	}
}

void LevelBase::notifyBattleStart()
{

}

void LevelBase::notifyBattleEnd()
{
	m_battle_data->Reset();
	SAFE_DEL(m_own_hub);
	SAFE_DEL(m_monster_hub);
}

void LevelBase::notifyBattleResultCompeleted()
{

}

void LevelBase::notifyAddAllGainDataIntoUserInfoAfterBattleWin()
{

}

void LevelBase::notifyCharacterLevelupChecking()
{

}

void LevelBase::notifyPlayerRankUpChecking()
{

}

void LevelBase::notifyBattleResourceLoadedEnd()
{

}

void LevelBase::onFightEnd()
{

}

void LevelBase::onFightResult()
{

}

void LevelBase::Update(float delta)
{
	m_time_tick += delta;
}

}//namespace battle
}//namespace taomee