//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_data.cpp
//        Author: leohou
//       Version:
//          Date: Nov 13, 2013
//          Time: 2:21:26 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     2:21:26 AM
//
//////////////////////////////////////////////////////////////

#include "game/battle/battle_data.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/handle_delegate.h"
#include "game/account/account_manager.h"
#include "game/army/unit/character.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/own_hub.h"
#include "game/event/universal_event.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/data_manager.h"
//#include "game/data_table/checkpoint_data_table.h"
#include "game/user_interface/message_box_ui/ui_message_box.h"
#include "game/battle/view/battle_view.h"
#include "game/user_data/friend_info.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "network/net_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

#include "game/game_manager/game_logger_manager.h"
#include "game/battle/battle_reward_helper.h"
#include "game/data_table/checkpointdaily_data_table.h"

namespace taomee {
namespace battle {

BattleData::BattleData()
{
  this->Reset();
}

BattleData::~BattleData()
{

}
  
void BattleData::InitDataForNewBattle()
{
  lucky_star_ = 0;
  original_rank_ = DataManager::GetInstance().user_info()->rank();  
  
  //CoreValueModule
  gain_xp_ = CoreValueModule::GetMainCheckpointCardRewardXP(current_checkpoint_id_);

  gain_gold_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
                                                                "QueryCheckPointGoldReward",
                                                                current_checkpoint_id_);

  bool is_checkpoint_completed = DataManager::GetInstance().user_info()->QueryCheckPointPassSucess(current_checkpoint_id_);        
  this->set_is_checkpoint_frist_complete(!is_checkpoint_completed);

  gain_xp_for_player_ = CoreValueModule::GetMainCheckpointUserRewardEXP(current_checkpoint_id_, is_checkpoint_frist_complete_);
  battle_constions_flag_ = kBattleWinTypeNoLose;
  if (current_friend_id_.size() > 0)
  {
    //��ʱ�Ǻ��ѿ����ͷż���
    choosen_friend_ = true;//!(FriendController::GetInstance().GetHelperByUid(current_friend_id_)->is_helper());
  }
}

void BattleData::Reset()
{
  current_task_id_ = 0;
  current_checkpoint_id_ = 0;
  current_friend_card_id_ = 0;
  team_id_ = 0;
  current_friend_id_.clear();
  battle_win_ = false;
  original_rank_ = DataManager::GetInstance().user_info()->rank();
  gain_xp_ = 0;
  gain_xp_for_player_ = 0;
  is_checkpoint_frist_complete_ = false;
  gain_gold_ = 0;
  gain_ap_ = 0;
  gain_xp_multiple_ = 1.0f;
  gain_gold_multiple_ = 1.0f;
  gain_item_multiple_ = 1.0f;
  battle_constions_flag_ = 0;
  firstCharactersSid = 0;
  firstCharactersAttack = 0;
  firstCharactersLevel = 0;
  firstCharactersSkillId = 0;
  firstCharactersPhyDM = 0;
  firstMonsterData_1 = 0;
  firstMonsterData_2 = 0;

  choosen_friend_ = false;
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
  {
    characters_status_[i] = data::kCharacterStatusUnkown;
  }

  pass_grade_ = 0;
}

void BattleData::syncOriRank()
{
  original_rank_ = DataManager::GetInstance().user_info()->rank();
}
  
void BattleData::set_team_id(int team_id)
{ 
  team_id_ = team_id;
  // init character status
  uint_32 characSId[data::kMaxCharacterCountInOneTeam] = {data::kUnexistCharacterId};
  DataManager::GetInstance().user_info()->teams_ids(team_id, characSId);
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
  {
    if (characSId[i]!=data::kUnexistCharacterId)
    {
      characters_status_[i] = data::kCharacterStatusReserved;
    }
  }

  for (int i = 0;i<data::kMaxCharacterCountInOneTeam; ++i)
  {
	  if(characSId[i] != data::kUnexistCharacterId)
	  {
		  firstCharactersSid = characSId[i];
		  BornCalculator* tempCalc = DataManager::GetInstance().calculator();
      data::CharacterInfo* cInfo = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(firstCharactersSid);
		  firstCharactersLevel = cInfo->level();
		  
		  /////
		  int hp = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypeHp);
		  firstCharactersAttack +=hp;
		  int phy_attack = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypePhyAtk);
		  firstCharactersAttack +=phy_attack;
		  int mag_attack = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypeMagAtk);
		  firstCharactersAttack +=mag_attack;
		  int pdef = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypePDef);
		  firstCharactersAttack += pdef;
		  int mdef = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypeMDef);
		  firstCharactersAttack += mdef;
		  int fdamage = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypeFDamage);
		  firstCharactersAttack += fdamage;
		  int fundamage = tempCalc->PropertyCalculatorForCharacterByInfoAndType(cInfo,kAttrTypeFUnDamage);
		  firstCharactersAttack +=fundamage;

		  /////

		  int c_id = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(firstCharactersSid)->card_id();
		  CharacterData* char_data = DataManager::GetInstance().
			  GetCharacterDataTable()->GetCharacter(c_id);
		  firstCharactersSkillId = char_data->GetSkillId(kSkillSkill);
		  SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(firstCharactersSkillId);
		  float phyDamageMultiple = skillData->GetPhyAddedMul();
		  firstCharactersPhyDM = phyDamageMultiple;
		  break;
	  }
  }
}
  
void BattleData::set_characters_status(data::eCharacterStatus newStatus, uint_32 sId)
{
  // init character status
  uint_32 characSId[data::kMaxCharacterCountInOneTeam] = {data::kUnexistCharacterId};
  DataManager::GetInstance().user_info()->teams_ids(team_id_, characSId);
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
  {
    if (characSId[i]==sId)
    {
      characters_status_[i] = newStatus;
      return;
    }
  }
}
  
void BattleData::ResetCharactersStatus()
{
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
  {
    if (characters_status_[i] != data::kCharacterStatusUnkown)
    {
      characters_status_[i] = data::kCharacterStatusReserved;
    }
  }
}

uint_32 BattleData::GetNextReservedCharacterSequenceId()
{
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
  {
    if (characters_status_[i] == data::kCharacterStatusReserved)
    {
      return DataManager::GetInstance().user_info()->GetSequenceIdForTeamIdx(team_id_, i);
    }
  }
  return data::kUnexistCharacterId;
}

void  BattleData::AddOneGainApWithRadio(float r)
{
  int costAp = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
                                                                        "QueryCheckPointCostAp",
                                                                        this->current_checkpoint_id());

  gain_ap_ = gain_ap_ + 1 + floorf(costAp*r);
}

void BattleData::SendGetFriendCardInfo()
{

}

void BattleData::SendRequestSession()
{
  //difference request bewteen elite and other checkpoint
  if ( current_checkpoint_id() < 30000 ) //other
  {
	  bool is_special = false;
	  if ( current_checkpoint_id() >= 3000 && current_checkpoint_id() <= 3999 )
	  {
		  CheckpointDailyData* dailyData = DataManager::GetInstance().GetCheckpointDailyDataTable()->GetCheckpointdaily(current_checkpoint_id());
		  if ( dailyData && 
			  (dailyData->get_cp_type() == 4 || // ͻ�ƹ�ʵ��
			   dailyData->get_cp_type() == 5 || // ������
			   dailyData->get_cp_type() == 6 ) ) // ���޹ؿ�
		  {
			  is_special = true;
		  }
	  }
	  if ( is_special )
	  {
		  boost::shared_ptr<SpecialBattleRequestSession> battle_request_session = boost::make_shared<SpecialBattleRequestSession>();
		  battle_request_session->SubscribeReciveBodyComplete(this, &BattleData::onRequestSpecialSessionCompleted);

		  net::before_special_battle_in::Before_special_battle_in battle_ready_in;
		  battle_ready_in.set_cmd(GetHttpActionIDByName("battle_beforeSpecialBattle"));
		  battle_ready_in.set_session(account::AccountManager::GetInstance().session());

		  std::ostringstream os;
		  os << account::AccountManager::GetInstance().user_id();
		  battle_ready_in.set_userid(os.str());

		  battle_ready_in.set_checkpoint(current_checkpoint_id_);
		  //Ϊ��ϵͳĬ����ս��������
		  if ( strcmp(current_friend_id_.c_str(),"system") == 0 )
		  {
			  battle_ready_in.set_helper_uid("");
		  }   
		  else
		  {
			  std::ostringstream os;
			  os << current_friend_card_sid_;
			  battle_ready_in.set_helper_uid(current_friend_id_); 
		  }

		  battle_request_session->set_message_in(battle_ready_in);

		  net::NetManager& http_client = net::NetManager::GetInstance();
		  http_client.SendSession(battle_request_session);
	  }
	  else
	  {
		  boost::shared_ptr<BattleRequestSession> battle_request_session = boost::make_shared<BattleRequestSession>();
		  battle_request_session->SubscribeReciveBodyComplete(this, &BattleData::onRequestSessionCompleted);

		  net::before_battleEx_in::Before_battleEx_in battle_ready_in;
		  battle_ready_in.set_cmd(GetHttpActionIDByName("battle_beforeBattleEx"));
		  battle_ready_in.set_session(account::AccountManager::GetInstance().session());

		  std::ostringstream os;
		  os << account::AccountManager::GetInstance().user_id();
		  battle_ready_in.set_userid(os.str());

		  battle_ready_in.set_checkpoint(current_checkpoint_id_);
		  //Ϊ��ϵͳĬ����ս��������
		  if ( strcmp(current_friend_id_.c_str(),"system") == 0 )
		  {
			  battle_ready_in.set_helper_uid("");
		  }   
		  else
		  {
			  std::ostringstream os;
			  os << current_friend_card_sid_;
			  battle_ready_in.set_card_sid(os.str());
			  battle_ready_in.set_helper_uid(current_friend_id_); 
		  }

		  battle_request_session->set_message_in(battle_ready_in);

		  net::NetManager& http_client = net::NetManager::GetInstance();
		  http_client.SendSession(battle_request_session);
	  }
  }//if ( current_checkpoint_id() < 30000 ) //other
  else if(ISBABEL(current_checkpoint_id()))
  {
	   boost::shared_ptr<BattleBabelRequestSession> battle_babel_request_session = boost::make_shared<BattleBabelRequestSession>();
	   battle_babel_request_session->SubscribeReciveBodyComplete(this, &BattleData::onRequestBabelSessionCompleted);
	   net::before_babel_in::Before_babel_in battle_babel_ready_in;
	   battle_babel_ready_in.set_cmd(GetHttpActionIDByName("battle_beforeBabel"));
	   battle_babel_ready_in.set_session(account::AccountManager::GetInstance().session());

	   std::ostringstream os;
	   os << account::AccountManager::GetInstance().user_id();
	   battle_babel_ready_in.set_userid(os.str());
	   battle_babel_ready_in.set_helper_uid(current_friend_id_);
	   battle_babel_request_session->set_message_in(battle_babel_ready_in);
	   net::NetManager& http_client = net::NetManager::GetInstance();
	   http_client.SendSession(battle_babel_request_session);
  }//else if(ISBABEL(current_checkpoint_id()))
  else //elite
  {
    boost::shared_ptr<BattleEliteRequestSession> battle_elite_request_session = boost::make_shared<BattleEliteRequestSession>();
    battle_elite_request_session->SubscribeReciveBodyComplete(this, &BattleData::onRequestELiteSessionCompleted);

    net::before_elite_in::Before_elite_in battle_elite_ready_in;
    battle_elite_ready_in.set_cmd(GetHttpActionIDByName("battle_beforeElite"));
    battle_elite_ready_in.set_session(account::AccountManager::GetInstance().session());

    std::ostringstream os;
    os << account::AccountManager::GetInstance().user_id();
    battle_elite_ready_in.set_userid(os.str());

    battle_elite_ready_in.set_checkpoint(current_checkpoint_id_);
    battle_elite_ready_in.set_helper_uid(current_friend_id_);

    battle_elite_request_session->set_message_in(battle_elite_ready_in);

    net::NetManager& http_client = net::NetManager::GetInstance();
    http_client.SendSession(battle_elite_request_session);
  }//else //elite
    
    for (int i = 0; i < data::kMaxCharacterCountInOneTeam; ++i)
    {
      int sid = DataManager::GetInstance().user_info()->GetTeamCharacterIDByIndex(0, i);
      if (sid != data::kUnexistCharacterId)
      {
          int cid = DataManager::GetInstance().user_info()->getCardBaseInfoBySid(sid)->getID();
      }

    }
}

void BattleData::onRequestSessionCompleted(int error_code,
                                           boost::shared_ptr<BattleRequestSession> battle_request_session)
{
  if (error_code!=0)
  {
    char* msg = NULL;
    switch (error_code)
    {        
      case 10017:
      {
        msg = GetLuaText("battle_request_ap_not_enough");
      }
        break;
        
      case 10025:
      {
        msg = GetLuaText("battle_request_mission_past_yet");
      }
        break;
        
      case 10026:
      {
        msg = GetLuaText("battle_request_mission_condition_required");
      }
        break;
        
      case 10028:
      {
        msg = GetLuaText("battle_request_too_many_cards");
      }
        break;
        
      default: // 1004 1014
      {
        msg = GetLuaText("battle_request_server_error");
      }
        break;
    }
    // show message box
    ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
    msgBox->SetMsgTitleBMFont(GetLuaText("battle_request_error"));
    msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
    msgBox->ignoreAnchorPointForPosition(false);
    cocos2d::CCNode* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
    if (!parent)
    {
      parent = cocos2d::CCDirector::sharedDirector()->getRunningScene();
    }
    msgBox->setPosition(parent->getContentSize().width*0.5f,
                        parent->getContentSize().height*0.5f);
    msgBox->AttachToParentNode(parent);
    return;
  }
  
  const net::before_battleEx_out::Before_battleEx_out& battle_ready_out = battle_request_session->get_message_out();
  const std::vector<int>& drop_container = battle_ready_out.get_gain_seq();

  memset(is_drop_item_, 0, sizeof(is_drop_item_));
  for (std::vector<int>::const_iterator drop_iter = drop_container.begin();
    drop_iter != drop_container.end(); ++drop_iter)
  {
    assert( ((*drop_iter)-1) >= 0 && ((*drop_iter)-1) < kDropItemCount );
    is_drop_item_[(*drop_iter)-1] = true;
  }
  
  // notify battle controller
  BattleController::GetInstance().OnBattleRequestCompleted();
}

// ����ؿ�������սǰ׼���ظ�
void BattleData::onRequestSpecialSessionCompleted(int error_code,
	boost::shared_ptr<SpecialBattleRequestSession> battle_request_session)
{
	if (error_code!=0)
	{
		char* msg = NULL;
		switch (error_code)
		{        
		case 10017:
			{
				msg = GetLuaText("battle_request_ap_not_enough");
			}
			break;

		case 10025:
			{
				msg = GetLuaText("battle_request_mission_past_yet");
			}
			break;

		case 10026:
			{
				msg = GetLuaText("battle_request_mission_condition_required");
			}
			break;

		case 10028:
			{
				msg = GetLuaText("battle_request_too_many_cards");
			}
			break;

		default: // 1004 1014
			{
				msg = GetLuaText("battle_request_server_error");
			}
			break;
		}
		// show message box
		ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
		msgBox->SetMsgTitleBMFont(GetLuaText("battle_request_error"));
		msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
		msgBox->ignoreAnchorPointForPosition(false);
		cocos2d::CCNode* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
		if (!parent)
		{
			parent = cocos2d::CCDirector::sharedDirector()->getRunningScene();
		}
		msgBox->setPosition(parent->getContentSize().width*0.5f,
			parent->getContentSize().height*0.5f);
		msgBox->AttachToParentNode(parent);
		return;
	}

	const net::before_special_battle_out::Before_special_battle_out& battle_ready_out = battle_request_session->get_message_out();
	const std::vector<int>& drop_container = battle_ready_out.get_gain_seq();

	memset(is_drop_item_, 0, sizeof(is_drop_item_));
	for (std::vector<int>::const_iterator drop_iter = drop_container.begin();
		drop_iter != drop_container.end(); ++drop_iter)
	{
		assert( ((*drop_iter)-1) >= 0 && ((*drop_iter)-1) < kDropItemCount );
		is_drop_item_[(*drop_iter)-1] = true;
	}

	BattleController::GetInstance().OnBattleRequestCompleted();
}

void BattleData::onRequestELiteSessionCompleted(int error_code,
  boost::shared_ptr<BattleEliteRequestSession> battle_request_session)
{
  if (error_code!=0)
  {
    char* msg = NULL;
    switch (error_code)
    {        
    case 10017:
      {
        msg = GetLuaText("battle_request_ap_not_enough");
      }
      break;

    case 10025:
      {
        msg = GetLuaText("battle_request_mission_past_yet");
      }
      break;

    case 10026:
      {
        msg = GetLuaText("battle_request_mission_condition_required");
      }
      break;

    case 10028:
      {
        msg = GetLuaText("battle_request_too_many_cards");
      }
      break;

    default: // 1004 1014
      {
        msg = GetLuaText("battle_request_server_error");
      }
      break;
    }
    // show message box
    ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
    msgBox->SetMsgTitleBMFont(GetLuaText("battle_request_error"));
    msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
    msgBox->ignoreAnchorPointForPosition(false);
    cocos2d::CCNode* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
    if (!parent)
    {
      parent = cocos2d::CCDirector::sharedDirector()->getRunningScene();
    }
    msgBox->setPosition(parent->getContentSize().width*0.5f,
      parent->getContentSize().height*0.5f);
    msgBox->AttachToParentNode(parent);
    return;
  }
  //const net::before_elite_out::Before_elite_out& battle_ready_out = battle_request_session->get_message_out();
  //const std::vector<int>& drop_container = battle_ready_out.get_gain_seq();

  //memset(is_drop_item_, 0, sizeof(is_drop_item_));
  //for (std::vector<int>::const_iterator drop_iter = drop_container.begin();
  //  drop_iter != drop_container.end(); ++drop_iter)
  //{
  //  assert( ((*drop_iter)-1) >= 0 && ((*drop_iter)-1) < kDropItemCount );
  //  is_drop_item_[(*drop_iter)-1] = true;
  //}

  // notify battle controller
  BattleController::GetInstance().OnBattleRequestCompleted();
}

void BattleData::onRequestBabelSessionCompleted(int error_code,
	boost::shared_ptr<BattleBabelRequestSession> battle_babel_request_session)
{
	if (error_code!=0)
	{
		char* msg = NULL;
		switch (error_code)   
		{        
		case 10017:
			{
				msg = GetLuaText("battle_request_ap_not_enough");
			}
			break;

		case 10025:
			{
				msg = GetLuaText("battle_request_mission_past_yet");
			}
			break;

		case 10026:
			{
				msg = GetLuaText("battle_request_mission_condition_required");
			}
			break;

		case 10028:
			{
				msg = GetLuaText("battle_request_too_many_cards");
			}
			break;

		default: // 1004 1014
			{
				msg = GetLuaText("battle_request_server_error");
			}
			break;
		}
		// show message box
		ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
		msgBox->SetMsgTitleBMFont(GetLuaText("battle_request_error"));
		msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
		msgBox->ignoreAnchorPointForPosition(false);
		cocos2d::CCNode* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
		if (!parent)
		{
			parent = cocos2d::CCDirector::sharedDirector()->getRunningScene();
		}
		msgBox->setPosition(parent->getContentSize().width*0.5f,
			parent->getContentSize().height*0.5f);
		msgBox->AttachToParentNode(parent);
		return;
	}
	 BattleController::GetInstance().OnBattleRequestCompleted();
}

void BattleData::SendResultSession()
{
  //difference request bewteen elite and other checkpoint
  if ( current_checkpoint_id() < 30000 ) //other
  {
	  bool is_special = false;
	  int level_type = 0;
	  if ( current_checkpoint_id() >= 3000 && current_checkpoint_id() <= 3999 )
	  {
		  CheckpointDailyData* dailyData = DataManager::GetInstance().GetCheckpointDailyDataTable()->GetCheckpointdaily(current_checkpoint_id());
		  if ( dailyData &&
			  (dailyData->get_cp_type() == 4 || // ͻ�ƹ�ʵ��
			   dailyData->get_cp_type() == 5 || // ������
			   dailyData->get_cp_type() == 6 )) // ���޹ؿ�
		  {
			  level_type = dailyData->get_cp_type();
			  is_special = true;
		  }
	  }
	  if ( is_special )
	  {
		  boost::shared_ptr<SpecialBattleResultSession> battle_result_session = boost::make_shared<SpecialBattleResultSession>();
		  battle_result_session->SubscribeReciveBodyComplete(this, &BattleData::onResultSpecialSessionCompleted);

		  net::after_special_battle_in::After_special_battle_in battle_result_in;
		  battle_result_in.set_cmd(GetHttpActionIDByName("battle_afterSpecialBattle"));
		  battle_result_in.set_session(account::AccountManager::GetInstance().session());

		  std::ostringstream os;
		  os << account::AccountManager::GetInstance().user_id();
		  battle_result_in.set_userid(os.str());

		  battle_result_in.set_checkpoint(current_checkpoint_id_);
		  battle_result_in.set_is_win(battle_win_);
		  battle_result_in.set_type(level_type);

		  battle_result_in.set_grade(pass_grade_);

		  battle_result_in.set_checkcode(getCheckCodeArray());
		  battle_result_session->set_message_in(battle_result_in);
		  net::NetManager& http_client = net::NetManager::GetInstance();
		  http_client.SendSession(battle_result_session);
	  }
	  else
	  {
		  boost::shared_ptr<BattleResultSession> battle_result_session = boost::make_shared<BattleResultSession>();
		  battle_result_session->SubscribeReciveBodyComplete(this, &BattleData::onResultSessionCompleted);

		  net::after_battleEx_in::After_battleEx_in battle_result_in;
		  battle_result_in.set_cmd(GetHttpActionIDByName("battle_afterBattleEx"));
		  battle_result_in.set_session(account::AccountManager::GetInstance().session());

		  std::ostringstream os;
		  os << account::AccountManager::GetInstance().user_id();
		  battle_result_in.set_userid(os.str());

		  uint_32 currentBattleConditionFlag = battle::BattleController::GetInstance().battle_data()->battle_constions_flag();
		  battle_result_in.set_checkpoint(current_checkpoint_id_);
		  battle_result_in.set_is_win(battle_win_);
		  battle_result_in.set_status(currentBattleConditionFlag);
		  battle_result_in.set_checkcode(getCheckCodeArray());
		  battle_result_session->set_message_in(battle_result_in);
		  net::NetManager& http_client = net::NetManager::GetInstance();
		  http_client.SendSession(battle_result_session);
	  }
  }
   else if(ISBABEL(current_checkpoint_id()))
  {
	  //babel
	  boost::shared_ptr<BattleBabelResultSession> battle_result_session = boost::make_shared<BattleBabelResultSession>();
	  battle_result_session->SubscribeReciveBodyComplete(this,&BattleData::onResultBabelSessionCompleted);
	  net::after_babel_in::After_babel_in battle_result_in;
	  battle_result_in.set_cmd(GetHttpActionIDByName("battle_afterBabel"));
	  battle_result_in.set_session(account::AccountManager::GetInstance().session());

	  std::ostringstream os;
	  os << account::AccountManager::GetInstance().user_id();
	  battle_result_in.set_userid(os.str());
	  battle_result_in.set_is_win(battle_win_);
	  battle_result_in.set_checkcode(getCheckCodeArray());
	  battle_result_session->set_message_in(battle_result_in);
	  net::NetManager& http_client = net::NetManager::GetInstance();
	  http_client.SendSession(battle_result_session);
  }
  else
  {
    boost::shared_ptr<BattleEliteResultSession> battle_result_session = boost::make_shared<BattleEliteResultSession>();
    battle_result_session->SubscribeReciveBodyComplete(this, &BattleData::onResultELiteSessionCompleted);

    net::after_elite_in::After_elite_in battle_result_in;
    battle_result_in.set_cmd(GetHttpActionIDByName("battle_afterElite"));
    battle_result_in.set_session(account::AccountManager::GetInstance().session());

    std::ostringstream os;
    os << account::AccountManager::GetInstance().user_id();
    battle_result_in.set_userid(os.str());

    uint_32 currentBattleConditionFlag = battle::BattleController::GetInstance().battle_data()->battle_constions_flag();
    battle_result_in.set_checkpoint(current_checkpoint_id_);
    battle_result_in.set_is_win(battle_win_);
    battle_result_in.set_status(currentBattleConditionFlag);

	
	battle_result_in.set_checkcode(getCheckCodeArray());
    battle_result_session->set_message_in(battle_result_in);
	

    net::NetManager& http_client = net::NetManager::GetInstance();
    http_client.SendSession(battle_result_session);
  }

	
}

std::vector <std::vector<int> > BattleData::getCheckCodeArray()
{
	std::vector <  std::vector <int>   >   _array(3);
	for(int   i=0;i <3;i++) 
	{
		_array[i].resize(2);
	}

	_array[0][0] = firstMonsterData_1;
	_array[0][1] = firstMonsterData_2;
	_array[1][0] = firstCharactersSid<<4|2;
	_array[1][1] =	firstCharactersLevel<<24|firstCharactersAttack;
	_array[2][0] = firstCharactersSkillId<<4|3;
	_array[2][1] = firstCharactersPhyDM*100;
	for(int   i=0;i <3;i++) 
	{ 
		for(int   j=0;j <2;j++) 
		{
			CCLog("array[%d][%d]==%d",i,j,_array[i][j]);
		}
	}
	return _array;
}

void BattleData::onResultSessionCompleted(int error_code,
                                          boost::shared_ptr<BattleResultSession> battle_result_session)
{
  if (error_code!=0)
  {
    char* msg = NULL;
    switch (error_code)
    {        
      case 10018:
      {
        msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_battle_not_start");
      }
      break;

      default: // 1014
      {
        msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_server_error");
      }
        break;
    }
    // show message box
    ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
    msgBox->SetMsgTitleBMFont("");
    msgBox->SetMsgContent(msg);
    msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
    msgBox->ignoreAnchorPointForPosition(false);
    cocos2d::CCLayer* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
    msgBox->setPosition(parent->getContentSize().width*0.5f,
                        parent->getContentSize().height*0.5f);
    msgBox->AttachToParentNode(parent);
    typedef  HandleDelegate0 <battle::BattleController*> DelegateType;
    msgBox->RegisterMsgOkHandle(boost::make_shared<DelegateType>(
      &(battle::BattleController::GetInstance()), &BattleController::End));
    return;
  }
  // clean old data
  this->ClearGainCardsMap();
  /*
  // save battle conditions --  kBattleWinTypeInTime : battle time is counted in local device
  const int battleResultFlag = battle_result_session->get_message_out().get_status();
  battle::BattleController::GetInstance().battle_data()->set_battle_constions_flag(battleResultFlag);
  */

  //bool is_checkpoint_completed = DataManager::GetInstance().user_info()->QueryCheckPointPassSucess(this->current_checkpoint_id());        
  //this->set_is_checkpoint_frist_complete(!is_checkpoint_completed);
  //this->set_gain_xp_for_player(CoreValueModule::GetMainCheckpointUserRewardEXP(this->current_checkpoint_id(), is_checkpoint_completed));
  lucky_star_ = battle_result_session->get_message_out().get_lucky_star();

  this->battle_reward_map_.clear();
  this->battle_first_complete_reward_map.clear();
  if (battle_result_session->get_message_in().get_is_win())
  {
    const std::vector<taomee::net::after_battleEx_out::Gains>& gains = battle_result_session->get_message_out().get_gains();
    addServerRewardAfterBattleWin(gains.begin(), gains.end(), battle_reward_map_, gain_card_map_);
    addLocalRewardAfterBattleWin();
  }
  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua","setPreEndIsWin",battle_result_session->get_message_in().get_is_win());
  // send notification
  BattleController::GetInstance().OnBattleResultCompeleted();

  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_End", battle_result_session->get_message_in().get_is_win());

  if (battle_result_session->get_message_in().get_is_win())
  {
    GameLoggerManager::GetInstance()->log_battle_checkpoint_pass(battle_result_session->get_message_in().get_checkpoint());
  }
  else
  {
    GameLoggerManager::GetInstance()->log_battle_checkpoint_faile(battle_result_session->get_message_in().get_checkpoint());
  }
}

// ����ؿ�������ս�����ظ�
void BattleData::onResultSpecialSessionCompleted(int error_code,
	boost::shared_ptr<SpecialBattleResultSession> battle_result_session)
{
	if (error_code!=0)
  {
    char* msg = NULL;
    switch (error_code)
    {        
      case 10018:
      {
        msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_battle_not_start");
      }
      break;

      default: // 1014
      {
        msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_server_error");
      }
        break;
    }
    // show message box
    ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
    msgBox->SetMsgTitleBMFont("");
    msgBox->SetMsgContent(msg);
    msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
    msgBox->ignoreAnchorPointForPosition(false);
    cocos2d::CCLayer* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
    msgBox->setPosition(parent->getContentSize().width*0.5f,
                        parent->getContentSize().height*0.5f);
    msgBox->AttachToParentNode(parent);
    typedef  HandleDelegate0 <battle::BattleController*> DelegateType;
    msgBox->RegisterMsgOkHandle(boost::make_shared<DelegateType>(
      &(battle::BattleController::GetInstance()), &BattleController::End));
    return;
  }
  // clean old data
  this->ClearGainCardsMap();

  this->battle_reward_map_.clear();
  this->battle_first_complete_reward_map.clear();
  if (battle_result_session->get_message_in().get_is_win())
  {
    const std::vector<taomee::net::after_special_battle_out::Gains>& gains = battle_result_session->get_message_out().get_gains();
    addServerRewardAfterBattleWin(gains.begin(), gains.end(), battle_reward_map_, gain_card_map_);
    addLocalRewardAfterBattleWin();
  }

  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua","setPreEndIsWin",battle_result_session->get_message_in().get_is_win());
  // send notification
  BattleController::GetInstance().OnBattleResultCompeleted();

  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_End", battle_result_session->get_message_in().get_is_win());

  if (battle_result_session->get_message_in().get_is_win())
  {
    GameLoggerManager::GetInstance()->log_battle_checkpoint_pass(battle_result_session->get_message_in().get_checkpoint());
  }
  else
  {
    GameLoggerManager::GetInstance()->log_battle_checkpoint_faile(battle_result_session->get_message_in().get_checkpoint());
  }
}

void BattleData::onResultBabelSessionCompleted(int error_code,
	boost::shared_ptr<BattleBabelResultSession> battle_babel_result_session)
{
	if (error_code!=0)
	{
		char* msg = NULL;
		switch (error_code)
		{        
		case 10018:
			{
				msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_battle_not_start");
			}
			break;

		default: // 1014
			{
				msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_server_error");
			}
			break;
		}
		// show message box
		ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
		msgBox->SetMsgTitleBMFont("");
		msgBox->SetMsgContent(msg);
		msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
		msgBox->ignoreAnchorPointForPosition(false);
		cocos2d::CCLayer* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
		msgBox->setPosition(parent->getContentSize().width*0.5f,
			parent->getContentSize().height*0.5f);
		msgBox->AttachToParentNode(parent);
		typedef  HandleDelegate0 <battle::BattleController*> DelegateType;
		msgBox->RegisterMsgOkHandle(boost::make_shared<DelegateType>(
			&(battle::BattleController::GetInstance()), &BattleController::End));
		return;
	}
	// clean old data
	this->ClearGainCardsMap();

	this->battle_reward_map_.clear();
  this->battle_first_complete_reward_map.clear();
  if (battle_babel_result_session->get_message_in().get_is_win())
  {
    const std::vector<taomee::net::after_babel_out::Gains>& gains = battle_babel_result_session->get_message_out().get_gains();
    addServerRewardAfterBattleWin(gains.begin(), gains.end(), battle_reward_map_, gain_card_map_);
    //addLocalRewardAfterBattleWin();
  }
  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua","setPreEndIsWin",battle_babel_result_session->get_message_in().get_is_win());
	// send notification
	BattleController::GetInstance().OnBattleResultCompeleted();
// 	int check = current_checkpoint_id_;
// 	string str_path = "script/checkpoint/" + Int2String(this->current_checkpoint_id()) + ".lua";
// 	LuaTinkerManager::GetInstance().CallLuaFunc<int>(str_path.c_str(), "Battle_End", battle_babel_result_session->get_message_in().get_is_win());

}

void BattleData::onResultELiteSessionCompleted(int error_code,
  boost::shared_ptr<BattleEliteResultSession> battle_result_session)
{

  if (error_code!=0)
  {
    char* msg = NULL;
    switch (error_code)
    {        
    case 10018:
      {
        msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_battle_not_start");
      }
      break;

    default: // 1014
      {
        msg = LuaTinkerManager::GetInstance().GetLuaText<char*>("battle_request_server_error");
      }
      break;
    }
    // show message box
    ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
    msgBox->SetMsgTitleBMFont("");
    msgBox->SetMsgContent(msg);
    msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
    msgBox->ignoreAnchorPointForPosition(false);
    cocos2d::CCLayer* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
    msgBox->setPosition(parent->getContentSize().width*0.5f,
      parent->getContentSize().height*0.5f);
    msgBox->AttachToParentNode(parent);
    typedef  HandleDelegate0 <battle::BattleController*> DelegateType;
    msgBox->RegisterMsgOkHandle(boost::make_shared<DelegateType>(
      &(battle::BattleController::GetInstance()), &BattleController::End));
    return;
  }
  // clean old data
  this->ClearGainCardsMap();

  this->battle_reward_map_.clear();
  this->battle_first_complete_reward_map.clear();


  if (battle_result_session->get_message_in().get_is_win())
  {
    const std::vector<taomee::net::after_elite_out::Gains>& gains = battle_result_session->get_message_out().get_gains();
    addServerRewardAfterBattleWin(gains.begin(), gains.end(), battle_reward_map_, gain_card_map_);
    addLocalRewardAfterBattleWin();
  }
   LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua","setPreEndIsWin",battle_result_session->get_message_in().get_is_win());
  // send notification
  BattleController::GetInstance().OnBattleResultCompeleted();

  //string str_path = "script/checkpoint/" + Uint2String(battle_result_session->get_message_in().get_checkpoint()) + ".lua";
  //LuaTinkerManager::GetInstance().CallLuaFunc<int>(str_path.c_str(), "Battle_End", battle_result_session->get_message_in().get_is_win());

  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_End", battle_result_session->get_message_in().get_is_win());
}
 
uint_8 BattleData::GetNextConditionIndex(uint_8 currentIdx)
{
  assert(currentIdx<kBattleWinTypesCount);
  while (currentIdx<kBattleWinTypesCount)
  {
    if (battle_constions_flag_ & (1<<currentIdx))
    {
      return currentIdx;
    }
    ++currentIdx;
  }
  return static_cast<uint_8>(kBattleWinTypesCount);
}
  
bool BattleData::CanSelectedUnitUsingActiveSkill(uint_32 obj_id)
{
  if (choosen_friend_)
  {
    return true;
  }
  //��ʱ�Ǻ��ѿ����ͷż���
  /*
  if (current_friend_id_.size() > 0 )
  {
      army::Character* cInfo = dynamic_cast<army::Character*>(BattleController::
      GetInstance().own_hub()->troops()->GetObjectById(obj_id));
    if (cInfo->sequence_id() == FriendController::GetInstance().
      GetHelperByUid(current_friend_id_)->lead_character_friend()->sequence_id())
    {
      return false;
    }
  }
  */

  return true;
}
  
bool BattleData::CanUnitUsingActiveSkill(uint_32 unitSeqId)
{
  bool tempIsFriend = FriendController::GetInstance().battleHelpIsFriend();
  // if (choosen_friend_)
  // {
  //   return true;
  // }

  //��ʱ�Ǻ��ѿ����ͷż���
  
  if (current_friend_id_.size() > 0)
  {
    if (unitSeqId == FriendController::GetInstance().
      GetHelperByUid(current_friend_id_)->lead_character_friend()->sequence_id())
    {
      if(tempIsFriend == false)
      {
        return false;
      }
      
    }
  }  
  
  return true;
}
  
float BattleData::GetRewardRadio()
{
  int cnt = 0;
  for (uint_8 idx = 0; idx < kBattleWinTypesCount; ++idx)
  {
    if (battle_constions_flag_ & (1<<idx)) 
	{
      ++cnt;
    }
  }
  if (0==cnt)
  {
	  return 0.0f;
  }  
  return kBattleWinRewardRadio[cnt-1];
}
  
float BattleData::GetBattleTimeLimitForCurrnetCheckPoint()
{
	int max_battle_time = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
		"script/mission/checkpoint_data_util.lua","QueryCheckPointMaxBattleTime",
		this->current_checkpoint_id());
  return max_battle_time;
}

bool BattleData::is_checkpoint_frist_complete()
{
  return is_checkpoint_frist_complete_;
}

void BattleData::set_is_checkpoint_frist_complete( bool is_frist )
{
  is_checkpoint_frist_complete_ = is_frist;
}

uint_8 BattleData::GetDropCount()
{
  uint_8 count = 0;
  for (int i = 0; i < kDropItemCount; ++i)
  {
    if (is_drop_item_[i] == true)
    {
      count++;
    }    
  }
  return count;
}

int_8 BattleData::GetDropItemIdxByIndex(uint_8 index)
{
  uint_8 count = 0;
  for (int i = 0; i < kDropItemCount; ++i)
  {
    if (is_drop_item_[i])
    {
      ++count;
      if (count == index)
      {
        return i + 1;
      }
    }
  }
  return 0;
  //return is_drop_item_[index - 1] ? count : 0;
}

cocos2d::CCArray* BattleData::GetBattleReward()
{
  CCArray *array = CCArray::create();

  for(std::map<uint_32, uint_32>::iterator itr = battle_reward_map_.begin();
    itr != battle_reward_map_.end(); ++itr)
  {
    array->addObject(cocos2d::CCInteger::create((itr)->first));
    array->addObject(cocos2d::CCInteger::create((itr)->second));
  }
  return array;
}

cocos2d::CCArray* BattleData::GetBattleFristReward()
{
  CCArray *array = CCArray::create();

  for(std::map<uint_32, uint_32>::iterator itr = battle_first_complete_reward_map.begin();
    itr != battle_first_complete_reward_map.end(); ++itr)
  {
    array->addObject(cocos2d::CCInteger::create((itr)->first));
    array->addObject(cocos2d::CCInteger::create((itr)->second));
  }
  return array;
}

void BattleData::addLocalRewardAfterBattleWin()
{
  bool is_first = is_checkpoint_frist_complete();
  int drop_count = GetDropCount();
  BaseCheckpointData* data = BaseCheckpointDataTable::GetInstance()->GetDataById(current_checkpoint_id_);
  for (int idx = 1; idx <= drop_count; ++idx)
  {
    int item_count = 0;
    int item_id = 0;
    int drop_idx = GetDropItemIdxByIndex(idx);
    if (drop_idx != 0)
    {
       if (data->getLocalDropItemData(drop_idx, item_id, item_count))
       {
          if (item_id > 0 && item_count > 0)
          {
            std::map<uint_32, uint_32>::iterator it = battle_reward_map_.find(item_id);
            if (it != battle_reward_map_.end())
            {
              it->second += item_count;
            }
            else
            {
              battle_reward_map_.insert(std::pair<int,int>(item_id, item_count));
            }
            DataManager::GetInstance().user_info()->AddLocalItemToUserBag(item_id, item_count);
          }
       }
    }
  }
  battle_first_complete_reward_map.clear();
  if (is_first)
  {
    int item_type = 0;
    int item_count = 0;
    int item_id = 0;
    for (int idx = 1; idx <= 2; ++idx)
    {
      if (data->getLocalFirstDropItemData(idx, item_id, item_count, item_type))
      {
        if (item_id > 0 && item_count > 0)
        {
          battle_first_complete_reward_map.insert(std::pair<int,int>(item_id, item_count));
          DataManager::GetInstance().user_info()->AddLocalItemToUserBag(item_id, item_count);
        }
      }
    }
    //�״�ͨ�����߹ؿ� �������Ǽ�¼
    if ( data->getType() == 3 )
    {
      DataManager::GetInstance().user_info()->AddLocalItemToUserBag(66, 1);
    }
  }
}

} /* namespace battle */
} /* namespace taomee */
