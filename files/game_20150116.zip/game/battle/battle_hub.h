//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  battle_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_hub_h
#define ChainChronicle_battle_hub_h

#include <queue>

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
  
namespace army {
  class MoveObject;
  class Summon;
  class BornHub;
  class TroopsHub;
  class SummonTroopsHub;
}
  
namespace battle {

class BattleView;
class BattleDamage;

class BattleHub {
public:
  BattleHub();
  virtual ~BattleHub();
  
  typedef std::list<army::MoveObject*> TiledObjectsList;
  
public:
  // update invoke : all active units in battle_hub will update
  virtual void Update(float delta_time) = 0;
  // the mark flag for hub's force side : true means palyer's hero hub;
  // false means monters hub
  virtual bool IsCharacterHub() = 0;
  virtual bool IsRightSideHub() = 0;
  virtual void SetRightSideHub(bool is_right_side) = 0;

  virtual army::MoveObject* CreateUnitById(uint_32 unit_id, bool is_substitution = false);
  virtual army::MoveObject* CreateUnitBySubstitution(uint_32 unit_id);
  virtual army::MoveObject* CreateSummonUnit();

  virtual void SwitchUnitToActiveIdsList(uint_32 unit_id);
  // get MoveObject reference by id
  virtual army::MoveObject* GetUnitById(uint_32 unit_id);

  virtual army::Summon* GetSunmonUnitById(uint_32 unit_id);

  // dead notification
  virtual void NotifyOneUnitDead(uint_32 object_id) = 0;
  // process skill hit from hit unit to target unit by id(target unit MUST be one
  // member of this battle_hub, the hit unit can be either friend or enemy)
  virtual bool HitOneUnitInThisHub(
	  uint_32 skill_release_unit_id,uint_32 target_unit_id,uint_32 skill_id,int_32  penetrate_count,bool is_critical);
  virtual bool HitOneUnitInThisHub(
	  army::MoveObject* attacker,army::MoveObject* target,uint_32 skill_id,int_32  penetrate_count,bool is_critical);

  virtual bool SputteringOneUnitInThisHub(uint_32 skill_release_unit_id, uint_32 target_unit_id, uint_32 skill_id, float damaga_multiple);
  // units in this hub will be under the attack damage from its enemy hub
  virtual void UnderAttack(std::queue<BattleDamage*>* damage_queue);
  // damage one unit in own hub with damage value
  virtual void DamageUnit(army::MoveObject* target, int damageValue, army::MoveObject* attacker, bool hitBySkill, battle::eAttackDamageType attackDamageType = battle::kDamageTypePhysics);
  
public: // getter & setter  
  void       set_enemy_hub(BattleHub* hub) {
    enemy_hub_ = hub;
  }
  BattleHub* enemy_hub() {
    return enemy_hub_;
  }

  void set_battle_view(BattleView* battle_view);
  BattleView* battle_view();
  
  army::BornHub* born_hub()
  {
	  return born_hub_;
  }
  
  army::TroopsHub* troops()
  {
	  return troops_;
  }

  army::SummonTroopsHub* summon_troops()
  {
	  return summon_troops_;
  }
  
  std::queue<BattleDamage*>* damage_queue()
  {
	  return &damage_queue_;
  }
  
  army::MoveObject* GetFirstMoveObjectInTileWithIndex(int_8 tileIdx);
  void GetAllMoveObjectsInTileWithIndex(int_8 tileIdx,
                                        std::list<army::MoveObject*>& moveObjList);
  void GetAllMoveObjectsInOneRowByRowIndex(int_8 rowIdx,
                                           std::list<army::MoveObject*>& moveObjList);
  // only include move_object in column [0 - 2]
  void GetAllMoveObjectsInOneValidRowByRowIndex(int_8 rowIdx,
                                           std::list<army::MoveObject*>& moveObjList);
  // get all move objects by search index list & search center point position
  virtual void GetAllMoveObjectsInTilesWithIndexList(const std::vector<int_8>& indexList,
                                                     std::list<army::MoveObject*>& moveObjList,
                                                     cocos2d::CCPoint searchCenterPos);
public:
	uint_32 AddImmediatelySummonAtIndex( uint_16 level, uint_32 card_id, int_8 tileIdx);
public:
  void RemoveAllActiveObjectsAndResetTroopsList();
  
  void AddDamageIntoHub(int value,uint_32 target_unit_id,uint_32 caster_id,eAttackDamageType damageType = kDamageTypePhysics);
  
public: // operator on reference list of all move objects in this hub: insert/remove/update
  void insertAttackerReference(army::MoveObject* agent);
  void removeAttackerReference(army::MoveObject* agent);
  void updateAttackerReference(int_8 originalTileIndex, army::MoveObject* agent);
  
protected:
  BattleHub* enemy_hub_;
  BattleView* battle_view_;
  army::BornHub* born_hub_;
  army::TroopsHub* troops_;
  army::SummonTroopsHub* summon_troops_;
  
protected:
  // reference index vector on move object(all characters & monsters)
  // with tile coordinate index as key
  std::vector<std::list<army::MoveObject*> > move_objects_reference_;
  // all damages' to enemies (heal to friends) list in each update circle
  std::queue<BattleDamage*> damage_queue_;
};

} // battle
} // taomee

#endif // ChainChronicle_battle_hub_h
