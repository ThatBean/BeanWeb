//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  own_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  4:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_own_hub_h
#define ChainChronicle_own_hub_h

#include "game/battle/battle_hub.h"

namespace taomee {
  
namespace army {
  class Character;
}
  
namespace data {
  class CharacterInfo;
}
  
namespace battle {
  
class CharacterCreatationInfo
{
public:
  CharacterCreatationInfo() {}
  CharacterCreatationInfo(uint_32 unitId,
                          uint_32 cardId,
                          int_8   tileX,
                          int_8   tileY,
                          uint_8  level,
                          bool    isFriend)
    : unit_id_(unitId),
      card_id_(cardId),
      tile_x_(tileX),
      tile_y_(tileY),
      level_(level),
      is_friend_(isFriend)
  {
    
  }
  CharacterCreatationInfo(const CharacterCreatationInfo& data)
  {
    this->InitWithData(data);
  }
  
  virtual void InitWithData(const CharacterCreatationInfo& data)
  {
    unit_id_ = data.unit_id_;
    card_id_  = data.card_id_;
    tile_x_   = data.tile_x_;
    tile_y_   = data.tile_y_;
    level_    = data.level_;
    is_friend_ = data.is_friend_;
  }
  
public:
  uint_32 unit_id_;
  uint_32 card_id_;
  int_8   tile_x_;
  int_8   tile_y_;
  uint_8  level_;
  bool    is_friend_;
};

class PvpCharacterCreatationInfo : public CharacterCreatationInfo
{

public:

  PvpCharacterCreatationInfo()
  {

  }

  PvpCharacterCreatationInfo(const PvpCharacterCreatationInfo& data)
  {
    InitWithData(data);
  }

  void InitWithData(const CharacterCreatationInfo& c_data)
  {
    CharacterCreatationInfo::InitWithData(c_data);
    const PvpCharacterCreatationInfo* data = (PvpCharacterCreatationInfo*)(&c_data);    
    hp_ = data->hp_;
    physics_attack_ = data->physics_attack_;
	magic_attack_ = data->physics_attack_;
	dodge = data->dodge;
	hit_rate = data->hit_rate;
    pdef_ = data->pdef_;
    mdef_ = data->mdef_;
    fdamage_ = data->fdamage_;
    fundamage_ = data->fundamage_;
  }
public:
   uint_32  hp_;
   uint_32  physics_attack_;
   uint_32  magic_attack_;
   uint_32  dodge;
   uint_32  hit_rate;
   uint_32  pdef_;
   uint_32  mdef_;
   uint_32  fdamage_;
   uint_32  fundamage_;
};


class OwnHub : public BattleHub {
public:
  OwnHub(bool isRightSideHub);
//  explicit OwnHub(int num);
  virtual ~OwnHub();
  
public:
  virtual void Update(float delta_time);
  // true means palyer's hero hub
  virtual bool IsCharacterHub()
  {
	  return mIsCharacter;
  }
  virtual bool IsRightSideHub()
  {
	  return mIsRightSide;
  };
  virtual void SetRightSideHub(bool is_right_side)
  {
	  mIsRightSide = is_right_side;
  };

  // nitification for unit's death
  virtual void NotifyOneUnitDead(uint_32 object_id);
  
  // create one character for new player's guide
  LUA_INTERFACE void CreateOneCharacter(uint_32 unitId,
                                        uint_32 cardId,
                                        uint_8  tileIdx,
                                        uint_8  level,
                                        bool    isFriend);

  LUA_INTERFACE void CreateNextCharacterForLua(uint_32 unitId, uint_32 cardId, uint_32 level);

  //SnowCold
  void  CreateOnePvpCharacter(uint_32 unitId, PvpCharacterCreatationInfo& data);

  void AddImmediatelyCharacterAtIndex( uint_16 level,
    uint_32 unit_id,
    uint_32 card_id,
    int_8 tileIdx,
    bool isFriend);
public:
  void PopOneCreatationInfo(CharacterCreatationInfo& data)
  {
    data.InitWithData(creatation_list_.front());
    creatation_list_.pop_front();
  }
  
  void PopOnePvpCreationInfo(PvpCharacterCreatationInfo& data)
  {
    data.InitWithData(pvp_creatation_list_.front());
    pvp_creatation_list_.pop_front();
  }

  const std::list<CharacterCreatationInfo>& creatation_list()const { return creatation_list_; }
  const std::list<PvpCharacterCreatationInfo>& pvp_creatation_list()const { return pvp_creatation_list_; }
  
  const std::list<data::CharacterInfo*>& characters_info_list() const { return characters_info_list_; }
  void AddOneCharacterInfo(data::CharacterInfo* info)
  {
    characters_info_list_.push_back(info);
  }
  
  void UpdateVictorySpecial(float delta_time);
  
  void ShowXpBarForBattleVictory(uint_32 xp,
    std::vector<std::pair<uint_8, cocos2d::CCPoint> >& xpPos);
  
  void ShowRankUpForBattleVictory(std::vector<cocos2d::CCPoint>& bottomPos);

  void GetAllLevelupCharacterIds(std::vector<uint_32>& ids);
  
  void SetOwnHubUpdateFlag(bool bStopUpdateFlag);
public:
  // @ isAddFlag : true means add buff status; false means remove status
  LUA_INTERFACE void AddInvincibleBUFFStatusOnRole(int_32 unitId, bool isAddFlag);
  
protected: // for new player's guide only
  std::list<CharacterCreatationInfo> creatation_list_;
  std::list<PvpCharacterCreatationInfo> pvp_creatation_list_;
  // character cards list
  std::list<data::CharacterInfo*>    characters_info_list_;

private:
  bool    update_stop_flag_;
  bool    mIsCharacter;
  bool    mIsRightSide;
};

} // namespace battle
} // namespace taomee

#endif // ChainChronicle_own_hub_h
