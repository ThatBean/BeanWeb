//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  battle_hub.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/battle_hub.h"

#include "game/artificial_intelligence/intent_state/ai_state.h"
#include "game/army/unit/move_object.h"
#include "game/army/unit/summon.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/army/unit_hub/summon_troops_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/battle/battle_controller.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "game/battle/damage/battle_damage.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/character_data_table.h"

namespace taomee {
namespace battle {
  
BattleHub::BattleHub()
  : enemy_hub_(NULL),
    battle_view_(NULL),
	troops_(NULL),
	summon_troops_(NULL)
    //born_hub_(new army::BornHub(this))
{
  //Modified by peteryu
  born_hub_ = new army::BornHub(this);
  std::list<army::MoveObject*> temp;
  move_objects_reference_.assign(battle::kMapTilesIndexMax, temp);
}
  
BattleHub::~BattleHub() {
  enemy_hub_ = NULL;
  battle_view_ = NULL;
  move_objects_reference_.clear();
  SAFE_DEL(born_hub_);
  SAFE_DEL(troops_);
  SAFE_DEL(summon_troops_);
}
  
void BattleHub::set_battle_view(BattleView* battle_view) {
  battle_view_ = battle_view;
}
BattleView* BattleHub::battle_view() {
  return battle_view_;
}
  
army::MoveObject* BattleHub::GetFirstMoveObjectInTileWithIndex(int_8 tileIdx)
{
  TiledObjectsList* aList = &(move_objects_reference_[tileIdx]);
  if (!aList || aList->size()<=0) {
    return NULL;
  }
  else
  {
    return aList->front();
  }
}
  
void BattleHub::GetAllMoveObjectsInTileWithIndex(int_8 tileIdx,
                                                 std::list<army::MoveObject*>& moveObjList)
{
  moveObjList.clear();
  TiledObjectsList* aList = &(move_objects_reference_[tileIdx]);
  if (!aList || aList->size()<=0) {
    return ;
  }  
  // get all moveObjs' reference 
  for (std::list<army::MoveObject*>::iterator list_it = aList->begin();
       list_it != aList->end(); ++list_it)
  {
    moveObjList.push_back(*list_it);
  }
}
  
void BattleHub::GetAllMoveObjectsInOneRowByRowIndex(int_8 rowIdx,
                                                    std::list<army::MoveObject*>& moveObjList)
{
  moveObjList.clear();
  assert(rowIdx>=0 && rowIdx<kMapRowCount);
  for (int i = kUnexistTileCoordinate; i<kMapColumnCount; ++i)
  {
    int_8 tileIndex = GetTileIndexByTileCoordinatePos(ccp(i, rowIdx));
    TiledObjectsList* aList = &(move_objects_reference_[tileIndex]);
    if (!aList || aList->size()<=0) {
      continue ;
    }
    // get all moveObjs' reference
    for (std::list<army::MoveObject*>::iterator list_it = aList->begin();
         list_it != aList->end(); ++list_it)
    {
      moveObjList.push_back(*list_it);
    }
  }
}

void BattleHub::GetAllMoveObjectsInOneValidRowByRowIndex(int_8 rowIdx,
                                                    std::list<army::MoveObject*>& moveObjList)
{
  moveObjList.clear();
  assert(rowIdx>=0 && rowIdx<kMapRowCount);
  for (int i = 0; i<kMapColumnCount; ++i)
  {
    int_8 tileIndex = GetTileIndexByTileCoordinatePos(ccp(i, rowIdx));
    TiledObjectsList* aList = &(move_objects_reference_[tileIndex]);
    if (!aList || aList->size()<=0) {
      continue ;
    }
    // get all moveObjs' reference
    for (std::list<army::MoveObject*>::iterator list_it = aList->begin();
      list_it != aList->end(); ++list_it)
    {
      moveObjList.push_back(*list_it);
    }
  }
}
  
void BattleHub::RemoveAllActiveObjectsAndResetTroopsList()
{
	const std::vector<uint_32>& active_ids = troops()->active_ids();
	for (int i = 0; i < active_ids.size(); ++i)
	{
		army::MoveObject* obj = troops()->GetObjectById(active_ids[i]);
		if ( obj )
		{
			this->removeAttackerReference(obj);
			obj->BeDestroyed();
		}
	}
	troops()->RemoveDeadMoveOjectsAfterBattleEnd();
}
  
void BattleHub::AddDamageIntoHub(int value,uint_32 target_unit_id,uint_32 caster_id,eAttackDamageType damageType)
{
	if ( value == 0 )
	{
		return;
	}

	BattleDamage* damage = new BattleDamage();
	damage->set_damage_value(value);
	damage->set_attacker_id(caster_id);
	damage->set_target_id(target_unit_id);
	damage->set_damage_type(damageType);
	damage->dotProcess();
	damage_queue()->push( damage);
}
  
bool BattleHub::HitOneUnitInThisHub(
	uint_32 skill_release_unit_id, uint_32 target_unit_id, 
	uint_32 skill_id, int_32 penetrate_count, bool is_critical)
{
  BattleDamage* damage = new BattleDamage();
  damage->set_attacker_id(skill_release_unit_id);
  damage->set_target_id(target_unit_id);
  damage->set_skill_id(skill_id);
  damage->set_penetrate_count(penetrate_count);
  damage->set_is_critical_hit(is_critical);
  damage->nomralProcess();
  if (damage->damage_value()==0)
  {
    delete damage;
    return true;
  }
  else 
  {
    damage_queue_.push(damage);
  }  
  return (damage->damage_value()>0);
}

bool BattleHub::HitOneUnitInThisHub(
	army::MoveObject* attacker, army::MoveObject* target, 
	uint_32 skill_id, int_32 penetrate_count, bool is_critical)
{
  assert(attacker && target);
  return this->HitOneUnitInThisHub(
	  attacker->move_object_id(), target->move_object_id(), skill_id, penetrate_count, is_critical);
}

bool BattleHub::SputteringOneUnitInThisHub(uint_32 skill_release_unit_id, uint_32 target_unit_id, uint_32 skill_id, float damaga_multiple)
{
	BattleDamage* damage = new BattleDamage();
	damage->set_attacker_id(skill_release_unit_id);
	damage->set_target_id(target_unit_id);
	damage->set_skill_id(skill_id);
	damage->set_enable_infect(false);
	damage->set_final_damaga_multiple(damaga_multiple);
	damage->set_is_sputtering(true);
	damage->nomralProcess();
	if (damage->damage_value()==0)
	{
		delete damage;
		return true;
	}
	else 
	{
		damage_queue_.push(damage);
	}  
	return (damage->damage_value()>0);
}

void BattleHub::UnderAttack(std::queue<BattleDamage*>* damage_queue)
{
  while (!damage_queue->empty()) {
    BattleDamage* damage = damage_queue->front();
    damage_queue->pop();
    
    damage->Attack();
    delete damage;
  }
}
  
  // damage one unit in own hub with damage value
void BattleHub::DamageUnit(army::MoveObject* target, int damageValue, army::MoveObject* attacker, bool hitBySkill, battle::eAttackDamageType attackDamageType)
{
  if(!target->is_active())
    return;

  int hp = target->currnet_health_point()-damageValue;
  if (hp <= 0) 
  {
    hp = 0;

	battle::eDeadReason dead_reason = battle::kDeadReason_Normal;
	if ( hitBySkill && attackDamageType == battle::kDamageTypeSuicide && target->move_object_id() == attacker->move_object_id() )
	{
		dead_reason = battle::kDeadReason_Suicide;
	}
    target->GoDeadStation(dead_reason);

	if ( attacker->is_active() )
	{
		attacker->add_energy_value(300.0f);
	}
  }
  // trigger out ability : hurted by enemy
  if (damageValue>0)
  {
	target->add_bear_damage(damageValue);

	float add_energy = (float)damageValue / (float)target->total_health_point() * 300.0f;
	target->add_energy_value(add_energy);
  }  
  target->set_currnet_health_point(hp);
  CharacterData *char_data = target->character_card_data();
  if (char_data->GetIsEnemy() && char_data->GetMonsterLevel() > kMonsterLevelNormal)
  {
    battle::BattleController::GetInstance().battle_ui()->UpdateBossHp(target->GetCurrentHealthPointPercent()*100);
  }

}
  
void BattleHub::
  GetAllMoveObjectsInTilesWithIndexList(const std::vector<int_8>& indexList,
                                        std::list<army::MoveObject*>& moveObjList,
                                        cocos2d::CCPoint searchCenterPos)
{
  moveObjList.clear();
  if (indexList.size() == 0)
  {
    return;
  }
  
  // need insert by order according to distance
  if (ccpDistanceSQ(searchCenterPos, kUnexistCoordinatePoint)>1)
  {
    for (std::vector<int_8>::const_iterator itIdx = indexList.begin(); itIdx != indexList.end(); ++itIdx)
    {
      TiledObjectsList* aList = &(move_objects_reference_[*itIdx]);
      if (!aList || aList->size()<=0) {
        continue ;
      }
      // get all moveObjs' reference in search tiles list
      for (std::list<army::MoveObject*>::iterator list_it = aList->begin(); list_it != aList->end(); ++list_it)
      {
		army::MoveObject* move_obj = *list_it;
		if ( move_obj->is_temp_dead() )
		{
			continue;
		}
        bool hasInsert = false;
        float dis = ccpDistanceSQ(searchCenterPos, move_obj->current_pos());
        for (std::list<army::MoveObject*>::iterator it = moveObjList.begin(); it != moveObjList.end(); ++it)
        {
          if (dis < ccpDistanceSQ(searchCenterPos, (*it)->current_pos()))
          {
            hasInsert = true;
            moveObjList.insert(it, move_obj);
            break;
          }
        }
        if (!hasInsert)
        {
          moveObjList.push_back(move_obj);
        }
      }
    }
  }
  else
  {
    for (std::vector<int_8>::const_iterator itIdx = indexList.begin();
         itIdx != indexList.end(); ++itIdx)
    {
      TiledObjectsList* aList = &(move_objects_reference_[*itIdx]);
      if (!aList || aList->size()<=0) {
        continue ;
      }
      // get all moveObjs' reference
      for (std::list<army::MoveObject*>::iterator list_it = aList->begin();
           list_it != aList->end(); ++list_it)
      {
        moveObjList.push_back(*list_it);
      }
    }
  }
}  

army::MoveObject* BattleHub::CreateUnitById(uint_32 unit_id, bool is_substitution /* = false */)
{
	return troops_->CreateObjectById(unit_id, is_substitution);
}
army::MoveObject* BattleHub::CreateUnitBySubstitution(uint_32 unit_id)
{
	return troops_->CreateUnitBySubstitution(unit_id);
}

army::MoveObject* BattleHub::CreateSummonUnit()
{
	uint_32 unit_id = summon_troops_->GetNextActiveObjectId();
	return summon_troops_->CreateObjectById(unit_id, false);
}

void BattleHub::SwitchUnitToActiveIdsList(uint_32 unit_id)
{
	return troops_->SwitchUnitToActiveIdsList(unit_id);
}

void BattleHub::insertAttackerReference(army::MoveObject* agent)
{
  int_8 curTileIndex = agent->tile_index();
  assert(battle::IsTileCoordinateInRange(battle:: \
                                GetTileCoordinatePosByTileIndex(curTileIndex)));
  
  TiledObjectsList* aList = &(move_objects_reference_[curTileIndex]);
  if (aList && aList->size()>0)
  {
    std::list<army::MoveObject*>::iterator list_it = aList->begin();
    // move ahead on this list
    for ( ;(list_it != aList->end()) &&
           ((*list_it)->move_object_id() < agent->move_object_id());
         ++list_it)
    {
    }
    if (list_it == aList->end()) {
      move_objects_reference_[curTileIndex].push_back(agent);
    }
    else
    {
      assert((*list_it)->move_object_id() != agent->move_object_id());
      //--list_it;
      move_objects_reference_[curTileIndex].insert(list_it, agent);
    }
  }
  else {
    move_objects_reference_[curTileIndex].push_front(agent);
  }
}

void BattleHub::removeAttackerReference(army::MoveObject* agent)
{
  int curTileIndex = agent->tile_index();
  assert(battle::IsTileCoordinateInRange(battle:: \
                                GetTileCoordinatePosByTileIndex(curTileIndex)));
  
  TiledObjectsList* aList = &(move_objects_reference_[curTileIndex]);
  if (!aList || aList->size()<=0)
  {
    return;
  }
  
  for (std::list<army::MoveObject*>::iterator list_it = aList->begin();
       list_it != aList->end();
       ++list_it)
  {
    if ( (*list_it)->move_object_id() == agent->move_object_id() )
    {
      aList->erase(list_it);
      return;
    }
  }
}

void BattleHub::updateAttackerReference(int_8 originalTileIndex,
                                        army::MoveObject* agent)
{
  int curTileIndex = agent->tile_index();
  assert(battle::IsTileCoordinateInRange(battle:: \
                                GetTileCoordinatePosByTileIndex(curTileIndex)));
  assert(battle::IsTileCoordinateInRange(battle:: \
                           GetTileCoordinatePosByTileIndex(originalTileIndex)));
  assert(originalTileIndex != curTileIndex);
  
  if ( originalTileIndex >= move_objects_reference_.size())
  {
	  assert(0);
	  return;
  }

  TiledObjectsList* aList = &(move_objects_reference_[originalTileIndex]);
  if ( aList->size() <= 0 )
  {
	  if ( agent->is_active())
	  {
		  assert(false);
	  }
    return;
  }
  
  std::list<army::MoveObject*>::iterator list_it = aList->begin();
  for (;
       list_it != aList->end();
       ++list_it)
  {
    if ( (*list_it)->move_object_id()==agent->move_object_id() )
    {
      break;
    }
  }
  if (list_it==aList->end())
  {
    assert(false);
    return;
  }  
  aList->erase(list_it);
  
  this->insertAttackerReference(agent);
}

army::MoveObject* BattleHub::GetUnitById(uint_32 unit_id)
{
	return troops_->GetObjectById(unit_id);
}

army::Summon* BattleHub::GetSunmonUnitById(uint_32 unit_id)
{
	army::MoveObject* obj = summon_troops_->GetObjectById(unit_id);
	if ( obj )
	{
		army::Summon* summon= dynamic_cast<army::Summon*>(obj);
		return summon;
	}
	
	return NULL;
}

uint_32 BattleHub::AddImmediatelySummonAtIndex( uint_16 level, uint_32 card_id, int_8 tileIdx)
{
	return born_hub_->CreateOneSummonWithBornInfoAtIndex( card_id, ai::kAIStateGuard, tileIdx, level);
}
  
} // battle
} // taomee
