//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_state.cpp
//        Author: leohou
//       Version:
//          Date: Oct 20, 2013
//          Time: 10:18:30 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     10:18:30 PM
//
//////////////////////////////////////////////////////////////

#include "game/battle/battle_state.h"

#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_data.h"
#include "game/battle/view/battle_view.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "engine/base/state_machine/state_machine.h"
#include "engine/sound/sound_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "game/battle/monster_hub.h"
// #include "game/user_interface/battle_ui/battle_menu_layer.h"
#include "game/battle/battle_resource_loader.h"
#include "game/event/event_battle/event_battle.h"

namespace taomee {
namespace battle {

// state request session
BattleStateRequestSession* BattleStateRequestSession::Instance()
{
  static BattleStateRequestSession battle_state_request_session;
  return &battle_state_request_session;
}

BattleStateRequestSession::BattleStateRequestSession()
{

}

BattleStateRequestSession::~BattleStateRequestSession()
{

}

void BattleStateRequestSession::Enter(BattleController* battle_controller)
{
  if (battle_controller->getIsInEditorMode())
  {
    battle_controller->OnBattleRequestCompleted();
  }
  else
  {
    battle_controller->getCurrentBattleData()->SendRequestSession();
  }
}

void BattleStateRequestSession::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  // do nothing
}

void BattleStateRequestSession::Exit(BattleController* battle_controller)
{
  // do nothing
}


// state prepare
BattleStatePrepare* BattleStatePrepare::Instance()
{
  static BattleStatePrepare battle_state_prepare;
  return &battle_state_prepare;
}

BattleStatePrepare::BattleStatePrepare() {
}

BattleStatePrepare::~BattleStatePrepare() {
}

void BattleStatePrepare::Enter(BattleController* battle_controller)
{
  battle_controller->BeginPrepare();
  LuaTinkerManager::GetInstance()
    .CallLuaFunc<bool>("script/resource/battle_resource_loader.lua", "get_battle_resource_list");
}

void BattleStatePrepare::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  if (LuaTinkerManager::GetInstance()
    .CallLuaFunc<bool>("script/resource/battle_resource_loader.lua", "load_battle_resource"))
  {
    battle_controller->PrepareOne();
  }
}

void BattleStatePrepare::Exit(BattleController* battle_controller)
{
  LuaTinkerManager::GetInstance()
    .CallLuaFunc<bool>("script/resource/battle_resource_loader.lua", "load_battle_resource_end");
}

////////////////////////////////////////////////////////
// state prepare
BattleStateLoadResource* BattleStateLoadResource::Instance()
{
  static BattleStateLoadResource battle_state_load_resource;
  return &battle_state_load_resource;
}

BattleStateLoadResource::BattleStateLoadResource() {
}

BattleStateLoadResource::~BattleStateLoadResource() {
}

void BattleStateLoadResource::Enter(BattleController* battle_controller)
{

}

void BattleStateLoadResource::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  if (BattleResourceLoader::GetInstance()->update())
  {
    battle_controller->onBattleResourceLoadedEnd();
  }
}

void BattleStateLoadResource::Exit(BattleController* battle_controller)
{

  BattleResourceLoader::GetInstance()->clear();
  battle_controller->EndPrepare();
}

///////////////////////////////////////////////////////

// state drama
BattleStateDrama::BattleStateDrama(){
}
BattleStateDrama::~BattleStateDrama() {
}
BattleStateDrama* BattleStateDrama::Instance()
{
  static BattleStateDrama battle_state_drama;
  return &battle_state_drama;
}
void BattleStateDrama::Enter(BattleController* battle_controller)
{
  bool bHaveDrame = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_Drama_Start");
  
  if (bHaveDrame == false)
  {
    battle_controller->GetStateMachine()->ChangeState(BattleStateBattle::Instance());
  }
}

void BattleStateDrama::UpdateEachFrame(BattleController* battle_controller, float delta)
{
}

void BattleStateDrama::Exit(BattleController* battle_controller)
{
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_Start");

  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
      MonsterHub* hub = static_cast<MonsterHub*>(battle_controller->monster_hub());
      hub->Start();
    }
    break;
  case battle::kBattleType_Pvp:
  case battle::kBattleType_SandBox:
    {

    }
    break;
  default:
    break;
  }
}

//state pvp_prepare

BattleStatePvpPrepare::BattleStatePvpPrepare(){
}
BattleStatePvpPrepare::~BattleStatePvpPrepare() {
}
BattleStatePvpPrepare* BattleStatePvpPrepare::Instance()
{
  static BattleStatePvpPrepare battle_state_pvp_prepare;
  return &battle_state_pvp_prepare;
}
void BattleStatePvpPrepare::Enter(BattleController* battle_controller)
{
  time_delay_ = 0;
  battle_controller->PlayPvpPrepareAnimation();
}

void BattleStatePvpPrepare::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  /*
  time_delay_ += delta;
  if (time_delay_ >= 2.0f)
  {
    battle_controller->GetStateMachine()->ChangeState(BattleStateBattle::Instance());
  }
  */
}

void BattleStatePvpPrepare::Exit(BattleController* battle_controller)
{
}
// state battle
BattleStateBattle* BattleStateBattle::Instance()
{
  static BattleStateBattle battle_state_battle;
  return &battle_state_battle;
}

BattleStateBattle::BattleStateBattle() 
{
}

BattleStateBattle::~BattleStateBattle() 
{
}

void BattleStateBattle::Enter(BattleController* battle_controller)
{
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
  	  battle_controller->EnableBattleTouch();
	    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/battleMenuLayer/BattleMenuCPlusInterface.lua", "battleMenuShowNewBie");
    }
    break;
  case battle::kBattleType_Pvp:
    {
      battle_controller->EnableBattleTouch();
    }
    break;
  case battle::kBattleType_SandBox:
    {
      battle_controller->EnableBattleTouch();
    }
    break;
  default:
    break;
  }
}

void BattleStateBattle::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  battle_controller->UpdateBattle(delta);
}

void BattleStateBattle::Exit(BattleController* battle_controller)
{
  battle_controller->DisableBattleTouch();
}

// state pause
BattleStatePause* BattleStatePause::Instance()
{
  static BattleStatePause battle_state_pause;
  return &battle_state_pause;
}

BattleStatePause::BattleStatePause() {
}

BattleStatePause::~BattleStatePause() {
}

void BattleStatePause::Enter(BattleController* battle_controller)
{
  battle_controller->battle_view()->PauseBattleLayer();
}

void BattleStatePause::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  // do nothing
}

void BattleStatePause::Exit(BattleController* battle_controller)
{
  battle_controller->battle_view()->ResumeBattleLayer();
}


// state result session
BattleStateResultSession* BattleStateResultSession::Instance()
{
  static BattleStateResultSession battle_state_result_session;
  return &battle_state_result_session;
}

BattleStateResultSession::BattleStateResultSession()
{

}

BattleStateResultSession::~BattleStateResultSession()
{

}

void BattleStateResultSession::Enter(BattleController* battle_controller)
{
  if (battle_controller->getIsInEditorMode())
  {
      battle_controller->OnBattleResultCompeleted();
  }
  else
  {
      battle_controller->getCurrentBattleData()->SendResultSession();
  }
}

void BattleStateResultSession::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  // do nothing
}

void BattleStateResultSession::Exit(BattleController* battle_controller)
{
  // do nothing
}


// state win
BattleStateWin* BattleStateWin::Instance()
{
  static BattleStateWin battle_state_win;
  return &battle_state_win;
}

BattleStateWin::BattleStateWin() {
}

BattleStateWin::~BattleStateWin() {
}

void BattleStateWin::Enter(BattleController* battle_controller)
{
  battle::BattleController::GetInstance().BattleVictory();
  int win_music_id = GetLuaMusic("kSIDWin_bgm");
  SoundManager::GetInstance().PlayBackgroundMusic(win_music_id, true);
  //ת�ƿ���Ȩ��Lua��
  //LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/BattleWinStateController.lua", "enterBattleWinState");
}

void BattleStateWin::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  battle_controller->UpdateBattleVictoryCelebration(delta);
}

void BattleStateWin::Exit(BattleController* battle_controller)
{

}

//
// state lose
BattleStatePvpLose* BattleStatePvpLose::Instance()
{
  static BattleStatePvpLose battle_state_pvp_lose;
  return &battle_state_pvp_lose;
}

BattleStatePvpLose::BattleStatePvpLose() {
}

BattleStatePvpLose::~BattleStatePvpLose() {
}

void BattleStatePvpLose::Enter(BattleController* battle_controller)
{
 // battle::BattleController::GetInstance().BattleVictory();
  //int win_music_id = GetLuaMusic("kSIDWin_bgm");
  //SoundManager::GetInstance().PlayBackgroundMusic(win_music_id, true);
}

void BattleStatePvpLose::UpdateEachFrame(BattleController* battle_controller, float delta)
{
  //battle_controller->UpdateBattleVictoryCelebration(delta);
}

void BattleStatePvpLose::Exit(BattleController* battle_controller)
{

}
//

// state failed
BattleStateFailed* BattleStateFailed::Instance()
{
  static BattleStateFailed battle_state_over;
  return &battle_state_over;
}

BattleStateFailed::BattleStateFailed() {
}

BattleStateFailed::~BattleStateFailed() {
}

void BattleStateFailed::Enter(BattleController* battle_controller)
{
  battle::BattleController::GetInstance().BattleFailed();
}

void BattleStateFailed::UpdateEachFrame(BattleController* battle_controller, float delta)
{

}

void BattleStateFailed::Exit(BattleController* battle_controller)
{

}

BattleStateOver* BattleStateOver::Instance()
{
	static BattleStateOver battle_state_over;
	return &battle_state_over;
}

BattleStateOver::BattleStateOver() {
}

BattleStateOver::~BattleStateOver() {
}

void BattleStateOver::Enter(BattleController* battle_controller)
{
	battle::BattleController::GetInstance().BattleOver();
}

void BattleStateOver::UpdateEachFrame(BattleController* battle_controller, float delta)
{
	battle_controller->UpdateLevelEntity(delta);
}

void BattleStateOver::Exit(BattleController* battle_controller)
{

}

} /* namespace battle */
} /* namespace taomee */
