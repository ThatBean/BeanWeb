#ifndef BATTLE_DATA_DEFAULT_H
#define BATTLE_DATA_DEFAULT_H

#include "game/battle/battle_data.h"
#include "network/proto/arena_before_challenge_in.h"
#include "network/proto/arena_before_challenge_out.h"
#include "network/proto/arena_after_challenge_in.h"
#include "network/proto/arena_after_challenge_out.h"

namespace taomee {
  namespace battle {

    class BattleDataDefault : public BattleData
    {
    public:
      BattleDataDefault();
      virtual ~BattleDataDefault();

      virtual void Reset();
      virtual void InitDataForNewBattle();

      virtual void SendRequestSession();
      virtual void SendResultSession();

    };

  } /* namespace battle */
} /* namespace taomee */


#endif