//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_pvp_data.cpp
//        Author: coldouyang
//          Date: 2014/8/26 16:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/8/26      add
//////////////////////////////////////////////////////////////

#include "game/battle/battle_data_default.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/handle_delegate.h"
#include "game/account/account_manager.h"
#include "game/army/unit/character.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/own_hub.h"
#include "game/event/universal_event.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/user_interface/message_box_ui/ui_message_box.h"
#include "game/battle/view/battle_view.h"
#include "game/user_data/friend_info.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "network/net_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/game_logger_manager.h"

namespace taomee {
  namespace battle {

    BattleDataDefault::BattleDataDefault()
    {
      this->Reset();
    }

    BattleDataDefault::~BattleDataDefault()
    {

    }

    void BattleDataDefault::InitDataForNewBattle()
    {
      battle_constions_flag_ = kBattleWinTypeNoLose;
      current_task_id_ = 0;
      current_checkpoint_id_ = 0;
      team_id_ = 0;
      current_friend_id_.clear();
      battle_win_ = false;
      original_rank_ = DataManager::GetInstance().user_info()->rank();
      gain_xp_ = 0;
      gain_xp_for_player_ = 0;
      gain_gold_ = 0;
      gain_ap_ = 0;
      gain_xp_multiple_ = 1.0f;
      gain_gold_multiple_ = 1.0f;
      gain_item_multiple_ = 1.0f;
      //battle_constions_flag_ = 0;
      choosen_friend_ = false;
      for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
      {
        characters_status_[i] = data::kCharacterStatusUnkown;
      }
    }

    void BattleDataDefault::Reset()
    {
      current_task_id_ = 0;
      current_checkpoint_id_ = 0;
      team_id_ = 0;
      current_friend_id_.clear();
      battle_win_ = false;
      original_rank_ = DataManager::GetInstance().user_info()->rank();
      gain_xp_ = 0;
      gain_xp_for_player_ = 0;
      gain_gold_ = 0;
      gain_ap_ = 0;
      gain_xp_multiple_ = 1.0f;
      gain_gold_multiple_ = 1.0f;
      gain_item_multiple_ = 1.0f;
      battle_constions_flag_ = 0;
      choosen_friend_ = false;
      for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
      {
        characters_status_[i] = data::kCharacterStatusUnkown;
      }
    }

    void BattleDataDefault::SendRequestSession()
    {
      BattleController::GetInstance().OnBattleRequestCompleted();
    }

    void BattleDataDefault::SendResultSession()
    {
      BattleController::GetInstance().OnBattleResultCompeleted();
    }

  } /* namespace battle */
} /* namespace taomee */
