//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_resource_loader.h
//        Author: coldouyang
//          Date: 2014/10/23 15:21
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/23      add
//////////////////////////////////////////////////////////////

#ifndef BATTLE_RESOURCE_LOADER_H
#define BATTLE_RESOURCE_LOADER_H

#include "game/battle/battle_controller.h"

class BattleResourceLoader
{
public:
  static BattleResourceLoader* GetInstance();
  bool update();
  void addLoadCardID(int id);
  void clear();
protected:
  void loadSkillResource(int skill_id);
  void loadAuraResource(int aura_id);
  void loadAuraListResource(const std::string& auraList);

  bool add_break_resource_by_break_id(int break_id);

protected:
  void load_projectiles_data(const std::string& res_name);
  void load_armature_data(const std::string& res_name);
protected:
  BattleResourceLoader();
  ~BattleResourceLoader();
  std::vector<int> mLoadArray;
  static BattleResourceLoader* INSTANCE_;
};

#endif