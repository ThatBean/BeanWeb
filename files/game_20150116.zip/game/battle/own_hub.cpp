//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  own_hub.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  4:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/own_hub.h"


#include "game/army/unit/character.h"
#include "game/army/unit/unit_constants.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/army/unit_hub/character_troops_hub.h"
#include "game/army/unit_hub/summon_troops_hub.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/battle/damage/battle_damage.h"
#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_data.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {
namespace battle {
  
OwnHub::OwnHub(bool isRightSideHub)
  : BattleHub(),
  update_stop_flag_(false)
{
  mIsCharacter = true;
  mIsRightSide = isRightSideHub;
  if (mIsRightSide)
  {
    troops_ = new army::CharacterTroopsHub( this, army::kCharaterObject_StartId, army::kCharaterObject_EndId);
	summon_troops_ = new army::SummonTroopsHub( this, army::kCharaterSummonObject_StartId, army::kCharaterSummonObject_EndId);
  }
  else
  {
    troops_ = new army::CharacterTroopsHub( this, army::kPvPCharaterObject_StartId, army::kPvPCharaterObject_EndId);
	summon_troops_ = new army::SummonTroopsHub( this, army::kMonsterSummonObject_StartId, army::kMonsterSummonObject_EndId);
  }
  creatation_list_.clear();
  pvp_creatation_list_.clear();
  characters_info_list_.clear();
}

OwnHub::~OwnHub()
{
  creatation_list_.clear();
  pvp_creatation_list_.clear();
  for (std::list<data::CharacterInfo*>::iterator it = characters_info_list_.begin();
       it != characters_info_list_.end(); ++it)
  {
    delete (*it);
  }
  characters_info_list_.clear();
}
  
void OwnHub::Update(float delta_time)
{
  if (update_stop_flag_)
  {
    return;
  }
  if (false == troops_->Update(delta_time))
  {

  }

  summon_troops_->Update(delta_time);
}

void OwnHub::NotifyOneUnitDead( uint_32 object_id )
{
  army::MoveObject* move_obj = GetUnitById(object_id);
  assert( move_obj );

  battle::BattleController::GetInstance().tiled_map()->
      MoveCharacterOutOfGarrisonTile(object_id, dynamic_cast<army::Character*> 
                                    (move_obj)->garrison_tile_index());
  // reset battle win condition type in battle data
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
      battle::BattleController::GetInstance().battle_data()->
        reset_battle_constions_flag(kBattleWinTypeNoLose);
      this->born_hub()->CreateNextCharacterForBattleWithDestroyedMoveObjectId(object_id);
    }
    break;
  case battle::kBattleType_Pvp:
  case battle::kBattleType_SandBox:
    {

    }
    break;
  default:
    break;
  }
}

void OwnHub::UpdateVictorySpecial(float delta_time)
{
  this->troops()->UpdateVictoryCelebration(delta_time);
}
  
void OwnHub::ShowXpBarForBattleVictory(uint_32 xp,
                                       std::vector<std::pair<uint_8, cocos2d::CCPoint> >& xpPos)
{
  int existCnt = troops_->unremove_dead_ids();
  for (int i = 0; i<existCnt; ++i)
  {
    army::Character* charac = dynamic_cast<army::Character*>(troops_->GetDeadObjectByIndex(i));
    if (NULL==charac || NULL==charac->anima_node() ||
        NULL==charac->anima_node()->getChildByTag(army::kHitPointBarFlag))
    {
      continue;
    }
    uint_8 level = charac->ShowXpBarForXpReward(xp);
    cocos2d::CCPoint bonePos = charac->anima_node()->GetBonePositionInSkeleton(kBoneTypeHealthBar);
    xpPos.push_back(std::pair<uint_8, cocos2d::CCPoint>(level,
                          ccpAdd(charac->anima_node()->getPosition(), bonePos) ));
  }
}

void OwnHub::ShowRankUpForBattleVictory(std::vector<cocos2d::CCPoint>& bottomPos)
{
  int existCnt = troops_->unremove_dead_ids();
  for (int i = 0; i<existCnt; ++i)
  {
    army::Character* charac = dynamic_cast<army::Character*>(troops_->GetDeadObjectByIndex(i));
    if (NULL==charac || NULL==charac->anima_node() ||
      NULL==charac->anima_node()->getChildByTag(army::kHitPointBarFlag))
    {
      continue;
    }
    bottomPos.push_back(charac->anima_node()->getPosition());
  }
}
  
void OwnHub::CreateOneCharacter(uint_32 unitId,
                                uint_32 cardId,
                                uint_8  tileIdx,
                                uint_8  level,
                                bool    isFriend)
{
  //assert(unitId<army::kCharaterObjectCount);
  //assert(level<army::kMaxCharacterLevel);
  //assert(tileIdx<(battle::kMapColumnCount/2)*(battle::kMapColumnCount/2));

  uint_8 tileX = tileIdx%battle::kMapColumnCount;
  uint_8 tileY = tileIdx/battle::kMapColumnCount;
  //uint_8 tileX = tileIdx / battle::kMapRowCount;
  //uint_8 tileY = tileIdx % battle::kMapRowCount;
  creatation_list_.push_back(CharacterCreatationInfo(unitId, cardId, tileX, tileY, level, isFriend));
}

void OwnHub::CreateOnePvpCharacter(uint_32 unitId, PvpCharacterCreatationInfo& data)
{
  pvp_creatation_list_.push_back(PvpCharacterCreatationInfo(data));
}

void OwnHub::CreateNextCharacterForLua(uint_32 unitId, uint_32 cardId, uint_32 level)
{
  this->born_hub()->CreateNextCharacterForLua(unitId, cardId, level);
  battle::BattleController::GetInstance().battle_ui()->UpdateSkillReleaseButtonByCreateChar();
}

void OwnHub::AddImmediatelyCharacterAtIndex( uint_16 level,
  uint_32 unit_id,
  uint_32 card_id,
  int_8 tileIdx,
  bool isFriend)
{
  this->born_hub()->CreateOneCharacterWithBornInfo(unit_id,
    card_id,
    level,
    tileIdx % battle::kMapColumnCount,
    tileIdx / battle::kMapColumnCount,
    isFriend);
}

void OwnHub::GetAllLevelupCharacterIds(std::vector<uint_32>& ids)
{
  ids.clear();
  int existCnt = troops_->unremove_dead_ids();
  for (int i = 0; i<existCnt; ++i)
  {
    army::Character* charac = dynamic_cast<army::Character*>(troops_->GetDeadObjectByIndex(i));
    if (charac->is_levelup()) {
      ids.push_back(charac->sequence_id());
    }
  }
}
  



void OwnHub::AddInvincibleBUFFStatusOnRole(int_32 unitId, bool isAddFlag)
{
  if (LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId") <= 10 || LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId") <= 10 )
  {
    army::MoveObject* unit = troops_->GetObjectById(unitId);
    if ( unit )
    {
      if (isAddFlag) 
      {
        unit->retain_battle_status_flag(battle::kDamageInvincible);
      }
      else
      {
        unit->release_battle_status_flag(battle::kDamageInvincible);
      }
    }
  }

}

void OwnHub::SetOwnHubUpdateFlag( bool bStopUpdateFlag )
{
  update_stop_flag_ = bStopUpdateFlag;
}


} // namespace battle
} // namespace taomee