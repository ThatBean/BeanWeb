//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_touch_handler.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/touch/battle_touch_handler.h"

#include "engine/animation/projectile_animation.h"
#include "engine/base/random_helper.h"
#include "engine/particle/particle_manager.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_hub.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/battle/view/aim_mark.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/view/player_box.h"
#include "game/effect/touch_area_layer.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "engine/sound/sound_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "game/battle/battle_data.h"

namespace {
const uint_32 kInvalidUnitId = -1;

}

using namespace cocos2d;

namespace taomee {
namespace battle {

BattleTouchHandler::BattleTouchHandler()
: battle_controller_(NULL),
  touch_state_(kTouchDisabled),
  selected_character_id_(0),
  selected_characted_focused_(false),
  selected_by_current_touch_(false),
  current_target_id_(kInvalidUnitId),
  current_touch_position_(CCPointZero),
  touch_began_position_(CCPointZero),
  line_(NULL),
  area_node_(NULL)
{

}

BattleTouchHandler::~BattleTouchHandler()
{
  battle_controller_ = NULL;

  CC_SAFE_RELEASE_NULL(line_);
  CC_SAFE_RELEASE_NULL(area_node_);
}

void BattleTouchHandler::OnTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent* e,
                                        cocos2d::CCLayer* target_layer)
{
  if (battle_controller_->is_forbid_touch())
  {
    return;
  }

  if (touch_state_ == kTouchDisabled)
  {
    return;
  }

  touch_state_ = kTouchInvalid;
  selected_by_current_touch_ = false;
  current_target_id_ = kInvalidUnitId;
  current_touch_position_ = CCPointZero;
  touch_began_position_ = CCPointZero;

  // TODO(leohou): should process multi touches?
  if (touches->count() > 1)
  {
    return;
  }

  touch_state_ = kTouchBegan;

  CCTouch* touch = dynamic_cast<CCTouch*>(touches->anyObject());
  CCPoint location_in_target_layer = target_layer->convertToNodeSpace(touch->getLocation());

  touch_began_position_ = location_in_target_layer;

  if (selected_character_id_ == kInvalidUnitId)
  {
    uint_32 character_id = kInvalidUnitId;
    if (!this->IsTouchOnCharacter(location_in_target_layer, character_id))
    {
      return;
    }
    // �ű����Ƶ��
    if ( battle_controller_->handling_obj_id() != army::kUnexistTargetId )
    {
      if (battle_controller_->handling_obj_id() != character_id)
      {
        return;
      }
    }  

    this->FocusCharacter(character_id);
    this->SelectCharacter(character_id);
  }
  else
  {
    uint_32 character_id = kInvalidUnitId;
    if (this->IsTouchOnCharacter(location_in_target_layer, character_id))
    {
      // �ű����Ƶ��
      if ( battle_controller_->handling_obj_id() != army::kUnexistTargetId )
      {
        if (battle_controller_->handling_obj_id() != character_id)
        {
          return;
        }
      }  

      if (selected_character_id_ == character_id && !selected_characted_focused_)
      {
        this->FocusCharacter(character_id);
      }
      else if (selected_character_id_ != character_id)
      {
        this->DefocusCharacter(selected_character_id_);
        this->FocusCharacter(character_id);

        this->SelectCharacter(character_id);
      }
    }
  }
}

void BattleTouchHandler::OnTouchesMoved(cocos2d::CCSet* touches, cocos2d::CCEvent* e,
                                        cocos2d::CCLayer* target_layer)
{
  if (battle_controller_->is_forbid_touch())
  {
    return;
  }
  if (touch_state_ == kTouchDisabled ||
      touch_state_ == kTouchInvalid)
  {
    return;
  }

  if (!selected_characted_focused_)
  {
    return;
  }

  // Note: on some android devices, just touch down and up may trigger touch moved event,
  // so we have to filter touch moved event
  CCTouch* touch = dynamic_cast<CCTouch*>(touches->anyObject());
  CCPoint location_in_target_layer = target_layer->convertToNodeSpace(touch->getLocation());

  if (touch_state_ != kTouchMoved &&
	  fabs(touch_began_position_.x - location_in_target_layer.x) <= kMapTileAverageLength * 0.33f &&
	  fabs(touch_began_position_.y - location_in_target_layer.y) <= kMapTileAverageHeight * 0.33f)
  {
	  return;
  }

  CCLog("touch moved");
  touch_state_ = kTouchMoved;

  this->RemoveGaurdCircle();

  current_touch_position_ = location_in_target_layer;

  this->UpdateMovedTouch(current_touch_position_);
}

void BattleTouchHandler::OnTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* e,
                                        cocos2d::CCLayer* target_layer)
{
  if (battle_controller_->is_forbid_touch())
  {
    return;
  }
  if (touch_state_ == kTouchDisabled ||
      touch_state_ == kTouchInvalid)
  {
    return;
  }

  if (!selected_characted_focused_)
  {
    return;
  }

  CCTouch* touch = dynamic_cast<CCTouch*>(touches->anyObject());
  CCPoint location_in_target_layer = target_layer->convertToNodeSpace(touch->getLocation());
  
  uint_32 unit_id = kInvalidUnitId;
  if (touch_state_ == kTouchBegan)
  {
    if (battle_controller_->handling_target_tile_idx() == -1 && this->IsTouchOnMonster(location_in_target_layer, unit_id))
    {
      // �ű����Ƶ��
      if ( battle_controller_->handling_target_obj_id() != army::kUnexistTargetId )
      {
        if (battle_controller_->handling_target_obj_id() == unit_id)
        {
          this->AimTarget(unit_id);
          this->CancelTarget(unit_id, false);
          this->OnTouchEndedOnMonster(unit_id, location_in_target_layer);
        }
        else
        {
          this->OnTouchEndedOnPosition(location_in_target_layer);
        }
      }  
      else
      {
        this->AimTarget(unit_id);
        this->CancelTarget(unit_id, false);
        this->OnTouchEndedOnMonster(unit_id, location_in_target_layer);
      }   
    }
    else if (this->IsTouchOnCharacter(location_in_target_layer, unit_id))
    {
      if (selected_character_id_ == unit_id && !selected_by_current_touch_)
      {
        // �ű����Ƶ��
        if ( battle_controller_->handling_obj_id() != army::kUnexistTargetId )
        {
          if (battle_controller_->handling_obj_id() == unit_id)
          {
            this->DefocusCharacter(selected_character_id_);
          }
        }  
        else
        {
          this->DefocusCharacter(selected_character_id_);
        }         
      }
      else if (selected_character_id_ != unit_id)
      {
        this->AimTarget(unit_id);
        this->CancelTarget(unit_id, false);
        this->OnTouchEndedOnCharacter(unit_id, location_in_target_layer);
      }
      else 
      {
        this->RemoveGaurdCircle();
      }
    }
    else
    {
       this->OnTouchEndedOnPosition(location_in_target_layer);
    }

    touch_state_ = kTouchEnded;
    return;
  }
  else if (touch_state_ == kTouchMoved)
  {
    if (current_target_id_ != kInvalidUnitId)
    {
      this->CancelTarget(current_target_id_,false);
      current_target_id_ = kInvalidUnitId;
    }
    if (battle_controller_->handling_target_tile_idx() == -1 && this->IsTouchOnMonster(location_in_target_layer, unit_id))
    {
      // �ű����Ƶ��
      if ( battle_controller_->handling_target_obj_id() != army::kUnexistTargetId )
      {
        if (battle_controller_->handling_target_obj_id() == unit_id)
        {
          this->OnTouchEndedOnMonster(unit_id, location_in_target_layer);
        }
        else
        {
          this->OnTouchEndedOnPosition(location_in_target_layer);
        }
      }  
      else
      {
        this->OnTouchEndedOnMonster(unit_id, location_in_target_layer);
      }  
    }
    else if (this->IsTouchOnCharacter(location_in_target_layer, unit_id))
    {
      // �ű����Ƶ��
      if ( battle_controller_->handling_obj_id() != army::kUnexistTargetId )
      {
        if (battle_controller_->handling_obj_id() == unit_id)
        {
          this->OnTouchEndedOnCharacter(unit_id, location_in_target_layer);
        }
      }  
      else
      {
        this->OnTouchEndedOnCharacter(unit_id, location_in_target_layer);
      }   
    }
    else
    {
       this->OnTouchEndedOnPosition(location_in_target_layer);
     }
  }

  touch_state_ = kTouchEnded;
}

bool BattleTouchHandler::IsTouchOnCharacter(const cocos2d::CCPoint& touch_point, uint_32& character_id)
{
  std::map<uint_32, SkeletonAnimation*> unit_container;
  battle_controller_->GetActiveUnitAniamtionList(unit_container);
  float percent = 1000;
  for (std::map<uint_32, SkeletonAnimation*>::iterator unit_iter = unit_container.begin();
      unit_iter != unit_container.end(); ++unit_iter)
  {
    if (false == battle_controller_->GetObjectById((unit_iter->first))->owner_hub()->IsCharacterHub())
    {
      continue;
    }

    SkeletonAnimation* skeleton_animation = unit_iter->second;
    const cocos2d::CCRect rect = skeleton_animation->GetBoundingBox();
    if (rect.containsPoint(touch_point))
    {
      taomee::army::MoveObject* obj = battle_controller_->get_active_unit_by_id(unit_iter->first);
	  if ( obj->check_battle_status_flag( battle::kDamageEnchantment) == false)
	  {
		  float o_percent = obj->GetCurrentHealthPointPercent();
		  if (o_percent < percent)
		  {
			  percent = o_percent;
			  character_id = unit_iter->first;
		  }
	  }
    }
  }
  
  if (percent < 1000)
  {
    return true;
  }
  
  return false;
}

bool BattleTouchHandler::IsTouchOnMonster(const cocos2d::CCPoint& touch_point, uint_32& monster_id)
{
  std::map<uint_32, SkeletonAnimation*> unit_container;
  battle_controller_->GetActiveUnitAniamtionList(unit_container);

  for (std::map<uint_32, SkeletonAnimation*>::iterator unit_iter = unit_container.begin();
      unit_iter != unit_container.end(); ++unit_iter)
  {
    if (battle_controller_->GetObjectById((unit_iter->first))->owner_hub()->IsCharacterHub())
    {
      continue;
    }

    SkeletonAnimation* skeleton_animation = unit_iter->second;
    const cocos2d::CCRect rect = skeleton_animation->GetBoundingBox();
    if (rect.containsPoint(touch_point))
    {
      // TODO(leohou): take unit's zorder into account
      monster_id = unit_iter->first;
      return true;
    }
  }

  return false;
}

void BattleTouchHandler::FocusCharacter(const uint_32 character_id)
{
  // TODO(leohou)
  CCLog("FocusCharacter: character_id = %ld", character_id);

  selected_characted_focused_ = true;

  using namespace army;

  army::MoveObject *selected_object = battle_controller_->GetObjectById(character_id);
  if ( !selected_object )
  {
	  assert(0);
	  return;
  }
  
  selected_object->anima_manager()->StartGuardArea(10000.f);
  selected_object->anima_manager()->StartHitRedShader(0.5f);

  CCNode* bind_node = battle_controller_->battle_view()->GetLayerBindNode(battle::kBottomLayer, character_id);
  PlayerBox* player_box =  dynamic_cast<PlayerBox*>(bind_node->getChildByTag(kPlayerBoxTag));

  if (player_box->IsSelected())
  {
    selected_by_current_touch_ = false;
  }
  else
  {
    selected_by_current_touch_ = true;
  }

  if (player_box != NULL)
  {
    player_box->OnSelected();
  }
  else
  {
    assert(player_box != NULL);
  }
}

void BattleTouchHandler::DefocusCharacter(const uint_32 character_id)
{
  // TODO(leohou)
  CCLog("DefocusCharacter: character_id = %ld", character_id);

  if (character_id == kInvalidUnitId)
  {
    return;
  }
  
  selected_characted_focused_ = false;

  using namespace army;
  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(character_id);
  if ( !unit || !unit->is_active() )
  {
    return;
  }
  CCNode* bind_node = battle_controller_->battle_view()->GetLayerBindNode(battle::kBottomLayer, character_id);
  PlayerBox* player_box =  dynamic_cast<PlayerBox*>(bind_node->getChildByTag(kPlayerBoxTag));

  if (player_box != NULL)
  {
    player_box->OnUnselected();
  }
  else
  {
    assert(player_box != NULL);
  }

}

void BattleTouchHandler::OnTouchMoveToCharacter(const uint_32 character_id, const cocos2d::CCPoint& position)
{
  // TODO(leohou)
  //CCLog("OnTouchMoveToCharacter: character_id = %d", character_id);
  this->RemoveArea();
  this->AddLineToPosition(position);

  if (character_id == selected_character_id_)
  {
    using namespace army;
    army::MoveObject* unit = battle_controller_->GetObjectById(selected_character_id_);
    if ( !unit || !unit->is_active())
    {
      this->RemoveArea();
      return;
    }

    int_8 character_tile_index =battle::GetTileIndexByCurrentPointPosition(unit->current_pos());
    CCPoint center_point = battle::GetCenterPointPositionInTile(character_tile_index);

    this->AddAreaOnPosition(center_point);
    return;
  }

  if (character_id == current_target_id_)
  {
    return;
  }

  this->CancelTarget(current_target_id_);
  this->AimTarget(character_id);

  current_target_id_ = character_id;
}

void BattleTouchHandler::OnTouchMoveToMonster(const uint_32 monster_id, const cocos2d::CCPoint& position)
{
  // TODO(leohou)
  //CCLog("OnTouchMoveToMonster: monster_id = %d", monster_id);
  this->RemoveArea();
  this->AddLineToPosition(position);

  if (monster_id == current_target_id_)
  {
    return;
  }

  this->AimTarget(monster_id);
  this->CancelTarget(current_target_id_);

  current_target_id_ = monster_id;
}

void BattleTouchHandler::OnTouchMoveToPosition(const cocos2d::CCPoint& position)
{
  // TODO(leohou)
  this->AddLineToPosition(position);

  if (current_target_id_ != kInvalidUnitId)
  {
    this->CancelTarget(current_target_id_);
    current_target_id_ = kInvalidUnitId;
  }

  // touch in tile
  int_8 touch_tile_index = battle::GetTileIndexByCurrentPointPosition(position);

  //�ڵз�����ɵվ������
  //if (battle::IsTileIndexInRightPart(touch_tile_index))
  //{
    CCPoint center_point = battle::GetCenterPointPositionInTile(touch_tile_index);
    this->AddAreaOnPosition(center_point);
  //}
  //else
  //{
  //  this->RemoveArea();
  //}
  //�ڵз�����ɵվ������
}

void BattleTouchHandler::OnTouchEndedOnCharacter(const uint_32 character_id, const cocos2d::CCPoint& position)
{
  // TODO(leohou)
  
  //��ɫ����λ�ý����Ұ볡
  army::MoveObject* unit = battle_controller_->GetObjectById(selected_character_id_);
  int_8 target_tile_idx = battle::GetTileIndexByCurrentPointPosition(unit->current_pos());
  if (battle::IsTileIndexInRightPart(target_tile_idx))
  {
    battle_controller_->ExchangeOneCharacterToAnother(selected_character_id_, character_id);
  }
  else
  {
    OnTouchEndedOnPositionWithoutAction(position);
  }
  //��ɫ����λ�ý����Ұ볡

  this->RemoveLine();
  this->RemoveArea();

  this->DefocusCharacter(selected_character_id_);
  SoundManager::GetInstance().PlayEffect(GetLuaSoundEffect("kSIDTouchEndOnScreen"));
}

void BattleTouchHandler::OnTouchEndedOnMonster(const uint_32 monster_id, const cocos2d::CCPoint& position)
{
  // TODO(leohou)  
  this->RemoveLine();
  this->RemoveArea();

  if (battle_controller_->handling_target_obj_id() != army::kUnexistTargetId && battle_controller_->handling_target_obj_id() == monster_id)
  {
    //string str_path = "script/checkpoint/" + Uint2String(battle_controller_->battle_data()->current_checkpoint_id()) + ".lua";
    //LuaTinkerManager::GetInstance().CallLuaFunc<int>(str_path.c_str(), "Battle_Move_End");


    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_Move_End");
  }

  battle_controller_->DispatchOneCharacterToAttackSelectedMonster(selected_character_id_, monster_id);

  this->DefocusCharacter(selected_character_id_);
  SoundManager::GetInstance().PlayEffect(GetLuaSoundEffect("kSIDTouchEndOnScreen"));
}

void BattleTouchHandler::OnTouchEndedOnPosition(const cocos2d::CCPoint& position)
{
  // TODO(leohou)
  this->RemoveLine();
  this->RemoveArea();

  if (battle_controller_->handling_target_tile_idx() != -1 )
  {
    if (battle_controller_->handling_target_tile_idx() != GetTileIndexByCurrentPointPosition(position))
    {   
    }
    else
    {
      //string str_path = "script/checkpoint/" + Uint2String(battle_controller_->battle_data()->current_checkpoint_id()) + ".lua";
      //LuaTinkerManager::GetInstance().CallLuaFunc<int>(str_path.c_str(), "Battle_Move_End");


      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_Move_End");

    }
  }

  if (battle_controller_->handling_target_obj_id() != army::kUnexistTargetId)
  {
    return;
  }

  bool moved = battle_controller_->DispatchOneCharacterToGarrisonTargetPoint(selected_character_id_, position);
  
  if (moved)
  {
    this->DefocusCharacter(selected_character_id_);
  }
  else
  {
    OnTouchEndedOnPositionWithoutAction(position);
  }
  SoundManager::GetInstance().PlayEffect(GetLuaSoundEffect("kSIDTouchEndOnScreen"));
}

void BattleTouchHandler::OnTouchEndedOnPositionWithoutAction(const cocos2d::CCPoint& position)
{
  if (touch_state_ == kTouchMoved)
  {
    if (position.x != touch_began_position_.x && position.y != touch_began_position_.y)
    {
      uint_32 monster_id = kInvalidUnitId;
      if (isIntersectWithMonster(touch_began_position_, position, monster_id))
      {
        OnTouchEndedOnMonster(monster_id, position);
      }
      else
      {
        if (position.x > touch_began_position_.x) //1.�Ƿ���������
        {
          const int index_table[9] = {3, 9, 15, 4, 10, 16, 5, 11, 17};
          for (int i = 0; i < 9; ++i)
          {
            cocos2d::CCPoint p = GetPointPositionByGridTileIndex(index_table[i]);
          
            bool moved = battle_controller_->DispatchOneCharacterToGarrisonTargetPoint(selected_character_id_, p);

            if (moved)
            {
              this->DefocusCharacter(selected_character_id_);
              return;
            }
          }
        }

        //�ڵз�����ɵվ������
        // set new motion & target position
        army::MoveObject* unit = battle_controller_->GetObjectById(selected_character_id_);
        int_8 target_tile_idx = battle::GetTileIndexByCurrentPointPosition(position);
        cocos2d::CCPoint target_pos = battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);
        unit->target_selection()->resetTargetSelection();
        unit->target_selection()->set_is_forced_move_to(true);
        unit->target_selection()->set_target_pos(target_pos);
        unit->set_ai_state(ai::kAIStateGuard);
        //�ڵз�����ɵվ������
      }
    }
  }  
}

void BattleTouchHandler::AddLineToPosition(const cocos2d::CCPoint& position)
{
  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(selected_character_id_);
  if ( !unit || !unit->is_active())
  {
    // selected character invalid, remove the line
    this->RemoveLine();
    return;
  }

  if (line_ == NULL)
  {
    line_ = CCSprite::createWithSpriteFrameName("line.png");
    line_->setFlipX(true);
    line_->retain();
  }

  line_->setVisible(true);

  if (line_->getParent() == NULL)
  {
    battle_controller_->battle_view()->AddElementToScene(line_, kBottomLayer);
  }


  line_->setAnchorPoint(ccp(0.0f, 0.5f));
  line_->setPosition(unit->current_pos());

  float line_length = ccpDistance(position, unit->current_pos());
  line_->setScaleX(line_length / line_->getContentSize().width);

  float radian = 2 * M_PI - RadiansBetweenPoint(unit->current_pos(), position);
  line_->setRotation(CC_RADIANS_TO_DEGREES(radian));
}

void BattleTouchHandler::RemoveLine()
{
  if (line_ != NULL)
  {
    line_->removeFromParentAndCleanup(true);
    CC_SAFE_RELEASE_NULL(line_);
  }
}

void BattleTouchHandler::AddAreaOnPosition(const cocos2d::CCPoint& position)
{
  using namespace army;
  army::MoveObject* unit = battle_controller_->GetObjectById(selected_character_id_);

  if ( !unit || !unit->is_active())
  {
    this->RemoveArea();
    return;
  }

  unit->anima_manager()->RemoveGuardArea();

  if (area_node_ == NULL)
  {
    area_node_ = effect::TouchAreaLayer::create(unit, effect::kTouchAreaGuard);
    area_node_->retain();
    battle_controller_->battle_view()->AddElementToScene(area_node_, kBottomLayer);
  }

  area_node_->setPosition(position);
}

void BattleTouchHandler::RemoveArea()
{
  if (area_node_ != NULL)
  {
    area_node_->removeFromParentAndCleanup(true);
    CC_SAFE_RELEASE_NULL(area_node_);
  }
}

void BattleTouchHandler::RemoveGaurdCircle()
{
  army::MoveObject* unit = battle_controller_->GetObjectById(selected_character_id_);

  if (!unit)
  {
	return;
  }

  unit->anima_manager()->RemoveGuardArea();
}

void BattleTouchHandler::AimTarget(const uint_32 character_id)
{
  using namespace army;
  army::MoveObject* unit = battle_controller_->GetObjectById(character_id);

  if ( !unit || !unit->is_active())
  {
    return;
  }

  AimMark* aim_mark = dynamic_cast<AimMark*>(unit->anima_node()->getChildByTag(kAimMarkTag));
  if (aim_mark != NULL)
  {
    aim_mark->OnSelected(static_cast<AimMarkType>(!army::AreTwoMoveObjectsInTheSameForceHub(character_id, selected_character_id_)));
  }
  else
  {
    assert(aim_mark != NULL);
  }
}

void BattleTouchHandler::CancelTarget(const uint_32 character_id, bool is_hide_now/* = true*/)
{
  if (character_id == kInvalidUnitId)
  {
    return;
  }

  using namespace army;
  army::MoveObject* unit = battle_controller_->GetObjectById(character_id);

  if ( !unit|| !unit->is_active())
  {
    return;
  }

  AimMark* aim_mark = dynamic_cast<AimMark*>(unit->anima_node()->getChildByTag(kAimMarkTag));
  if (aim_mark != NULL)
  {
    aim_mark->OnUnselected(is_hide_now);
  }
  else
  {
    assert(aim_mark != NULL);
  }
}

void BattleTouchHandler::EnableTouch()
{
  assert(touch_state_ == kTouchDisabled);

  touch_state_ = kTouchInvalid;
}

void BattleTouchHandler::DisableTouch()
{
  if (touch_state_ == kTouchDisabled)
  {
    return;
  }  

  this->DefocusCharacter(selected_character_id_);
  this->RemoveArea();
  this->RemoveLine();
  this->CancelTarget(current_target_id_, true);

  touch_state_ = kTouchDisabled;
}

void BattleTouchHandler::UpdateEachFrame(float delta_time)
{
  if (battle_controller_->is_forbid_touch())
  {
    return;
  }
  
  if (touch_state_ != kTouchMoved)
  {
    return;
  }

  using namespace army;
  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(selected_character_id_);

  if ( !unit || !unit->is_active())
  {
    // current selected unit invalid, break touch cycle
    this->CancelTarget(current_target_id_);
    this->RemoveLine();
    return;
  }
  else
  {
    // update line start point
    if (line_ != NULL)
    {
      line_->setPosition(unit->current_pos());
    }
  }

  this->UpdateMovedTouch(current_touch_position_);
}

void BattleTouchHandler::SelectCharacter(const uint_32 character_id)
{
  selected_character_id_ = character_id;
  battle_controller_->battle_ui()->OneCharacterSelectedByPlayer(character_id);
}


void BattleTouchHandler::UpdateMovedTouch(const cocos2d::CCPoint& position)
{
  uint_32 unit_id = kInvalidUnitId;
  if (this->IsTouchOnMonster(position, unit_id))
  {
    if ( (battle_controller_->handling_target_obj_id() != army::kUnexistTargetId && battle_controller_->handling_target_obj_id() != unit_id)
      || battle_controller_->handling_target_tile_idx() != -1)
    {
      return;
    }    
    this->OnTouchMoveToMonster(unit_id, position);
    return;
  }

  if (this->IsTouchOnCharacter(position, unit_id))
  {
    if ( battle_controller_->handling_obj_id() != army::kUnexistTargetId && battle_controller_->handling_obj_id() != unit_id)
    {
      return;
    }    
    this->OnTouchMoveToCharacter(unit_id, position);
    return;
  }

  this->OnTouchMoveToPosition(position);
}

void BattleTouchHandler::SetChooseCharacter(uint_32 character_id)
{
  if (selected_character_id_ != character_id)
  {
    this->DefocusCharacter(selected_character_id_);
    this->FocusCharacter(character_id);

    this->SelectCharacter(character_id);
    this->RemoveGaurdCircle();
  }
}

void BattleTouchHandler::SetMoveCharacter(uint_32 character_id, int_8 tile_idx)
{
  if (selected_character_id_ != character_id)
  {
    this->DefocusCharacter(selected_character_id_);
    this->FocusCharacter(character_id);

    this->SelectCharacter(character_id);
    this->RemoveGaurdCircle();
  }
  CCPoint pos = GetCenterPointPositionInTile(tile_idx);
  this->OnTouchEndedOnPosition(pos);
}

bool BattleTouchHandler::isIntersectWithMonster(const cocos2d::CCPoint& p1, const cocos2d::CCPoint& p2, uint_32& monster_id)
{

  std::map<uint_32, SkeletonAnimation*> unit_container;
  battle_controller_->GetActiveUnitAniamtionList(unit_container);

  for (std::map<uint_32, SkeletonAnimation*>::iterator unit_iter = unit_container.begin();
    unit_iter != unit_container.end(); ++unit_iter)
  {
    if (battle_controller_->GetObjectById((unit_iter->first))->owner_hub()->IsCharacterHub())
    {
      continue;
    }

    SkeletonAnimation* skeleton_animation = unit_iter->second;
    const cocos2d::CCRect rect = skeleton_animation->GetBoundingBox();
    if (isRayIntersectWithRect(p1, p2, rect))
    {
      CCLog("--Monst Id=%d", unit_iter->first);
      monster_id = unit_iter->first;
      return true;
    }
  }
  return false;
}

bool BattleTouchHandler::isRayIntersectWithRect(const cocos2d::CCPoint& p1, const cocos2d::CCPoint& p2, const cocos2d::CCRect& rect)
{
  CCPoint result;
  bool direction = (p2.x - p1.x) > 0 ? true : false;
  //1.right
  result.x = rect.getMaxX();
  calcualteLinePositionFixedX(p1, p2, result);
  bool resultDirection = (result.x - p1.x) > 0 ? true : false; 
  if (resultDirection != direction || result.y < rect.getMinY() || result.y > rect.getMaxY())
  {  
  }
  else
  {
    return true;
  }
  //2.top
  result.y = rect.getMaxY();
  calcualteLinePositionFixedY(p1, p2, result);
  resultDirection = (result.x - p1.x) > 0 ? true : false;
  if (resultDirection != direction || result.x < rect.getMinX() || result.x > rect.getMaxX())
  {
  }
  else
  {
    return true;
  }
  
  //3.bottom
  result.y = rect.getMinY();
  calcualteLinePositionFixedY(p1, p2, result);
  resultDirection = (result.x - p1.x) > 0 ? true : false;
  if (resultDirection != direction || result.x < rect.getMinX() || result.x > rect.getMaxX())
  {
  }
  else
  {
    return true;
  }
  return false;
}

bool BattleTouchHandler::calcualteLinePositionFixedX(const cocos2d::CCPoint & p1, const cocos2d::CCPoint& p2, cocos2d::CCPoint& outResult)
{
  outResult.y = (outResult.x * (p2.y - p1.y) - (p1.x * p2.y) + (p1.y * p2.x)) / (p2.x - p1.x);
  return true; 
}

bool BattleTouchHandler::calcualteLinePositionFixedY(const cocos2d::CCPoint & p1, const cocos2d::CCPoint& p2, cocos2d::CCPoint& outResult)
{
  outResult.x = (outResult.y * (p2.x - p1.x) - (p1.y * p2.x) + (p1.x * p2.y)) / (p2.y - p1.y);
  return true;
}

} /* namespace battle */
} /* namespace taomee */
