//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: touch_handler.h
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#ifndef TOUCH_HANDLER_H_
#define TOUCH_HANDLER_H_


namespace cocos2d {
class CCSet;
class CCEvent;
class CCLayer;
}

namespace taomee {
namespace battle {

class TouchHandler {
public:
  virtual void OnTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent* e,
                              cocos2d::CCLayer* target_layer) = 0;
  virtual void OnTouchesMoved(cocos2d::CCSet* touches, cocos2d::CCEvent* e,
                              cocos2d::CCLayer* target_layer) = 0;
  virtual void OnTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* e,
                              cocos2d::CCLayer* target_layer) = 0;
};

} /* namespace battle */
} /* namespace taomee */
#endif /* TOUCH_HANDLER_H_ */
