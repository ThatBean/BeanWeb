//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_touch_handler.h
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_TOUCH_HANDLER_H_
#define BATTLE_TOUCH_HANDLER_H_

#include "game/battle/touch/touch_handler.h"

#include "engine/base/basictypes.h"

#include "cocoa/CCGeometry.h"

namespace cocos2d {
class CCNode;
class CCSprite;
class CCLabelTTF;
}

namespace taomee {
namespace battle {

class BattleController;

class BattleTouchHandler : public TouchHandler {
public:
  BattleTouchHandler();
  virtual ~BattleTouchHandler();

  virtual void OnTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent* e, cocos2d::CCLayer* target_layer);
  virtual void OnTouchesMoved(cocos2d::CCSet* touches, cocos2d::CCEvent* e, cocos2d::CCLayer* target_layer);
  virtual void OnTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* e, cocos2d::CCLayer* target_layer);

  void EnableTouch();
  void DisableTouch();

  void set_battle_controller(BattleController* battle_controller)
  {
    battle_controller_ = battle_controller;
  }
  
  uint_32 selected_character_id()
  {
    return selected_character_id_;
  }

  void UpdateEachFrame(float delta_time);

  void SelectCharacter(const uint_32 character_id);

  void SetChooseCharacter(uint_32 character_id);

  void SetMoveCharacter(uint_32 character_id, int_8 tile_idx);
private:
  bool IsTouchOnCharacter(const cocos2d::CCPoint& touch_point, uint_32& character_id);
  bool IsTouchOnMonster(const cocos2d::CCPoint& touch_point, uint_32& monster_id);

  void FocusCharacter(const uint_32 character_id);
  void DefocusCharacter(const uint_32 character_id);

  void OnTouchMoveToCharacter(const uint_32 character_id, const cocos2d::CCPoint& position);
  void OnTouchMoveToMonster(const uint_32 monster_id, const cocos2d::CCPoint& position);
  void OnTouchMoveToPosition(const cocos2d::CCPoint& position);

  void OnTouchEndedOnCharacter(const uint_32 character_id, const cocos2d::CCPoint& position);
  void OnTouchEndedOnMonster(const uint_32 monster_id, const cocos2d::CCPoint& position);
  void OnTouchEndedOnPosition(const cocos2d::CCPoint& position);

  //TODO coldouyang
  void OnTouchEndedOnPositionWithoutAction(const cocos2d::CCPoint& position);  

  void AddLineToPosition(const cocos2d::CCPoint& position);
  void RemoveLine();

  void AddAreaOnPosition(const cocos2d::CCPoint& position);
  void RemoveArea();
  void RemoveGaurdCircle();

  void UpdateMovedTouch(const cocos2d::CCPoint& position);

  enum TargetType {
    kTargetEnemy = 0,
    kTargetFriend
  };

  void AimTarget(const uint_32 character_id);
  void CancelTarget(const uint_32 character_id, bool is_hide_now = true);

  enum TouchState {
    kTouchDisabled = -1,
    kTouchInvalid = 0,
    kTouchBegan,
    kTouchMoved,
    kTouchEnded
  };

private:
  BattleController* battle_controller_;

  TouchState touch_state_;

  uint_32 selected_character_id_;
  bool selected_characted_focused_;
  bool selected_by_current_touch_;

  uint_32 current_target_id_;

  cocos2d::CCPoint current_touch_position_;
  cocos2d::CCPoint touch_began_position_;

  cocos2d::CCSprite* line_;
  cocos2d::CCNode* area_node_;

private:
  
  //����ֱ���Ƿ��ཻ���κ�active monster
  bool isIntersectWithMonster(const cocos2d::CCPoint& p1, const cocos2d::CCPoint& p2, uint_32& monster_id);

  //TODO,����ʽֱ�߷���
  bool isRayIntersectWithRect(const cocos2d::CCPoint& p1, const cocos2d::CCPoint& p2, const cocos2d::CCRect& rect);

  bool calcualteLinePositionFixedX(const cocos2d::CCPoint
& p1, const cocos2d::CCPoint& p2, cocos2d::CCPoint& outResult);

  bool calcualteLinePositionFixedY(const cocos2d::CCPoint
    & p1, const cocos2d::CCPoint& p2, cocos2d::CCPoint& outResult);

};

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_TOUCH_HANDLER_H_ */
