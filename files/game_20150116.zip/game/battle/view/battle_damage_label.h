//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-29
//          Time:  9:56
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-29        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_damage_label_h
#define ChainChronicle_battle_damage_label_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
  
namespace pvp {
  class PvpView;
}
  
namespace battle {

enum eDamageLabelType
{
	eDamageLabelType_Unknown = -1,
	// 0�����չ�
	eDamageLabelType_Physics,
	// 1�����չ�
	eDamageLabelType_Magic,
	// 2��������
	eDamageLabelType_PhysicsCritical,
	// 3��������
	eDamageLabelType_MagicCritical,
	// ��������
	eDamageLabelType_PhysicsSkill,
	// ��������
	eDamageLabelType_MagicSkill,
	// ���˺�
	eDamageLabelType_Ice,
	// ���˺�
	eDamageLabelType_Fire,
	// ���˺�
	eDamageLabelType_Wind,
	// ����
	eDamageLabelType_Heal,
	// �޵�
	eDamageLabelType_Invincible,
	// ����
	eDamageLabelType_ImmuneControl,
	eDamageLabelType_PhysicsImmune,
	eDamageLabelType_MagicImmune,
	// δ����
	eDamageLabelType_Dodge,
	// ��������
	eDamageLabelType_AddPhysicsDefense,
	eDamageLabelType_AddMagicDefense,
	eDamageLabelType_SubPhysicsDefense,
	eDamageLabelType_SubMagicDefense,
	// ����
	eDamageLabelType_SubSpeed,
	// ����
	eDamageLabelType_Stunned,
	// ����
	eDamageLabelType_Freeze,
	// �ж�
	eDamageLabelType_Poison,
	// ��Ĭ
	eDamageLabelType_Silence,
	// ��ä
	eDamageLabelType_Blinded,
	// ����
	eDamageLabelType_SeriousInjury,
	// ʯ��
	eDamageLabelType_Petrifaction,
	// ��������
	eDamageLabelType_Frostbite,
	// �绯����
	eDamageLabelType_Weathering,
	// ��ȼ����
	eDamageLabelType_Flammable,
	// նɱ
	eDamageLabelType_Slay,

	eDamageLabelType_Max,
};


class BattleView;
class DamageLabel;
class BattleController;

class DamageLabelPool
{
public:
	DamageLabelPool( int size);
	~DamageLabelPool();

	DamageLabel* create();

	void destroy(DamageLabel* obj);

	void clearup();

private:
	int mSize;
	std::queue<DamageLabel*> mPool;
	std::vector<DamageLabel*> mAllLabelPool;
};


class DamageLabel : public cocos2d::CCNodeRGBA
{
public:
	friend class DamageLabelPool;
protected:
	DamageLabel();
public:
  ~DamageLabel();
  
  virtual bool init();

  void setIsCharacter(bool b);

  void setDamageValue(int damage_value);

  void setDamageLabelType(battle::eDamageLabelType dlType);

  static DamageLabel * create(eDamageLabelType damage_label_type, int damage_value, bool is_character);

  static eDamageLabelType toDamageLabelType(uint_32 attack_type , eAttackDamageType damege_type);
  static eDamageLabelType toDamageLabelType( eDamageStatus battle_status);
public:
  void ShowDamageValueOnBattleLayer(battle::BattleView* parent, cocos2d::CCPoint position);

private:
	void reset();

	void updateDamageContent();

	void updateDamageFontResouce();

	void updateDamageLableCtrl();

	void updateTextureText();

	void updateColor();

	void playAction();

	void actionFinishedCallback();
	void recycleCallBack();


private:
	bool checkValid();
private:
	bool is_character_;

	eDamageLabelType damage_label_type_;

	int damage_value_;

	std::string damage_value_str_;

	std::string font_resource_;

	std::string sprite_resource_;

	cocos2d::ccColor3B damage_label_color_;
  
	cocos2d::CCLabelAtlas* damage_label_;

	cocos2d::CCSprite* tex_text_;

};
  
} // namespace battle
} // namespace taomee

#endif // ChainChronicle_battle_damage_label_h
