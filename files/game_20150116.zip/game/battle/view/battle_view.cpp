﻿
//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_view.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/view/battle_view.h"

#include "engine/base/cocos2d_wrapper.h"
#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/battle/view/battle_layer.h"
#include "game/battle/view/tiled_grid_layer.h"
#include "game/shader/shader_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/touch_helper/touch_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/shader/shader_manager.h"
#include "game/battle/battle_controller.h"
#include "game/game_manager/game_manager.h"
using namespace cocos2d;

namespace taomee {
namespace battle {

BattleView::BattleView()
: battle_scene_(NULL),
  container_layer_(NULL),
  battle_layer_(NULL),
  grid_layer_(NULL),
  ui_layer_(NULL),
  touch_helper_(NULL),
  callback_(NULL)
{
}

BattleView::~BattleView()
{
  touch_helper_->unregisterWithTouchDispatcher();
  CC_SAFE_RELEASE_NULL(touch_helper_);
  battle_scene_->removeAllChildrenWithCleanup(true);
  CC_SAFE_RELEASE_NULL(battle_scene_);
  CC_SAFE_RELEASE_NULL(container_layer_);
  CC_SAFE_RELEASE_NULL(battle_layer_);
  if (callback_)
  {
	  delete callback_;
	  callback_ = NULL;
  }
  
}

void BattleView::Init()
{
  battle_scene_ = CCScene::create();
  battle_scene_->retain();

}

void BattleView::SwitchToBattleScene()
{
  assert(battle_scene_ != NULL);

  if (CCDirector::sharedDirector()->getRunningScene() != NULL) {
    CCDirector::sharedDirector()->replaceScene(battle_scene_);
  } else {
    CCDirector::sharedDirector()->runWithScene(battle_scene_);
  }

  taomee::GameManager::GetInstance().SetCurrentTemplateScene(NULL);
}

void BattleView::SetBattleStageDefault()
{
	if(container_layer_)
	{
		container_layer_->setPosition(battle_scene_->getContentSize().width * 0.5f,
			battle_scene_->getContentSize().height * 0.5f);
	}
}

void BattleView::CreateBattleStage(uint_32 check_point_id)
{
  container_layer_ = CCLayer::create();
  container_layer_->retain();
  container_layer_->setPosition(battle_scene_->getContentSize().width * 0.5f,
                                battle_scene_->getContentSize().height * 0.5f);

  this->CreateMapLayer(check_point_id);
  this->CreateBattleLayer();
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
      this->CreateTopBattleLayer(check_point_id);
    }
    break;
  case battle::kBattleType_Pvp:
  case battle::kBattleType_SandBox:
    {

    }
    break;
  default:
    break;
  }
  this->createTiledGridLayer();
  touch_helper_ = TouchHelper::CreateWithRootNode(battle_scene_);
  touch_helper_->retain();
  touch_helper_->registerWithTouchDispatcher(0,true);
}

void BattleView::LoadBattleStage()
{
  battle_scene_->addChild(container_layer_, kContainerLayer, kContainerLayer);
  
  ui_layer_ = CCLayer::create();
  ui_layer_->setContentSize(CCSizeMake(1136,640));
  ui_layer_->ignoreAnchorPointForPosition(false);
  ui_layer_->setAnchorPoint(ccp(0.5f, 0.5f));
  ui_layer_->setPosition(battle_scene_->getContentSize().width * 0.5f,\
    battle_scene_->getContentSize().height * 0.5f);
  battle_scene_->addChild(ui_layer_);

  
  CCLayer* bg_layer = CCLayer::create();
  bg_layer->setContentSize(CCSizeMake(1136,768));
  bg_layer->ignoreAnchorPointForPosition(false);
  bg_layer->setAnchorPoint(ccp(0.5f, 0.5f));
  bg_layer->setPosition(battle_scene_->getContentSize().width * 0.5f,\
    battle_scene_->getContentSize().height * 0.5f);

  battle_scene_->addChild(bg_layer,kTopBoardUI);

  CCLayer* ui_top_board_layer = LuaTinkerManager::GetInstance()\
    .CallLuaFunc<CCLayer*>("script/ui/ui_top_borad_layer.lua", "CreateUITopBoradLayer");
  ui_top_board_layer->ignoreAnchorPointForPosition(false);
  ui_top_board_layer->setAnchorPoint(ccp(0.5f, 0.5f));
  ui_top_board_layer->setPosition(1136 * 0.5f,\
    768 * 0.5f);
  bg_layer->addChild(ui_top_board_layer,kTopBoardUI);

}


void BattleView::SetTouchHandler(TouchHandler* touch_handler)
{
  battle_layer_->set_touch_handler(touch_handler);
}


void BattleView::AddMoveObject(army::MoveObject* move_object) {
  this->AddElementToScene(move_object->anima_node(), kCharacterLayer);
}

void BattleView::AddElementToScene(cocos2d::CCNode* element, BattleLayerType layer_type)
{
  assert(element != NULL);
  assert(battle_layer_ != NULL);

  battle_layer_->AddElement(element, layer_type);
}

void BattleView::RemoveElementFromScene(int_32 tag, BattleLayerType layer_type)
{
  assert(battle_layer_ != NULL);

  battle_layer_->RemoveElementWithTag(tag, layer_type);
}
 
cocos2d::CCLayer* BattleView::Battle_Container_Layer()
{
  return container_layer_;
}

cocos2d::CCLayer* BattleView::Battle_Layer()
{
  return battle_layer_;
}

cocos2d::CCLayer* BattleView::GetLayer(BattleLayerType layer_type)
{
  return battle_layer_->GetLayer(layer_type);
}
  
void BattleView::reversivelyPauseAllChildren(cocos2d::CCNode* node)
{
  node->pauseSchedulerAndActions();
  
  cocos2d::CCObject* obj = NULL;
  CCARRAY_FOREACH(node->getChildren(), obj)
  {
    cocos2d::CCNode* child = dynamic_cast<cocos2d::CCNode*>(obj);
    this->reversivelyPauseAllChildren(child);
  }
}

void BattleView::reversivelyResumeAllChildren(cocos2d::CCNode* node)
{
  node->resumeSchedulerAndActions();
  
  cocos2d::CCObject* obj = NULL;
  CCARRAY_FOREACH(node->getChildren(), obj)
  {
    cocos2d::CCNode* child = dynamic_cast<cocos2d::CCNode*>(obj);
    this->reversivelyResumeAllChildren(child);
  }
}

void BattleView::CreateMapLayer(uint_32 check_point_id)
{
  //CCSize window_size = CCDirector::sharedDirector()->getWinSize();
  
//  int mapId = DataManager::GetInstance().GetCheckPointTable()
//                                ->GetCheckpoint(check_point_id)->GetBattlebg();
  
  string mapName;
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
    { 
      int mapId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
        "QueryCheckPointBattleBgID",
        check_point_id);
      char c_mapId[8] = {'\0'};
      sprintf(c_mapId, "%d", mapId);
      mapName = "textures/map/battlemap_" + string(c_mapId) + ".png";
    }
    break;
  case battle::kBattleType_Pvp:
    {
      mapName = "textures/map/battlemap_13.png";
    }
    break;
  case battle::kBattleType_SandBox:
    {
      mapName = "textures/map/battlemap_12.png";
    }
    break;
  default:
    break;
  }  
  
  CCSprite* map_sprite = CCSprite::create(mapName.c_str());

  CCLayer* map_layer = CCLayer::create();
  map_layer->ignoreAnchorPointForPosition(false);
  map_layer->setAnchorPoint(ccp(0.5f, 0.5f));
  map_layer->setContentSize(GetMapLayerDesignSize());
  map_layer->setPosition(CCPointZero);
  container_layer_->addChild(map_layer, kMapLayer, kMapLayer);

  map_sprite->setAnchorPoint(ccp(0.5f, 0.5f));
  map_sprite->setPosition(ccp(map_layer->getContentSize().width * 0.5,
                              map_layer->getContentSize().height * 0.5));


  map_layer->addChild(map_sprite);
  mBgSprite = map_sprite;
  //  CMapLayer *map_layer = new CMapLayer();
  //  map_layer->autorelease();
  //  map_layer->LoadATLMap();
  //  //map_layer->setScale(2.0);
  //  map_layer->setAnchorPoint(ccp(0.0, 0.0));
  //  map_layer->setPosition(ccp(60, 0));
  //
  //  CCLayer* deco_layer = CCLayer::create();
  //
  //  CCSprite* sprite_tree1 = CCSprite::create();
  //  sprite_tree1->initWithFile("textures/test_obj.png");
  //  sprite_tree1->setAnchorPoint(ccp(0, 1));
  //  sprite_tree1->setPosition(ccp(0, 770));
  //  deco_layer->addChild(sprite_tree1);
  //
  //  CCSprite* sprite_tree2 = CCSprite::create();
  //  sprite_tree2->initWithFile("textures/test_obj.png");
  //  sprite_tree2->setAnchorPoint(ccp(0, 1));
  //  sprite_tree2->setPosition(ccp(400, 830));
  //  deco_layer->addChild(sprite_tree2);
  //
  //  CCSprite* sprite_tree3 = CCSprite::create();
  //  sprite_tree3->initWithFile("textures/test_obj.png");
  //  sprite_tree3->setAnchorPoint(ccp(0, 1));
  //  sprite_tree3->setPosition(ccp(750, 770));
  //  deco_layer->addChild(sprite_tree3);
  //
  //  this->AddElementToScene(map_layer, kMapLayer);
  //  this->AddElementToScene(deco_layer, kMapLayer);
/*
  CCClippingNode* pClip=CCClippingNode::create();
  pClip->setContentSize(CCSize(200, 200));
  pClip->setInverted(false);
  map_layer->addChild(pClip);
  
  CCSprite* sprite = CCSprite::create("textures/effect/select_frog.png");
  sprite->setScale(4.0);
  sprite->setPosition(ccp(100, 100));
  pClip->addChild(sprite);

  static ccColor4F green = {0, 1, 0, 1};
  float fRadius = 100.0f;
  const int nCount = 100;
  const float coef = 2.0f * (float)M_PI / nCount;
  static CCPoint circle[nCount];
  for(unsigned int i = 0; i < nCount; i++) {
    float rads = i*coef;
    circle[i].x = fRadius * cosf(rads) + 100;
    circle[i].y = fRadius * sinf(rads) + 100;
  }
  CCDrawNode *pStencil=CCDrawNode::create();
  pStencil->drawPolygon(circle, nCount, green, 0, green);

  pClip->setStencil(pStencil);

  shader::SetAllNodeWithShader(sprite, shader::kShaderTargetArea);
  */
}

void BattleView::CreateBattleLayer()
{
  battle_layer_ = BattleLayer::create();
  battle_layer_->retain();
  battle_layer_->setPosition(CCPointZero);
#if CC_TARGET_PLATFORM == CC_PLATFORM_IOS
  cocos2d::CCSize size = cocos2d::CCDirector::sharedDirector()->getVisibleSize();
  if (size.width == 1136)
  {
    battle_layer_->setScale(1.05f);
  }
#endif
  container_layer_->addChild(battle_layer_, kBattleLayer, kBattleLayer);
}

void BattleView::CreateTopBattleLayer(uint_32 check_point_id)
{
  int mapId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
    "QueryCheckPointBattleBgID",
    check_point_id);

  char c_mapId[8] = {'\0'};
  sprintf(c_mapId, "%d", mapId);

  //get map foreground
  int foreground_shader = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/map_foreground_config.lua"
    ,"GetMapForeGroundShader"
    , mapId);

  std::string battle_fore_image_name_ = "textures/map_foreground/battlemap_" + string(c_mapId) + "_foreground.pvr.ccz";
  unsigned long len = 0;
  unsigned char *data =CCFileUtils::sharedFileUtils()->getFileData(battle_fore_image_name_.c_str(), "rb", &len); 
  if(len >0 && data)
  {
    delete[] data;
  }
  else
  {
    battle_fore_image_name_ = "";
  }

  if (!battle_fore_image_name_.empty())
  {
    CCLayer* top_battle_layer = CCLayer::create();
    top_battle_layer->setContentSize(CCSizeMake(1136,640));
    top_battle_layer->setPosition(CCPointZero);
    top_battle_layer->setAnchorPoint(ccp(0.5f, 0.5f));
    top_battle_layer->ignoreAnchorPointForPosition(false);

    container_layer_->addChild(top_battle_layer, kTopBattleLayer, kTopBattleLayer);

    CCSprite* map_fore_sprite_left = CCSprite::create(battle_fore_image_name_.c_str());
    map_fore_sprite_left->setPosition(ccp(-50, 0));
    map_fore_sprite_left->setAnchorPoint(ccp(0,0));
    if(foreground_shader != 0)
      map_fore_sprite_left->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderGrass));

    CCSprite* map_fore_sprite_right = CCSprite::create(battle_fore_image_name_.c_str());
    map_fore_sprite_right->setFlipX(true);
    map_fore_sprite_right->setPosition(ccp(top_battle_layer->getContentSize().width + 50,0));
    map_fore_sprite_right->setAnchorPoint(ccp(1,0));
    if(foreground_shader != 0)
      map_fore_sprite_right->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderGrassReverse));

    top_battle_layer->addChild(map_fore_sprite_left);
    top_battle_layer->addChild(map_fore_sprite_right);
  }
}
  
void BattleView::createTiledGridLayer()
{
  grid_layer_ = TiledGridLayer::create();
  this->AddElementToScene(grid_layer_, kBottomLayer);
}

cocos2d::CCNode* BattleView::GetLayerBindNode(BattleLayerType layer_type, uint_32 move_obj_id)
{
  return battle_layer_->GetLayerBindNode(layer_type, move_obj_id);
}

void BattleView::UpdateBindNode(BattleLayerType layer_type, uint_32 move_obj_id, cocos2d::CCPoint pos)
{
  battle_layer_->UpdateBindNode(layer_type, move_obj_id, pos);
}

void BattleView::ClearBindNode(uint_32 move_obj_id)
{
  battle_layer_->ClearBindNode(move_obj_id);
}

void BattleView::PauseBattleLayer()
{
  this->reversivelyPauseAllChildren(battle_layer_);
}

void BattleView::ResumeBattleLayer()
{
  this->reversivelyResumeAllChildren(battle_layer_);
}

void BattleView::CreateArrows(ai::eAIBornLine line_type)
{
  if (grid_layer_) 
  {
    grid_layer_->CreateArrow(line_type);
  }
}
  
void BattleView::ResetBattleViewForBattleWin()
{
  // remove tiled grid layer
  battle_layer_->removeChildByTag(kBottomLayer, true);
}
  
void BattleView::ZoomContainerLayerWithNewFocusPoint(cocos2d::CCPoint anPoint)
{
  container_layer_->stopAllActions();
  container_layer_->ignoreAnchorPointForPosition(false);
  container_layer_->setAnchorPoint(ccp(anPoint.x / battle_scene_->getContentSize().width-0.5f,
	                                   anPoint.y / battle_scene_->getContentSize().height-0.5f));
  container_layer_->setPosition(anPoint);
  cocos2d::CCScaleTo* zoom = cocos2d::CCScaleTo::create(0.3f, 1.6f);
  cocos2d::CCScaleTo* zoomBack = cocos2d::CCScaleTo::create(0.3f, 1.0f);
  cocos2d::CCDelayTime* delay = cocos2d::CCDelayTime::create(0.8f);
  if (callback_)
  {
    delete callback_;
	  callback_ = NULL;
  }
  callback_ = new base::CCCallback<BattleView>(this,&BattleView::resetContainerLayerBack);
  CCCallFunc* callFunc = CCCallFunc::create(callback_, callfunc_selector(
                                base::CCCallback<BattleView>::selector_callback));
  container_layer_->runAction(cocos2d::CCSequence::create(zoom, delay, zoomBack, callFunc, NULL));
}

void BattleView::ZoomOutContainerLayerWithNewFocusPoint(cocos2d::CCPoint anPoint)
{
  container_layer_->stopAllActions();
  container_layer_->ignoreAnchorPointForPosition(false);
  container_layer_->setAnchorPoint(ccp(anPoint.x / battle_scene_->getContentSize().width-0.5f,
                                       anPoint.y / battle_scene_->getContentSize().height-0.5f));
  container_layer_->setPosition(anPoint);
  cocos2d::CCScaleTo* zoom = cocos2d::CCScaleTo::create(0.4f, 1.6f);
  container_layer_->runAction(zoom);
}

void BattleView::ZoomInContainerLayer()
{
  cocos2d::CCScaleTo* zoomBack = cocos2d::CCScaleTo::create(0.4f, 1.0f);
  container_layer_->runAction(zoomBack);
  resetContainerLayerBack();
}
  
void BattleView::resetContainerLayerBack()
{
  container_layer_->setAnchorPoint(ccp(0.5f,0.5f));
  container_layer_->setPosition(battle_scene_->getContentSize().width * 0.5f,
                                battle_scene_->getContentSize().height * 0.5f);
  container_layer_->ignoreAnchorPointForPosition(true);
}

void BattleView::SetTouchFliterEnable( bool flag )
{
  if (touch_helper_)
  {
    touch_helper_->SetTouchFliterEnable(flag);
  }
}


} /* namespace battle */
} /* namespace taomee */
