//
//  tiled_grid_layer.cpp
//  ChainChronicle
//
//  Created by gaven on 9/18/13.
//
//

#include "game/battle/view/tiled_grid_layer.h"

#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/coordinate_helper.h"

namespace taomee {  
namespace battle {

using namespace cocos2d;

bool TiledGridLayer::init()
{
  CCLayer::init();
  
  setContentSize(iCC_DESIGN_SIZE);
  
  this->setAnchorPoint(ccp(0, 0));
  this->setPosition(ccp(0, 0));
  this->setTouchEnabled(false);
  
//  CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("textures/map/grid_element.plist");
  gridBatch_ = CCSpriteBatchNode::create("textures/battle/battle_ex.pvr.ccz", 128);
  gridBatch_->setAnchorPoint(ccp(0, 0));
  gridBatch_->setPosition(ccp(0, 0));
  this->addChild(gridBatch_);
  /*
  int_8 mid_column = kMapColumnCount*0.5;
  // first & last row
  for (int j = 0; j <= kMapColumnCount; ++j)
  {
    CCPoint selfPosFirst = GetPointPositionByGridPointCoordinate(0, j);
    CCPoint selfPosLast = GetPointPositionByGridPointCoordinate(kMapRowCount, j);
    // left
    if (j != 0 && j != mid_column)
    {
      CCSprite* cSprite1 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite1->setScale(0.2f);
      cSprite1->getTexture()->setAntiAliasTexParameters();
      cSprite1->setAnchorPoint(ccp(0, 0.5f));
      cSprite1->setPosition(selfPosFirst);
      cSprite1->setRotation(180.0f);
      gridBatch_->addChild(cSprite1);
      CCSprite* cSprite2 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite2->setScale(0.2f);
      cSprite2->getTexture()->setAntiAliasTexParameters();
      cSprite2->setAnchorPoint(ccp(0, 0.5f));
      cSprite2->setPosition(selfPosLast);
      cSprite2->setRotation(180.0f);
      gridBatch_->addChild(cSprite2);
    }
    // right
    if (j != kMapColumnCount)
    {
      CCSprite* cSprite1 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite1->setScale(0.2f);
      cSprite1->getTexture()->setAntiAliasTexParameters();
      cSprite1->setAnchorPoint(ccp(0, 0.5f));
      cSprite1->setPosition(selfPosFirst);
      gridBatch_->addChild(cSprite1);
      CCSprite* cSprite2 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite2->setScale(0.2f);
      cSprite2->getTexture()->setAntiAliasTexParameters();
      cSprite2->setAnchorPoint(ccp(0, 0.5f));
      cSprite2->setPosition(selfPosLast);
      gridBatch_->addChild(cSprite2);
    }
    // bottom for first row only
    CCSprite* cSprite3 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSprite3->setScale(0.2f);
    cSprite3->getTexture()->setAntiAliasTexParameters();
    CCPoint bottom = GetPointPositionByGridPointCoordinate(1, j);
    cSprite3->setAnchorPoint(ccp(0, 0.5f));
    cSprite3->setPosition(selfPosFirst);
    float angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPosFirst, bottom));
    if (angle>180.0f)
    {
      angle = angle-360.0f;
    }
    cSprite3->setRotation(-angle);
    gridBatch_->addChild(cSprite3);
    // top for last row only
    CCSprite* cSprite4 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSprite4->setScale(0.2f);
    cSprite4->getTexture()->setAntiAliasTexParameters();
    CCPoint top = GetPointPositionByGridPointCoordinate(kMapRowCount-1, j);
    cSprite4->setAnchorPoint(ccp(0, 0.5f));
    cSprite4->setPosition(selfPosLast);
    angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPosLast, top));
    cSprite4->setRotation(-angle);
    gridBatch_->addChild(cSprite4);
  }
  
  // center points
  for (int i = 1; i < kMapRowCount; ++i)
  {
    for (int j = 1; j < kMapColumnCount; ++j)
    {
      CCPoint selfPos = GetPointPositionByGridPointCoordinate(i, j);
    
      // right
      CCSprite* cSprite1 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite1->setScale(0.2f);
      cSprite1->getTexture()->setAntiAliasTexParameters();
      cSprite1->setAnchorPoint(ccp(0, 0.5f));
      cSprite1->setPosition(selfPos);
      gridBatch_->addChild(cSprite1);
      // left
      if (j!=mid_column)
      {
        CCSprite* cSprite2 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//        cSprite2->setScale(0.2f);
        cSprite2->getTexture()->setAntiAliasTexParameters();
        cSprite2->setAnchorPoint(ccp(0, 0.5f));
        cSprite2->setPosition(selfPos);
        cSprite2->setRotation(180.0f);
        gridBatch_->addChild(cSprite2);
      }
      
      // top
      CCSprite* cSprite3 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite3->setScale(0.2f);
      cSprite3->getTexture()->setAntiAliasTexParameters();
      CCPoint top = GetPointPositionByGridPointCoordinate(i-1, j);
      cSprite3->setAnchorPoint(ccp(0, 0.5f));
      cSprite3->setPosition(selfPos);
      float angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPos, top));
      cSprite3->setRotation(-angle);
      gridBatch_->addChild(cSprite3);

      // bottom
      CCSprite* cSprite4 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//      cSprite4->setScale(0.2f);
      cSprite4->getTexture()->setAntiAliasTexParameters();
      CCPoint bottom = GetPointPositionByGridPointCoordinate(i+1, j);
      cSprite4->setAnchorPoint(ccp(0, 0.5f));
      cSprite4->setPosition(selfPos);
      angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPos, bottom));
      if (angle>180.0f)
      {
        angle = angle-360.0f;
      }
      cSprite4->setRotation(-angle);
      gridBatch_->addChild(cSprite4);
    }
  }
  
  // first & last column
  for (int_8 i = 1; i<kMapRowCount; ++i)
  {
    CCPoint selfPosFirst = GetPointPositionByGridPointCoordinate(i, 0);
    CCPoint selfPosLast = GetPointPositionByGridPointCoordinate(i, kMapColumnCount);
    // right only for first column
    CCSprite* cSpriteR = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSpriteR->setScale(0.2f);
    cSpriteR->getTexture()->setAntiAliasTexParameters();
    cSpriteR->setAnchorPoint(ccp(0, 0.5f));
    cSpriteR->setPosition(selfPosFirst);
    gridBatch_->addChild(cSpriteR);
    // left only for last column
    CCSprite* cSpriteL = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSpriteL->setScale(0.2f);
    cSpriteL->getTexture()->setAntiAliasTexParameters();
    cSpriteL->setAnchorPoint(ccp(0, 0.5f));
    cSpriteL->setPosition(selfPosLast);
    cSpriteL->setRotation(180.0f);
    gridBatch_->addChild(cSpriteL);
    // top
    CCSprite* cSprite1 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSprite1->setScale(0.2f);
    cSprite1->getTexture()->setAntiAliasTexParameters();
    CCPoint topL = GetPointPositionByGridPointCoordinate(i-1, 0);
    cSprite1->setAnchorPoint(ccp(0, 0.5f));
    cSprite1->setPosition(selfPosFirst);
    float angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPosFirst, topL));
    cSprite1->setRotation(-angle);
    gridBatch_->addChild(cSprite1);
    CCSprite* cSprite2 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSprite2->setScale(0.2f);
    cSprite2->getTexture()->setAntiAliasTexParameters();
    CCPoint topR = GetPointPositionByGridPointCoordinate(i-1, kMapColumnCount);
    cSprite2->setAnchorPoint(ccp(0, 0.5f));
    cSprite2->setPosition(selfPosLast);
    angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPosLast, topR));
    cSprite2->setRotation(-angle);
    gridBatch_->addChild(cSprite2);    
    // bottom
    CCSprite* cSprite3 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSprite3->setScale(0.2f);
    cSprite3->getTexture()->setAntiAliasTexParameters();
    CCPoint bottomL = GetPointPositionByGridPointCoordinate(i+1, 0);
    cSprite3->setAnchorPoint(ccp(0, 0.5f));
    cSprite3->setPosition(selfPosFirst);
    angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPosFirst, bottomL));
    if (angle>180.0f)
    {
      angle = angle-360.0f;
    }
    cSprite3->setRotation(-angle);
    gridBatch_->addChild(cSprite3);
    CCSprite* cSprite4 = CCSprite::createWithSpriteFrameName("grid_corner.png");
//    cSprite4->setScale(0.2f);
    cSprite4->getTexture()->setAntiAliasTexParameters();
    CCPoint bottomR = GetPointPositionByGridPointCoordinate(i+1, kMapColumnCount);
    cSprite4->setAnchorPoint(ccp(0, 0.5f));
    cSprite4->setPosition(selfPosLast);
    angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPosLast, bottomR));
    if (angle>180.0f)
    {
      angle = angle-360.0f;
    }
    cSprite4->setRotation(-angle);
    gridBatch_->addChild(cSprite4);
  }
  
  for (int_8 i = 0; i<=kMapRowCount; ++i)
  {
    for (int_8 j = 0.5f*kMapColumnCount; j<=kMapColumnCount; ++j)
    {
      CCPoint selfPos = GetPointPositionByGridPointCoordinate(i, j);

      if (j != kMapColumnCount)
      {
        CCPoint right = GetPointPositionByGridPointCoordinate(i, j+1);
        CCSprite* lSpriteRight = CCSprite::createWithSpriteFrameName("grid_line.png");
//        lSpriteRight->setScale(0.2f);
        lSpriteRight->getTexture()->setAntiAliasTexParameters();
        float length = lSpriteRight->getContentSize().width;
        float disRight = ccpDistance(selfPos, right);
        lSpriteRight->setAnchorPoint(ccp(0, 0.5f));
        lSpriteRight->setPosition(selfPos);
        lSpriteRight->setScaleX(disRight/length);
        gridBatch_->addChild(lSpriteRight); 
      }
      
      if (i != kMapRowCount)
      {
        CCPoint bottom = GetPointPositionByGridPointCoordinate(i+1, j);
        CCSprite* lSpriteBottom = CCSprite::createWithSpriteFrameName("grid_line.png");
//        lSpriteBottom->setScale(0.2f);
        lSpriteBottom->getTexture()->setAntiAliasTexParameters();
        float length = lSpriteBottom->getContentSize().width;
        float disBottom = ccpDistance(selfPos, bottom);
        lSpriteBottom->setAnchorPoint(ccp(0, 0.5f));
        lSpriteBottom->setPosition(selfPos);
        lSpriteBottom->setScaleX(disBottom/length);
        float angle = CC_RADIANS_TO_DEGREES(RadiansBetweenPoint(selfPos, bottom));
        if (angle>180.0f)
        {
          angle = angle-360.0f;
        }
        lSpriteBottom->setRotation(-angle);
        gridBatch_->addChild(lSpriteBottom);
      }
    }
  }
  */
  CCSprite* colorField = CCSprite::createWithSpriteFrameName("failed_area.png");
  colorField->setAnchorPoint(ccp(0.0f, 1.0f));
  CCPoint pos = GetPointPositionByGridPointCoordinate(0, kMapColumnCount);
  colorField->setPosition(ccp(pos.x-30, pos.y+45));
  gridBatch_->addChild(colorField);
  return true;
}
  
void TiledGridLayer::draw()
{
  CCLayer::draw();
/*
  ccDrawColor4F(0.5f, 0.5f, 0.5f, 0.5f);
  glLineWidth(3.0f);
 
  for (int i = 0; i != kMapRowCount; ++i)
  {
    for (int j = 0; j != kMapColumnCount; ++j)
    {
      int_8 tile_index = GetTileIndexByTileCoordinatePos(ccp(j, i));
      CCPoint bottom_right = GetBottomRightPointPositionInTile(tile_index);
      CCPoint top_right = GetTopRightPointPositionInTile(tile_index);
      CCPoint bottom_left = GetBottomLeftPointPositionInTile(tile_index);
      CCPoint top_left = GetTopLeftPointPositionInTile(tile_index);
      
      ccDrawLine(bottom_right, bottom_left);
      ccDrawLine(bottom_left, top_left);
      ccDrawLine(top_left, top_right);
      ccDrawLine(top_right, bottom_right);
    }
  }
*/
}

void TiledGridLayer::CreateArrow( ai::eAIBornLine line_type )
{
  if ( gridBatch_->getChildByTag(line_type*3)) 
  {
    return;
  }
  
  for (int i = 0; i < 3; ++i) 
  {
    CCSprite* arrow = CCSprite::createWithSpriteFrameName("arrows.png");
    arrow->setAnchorPoint(ccp(0, 1.0f));
    CCPoint pos = GetPointPositionByGridPointCoordinate(line_type, 0);
    arrow->setPosition(ccp(20 + i*50 + (3-(line_type+1))*10 , pos.y - 35));
    arrow->setScale(1.0f - (3-(line_type+1))*0.1f);
    arrow->setVisible(false);
    arrow->setTag(line_type * 3 + i);
    CCDelayTime* delay = CCDelayTime::create(i*0.2f);
    CCBlink* blink = CCBlink::create(4,3);  
    CCCallFuncN* callback = CCCallFuncN::create(this,callfuncN_selector(TiledGridLayer::onBlinkFinished));
    CCSequence* seq =  CCSequence::create(delay, blink, callback, NULL);
    arrow->runAction(seq);  
    gridBatch_->addChild(arrow);
  }  
}

void TiledGridLayer::onBlinkFinished( CCNode* node )
{
  assert(node != NULL);
  node->removeFromParentAndCleanup(true);
}



} // namespace battle
} // namespace taomee