﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_view_constant.h
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_VIEW_CONSTANT_H_
#define BATTLE_VIEW_CONSTANT_H_

#include "cocoa/CCGeometry.h"

namespace taomee {
namespace battle {

/**
 * battle view hierarchy
 *
 * battle_scene
 * ｜---- top_board
 * ├── ui_layer
 * └── container_layer
 * ｜  ├── top_battle_layer
 * ｜  ├── battle_layer
 * ｜  │   ├── top_layer
 * ｜  │   ├── character_layer
 * ｜  │   └── bottom_layer
 * ｜  └── map_layer
 */
enum SceneLayerType {
  kContainerLayer       = 0,
  kBattleMenuUI         = 100,
  kTopBoardUI           = 200,
};

enum ContainerLayerType {
  kMapLayer             = kContainerLayer,
  kBattleLayer          = 1,
  kTopBattleLayer       = 2,
};

enum BattleLayerType {
  kLayerBegin           = 0,
  kBottomLayer          = 1,
  kCharacterLayer       = 2,
  kTopLayer             = 3,
  kLayerEnd,
};
  
enum eBattleUIType {
  kBattleUITypeUnkown           = 0,
  kBattleUITypeMenu             = kBattleMenuUI,
  kBattleUITypeSkillRandLayer   = 101,
  kBattleUITypeSpellCasteLayer  = 102,
  kBattleUITypeMax,
};

cocos2d::CCSize GetMapLayerDesignSize();
cocos2d::CCSize GetBattleLayerDesignSize();

float GetMapLayerScale();
float GetBattleLayerScale();

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_VIEW_CONSTANT_H_ */
