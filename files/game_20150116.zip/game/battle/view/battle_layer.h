
//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_layer.h
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_LAYER_H_
#define BATTLE_LAYER_H_

#include "engine/base/cocos2d_wrapper.h"

#include "game/battle/view/battle_view_constant.h"

namespace taomee {
namespace battle {

class TouchHandler;

class BattleLayer : public cocos2d::CCLayer {
public:
  BattleLayer();
  virtual ~BattleLayer();

  CREATE_FUNC(BattleLayer);
  virtual bool init();

public:
  // touch
  virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
  virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
  virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
  virtual void ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);

  void set_touch_handler(TouchHandler* touch_handler) { touch_handler_ = touch_handler; }

public:
  void AddElement(cocos2d::CCNode* element, BattleLayerType layer_type);
  void RemoveElementWithTag(int_32 tag, BattleLayerType layer_type);
  cocos2d::CCLayer* GetLayer(BattleLayerType layer_type);

  // this node pos will be refreshed
  CCNode* GetLayerBindNode(BattleLayerType layer_type, uint_32 move_obj_id);
  void    UpdateBindNode(BattleLayerType layer_type, uint_32 move_obj_id, cocos2d::CCPoint pos);
  void    ClearBindNode(uint_32 move_obj_id);
private:
  TouchHandler* touch_handler_;

};

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_LAYER_H_ */
