//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: aim_mark.cpp
//        Author: leohou
//       Version:
//          Date: Oct 13, 2013
//          Time: 11:04:00 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     11:04:00 PM
//
//////////////////////////////////////////////////////////////

#include "game/battle/view/aim_mark.h"
#include "engine/sound/sound_manager.h"
#include "engine/script/lua_tinker_manager.h"

#include <cassert>
#include <cstddef>

namespace {
const std::string kAimTargetTexture = "aim.png";

const cocos2d::ccColor3B kAimTargetColor[] = {
  cocos2d::ccWHITE,
  cocos2d::ccRED,
};

const int kAimMarkSpriteTag = 123;

}

using namespace cocos2d;

namespace taomee {
namespace battle {

AimMark* AimMark::Create(AimMarkType aim_mark_type)
{
  AimMark* aim_mark = new AimMark();
  aim_mark->Init(aim_mark_type);
  aim_mark->autorelease();

  return aim_mark;
}

AimMark::AimMark()
: state_(kStateUnselected)
{

}

AimMark::~AimMark()
{

}

void AimMark::Init(AimMarkType aim_mark_type)
{
  assert(aim_mark_type >= 0 && aim_mark_type < sizeof (kAimTargetColor) / sizeof (kAimTargetColor[0]));

  CCSprite* aim_target_sprite = CCSprite::createWithSpriteFrameName(kAimTargetTexture.c_str());
  aim_target_sprite->setColor(kAimTargetColor[aim_mark_type]);

  this->addChild(aim_target_sprite, kAimMarkSpriteTag, kAimMarkSpriteTag);

  this->setVisible(false);
}

void AimMark::OnSelected(AimMarkType aim_mark_type /* = kAimMarkEnemy */)
{
  if (state_ == kStateSelected)
  {
    return;
  }
  
  (dynamic_cast<CCSprite*>(this->getChildByTag(kAimMarkSpriteTag)))->setColor(kAimTargetColor[aim_mark_type]);
  
  state_ = kStateSelected;

  CCSprite* aim_target_node = (CCSprite*)this->getChildByTag(kAimMarkSpriteTag);
  assert(aim_target_node != NULL);
  aim_target_node->stopAllActions();
  this->setVisible(true);
  aim_target_node->setScale(4.0f);
  aim_target_node->setOpacity(0);

  CCScaleTo* init_scale_down = CCScaleTo::create(0.4f, 1.0f);
  CCCallFuncN* init_scale_callback = CCCallFuncN::create(this, callfuncN_selector(AimMark::onInitScaleCompleted));
  aim_target_node->runAction(CCSequence::create(init_scale_down, init_scale_callback, NULL));

  CCFadeIn* fade_in = CCFadeIn::create(0.3f);
  aim_target_node->runAction(CCSequence::create(fade_in, NULL));
  SoundManager::GetInstance().PlayEffect(GetLuaSoundEffect("kSIDCharacterSelected"));
}

void AimMark::OnUnselected(bool is_hide_now/* = true*/)
{
  state_ = kStateUnselected; 
  CCNode* aim_target_node = this->getChildByTag(kAimMarkSpriteTag);
  assert(aim_target_node != NULL);

  if (is_hide_now) 
  {
    aim_target_node->stopAllActions();
    aim_target_node->setScale(1.0f);

    this->setVisible(false);
  }
  else
  { 
    CCCallFunc* callback = CCCallFunc::create(this,callfunc_selector(AimMark::onDelayFinished));
    aim_target_node->runAction(CCSequence::create(CCDelayTime::create(1.0f),callback, NULL));
  }

}

bool AimMark::IsSelected()
{
  return state_ == kStateSelected;
}

void AimMark::onInitScaleCompleted(cocos2d::CCNode* node)
{
  assert(node != NULL);

  CCScaleTo* scale_up = CCScaleTo::create(0.2f, 1.06f);
  CCScaleTo* scale_down = CCScaleTo::create(0.2f, 0.94f);
  CCSequence* scale = CCSequence::create(scale_up, scale_down, NULL);
  CCRepeatForever* repeat_action = CCRepeatForever::create(scale);
  node->runAction(repeat_action);
}

void AimMark::onDelayFinished()
{
  OnUnselected();
}

} /* namespace battle */
} /* namespace taomee */
