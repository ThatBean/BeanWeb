//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: player_box.h
//        Author: leohou
//       Version:
//          Date: Oct 11, 2013
//          Time: 5:15:30 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     5:15:30 AM
//
//////////////////////////////////////////////////////////////

#ifndef PLAYER_BOX_H_
#define PLAYER_BOX_H_

#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace battle {

enum PlayerBoxColor {
  kBoxColorRed = 0,
  kBoxColorYellow,
  kBoxColorPurple,
  kBoxColorGreen,
  kBoxColorBlue,
};

class PlayerBox : public cocos2d::CCNode {
public:
  virtual ~PlayerBox();

  // create a autorelease object
  static PlayerBox* Create(PlayerBoxColor box_color);

  void OnSelected();
  void OnUnselected();
  bool IsSelected();

private:
  PlayerBox();

  void Init(PlayerBoxColor box_color);

  enum State {
    kStateUnselected = 0,
    kStateSelected = 1,
  };

  void OnInitScaleCompleted(cocos2d::CCNode* node);

private:
  State state_;
};

} /* namespace battle */
} /* namespace taomee */
#endif /* PLAYER_BOX_H_ */
