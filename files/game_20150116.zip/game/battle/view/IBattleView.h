//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: IBattleView.h
//        Author: coldouyang
//          Date: 2014/12/30 17:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/12/30      add
//////////////////////////////////////////////////////////////

#ifndef IBATTLEVIEW_H
#define IBATTLEVIEW_H
#include "cocos2d.h"
#include "game/battle/view/battle_view_constant.h"

/************************************************************************/
/* �ӿ��ֻ࣬��Ϊ�˷��뵱ǰ����ϵͳ��ս����������*/
//�������ȫ������ǰBattleView ~~
/************************************************************************/
class IBattleView
{
public:
    virtual void AddElementToScene(cocos2d::CCNode* element, taomee::battle::BattleLayerType layer_type) = 0;
    virtual cocos2d::CCLayer* Battle_Container_Layer() = 0;
    virtual void SetBattleStageDefault() = 0;
protected:
private:
};

#endif