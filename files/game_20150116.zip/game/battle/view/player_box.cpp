//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: player_box.cpp
//        Author: leohou
//       Version:
//          Date: Oct 11, 2013
//          Time: 5:15:30 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     5:15:30 AM
//
//////////////////////////////////////////////////////////////

#include "game/battle/view/player_box.h"
#include "engine/sound/sound_manager.h"
#include "engine/script/lua_tinker_manager.h"

#include <cassert>
#include <cstddef>

namespace {

//const std::string kPlayerBoxTextureFolder = "ui/ui_battle";
const std::string kPlayerBoxTextureArray[] = {
  "professionbox_red.png",
  "professionbox_yellow.png",
  "professionbox_pruple.png",
  "professionbox_green.png",
  "professionbox_blue.png"
};


const cocos2d::CCPoint kAnchorPointArray[] = {
  cocos2d::CCPoint(1, 0),
  cocos2d::CCPoint(0, 0),
  cocos2d::CCPoint(0, 1),
  cocos2d::CCPoint(1, 1)
};

const bool kFlipXArray[] = {
  false,
  true,
  true,
  false
};

const bool kFlipYArray[] = {
  false,
  false,
  true,
  true
};

const int kBatchNodeTag = 123;

}

using namespace cocos2d;

namespace taomee {
namespace battle {

PlayerBox* PlayerBox::Create(PlayerBoxColor box_color)
{
  PlayerBox* player_box = new PlayerBox();
  player_box->Init(box_color);
  player_box->autorelease();

  return player_box;
}

PlayerBox::PlayerBox()
: state_(kStateUnselected)
{

}

PlayerBox::~PlayerBox()
{

}

void PlayerBox::Init(PlayerBoxColor box_color)
{
  assert(box_color >= 0 && box_color < sizeof (kPlayerBoxTextureArray) / sizeof (kPlayerBoxTextureArray[0]));

//   std::string player_box_texture = kPlayerBoxTextureFolder;
//   player_box_texture += "/";
  std::string player_box_texture = kPlayerBoxTextureArray[box_color];

  CCSpriteBatchNode* batch_node = CCSpriteBatchNode::create("textures/battle/battle_ex.pvr.ccz");

  CCSprite *sprite = NULL;
  for (int i = 0; i < 4; ++i)
  {
    sprite = CCSprite::createWithSpriteFrameName(player_box_texture.c_str());
    sprite->setPosition(CCPointZero);
    sprite->setAnchorPoint(kAnchorPointArray[i]);
    sprite->setFlipX(kFlipXArray[i]);
    sprite->setFlipY(kFlipYArray[i]);

    batch_node->addChild(sprite);
  }

  this->addChild(batch_node, kBatchNodeTag, kBatchNodeTag);
}

void PlayerBox::OnSelected()
{
  if (state_ == kStateSelected)
  {
    return;
  }

  state_ = kStateSelected;

  CCNode* batch_node = this->getChildByTag(kBatchNodeTag);
  assert(batch_node != NULL);

  batch_node->setScale(2.0f);

  CCScaleTo* init_scale_down = CCScaleTo::create(0.5f, 1.0f);
  CCCallFuncN* init_scale_callback = CCCallFuncN::create(this, callfuncN_selector(PlayerBox::OnInitScaleCompleted));
  batch_node->runAction(CCSequence::create(init_scale_down, init_scale_callback, NULL));
  SoundManager::GetInstance().PlayEffect(GetLuaSoundEffect("kSIDCharacterSelected"));
}

void PlayerBox::OnUnselected()
{
  state_ = kStateUnselected;

  CCNode* batch_node = this->getChildByTag(kBatchNodeTag);
  assert(batch_node != NULL);

  batch_node->stopAllActions();
  batch_node->setScale(1.0f);
}

bool PlayerBox::IsSelected()
{
  return state_ == kStateSelected;
}

void PlayerBox::OnInitScaleCompleted(cocos2d::CCNode* node)
{
  assert(node != NULL);

  CCScaleTo* scale_up = CCScaleTo::create(0.5f, 1.05f);
  CCScaleTo* scale_down = CCScaleTo::create(0.5f, 0.95f);
  CCSequence* scale = CCSequence::create(scale_up, scale_down, NULL);
  CCRepeatForever* repeat_action = CCRepeatForever::create(scale);
  node->runAction(repeat_action);
}


} /* namespace battle */
} /* namespace taomee */
