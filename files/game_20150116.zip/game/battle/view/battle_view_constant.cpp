﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_view_constant.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/view/battle_view_constant.h"
#include "game/battle/tiled_map/map_constants.h"

#include "CCDirector.h"
#include "CCEGLView.h"
#include <algorithm>

using namespace cocos2d;

namespace {

const CCSize kMapLayerDesignSize = iCC_DESIGN_SIZE;
const CCSize kBattleLayerDesignSize = iCC_DESIGN_SIZE;

}


namespace taomee {
namespace battle {

cocos2d::CCSize GetMapLayerDesignSize()
{
  return kMapLayerDesignSize;
}

cocos2d::CCSize GetBattleLayerDesignSize()
{
  return kBattleLayerDesignSize;
}

float GetMapLayerScale()
{
  CCSize window_size = CCDirector::sharedDirector()->getWinSize();
  float map_scale = (std::max)(window_size.width / kMapLayerDesignSize.width,
                               window_size.height / kMapLayerDesignSize.height);

  return map_scale;
}

float GetBattleLayerScale()
{
  CCSize window_size = CCDirector::sharedDirector()->getWinSize();
  float battle_scale = (std::min)(window_size.width / kBattleLayerDesignSize.width,
                                  window_size.height / kBattleLayerDesignSize.height);

  return battle_scale;
}

} /* namespace battle */
} /* namespace taomee */
