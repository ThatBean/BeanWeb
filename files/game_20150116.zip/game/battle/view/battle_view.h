﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_view.h
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_VIEW_H_
#define BATTLE_VIEW_H_

#include "game/battle/view/battle_view_constant.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "engine/base/basictypes.h"
#include "engine/base/callback.h"
#include "game/battle/view/IBattleView.h"

namespace cocos2d
{
class CCScene;
class CCNode;
class CCLayer;
}

namespace taomee {

namespace army {
class MoveObject;
}
class TouchHelper;
namespace battle {

class BattleLayer;
class TouchHandler;
class TiledGridLayer;


class BattleView : public IBattleView
{
public:
  BattleView();
  virtual ~BattleView();

public:
  void Init();
  void SwitchToBattleScene();
  void CreateBattleStage(uint_32 check_point_id);
  void SetBattleStageDefault();

  void LoadBattleStage();

  void SetTouchHandler(TouchHandler* touch_handler);

  void AddMoveObject(army::MoveObject* move_object);
  void AddElementToScene(cocos2d::CCNode* element, BattleLayerType layer_type);
  void RemoveElementFromScene(int_32 tag, BattleLayerType layer_type);
  void UpdateBindNode(BattleLayerType layer_type, uint_32 move_obj_id, cocos2d::CCPoint pos);
  void ClearBindNode(uint_32 move_obj_id);
  
  void PauseBattleLayer();
  void ResumeBattleLayer();

  void CreateArrows(ai::eAIBornLine line_type);

  void SetTouchFliterEnable(bool flag);
public:
  void ResetBattleViewForBattleWin();
  void ZoomContainerLayerWithNewFocusPoint(cocos2d::CCPoint anPoint);
  void ZoomOutContainerLayerWithNewFocusPoint(cocos2d::CCPoint anPoint);
  void ZoomInContainerLayer();
  
public: // getter & setter
  cocos2d::CCScene* battle_scene()
  {
    return battle_scene_;
  }
  cocos2d::CCLayer* Battle_Container_Layer();
  cocos2d::CCLayer* Battle_Layer();
  cocos2d::CCLayer* GetLayer(BattleLayerType layer_type);
  cocos2d::CCNode*  GetLayerBindNode(BattleLayerType layer_type, uint_32 move_obj_id);
  cocos2d::CCLayer* get_ui_layer() {return ui_layer_;}

private:
  void CreateMapLayer(uint_32 check_point_id);
  void CreateBattleLayer();
  void CreateTopBattleLayer(uint_32 check_point_id);
  void createTiledGridLayer();
  
  void reversivelyPauseAllChildren(cocos2d::CCNode* node);
  void reversivelyResumeAllChildren(cocos2d::CCNode* node);
  
  void resetContainerLayerBack();

private:
  base::CCCallback<BattleView>* callback_;
  cocos2d::CCScene* battle_scene_;
  cocos2d::CCLayer* container_layer_;
  BattleLayer* battle_layer_;
  TiledGridLayer* grid_layer_;
  cocos2d::CCLayer* ui_layer_;

  TouchHelper* touch_helper_;
  cocos2d::CCSprite* mBgSprite;
public:
  cocos2d::CCSprite* getBattleBgSprite() { return mBgSprite; };
};

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_VIEW_H_ */
