//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_layer.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////
#include "engine/base/basictypes.h"
#include "game/battle/view/battle_layer.h"

#include "game/battle/touch/touch_handler.h"

using namespace cocos2d;

namespace taomee {
namespace battle {

BattleLayer::BattleLayer()
: touch_handler_(NULL)
{

}

BattleLayer::~BattleLayer()
{
  touch_handler_ = NULL;
}

bool BattleLayer::init()
{
  if (!CCLayer::init())
  {
    return false;
  }

  this->setContentSize(GetBattleLayerDesignSize());
  this->ignoreAnchorPointForPosition(false);
  this->setAnchorPoint(ccp(0.5f, 0.5f)); 
  this->setScale(GetBattleLayerScale() * 0.9f);
//  CCSprite* grid_sprite = CCSprite::create("textures/map/grid.png");
//  grid_sprite->setAnchorPoint(ccp(0.5f, 0.5f));
//  grid_sprite->setPosition(ccp(0, 0));
//  this->addChild(grid_sprite, -1);

  const CCSize battle_layer_size = GetBattleLayerDesignSize();
  for (int i = kBottomLayer; i < kLayerEnd; ++i) {
    CCLayer* layer = CCLayer::create();
    layer->setContentSize(battle_layer_size);
    layer->setPosition(ccp(this->getContentSize().width * 0.5f,this->getContentSize().height * 0.5f));
    layer->setAnchorPoint(ccp(0.5f, 0.5f));
    layer->ignoreAnchorPointForPosition(false);
    this->addChild(layer, i, i);
  }

  // enable touch
  this->setTouchEnabled(true);

  return true;

}

void BattleLayer::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
  if (touch_handler_ != NULL)
  {
    touch_handler_->OnTouchesBegan(pTouches, pEvent, this->GetLayer(kCharacterLayer));
  }
}

void BattleLayer::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
  if (touch_handler_ != NULL)
  {
    touch_handler_->OnTouchesMoved(pTouches, pEvent, this->GetLayer(kCharacterLayer));
  }
}

void BattleLayer::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{
  if (touch_handler_ != NULL)
  {
    touch_handler_->OnTouchesEnded(pTouches, pEvent, this->GetLayer(kCharacterLayer));
  }
}

void BattleLayer::ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
{

}

cocos2d::CCLayer* BattleLayer::GetLayer(BattleLayerType layer_type)
{
  assert(layer_type >= kLayerBegin && layer_type < kLayerEnd);

  CCLayer* layer = dynamic_cast<CCLayer*>(this->getChildByTag(layer_type));
  return layer;
}

void BattleLayer::AddElement(cocos2d::CCNode* element, BattleLayerType layer_type)
{
  assert(element != NULL);

  CCLayer* layer = this->GetLayer(layer_type);
  if (layer != NULL) {
    layer->addChild(element);
  } else {
    assert(false);
  }
}

void BattleLayer::RemoveElementWithTag(int_32 tag, BattleLayerType layer_type)
{
  CCLayer* layer = this->GetLayer(layer_type);
  if (layer != NULL) {
	layer->removeChildByTag(tag);
  } else {
	assert(false);
  }
}

// this node pos will be refreshed
CCNode* BattleLayer::GetLayerBindNode( BattleLayerType layer_type, uint_32 move_obj_id )
{
  CCLayer* layer = GetLayer(layer_type);
  if (layer) 
  {
    CCNode* node = layer->getChildByTag(move_obj_id);
    if (node == NULL) 
    {
      node = CCNode::create();
      node->setTag(move_obj_id);
      layer->addChild(node);
    }
    return node;
  }
  return NULL;
}

void BattleLayer::UpdateBindNode( BattleLayerType layer_type, uint_32 move_obj_id, cocos2d::CCPoint pos )
{
  CCLayer* layer = GetLayer(layer_type);
  if (layer) 
  {
    CCNode* node = layer->getChildByTag(move_obj_id);
    if (node) 
    {
      node->setPosition(pos);
    }
  }
}

void BattleLayer::ClearBindNode(uint_32 move_obj_id)
{
  for (int i = kBottomLayer; i < kLayerEnd; ++i)
  {
    CCLayer* layer = GetLayer((BattleLayerType)i);
    if (layer) 
    {
      layer->removeChildByTag(move_obj_id);
    }
  }
}





} /* namespace battle */
} /* namespace taomee */
