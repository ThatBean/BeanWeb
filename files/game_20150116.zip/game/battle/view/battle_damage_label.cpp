//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-29
//          Time:  9:56
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-29        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/view/battle_damage_label.h"

#include "game/battle/view/battle_view.h"
#include "game/effect/CCShake.h"
//#include "game/pvp/pvp_view/pvp_view.h"
#include "engine/base/loggermanager.h"
#include "game/battle/battle_controller.h"

namespace taomee {
namespace battle {
  
using namespace cocos2d;

static int g_DamageLabelZOrder = 1<<30;
static const float DamageLableSize_NormalDamage = 0.4f;
static const float DamageLableSize_WeakenDamage = DamageLableSize_NormalDamage * 0.75f;
static const float DamageLableSize_CriticalDamage = DamageLableSize_NormalDamage * 1.5f;
static const float DamageLableSize_SkillDamage = DamageLableSize_NormalDamage * 2.0f;
static const float DamageLableSize_Text = DamageLableSize_NormalDamage * 1.0f;
static const float DamageLable_MoveBy0_Y = 50.0f;
static const float DamageLable_MoveBy1_Y = 100.0f;

DamageLabelPool::DamageLabelPool(int size)
	: mSize(size)
{


}

DamageLabelPool::~DamageLabelPool()
{
	clearup();
}

DamageLabel* DamageLabelPool::create()
{
	DamageLabel* obj = NULL;

	if (mPool.empty())
	{
		obj = new DamageLabel();
		obj->init();
    mAllLabelPool.push_back(obj);
	}
	else
	{
		obj = mPool.front();
		mPool.pop();
	}
	

	return obj;
}

void DamageLabelPool::destroy(DamageLabel* obj)
{
	if ( !obj )
	{
		return;
	}

	if ( mPool.size() > mSize )
	{
    std::vector<DamageLabel*>::iterator it = mAllLabelPool.begin();
    for (; it != mAllLabelPool.end(); ++it)
    {
      if (obj == *it)
      {
        (*it)->release();
        mAllLabelPool.erase(it);
        break;
      }
    }
	}
	else
	{
		mPool.push( obj );
	}
}

void DamageLabelPool::clearup()
{
  std::vector<DamageLabel*>::iterator it = mAllLabelPool.begin();
  for (; it != mAllLabelPool.end(); )
  {
    (*it)->release();
    it = mAllLabelPool.erase(it);
  }
  
	while ( !mPool.empty())
	{
		mPool.pop();
	}
  
}

DamageLabel::DamageLabel()
	: damage_label_(NULL)
	, tex_text_(NULL)
{
  
}

DamageLabel::~DamageLabel()
{
	if (tex_text_ && tex_text_->getParent())
	{
		tex_text_->removeFromParentAndCleanup(true);
		CC_SAFE_RELEASE_NULL(tex_text_);
	}

  CC_SAFE_RELEASE_NULL(damage_label_);
}
  
bool DamageLabel::init()
{
	if (!CCNode::init())
	{
		return false;
	}

	font_resource_ = "font/gary_number.png";
 	damage_label_ = cocos2d::CCLabelAtlas::create("+,-./0123456789:", font_resource_.c_str(), 45, 59, '+');
	damage_label_->retain();
	damage_label_->setAnchorPoint(ccp(0.5f, 0.5f));
	damage_label_->setCascadeColorEnabled(true);
	damage_label_->setCascadeOpacityEnabled(true);
	damage_label_->setOpacityModifyRGB(true);
	this->addChild(damage_label_);

	CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(
		"ui/agoui_local_text/agoui_local_text_ex.plist",
		"ui/agoui_local_text/agoui_local_text_ex.pvr.ccz");

	sprite_resource_ = "agoui_jiansu_yellow.png";
	tex_text_ = CCSprite::createWithSpriteFrameName(sprite_resource_.c_str());
	//tex_text_ = cocos2d::CCSprite::create(sprite_resource_.c_str());
	tex_text_->retain();
	tex_text_->setAnchorPoint(ccp(0.5f, 0.0f));
	tex_text_->setCascadeColorEnabled(true);
	tex_text_->setCascadeOpacityEnabled(true);
	tex_text_->setOpacityModifyRGB(true);
	this->addChild(tex_text_);

	this->setCascadeColorEnabled(true);
	this->setCascadeOpacityEnabled(true);
	this->setOpacityModifyRGB(true);
	return true;
}

void DamageLabel::reset()
{
	is_character_ = false;
	damage_value_ = 0;
	damage_label_type_ = eDamageLabelType_Unknown;
	damage_label_color_ = ccWHITE;
	damage_value_str_ = "";
}
  
DamageLabel* DamageLabel::create(eDamageLabelType damage_label_type, int damage_value, bool is_character)
{
	 DamageLabel * pRet = BattleController::GetInstance().damage_label_pool()->create();
	 pRet->reset();

	 pRet->setIsCharacter(is_character);
	 pRet->setDamageValue(damage_value);
	 pRet->setDamageLabelType( damage_label_type);

	return pRet;
}

void DamageLabel::setIsCharacter(bool b)
{
	this->is_character_ = b;
}
void DamageLabel::setDamageValue(int damage_value)
{
	this->damage_value_ = damage_value;
}

void DamageLabel::setDamageLabelType(eDamageLabelType dlType)
{
	this->damage_label_type_ = dlType;
}

bool DamageLabel::checkValid()
{
	if ( this->damage_label_type_ == eDamageLabelType_Unknown)
	{
		return false;
	}

	if ( this->damage_value_ == 0 && (
		this->damage_label_type_ == eDamageLabelType_Physics || 
		this->damage_label_type_ == eDamageLabelType_Magic || 
		this->damage_label_type_ == eDamageLabelType_PhysicsCritical || 
		this->damage_label_type_ == eDamageLabelType_MagicCritical || 
		this->damage_label_type_ == eDamageLabelType_PhysicsSkill || 
		this->damage_label_type_ == eDamageLabelType_MagicSkill || 
		this->damage_label_type_ == eDamageLabelType_Ice || 
		this->damage_label_type_ == eDamageLabelType_Fire || 
		this->damage_label_type_ == eDamageLabelType_Wind || 
		this->damage_label_type_ == eDamageLabelType_Heal))
	{
		return false;
	}

	return true;
}

void DamageLabel::ShowDamageValueOnBattleLayer(battle::BattleView* parent, cocos2d::CCPoint position)
{
	if ( !checkValid())
	{
		return;
	}

	this->setPosition( position);
	this->setZOrder(g_DamageLabelZOrder--);
	parent->AddElementToScene( this, kTopLayer);

	updateDamageContent();

	updateDamageFontResouce();

	updateColor();

	updateTextureText();

	updateDamageLableCtrl();
	
	playAction();
}

void DamageLabel::updateDamageContent()
{	
	if ( damage_value_ < 0)
	{
		char damage_str[16] = {'\0'};
		sprintf(damage_str, "+%d", abs(damage_value_));
		damage_value_str_ = damage_str;
	}
	else if ( damage_value_  > 0)
	{
		char damage_str[16] = {'\0'};
		if ( is_character_)
		{
			sprintf(damage_str, "-%d", abs(damage_value_));
		}
		else
		{
			sprintf(damage_str, "%d", abs(damage_value_));
		}
		damage_value_str_ = damage_str;
	}
	else//if ( damage_value_ == 0)
	{
		damage_value_str_ = "";
	}
}

void DamageLabel::updateDamageFontResouce()
{
	if ( damage_value_ == 0)
	{
		return;
	}
 
 	switch( this->damage_label_type_ )
 	{
 	case eDamageLabelType_Heal:
 		font_resource_ = "font/green_number.png";
 		break;
 	case eDamageLabelType_Ice:
 		font_resource_ = "font/blue_number.png";
 		break;
 	case eDamageLabelType_Fire:
 		font_resource_ = "font/orange_number.png";
 		break;
 	case eDamageLabelType_Wind:
 		font_resource_ = "font/purple_number.png";
 		break;
 	default:
 		font_resource_ = "font/gary_number.png";
 		break;
 	}
}

void DamageLabel::updateDamageLableCtrl()
{
	this->setZOrder(100);
	this->setScale(0.1f);
	this->setColor(damage_label_color_);

	if ( damage_value_str_.empty())
	{
		damage_label_->setVisible(false);
	}
	else
	{
		damage_label_->setVisible(true);
		damage_label_->setPositionX(0);
		damage_label_->initWithString(damage_value_str_.c_str(), font_resource_.c_str(), 45, 59, '+');
	}

	if ( sprite_resource_.empty() )
	{
		tex_text_->setVisible(false);
	}
	else
	{
		CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(
			"ui/agoui_local_text/agoui_local_text_ex.plist",
			"ui/agoui_local_text/agoui_local_text_ex.pvr.ccz");

		tex_text_->setVisible( true );
		tex_text_->setPositionX(0);
		tex_text_->initWithSpriteFrameName(sprite_resource_.c_str());
	}

	if (damage_label_->isVisible() && tex_text_->isVisible())
	{
		CCSize texSize = tex_text_->boundingBox().size;
		tex_text_->setPositionX( -texSize.width/2.0f );

		// offset x
		CCSize damage_label_Size = damage_label_->boundingBox().size;
		float offset_x = damage_label_Size.width/2.0f + (texSize.width - damage_label_Size.width)/4.0f;
		damage_label_->setPositionX( damage_label_->getPositionX() + offset_x);
	}
}

void DamageLabel::updateTextureText()
{
	sprite_resource_ = "";
	switch( this->damage_label_type_ )
	{
	case eDamageLabelType_Invincible:
	case eDamageLabelType_ImmuneControl:
		sprite_resource_ = is_character_ ? "agoui_mianyi_green.png" : "agoui_mianyi_yellow.png";
		break;
	case eDamageLabelType_PhysicsImmune:
		sprite_resource_ = is_character_ ? "agoui_wulidikang_green.png" : "agoui_wulidikang_yellow.png";
		break;
	case eDamageLabelType_MagicImmune:
		sprite_resource_ = is_character_ ? "agoui_fashudikan_green.png" : "agoui_fashudikan_yellow.png";
		break;
	case eDamageLabelType_AddPhysicsDefense:
		sprite_resource_ = is_character_ ? "agoui_wufangdun_green.png" : "agoui_wufangdun_yellow.png";
		break;
	case eDamageLabelType_AddMagicDefense:
		sprite_resource_ = is_character_ ? "agoui_fafangdun_green.png" : "agoui_fafangdun_yellow.png";
		break;
	case eDamageLabelType_SubPhysicsDefense:
		sprite_resource_ = is_character_ ? "agoui_wufangpo_red.png" : "agoui_wufangpo_yellow.png";
		break;
	case eDamageLabelType_SubMagicDefense:
		sprite_resource_ = is_character_ ? "agoui_fafangpo_red.png" : "agoui_fafangpo_yellow.png";
		break;
	case eDamageLabelType_SubSpeed:
		sprite_resource_ = is_character_ ? "agoui_jiansu_red.png" : "agoui_jiansu_yellow.png";
		break;
	case eDamageLabelType_Stunned:
		sprite_resource_ = is_character_ ? "agoui_xuayun_red.png" : "agoui_xuanyun_yellow.png";
		break;
	case eDamageLabelType_Freeze:
		sprite_resource_ = is_character_ ? "agoui_dongjing_red.png" : "agoui_dongjie_yellow.png";
		break;
	case eDamageLabelType_Poison:
		sprite_resource_ = is_character_ ? "agoui_zhongdu_red.png" : "agoui_zhongdu_yellow.png";
		break;
	case eDamageLabelType_Silence:
		sprite_resource_ = is_character_ ? "agoui_fengmo_red.png" : "agoui_fengmo_yellow.png";
		break;
	case eDamageLabelType_Blinded:
		sprite_resource_ = is_character_ ? "agoui_zhimang_red.png" : "agoui_zhimang_yellow.png";
		break;
	case eDamageLabelType_SeriousInjury:
		sprite_resource_ = is_character_ ? "agoui_zhisi_red.png" : "agoui_zhisi_yellow.png";
		break;
	case eDamageLabelType_Petrifaction:
		sprite_resource_ = is_character_ ? "agoui_shihua_red.png" : "agoui_shihua_yellow.png";
		break;
 	case eDamageLabelType_Frostbite:
 		sprite_resource_ = is_character_ ? "agoui_bingshang_red.png" : "agoui_bingshang_yellow.png";
 		break;
	case eDamageLabelType_Weathering:
		sprite_resource_ = is_character_ ? "agoui_fengshang_red.png" : "agoui_fengshang_yellow.png";
		break;
	case eDamageLabelType_Flammable:
		sprite_resource_ = is_character_ ? "agoui_huoshang_red.png" : "agoui_huoshang_yellow.png";
		break;
	case eDamageLabelType_Slay:
		sprite_resource_ = is_character_ ? "agoui_zhansha_red.png" : "agoui_zhansha_yellow.png";
		break;
	default:
		sprite_resource_ = "";
		break;
	}
}

void DamageLabel::updateColor()
{
	if ( damage_value_ == 0)
	{
		return;
	}

	switch(this->damage_label_type_)
	{
	case eDamageLabelType_Heal:
		//damage_label_color_ = ccGREEN;
		break;
	case eDamageLabelType_Ice:
		//damage_label_color_ = ccBLUE;
		break;
	case eDamageLabelType_Fire:
		//damage_label_color_ = ccORANGE;
		break;
	case eDamageLabelType_Wind:
		//damage_label_color_ = ccGRAY;
		break;
	case eDamageLabelType_Physics:
	case eDamageLabelType_PhysicsCritical:
	case eDamageLabelType_PhysicsSkill:
		damage_label_color_ = is_character_ ? ccRED: ccWHITE;
		break;
	case eDamageLabelType_Magic:
	case eDamageLabelType_MagicCritical:
	case eDamageLabelType_MagicSkill:
		damage_label_color_ = is_character_ ? ccRED: ccYELLOW;
		break;

	default:
		damage_label_color_ = ccWHITE;
		break;
	}
}

void DamageLabel::playAction()
{
	float fadeout_in = 0.3f;
	float fadeout_time = 0.6f;
	float stop_time = 0.0f;
	cocos2d::CCSequence* actSeq = NULL;

	switch( this->damage_label_type_ )
	{
	case eDamageLabelType_PhysicsCritical:
	case eDamageLabelType_MagicCritical:
		{
			//1
			cocos2d::CCScaleTo* scaleBig = cocos2d::CCScaleTo::create( fadeout_in, DamageLableSize_CriticalDamage);
			cocos2d::CCMoveBy* upTo = cocos2d::CCMoveBy::create( fadeout_in, cocos2d::CCPoint(0,DamageLable_MoveBy0_Y));
			cocos2d::CCSpawn* big_upto = cocos2d::CCSpawn::create( scaleBig, upTo, NULL);
			//2
			CCShake* shake = CCShake::actionWithDuration(0.3f, 4.0f, 0.6f);
			cocos2d::CCScaleTo* scaleSmall = cocos2d::CCScaleTo::create(0.1f, DamageLableSize_NormalDamage);
			stop_time = 0.4f;
			//3
			cocos2d::CCMoveBy* moveOut = cocos2d::CCMoveBy::create(fadeout_time, cocos2d::CCPoint(0,DamageLable_MoveBy1_Y));
			actSeq = cocos2d::CCSequence::create(big_upto, shake, scaleSmall ,moveOut, NULL);
		}
		break;
	case eDamageLabelType_PhysicsSkill:
	case eDamageLabelType_MagicSkill:
		{
			//1
			cocos2d::CCScaleTo* scaleBig = cocos2d::CCScaleTo::create( fadeout_in, DamageLableSize_SkillDamage);
			cocos2d::CCMoveBy* upTo = cocos2d::CCMoveBy::create( fadeout_in, cocos2d::CCPoint(0,DamageLable_MoveBy0_Y));
			cocos2d::CCSpawn* big_upto = cocos2d::CCSpawn::create( scaleBig, upTo, NULL);
			//2
			CCShake* shake = CCShake::actionWithDuration(0.3f, 4.0f, 0.6f);
			cocos2d::CCScaleTo* scaleSmall = cocos2d::CCScaleTo::create(0.1f, DamageLableSize_NormalDamage);
			stop_time = 0.4f;
			//3
			cocos2d::CCMoveBy* moveOut = cocos2d::CCMoveBy::create(fadeout_time, cocos2d::CCPoint(0,DamageLable_MoveBy1_Y));
			actSeq = cocos2d::CCSequence::create(big_upto, shake, scaleSmall ,moveOut, NULL);
		}
		break;
	case eDamageLabelType_Physics:
	case eDamageLabelType_Magic:
	case eDamageLabelType_Ice:
	case eDamageLabelType_Fire:
	case eDamageLabelType_Wind:
	case eDamageLabelType_Heal:
		{
			//1
			cocos2d::CCScaleTo* scaleBig = cocos2d::CCScaleTo::create(fadeout_in, DamageLableSize_NormalDamage);
			cocos2d::CCMoveBy* upTo = cocos2d::CCMoveBy::create( fadeout_in, cocos2d::CCPoint(0,DamageLable_MoveBy0_Y));
			cocos2d::CCSpawn* big_upto = cocos2d::CCSpawn::create( scaleBig, upTo, NULL);
			//2
			cocos2d::CCDelayTime* stop = cocos2d::CCDelayTime::create(0.2f);
			stop_time = 0.2f;
			//3
			cocos2d::CCMoveBy* moveOut = cocos2d::CCMoveBy::create( fadeout_time, cocos2d::CCPoint(0,DamageLable_MoveBy1_Y));
			actSeq = cocos2d::CCSequence::create( big_upto,stop,moveOut, NULL);
		}
		break;
	case eDamageLabelType_Invincible:
	case eDamageLabelType_PhysicsImmune:
	case eDamageLabelType_MagicImmune:
	case eDamageLabelType_Dodge:
	case eDamageLabelType_AddPhysicsDefense:
	case eDamageLabelType_AddMagicDefense:
	case eDamageLabelType_SubPhysicsDefense:
	case eDamageLabelType_SubMagicDefense:
	case eDamageLabelType_SubSpeed:
	case eDamageLabelType_Stunned:
	case eDamageLabelType_Freeze:
	case eDamageLabelType_Poison:
	case eDamageLabelType_Silence:
	case eDamageLabelType_Blinded:
	case eDamageLabelType_SeriousInjury:
	case eDamageLabelType_Petrifaction:
	case eDamageLabelType_Slay:
		{
			//1
			cocos2d::CCScaleTo* scaleBig = cocos2d::CCScaleTo::create(fadeout_in, DamageLableSize_Text);
			cocos2d::CCMoveBy* upTo = cocos2d::CCMoveBy::create( fadeout_in, cocos2d::CCPoint(0,DamageLable_MoveBy0_Y*2));
			cocos2d::CCSpawn* big_upto = cocos2d::CCSpawn::create( scaleBig, upTo, NULL);
			//2
			cocos2d::CCDelayTime* stop = cocos2d::CCDelayTime::create(0.6f);
			stop_time = 0.6f;
			//3
			cocos2d::CCDelayTime* stop1 = cocos2d::CCDelayTime::create(fadeout_time);
			actSeq = cocos2d::CCSequence::create( big_upto,stop,stop1, NULL);
		}
		break;
	default:
		
		break;
	}

	// ���뵭��
	cocos2d::CCFadeIn* fadeIn = cocos2d::CCFadeIn::create(fadeout_in);
	cocos2d::CCDelayTime* dalayTime = cocos2d::CCDelayTime::create(stop_time);
	cocos2d::CCFadeOut* fadeOut = cocos2d::CCFadeOut::create(fadeout_time);
	cocos2d::CCSequence* fade_in_out =  cocos2d::CCSequence::create(fadeIn, dalayTime, fadeOut,NULL);

	cocos2d::CCSpawn* spawn = cocos2d::CCSpawn::create( fade_in_out, actSeq,NULL);

	CCRemoveSelf* removeSelf = CCRemoveSelf::create();
	cocos2d::CCCallFunc* callback = cocos2d::CCCallFunc::create( this, callfunc_selector(DamageLabel::actionFinishedCallback));
	CCCallFunc* recycleCallBack = CCCallFunc::create(this, callfunc_selector(DamageLabel::recycleCallBack));

  this->setScale(DamageLableSize_NormalDamage);
	this->runAction(cocos2d::CCSequence::create( spawn, callback, removeSelf, recycleCallBack,NULL));
}
  
void DamageLabel::recycleCallBack()
{
  	BattleController::GetInstance().damage_label_pool()->destroy( this);
}

void DamageLabel::actionFinishedCallback()
{
	this->stopAllActions();
}

eDamageLabelType DamageLabel::toDamageLabelType(uint_32 attack_type , eAttackDamageType damege_type)
{
	if (attack_type & kAttackResultIceDamage)
	{
		return eDamageLabelType_Ice;
	}
	else if (attack_type & kAttackResultFireDamage)
	{
		return eDamageLabelType_Fire;
	}
	else if (attack_type & kAttackResultWindDamage)
	{
		return eDamageLabelType_Wind;
	}
	else if (attack_type & kAttackResultSkillDamage)
	{
		if ( damege_type == kDamageTypePhysics)
			return eDamageLabelType_PhysicsSkill;
		else
			return eDamageLabelType_MagicSkill;
	}
	else if (attack_type & kAttackResultCriticalDamage)
	{
		if ( damege_type == kDamageTypePhysics)
			return eDamageLabelType_PhysicsCritical;
		else
			return eDamageLabelType_MagicCritical;
	}
	else if ( attack_type & kAttackResultNormalDamage)
	{
		if ( damege_type == kDamageTypePhysics)
			return eDamageLabelType_Physics;
		else
			return eDamageLabelType_Magic;
	}

	return eDamageLabelType_Unknown;
}


eDamageLabelType DamageLabel::toDamageLabelType( eDamageStatus battle_status)
{
	switch (battle_status)
	{
	case kDamageLoweMoveSpeed:
	case kDamageLowerAttackSpeed:
		return eDamageLabelType_SubSpeed;
		break;
	case kDamageStunned:
		return eDamageLabelType_Stunned;
		break;
	case kDamageFreeze:
		return eDamageLabelType_Freeze;
		break;
	case kDamagePoison:
		return eDamageLabelType_Poison;
		break;
	case kDamagePetrifaction:
		return eDamageLabelType_Petrifaction;
		break;
	case kDamageBlinded:
		return eDamageLabelType_Blinded;
		break;
	case kDamageSilence:
		return eDamageLabelType_Silence;
		break;
	case kDamageSeriousInjury:
		return eDamageLabelType_SeriousInjury;
		break;
	}
	return eDamageLabelType_Unknown;
}

} // namespace battle
} // namespace taomee