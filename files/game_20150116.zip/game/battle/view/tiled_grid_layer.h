//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-18
//          Time:  3:47
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-18        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_tiled_grid_layer_h
#define ChainChronicle_tiled_grid_layer_h

#include "engine/base/cocos2d_wrapper.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"

namespace taomee {
namespace battle {
  
class TiledGridLayer : public cocos2d::CCLayer
{
public:
  TiledGridLayer() {}
  ~TiledGridLayer() {}
  
  CREATE_FUNC(TiledGridLayer);
  
  virtual bool init();
  virtual void draw();

  void          CreateArrow(ai::eAIBornLine line_type);
private:
  void          onBlinkFinished(cocos2d::CCNode* node);

  cocos2d::CCSpriteBatchNode* gridBatch_;
};
  
} // namespace battle
} // namespace taomee

#endif // ChainChronicle_tiled_grid_layer_h
