//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  map_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-17
//          Time:  3:52
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-17        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/tiled_map/map_constants.h"

namespace taomee {
namespace battle {
  
static cocos2d::CCPoint grid_pos_[kMapRowCount+1][kMapColumnCount+1];

const cocos2d::CCPoint& grid_position_x_y(int_8 x, int_8 y)
{
  assert(grid_pos_[0][0].x != kUnexistTileIndex ||
         grid_pos_[0][0].y != kUnexistTileIndex);
  return grid_pos_[x][y];
}
  
const cocos2d::CCPoint BorderTilesCoordinatePosbyTileIndex(int_8 index)
{
  assert(index<kMapTilesIndexMax);
  if (index==kBorderRightFailedTileIndex)
  {
    return kBorderRightFailedTileCoordinate;
  }
  return ccp(kUnexistTileCoordinate, index-kBorderRightFailedTileIndex-1);
}

int_8 BorderTilesIndexByTilesCoordinatePos(const cocos2d::CCPoint& pos)
{
  if (pos.x==kMapColumnCount && pos.y==0)
  {
    return kBorderRightFailedTileIndex;
  }
  assert(pos.x==kUnexistTileCoordinate && pos.y<kMapRowCount);
  return kBorderRightFailedTileIndex+pos.y+1;
}
  
void CalculateGridPositionForBattleFieldOnlyOnceInTileMapConstructor()
{
  if (grid_pos_[0][0].x == kUnexistTileIndex &&
      grid_pos_[0][0].y == kUnexistTileIndex)
  {
    // calculate yet
    assert(false);
    return;
  }
  // calculate position for all grid corner points
  cocos2d::CCSize display_size = iCC_DESIGN_SIZE;
  float width_long = display_size.width*KWidthScreenWidthRatio;
  float height = width_long*kHieghtWidthRatio;
  float width_short = width_long - kIncreasePixels*kMapTilesCount;
  cocos2d::CCPoint first_point_pos = ccp((display_size.width-width_short)*0.5f,
                                         (display_size.height+height)*0.5f-kHeightDownOffset);
  float unit_height = (height-0.5f*(kMapRowCount-1)*kMapRowCount*kIncreasePixels)/kMapRowCount;
  float unit_width = width_short/kMapColumnCount;
  for (int i = 0; i<=kMapRowCount; ++i)
  {
    for (int j = 0; j<=kMapColumnCount; ++j)
    {
      grid_pos_[i][j] = ccp(first_point_pos.x+unit_width*j,
                            first_point_pos.y-unit_height*i);
    }
    first_point_pos.x = first_point_pos.x - 0.5f*kIncreasePixels*kMapColumnCount;
    unit_height += kIncreasePixels;
    unit_width += kIncreasePixels;
  }
}
  
}
}