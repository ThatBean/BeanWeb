//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-17
//          Time:  2:22
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-17        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/tiled_map/tiled_map.h"

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/character.h"
#include "game/battle/own_hub.h"
#include "game/battle/monster_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"

namespace taomee {
namespace battle {

/*
index arrangement for tiled map, add by peteryu
 ------------>x column
 |invalid                           invalid
 ----------------------------------------
 | 19     | 0 | 1 | 2 | 3 | 4 | 5 |
 | 20     | 6 | 7 | 8 | 9 | 10| 11|  18
 | 21     | 12| 13| 14| 15| 16| 17|
 y row
*/
  

TiledMap::TiledMap()
{
  // reset tile index & grassion card id
  for (int i = 0; i<kMapRowCount; ++i)
  {
    for (int j = 0; j<kMapColumnCount; ++j)
    {
      tiles_[i][j].tile_index_ = i*kMapColumnCount+j;
      tiles_[i][j].garrison_character_id_ = kUnexistGrassionCardId;
    }
  }
  // calculate position for all grid corner points
  CalculateGridPositionForBattleFieldOnlyOnceInTileMapConstructor();
}
  
// get grids range by self tile index & range grids count
bool TiledMap::GetRangeQuadrangleFourVertexPointInAnticlockwise(std::vector<cocos2d::CCPoint> &vertexs,
                                                                int_8 current_tile_idx,
                                                                int_8 range_width,
                                                                bool   is_left_derection /* = true */)
{
  vertexs.clear();
  cocos2d::CCPoint tileCoordinatePos = GetTileCoordinatePosByTileIndex(current_tile_idx);
  if (false==IsTileCoordinateInRange(tileCoordinatePos))
  {
    return false;
  }
  cocos2d::CCPoint topRight = cocos2d::CCPointZero;
  cocos2d::CCPoint topLeft = cocos2d::CCPointZero;
  cocos2d::CCPoint bottomRight = cocos2d::CCPointZero;
  cocos2d::CCPoint bottomLeft = cocos2d::CCPointZero;
  if (is_left_derection)
  {
    topRight = GetTopRightPointPositionInTile(current_tile_idx);
    bottomRight = GetBottomRightPointPositionInTile(current_tile_idx);
    // insert bottom right vertx of quadrangle
    vertexs.push_back(bottomRight);
    // insert top right vertx of quadrangle
    vertexs.push_back(topRight);
    tileCoordinatePos.x = tileCoordinatePos.x - range_width;
    // out of range
    if (tileCoordinatePos.x<0)
    {
      int_8 leftTile = GetTileIndexByTileCoordinatePos(ccp(0, tileCoordinatePos.y));
      float offsetLeft = kMapTileAverageLength +
                         kIncreasePixels*(tileCoordinatePos.y-kMapRowCount/2);
      topLeft = GetTopLeftPointPositionInTile(leftTile);
      bottomLeft = GetBottomLeftPointPositionInTile(leftTile);
      topLeft.x = topLeft.x - offsetLeft;
      bottomLeft.x= bottomLeft.x - offsetLeft;
    }
    else
    {
      int_8 leftTile = GetTileIndexByTileCoordinatePos(tileCoordinatePos);
      topLeft = GetTopLeftPointPositionInTile(leftTile);
      bottomLeft = GetBottomLeftPointPositionInTile(leftTile);
    }
    // insert top left vertx of quadrangle
    vertexs.push_back(topLeft);
    // insert bottom left vertx of quadrangle
    vertexs.push_back(bottomLeft);
  }
  else
  {
    topLeft = GetTopLeftPointPositionInTile(current_tile_idx);
    bottomLeft = GetBottomLeftPointPositionInTile(current_tile_idx);
    // insert top left vertex of quadrangle
    vertexs.push_back(topLeft);
    // insert bottom left vertex of quadrangle
    vertexs.push_back(bottomLeft);
    tileCoordinatePos.x = tileCoordinatePos.x + range_width;
    // out of range
    if (tileCoordinatePos.x>=kMapColumnCount)
    {
      int_8 rightTile = GetTileIndexByTileCoordinatePos(ccp(kMapColumnCount-1,
                                                             tileCoordinatePos.y));
      float offsetRight = kMapTileAverageLength +
                          kIncreasePixels*(tileCoordinatePos.y-kMapRowCount/2);
      topRight = GetTopRightPointPositionInTile(rightTile);
      bottomRight = GetBottomRightPointPositionInTile(rightTile);
      topRight.x = topRight.x + offsetRight;
      bottomRight.x = bottomRight.x + offsetRight;
    }
    else
    {
      int_8 rightTile = GetTileIndexByTileCoordinatePos(tileCoordinatePos);
      topRight = GetTopRightPointPositionInTile(rightTile);
      bottomRight = GetBottomRightPointPositionInTile(rightTile);
    }
    // insert bottom right vertex of quadrangle
    vertexs.push_back(bottomRight);
    // insert top right vertex of quadrangle
    vertexs.push_back(topRight);
  }
  return true;
}
  
// get tiles index by itself's location tile index & range grids info
bool TiledMap::GetRangeQuadrangleTilesList(std::vector<int_8> &tileIndexs,
                                           int_8 current_tile_idx,
                                           int_8 range_width,
                                           bool   is_left_derection /* = true */)
{
  tileIndexs.clear();
  cocos2d::CCPoint tileCoordinatePos = GetTileCoordinatePosByTileIndex(current_tile_idx);
  if (false==IsTileCoordinateInRange(tileCoordinatePos))
  {
    return false;
  }
  if (is_left_derection)
  {
    for (int x = tileCoordinatePos.x; x>=0 && range_width!=0; --x, --range_width)
    {
      tileIndexs.push_back(GetTileIndexByTileCoordinatePos(ccp(x, tileCoordinatePos.y)));
    }
    // not as long as enough, push the left tile on the row
    if (range_width!=0)
    {
      tileIndexs.push_back(GetTileIndexByTileCoordinatePos(ccp(-1, tileCoordinatePos.y)));
    }
  }
  else
  {
    for (int x = tileCoordinatePos.x; x<kMapColumnCount && range_width!=0; ++x, --range_width)
    {
      tileIndexs.push_back(GetTileIndexByTileCoordinatePos(ccp(x, tileCoordinatePos.y)));
    }
    // not as long as enough, push the right failed tile
    if (range_width!=0)
    {
      tileIndexs.push_back(kBorderRightFailedTileIndex);
    }
  }
  // only valid tile index in battle field can be keeped
  for (std::vector<int_8>::iterator it = tileIndexs.begin();
       it != tileIndexs.end(); )
  {
    cocos2d::CCPoint tilePos = GetTileCoordinatePosByTileIndex(*it);
    if (false==IsTileCoordinateInValidBattleRectangle(tilePos))
    {
      it = tileIndexs.erase(it);
    }
    else
    {
      ++it;
    }
  }
  return true;
}
/*
// get attackable tiles list for unit with body range >1
bool TiledMap::GetAttackableTilesListForHugeMoveObject(std::vector<int_8> &tileIndexs,
                                                       int_8 current_tile_idx,
                                                       int_8 height)
{
  tileIndexs.clear();
  cocos2d::CCPoint tileCoordinatePos = GetTileCoordinatePosByTileIndex(current_tile_idx);
  if (false==IsTileCoordinateInRange(tileCoordinatePos))
  {
    return false;
  }
  assert((tileCoordinatePos.y+1)>height);
  for (int h = tileCoordinatePos.y; h>=0 && height>0; --h, --height )
  {
    tileIndexs.push_back(GetTileIndexByTileCoordinatePos(ccp(tileCoordinatePos.x, h)));
  }
  if (height>0)
  {
    return false;
  }
  return true;
}
 */ 
bool TiledMap::AreTwoUnitInTheSameRow(cocos2d::CCPoint pos1,
                                      cocos2d::CCPoint pos2)
{
  cocos2d::CCPoint tilePos1 = GetTileCoordinatePosByCurrentPointPosition(pos1);
  cocos2d::CCPoint tilePos2 = GetTileCoordinatePosByCurrentPointPosition(pos2);
  return (tilePos1.y == tilePos2.y);
}
  
// input pos is unit's pixel position on battle field view
// the return pos is the fitable pixel position, too.
// witch can void units' overlap standing
cocos2d::CCPoint TiledMap::
  FindEmptyFitablePointPositionForMoveObjectFight(uint_32 unitId,
                                                  cocos2d::CCPoint unitPos)
{
  return ccp(unitPos.x, unitPos.y + kMapTileMaxHeight * random_lower_upper(0.1, 0.5));

  //better for understanding
  //if must use #-splitted tile, check beliw
  /*
  cocos2d::CCPoint coorPos = GetTileCoordinatePosByCurrentPointPosition(unitPos);
  int_8 tileIndex = GetTileIndexByTileCoordinatePos(coorPos);
  uint_32 flag = this->getGarrisonFlagForTileWithIndex(unitId, tileIndex);

  cocos2d::CCPoint cornerPoints[4] = {
    GetTopLeftPointPositionInTile(tileIndex),
    GetTopRightPointPositionInTile(tileIndex),
    GetBottomRightPointPositionInTile(tileIndex),
    GetBottomLeftPointPositionInTile(tileIndex)
  };
  float boxWidth = cornerPoints[2].x - cornerPoints[3].x;
  float boxHeight = cornerPoints[1].y - cornerPoints[2].y;
  float innerX = unitPos.x - cornerPoints[3].x;
  float innerY = unitPos.y - cornerPoints[3].y;
  int_8 innderIndex = (kTotalStandPointInOneTile/kMapRowCount)*
                       (kMapRowCount-ceilf(innerY*kMapRowCount/boxHeight)) +
                       ceilf(innerX*kMapRowCount/boxWidth);
//  CCLOG("GarrisonFlag: %lx for tile: %d with inner index %d", flag, tileIndex, innderIndex);
  
//   // tile grid is not a rectangle but a trapezoid, not in
//   if(innderIndex>kTotalStandPointInOneTile)
//   {
//     return unitPos;
//   }
//   // not at the coming line: not need to hash -- the pos is already setted randomly.
//   if(innderIndex<(kTotalStandPointInOneTile-kMapRowCount))
//   {
//     return unitPos;
//   }  
  
  // empty point, fitable position to fight
  if ((flag & (1<<innderIndex))==kTileStandFlagNone)
  {
    return unitPos;
  }
  
  bool canMoveDown = coorPos.y<kMapRowCount-1;
  bool canMoveUp = coorPos.y>0;
  // full point, need relocated -- check the follow 4 points: if all of these 3
  // points are garrisoned, take one point randomly between NO.1 and NO.2(#)
  /*
     --4----
       3       // if 2 has been garrisoned by other object, check this one
       1       // if # has been garrisoned by other object, check this one
     --#----   // # is the first standing point position of unit
       2       // if 1 has been garrisoned by other object, check this one
       5
     --6----
    --NO.1 & NO.3 points are in the same tile with NO.#, do not need check whether 
      it is in range or not; NO.2 are the points in different tile with NO.#.
      Check in available range is necessary.
  *//*
  // NO.1 inner index 
  if (canMoveUp && (flag & (1<<(innderIndex-kMapRowCount)))==kTileStandFlagNone)
  {
    return ccp(unitPos.x, unitPos.y + boxHeight/kMapRowCount);
  }
  // NO.2 inner index : tile available check
  if (canMoveDown)
  {
    int_8 downTileIndex = tileIndex+kMapColumnCount;
    uint_32 flagDown = this->getGarrisonFlagForTileWithIndex(unitId, downTileIndex);
    if ((flagDown & 1<<(innderIndex%kMapRowCount))==kTileStandFlagNone)
    {
      return ccp(unitPos.x, unitPos.y - boxHeight/kMapRowCount);
    }
  }
  // NO.3 inner index
  if (canMoveUp && (flag & (1<<(innderIndex-2*kMapRowCount)))==kTileStandFlagNone)
  {
    return ccp(unitPos.x, unitPos.y + boxHeight/kMapRowCount);
  }
  // all 3 point are garrisoned, set one point randomly between NO.1 and NO.2(#)
  if (canMoveDown)
  { // from NO.4 to NO.1, move down is available
    return ccp(unitPos.x,
               unitPos.y + boxHeight/kMapRowCount*random_lower_upper(-3, -1));
  }
  else
  { // from NO.2 to NO.6, move down is invalid
    assert(canMoveUp);
    return ccp(unitPos.x,
               unitPos.y + boxHeight/kMapRowCount*random_lower_upper(1, 3));
  }*/
}
  
cocos2d::CCPoint TiledMap::GetBornPositionForMoveObjectsByRowIndex(int rowIndex,
                                                                   bool isMonster /* = true */)
{
  assert(rowIndex>kMapTilesRowUnkown && rowIndex<kMapTilesRowMax);
  cocos2d::CCPoint coordinatePos = ccp(0, rowIndex);
  if (!isMonster)
  {
    coordinatePos = ccp(kMapColumnCount, rowIndex);
  }
  int_8 tileIdx = GetTileIndexByTileCoordinatePos(coordinatePos);
  cocos2d::CCPoint born_pos = GetGarrisonPointForMoveObjectInTile(tileIdx);
  if (isMonster)
  {
    born_pos.x -= iCC_DESIGN_SIZE.width/kMapRowCount;
  }
  else
  {
    born_pos.x += iCC_DESIGN_SIZE.width/kMapRowCount;
  }
  return born_pos;
}
  
// check the destination tile is empty or not
bool TiledMap::IsTileEmpty(int_8 tile_index)
{
  cocos2d::CCPoint tile_pos = GetTileCoordinatePosByTileIndex(tile_index);
  if (false == IsTileCoordinateInRange(tile_pos)) {
    return false;
  }
  uint_32 exist_card_id =
    tiles_[static_cast<int>(tile_pos.y)][static_cast<int>(tile_pos.x)].garrison_character_id_;
  return (exist_card_id==kUnexistGrassionCardId);
}

// check the destination tile can garrison or not
bool TiledMap::IsTileCanGarrisonCharacter(uint_32 chac_id,
                                          int_8   tile_index)
{
//SnowCold
/*
  int tile_tmp = tile_index % kMapColumnCount;
  if ( tile_tmp < 3 || tile_index>=kMapTilesCount)
  {
    return false;
  }  
*/
  cocos2d::CCPoint tile_pos = GetTileCoordinatePosByTileIndex(tile_index);
  if (IsTileCoordinateInRange(tile_pos))
  {
    std::list<army::MoveObject*> existMoveObjList;
    battle::BattleController::GetInstance().own_hub()-> \
      GetAllMoveObjectsInTileWithIndex(tile_index, existMoveObjList);
    for (std::list<army::MoveObject*>::iterator it = existMoveObjList.begin();
         it != existMoveObjList.end(); )
    {
      // remove all ungarrison Characters
		army::Character* character = dynamic_cast<army::Character*>(*it);
      if ( character && character->garrison_tile_index() != tile_index)
      {
        it = existMoveObjList.erase(it);
      }
      else
      {
        ++it;
      }
    }
    // empty means can garrison on this tile
    if (existMoveObjList.size()==0)
    {
      return true;
    }
    // only checked character with move_object_id == chac_id it self in this tile
    // means can garrison on this tile too
    else if (existMoveObjList.size()==1)
    {
      uint_32 exist_obj_id = existMoveObjList.front()->move_object_id();
      assert(exist_obj_id!=kUnexistGrassionCardId);
      return (exist_obj_id==chac_id);
    }
    // this tile has been garrisoned yet & the garrisoned character is still in this tile
    else 
    {
      return false;
    }
  }
  return false;
}
  
// exchange two characters' garrison tiles
bool TiledMap::ExchangeGarrisonTileBetweenTwoCharacter(uint_32 chac_id1,
                                                      uint_32 chac_id2)
{
  int_8 tile_idx1 = kUnexistTileIndex, tile_idx2 = kUnexistTileIndex;
  for (int i = 0; i<kMapRowCount; ++i)
  {
    for (int j = 0; j<kMapColumnCount; ++j)
    {
      if (tiles_[i][j].garrison_character_id_ == chac_id1 && tile_idx1 == kUnexistTileIndex)
      {
        tile_idx1 = GetTileIndexByTileCoordinatePos(ccp(i, j));
      }
      else if(tiles_[i][j].garrison_character_id_ == chac_id2 && tile_idx2 == kUnexistTileIndex)
      {
        tile_idx2 = GetTileIndexByTileCoordinatePos(ccp(i, j));
      }
    }
  }
  if (tile_idx1 == kUnexistTileIndex || tile_idx2 == kUnexistTileIndex) {
    return false;
  }
  else {
    uint_32 temp_id = chac_id1;
    tiles_[static_cast<int>(tile_idx1/kMapColumnCount)]
          [tile_idx1%kMapColumnCount].garrison_character_id_ = chac_id2;
    tiles_[static_cast<int>(tile_idx2/kMapColumnCount)]
          [tile_idx2%kMapColumnCount].garrison_character_id_ = temp_id;
    return true;
  }
}
  
// dispach one character garrison tile with index
bool TiledMap::DispatchCharacterGarrisonTile(uint_32 chac_id,
                                             int_8   tile_index)
{
  if (false == this->IsTileCanGarrisonCharacter(chac_id, tile_index)) {
    return false;
  }
  tiles_[static_cast<int>(tile_index/kMapColumnCount)]
        [tile_index%kMapColumnCount].garrison_character_id_ = chac_id;
  return true;
}
  
// dispach one character garrison one empty tile nearby tile with index
void TiledMap::DispatchCharacterGarrisonNearbyTile(uint_32 chac_id,
                                                   int_8   tile_index)
{
  int_8 emptyTileIdx = this->GetOneClosetEmptyTileNearby(tile_index);
  BattleController::GetInstance().
    DispatchOneCharacterToGarrisonTargetTile(chac_id, emptyTileIdx);
}
  
  // move character out the tile with index
bool TiledMap::MoveCharacterOutOfGarrisonTile(uint_32 chac_id,
                                              int_8   tile_index)
{
  int row = static_cast<int>(tile_index/kMapColumnCount);
  int column = tile_index%kMapColumnCount;
  if (tiles_[row][column].garrison_character_id_ != chac_id) {
    return false;
  }
  tiles_[row][column].garrison_character_id_ = kUnexistGrassionCardId;
  return true;
}
  
// choose one closet tile near the destination tile
int_8 TiledMap::GetOneClosetEmptyTileNearby(int_8 tile_index)
{
  cocos2d::CCPoint tile_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int_8 x = static_cast<int_8>(tile_pos.x);
  int_8 y = static_cast<int_8>(tile_pos.y);
  int_8 nearby_tile = kUnexistTileIndex;
  float min_dis = 1000.0f;
  for (int i = 0.5f*battle::kMapColumnCount; i<battle::kMapColumnCount; ++i)
  {
    for (int j = 0; j<battle::kMapRowCount; ++j) {
      float distance = (y-j)*(y-j)*0.9f + (x-i)*(x-i);
      int_8 tile_idx = GetTileIndexByTileCoordinatePos(cocos2d::CCPoint(i,j));
      if (distance<min_dis && this->IsTileEmpty(tile_idx)) {
        min_dis = distance;
        nearby_tile = tile_idx;
      }
    }
  }
  return nearby_tile;
}
  
uint_32 TiledMap::getGarrisonFlagForTileWithIndex(uint_32 unit_id, int_8 tile_index)
{
  uint_32 flag = kTileStandFlagNone;
  cocos2d::CCPoint cornerPoints[4] = {
    GetTopLeftPointPositionInTile(tile_index),
    GetTopRightPointPositionInTile(tile_index),
    GetBottomRightPointPositionInTile(tile_index),
    GetBottomLeftPointPositionInTile(tile_index)
  };
  float boxWidth = cornerPoints[2].x - cornerPoints[3].x;
  float boxHeight = cornerPoints[1].y - cornerPoints[2].y;
  
  std::list<army::MoveObject *> characList;
  std::list<army::MoveObject *> monsterList;
  battle::BattleController::GetInstance().own_hub()->
    GetAllMoveObjectsInTileWithIndex(tile_index, characList);
  battle::BattleController::GetInstance().monster_hub()->
    GetAllMoveObjectsInTileWithIndex(tile_index, monsterList);
  for (std::list<army::MoveObject *>::iterator it = characList.begin();
       it != characList.end(); ++it)
  {
    cocos2d::CCPoint pos = (*it)->current_pos();
    // ignore checked unit itself
    if ((*it)->move_object_id() == unit_id ||
        GetTileIndexByCurrentPointPosition(pos)!=tile_index)
    {
      continue;
    }
    float x = pos.x - cornerPoints[3].x;
    float y = pos.y - cornerPoints[3].y;
    int_8 index = (kTotalStandPointInOneTile/kMapRowCount)*
                   (kMapRowCount-ceilf(y*kMapRowCount/boxHeight)) +
                   ceilf(x*kMapRowCount/boxWidth);
    if(index>kTotalStandPointInOneTile)
    {
      continue;
    }
    flag = flag | (1<<index);
  }
  for (std::list<army::MoveObject *>::iterator it = monsterList.begin();
       it != monsterList.end(); ++it)
  {
    // ignore checked unit itself
    if ((*it)->move_object_id() == unit_id ||
        GetTileIndexByCurrentPointPosition((*it)->current_pos())!=tile_index)
    {
      continue;
    }
    cocos2d::CCPoint pos = (*it)->current_pos();
    float x = pos.x - cornerPoints[3].x;
    float y = pos.y - cornerPoints[3].y;
    int_8 index = (kTotalStandPointInOneTile/kMapRowCount)*
                   (kMapRowCount-ceilf(y*kMapRowCount/boxHeight)) +
                   ceilf(x*kMapRowCount/boxWidth);
    if(index>kTotalStandPointInOneTile)
    {
      continue;
    }
    flag = flag | (1<<index);
  }
  return flag;
}
  
bool TiledMap::IsAnyMoveObjectInOwnTileTooNearBy(uint_32 unit_id, int_8 tile_index)
{  
  float nearestDis = (kMapTileAverageLength/kMapRowCount)*0.5f;
  nearestDis = nearestDis*nearestDis;

  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(unit_id);
  if ( !unit )
  {
	  return false;
  }

  cocos2d::CCPoint pos = unit->current_pos();

  std::list<army::MoveObject *> characList;
  std::list<army::MoveObject *> monsterList;
  battle::BattleController::GetInstance().own_hub()->
    GetAllMoveObjectsInTileWithIndex(tile_index, characList);
  battle::BattleController::GetInstance().monster_hub()->
    GetAllMoveObjectsInTileWithIndex(tile_index, monsterList);
  for (std::list<army::MoveObject *>::iterator it = characList.begin();
       it != characList.end(); ++it)
  {
    // ignore checked unit itself or maximum ids
    if ((*it)->move_object_id() >= unit_id)
    {
      continue;
    }
    cocos2d::CCPoint neiborPos = (*it)->current_pos();
    if (ccpDistanceSQ(pos, neiborPos)<nearestDis)
    {
      return true;
    }
  }
  for (std::list<army::MoveObject *>::iterator it = monsterList.begin();
       it != monsterList.end(); ++it)
  {
    // ignore checked unit itself
    if ((*it)->move_object_id() >= unit_id)
    {
      continue;
    }
    cocos2d::CCPoint neiborPos = (*it)->current_pos();
    if (ccpDistanceSQ(pos, neiborPos)<nearestDis)
    {
      return true;
    }
  }
  return false;
}
  
} // battle
} // taomee