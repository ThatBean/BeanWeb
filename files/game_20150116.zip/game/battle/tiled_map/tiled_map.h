//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-17
//          Time:  2:22
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-17        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_tiled_map_h
#define ChainChronicle_tiled_map_h

#include "engine/base/basictypes.h"
#include "game/battle/tiled_map/map_constants.h"

namespace cocos2d {
  class CCPoint;
}

namespace taomee {
namespace battle {
  
class TiledMap
{
public:
  TiledMap();
  virtual ~TiledMap() {}
  
public: // move object's pos on map
  // get grids range by self tile index & range grids count
  bool GetRangeQuadrangleFourVertexPointInAnticlockwise(std::vector<cocos2d::CCPoint> &vertexs,
                                                        int_8 current_tile_idx,
                                                        int_8 range_width,
                                                        bool   is_left_derection = true);
  // get tiles index by itself's location tile index & range grids info
  bool GetRangeQuadrangleTilesList(std::vector<int_8> &tileIndexs,
                                   int_8 current_tile_idx,
                                   int_8 range_width,
                                   bool   is_left_derection = true);
  /*
  // get attackable tiles list for unit with body range >1
  bool GetAttackableTilesListForHugeMoveObject(std::vector<int_8> &tileIndexs,
                                               int_8 current_tile_idx,
                                               int_8 height);*/
  
  // the two input pos are screen pixel position
  bool AreTwoUnitInTheSameRow(cocos2d::CCPoint pos1,
                              cocos2d::CCPoint pos2);
  
  // input pos is unit's pixel position on battle field view
  // the return pos is the fitable pixel position, too.
  // witch can void units' overlap standing
  cocos2d::CCPoint FindEmptyFitablePointPositionForMoveObjectFight(uint_32 unitId,
                                                                   cocos2d::CCPoint unitPos);
  
  // get born pos by row index for move objects
  cocos2d::CCPoint GetBornPositionForMoveObjectsByRowIndex(int rowIndex,
                                                           bool isMonster = true);

public: // Garrison tile operations
  // check the destination tile is empty or not
  bool IsTileEmpty(int_8  tile_index);
  // check the destination tile can garrison or not
  bool IsTileCanGarrisonCharacter(uint_32 chac_id,
                                  int_8   tile_index);
  // exchange two characters' garrison tiles
  bool ExchangeGarrisonTileBetweenTwoCharacter(uint_32 chac_id1,
                                               uint_32 chac_id2);
  // dispach one character garrison tile with index
  bool DispatchCharacterGarrisonTile(uint_32 chac_id,
                                     int_8   tile_index);
  // dispach one character garrison one empty tile nearby tile with index
  void DispatchCharacterGarrisonNearbyTile(uint_32 chac_id,
                                           int_8   tile_index);
  // move character out the tile with index
  bool MoveCharacterOutOfGarrisonTile(uint_32 chac_id,
                                      int_8   tile_index);
  // choose one closet tile near the destination tile
  int_8 GetOneClosetEmptyTileNearby(int_8 tile_index);
  
  bool IsAnyMoveObjectInOwnTileTooNearBy(uint_32 unit_id, int_8 tile_index);
 
private:
  uint_32 getGarrisonFlagForTileWithIndex(uint_32 unit_id, int_8 tile_index);
    
private:
  struct Tile
  {
    int_8    tile_index_;
    uint_32  garrison_character_id_;
  };
  
private:
  Tile       tiles_[kMapRowCount][kMapColumnCount];
};
  
} // battle
} // taomee


#endif // ChainChronicle_tiled_map_h
