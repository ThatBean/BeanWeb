//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  map_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-17
//          Time:  2:52
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-17        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_map_constants_h
#define ChainChronicle_map_constants_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace battle {

// design size in battle map & tile calculation
#define iCC_DESIGN_SIZE  (cocos2d::CCSize(1136, 640))
 
// invalid flag : card id / tile index / tile coordinate
enum
{
  kUnexistGrassionCardId   = -1,
  kUnexistTileIndex        = -1,
  kUnexistTileCoordinate   = -1,
};
// invalid flaf for coordiante pos 
const cocos2d::CCPoint kUnexistCoordinatePoint =
  cocos2d::CCPoint(kUnexistTileCoordinate, kUnexistTileCoordinate);
  
// row index constants
enum
{
  kMapTilesRowUnkown       = -1,
  kMapTilesRowTop          = 0,
  kMapTilesRowCenter       = 1,
  kMapTilesRowBottom       = 2,
  kMapTilesRowMax,
};
  
/* (3*6)
   Y : is in range[0,3]
   * * * * * *   
   * * * * * * 
   * * * * * * X  : X is in range[0,5]
   that means x is using kMapColumnCount, but y using kMapRowCount
*/
const uint_8  kMapRowCount              = 3;
const uint_8  kMapColumnCount           = 6;
const uint_8  kMapTilesCount            = kMapRowCount*kMapColumnCount;

// nborder tiles : 3 on left border & 1 on right 
enum eBorderTilesIndex
{
  kBorderRightFailedTileIndex                 = kMapTilesCount, // 18
  kBorderLeftTopTileIndex, // 19
  kBorderLeftCenterTileIndex, // 20
  kBorderLeftBottomTileIndex, // 21
  kMapTilesIndexMax,
};  
const cocos2d::CCPoint kBorderRightFailedTileCoordinate = ccp(kMapColumnCount, 0);
const cocos2d::CCPoint kBorderLeftTopTileCoordinate = ccp(kUnexistTileCoordinate, 0);
const cocos2d::CCPoint kBorderLeftCenterTileCoordinate = ccp(kUnexistTileCoordinate, 1);
const cocos2d::CCPoint kBorderLeftBottomTileCoordinate = ccp(kUnexistTileCoordinate, 2);
  
// current standing move object in fight state should mark in its stand tile
/*
  1<<1 2<<1 3<<1  : 1/3 part of tile & its number
  4<<1 5<<1 6<<1  : 1/3 part of tile & its number
  7<<1 8<<1 9<<1  : 1/3 part of tile & its number
 */
const uint_8 kTotalStandPointInOneTile = 9;
enum eTileStandFlag
{
  kTileStandFlagNone        = 0,
  kTileStandFlagTopLeft     = 1<<1,
  kTileStandFlagTopCenter   = 1<<2,
  kTileStandFlagTopright    = 1<<3,
  kTileStandFlagMiddleLeft  = 1<<4,
  kTileStandFlagMiddleCenter= 1<<5,
  kTileStandFlagMiddleRight = 1<<6,
  kTileStandFlagBottomLeft  = 1<<7,
  kTileStandFlagBottomCenter= 1<<8,
  kTileStandFlagBottomRight = 1<<9,
  kTileStandFlagFull        = 0x03FE,
};

// constants for calculation of tiles' coordinate pos & move objects' scale
const uint_8  kIncreasePixels           = 4;
const uint_8  kHeightDownOffset         = 10;  
const float   kHieghtWidthRatio         = 0.375f;
const float   KWidthScreenWidthRatio    = 0.87f;  
const float   kMapTileAverageLength     = (iCC_DESIGN_SIZE.width*KWidthScreenWidthRatio -
                                           0.5f*kIncreasePixels*kMapTilesCount) / kMapColumnCount;
const float   kMapTileMinLength         = kMapTileAverageLength-kIncreasePixels;
const float   kMapTileMaxLength         = kMapTileAverageLength+kIncreasePixels;
const float   kMapTileAverageHeight     = iCC_DESIGN_SIZE.width*battle::KWidthScreenWidthRatio*
                                          battle::kHieghtWidthRatio / kMapRowCount;
const float   kMapTileMinHeight         = kMapTileAverageHeight-kIncreasePixels;
const float   kMapTileMaxHeight         = kMapTileAverageHeight+kIncreasePixels;
  
const float   kScaleFactor              = 0.9f;
const uint_8  kDefaultHealerTileIndex   = 10;
const uint_8  kDefaultMonsterHealerTileIndex = 7;
  
const uint_8  kCharacterStandOffetHeight = 15;
  
const uint_8  kSelectedBorderOffsetHight = 20;
  
// getter func for grid pos on battle field
const cocos2d::CCPoint& grid_position_x_y(int_8 x, int_8 y);
  
const cocos2d::CCPoint BorderTilesCoordinatePosbyTileIndex(int_8 index);
int_8 BorderTilesIndexByTilesCoordinatePos(const cocos2d::CCPoint& pos);
  
void CalculateGridPositionForBattleFieldOnlyOnceInTileMapConstructor();

const float   kMapRightMostX    = 1200;

} // namespace battle
} // namespace taomee

#endif // ChainChronicle_map_constants_h
