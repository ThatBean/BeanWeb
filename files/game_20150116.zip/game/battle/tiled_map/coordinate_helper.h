//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  coordinate_helper.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-21
//          Time:  5:28
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-22        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_coordinate_helper_h
#define ChainChronicle_coordinate_helper_h

#include "engine/base/basictypes.h"

namespace cocos2d {
class CCPoint;
}

namespace taomee {
namespace battle {

// for new player's guide special -- change index in lua script into map tile index
int_8 GetTileIndexByLuaIndex(int_8 lua_idx);
  
// zorder & scale zoom factor for move object by pos on battle map
int GetZorderByPosition(cocos2d::CCPoint pos, uint_32 objId = 0);
float GetScaleByPosition(cocos2d::CCPoint pos);
// angle calculate
float RadiansBetweenPoint(const cocos2d::CCPoint& begin_pos,
                          const cocos2d::CCPoint& end_pos);
  
// tile pos' check mothed
bool IsTileCoordinateInRange(const cocos2d::CCPoint& coordinate_pos);
bool IsTileCoordinateInValidBattleRectangle(const cocos2d::CCPoint& coordinate_pos);
bool IsTileIndexInRightPart(int_8 index);
bool IsTileCoordinateInRightPart(const cocos2d::CCPoint& coordinate_pos);
  
// get five tile point pos by tile index
cocos2d::CCPoint GetTopRightPointPositionInTile(int_8 tile_index);
cocos2d::CCPoint GetTopLeftPointPositionInTile(int_8 tile_index);
cocos2d::CCPoint GetBottomRightPointPositionInTile(int_8 tile_index);
cocos2d::CCPoint GetBottomLeftPointPositionInTile(int_8 tile_index);
cocos2d::CCPoint GetCenterPointPositionInTile(int_8 tile_index);
  
// get tile index by move direction & tiles count
int_8 GetDestinationTileIndexByDirectionAndMoveDistance(int_8 sourceTileIdx,
                                                        uint_8 tilesDis,
                                                        bool isRightForward = true );
  
// get Garrison point pos by tile index for move object(both characters & monsters)
cocos2d::CCPoint GetGarrisonPointForMoveObjectInTile(int_8 tile_index);
  
// exchange among tile index, tile coordiante pos & point pos
cocos2d::CCPoint GetPointPositionByGridPointCoordinate(int_8 x, int_8 y);
cocos2d::CCPoint GetPointPositionByGridCoordinatePos(const cocos2d::CCPoint& coordinate_pos);
cocos2d::CCPoint GetPointPositionByGridTileIndex(int_8 index);
int_8 GetTileIndexByCurrentPointPosition(const cocos2d::CCPoint& pos);
int_8 GetTileIndexByTileCoordinatePos(const cocos2d::CCPoint& coordinate_pos);
cocos2d::CCPoint GetTileCoordinatePosByCurrentPointPosition(const cocos2d::CCPoint& pos);
cocos2d::CCPoint GetTileCoordinatePosByTileIndex(int_8 index);
   
// get all tiles' index list in one row
void GetAllTilesIndexListInRow(int_8 rowIndex, std::vector<int_8>& list);

float  GetMinYInTile();
float  GetMaxYInTile();
} // namespace battle
} // namespace taomee


#endif // ChainChronicle_coordinate_helper_h
