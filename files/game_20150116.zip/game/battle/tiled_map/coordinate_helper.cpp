//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  coordinate_helper.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-21
//          Time:  5:28
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-22        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/tiled_map/coordinate_helper.h"

#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/tiled_map/map_constants.h"

namespace taomee {
namespace battle {
  
int_8 GetTileIndexByLuaIndex(int_8 lua_idx)
{
  assert(lua_idx>=0 && lua_idx<(battle::kMapColumnCount/2)*(battle::kMapColumnCount/2));
  return (lua_idx%(battle::kMapColumnCount/2)+(battle::kMapColumnCount/2) +
          lua_idx/(battle::kMapColumnCount/2)*battle::kMapColumnCount);
}
  
int GetZorderByPosition(cocos2d::CCPoint pos, uint_32 objId /* = 0 */ )
{
  int height = (iCC_DESIGN_SIZE.height - static_cast<int>(pos.y));
  assert(height>=0&&height<1024);
  height = (height<<8) | objId;
  return height;
}

float GetScaleByPosition(cocos2d::CCPoint pos)
{
  float width_long = iCC_DESIGN_SIZE.width*battle::KWidthScreenWidthRatio;
  float height_low = width_long*battle::kHieghtWidthRatio;
  height_low = (iCC_DESIGN_SIZE.height - height_low)*0.5f - battle::kHeightDownOffset;
  float height_top = height_low+width_long*battle::kHieghtWidthRatio;
  float height = pos.y;
  if (height<height_low)
  {
    return 1.0f*0.8f;
  }
  else if(height>height_top)
  {
    return battle::kScaleFactor*0.8f;
  }
  else
  {
    return (battle::kScaleFactor + (1.0f-battle::kScaleFactor)*(height_top-height)/(height_top-height_low))*0.8f;
  }
}
  
float RadiansBetweenPoint(const cocos2d::CCPoint& begin_pos,
                          const cocos2d::CCPoint& end_pos)
{
  float delta_x = end_pos.x - begin_pos.x;
  float delta_y = end_pos.y - begin_pos.y;
  if(delta_x == 0)
  {
    if (delta_y<=0) {
      return M_PI*1.5f;
    }
    else {
      return M_PI*0.5f;
    }
  }
  else
  {
    float radians = atanf(delta_y / delta_x);
    if (delta_y>0) {
      if (delta_x>0) {  // 1
        return radians;
      }
      else {  //  2
        return M_PI+radians;
      }
    }
    else {
      if (delta_x>0) { //  4
        return 2*M_PI+radians;
      }
      else {  // 3
        return M_PI+radians;
      }
    }
  }
}
  
bool IsTileCoordinateInRange(const cocos2d::CCPoint& coordinate_pos)
{
  if (coordinate_pos.x>=0 && coordinate_pos.x<kMapColumnCount &&
      coordinate_pos.y>=0 && coordinate_pos.y<kMapRowCount)
  {
    return true;
  }
  if (coordinate_pos.x==kUnexistTileCoordinate &&
      coordinate_pos.y>=0 &&
      coordinate_pos.y<kMapRowCount)
  {
    return true;
  }
  if (coordinate_pos.x==kMapColumnCount && coordinate_pos.y==0)
  {
    return true;
  }
  return false;
}
  
bool IsTileCoordinateInValidBattleRectangle(const cocos2d::CCPoint& coordinate_pos)
{
  int_8 tileIndex = GetTileIndexByTileCoordinatePos(coordinate_pos);
  return (tileIndex>=0 && tileIndex<kMapTilesCount);
}

bool IsTileIndexInRightPart(int_8 index)
{
  return (index!=kBorderRightFailedTileIndex &&
          IsTileCoordinateInRightPart(GetTileCoordinatePosByTileIndex(index)));
}

bool IsTileCoordinateInRightPart(const cocos2d::CCPoint& coordinate_pos)
{
  return (2*coordinate_pos.x>=battle::kMapColumnCount && coordinate_pos.y!=kUnexistTileCoordinate);
}
  
// get tile point pos with tile index
cocos2d::CCPoint GetTopRightPointPositionInTile(int_8 tile_index)
{
  assert(tile_index<kMapTilesIndexMax);
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int x = static_cast<int>(coordinate_pos.x);
  int y = static_cast<int>(coordinate_pos.y);
  if (x == kUnexistTileCoordinate && y == kUnexistTileCoordinate)
  {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  if (x==kMapColumnCount && y==0) // kBorderRightFailedTileIndex
  {
    return ccp(grid_position_x_y(y,x).x+kMapTileAverageLength,
               grid_position_x_y(y,x).y);
  }
  return grid_position_x_y(y,x+1);
}
  
cocos2d::CCPoint GetTopLeftPointPositionInTile(int_8 tile_index)
{
  assert(tile_index<kMapTilesIndexMax);
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int x = static_cast<int>(coordinate_pos.x);
  int y = static_cast<int>(coordinate_pos.y);
  if (x == kUnexistTileCoordinate && y == kUnexistTileCoordinate)
  {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  else if (x == kUnexistTileCoordinate) // kBorderLeft tiles
  {
    return ccp(grid_position_x_y(y,x+1).x-kMapTileAverageLength,
               grid_position_x_y(y,x+1).y);
  }
  else
  {
    return grid_position_x_y(y,x);
  }
}

cocos2d::CCPoint GetBottomRightPointPositionInTile(int_8 tile_index)
{
  assert(tile_index<kMapTilesIndexMax);
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int x = static_cast<int>(coordinate_pos.x);
  int y = static_cast<int>(coordinate_pos.y);
  if (x == kUnexistTileCoordinate && y == kUnexistTileCoordinate)
  {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  if (x==kMapColumnCount && y==0) // kBorderRightFailedTileIndex
  {
    return ccp(grid_position_x_y(y+1,x).x+kMapTileAverageLength,
               grid_position_x_y(y+1,x).y);
  }
  return grid_position_x_y(y+1,x+1);
}

cocos2d::CCPoint GetBottomLeftPointPositionInTile(int_8 tile_index)
{
  assert(tile_index<kMapTilesIndexMax);
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int x = static_cast<int>(coordinate_pos.x);
  int y = static_cast<int>(coordinate_pos.y);
  if (x == kUnexistTileCoordinate && y == kUnexistTileCoordinate) {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  else if (x == kUnexistTileCoordinate) // kBorderLeft tiles
  {
    return ccp(grid_position_x_y(y+1,x-1).x-kMapTileAverageLength,
               grid_position_x_y(y+1,x-1).y);
  }
  else
  {
    return grid_position_x_y(y+1,x);
  }
}

cocos2d::CCPoint GetCenterPointPositionInTile(int_8 tile_index)
{
  assert(tile_index<kMapTilesIndexMax);
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int x = static_cast<int>(coordinate_pos.x);
  int y = static_cast<int>(coordinate_pos.y);
  if (x == kUnexistTileCoordinate && y == kUnexistTileCoordinate) {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  cocos2d::CCSize display_size = iCC_DESIGN_SIZE;
  float width_long = display_size.width*KWidthScreenWidthRatio;
  float height = width_long*kHieghtWidthRatio;
  float width_short = width_long - kIncreasePixels*kMapTilesCount;
  float unit_height = (height-0.5f*(kMapRowCount-1)*(kMapRowCount-2)*kIncreasePixels)/kMapRowCount;
  float unit_width = width_short/kMapColumnCount;
  unit_width += x*kIncreasePixels;
  unit_height += x*kIncreasePixels;
  if (x == kUnexistTileCoordinate) // kBorderLeft tiles
  {
    return ccp(grid_position_x_y(y,x+1).x-0.5f*unit_width,
               grid_position_x_y(y+1,x+1).y+0.5f*unit_height);
  }
  else if (x == kMapTilesCount) // kBorderRightFailedTileIndex
  {
    return ccp(grid_position_x_y(kMapRowCount*0.5f,x-1).x+0.5f*unit_width,
               grid_position_x_y(kMapRowCount*0.5f+1,x-1).y+0.5f*unit_height);
  }
  else
  {
    return ccp(grid_position_x_y(y,x).x+0.5f*unit_width,
               grid_position_x_y(y+1,x).y+0.5f*unit_height);
  }
}
  
// get tile index by move direction & tiles count
int_8 GetDestinationTileIndexByDirectionAndMoveDistance(int_8 sourceTileIdx,
                                                        uint_8 tilesDis,
                                                        bool isRightForward /* = true */)
{
  assert(tilesDis<kMapColumnCount);
  cocos2d::CCPoint tileCoordinatePos = GetTileCoordinatePosByTileIndex(sourceTileIdx);
  if (isRightForward)
  {
    if (tileCoordinatePos.x+tilesDis>kMapColumnCount)
    {
      return GetTileIndexByTileCoordinatePos(ccp(kMapColumnCount, tileCoordinatePos.y));
    }
    return GetTileIndexByTileCoordinatePos(ccp(tileCoordinatePos.x+tilesDis,
                                               tileCoordinatePos.y));
  }
  else
  {
    if (tileCoordinatePos.x-tilesDis<kUnexistTileCoordinate)
    {
      return GetTileIndexByTileCoordinatePos(ccp(kUnexistTileCoordinate,
                                                 tileCoordinatePos.y));
    }
    return GetTileIndexByTileCoordinatePos(ccp(tileCoordinatePos.x-tilesDis,
                                               tileCoordinatePos.y));
  }
}

cocos2d::CCPoint GetGarrisonPointForMoveObjectInTile(int_8 tile_index)
{
  assert(tile_index<kMapTilesIndexMax);
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(tile_index);
  int x = static_cast<int>(coordinate_pos.x);
  int y = static_cast<int>(coordinate_pos.y);
  if (x == kUnexistTileCoordinate && y == kUnexistTileCoordinate) {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  cocos2d::CCSize display_size = iCC_DESIGN_SIZE;
  float width_long = display_size.width*KWidthScreenWidthRatio;
  float width_short = width_long - kIncreasePixels*kMapTilesCount;
  float unit_width = width_short/kMapColumnCount;
  unit_width += x*kIncreasePixels;
  return ccp(grid_position_x_y(y,x).x+0.5f*unit_width,
             grid_position_x_y(y+1,x).y+kCharacterStandOffetHeight);
}

cocos2d::CCPoint GetPointPositionByGridPointCoordinate(int_8 x, int_8 y)
{
  assert(x>=0 && x<kMapRowCount+1);
  assert(y>=0 && y<kMapColumnCount+1);
  return grid_position_x_y(x,y);
}
  
cocos2d::CCPoint GetPointPositionByGridCoordinatePos(
                                        const cocos2d::CCPoint& coordinate_pos)
{
  return GetPointPositionByGridPointCoordinate(coordinate_pos.x,
                                               coordinate_pos.y);
}
  
cocos2d::CCPoint GetPointPositionByGridTileIndex(int_8 index)
{
  cocos2d::CCPoint coordinate_pos = GetTileCoordinatePosByTileIndex(index);
  return GetPointPositionByGridCoordinatePos(ccp(coordinate_pos.y, coordinate_pos.x));
}

// get tile index by position
int_8 GetTileIndexByCurrentPointPosition(const cocos2d::CCPoint& pos)
{
  cocos2d::CCPoint tile_pos = GetTileCoordinatePosByCurrentPointPosition(pos);
  if (IsTileCoordinateInRange(tile_pos))
  {
    return GetTileIndexByTileCoordinatePos(tile_pos);
  }
  else
  {
    return kUnexistTileIndex;
  }
}

// TO DO : this method need improved
cocos2d::CCPoint GetTileCoordinatePosByCurrentPointPosition(const cocos2d::CCPoint& pos)
{
  for (int i = 0; i<kMapRowCount; ++i)
  {
    for (int j = 0; j<kMapColumnCount; ++j)
    {
      if (pos.x>=grid_position_x_y(i+1,j).x &&
          pos.y<=grid_position_x_y(i,j).y &&
          pos.x<=grid_position_x_y(i+1,j+1).x &&
          pos.y>=grid_position_x_y(i+1,j+1).y)
      {
        return ccp(j, i);
      }
    }
  }
  if (pos.x<=grid_position_x_y(1,0).x &&
      pos.y>=grid_position_x_y(1,0).y &&
      pos.y<grid_position_x_y(0,0).y) // kBorderLeft tiles
  {
    return kBorderLeftTopTileCoordinate;
  }
  else if (pos.x<=grid_position_x_y(2,0).x &&
           pos.y>=grid_position_x_y(2,0).y &&
           pos.y<grid_position_x_y(1,0).y)
  {
    return kBorderLeftCenterTileCoordinate;
  }
  else if (pos.x<=grid_position_x_y(3,0).x &&
           pos.y>=grid_position_x_y(3,0).y &&
           pos.y<grid_position_x_y(2,0).y)
  {
    return kBorderLeftBottomTileCoordinate;
  }
  else if (pos.x>grid_position_x_y(kMapColumnCount,0).x &&
           pos.y<grid_position_x_y(0,0).y &&
           pos.y>=grid_position_x_y(3,0).y) // kBorderRightFailedTile
  {
    return kBorderRightFailedTileCoordinate;
  }
  return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
}

cocos2d::CCPoint GetTileCoordinatePosByTileIndex(int_8 index)
{
  if (index<0 || index>=kMapTilesIndexMax)
  {
    return ccp(kUnexistTileCoordinate, kUnexistTileCoordinate);
  }
  if (index<kMapTilesCount)
  {
    return ccp(index%kMapColumnCount,
               static_cast<int>(index/kMapColumnCount));
  }
  else
  {
    return BorderTilesCoordinatePosbyTileIndex(index);
  }
}

int_8 GetTileIndexByTileCoordinatePos(const cocos2d::CCPoint& coordinate_pos)
{
  if (coordinate_pos.x>=0 && coordinate_pos.x<kMapColumnCount &&
      coordinate_pos.y>=0 && coordinate_pos.y<kMapRowCount)
  {
    return static_cast<int>(coordinate_pos.y)*kMapColumnCount +
           static_cast<int>(coordinate_pos.x);
  }
  if (static_cast<int_8>(coordinate_pos.x) == kUnexistTileCoordinate &&
      coordinate_pos.y<kMapRowCount)
  { // kBorderLeftTiles
    return kBorderLeftTopTileIndex+coordinate_pos.y;
  }
  if (coordinate_pos.x==kMapColumnCount && coordinate_pos.y==0)
  { // kBorderRightFailedTile
    return kBorderRightFailedTileIndex;
  }
  else
  {
    assert(false);
    return kUnexistTileIndex;
  }
}
  
void GetAllTilesIndexListInRow(int_8 rowIndex, std::vector<int_8>& list)
{
  assert(rowIndex>=0 && rowIndex<kMapRowCount);
  list.clear();
  list.push_back(kBorderLeftTopTileIndex+rowIndex);
  for (int i =0; i<kMapColumnCount; ++i)
  {
    list.push_back(rowIndex*kMapColumnCount +i);
  }
}

static float MinYofTile = -1.0f;
static float MaxYofTile = -1.0f;

float GetMinYInTile()
{
  if(MinYofTile < 0.0f)
    MinYofTile = GetBottomLeftPointPositionInTile(12).y;
  return MinYofTile;
}

float GetMaxYInTile()
{
  if(MaxYofTile < 0.0f)
    MaxYofTile = GetTopRightPointPositionInTile(0).y;
  return MaxYofTile;
}


} // namespace battle
} // namespace taomee