//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_resouce_loader.cpp
//        Author: coldouyang
//          Date: 2014/10/23 15:21
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/23      add
//////////////////////////////////////////////////////////////

#include "game/battle/battle_resource_loader.h"

#include "game/army/unit/move_object.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_data_table.h"
#include "game/data_table/aura_data_table.h"
#include "engine/animation/projectile_animation_cache_manager.h"
#include "engine/animation/animation_constant.h"
#include "engine/base/utils_string.h"

BattleResourceLoader* BattleResourceLoader::INSTANCE_ = NULL;
BattleResourceLoader::BattleResourceLoader()
{

}

BattleResourceLoader::~BattleResourceLoader()
{

}

BattleResourceLoader* BattleResourceLoader::GetInstance()
{
  if (!INSTANCE_)
  {
      INSTANCE_ = new BattleResourceLoader();
  }
  return INSTANCE_;
}

bool BattleResourceLoader::add_break_resource_by_break_id(int break_id)
{

  SkillBrkDataTable *skill_brk_table = DataManager::GetInstance().GetSkillBrkTable();

  if ( break_id < 0 || break_id >= MAX_SKILL_BREAK || !skill_brk_table->TryGetSkillBrk(break_id))
  {
    return false;
  }

  skillBreakSet_t *sbset = &(skill_brk_table->TryGetSkillBrk(break_id)->skill_break_list);

  skillBreakSetIt_t it		= sbset->begin();
  skillBreakSetIt_t itEnd   = sbset->end();

  it = sbset->begin();
  itEnd	= sbset->end();

  for ( ; it != itEnd; it++ )
  {   
    skillBreak_t *skill_break = &(*it);
	load_projectiles_data(skill_break->proc_particle);

	load_armature_data(skill_break->proc_armature);

	load_projectiles_data(skill_break->ending_particle);

  }
  return true;
}

void BattleResourceLoader::load_projectiles_data(const std::string& res_name)
{
	if ( res_name.empty() )
		return;

	ProjectilesData* projectile_data = 
		DataManager::GetInstance().GetProjectilesDataTable()->GetProjectiles(res_name);

	if ( !projectile_data)
		return ;

	std::string folder = "textures/projectile/";
	const std::string& image_file = projectile_data->GetExportName();
	const std::string& particle = projectile_data->GetParticleEmitter();
	if ((folder.size()==0 || image_file.size()==0) && particle.size()==0)
		return ;

	if (folder.size() != 0 && image_file.size() != 0) 
	{
		string plist_file = folder + image_file + ".plist";
		string png_file = folder + image_file + ".pvr.ccz";
		string animation_file_ = folder + image_file + "_animation.plist";
		string animation_name_ = image_file;

		// load animation texture and config 
		CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(plist_file.c_str(),
			png_file.c_str());
		CCAnimationCache::sharedAnimationCache()->addAnimationsWithFile(animation_file_.c_str());
		ProjectileAnimationCacheManager::GetInstance().AddCacheProjectileAnimationInfo(plist_file.c_str(), png_file.c_str(), animation_name_.c_str());
	}
}

void BattleResourceLoader::load_armature_data(const std::string& res_name)
{
	if ( res_name.empty())
		return;
	
	if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData( res_name.c_str()) == NULL)
	{
		std::string skeleton_config = kDefaultSkeletonFilePath+res_name+".xml";
		std::string skeleton_plist = kDefaultSkeletonFilePath+res_name+".plist";
		std::string skeleton_texture = kDefaultSkeletonFilePath+res_name+".pvr.ccz";
		CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(
			skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
	}
}

void BattleResourceLoader::loadSkillResource(int skill_id)
{
	if(skill_id == kSkillInvaild)
		return ;

	const SkillBase* skillBaseData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
	if ( skillBaseData == NULL ) 
	{
		CCLOG( "��Ч��SkillID %d ����", (int)skill_id );
		return ;
	}

	load_armature_data(skillBaseData->GetPowerEffect());
	load_armature_data(skillBaseData->GetPower2Effect());

	int_32   break_id;
	break_id = skillBaseData->GetSelfBreakId();
	add_break_resource_by_break_id(break_id);
	break_id = skillBaseData->GetEffBreakId();
	add_break_resource_by_break_id(break_id);
	break_id = skillBaseData->GetTagBreakId();
	add_break_resource_by_break_id(break_id);
	add_break_resource_by_break_id(break_id + 1);
	add_break_resource_by_break_id(break_id + 2);

	loadAuraListResource(skillBaseData->GetSelfStatus());
	loadAuraListResource(skillBaseData->GetTagPlayerStatus());
	loadAuraListResource(skillBaseData->GetTagStatus());
}

void BattleResourceLoader::loadAuraResource(int aura_id)
{
	if ( aura_id == Invalid_Aura_ID || aura_id == Invalid_Ability_ID)
		return;

	const AuraData* auraData = DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id);
	if ( auraData == NULL )
	{
		CCLOG( "��Ч��aura_id %d ����", aura_id );
		return ;
	}

	load_projectiles_data(auraData->get_effect());
	load_armature_data(auraData->get_effect_stage1());
	load_armature_data(auraData->get_effect_stage2());
	load_armature_data(auraData->get_effect_stage3());
}

void BattleResourceLoader::loadAuraListResource(const std::string& auraList)
{
	if ( auraList.empty())
		return;

	std::vector<std::string> ids = split(auraList,skillIdSeparator);
	for (std::vector<std::string>::iterator it = ids.begin(); it != ids.end(); ++it)
	{
		int aura_id = atoi(it->c_str());
		loadAuraResource(aura_id);
	}
}

bool BattleResourceLoader::update()
{
  if (mLoadArray.empty())
  {
    return true;
  }
  //do
  int id = mLoadArray.back();
  mLoadArray.pop_back();
  //break animation
  CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(id);
  
  int skill_id = char_data->GetSkillId(kSkillSkill);
  loadSkillResource(skill_id);

  // ����
  int aura_id_1= char_data->GetSkillId(kSkillPassive1);
  loadAuraResource(aura_id_1);
  int aura_id_2= char_data->GetSkillId(kSkillPassive2);
  loadAuraResource(aura_id_2);
  int aura_id_3= char_data->GetSkillId(kSkillWeapon);
  loadAuraResource(aura_id_3);

  return false;
}

void BattleResourceLoader::addLoadCardID(int id)
{
	std::vector<int>::iterator iter = std::find(mLoadArray.begin(), mLoadArray.end(), id);
	if ( iter == mLoadArray.end() )
	{
		mLoadArray.push_back(id);
	}
}

void BattleResourceLoader::clear()
{
  mLoadArray.clear();
}
