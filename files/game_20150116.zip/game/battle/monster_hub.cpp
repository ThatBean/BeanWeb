//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  enemy_hub.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  4:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/monster_hub.h"
#include "game/passive_ability/aura.h"
#include "game/army/unit/monster.h"
#include "game/army/unit/unit_constants.h"
#include "game/army/unit_hub/monst_troops_hub.h"
#include "game/army/unit_hub/summon_troops_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/battle/damage/battle_damage.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "engine/base/basictypes.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "game/battle/battle_data.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/character_data_table.h"
#include <set>
#include <queue>
#include <map>

namespace taomee {
namespace battle {
  
MonsterHub::MonsterHub()
  : BattleHub(),
    update_stop_flag_(false),
    cur_round_(0),
    timeline_(0.0),
    dead_count_(0),
    create_round_(0),
    mIsRightSide(false)
{
  troops_ = new army::MonsterTroopsHub( this, army::kMonsterObject_StartId, army::kMonsterObject_EndId);
  summon_troops_ = new army::SummonTroopsHub( this, army::kMonsterSummonObject_StartId, army::kMonsterSummonObject_EndId);
}

MonsterHub::~MonsterHub()
{

}
  
void MonsterHub::Update(float delta_time)
{
  if (update_stop_flag_)
  {
    return;
  }
  troops_->Update(delta_time);
  BornMosterLoop(delta_time);
}

void MonsterHub::emitNextWaveMonster()
{
	++cur_round_;
	dead_count_ = 0;
	timeline_ = 0;
	battle::BattleController::GetInstance().notifyNewWaveComing( (cur_round_+1), born_monsters_.size(), born_monsters_[cur_round_].boss_round );
}

void MonsterHub::NotifyOneUnitDead(uint_32 object_id)
{
	++dead_count_;
  
	//currently only main goes here
	int getCurrentBattleDataId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId");
	if ( getCurrentBattleDataId <= 10 || getCurrentBattleDataId > 0)
	{
		bool isLastOne = false;
		bool isLastWave = false;
		int round_monster_count = born_monsters_[cur_round_].moster_num;
		if (dead_count_ == round_monster_count)
		{
			isLastOne = true;
			if ( cur_round_ + 1 >= (int)born_monsters_.size() )
			{
				isLastWave = true;
			}
		}

		battle::BattleController::GetInstance().notifyMonsterDead( object_id, isLastOne, isLastWave);
	
		LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_Monster_Dead", object_id);
	}
}
  
// get all move objects by search index list & search center point position
void MonsterHub::GetAllMoveObjectsInTilesWithIndexList(const std::vector<int_8>& indexList,
                                                       std::list<army::MoveObject*>& moveObjList,
                                                       cocos2d::CCPoint searchCenterPos)
{
  BattleHub::GetAllMoveObjectsInTilesWithIndexList(indexList, moveObjList, searchCenterPos);
  // search all monsters with height>1 & extend point in search tiles list
  const std::vector<uint_32>& active_ids = this->troops()->active_ids();
  for(int i = 0; i< active_ids.size(); ++i )
  {
    army::MoveObject* mons = this->troops()->GetObjectById(active_ids[i]);
    if (mons->offset_points_count()<=1)
    {
      continue;
    }

    bool hasInsert = false;
    for (int offsetIdx = 1; offsetIdx<mons->offset_points_count(); ++offsetIdx)
    {
      cocos2d::CCPoint pos = mons->get_pos_by_offset(offsetIdx);
      int_8 offsetTileIdx = GetTileIndexByCurrentPointPosition(pos);
      if (std::find(indexList.begin(), indexList.end(), offsetTileIdx)==indexList.end())
      {
        continue;
      }
      float dis = ccpDistanceSQ(searchCenterPos, pos);
      for (std::list<army::MoveObject*>::iterator it = moveObjList.begin();
           it != moveObjList.end(); ++it)
      {
        if (dis < ccpDistanceSQ(searchCenterPos, (*it)->current_pos()))
        {
          // mark it if this monster has been selected
          hasInsert = true;
          moveObjList.insert(it, mons);
          break;
        }
      }
      // avoid to insert one monster into selected moveObjList more than once
      if (!hasInsert)
      {
        moveObjList.push_back(mons);
      }
      break;
    }
  }
}

void MonsterHub::Start()
{ 
  cur_round_ = 0;
  timeline_ = 0;
  dead_count_ = 0;
  this->Restart();
}
  
void MonsterHub::Restart()
{
  battle::BattleController::GetInstance().
    notifyNewWaveComing((cur_round_+1), born_monsters_.size(), false);
}
  
void MonsterHub::SaveUnkilledMonstersIdList()
{
  // reset dead count
  dead_count_ = 0;
  // all monsters are dead in this round
  int currentActiveCount = troops_->active_ids_count();
  if (currentActiveCount==0)
  { 
    ++cur_round_;
    return;
  }

  const std::vector<uint_32>& active_ids = troops_->active_ids();
  for (int i = 0; i < active_ids.size(); ++i)
  {
    army::Monster* monster = dynamic_cast<army::Monster*>(troops_->GetObjectById(active_ids[i]));
	if ( monster)
	{
		BornMosterInfo tempInfo = BornMosterInfo(
			monster->level(),
			monster->move_object_id(),
			monster->card_id(),
			monster->born_line(),
			monster->timestamp(),
			monster->des_hp_mult(),
			monster->des_att_mult());
		born_monsters_[cur_round_].mosters.push(tempInfo);
	}
  }
  born_monsters_[cur_round_].moster_num = currentActiveCount;
  timeline_ = born_monsters_[cur_round_].mosters.top().timestamp_*0.001f - 3;
}

void MonsterHub::BornMosterLoop(float dt)
{
	float curr_battle_time = battle::BattleController::GetInstance().GetBattleTimeTick() * 1000.0f;
	std::vector<BornMosterInfo>::iterator delay_iter = delay_add__list_.begin();
	while ( delay_iter != delay_add__list_.end())
	{
		const BornMosterInfo& bmi = (*delay_iter);
		if ( bmi.timestamp_ <= curr_battle_time )
		{
			AddImmediatelyMosterAtBornLine(bmi.level_, bmi.unit_id_, bmi.card_id_, bmi.born_line_, bmi.timestamp_, bmi.des_hp_mult_, bmi.des_att_mult);
			delay_iter = delay_add__list_.erase(delay_iter);
		}
		else
		{
			++delay_iter;
		}
	}

	if ( born_monsters_.size() > cur_round_)
	{
		while(!(born_monsters_[cur_round_].mosters.empty())) 
		{
			const BornMosterInfo& born_moster_info = born_monsters_[cur_round_].mosters.top();
			if (born_moster_info.timestamp_ <= timeline_ * 1000)
			{
				this->born_hub()->CreateOneMonsterWithBornInfo(born_moster_info.unit_id_,
					born_moster_info.card_id_,
					ai::kAIStateCommon,
					born_moster_info.born_line_,
					born_moster_info.level_,
					born_moster_info.timestamp_,
					born_moster_info.des_hp_mult_,
					born_moster_info.des_att_mult);

				if(born_moster_info.unit_id_ == 11)
				{
					BornCalculator* tempCalc = DataManager::GetInstance().calculator();
					int hp = 
						tempCalc->HPCalculatorForMonsterByCardIdAndLevel(born_moster_info.card_id_, born_moster_info.level_,born_moster_info.des_hp_mult_);
					int attack = 
						tempCalc->PhyAttackCalculatorForMonsterByCardIdAndLevel(born_moster_info.card_id_,born_moster_info.level_,born_moster_info.des_att_mult);

					int data1 = born_moster_info.card_id_<<4|1;
					battle::BattleController::GetInstance().getCurrentBattleData()->setFirstMonsterData_1(data1);
					int data2 = born_moster_info.level_<<24|(hp+attack);
					battle::BattleController::GetInstance().getCurrentBattleData()->setFirstMonsterData_2(data2);
				}
			}
			else 
			{
				break;
			}
			born_monsters_[cur_round_].mosters.pop();
		}  
		timeline_ += dt;
	}
}

void MonsterHub::AddRoundMoster( uint_16 level,
  uint_32 unit_id,
  uint_32 card_id,
  ai::eAIBornLine born_line,
  uint_32 timestamp,
  float des_hp_mult,
  float des_att_mult)
{
  BornMosterInfo tempInfo = BornMosterInfo(level, unit_id, card_id, born_line, timestamp,des_hp_mult,des_att_mult);
  born_monsters_[create_round_].AddMosterInfo(&tempInfo);
}

void MonsterHub::AddImmediatelyMosterAtIndex( uint_16 level,
  uint_32 unit_id,
  uint_32 card_id,
  int_8 tileIdx,
  uint_32 timestamp,
  float des_hp_mult,
  float des_att_mult)
{
  born_monsters_[cur_round_].moster_num++;
  born_monsters_[cur_round_].monster_card_id_list.push_back(card_id);
  //ai::eAIBornLine born_line = ai::eAIBornLine(tileIdx / battle::kMapColumnCount);
  this->born_hub()->CreateOneMonsterWithBornInfoAtIndex(
	  unit_id,  card_id,  ai::kAIStateCommon, tileIdx, level, timestamp, des_hp_mult, des_att_mult);

  if(unit_id == 11)
  {
	  BornCalculator* tempCalc = DataManager::GetInstance().calculator();
	  int hp = tempCalc->HPCalculatorForMonsterByCardIdAndLevel(card_id, level, des_hp_mult);
	  int attack = tempCalc->PhyAttackCalculatorForMonsterByCardIdAndLevel(card_id, level, des_att_mult);

	  int data1 = card_id<<4|1;
	  battle::BattleController::GetInstance().getCurrentBattleData()->setFirstMonsterData_1(data1);
	  int data2 = level<<24|(hp+attack);
	  battle::BattleController::GetInstance().getCurrentBattleData()->setFirstMonsterData_2(data2);
  }
}

void MonsterHub::AddImmediatelyMosterAtBornLine(
	uint_16 level, uint_32 unit_id,uint_32 card_id, 
	ai::eAIBornLine born_line, uint_32 timestamp, float des_hp_mult /* = 0.0f  */,float des_att_mult /* = 0.0f */)
{
	born_monsters_[cur_round_].moster_num++;
	born_monsters_[cur_round_].monster_card_id_list.push_back(card_id);
	this->born_hub()->CreateOneMonsterWithBornInfo(
		unit_id, card_id, ai::kAIStateCommon, born_line, level, timestamp, des_hp_mult, des_att_mult);

	if(unit_id == 11)
	{
		BornCalculator* tempCalc = DataManager::GetInstance().calculator();
		int hp = tempCalc->HPCalculatorForMonsterByCardIdAndLevel(card_id, level, des_hp_mult);
		int attack = tempCalc->PhyAttackCalculatorForMonsterByCardIdAndLevel(card_id, level, des_att_mult);

		int data1 = card_id<<4|1;
		battle::BattleController::GetInstance().getCurrentBattleData()->setFirstMonsterData_1(data1);
		int data2 = level<<24|(hp+attack);
		battle::BattleController::GetInstance().getCurrentBattleData()->setFirstMonsterData_2(data2);
	}
}

void MonsterHub::DelayAddImmediatelyMosterAtBornLine(
	uint_16 level, uint_32 unit_id,uint_32 card_id, ai::eAIBornLine born_line, uint_32 delay_time, float des_hp_mult /* = 0.0f  */,float des_att_mult /* = 0.0f */)
{
	uint_32 timestamp = (uint_32)(battle::BattleController::GetInstance().GetBattleTimeTick()*1000.0f + delay_time);
	BornMosterInfo tempInfo = BornMosterInfo(level, unit_id, card_id, born_line, timestamp,des_hp_mult,des_att_mult);
	
	delay_add__list_.push_back(tempInfo);
}

LUA_INTERFACE void MonsterHub::SetBossRound()
{
    born_monsters_[create_round_++].boss_round = true;
}

LUA_INTERFACE CCArray* MonsterHub::GetAllMonsterCardArray()
{
  CCArray* monster_card_array = CCArray::create();
  std::set<uint_32> monster_card_set;

  for(std::map<int, RoundMoster>::iterator itr_map = born_monsters_.begin();
    itr_map != born_monsters_.end(); ++itr_map)
  {
    for(std::list<uint_32>::iterator itr_list = itr_map->second.monster_card_id_list.begin();
      itr_list != itr_map->second.monster_card_id_list.end(); ++itr_list)
    {
      if(monster_card_set.count(*itr_list) == 0)
      {
        monster_card_set.insert(*itr_list);
      }
    }
  }

  for(std::set<uint_32>::iterator itr = monster_card_set.begin(); itr != monster_card_set.end(); ++itr)
  {
    monster_card_array->addObject(CCInteger::create(*itr));
  }

  return monster_card_array;
}

void MonsterHub::SetMonsterHubUpdateFlag(bool flag)
{
  update_stop_flag_ = flag;
}

LUA_INTERFACE void MonsterHub::BossPlaySkill( uint_32 unit_id, int_32 skill_id )
{
  army::MoveObject* obj = this->troops()->GetObjectById(unit_id);
  if (obj && obj->is_active())
  {
    obj->set_play_skill_id(skill_id);
  }
  
}

uint_32 MonsterHub::GetCurrRoundBossCardID()
{
  if (cur_round_ < 0  || cur_round_ >= (int)born_monsters_.size()) 
  {
    return 0;
  }

  for(std::list<uint_32>::iterator itr_list = born_monsters_[cur_round_].monster_card_id_list.begin();
    itr_list != born_monsters_[cur_round_].monster_card_id_list.end(); ++itr_list)
  {
     CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter((*itr_list));
     if (char_data && char_data->GetIsEnemy() && char_data->GetMonsterLevel() > kMonsterLevelNormal)
     {
       return (*itr_list);
     }     
  } 
  return 0;
}



} // namespace battle
} // namespace taomee