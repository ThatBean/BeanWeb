//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_pvp_data.h
//        Author: coldouyang
//          Date: 2014/8/26 16:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/8/26      add
//////////////////////////////////////////////////////////////

#ifndef BATTLE_PVP_DATA_H
#define BATTLE_PVP_DATA_H

#include "game/battle/battle_data.h"
#include "network/proto/arena_before_challenge_in.h"
#include "network/proto/arena_before_challenge_out.h"
#include "network/proto/arena_after_challenge_in.h"
#include "network/proto/arena_after_challenge_out.h"

namespace taomee {
  namespace battle {

class BattlePvpData : public BattleData
{
public:
  BattlePvpData();
  virtual ~BattlePvpData();

  virtual void Reset();
  virtual void InitDataForNewBattle();

  virtual void SendRequestSession();
  virtual void SendResultSession();
  
  const std::vector<taomee::net::arena_before_challenge_out::Oppo_team>& getOppoData() { return oppo_data; }
  const std::vector<taomee::net::arena_before_challenge_out::Self_team>& getSelfData() { return self_data; }
  std::vector <std::vector<int> > getCheckCodeArray();

private:
  typedef net::NetSession<net::arena_before_challenge_in::Arena_before_challenge_in, net::arena_before_challenge_out::Arena_before_challenge_out> ArenaRequestSession;
  typedef net::NetSession<net::arena_after_challenge_in::Arena_after_challenge_in, net::arena_after_challenge_out::Arena_after_challenge_out> ArenaResultSession;
  void onArenaRequestSessionCompleted(int error_code,
    boost::shared_ptr<ArenaRequestSession> arena_request_session);
  void onArenaResultSessionCompleted(int error_code, boost::shared_ptr<ArenaResultSession> arena_result_session);

  std::vector<taomee::net::arena_before_challenge_out::Oppo_team> oppo_data;//�Է�����
  std::vector<taomee::net::arena_before_challenge_out::Self_team> self_data;//�Է�����
};

  } /* namespace battle */
} /* namespace taomee */


#endif