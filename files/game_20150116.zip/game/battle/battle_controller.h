//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_controller.h
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_CONTROLLER_H_
#define BATTLE_CONTROLLER_H_

#include <map>

#include "engine/base/basictypes.h"
#include "game/battle/battle_constants.h"
#include "game/army/unit/move_object.h"
#include "game/user_data/user_data_constants.h"

#include "engine/platform/SingleInstance.h"
#define ISBABEL(id) (id >=30000 && id< 31000)

namespace taomee {

template <typename Entity>
class UpdateHelper;
class LoadHelper;

template <typename Entity>
class StateMachine;

namespace ui
{
  class BattleUIController;
}
  
namespace ability
{
  class AuraManager;
}

namespace battle {

class OwnHub;
class MonsterHub;
class BattleData;
class BattlePvpData;
class BattleDataDefault;
class BattleView;
class TiledMap;
class BattleTouchHandler;
class MoveObject;
class LevelBase;
class SkillSystem;
class DamageLabelPool;

/**
 * singleton, use BattleController::GetInstance() to get the instance
 */
class BattleController : public SingleInstanceObj {
public:
  virtual ~BattleController();

  static BattleController& GetInstance();

  StateMachine<BattleController>* GetStateMachine()
  {
    return battle_state_machine_;
  }

  void setBeginEditorMode() { mIsEditorMode = true; }
  bool getIsInEditorMode() { return mIsEditorMode; }
  void Start(eBattleType type = kBattleType_Main);
  void End();
  void Prepare(LoadHelper* load_helper);

  void set_current_checkpoint_id( int curr_checkpoint_id);

  void notifyQuitByPlayer();
  void notifyMonsterMoveToRightBorder(uint_32 monster_id);
  void notifyMoveObjBorn(uint_32 move_obj_id);
  void notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave);
  void notifyPlayerDead(uint_32 player_id, bool last_one);
  void notifyAddAllGainDataIntoUserInfoAfterBattleWin();
  void notifyCharacterLevelupChecking();
  void notifyPlayerRankUpChecking();

  void notifyNewWaveComing(uint_8 cur_wave, uint_8 total_wave, bool is_boss_round);

  void OnBattleRequestCompleted();
  void OnBattleResultCompeleted();

  void BeginPrepare();
  void PrepareOne();
  void EndPrepare();
  
  void beginResourceLoad();
  void onBattleResourceLoadedEnd();

  void EndTalk();

  void PauseBattle();
  void ResumeBattle();

  void EnableBattleTouch();
  void DisableBattleTouch();

  void UpdateEachFrame(float delta);

  void UpdateBattle(float delta);
  
  void UpdateBattleVictoryCelebration(float delta);

  void UpdateLevelEntity(float delta);

  void PreCreateBattleViewAndUnitHubs();
  void NewActiveSkillReleaseWithCharacterId(uint_32 cId);
  
  void CharacherDeadWithCharacterId(uint_32 cId);
  
  void AppEnterBackgroundDuringBattleState();

  void AddUILayerOnBattle(CCLayer *layer);

  void AddUILayeToBattleScene(CCLayer *layer);
  
  void AddStatusOn(int_32 buff_id, int_32 moveobj_id);

  float GetBattleTimeTick();

  bool SetBattleViewTouchFliterEnable(bool d);

  uint_32 getOwn_hubTroops(int index);
  int getMove_object_maxHp(int index);
  int getMove_object_curHp(int index);
  uint_32 getMove_object_id(int index);
  uint_32 getSIdByMoveId(int index);

  int getMove_object_curAngry(int index);
  bool checkMove_object_isCouldSkill(int index);
   
  eBattleType getBattleType();
  void  setBattleType(eBattleType type)
  {
	  //  mCurrentBattleType = type;
  }
  uint_32 getHubCurrRoundBossCardID();
  void reloadCSV();
public: // battle end methods : victory / failed / revive
  void BattleVictory();
  void ShowBattleXpReward();
  uint_32 BattleXpReward(std::vector<std::pair<uint_8, cocos2d::CCPoint> >& xpPos, std::vector<cocos2d::CCPoint>& bottomPos);
  void BattleOver();
  void BattleFailed();
  void BattleFailedConfirm();
  void BattleRevive(data::eItemCostEventKey costkey);
  void BattleClearTroop();
  void ShowNewCard();
  
public:  // touch delegate for player
  // player wants to exchange two characters' garrison tiles
  void ExchangeOneCharacterToAnother(uint_32 selected_unit_id,
                                     uint_32 reflected_unit_id);
  // player wants the selected character to attack the selected monster
  void DispatchOneCharacterToAttackSelectedMonster(uint_32 selected_unit_id,
                                                   uint_32 selected_monster_id);
  // player wants to dispatch the selected character to garrison a new tile/point
  bool DispatchOneCharacterToGarrisonTargetTile(uint_32 selected_unit_id,
                                                int_8 target_tile_idx);
  bool DispatchOneCharacterToGarrisonTargetPoint(uint_32 selected_unit_id,
                                                 const cocos2d::CCPoint& target_pos);
  // character back to garrison tile
  void CharacterBackToGarrisonTargetTile(uint_32 selected_unit_id,
                                         int_8 target_tile_idx);
  
public: // getter & setter

  BattleData* battle_data(eBattleType type = kBattleType_Main);
  BattleData* getCurrentBattleData();

  eBattleStateFlag    battle_state();
  
  BattleHub* own_hub()
  {
	  return m_own_hub_;
  }

  BattleHub* monster_hub()
  {
	  return m_monster_hub_;
  }

  static ability::AuraManager* AuraMgr()
  {
	  return BattleController::GetInstance().aura_manager_;
  }
  
  TiledMap* tiled_map() { return tiled_map_; }  
  BattleView* battle_view() { return battle_view_; }
  SkillSystem* skill_sys() { return skill_sys_; }
    
  ui::BattleUIController* battle_ui()
  {
	  return battle_ui_;
  }

  DamageLabelPool* damage_label_pool() { return damage_label_pool_;}
  
  army::MoveObject* GetObjectById(uint_32 obj_id);

  bool isCharecterActive(uint_32 sel_unit_id);

  cocos2d::CCPoint  GetObjectPosById(uint_32 obj_id);
  
  bool CanPauseBattle();

  void GetActiveUnitAniamtionList(std::map<uint_32, SkeletonAnimation*>& map);
  
  uint_32 GetCurrentSelectedUnitId();
  
  uint_32 GetCurrentMapId();
  
  void GetAllMoveObjectsInTilesWithIndexList(const std::vector<int_8>& indexList,
                                             std::list<uint_32>& moveObjList,
                                             BattleHub* searchHub = NULL,
                                             cocos2d::CCPoint searchCenterPos = kUnexistCoordinatePoint);
  
  uint_8 active_skill_chain_counter() { return active_skill_chain_counter_; }

  bool   CanSkillBeReseaseOrNot(uint_32 obj_id);

  void  AddMoveObjectTalkBubble(uint_32 obj_id,const char* content_text,int offsetY);
  void  RemoveMoveObjectTalkBubble(uint_32 obj_id);

  void  onShowTalkOver(CCNode* pNode);
  //����Pvp׼������
  void  PlayPvpPrepareAnimation();
  //Pvp׼���������Ž���
  void  onPvpPrepareAnimationOver();


  army::MoveObject* get_active_unit_by_id(uint_32 unit_id);
  void set_force_play_skill(uint_32 unit_id, bool is_play_skill = true);
  int_32 get_tile_index_by_unit_id(uint_32 unit_id);
  void instant_kill_by_unit_id(uint_32 unit_id);
  void set_unit_anima_direction(uint_32 unit_id, bool is_facing_right);
public:
  void set_is_forbid_skill_release(bool is_forbid);
  bool is_forbid_skill_release();

  void set_is_forbid_touch(bool is_forbid);
  bool is_forbid_touch();

  void set_handling_obj_id( uint_32 obj_id );
  uint_32 handling_obj_id();

  void set_handling_target_obj_id( uint_32 obj_id );
  uint_32 handling_target_obj_id();

  void set_handling_target_tile_idx( int_8 tile_idx );
  int_8 handling_target_tile_idx();
  
  void set_choose_moveobj(uint_32 obj_id);
  void set_move_moveobj(uint_32 obj_id, int_8 tile_idx);

  void set_unit_hp_by_sandbox(uint_32 unit_id, int hp);
  void show_unit_data_by_sandbox(uint_32 unit_id, int x, int y);

  void brainwash_by_unit_id(uint_32 unit_id, ai::eAIStateType intent_type);

  cocos2d::CCArray* get_active_id_cc_array_for_lua(bool is_monster_hub = false);

  int_32 get_sandbox_hub_config();
  void set_sandbox_hub_config(int_32 sandbox_hub_config);

  uint_32 getActive_ids_count();

  //����ս��ʤ���¼�֪ͨ-for lua
  void emitBattleWinEvent();

  void StartForSandbox();

  bool isBattleWin();
  bool isBattleFailed();
  bool isBattleOver();
  bool isBattleTimeout();
  bool isBattleQuit();

  void fightEnd();
private:
  BattleController();
  DISALLOW_COPY_AND_ASSIGN(BattleController);

  typedef void (BattleController::*PrepareMethod)();
  static PrepareMethod prepare_method_container[];

  void LoadResource();
  void CreateHub();
  void CreateStage();
  void CreateSkill();
  void CreateUI();
  void CreateUnit();
  void CreateMusic();


  LevelBase* CreateLevelEntity(eBattleType type, int check_point_id);
private:
  int                 current_prepare_step_;
  int_8               active_skill_chain_counter_;
  float               active_skill_chain_timer_;

private:
  StateMachine<BattleController>* battle_state_machine_;
  UpdateHelper<BattleController>* update_helper_;

  BattleHub* m_own_hub_;
  BattleHub* m_monster_hub_;

  TiledMap*           tiled_map_;
  
  BattleTouchHandler* battle_touch_handler_;
  BattleView*         battle_view_;
  
  SkillSystem*        skill_sys_;

  ability::AuraManager* aura_manager_;
  
  ui::BattleUIController* battle_ui_;

  DamageLabelPool* damage_label_pool_;
private:

	int m_current_checkpoint_id_;
	LevelBase* m_level_entity;
private:
  bool                is_forbid_touch_;
  uint_32             handling_obj_id_;
  uint_32             handling_target_obj_id_;         
  int_8               handling_target_tile_idx_;
  bool                is_forbid_skill_release_;

  float               time_tick_;

  int_32              sandbox_hub_config_;
  bool                mIsEditorMode;
};

} /* namespace battle */
} /* namespace taomee */

#endif /* BATTLE_CONTROLLER_H_ */
