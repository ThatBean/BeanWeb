//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  battle_damage.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////
#include "game/battle/damage/battle_damage.h"

#include "engine/base/loggermanager.h"
#include "engine/base/random_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/battle/battle_hub.h"
#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_data.h"
#include "game/battle/view/battle_damage_label.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/game_manager/data_manager.h"
#include "game/passive_ability/passive_ability_constants.h"
#include "game/army/unit/character.h"
#include "game/army/unit/summon.h"
#include "game/passive_ability/aura.h"

namespace taomee {
namespace battle {

BattleDamage::BattleDamage()
	: attacker_(NULL)
	, target_unit_(NULL)
	, attacker_id_(army::kUnexistTargetId)
	, target_id_(army::kUnexistTargetId)
	, critical_hit_(false)
	, skill_damage_(false)
	, skill_id_(0)
	, penetrate_count_(0)
	, damage_value_(0)
	, attack_result_type_(kAttackResultNormalDamage)
	, damage_type_(kDamageTypePhysics)
	, is_hit_(true)
	, enable_infect_(true)
	, is_dot_(false)
	, final_damaga_multiple_(1.0f)
	, is_sputtering_(false)
{
	
}

BattleDamage::~BattleDamage()
{
	owner_ = NULL;
}

void BattleDamage::set_attacker_id(uint_32 attacker_id)
{
	attacker_id_ = attacker_id;
}
void BattleDamage::set_target_id(uint_32 target_id)
{
	target_id_ = target_id;
}
void BattleDamage::set_skill_id(uint_32 skill_id)
{
	skill_id_ = skill_id;
}
void BattleDamage::set_is_critical_hit(bool b)
{
	critical_hit_ = b;
}
void BattleDamage::set_penetrate_count(int penetrate_count)
{
	penetrate_count_ = penetrate_count;
}
void BattleDamage::set_damage_value(int damage_value)
{
	damage_value_ = damage_value;
}
void BattleDamage::set_enable_infect(bool enable_infect)
{
	enable_infect_ = enable_infect;
}
void BattleDamage::set_damage_type(eAttackDamageType damageType)
{
	damage_type_ = damageType;
}
void BattleDamage::set_final_damaga_multiple(float final_damaga_multiple)
{
	final_damaga_multiple_ = final_damaga_multiple;
}
void BattleDamage::set_is_sputtering(bool is_sputtering)
{
	is_sputtering_ = is_sputtering;
}

void BattleDamage::nomralProcess()
{
	attacker_ = BattleController::GetInstance().GetObjectById(attacker_id_);
	target_unit_ = BattleController::GetInstance().GetObjectById(target_id_);

	assert(target_unit_ && target_unit_->is_active());

	owner_ = target_unit_->owner_hub();

	SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id_);
	bool isSkillAttack = skillData->GetSkillType();
	damage_type_ = static_cast<eAttackDamageType>(skillData->GetDamageType());

	float skill_level = attacker_->getSkillLevel(skill_id_);
	damage_value_ = skillData->GetSkillGrowDamage(skill_level);
	damage_value_ = damage_value_ + attacker_->physics_attack() * skillData->GetPhyAddedMul();
	damage_value_ = damage_value_ + attacker_->magic_attack() * skillData->GetMagAddedMul();

	bool is_teammate = army::AreTwoMoveObjectsInTheSameForceHub(attacker_id_, target_id_);
	if ( is_teammate )
	{
		if ( ( isSkillAttack && skillData->GetDamageSelfPercent()!= 0 ) ||
			(attacker_->check_battle_status_flag(battle::kDamageEnchantment)) )
		{
			this->calculateDamage();
		}
		else if ( damage_type_ == kDamageTypeHeal )
		{
			this->calculateHeal();
		}
		else
		{
			damage_value_ = 0;
		}
	}
	else
	{
		if ( damage_type_ != kDamageTypeHeal )
		{
			this->calculateDamage();
		}
	}

	if (damage_value_>0)
	{ 
		ByHitEvent::Emit(target_id_ , attacker_id_, attack_result_type_);

		HitEvent::Emit( attacker_id_, target_id_, attack_result_type_, skill_id_, enable_infect_);

		if (isSkillAttack)
		{
			battle::BattleController::GetInstance().battle_data()->set_battle_constions_flag(kBattleWinTypeSkillKill);
		}
		else
		{
			attacker_->add_energy_value(100);
			battle::BattleController::GetInstance().battle_data()->reset_battle_constions_flag(kBattleWinTypeSkillKill);
		}
	}

	is_dot_ = false;
}

void BattleDamage::dotProcess()
{
	assert( damage_value_ != 0 );

	critical_hit_ = false;
	penetrate_count_ = -1;

	attacker_ = BattleController::GetInstance().GetObjectById(attacker_id_);
	target_unit_ = BattleController::GetInstance().GetObjectById(target_id_);
	assert(target_unit_ && target_unit_->is_active());
	owner_ = target_unit_->owner_hub();

	if (damage_value_>0)
	{
		this->calculateValueDamage();
	}

	is_dot_ = true;
}

float BattleDamage::DefenceCorrection()
{
	static float defCor = 0.0f;
	if ( 0.0f == defCor)
	{
		defCor = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/config/debug_config.lua", "GetDefenceCorrection");
	}
	return defCor;
}

void BattleDamage::Attack()
{
	if (target_unit_->is_active() == false)
	{
		return;
	}

	if (damage_value_>0 &&
		(target_unit_->check_battle_status_flag(kDamageInvincible)) &&
		damage_type_ != kDamageTypeSuicide)
	{
		return;
	}

	if ( !is_hit_ )
	{
		// miss 
		attacker_->PushDamageLabel(0, battle::eDamageLabelType_Dodge, skill_damage_);
		//
		return;
	}


	if ( damage_value_>0 && target_unit_->check_battle_status_flag(kDamageStatusImmune) )
	{
		if ( damage_type_ == kDamageTypePhysics && target_unit_->check_immune_status_flag( battle::kImmuneTypePhysicsHurt))
		{
			// ��������
			target_unit_->PushDamageLabel(0, battle::eDamageLabelType_PhysicsImmune, skill_damage_);
			return;
		}
	  
		if (damage_type_ == kDamageTypeMagic && target_unit_->check_immune_status_flag( battle::kImmuneTypeMagicHurt))
		{
			// ħ������
			target_unit_->PushDamageLabel(0, battle::eDamageLabelType_MagicImmune, skill_damage_);
			return;
		}
	}

	eDamageLabelType damage_label_type = eDamageLabelType_Unknown;
	// value settings
	if (damage_value_<0)
	{
		int lostHp = target_unit_->currnet_health_point()-target_unit_->total_health_point();
		assert(lostHp<=0);
		if (damage_value_<lostHp)
		{
			damage_value_ = lostHp;
		}

		damage_label_type = eDamageLabelType_Heal;
	}
	else
	{
		damage_label_type = DamageLabel::toDamageLabelType(attack_result_type_, static_cast<battle::eAttackDamageType>(damage_type_));
	}

	// ��Ŀ�괦��
	owner_->DamageUnit(target_unit_, damage_value_, attacker_, skill_damage_, static_cast<battle::eAttackDamageType>(damage_type_));
	target_unit_->PushDamageLabel(damage_value_, damage_label_type, skill_damage_);
	if ( is_sputtering_ )
	{
		target_unit_->ShowAuraEffectByArmature(army::kBuffEffect_Slay_Hit, ability::kEffectPositionType_Mid, true);
	}
	else
	{
		if ( attack_result_type_ & kAttackResultSlayDamage)
		{
			target_unit_->PushDamageLabel(0, eDamageLabelType_Slay, false);
			target_unit_->ShowAuraEffectByArmature(army::kBuffEffect_Slay_Hit, ability::kEffectPositionType_Mid, true);
		}
	}
	
	if ( is_dot_ )
		return;
	

	if ( damage_value_ > 0 )
	{
		//����
		float thorns_multiple = 0.0f;
		if ( damage_type_ == battle::kDamageTypePhysics)
		{
			thorns_multiple = target_unit_->physics_thorns_boost_multiple();
		}
		else if (damage_type_ == battle::kDamageTypeMagic)
		{
			thorns_multiple = target_unit_->magic_thorns_boost_multiple();
		}
		if ( thorns_multiple > 0.0f)
		{
			int thorns_value = (int)(damage_value_ * thorns_multiple);
			if (thorns_value > 0)
			{
				attacker_->owner_hub()->DamageUnit(attacker_, thorns_value, target_unit_, false);
				damage_label_type = DamageLabel::toDamageLabelType(kAttackResultNormalDamage, kDamageTypePhysics);
				attacker_->PushDamageLabel(thorns_value, damage_label_type, false);

				target_unit_->ReplaceOneStatusEffectNewOneWithName(army::kStatusEffectTagThornsShield, ability::kEffectPositionType_Mid);
			}
		}
	}
  
	// ���Լ����⴦��
	if (damage_value_ > 0)
	{
		// ��Ѫ
		float hematophagia_multiple = 0.0f;
		if ( damage_type_ == battle::kDamageTypePhysics)
		{
			hematophagia_multiple = attacker_->physics_blood_boost_multiple();
		}
		else if ( damage_type_ == battle::kDamageTypeMagic)
		{
			hematophagia_multiple = attacker_->magic_blood_boost_multiple();
		}

		if ( hematophagia_multiple > 0.0f )
		{
			int hematophagia_value = (int)(-damage_value_ * hematophagia_multiple);
			if ( hematophagia_value < 0)
			{
				int lostHp = attacker_->currnet_health_point()-attacker_->total_health_point();
				assert(lostHp<=0);
				if (hematophagia_value<lostHp)
				{
					hematophagia_value = lostHp;
				}
				attacker_->owner_hub()->DamageUnit(attacker_, hematophagia_value, attacker_, false);
				attacker_->PushDamageLabel(hematophagia_value, eDamageLabelType_Heal, false);

				target_unit_->ShowAuraEffectByArmature(army::kBuffEffect_BloodHit, ability::kEffectPositionType_Mid, true);
				attacker_->ShowAuraEffectByArmature(army::kBuffEffect_BloodsuckBlast,ability::kEffectPositionType_Bottom, true);
			}
		}
	}
}

void BattleDamage::calculateDamage()
{
	assert(attacker_);

	if ( damage_value_ == 0)
	{
		CCLOGWARN("attacker_id(%d)......card_id(%d)....skill_id(%d)", attacker_id_, attacker_->card_id(), skill_id_);
		assert(damage_value_!=0);
		return;
	}
	
	int def_value = 0;

	// get skill data
	SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id_);
	bool isSkillAttack = skillData->GetSkillType();
	damage_type_ = static_cast<eAttackDamageType>(skillData->GetDamageType());
	float damageMultiple = 1.0f;

	// 1. for skill attack only -- different from normal hit
	if (isSkillAttack)
	{
		assert(!critical_hit_);
		skill_damage_ = true;
		attack_result_type_ = kAttackResultSkillDamage;
		if (skillData->GetDamageSelfPercent()>0 || skillData->GetDamgeEnemyPercent()>0)
		{
			float damage = 0;
			bool isDamageSelf = false;
			float total_health = attacker_->total_health_point();
			// to self
			if (target_unit_==attacker_)
			{
				isDamageSelf = true;
				float percent = skillData->GetDamageSelfPercent() / 100.0f;
				damage = total_health * percent;
			}
			else // to enemy
			{
				float percent = skillData->GetDamgeEnemyPercent() / 100.0f;
				damage =total_health * percent;
			}
			damage_type_ = kDamageTypeSuicide;

			if ( damage > 0 )
			{
				damage += 0.5f;
			}
			else if ( damage < 0)
			{
				damage -= 0.5f;
			}
			damage_value_ = (int_32)(damage);
			if ( !isDamageSelf )
			{
				target_unit_->ShieldSubtractDamage( damage_value_, static_cast<battle::eAttackDamageType>(damage_type_));
			}
			return;
		}
		else
		{
			uint_32 aStatus = attacker_->attack_status();
			uint_32 tStatus = target_unit_->battle_status_flag();
			attack_result_type_ = attack_result_type_ | GetFiveElementsStatusOverlayedResult(aStatus, tStatus);

			damageMultiple = damageMultiple * attacker_->skill_damage_boost_multiple();

			if ( attacker_->check_battle_status_flag(battle::kDamageSlay ))
			{
				float slay_rate = attacker_->slay_condition_rate();
				float targer_hp_rate = target_unit_->GetCurrentHealthPointPercent();
				if ( targer_hp_rate < slay_rate)
				{
					float slay_damage_mul = attacker_->slay_damage_multiple();
					damageMultiple = damageMultiple * slay_damage_mul;

					attack_result_type_ = attack_result_type_ | kAttackResultSlayDamage;
				}
			}

			// add multiple by skill combo
			float comboTimes = battle::BattleController::GetInstance().active_skill_chain_counter();
			damageMultiple = damageMultiple*(1.0f + comboTimes * 0.1f);

			// �������
			if ( attacker_->is_five_elements_restraint(target_unit_->five_elements() ))
			{
				damageMultiple *= battle::kElementsRestraintDamageMultiple;
			}

			//�ܵ������˺�ʱ�ļ���ϵ�� �� �����ߵ�ĳ�������˺��ӳ�
			float target_ele_damage_weak = target_unit_->GetElementsDamageWeakenMultiple(static_cast<eDamageStatus>(aStatus&kDamageProperty));
			float attacker_ele_damage_added = attacker_->GetElementsDamageAddedMultiple(static_cast<eDamageStatus>(aStatus&kDamageProperty));
			damageMultiple = damageMultiple * ( attacker_ele_damage_added - target_ele_damage_weak );
		}
	}//if (isSkillAttack)
	else // only normal hit 
	{
		// for status multiple
		uint_32 aStatus = attacker_->attack_status();
		uint_32 fStatus = attacker_->favorite_target_status();
		uint_32 tStatus = target_unit_->battle_status_flag();
		uint_32 ele_attack_status = GetFiveElementsStatusOverlayedResult(aStatus, tStatus);
		attack_result_type_ = attack_result_type_| ele_attack_status;
		eAttackResult otherType = GetOtherStatusExceptFiveElementsOverlayedResult(fStatus, tStatus);
		attack_result_type_ = attack_result_type_ | otherType;

		//�Ƿ�Ϊ��Χ��ͨ����
		if (this->isRangeAttackersNormalHit())
		{
			// ��Χ�����˺�ϵ��
			damageMultiple = damageMultiple*attacker_->range_attacker_melee_damage_boost_multiple();
		}
		/*
		// ��ʿ����Χ���� --ȥ����ʿ��Զ���˺�����
		else if (army::GetMoveObjectCareerByCardId(target_unit_->card_id())==army::kCareerTypeKnight/ *knight* / &&
					IsDamageFromRangeAttacker(skill_id_)/ *range attack* /)
		{
			// change to motion attack reflect when target is in idle/move motion state
			if (target_unit_->motion_state()<=ai::kMotionStateMoveTarget)
			{
				
				damageMultiple = damageMultiple*target_unit_->shield_damage_boost_multiple();
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(target_unit_,
																			ai::kMotionStateAttackReflect);
			}
			else if (target_unit_->motion_state()==ai::kMotionStateAttackReflect)
			{ // already in reflect state, mod damage multiple only
				damageMultiple = damageMultiple*target_unit_->shield_damage_boost_multiple();
			}
		}
		*/

		if (critical_hit_)
		{
			assert(!isSkillAttack);
			attack_result_type_ = attack_result_type_ | battle::kAttackResultCriticalDamage;
			// �����˺�
			damage_value_ += attacker_->critical_damage();
		}


		if ( attack_result_type_ & kAttackResultReinforceDamage)
		{
			damageMultiple *= attacker_->status_damage_boost_multiple();
		}

		// �������
		if ( attacker_->is_five_elements_restraint(target_unit_->five_elements() ))
		{
			damageMultiple *= battle::kElementsRestraintDamageMultiple;
		}

		// 4.
		//�ܵ������˺�ʱ�ļ���ϵ�� �� �����ߵ�ĳ�������˺��ӳ�
		float target_ele_damage_weak = target_unit_->GetElementsDamageWeakenMultiple(static_cast<eDamageStatus>(aStatus&kDamageProperty));
		float attacker_ele_damage_added = attacker_->GetElementsDamageAddedMultiple(static_cast<eDamageStatus>(aStatus&kDamageProperty));
		damageMultiple = damageMultiple * ( attacker_ele_damage_added - target_ele_damage_weak );
    
		damageMultiple *= attacker_->damage_boost_multiple();

		if (penetrate_count_>0)
		{
			assert(attacker_->run_through_damage_multiple()>0.0f);
			//��Χ�˺����εݼ��˺� add by dylan
			damageMultiple *= (attacker_->run_through_damage_multiple()/penetrate_count_);
			//damageMultiple *= (attacker_->run_through_damage_multiple());
		}

		float hitrate = attacker_->get_hit_rate( target_unit_->get_dodge());
		if (!flipProbability(hitrate))
		{
			is_hit_ = false;
		}
	}//else // only normal hit 
  
	if (damage_type_ == kDamageTypePhysics)
	{
		def_value = target_unit_->physics_defense();
	}
	else if (damage_type_ == kDamageTypeMagic)
	{
		def_value = target_unit_->magic_defense();
	}

	damageMultiple *= target_unit_->by_damage_boost_multiple();

	damageMultiple *= final_damaga_multiple_;

	//
	float correction = this->DefenceCorrection();
	float correctionDamage = 0.0;
	if ( damage_value_ - correction * def_value <= 0 )
	{
		//Atka^2*(1-(1/C)^2)/(Atka+Defb)
		correctionDamage = damage_value_*damage_value_;
		correctionDamage = correctionDamage * (1 - 1/correction * 1/correction);
		correctionDamage = correctionDamage / (damage_value_ + def_value);
	}
	else
	{
		//(Atka-Defb)
		correctionDamage = damage_value_ - def_value;
	}
	damage_value_ = correctionDamage > 1.0f ? (int_32)correctionDamage : 1;
	damage_value_ = damage_value_*damageMultiple;
	damage_value_ -= target_unit_->final_defense();
	damage_value_ += attacker_->final_damage();

	/*  ��ʱ��Ҫ�ȼ�����
	if (damage_type_ == kDamageTypeMagic || damage_type_ == kDamageTypePhysics)
	{
		//���ϵȼ�����
		if (battle::BattleController::GetInstance().getBattleType() == battle::kBattleType_Pvp)
		{
			army::Character* c = static_cast<army::Character*>(target_unit_);
			damage_value_ += 2 * target_unit_->level();
		}
		else if (battle::BattleController::GetInstance().getBattleType() == battle::kBattleType_Main)
		{
			if (!attacker_->owner_hub()->IsCharacterHub())
			{
				if (target_unit_->owner_hub()->IsCharacterHub())
				{
					damage_value_ += 1.5 * target_unit_->level();
				}
			}
		}
	}*/

	if ( damage_value_ < 0 )
	{
		if (damageMultiple == 0.0f)
		{
			damage_value_ = 0;
		}
		else
		{
			damage_value_ = 1;
		}
	}
  
	// 9. absorb check
	target_unit_->ShieldSubtractDamage( damage_value_, static_cast<battle::eAttackDamageType>(damage_type_));
	if ( damage_value_ == 0)
	{
		return;
	}

	// 9.1 maximum area damage check
	if (skillData->GetTagBreakId() >= 0) 
	{
		skillBreakSet_t skill_break_list = DataManager::GetInstance().GetSkillBrkTable()->GetSkillBrk(skillData->GetTagBreakId())->skill_break_list;
		int_8 skill_val_proc_count = skill_break_list[0].val_proc_count;
  
		if ((skill_val_proc_count > 1 || skill_val_proc_count < 0) && (damage_value_ > kMaximumAreaDamage)) 
		{
			damage_value_ = kMaximumAreaDamage;
		}
	}
}
  
void BattleDamage::calculateValueDamage()
{
  if (damage_type_!=kDamageTypeHoly)
  {
    float damageMultiple = 1.0f;
    int def_value = 0;

    if (damage_type_ == kDamageTypePhysics)
    {
      def_value = target_unit_->physics_defense();
    }
    else if (damage_type_ == kDamageTypeMagic)
    {
      def_value = target_unit_->magic_defense();
    }
    else
    {
      assert(false);
    }
    // 2. extra defense multiple
    damageMultiple *= target_unit_->by_damage_boost_multiple();
    
    // 3. FINAL CALCULATION : damage value * multiple + ATK_bonus - DEF_bonus - EXTRA_DEF_bonus
    damage_value_ = damage_value_-def_value;
    if (damage_value_ <= 0)
    {
      damage_value_ = rand()%14+6;
    }
    damage_value_ = damage_value_*damageMultiple;
  }
  
  // 4. absorb check
  target_unit_->ShieldSubtractDamage( damage_value_, static_cast<battle::eAttackDamageType>(damage_type_));
  if ( damage_value_ == 0)
  {
	  return;
  }
}

void BattleDamage::calculateHeal()
{
  // heal is nagative value
  damage_value_ = 0 - (fabsf(damage_value_) * army::kHealToDamageRadio);
  // get skill data 
  SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id_);
  // attack type : eAttackDamageType(magic / physics / heal / holy) -- skill attack / normal hit
  bool isSkillAttack = skillData->GetSkillType();
  if (isSkillAttack)
  {
    float damageMultiple =  attacker_->skill_damage_boost_multiple();
    // add multiple by skill combo
    float comboTimes = battle::BattleController::GetInstance().active_skill_chain_counter();
    damageMultiple = damageMultiple*(1.0f + comboTimes * 0.1f);
    damage_value_ = damage_value_ * damageMultiple;

	damage_value_  = damage_value_ * target_unit_->by_heal_boost_multiple();
  }
  else
  {
    damage_value_ = damage_value_ * attacker_->damage_boost_multiple() *
                    attacker_->heal_boost_multiple();

	damage_value_  = damage_value_ * target_unit_->by_heal_boost_multiple(); 
  }
}
  
bool BattleDamage::isRangeAttackersNormalHit()
{
  if (skill_id_==army::kNormalHitSkillId)
  {
    if (army::GetMoveObjectAttackTypeByCardId(attacker_->card_id())==
        army::kAttackTypeShot)
    {
      return true;
    }
  }
  return false;
}
  
} // battle
} // taomee
