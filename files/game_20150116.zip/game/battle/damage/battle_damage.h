//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  battle_damage.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  6:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_damage_h
#define ChainChronicle_battle_damage_h

#include "engine/base/basictypes.h"
#include "game/battle/damage/damage_constants.h"
#include "game/passive_ability/passive_ability_constants.h"

namespace taomee {
  
namespace army
{
  class MoveObject;
}
  
namespace battle {

class BattleHub;
  
class BattleDamage {
public:
	BattleDamage();
	virtual ~BattleDamage();
	
	static float DefenceCorrection();

public:
	void set_attacker_id(uint_32 attacker_id);
	void set_target_id(uint_32 target_id);
	void set_skill_id(uint_32 skill_id);
	void set_is_critical_hit(bool b);
	void set_penetrate_count(int penetrate_count);
	void set_damage_value(int damage_value);
	void set_enable_infect(bool enable_infect);
	void set_damage_type(eAttackDamageType damageType);
	void set_final_damaga_multiple(float final_damaga_multiple);
	void set_is_sputtering(bool is_sputtering);
public:

	void nomralProcess();
	void dotProcess();

  // attack calculate
  void Attack();
  
  // get attack result
  uint_32 GetAttackDamageTypeFlag() { return damage_type_; }
  
  // current damage value
  int_32      damage_value() { return damage_value_; }
  
private:
  void calculateDamage();
  void calculateValueDamage();
  void calculateHeal();
  bool isRangeAttackersNormalHit();

private:

  // critical / skill hit
  bool        critical_hit_;
  bool        skill_damage_;
  // penetrate count : -1 means can not penetrate, 0 means first target, >0 need * penetrate_multiple
  int_32      penetrate_count_;
  // attacker : need check attacker's active for some kind of feedback effection
  uint_32 attacker_id_;
  army::MoveObject* attacker_;
  // target unit
  uint_32 target_id_;
  army::MoveObject* target_unit_;
  // when damage_value_>0 means damage, otherwise means healing
  int_32      damage_value_; // == ATK/10
  // skill id
  uint_32     skill_id_;
  // attack result type
  uint_32     attack_result_type_;
  // value damage type
  uint_32     damage_type_;
  
  bool is_hit_;

  bool enable_infect_;

  bool is_dot_;

  float final_damaga_multiple_;

  bool is_sputtering_;
private:
  // reference to this damage's under attacker bub.
  BattleHub*  owner_;
};

} // battle
} // taomee

#endif // ChainChronicle_battle_damage_h
