//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  damage_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-26
//          Time:  6:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-26        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_damage_constants_h
#define ChainChronicle_damage_constants_h

#include "engine/base/basictypes.h"

namespace taomee {
namespace battle {
  
enum eAttackResult
{
  kAttackResultUnkown           = 1 << 0,
  kAttackResultNormalDamage     = 1 << 1,
  kAttackResultCriticalDamage   = 1 << 2,
  kAttackResultGenderDamage     = 1 << 3,
  kAttackResultFireDamage       = 1 << 4,
  kAttackResultIceDamage        = 1 << 5,
  kAttackResultWoodDamage       = 1 << 6,
  kAttackResultMetalDamage      = 1 << 7,
  kAttackResultEarthDamage      = 1 << 8,
  kAttackResultWeakenDamage     = 1 << 9,
  kAttackResultReinforceDamage  = 1 << 10,
  kAttackResultSkillDamage      = 1 << 11,
  kAttackResultWindDamage       = 1 << 12,
  kAttackResultSlayDamage       = 1 << 13,
  kAttackResultMax,
};
  
enum eAttackDamageType
{
  kDamageTypeUnkown          = -1,
  // �����˺�
  kDamageTypePhysics         = 0, // effected by physics defense multiple & extra defense
  // ħ���˺�
  kDamageTypeMagic           = 1, // effected by magic defense multiple & extra defense
  // ��ʥ�˺�- �����￹ħ��
  kDamageTypeHoly            = 2, // none defense multiple effect
  // �Ա�
  kDamageTypeSuicide         = 3, // none Invincible defense
  // ����
  kDamageTypeHeal		= 4,

  kDamageTypeMax,
};

enum eDamageStatusFlag
{
	kDamageStatusFlag_None = -1,
	kDamageStatusFlag_Invincible=0,
	kDamageStatusFlag_FireProperty,
	kDamageStatusFlag_IceProperty,
	kDamageStatusFlag_StatusImmune,
	kDamageStatusFlag_Stunned,
	kDamageStatusFlag_Freeze,
	kDamageStatusFlag_Poison,
	kDamageStatusFlag_LowerMoveSpeed,
	kDamageStatusFlag_Invisbility,
	kDamageStatusFlag_Repel,
	kDamageStatusFlag_MagicProperty,
	kDamageStatusFlag_Skeletonize,
	kDamageStatusFlag_Blinded,
	kDamageStatusFlag_RangeAttackMany,
	kDamageStatusFlag_Silence,
	kDamageStatusFlag_SeriousInjury,
	kDamageStatusFlag_LowerAttackSpeed,
	kDamageStatusFlag_WindProperty,
	kDamageStatusFlag_Petrifaction,
	kDamageStatusFlag_Slay,
	kDamageStatusFlag_kIntertwine,
	kDamageStatusFlag_kEnchantment,
	kDamageStatusFlag_kFear,
	kDamageStatusFlag_kWitchcraft,
	// add
	
	//
	kDamageStatusFlag_Max,
};
 
enum eDamageStatus
{
  kDamageNone				= 0x00,
  // 1-�޵�
  kDamageInvincible			= 1<<kDamageStatusFlag_Invincible, 
  // 2-������
  kDamageFireProperty		= 1<<kDamageStatusFlag_FireProperty,	
  // 4-������
  kDamageIceProperty		= 1<<kDamageStatusFlag_IceProperty,	
  // 8-����
  kDamageStatusImmune		= 1<<kDamageStatusFlag_StatusImmune, // immune to all status, can be hurt
  // 16-����
  kDamageStunned			= 1<<kDamageStatusFlag_Stunned, 
  // 32-����
  kDamageFreeze				= 1<<kDamageStatusFlag_Freeze, 
  // 64-�ж�
  kDamagePoison				= 1<<kDamageStatusFlag_Poison, 
  // 128-������
  kDamageLoweMoveSpeed		= 1<<kDamageStatusFlag_LowerMoveSpeed, 
  // 256-����
  kDamageInvisbility		= 1<<kDamageStatusFlag_Invisbility, 
  // 512-����
  kDamageRepel				= 1<<kDamageStatusFlag_Repel, // NOTE : SPECIAL for repel status only -- MUST NOT reuse agian
  // 1024-��ͨ�������Ա�Ϊħ������
  kDamageMagicProperty		= 1<<kDamageStatusFlag_MagicProperty,
  // 2048-�׹ǻ����Ʒ�
  kDamageSkeletonize		= 1<<kDamageStatusFlag_Skeletonize,
  // 4096-��ä
  kDamageBlinded			= 1<<kDamageStatusFlag_Blinded, 
  // 8192-�����������/�ᴩ
  kDamageRangeAttackMany	= 1<<kDamageStatusFlag_RangeAttackMany, // for range attacker only
  // 16384-��Ĭ
  kDamageSilence			= 1<<kDamageStatusFlag_Silence,
  // 32768-����
  kDamageSeriousInjury		= 1<<kDamageStatusFlag_SeriousInjury,
  // 65536-������
  kDamageLowerAttackSpeed	= 1<<kDamageStatusFlag_LowerAttackSpeed,
  // 131072-������
  kDamageWindProperty		= 1<<kDamageStatusFlag_WindProperty,
  // 262144 - ʯ��
  kDamagePetrifaction		= 1<<kDamageStatusFlag_Petrifaction,
  // 524288 -նɱ
  kDamageSlay				= 1<<kDamageStatusFlag_Slay,
  // ����/����
  kDamageIntertwine			= 1<<kDamageStatusFlag_kIntertwine,
  // �Ȼ�
  kDamageEnchantment		= 1<<kDamageStatusFlag_kEnchantment,
  // �־�
  kDamageFear				= 1<<kDamageStatusFlag_kFear,
  // ����(����)
  kDamageWitchcraft			= 1<<kDamageStatusFlag_kWitchcraft,
  
  kDamageMax				= kDamageStatusFlag_Max,
};

enum eImmuneTypeFlag
{
	kImmuneTypeFlag_None = -1,
	kImmuneTypeFlag_PhysicsHurt = 0,
	kImmuneTypeFlag_MagicHurt,
	kImmuneTypeFlag_LowerAttackSpeed,
	kImmuneTypeFlag_LowerMoveSpeed,
	kImmuneTypeFlag_Poison,
	kImmuneTypeFlag_FireDot,
	kImmuneTypeFlag_IceDot,
	kImmuneTypeFlag_WindDot,
	kImmuneTypeFlag_Control,
	//add

	//
	kImmuneTypeFlag_Max,
};

enum eImmuneType
{
	kImmuneTypeNone = 0x00,
	// 1-���������˺�
	kImmuneTypePhysicsHurt = 1 << kImmuneTypeFlag_PhysicsHurt,
	// 2-����ħ���˺�
	kImmuneTypeMagicHurt = 1 << kImmuneTypeFlag_MagicHurt,
	// 4-���߼�����
	kImmuneTypeLowerAttackSpeed = 1 << kImmuneTypeFlag_LowerAttackSpeed,
	// 8-���߼�����
	kImmuneTypeLowerMoveSpeed = 1 << kImmuneTypeFlag_LowerMoveSpeed,
	// 16-�����ж�
	kImmuneTypePoison = 1 << kImmuneTypeFlag_Poison,
	// 32-���߻�dot
	kImmuneTypeFireDot = 1 << kImmuneTypeFlag_FireDot,
	// 64-���߱�dot
	kImmuneTypeIceDot = 1 << kImmuneTypeFlag_IceDot,
	// 128-���߷�dot
	kImmuneTypeWindDot = 1 << kImmuneTypeFlag_WindDot,
	//256-���߿���
	kImmuneTypeControl = 1 << kImmuneTypeFlag_Control,

	kImmuneTypeMax = kImmuneTypeFlag_Max,
};

enum eDeadReason
{
	// ������������
	kDeadReason_Normal = 0,
	// �Ա�
	kDeadReason_Suicide = 1,
	// ��ʧ��
	kDeadReason_Disappear = 2,
};
  
const eDamageStatus kDamageProperty = static_cast<eDamageStatus>(kDamageFireProperty|kDamageIceProperty|kDamageWindProperty);
  
const uint_32 kOtherStatusExceptFiveElementsBitFlag = 0xffffffff & (~kDamageProperty);
const uint_32 kFiveElementsBitFlag                  = ~kOtherStatusExceptFiveElementsBitFlag;

const float kThroughDamageMultiple			  = 0.67f;
//const float kCriticalDamageMultiple           = 1.5f;
const float kShieldRangeDamageMuiltiple       = 0.4f;
const float kRangeAttackerMeleeDamageMultiple = 0.5f;
const float kElementsWeakenDamageMultiple     = 0.5f;
const float kElementsRestraintDamageMultiple  = 2.0f;
const float kSlayDamageMultiple  = 3.0f;

const float kMaximumAreaDamage  = 99999;

// ��������Ϊ250%
const float ATTACK_SPEED_MULTIPLE_MAX = 2.5f;
  
uint_32 GetFiveElementsStatusOverlayedResult(uint_32 attackStatus, uint_32 targetStatus);

eAttackResult GetOtherStatusExceptFiveElementsOverlayedResult(uint_32 attackStatus, uint_32 targetStatus);
bool IsDamageFromRangeAttacker(uint_32 skillid);
  
bool IsStatusAKindOfStunType(eDamageStatus type);
  
bool IsStatusAKindOfSkillForbiddenType(eDamageStatus type);

} // namespace battle
} // namespace taomee
#endif // ChainChronicle_damage_constants_h
