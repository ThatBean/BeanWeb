//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  battle_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-11-26
//          Time:  4:26
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-11-26        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_constants_h
#define ChainChronicle_battle_constants_h

#include "engine/base/basictypes.h"

namespace taomee {
namespace battle {

enum eBattleStateFlag
{
	kBattleStateNone,
	kBattleStateCombat,
	kBattleStateWin,
	kBattleStateFailed,
	kBattleStateOver,
	kBattleStateTimeout,
	kBattleStateQuitByPlayer,
	kBattleStateMax,
};

enum eBattleType
{
	kBattleType_Unknown = -1,
	kBattleType_Main = 0,
	kBattleType_Pvp,
	kBattleType_SandBox,
	kBattleType_Count,
};

enum eBattleSubType
{
	kBattleSubType_Unknown = -1,
	// ����
	kBattleSubType_Mission = 0,
	// �ճ�����(����ǡ��ر��ء����䱾)
	kBattleSubType_Daily,
	// ͨ����
	kBattleSubType_TongTianTa,
	// ��Ӣ����
	kBattleSubType_Elite,
	// ͻ�Ʊ�
	kBattleSubType_Break,
	// ��ʱKO -- ��������
	kBattleSubType_LevelLimitTimeKO,
	// ���޲���
	kBattleSubType_InfiniteWaveMonster,
	kBattleSceneType_Count,

};

enum eBattleWinConditionType
{
  kBattleWinTypeNone      = 0,
  kBattleWinTypeInTime    = 1<<0,
  kBattleWinTypeNoLose    = 1<<1,
  kBattleWinTypeSkillKill = 1<<2,
};

enum
{
  kCoverLayerZorder		  = (1024<<8) - 1,
  kMaxAnimationZorder	  = 1024<<8,
};
  
const uint_8 kBattleWinTypesCount = 3;
  
const float  kMaxSkillChainTime   = 30.0f;
const float  kShineUITime         = 5.0f;
  
const float  kBattleWinRewardRadio[kBattleWinTypesCount]  = {0.3f, 0.6f, 1.0f};
  
} // namespace battle
} // namespace taomee

#endif // ChainChronicle_battle_constants_h
