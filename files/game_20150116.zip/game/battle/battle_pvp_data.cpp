//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_pvp_data.cpp
//        Author: coldouyang
//          Date: 2014/8/26 16:20
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/8/26      add
//////////////////////////////////////////////////////////////

#include "game/battle/battle_pvp_data.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/handle_delegate.h"
#include "game/account/account_manager.h"
#include "game/army/unit/character.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/own_hub.h"
#include "game/event/universal_event.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/user_interface/message_box_ui/ui_message_box.h"
#include "game/battle/view/battle_view.h"
#include "game/user_data/friend_info.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "network/net_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "game/game_manager/game_logger_manager.h"
#include "game/battle/battle_reward_helper.h"

namespace taomee {
namespace battle {

BattlePvpData::BattlePvpData()
{
  this->Reset();
}

BattlePvpData::~BattlePvpData()
{

}
  
void BattlePvpData::InitDataForNewBattle()
{
  battle_constions_flag_ = kBattleWinTypeNoLose;
}

void BattlePvpData::Reset()
{
  current_task_id_ = 0;
  current_checkpoint_id_ = 0;
  team_id_ = 0;
  current_friend_id_.clear();
  battle_win_ = false;
  original_rank_ = DataManager::GetInstance().user_info()->rank();
  gain_xp_ = 0;
  gain_xp_for_player_ = 0;
  gain_gold_ = 0;
  gain_ap_ = 0;
  gain_xp_multiple_ = 1.0f;
  gain_gold_multiple_ = 1.0f;
  gain_item_multiple_ = 1.0f;
  battle_constions_flag_ = 0;
  choosen_friend_ = false;
  for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
  {
    characters_status_[i] = data::kCharacterStatusUnkown;
  }
}

void BattlePvpData::SendRequestSession()
{
  boost::shared_ptr<ArenaRequestSession> arena_request_session = boost::make_shared<ArenaRequestSession>();
  arena_request_session->SubscribeReciveBodyComplete(this, &BattlePvpData::onArenaRequestSessionCompleted);

  net::arena_before_challenge_in::Arena_before_challenge_in battle_ready_in;
  battle_ready_in.set_cmd(GetHttpActionIDByName("arena_beforeChallenge"));
  battle_ready_in.set_session(account::AccountManager::GetInstance().session());

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  battle_ready_in.set_userid(os.str());
  battle_ready_in.set_oppo_uid(get_pvp_oppo_uid());
  arena_request_session->set_message_in(battle_ready_in);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(arena_request_session);

  for (int i = 0; i < data::kMaxCharacterCountInOneTeam; ++i)
  {
    int sid = DataManager::GetInstance().user_info()->GetTeamCharacterIDByIndex(0, i);
    if (sid != data::kUnexistCharacterId)
    {
      int cid = DataManager::GetInstance().user_info()->getCardBaseInfoBySid(sid)->getID();
    }

  }
}

void BattlePvpData::onArenaRequestSessionCompleted(int error_code,
                                           boost::shared_ptr<ArenaRequestSession> battle_request_session)
{
  if (error_code!=0)
  {
    char* msg = NULL;
    switch (error_code)
    {        
      case 10017:
      {
        msg = GetLuaText("battle_request_ap_not_enough");
      }
        break;
        
      case 10025:
      {
        msg = GetLuaText("battle_request_mission_past_yet");
      }
        break;
        
      case 10026:
      {
        msg = GetLuaText("battle_request_mission_condition_required");
      }
        break;
        
      case 10028:
      {
        msg = GetLuaText("battle_request_too_many_cards");
      }
        break;
        
      default: // 1004 1014
      {
        msg = GetLuaText("battle_request_server_error");
      }
        break;
    }
    // show message box
    ui::UIMessageBox* msgBox = ui::UIMessageBox::Create(ui::kNormalMsgBoxOK);
    msgBox->SetMsgTitleBMFont(GetLuaText("battle_request_error"));
    msgBox->setAnchorPoint(ccp(0.5f, 0.5f));
    msgBox->ignoreAnchorPointForPosition(false);
    cocos2d::CCNode* parent = battle::BattleController::GetInstance().battle_view()->get_ui_layer();
    if (!parent)
    {
      parent = cocos2d::CCDirector::sharedDirector()->getRunningScene();
    }
    msgBox->setPosition(parent->getContentSize().width*0.5f,
                        parent->getContentSize().height*0.5f);
    msgBox->AttachToParentNode(parent);
    return;
  }
  //��������
  oppo_data.clear();
  self_data.clear();
  const taomee::net::arena_before_challenge_out::Arena_before_challenge_out& message_out = battle_request_session->get_message_out();
  const std::vector<taomee::net::arena_before_challenge_out::Oppo_team>& server_oppo_data = message_out.get_oppo_team();
  std::vector<taomee::net::arena_before_challenge_out::Oppo_team>::const_iterator it = server_oppo_data.begin();
  for (;  it != server_oppo_data.end(); ++it)
  {
    oppo_data.push_back(*it);
  }

  const std::vector<taomee::net::arena_before_challenge_out::Self_team>& server_self_data = message_out.get_self_team();
  std::vector<taomee::net::arena_before_challenge_out::Self_team>::const_iterator it2 = server_self_data.begin();
  for (;  it2 != server_self_data.end(); ++it2)
  {
    self_data.push_back(*it2);
  }

  BattleController::GetInstance().OnBattleRequestCompleted();
}

void BattlePvpData::SendResultSession()
{
  boost::shared_ptr<ArenaResultSession> arena_result_session = boost::make_shared<ArenaResultSession>();
  arena_result_session->SubscribeReciveBodyComplete(this, &BattlePvpData::onArenaResultSessionCompleted);

  net::arena_after_challenge_in::Arena_after_challenge_in pvp_result_in;
  pvp_result_in.set_cmd(GetHttpActionIDByName("arena_afterChallenge"));
  pvp_result_in.set_session(account::AccountManager::GetInstance().session());

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  pvp_result_in.set_userid(os.str());
  int win_tag = battle_win_ ? 1 : 0; 
  pvp_result_in.set_is_win(win_tag);
  pvp_result_in.set_checkcode(getCheckCodeArray());
  arena_result_session->set_message_in(pvp_result_in);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(arena_result_session);
}
std::vector <std::vector<int> > BattlePvpData::getCheckCodeArray()
{
	//����id:1����hp��2����attack��3����pdef��4����mdef��5����fdamage��6����fundamage
	int random_key =CCRANDOM_0_1()*(6)+1;
	std::vector <std::vector<int> >   _array(3);
	for(int   i=0;i <3;i++) 
	{
		_array[i].resize(2);
	}

	for (int i = 0;  i < self_data.size(); ++i)
	{
		const taomee::net::arena_before_challenge_out::Self_team& data = self_data.at(i);
		int key_value = 0;
		key_value  +=  data.get_attack();
		key_value  += data.get_hp();
		key_value += data.get_pdef();
		key_value +=  data.get_mdef();
		key_value += data.get_fdamage();
		key_value	+= data.get_fundamage();
		_array[0][0] = data.get_cardid()<<4|1;
		_array[0][1] = 1<<24|key_value;

		CharacterData* char_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(data.get_cardid());
		int firstCharactersSkillId = char_data->GetSkillId(kSkillSkill);
		SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(firstCharactersSkillId);
		float phyDamageMultiple = skillData->GetPhyAddedMul();
		float	firstCharactersPhyDM = phyDamageMultiple;
		_array[2][0] = firstCharactersSkillId<<4|3;
		_array[2][1] = firstCharactersPhyDM*100;

		break;
	}
	for (int i = 0;  i < oppo_data.size(); ++i)
	{

		const taomee::net::arena_before_challenge_out::Oppo_team& data = oppo_data.at(i);

		int key_value = 0;
		key_value  +=  data.get_attack();
		key_value  += data.get_hp();
		key_value += data.get_pdef();
		key_value +=  data.get_mdef();
		key_value += data.get_fdamage();
		key_value	+= data.get_fundamage();
		_array[1][0] = data.get_cardid()<<4|2;
		_array[1][1] = 1<<24|key_value;
		break;

	}
	return _array;
}

void BattlePvpData::onArenaResultSessionCompleted(int error_code, boost::shared_ptr<ArenaResultSession> arena_result_session)
{
  const taomee::net::arena_after_challenge_out::Arena_after_challenge_out& message_out = arena_result_session->get_message_out();
  //const taomee::net::arena_after_challenge_out::Bonus& bonus = message_out.get_bonus();
  //set_gain_gold(bonus.get_gold());
  //set_gain_xp(bonus.get_card_exp());
  //set_gain_xp_for_player(bonus.get_rank_exp());
  if ( error_code != 0 )
    return;
  this->ClearGainCardsMap();
  battle_reward_map_.clear();
  data::UserInfo* user_info = DataManager::GetInstance().user_info();
  PvpawardData* awardData = DataManager::GetInstance().GetPvpAwardDataTable()->GetPvpaward(user_info->rank());
  if ( NULL == awardData )
    return;
  if (battle_win_)
  {
    set_gain_xp(awardData->GetWin_card_exp());
    set_gain_xp_for_player(awardData->GetWin_rank_exp());
    user_info->UpdateItemCountWithType(awardData->GetWin_award1(),awardData->GetWin_award1_count());
    user_info->UpdateItemCountWithType(awardData->GetWin_award2(),awardData->GetWin_award2_count());    
    const std::vector<taomee::net::arena_after_challenge_out::Gains>& gains = message_out.get_gains();
    addServerRewardAfterBattleWin(gains.begin(), gains.end(), battle_reward_map_, gain_card_map_);
  }
  else
  {
    set_gain_xp(awardData->GetLose_card_exp());
    set_gain_xp_for_player(awardData->GetLose_rank_exp());
    user_info->UpdateItemCountWithType(awardData->GetLose_award1(),awardData->GetLose_award1_count());
    user_info->UpdateItemCountWithType(awardData->GetLose_award2(),awardData->GetLose_award2_count());
  }

  BattleController::GetInstance().OnBattleResultCompeleted();
  GameLoggerManager::GetInstance()->log_battle_pvp_person();
}

} /* namespace battle */
} /* namespace taomee */
