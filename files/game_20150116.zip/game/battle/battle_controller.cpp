//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_controller.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/battle_controller.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/update_helper.h"
#include "engine/base/load_helper.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/state_machine/state_machine.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/sound/sound_manager.h"
#include "engine/base/utils_string.h"
#include "engine/event_system/event_manager.h"
#include "game/army/unit/unit_constants.h"
#include "game/army/unit/character.h"
#include "game/army/unit/monster.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/army/unit_hub/summon_troops_hub.h"
#include "game/army/unit_hub/born_hub.h"
#include "game/skill/skill_system.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_constants.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/battle/battle_data.h"
#include "game/battle/battle_pvp_data.h"
#include "game/battle/battle_data_default.h"
#include "game/battle/battle_state.h"
#include "game/battle/own_hub.h"
#include "game/battle/monster_hub.h"
#include "game/battle/battle_constants.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/touch/battle_touch_handler.h"
#include "game/battle/view/battle_view.h"
#include "game/data_table/character_data_table.h"
#include "game/event/universal_event.h"
#include "game/mission/mission_contants.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/data_sync_module.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "game/user_interface/battle_ui/battle_ui_constants.h"
#include "engine/animation/skeleton_animation_cache_manager.h"
#include "game/effect/action_change_add_self_color.h"
#include "game/artificial_intelligence/ai_config.h"
#include "game/battle/view/battle_damage_label.h"
#include "game/battle/battle_resource_loader.h"
#include "game/passive_ability/auramanager.h"
#include "game/battle/level/levelbase.h"
#include "game/battle/level/levelpvp.h"
#include "game/battle/level/levelsandbox.h"
#include "game/battle/level/levelmission.h"
#include "game/battle/level/levelbabel.h"
#include "game/battle/level/leveldaily.h"
#include "game/battle/level/levelelite.h"
#include "game/battle/level/levelbreak.h"
#include "game/battle/level/levellimittimeko.h"
#include "game/battle/level/levelinfinitwavemonster.h"
#include "game/data_table/checkpointdaily_data_table.h"

using namespace cocos2d;

namespace {

/*
enum BattlePrepareStep
{
  kPrepareStepMin = 0,
  kPrepareStepLoadResource = 0,
  kPrepareStepCreateHub = 1,
  kPrepareStepCreateStage = 2,
  kPrepareStepCreateSkill = 3,
  kPrepareStepCreateUI = 4,
  kPrepareStepCreateUnit = 5,
  kPrepareStepCreateMusic = 6,

  kPrepareStepMax
};
*/

enum BattlePrepareStep
{
  kPrepareStepMin = 0,
  kPrepareStepLoadResource = 0,
  kPrepareStepCreateStage = 1,
  kPrepareStepCreateSkill = 2,
  kPrepareStepCreateUI = 3,
  kPrepareStepCreateUnit = 4,
  kPrepareStepCreateMusic = 5,
  kPrepareStepMax
};

}

namespace taomee {
namespace battle {

BattleController::PrepareMethod BattleController::prepare_method_container[] = {
  &BattleController::LoadResource,
  //&BattleController::CreateHub, 
  //move to PreCreateBattleViewAndUnitHubs(), call in resource_battle_loader.lua
  &BattleController::CreateStage,
  &BattleController::CreateSkill,
  &BattleController::CreateUI,
  &BattleController::CreateUnit,
  &BattleController::CreateMusic
};

BattleController& BattleController::GetInstance()
{
  static BattleController* X = NULL;
  if (!X)
  {
    X = new BattleController();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
  }
  return *X;
}

BattleController::BattleController()
  : battle_state_machine_(NULL),
    update_helper_(NULL),
    m_own_hub_(NULL),
    m_monster_hub_(NULL),
    tiled_map_(NULL),
    battle_touch_handler_(NULL),
    battle_view_(NULL),
    skill_sys_(NULL),
	aura_manager_(NULL),
	  damage_label_pool_(NULL),
    battle_ui_(NULL),
	m_current_checkpoint_id_(0),
	m_level_entity(NULL),
    current_prepare_step_(kPrepareStepMin),
    is_forbid_touch_(false),
    is_forbid_skill_release_(false),
    handling_obj_id_(army::kUnexistTargetId),
    handling_target_obj_id_(army::kUnexistTargetId),
    handling_target_tile_idx_(-1),
    sandbox_hub_config_(0)
{
	mIsEditorMode = false;
  battle_state_machine_ = new StateMachine<BattleController>(this);
  update_helper_ = new UpdateHelper<BattleController>(this);
  skill_sys_ = new SkillSystem();
  aura_manager_ = new ability::AuraManager();
  damage_label_pool_ = new DamageLabelPool(30);
}

BattleController::~BattleController()
{
  SAFE_DEL(tiled_map_);
  SAFE_DEL(battle_touch_handler_);
  SAFE_DEL(battle_view_);
  SAFE_DEL(skill_sys_);
  SAFE_DEL(aura_manager_);
  SAFE_DEL(m_level_entity);
  SAFE_DEL(battle_ui_);
  SAFE_DEL(damage_label_pool_);

  CC_SAFE_DELETE(battle_state_machine_);
  CC_SAFE_RELEASE_NULL(update_helper_);
}

BattleData* BattleController::getCurrentBattleData()
{
	CCAssert( m_level_entity != NULL, "m_level_entity != NULL");
	return m_level_entity->getBattleData();
}

BattleData* BattleController::battle_data(eBattleType type)
{
	CCAssert( m_level_entity != NULL, "m_level_entity != NULL");
	return m_level_entity->getBattleData();
}

eBattleType BattleController::getBattleType()
{
	BattleController* ins = &BattleController::GetInstance();
	if ( m_level_entity )
	{
		return  m_level_entity->getBattleType();
	}

	return kBattleType_Unknown;
}

void BattleController::set_current_checkpoint_id( int curr_checkpoint_id)
{
	m_current_checkpoint_id_ = curr_checkpoint_id;
}

LevelBase* BattleController::CreateLevelEntity(eBattleType type, int check_point_id)
{
	LevelBase* pLevel = NULL;
	if ( type == kBattleType_Main )
	{
		if ( check_point_id >= 2000 && check_point_id <= 2999 )
		{
			// RoleCheckPointType ������
			pLevel = new LevelMission();
		}
		else if ( check_point_id >= 3000 && check_point_id <= 3999 )
		{
			CheckpointDailyData* dailyData = DataManager::GetInstance().GetCheckpointDailyDataTable()->GetCheckpointdaily(check_point_id);
			if ( dailyData && dailyData->get_cp_type() == 4) // ͻ�ƹ�ʵ��
			{
				pLevel = new LevelBreak();
			}
			else if ( dailyData && dailyData->get_cp_type() == 5 ) // ����
			{
				pLevel = new LevelLimitTimeKO();
			}
			else if ( dailyData && dailyData->get_cp_type() == 6 ) // ����
			{
				pLevel = new LevelInfiniteWaveMonster();
			}
			else
			{
				// �ճ�����
				pLevel = new LevelDaily();
			}
		}
		else if ( ( check_point_id >= 1 && check_point_id <= 1999 ) ||
				  ( check_point_id >= 10000 && check_point_id <= 29999 ) ||
					check_point_id == 5001 )
		{
			// ��������
			pLevel = new LevelMission();
		}
		else if ( check_point_id >=30000 && check_point_id< 31000 )
		{
			// ͨ����
			pLevel = new LevelBabel();
		}
		else if ( check_point_id >= 90000)
		{
			// ��Ӣ����
			pLevel = new LevelElite();
		}
		else
		{
			CCAssert(0, "check_point_id error");
		}
	}
	else if ( type == kBattleType_Pvp )
	{
		pLevel = new LevelPvp();
	}
	else if ( type == kBattleType_SandBox )
	{
		pLevel = new LevelSandbox();
	}
	else
	{
		CCAssert( 0, "battle type error!" );
	}

	CCAssert( pLevel != NULL, "pLevel != NULL");
	return pLevel;
}

void BattleController::Start(eBattleType type)
{
	SAFE_DEL(m_level_entity);
	m_level_entity = CreateLevelEntity( type, m_current_checkpoint_id_ );
	m_level_entity->Initialize(m_current_checkpoint_id_);

	LuaTinkerManager::GetInstance().CallLuaFunc<int>(
		"script/battle/lua_battle_controller.lua", "SetCurrentBattleDataInfo");

  is_forbid_touch_ = false;
  handling_obj_id_ = army::kUnexistTargetId;
  handling_target_obj_id_ = army::kUnexistTargetId;
  handling_target_tile_idx_ = -1;
  is_forbid_skill_release_ = false;

  // init private temp data
  active_skill_chain_counter_ = 0;
  active_skill_chain_timer_ = 0;
  
  // create battle view and switch scene
  battle_view_ = new BattleView(); 
  battle_view_->Init();
  battle_view_->SwitchToBattleScene();

  // create battle loading layer
  battle_ui_ = new ui::BattleUIController(battle_view_->battle_scene());
  battle_ui_->CreateBattleLoading();

  time_tick_ = 0;

  aura_manager_->RemoveAllAura();
  m_level_entity->notifyBattleStart();
}

void BattleController::StartForSandbox()
{
	assert(getBattleType() == kBattleType_SandBox );

	LoadResource();
	CreateStage();
	CreateSkill();
	CreateUI();
	CreateUnit();
	CreateMusic();

	CreateHub();

	battle_ui_->RemoveBattleLoading();

	battle_view_->LoadBattleStage();

	//jump to battle directly
	battle_state_machine_->ChangeState(BattleStateBattle::Instance());
}

void BattleController::Prepare(LoadHelper* load_helper)
{
}

void BattleController::OnBattleRequestCompleted()
{
  battle_state_machine_->ChangeState(BattleStatePrepare::Instance());
}

void BattleController::BeginPrepare()
{
  // schedule update
  update_helper_->ScheduleUpdate(kUpdateEachFrame);
}

void BattleController::LoadResource()
{
  // load common resourece
  cocos2d::CCSpriteFrameCache::sharedSpriteFrameCache()->
    addSpriteFramesWithFile("textures/battle/battle_ex.plist");

  cocos2d::CCSpriteFrameCache::sharedSpriteFrameCache()->
    addSpriteFramesWithFile("ui/ui_icon/ui_icon_ex.plist");
}

void BattleController::CreateHub()
{
  assert(battle_view_ != NULL);

  // create logic map tiles grid
  tiled_map_ = new TiledMap();

  // the player's characters hub
  m_level_entity->createBattleHubs();

  m_own_hub_ = m_level_entity->getOwnHub();
  m_own_hub_->set_battle_view(battle_view_);

  m_monster_hub_ = m_level_entity->getMonsterHub();
  m_monster_hub_->set_battle_view(battle_view_);
}

void BattleController::CreateStage()
{
  int current_checkpoint_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId");
  battle_view_->CreateBattleStage(current_checkpoint_id);

  //battle_view_->CreateBattleStage(getCurrentBattleData()->current_checkpoint_id());
}

void BattleController::CreateSkill()
{
  // init skill system
  skill_sys_->Init(kUseSkillBattle);

  // touch handler
  battle_touch_handler_ = new BattleTouchHandler();
  battle_touch_handler_->set_battle_controller(this);
  battle_view_->SetTouchHandler(battle_touch_handler_);
}


void BattleController::CreateUnit()
{  
  BattleResourceLoader::GetInstance()->clear();

  m_level_entity->createUnit();
  battle_touch_handler_->SelectCharacter(army::kCharaterObject_StartId);
}

void BattleController::CreateUI()
{
  battle_ui_->CreateDefaultUIMenuInFirstLoad();
}

void BattleController::CreateMusic()
{
  int boss_music_id = GetLuaMusic("kSIDBoss_bgm");
  int win_music_id = GetLuaMusic("kSIDWin_bgm");

  bool bHasStory = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/checkpoint/checkpoint_story.lua" , "hasStory");
  if (bHasStory == false && LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId") > 0)
  {
	  uint_32 music_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
		  "QueryCheckPointBgMusicID",
		  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId"));
	  if (music_id > 0)
	  {
		  SoundManager::GetInstance().PlayBackgroundMusic(music_id, true);
	  }
  }
}
  
void BattleController::onBattleResourceLoadedEnd()
{
	m_level_entity->notifyBattleResourceLoadedEnd();
}

void BattleController::beginResourceLoad()
{
  this->GetStateMachine()->ChangeState(BattleStateLoadResource::Instance());
}


void BattleController::PrepareOne()
{
  if (current_prepare_step_ == kPrepareStepMax)
  {
    // prepare completed, change to battle

    beginResourceLoad();    
    // reset step
    current_prepare_step_ = kPrepareStepMin;

    return;
  }

  assert(current_prepare_step_ >= 0 &&
         current_prepare_step_ < sizeof (prepare_method_container) / sizeof (prepare_method_container[0]));

  (this->*prepare_method_container[current_prepare_step_])();

  current_prepare_step_++;
}

void BattleController::EndPrepare()
{
  // remove loading layer
  battle_ui_->RemoveBattleLoading();

  battle_view_->LoadBattleStage();
}

void BattleController::EndTalk()
{
  battle_state_machine_->ChangeState(BattleStateBattle::Instance());
}

void BattleController::End()
{
  battle_state_machine_->ChangeState(NullState<BattleController>::Instance());
  m_own_hub_ = NULL;
  m_monster_hub_ = NULL;
  SAFE_DEL(tiled_map_);
  SAFE_DEL(battle_touch_handler_);
  SAFE_DEL(battle_view_);
  SAFE_DEL(battle_ui_);

  damage_label_pool_->clearup();

  m_current_checkpoint_id_ = 0;
  m_level_entity->notifyBattleEnd();

  update_helper_->UnscheduleUpdate(kUpdateEachFrame);

  GameManager::GetInstance().OnBattleCompleted();
  FriendController::GetInstance().RemoveHelperList();
  ai::AIConfig::GetInstance().SetIsAutoFightEnable(false);
  mIsEditorMode = false;
}

void BattleController::OnBattleResultCompeleted()
{
	m_level_entity->notifyBattleResultCompeleted();
}

void BattleController::PauseBattle()
{
  assert(battle_state_machine_->CurrentState() == BattleStateBattle::Instance());

  battle_state_machine_->ChangeState(BattleStatePause::Instance());
}

void BattleController::ResumeBattle()
{
  assert(battle_state_machine_->CurrentState() == BattleStatePause::Instance());
  battle_state_machine_->ChangeState(BattleStateBattle::Instance());
}

void BattleController::EnableBattleTouch()
{
  battle_touch_handler_->EnableTouch();
}

void BattleController::DisableBattleTouch()
{
  battle_touch_handler_->DisableTouch();
}

void BattleController::UpdateEachFrame(float delta)
{
  battle_state_machine_->UpdateEachFrame(delta);
}

void BattleController::UpdateBattle(float delta)
{
  time_tick_ += delta;
  // update all units in two hubs
  m_own_hub_->Update(delta);
  //SnowCold
  m_monster_hub_->Update(delta);

  if (true == battle_state_machine_->IsInState(*BattleStateBattle::Instance()))
  {
    // update for skill system
    skill_sys_->Update(delta);
    // update passive ability
	  aura_manager_->Update( delta);
  }

  // under attack--recieve the damage : damage to enemy is push into
  // the queue saved in own battle hub. So, own_hub_ is under attack by damage_queue
  // from monster_hub_; and monster_hub_ is under attack by damage_queue from own_hub_ oppositely.
  m_own_hub_->UnderAttack(m_monster_hub_->damage_queue());
  m_monster_hub_->UnderAttack(m_own_hub_->damage_queue());

  // touch handler update
  battle_touch_handler_->UpdateEachFrame(delta);
  
  // update battle ui
  battle_ui_->UpdatBattleUI(delta);
  
  // timer & counter for skill combo
  if (active_skill_chain_counter_)
  {
    active_skill_chain_timer_ += delta;
    if (active_skill_chain_timer_>=kMaxSkillChainTime)
    {
      active_skill_chain_counter_ = 0;
      active_skill_chain_timer_ = 0;
      battle_ui_->HideSkillCombo();
    }
    else if (active_skill_chain_timer_>=(kMaxSkillChainTime-kShineUITime))
    {
      // shine ui on battle menu
      battle_ui_->ShineComboLabel();
    }
  }

  this->UpdateLevelEntity(delta);
}
  
void BattleController::PlayPvpPrepareAnimation()
{
  //battle_ui_->PlayPvpPrepareAnimation();
  onPvpPrepareAnimationOver();
}

void BattleController::onPvpPrepareAnimationOver()
{
   GetStateMachine()->ChangeState(BattleStateBattle::Instance());
}


army::MoveObject* BattleController::get_active_unit_by_id(uint_32 unit_id)
{
  taomee::army::TroopsHub* unit_troops;
  if (unit_id < army::kMonsterObject_StartId)
  {
    unit_troops = own_hub()->troops();
  }
  else
  {
    unit_troops = monster_hub()->troops();
  }

  army::MoveObject* unit = NULL;
  const std::vector<uint_32>& active_ids = unit_troops->active_ids();
  for (int i = 0; i < active_ids.size(); ++i)
  {
    if (active_ids[i] == unit_id)
    {
      unit = unit_troops->GetObjectById(active_ids[i]);
      break;
    }
  }

  if (unit)
  {
    return unit;
  }
  else
  {
    CCLog("Not found unit id = %d", unit_id);
    return NULL;
  }
}

void BattleController::show_unit_data_by_sandbox(uint_32 unit_id, int x, int y)
{
	if ( getBattleType() == battle::kBattleType_SandBox)
	{
		army::MoveObject* unit = get_active_unit_by_id(unit_id);
		if ( unit )
		{
			unit->setShowInfoOnSandBox(true, x, y);
		}
	}
}

void BattleController::set_unit_hp_by_sandbox(uint_32 unit_id, int hp)
{
	if ( getBattleType() == battle::kBattleType_SandBox)
	{
		army::MoveObject* unit = get_active_unit_by_id(unit_id);
		if ( unit )
		{
			if ( hp < 1)
			{
				hp = 1;
			}
			unit->set_currnet_health_point(hp);
		}
	}
}

void BattleController::brainwash_by_unit_id(uint_32 unit_id, ai::eAIStateType intent_type)
{
  army::MoveObject* unit = get_active_unit_by_id(unit_id);
  //unit->set_intent_type(intent_type);
  unit->set_ai_orig_state(intent_type);
  unit->set_ai_state(intent_type);
  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateIdle);
}

cocos2d::CCArray* BattleController::get_active_id_cc_array_for_lua(bool is_monster_hub /*= false*/)
{
  CCArray *array = CCArray::create();

  taomee::army::TroopsHub* unit_troops;
  if (is_monster_hub == false)
  {
    unit_troops = own_hub()->troops();
  }
  else
  {
    unit_troops = monster_hub()->troops();
  }

  const std::vector<uint_32>& active_ids = unit_troops->active_ids();
  for (int i = 0; i < active_ids.size(); ++i)
  {
    array->addObject(cocos2d::CCInteger::create(active_ids[i]));
  }

  return array;
}

void BattleController::set_force_play_skill(uint_32 unit_id, bool is_play_skill)
{
	if ( getBattleType() != battle::kBattleType_SandBox)
		return;
  army::MoveObject* unit = get_active_unit_by_id(unit_id);

  if (unit)
  {
	  //
	  {
		  static int times = 0;
		  static int max = 3;

		  //unit->ShowAuraEffectByArmature(vec_sss[times%vec_sss.size()]);

		  //aura_manager_->AddAura(unit, 20028, unit->move_object_id(), 0);

		  if (times % max ==0)
		  {
			//aura_manager_->AddAura(unit, 20001, unit->move_object_id(), 0);

			  times++;
			  //return;
		  }
		  else if (times % max ==1)
		  {
			  //aura_manager_->AddAura(unit, 10042, unit->move_object_id());
			  times++;
		  }
		  else if (times % max ==2)
		  {
			  times++;
		  }
	  }
    unit->set_force_play_skill(is_play_skill);
  }
}


int_32 BattleController::get_tile_index_by_unit_id(uint_32 unit_id)
{
  army::MoveObject* unit = get_active_unit_by_id(unit_id);

  if (unit)
  {
    return unit->tile_index();
  }
  else
  {
    return -1;
  }
}


void BattleController::instant_kill_by_unit_id(uint_32 unit_id)
{
  army::MoveObject* unit = get_active_unit_by_id(unit_id);

  if (unit)
  {
    unit->set_currnet_health_point(0);

    battle::eDeadReason dead_reason = battle::kDeadReason_Suicide;
    unit->GoDeadStation(dead_reason);
  }
}


void BattleController::set_unit_anima_direction(uint_32 unit_id, bool is_facing_right)
{
  army::MoveObject* unit = get_active_unit_by_id(unit_id);

  if (unit)
  {
    if (is_facing_right)
    {
      unit->set_anima_direction(kDirectionRight);
    }
    else
    {
      unit->set_anima_direction(kDirectionLeft);
    }
  }
}


int_32 BattleController::get_sandbox_hub_config()
{
  return sandbox_hub_config_;
}
void BattleController::set_sandbox_hub_config(int_32 sandbox_hub_config)
{
  sandbox_hub_config_ = sandbox_hub_config;

  if (sandbox_hub_config_ == 0)
  {
    m_own_hub_->set_enemy_hub(m_monster_hub_);
    m_monster_hub_->set_enemy_hub(m_own_hub_);
  }
  else
  {
    m_own_hub_->set_enemy_hub(m_monster_hub_);
    m_monster_hub_->set_enemy_hub(m_own_hub_);
  }
}

void BattleController::UpdateBattleVictoryCelebration(float delta)
{
	OwnHub* ownHub = dynamic_cast<OwnHub*>(m_own_hub_);
	ownHub->UpdateVictorySpecial(delta);
	battle_ui_->UpdateRewardUI(delta);
}

eBattleStateFlag BattleController::battle_state()
{
	return m_level_entity->getBattleStateFlag();
}

bool BattleController::isBattleWin()
{
	return m_level_entity->isBattleWin();
}

bool BattleController::isBattleFailed()
{
	return m_level_entity->isBattleFailed();
}
bool BattleController::isBattleOver()
{
	return m_level_entity->isBattleOver();
}
bool BattleController::isBattleTimeout()
{
	return m_level_entity->isBattleTimeout();
}
bool BattleController::isBattleQuit()
{
	return m_level_entity->isBattleQuit();
}
  
void BattleController::fightEnd()
{
  GameManager::GetInstance().BattleStateEnd();
  if (battle_ui_->is_battle_puased())
  { // resume game if needed
    cocos2d::CCDirector::sharedDirector()->resume();
  }
  m_own_hub_->troops()->ChangeAllActiveToIdle();
  monster_hub()->troops()->ChangeAllActiveToIdle();
  battle_ui_->RemoveAllBattleLayer();
  aura_manager_->RemoveAllAura();
}
  
void BattleController::notifyAddAllGainDataIntoUserInfoAfterBattleWin()
{
	m_level_entity->notifyAddAllGainDataIntoUserInfoAfterBattleWin();
}

void BattleController::notifyQuitByPlayer()
{
	m_level_entity->notifyQuitByPlayer();
}

void BattleController::notifyMonsterMoveToRightBorder(uint_32 monster_id)
{
	m_level_entity->notifyMonsterMoveToRightBorder(monster_id);
}

void BattleController::notifyMoveObjBorn(uint_32 move_obj_id)
{
	m_level_entity->notifyMoveObjBorn( move_obj_id );
}

void BattleController::notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave)
{
	m_level_entity->notifyMonsterDead( monster_id, last_one, last_wave);
}

void BattleController::notifyPlayerDead(uint_32 player_id, bool last_one)
{
	m_level_entity->notifyPlayerDead( player_id, last_one);
}

void BattleController::UpdateLevelEntity(float delta)
{
	m_level_entity->Update(delta);
}
  
void BattleController::BattleVictory()
{
  skill_sys()->ClearAllSkill();
  // clear grid layer
  battle_view_->ResetBattleViewForBattleWin();
  // remove all monsters
  monster_hub()->RemoveAllActiveObjectsAndResetTroopsList();
  // create all characters & set default AI station
  own_hub()->RemoveAllActiveObjectsAndResetTroopsList();
  own_hub()->born_hub()->CreateAllCharactersForBattleVictory();
  // update UI
  battle_ui_->BattleWin();
}
  
void BattleController::ShowBattleXpReward()
{
  assert(battle_ui_);
  battle_ui_->ShowXpBarIncreasing();
}

uint_32 BattleController::BattleXpReward(std::vector<std::pair<uint_8, cocos2d::CCPoint> >& xpPos,std::vector<cocos2d::CCPoint>& bottomPos)
{
	// show & update xp bar to reward percent
	OwnHub* ownHub = dynamic_cast<OwnHub*>(m_own_hub_);
	ownHub->ShowXpBarForBattleVictory(getCurrentBattleData()->gain_xp(), xpPos);
	ownHub->ShowRankUpForBattleVictory(bottomPos);
	return getCurrentBattleData()->gain_xp();
}
  
void BattleController::notifyCharacterLevelupChecking()
{
	m_level_entity->notifyCharacterLevelupChecking();
}
  
void BattleController::notifyPlayerRankUpChecking()
{
	m_level_entity->notifyPlayerRankUpChecking();
}

void BattleController::BattleOver()
{
	skill_sys()->ClearAllSkill();
}

void BattleController::BattleFailed()
{
  skill_sys()->ClearAllSkill();

  battle_ui_->BattleShowGameOver();
}
  
void BattleController::BattleFailedConfirm()
{
  battle_state_machine_->ChangeState(BattleStateResultSession::Instance());
}

void BattleController::BattleRevive(data::eItemCostEventKey costkey)
{
  // remove all passive ability
  aura_manager_->RemoveAllAura();

  battle_ui_->FreshButtons();

  m_level_entity->battleRevive();

  battle_touch_handler_->SelectCharacter(army::kCharaterObject_StartId);

  // change to battle state
  battle_state_machine_->ChangeState(BattleStateBattle::Instance());
  // send revive event to server
  DataManager::GetInstance().data_sync_module()->CommitUserEventNotify(costkey);

  battle_ui_->BattleRevive();
}

void BattleController::BattleClearTroop()
{
  // remove all passive ability
  aura_manager_->RemoveAllAura();

  m_level_entity->battleClearTroop();
  
  // change to battle state
  battle_state_machine_->ChangeState(BattleStateBattle::Instance());
}
  
// touch delegate for player
// player wants to exchange two characters' garrison tiles
void BattleController::ExchangeOneCharacterToAnother(uint_32 selected_unit_id,
                                                     uint_32 reflected_unit_id)
{
  if (selected_unit_id==reflected_unit_id)
  {
    return;
  }
  
  army::Character* selected_unit =
    dynamic_cast<army::Character*>(this->GetObjectById(selected_unit_id));
  army::Character* reflected_unit =
    dynamic_cast<army::Character*>(this->GetObjectById(reflected_unit_id));
  
  if ( !selected_unit || selected_unit->is_active() == false ||
       !reflected_unit || reflected_unit->is_active() == false )
  {
    return;
  }
  
  if (selected_unit->motion_state() == ai::kMotionStateReleaseSkill ||
      reflected_unit->motion_state() == ai::kMotionStateReleaseSkill)
  {
    return;
  }
  
  // set garrison tile flags in tiled_map
  this->tiled_map()->MoveCharacterOutOfGarrisonTile(selected_unit_id,
                                                   selected_unit->garrison_tile_index());
  this->tiled_map()->MoveCharacterOutOfGarrisonTile(reflected_unit_id,
                                                   reflected_unit->garrison_tile_index());
  this->tiled_map()->DispatchCharacterGarrisonTile(reflected_unit_id,
                                                  selected_unit->garrison_tile_index());
  this->tiled_map()->DispatchCharacterGarrisonTile(selected_unit_id,
                                                  reflected_unit->garrison_tile_index());
  // set garrison tile index in units
  int_8 garrison_tile_idx = selected_unit->garrison_tile_index();
  selected_unit->set_garrison_tile_index(reflected_unit->garrison_tile_index());
  reflected_unit->set_garrison_tile_index(garrison_tile_idx);
  
  // set target position for selected unit
  uint_32 previous_target = selected_unit->target_selection()->target_id();
  selected_unit->target_selection()->resetTargetSelection();
  selected_unit->target_selection()->set_target_pos(reflected_unit->current_pos());
  selected_unit->target_selection()->set_is_forced_move_to(true);
  selected_unit->target_selection()->set_previous_target_id(previous_target);
  selected_unit->set_ai_state(ai::kAIStateGuard);
  
  CCLog("TOTargetFriend--Touch ID: %ld, chose_target: %ld, target: %ld, previous_target: %ld",
        selected_unit->move_object_id(),
        selected_unit->target_selection()->choosen_target_id(),
        selected_unit->target_selection()->target_id(),
        selected_unit->target_selection()->previous_target_id());
  
  // set target position for reflected unit
  previous_target = reflected_unit->target_selection()->target_id();
  reflected_unit->target_selection()->resetTargetSelection();
  reflected_unit->target_selection()->set_target_pos(selected_unit->current_pos());
  reflected_unit->target_selection()->set_is_forced_move_to(true);
  reflected_unit->target_selection()->set_previous_target_id(previous_target);
  reflected_unit->set_ai_state(ai::kAIStateGuard);
}
  
// player wants the selected character to attack the selected monster
void BattleController::
  DispatchOneCharacterToAttackSelectedMonster(uint_32 selected_unit_id,
                                              uint_32 selected_monster_id)
{
  army::MoveObject* charac = this->GetObjectById(selected_unit_id);
  army::MoveObject* monster = this->GetObjectById(selected_monster_id);
  CharacterData *char_data = charac->character_card_data();
  if ( !charac || !monster )
  {
	  return;
  }
  if (charac->is_active()==false || monster->is_active()==false)
  {
    return;
  }
  if(charac->motion_state() == ai::kMotionStateReleaseSkill)
  {
    return;
  }
  //selected or near hit target, return
  if(charac->target_selection()->choosen_target_id() == selected_monster_id || 
    (charac->target_selection()->target_id() == selected_monster_id &&
     charac->selected_skill_id() == char_data->GetSkillId(kSkillNormalHitNear)))
  {
    return;
  }

  uint_32 previous_target = charac->target_selection()->target_id();
  // do not force attack monster that behind current attacking monster
  // monster   cur_monster    character
  // 1. three object in the same row
  // 2. character is attacking cur_monster
  // 3. user force operation, select to monster(behind cur_monster)
  // 4. do not attack monster until cur_monster is being cleared
  if(previous_target != army::kUnexistTargetId)
  {
    army::MoveObject* cur_monster = GetObjectById(previous_target);
	if ( cur_monster )
	{
		if (false==cur_monster->is_active())
		{
			previous_target = -1;
		}
		else
		{
			bool is_same_row = tiled_map()->AreTwoUnitInTheSameRow(charac->current_pos(),
				monster->current_pos());
			is_same_row &= tiled_map()->AreTwoUnitInTheSameRow(monster->current_pos(),
				cur_monster->current_pos());

			if(is_same_row)
			{
				if(charac->current_pos().x > cur_monster->current_pos().x &&
					cur_monster->current_pos().x > monster->current_pos().x)
				{
					previous_target = -1;
				}
			}
		}
	}
  }

  // for bug that shaked when owener locked target with range skill
  if(charac->target_selection()->target_id() == selected_monster_id &&
    charac->selected_skill_id() == char_data->GetSkillId(kSkillNormalHitFar))
  {
    previous_target = -1;
  }

  charac->target_selection()->resetTargetSelection();
  charac->target_selection()->set_is_forced_move_to(true);
  charac->target_selection()->set_choosen_target_id(selected_monster_id);
  charac->target_selection()->set_target_id(previous_target);
  charac->target_selection()->set_previous_target_id(previous_target);

  CCLog("TOTargetEnemy--Touch ID: %ld, chose_target: %ld, target: %ld, previous_target: %ld",
    charac->move_object_id(),
    charac->target_selection()->choosen_target_id(),
    charac->target_selection()->target_id(),
    charac->target_selection()->previous_target_id());

  // for big boss, need lock one point of boss body
  if(monster->offset_points_count() > 1)
  {
    float min_distance = 100000000.0f;
    int target_id_point_offset = 0;
    for(int i = 0; i < monster->offset_points_count(); ++i)
    {
      if(ccpDistanceSQ(charac->current_pos(), monster->get_pos_by_offset(i)) < min_distance)
      {
        min_distance = ccpDistanceSQ(charac->current_pos(), monster->get_pos_by_offset(i));
        target_id_point_offset = i;
      }
    }
    charac->target_selection()->set_target_id_point_offset(target_id_point_offset);
  }

  charac->set_ai_state(ai::kAIStateGuard);
}
  
// player wants to dispatch the selected character to garrison a new tile/point
bool BattleController::
  DispatchOneCharacterToGarrisonTargetTile(uint_32 selected_unit_id,
                                           int_8 target_tile_idx)
{
  army::MoveObject* charac = this->GetObjectById(selected_unit_id);
  if (!charac || charac->is_active()==false) {
    return false;
  }
  if (false == this->tiled_map()->IsTileCanGarrisonCharacter(selected_unit_id,
                                                             target_tile_idx))
  {
    return false;
  }
  if(charac->motion_state() == ai::kMotionStateReleaseSkill)
  {
    return false;
  }

  // set garrison tile flag in tiled_map: move out from original tile & garrison
  // into new tile
  int_8 original_garrison_tile_idx =
    (dynamic_cast<army::Character*>(this->GetObjectById(selected_unit_id)))\
      ->garrison_tile_index();
  this->tiled_map()->MoveCharacterOutOfGarrisonTile(selected_unit_id,
                                                    original_garrison_tile_idx);
  this->tiled_map()->DispatchCharacterGarrisonTile(selected_unit_id,
                                                   target_tile_idx);
  (dynamic_cast<army::Character*>(charac))->set_garrison_tile_index(target_tile_idx);
  
  // set new motion & target position
  cocos2d::CCPoint target_pos =
    battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);  
  uint_32 previous_target = charac->target_selection()->target_id();
  charac->target_selection()->resetTargetSelection();
  charac->target_selection()->set_is_forced_move_to(true);
  charac->target_selection()->set_target_pos(target_pos);
  charac->target_selection()->set_previous_target_id(previous_target);
  charac->set_ai_state(ai::kAIStateGuard);
  
  CCLog("TOTargetTile--Touch ID: %ld, chose_target: %ld, target: %ld, previous_target: %ld",
        charac->move_object_id(),
        charac->target_selection()->choosen_target_id(),
        charac->target_selection()->target_id(),
        charac->target_selection()->previous_target_id());

  //charac->owner_hub()->enemy_hub()->troops()->GetLastMoveObjectInSelectedRow(
  //  charac->GetCurrentRowIndex());
  return true;
}
  
bool BattleController::
  DispatchOneCharacterToGarrisonTargetPoint(uint_32 selected_unit_id,
                                            const cocos2d::CCPoint& target_pos)
{
  int_8 target_tile_idx = battle::GetTileIndexByCurrentPointPosition(target_pos);
  if (false == battle::IsTileIndexInRightPart(target_tile_idx))
  {
    return false;
  }
  return this->DispatchOneCharacterToGarrisonTargetTile(selected_unit_id,
                                                        target_tile_idx);
}
  
void BattleController::
  CharacterBackToGarrisonTargetTile(uint_32 selected_unit_id,
                                    int_8 target_tile_idx)
{
  if (false == this->tiled_map()->IsTileCanGarrisonCharacter(selected_unit_id,
                                                             target_tile_idx))
  {
    this->tiled_map()->DispatchCharacterGarrisonNearbyTile(selected_unit_id,
                                                           target_tile_idx);
  }
}  
  
void BattleController::
  GetAllMoveObjectsInTilesWithIndexList(const std::vector<int_8>& indexList,
                                        std::list<uint_32>& moveObjList,
                                        BattleHub* searchHub /* = NULL */,
                                        cocos2d::CCPoint searchCenterPos /* = kUnexistCoordinatePoint */)
{
  moveObjList.clear();
  
  std::list<army::MoveObject*> selectedObjList;
  // only search one force
  if (searchHub)
  {
    searchHub->GetAllMoveObjectsInTilesWithIndexList(indexList, selectedObjList, searchCenterPos);
  }
  // search all troops both in ownHub & monsterHub
  else
  {
    std::list<army::MoveObject*> oneObjList;
    std::list<army::MoveObject*> anotherObjList;
    own_hub()->GetAllMoveObjectsInTilesWithIndexList(indexList, oneObjList, searchCenterPos);
    monster_hub()->GetAllMoveObjectsInTilesWithIndexList(indexList, anotherObjList, searchCenterPos);
    // need reorder in two list
    if (ccpDistanceSQ(searchCenterPos, kUnexistCoordinatePoint)>1)
    {
      float maxDis = iCC_DESIGN_SIZE.width*iCC_DESIGN_SIZE.width;
      float oneDis = maxDis, anotherDis = maxDis;
      cocos2d::CCPoint pos = cocos2d::CCPointZero;
      std::list<army::MoveObject*>::iterator itOne = oneObjList.begin();
      std::list<army::MoveObject*>::iterator itAnother = anotherObjList.begin();
      while ((itOne!=oneObjList.end()) ||
             (itAnother!=anotherObjList.end()))
      {
        if (itOne!=oneObjList.end())
        {
          // oneDis need calcluate by new obj pos
          if (oneDis==maxDis)
          {
            pos = (*itOne)->current_pos();
            oneDis = ccpDistanceSQ(searchCenterPos, pos);
          }          
        }
        else
        {
          oneDis = maxDis;
        }
        if (itAnother!=anotherObjList.end())
        {
          // anotherDis need calcluate by new obj pos
          if (anotherDis==maxDis)
          {
            pos = (*itAnother)->current_pos();
            anotherDis = ccpDistanceSQ(searchCenterPos, pos);
          }          
        }
        else
        {
          anotherDis = maxDis;
        }
        // insert (*itAnother) in anotherObjList into selectedObjList
        if (oneDis>=anotherDis)
        {
          oneDis = maxDis;
          selectedObjList.push_back(*itAnother);
          ++itAnother;
        }
        // insert (*itOne) in oneObjList into selectedObjList
        else
        {
          anotherDis = maxDis;
          selectedObjList.push_back(*itOne);
          ++itOne;
        }
      }
    }
    else
    {
      for (std::list<army::MoveObject*>::iterator it = oneObjList.begin();
           it != oneObjList.end(); ++it)
      {
        selectedObjList.push_back(*it);
      }
      for (std::list<army::MoveObject*>::iterator it = anotherObjList.begin();
           it != anotherObjList.end(); ++it)
      {
        selectedObjList.push_back(*it);
      }
    }
  }
  
  // take id from obj list & insert it into moveObjList
  for (std::list<army::MoveObject*>::iterator it = selectedObjList.begin();
       it != selectedObjList.end(); ++it)
  {
    moveObjList.push_back((*it)->move_object_id());
  }
}

void  BattleController::PreCreateBattleViewAndUnitHubs()
{
  CreateHub();
}
  
void  BattleController::NewActiveSkillReleaseWithCharacterId(uint_32 cId)
{
  if (active_skill_chain_counter_ < 8)
  {
    ++active_skill_chain_counter_;
  }    

  battle_ui_->ShowSkillComboWithTimes(active_skill_chain_counter_);
}
  
void  BattleController::CharacherDeadWithCharacterId(uint_32 cId)
{
  if (cId != battle_touch_handler_->selected_character_id() ||
	  own_hub()->troops()->active_ids_count()<=0)
  {
    return;
  }
  battle_touch_handler_->SelectCharacter(own_hub()->troops()->GetActiveObjectByIndex(0)->move_object_id());  
}
  
void BattleController::AppEnterBackgroundDuringBattleState()
{
  battle_touch_handler_->DisableTouch();
  battle_touch_handler_->EnableTouch();
}
  
uint_32 BattleController::GetCurrentSelectedUnitId()
{
  return battle_touch_handler_->selected_character_id();
}
  
uint_32 BattleController::GetCurrentMapId()
{
  switch(getBattleType())
  {
  case kBattleType_Main:
    { 
      return LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
        "QueryCheckPointBattleBgID",
        LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId"));
    }
    break;
  case kBattleType_Pvp:
  case kBattleType_SandBox:
    {
      return LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
        "QueryCheckPointBattleBgID",
        LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId"));
    }
    break;
  default:
      return 0; //should not go there
    break;
  }
}

army::MoveObject* BattleController::GetObjectById(uint_32 obj_id)
{
	if ( obj_id >= army::kCharaterObject_StartId && obj_id <= army::kCharaterObject_EndId)
	{
		return m_own_hub_->troops()->GetObjectById(obj_id);
	}
	else if ( obj_id >= army::kMonsterObject_StartId && obj_id <= army::kMonsterObject_EndId)
	{
		return m_monster_hub_->troops()->GetObjectById(obj_id);
	}
	else if ( obj_id >= army::kPvPCharaterObject_StartId && obj_id <= army::kPvPCharaterObject_EndId)
	{
		return m_monster_hub_->troops()->GetObjectById(obj_id);
	}
	else if ( obj_id >= army::kCharaterSummonObject_StartId && obj_id <= army::kCharaterSummonObject_EndId)
	{
		return m_own_hub_->summon_troops()->GetObjectById(obj_id);
	}
	else if ( obj_id >= army::kMonsterSummonObject_StartId && obj_id <= army::kMonsterSummonObject_EndId)
	{
		return m_monster_hub_->summon_troops()->GetObjectById(obj_id);
	}

	return NULL;
}

bool BattleController::isCharecterActive(uint_32 sel_unit_id)
{
  army::Character* sel_charac = dynamic_cast<army::Character*>( \
    battle::BattleController::GetInstance().GetObjectById(sel_unit_id));
  return (!sel_charac || sel_charac->is_active()==false);
}
  
cocos2d::CCPoint BattleController::GetObjectPosById(uint_32 obj_id)
{
  if (obj_id < army::kMonsterObject_StartId)
  {
    return m_own_hub_->troops()->GetObjectById(obj_id)->anima_node()->getPosition();
  }
  else
  {
	army::MoveObject* monsterObj = m_monster_hub_->troops()->GetObjectById(obj_id);
    if (monsterObj && monsterObj->anima_node())
	{
      return monsterObj->anima_node()->getPosition();
	}
    CCLog("GetObject%d, position error ",obj_id);
    return ccp(0,0);
  }
}

bool BattleController::CanPauseBattle()
{
  return (battle_state_machine_->CurrentState() == BattleStateBattle::Instance());
}
  
void BattleController::GetActiveUnitAniamtionList(std::map<uint_32, SkeletonAnimation*>& map)
{
  map.clear();
  army::TroopsHub* own_troop = m_own_hub_->troops();
  const std::vector<uint_32>& own_active_ids = own_troop->active_ids();
  for (int i = 0; i < own_active_ids.size(); ++i)
  {
	  army::MoveObject* obj = own_troop->GetObjectById(own_active_ids[i]);
	  if (obj)
	  {
		  SkeletonAnimation* node = obj->anima_node();
		  map.insert(std::pair<uint_32, SkeletonAnimation*>(obj->move_object_id(), node));
	  }
  }

  army::TroopsHub* enemy_troop = monster_hub()->troops();
  const std::vector<uint_32>& enemy_active_ids = enemy_troop->active_ids();
  for (int i = 0; i < enemy_active_ids.size(); ++i)
  {
	  army::MoveObject* obj = enemy_troop->GetObjectById(enemy_active_ids[i]);
	  if ( obj )
	  {
		  SkeletonAnimation* node = obj->anima_node();
		  map.insert(std::pair<uint_32, SkeletonAnimation*>(obj->move_object_id(), node));
	  }
  }
}

void BattleController::notifyNewWaveComing( uint_8 cur_wave, uint_8 total_wave, bool is_boss_round )
{
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "callCurrentBattleDataScriptFunc", "Battle_Wave", cur_wave, total_wave);

  battle_ui_->NewWaveComing(cur_wave,total_wave,is_boss_round);

  if ( is_boss_round )
  {
	  BattleSceneTypeEvent::Emit( ability::kBattleSceneType_Pve_Boss );

    int boss_music_id = GetLuaMusic("kSIDBoss_bgm");
    SoundManager::GetInstance().PlayBackgroundMusic(boss_music_id, true);
  }
  else
  {
    BattleSceneTypeEvent::Emit( ability::kBattleSceneType_Pve_Normal );
    uint_32 music_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
      "QueryCheckPointBgMusicID",
      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId"));
    if (music_id > 0)
    {
      SoundManager::GetInstance().PlayBackgroundMusic(music_id, true);
    }
  }
}

void BattleController::ShowNewCard()
{
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/scene/battle_controller.lua", "OnEndBattle", battle_view_->get_ui_layer()); 
}

void BattleController::set_is_forbid_skill_release( bool is_forbid )
{
  is_forbid_skill_release_ = is_forbid;
}

bool BattleController::is_forbid_skill_release()
{
  return is_forbid_skill_release_;
}

void BattleController::set_is_forbid_touch( bool is_forbid )
{
  is_forbid_touch_ = is_forbid;
}

bool BattleController::is_forbid_touch()
{
  switch(getBattleType())
  {
  case kBattleType_Main:
    { 
      return is_forbid_touch_;
    }
    break;
  case kBattleType_Pvp:
    {
      return true;
    }
    break;
  case kBattleType_SandBox:
    {
      return false;
    }
    break;
  default:
      return true;
    break;
  }
}

void BattleController::set_handling_obj_id( uint_32 obj_id )
{
  handling_obj_id_ = obj_id;
}

uint_32 BattleController::handling_obj_id()
{
  return handling_obj_id_;
}

void BattleController::set_handling_target_obj_id( uint_32 obj_id )
{
  handling_target_obj_id_ = obj_id;
  handling_target_tile_idx_ = -1;
}

uint_32 BattleController::handling_target_obj_id()
{
  return handling_target_obj_id_;
}

void BattleController::set_handling_target_tile_idx( int_8 tile_idx )
{
  if (tile_idx == -1 )
  {
    handling_target_tile_idx_ = -1;
    return;
  }
  handling_target_tile_idx_ = GetTileIndexByLuaIndex(tile_idx);
  handling_target_obj_id_ = army::kUnexistTargetId;
}

int_8 BattleController::handling_target_tile_idx()
{
  return handling_target_tile_idx_;
}

void BattleController::AddUILayerOnBattle( CCLayer *layer )
{
  battle_view_->GetLayer(kTopLayer)->addChild(layer);
}


void BattleController::AddUILayeToBattleScene(CCLayer *layer)
{
  layer->ignoreAnchorPointForPosition(false);
  layer->setAnchorPoint(ccp(0.5f, 0.5f));
  layer->setPosition(ccp(battle_view_->battle_scene()->getContentSize().width * 0.5f,
                          battle_view_->battle_scene()->getContentSize().height * 0.5f));
  battle_view_->battle_scene()->addChild(layer,ui::KBattleUIDepthMax);
}

void BattleController::AddStatusOn( int_32 buff_id, int_32 moveobj_id )
{
  //int CurrentBattleDataId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "getCurrentBattleDataId");
  //if ( CurrentBattleDataId <= 10 || CurrentBattleDataId >= 90000)
  {
    army::MoveObject* move_obj = get_active_unit_by_id(moveobj_id);
    if ( move_obj && move_obj->is_active() )
    {
		aura_manager_->AddAura(move_obj, buff_id, moveobj_id);
    } 
  }
}

void BattleController::set_choose_moveobj( uint_32 obj_id )
{
  this->battle_touch_handler_->SetChooseCharacter(obj_id);
}

void BattleController::set_move_moveobj( uint_32 obj_id, int_8 tile_idx )
{
  int_8 target_tile_idx = GetTileIndexByLuaIndex(tile_idx);
  this->battle_touch_handler_->SetMoveCharacter(obj_id, target_tile_idx);
}

bool BattleController::CanSkillBeReseaseOrNot( uint_32 obj_id )
{
  army::Character* sel_charac = dynamic_cast<army::Character*>( \
    battle::BattleController::GetInstance().GetObjectById(obj_id));
  if (!sel_charac || sel_charac->is_active()==false)
  {
    return false;
  }

  if (sel_charac->check_battle_status_flag(kDamageSilence))
  {
	  return false;
  }

  // get card id firstly
  uint_32 cardId = sel_charac->card_id();
  // get card data from character.csv
  /*uint_8 skillCostCount = army::GetMoveObjectSkillCostNumByCardId(cardId);
  army::eCareerType type = army::GetMoveObjectCareerByCardId(cardId);
  return this->battle_ui_->CanSkillBeReseaseOrNot(obj_id, type,skillCostCount);*/

  int curAngry = this->getMove_object_curAngry(obj_id);
  if (curAngry >= taomee::ui::getKMaxAngry())
  {
	  return true;
  }
  return false;

}

float BattleController::GetBattleTimeTick()
{
  return time_tick_;
}

void BattleController::reloadCSV()
{
  DataManager::GetInstance().ReloadFile();
  skill_sys_->skill_data()->Init();
}

void BattleController::AddMoveObjectTalkBubble(uint_32 obj_id, const char* content_text,int offsetY )
{
  army::Character* sel_charac = dynamic_cast<army::Character*>( \
    battle::BattleController::GetInstance().GetObjectById(obj_id));
  if (!sel_charac || sel_charac->is_active()==false)
  {
    return;
  }

  cocos2d::CCLabelTTF* content_label = cocos2d::CCLabelTTF::create(content_text, "Helvetica", 20);
  //content_label->setDimensions(CCSizeMake(200,60));
  //content_label->setHorizontalAlignment(kCCTextAlignmentCenter);
  content_label->setAnchorPoint(ccp(0.5f,0.5f));
  CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/agoui_common/agoui_common_ex.plist","ui/agoui_common/agoui_common_ex.pvr.ccz");
  CCScale9Sprite *back_ground = CCScale9Sprite::createWithSpriteFrameName("agoui_frame_bg1.png");
  back_ground->addChild(content_label);
  back_ground->setContentSize(CCSizeMake(200,60));
  content_label->setPosition(ccp(back_ground->getContentSize().width / 2, back_ground->getContentSize().height / 2));
  //CCSprite* talk_arrow = CCSprite::createWithSpriteFrameName("agoui_talk_arrow.png");
  //talk_arrow->setPosition(ccp(0,-(back_ground->getContentSize().height / 2+4.0f)));

  CCLayer* pLayer = CCLayer::create();
  //pLayer->addChild(talk_arrow);
  pLayer->addChild(back_ground);
  pLayer->setContentSize(back_ground->getContentSize());
  pLayer->setAnchorPoint(ccp(0,0.5));
  //position Y depends on mid line
  pLayer->setPosition(ccp(30,sel_charac->anima_node()->GetBoundingBox().size.height+offsetY));

  sel_charac->anima_node()->addChild(pLayer,0,army::kMoveObjectTag);
}

void BattleController::RemoveMoveObjectTalkBubble(uint_32 obj_id)
{
  army::Character* sel_charac = dynamic_cast<army::Character*>( \
    battle::BattleController::GetInstance().GetObjectById(obj_id));
  if (!sel_charac || sel_charac->is_active()==false)
  {
    return;
  }
  CCNode* pNode = sel_charac->anima_node()->getChildByTag(army::kMoveObjectTag);
  if(pNode != NULL)
    pNode->removeFromParentAndCleanup(true);
}

/////////////////////////////////////////////////////////////////////////////

void BattleController::emitBattleWinEvent()
{
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/scene/battle_controller.lua", "OnRewardItemWhenBattleWin");
}

bool BattleController::SetBattleViewTouchFliterEnable(bool d)
{
  battle::BattleController::GetInstance().battle_view()->SetTouchFliterEnable(d);
  return true;
}

uint_32 BattleController::getActive_ids_count()
{
	return (battle::BattleController::GetInstance().own_hub()->
	troops()->active_ids_count());
}

uint_32 BattleController::getSIdByMoveId(int index)
{
	taomee::army::Character* tempCharacter = dynamic_cast<taomee::army::Character*>(battle::BattleController::GetInstance().own_hub()->
		troops()->GetActiveObjectByIndex(index));
	if (tempCharacter == NULL)
	{
		return NULL;
	}
	return tempCharacter->sequence_id();
}

uint_32 BattleController::getOwn_hubTroops(int index)
{
	return (battle::BattleController::GetInstance().own_hub()->
		troops()->GetActiveObjectByIndex(index)->card_id());
}

uint_32 BattleController::getMove_object_id(int index)
{
	return (battle::BattleController::GetInstance().own_hub()->
		troops()->GetActiveObjectByIndex(index)->move_object_id());
}

int BattleController::getMove_object_maxHp(int index)
{
	army::MoveObject* tempMoveObj = battle::BattleController::GetInstance().own_hub()->
		troops()->GetObjectById(index);
	if(tempMoveObj == NULL)
	{
		return 1234;
	}
	return (tempMoveObj->total_health_point());
}

int BattleController::getMove_object_curHp(int index)
{
	army::MoveObject* tempMoveObj = battle::BattleController::GetInstance().own_hub()->
		troops()->GetObjectById(index);
	if(tempMoveObj == NULL)
	{
		return 0;
	}
	return (tempMoveObj->currnet_health_point());
}


uint_32 BattleController::getHubCurrRoundBossCardID()
{
  battle::MonsterHub* hub = static_cast<battle::MonsterHub*>(battle::BattleController::GetInstance().monster_hub());
  uint_32 card_id = hub->GetCurrRoundBossCardID();
  return card_id;
}

int BattleController::getMove_object_curAngry(int index)
{
	army::MoveObject* tempMoveObj = battle::BattleController::GetInstance().own_hub()->
		troops()->GetObjectById(index);
	if(tempMoveObj == NULL)
	{
		return 0;
	}
	return (tempMoveObj->energy_value());
}
bool BattleController::checkMove_object_isCouldSkill(int index)
{
	army::MoveObject* tempMoveObj = battle::BattleController::GetInstance().own_hub()->
		troops()->GetObjectById(index);
	if(tempMoveObj == NULL)
	{
		return false;
	}
	if ( tempMoveObj->check_battle_status_flag( battle::kDamageStunned) ||
		tempMoveObj->check_battle_status_flag( battle::kDamageFreeze) ||
		tempMoveObj->check_battle_status_flag( battle::kDamagePetrifaction) ||
		tempMoveObj->check_battle_status_flag( battle::kDamageRepel) ||
		tempMoveObj->check_battle_status_flag( battle::kDamageSilence))
	{
		return false;
	}
	return true;
}

} /* namespace battle */
} /* namespace taomee */
