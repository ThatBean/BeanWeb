//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  enemy_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  4:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_enemy_hub_h
#define ChainChronicle_enemy_hub_h

#include "game/battle/battle_hub.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;

namespace taomee {
  
namespace army {
  class Monster;
}
  
namespace battle {

class BornMosterInfo{
 public:
  BornMosterInfo(uint_16 level,
                 uint_32 unit_id,
                 uint_32 card_id,
                 ai::eAIBornLine born_line,
                 uint_32 timestamp,
                 float des_hp_mult,
                 float des_att_mult)
    : level_(level),
      unit_id_(unit_id),
      card_id_(card_id),
      born_line_(born_line),
      timestamp_(timestamp),
      des_hp_mult_(des_hp_mult),
      des_att_mult(des_att_mult)
  {
  }
  bool operator<(const BornMosterInfo& moster) const
  {
     return (timestamp_ > moster.timestamp_? true: false);
  }
 public:
  uint_16 level_;
  uint_32 card_id_;
  uint_32 unit_id_;
  uint_32 timestamp_;
  ai::eAIBornLine born_line_;
  float   des_hp_mult_;
  float   des_att_mult;
};


class RoundMoster{
public:
  RoundMoster():moster_num(0),boss_round(false){}  
  void AddMosterInfo(BornMosterInfo* moster_info) {
    mosters.push(*moster_info);
    ++moster_num;
    monster_card_id_list.push_back(moster_info->card_id_);
  }
  std::priority_queue<BornMosterInfo> mosters; 
  std::list<uint_32> monster_card_id_list;
  int moster_num;
  bool boss_round;
};

class MonsterHub : public BattleHub {
public:
  MonsterHub();
  explicit MonsterHub(int num);
  virtual ~MonsterHub();
  
public:
  virtual void Update(float delta_time);
  // false means monters hub
  virtual bool IsCharacterHub() { return false; };
  virtual bool IsRightSideHub() { return mIsRightSide; };
  virtual void SetRightSideHub(bool is_right_side) { mIsRightSide = is_right_side; };

  // get all move objects by search index list & search center point position
  virtual void GetAllMoveObjectsInTilesWithIndexList(const std::vector<int_8>& indexList,
                                                     std::list<army::MoveObject*>& moveObjList,
                                                     cocos2d::CCPoint searchCenterPos);
  virtual void NotifyOneUnitDead(uint_32 object_id);


  void emitNextWaveMonster();

public:
  void Start();
  void Restart(); // for battle revive
  void SaveUnkilledMonstersIdList();
  
  uint_32 GetCurrRoundBossCardID();

  int   GetCurrRound()
  {
	  return cur_round_;
  }
public:
  LUA_INTERFACE void AddRoundMoster(
	  uint_16 level, uint_32 unit_id, uint_32 card_id, ai::eAIBornLine born_line, uint_32 timestamp, float des_hp_mult = 0.0f, float des_att_mult = 0.0f);

  LUA_INTERFACE void AddImmediatelyMosterAtIndex( 
	  uint_16 level, uint_32 unit_id, uint_32 card_id, int_8 tileIdx, uint_32 timestamp, float des_hp_mult = 0.0f, float des_att_mult = 0.0f);

  LUA_INTERFACE void AddImmediatelyMosterAtBornLine( 
	  uint_16 level, uint_32 unit_id,uint_32 card_id, ai::eAIBornLine born_line, uint_32 timestamp, float des_hp_mult = 0.0f ,float des_att_mult = 0.0f);

  LUA_INTERFACE void DelayAddImmediatelyMosterAtBornLine( 
	  uint_16 level, uint_32 unit_id,uint_32 card_id, ai::eAIBornLine born_line, uint_32 delay_time, float des_hp_mult = 0.0f ,float des_att_mult = 0.0f);

  LUA_INTERFACE void SetRound() {
	  create_round_++;
  }
  LUA_INTERFACE void SetBossRound();

  LUA_INTERFACE CCArray* GetAllMonsterCardArray();
  
  LUA_INTERFACE void SetMonsterHubUpdateFlag(bool flag);

  LUA_INTERFACE void BossPlaySkill(uint_32 unit_id, int_32 skill_id);

private:
  void BornMosterLoop(float dt);

private:
  bool  update_stop_flag_;
  bool  mIsRightSide;
  int   cur_round_;
  int   create_round_;
  int   dead_count_;
  float timeline_;
  std::map<int, RoundMoster > born_monsters_;

  std::vector<BornMosterInfo> delay_add__list_;
};

} // namespace battle
} // namespace taomee

#endif // ChainChronicle_enemy_hub_h
