//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_data.h
//        Author: leohou
//       Version:
//          Date: Nov 13, 2013
//          Time: 2:21:26 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     2:21:26 AM
//
//////////////////////////////////////////////////////////////

#ifndef BATTLE_DATA_H_
#define BATTLE_DATA_H_

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"
#include "game/user_data/user_data_constants.h"

#include "network/session/net_session.hpp"
#include "network/proto/before_battleEx_in.h"
#include "network/proto/before_battleEx_out.h"
#include "network/proto/after_battleEx_in.h"
#include "network/proto/after_battleEx_out.h"
#include "network/proto/bouns_battle_ready_out.h"
#include "network/proto/before_elite_in.h"
#include "network/proto/before_elite_out.h"
#include "network/proto/after_elite_in.h"
#include "network/proto/after_elite_out.h"
#include "network/proto/before_babel_in.h"
#include "network/proto/after_babel_in.h"
#include "network/proto/after_babel_out.h"
#include "network/proto/after_special_battle_in.h"
#include "network/proto/after_special_battle_out.h"
#include "network/proto/before_special_battle_in.h"
#include "network/proto/before_special_battle_out.h"


using namespace cocos2d;

namespace taomee {
namespace battle {

class BattleData {
public:
  BattleData();
  virtual ~BattleData();

  virtual void Reset();
  virtual void InitDataForNewBattle();

  virtual void SendGetFriendCardInfo();
  virtual void SendRequestSession();
  virtual void SendResultSession();

public:
  
  int  getLuckyStar() { return lucky_star_; }
  void syncOriRank();
  float getPvpLimitTime() { return 120; }
  void set_pvp_oppo_uid(const char* id) { pvp_oppo_uid_ = id; }
  void set_pvp_oppo_nick_name(const char* name) { pvp_oppo_nick_name = name; }
  void set_pvp_oppo_leader_id(uint_32 card_id) { pvp_oppo_leader_card_id = card_id; }
  const char* get_pvp_oppo_nick_name() { return pvp_oppo_nick_name.c_str(); }
  int  get_pvp_oppo_leader_id() { return pvp_oppo_leader_card_id; }

  const char* get_pvp_oppo_uid() { return pvp_oppo_uid_.c_str(); }
  int current_task_id() const { return current_task_id_; }
  void set_current_task_id(int current_task_id) { current_task_id_ = current_task_id; }

  int current_checkpoint_id() const
  {
	return current_checkpoint_id_;
  }
  void set_current_checkpoint_id(int current_checkpoint_id)
  {
	  current_checkpoint_id_ = current_checkpoint_id;
  }

  const std::string& current_friend_id() const
  {
	  return current_friend_id_;
  }
  void set_current_friend_id(const std::string& current_friend_id)
  {
	  current_friend_id_ = current_friend_id;
  }
   
  const int current_friend_card_id() const
  {
	  return current_friend_card_id_;
  }
  void set_current_friend_card_id(const int current_friend_card_id)
  {
	  current_friend_card_id_ = current_friend_card_id;
  }
  
  void setCurrentFriendCardSid(const int sid)
  {
	  current_friend_card_sid_ = sid;
  }
  const int getFriendCardSID()
  {
	  return current_friend_card_sid_;
  }

  int team_id() const { return team_id_; }
  void set_team_id(int team_id);
  
  void set_characters_status(data::eCharacterStatus newStatus, uint_32 sId);
  void ResetCharactersStatus();
  uint_32 GetNextReservedCharacterSequenceId();

  bool battle_win() const { return battle_win_; }
  void set_battle_win(bool battle_win) {
	  battle_win_ = battle_win;
  }
  

  int pass_grade()
  {
	  return pass_grade_;
  }
  void set_pass_grade(int grade)
  {
	  pass_grade_ = grade;
  }

  uint_16 original_rank()const { return original_rank_; }
  
  int gain_xp()const { return gain_xp_*gain_xp_multiple_; }
  void set_gain_xp(int xp) { gain_xp_ = xp; }

  int gain_xp_for_player()const { return gain_xp_for_player_; }
  void set_gain_xp_for_player(int xp) { gain_xp_for_player_ = xp; }
  
  int gain_gold()const { return gain_gold_*gain_gold_multiple_; }
  void set_gain_gold(int gold) { gain_gold_ = gold; }
  
  int   gain_ap() const { return gain_ap_; }
  void  set_gain_ap(int ap) { gain_ap_ = ap; }
  void  AddOneGainApWithRadio(float r);

  
  float gain_xp_multiple() { return gain_xp_multiple_; }
  void  add_gain_xp_multiple(float mul)
  {
    gain_xp_multiple_ = gain_xp_multiple_ + mul;
  }
  float gain_gold_multiple() { return gain_gold_multiple_; }
  void  add_gain_gold_multiple(float mul)
  {
    gain_gold_multiple_ = gain_gold_multiple_ + mul;
  }
  float gain_item_multiple() { return gain_item_multiple_; }
  void  add_gain_item_multiple(float mul)
  {
    gain_item_multiple_ = gain_item_multiple_ + mul;
  }
  const std::map<uint_32, uint_32>& gain_card_map()
  {
    return gain_card_map_;
  }
  void  AddOneGainCardMap(uint_32 sequenceId, uint_32 cardId)
  {
    gain_card_map_.insert(std::pair<int, int>(sequenceId, cardId));
  }
  void  ClearGainCardsMap() { gain_card_map_.clear(); }
    
  uint_32     battle_constions_flag() { return battle_constions_flag_; }
  void        set_battle_constions_flag(uint_32 flag)
  {
    battle_constions_flag_ = battle_constions_flag_ | flag;
  }
  void        reset_battle_constions_flag(uint_32 flag)
  {
    battle_constions_flag_ = battle_constions_flag_ & (~flag);
  }
  void        memset_battle_constions_flag() { battle_constions_flag_ = 0; }
  
  uint_8      GetNextConditionIndex(uint_8 currentIdx);
  float       GetRewardRadio();
  float       GetBattleTimeLimitForCurrnetCheckPoint();
  
  bool        choosen_friend() { return choosen_friend_; }
  void        set_choosen_friend(bool flag) { choosen_friend_ = flag; }
  
  bool        CanSelectedUnitUsingActiveSkill(uint_32 obj_id);
  bool        CanUnitUsingActiveSkill(uint_32 unitSeqId);
  
  uint_8      GetDropCount();
  int_8       GetDropItemIdxByIndex(uint_8 index);
  
  bool        is_checkpoint_frist_complete();
  void        set_is_checkpoint_frist_complete( bool is_frist );
  
  cocos2d::CCArray* GetBattleReward();
  cocos2d::CCArray* GetBattleFristReward();
  void setFirstMonsterData_1(int num){ firstMonsterData_1 = num;};
  void setFirstMonsterData_2(int num){ firstMonsterData_2 = num;};

  std::vector <std::vector<int> > getCheckCodeArray();
private:

  typedef net::NetSession<net::before_battleEx_in::Before_battleEx_in, net::before_battleEx_out::Before_battleEx_out> BattleRequestSession;
  void onRequestSessionCompleted(int error_code,
                                 boost::shared_ptr<BattleRequestSession> battle_request_session);

  typedef net::NetSession<net::after_battleEx_in::After_battleEx_in, net::after_battleEx_out::After_battleEx_out> BattleResultSession;
  void onResultSessionCompleted(int error_code,
                                 boost::shared_ptr<BattleResultSession> battle_result_session);
  ////elite
  typedef net::NetSession<net::before_elite_in::Before_elite_in, net::before_elite_out::Before_elite_out> BattleEliteRequestSession;
  void onRequestELiteSessionCompleted(int error_code,
                                  boost::shared_ptr<BattleEliteRequestSession> battle_elite_request_session);

  typedef net::NetSession<net::after_elite_in::After_elite_in, net::after_elite_out::After_elite_out> BattleEliteResultSession;
  void onResultELiteSessionCompleted(int error_code,
    boost::shared_ptr<BattleEliteResultSession> battle_elite_result_session);
  ///babel
  typedef net::NetSession<net::before_babel_in::Before_babel_in, void> BattleBabelRequestSession;
  void onRequestBabelSessionCompleted(int error_code,
	  boost::shared_ptr<BattleBabelRequestSession> battle_babel_request_session);

  typedef net::NetSession<net::after_babel_in::After_babel_in, net::after_babel_out::After_babel_out> BattleBabelResultSession;
  void onResultBabelSessionCompleted(int error_code,
	  boost::shared_ptr<BattleBabelResultSession> battle_babel_result_session);

  typedef net::NetSession<net::before_special_battle_in::Before_special_battle_in, net::before_special_battle_out::Before_special_battle_out> SpecialBattleRequestSession;
  void onRequestSpecialSessionCompleted(int error_code,
	  boost::shared_ptr<SpecialBattleRequestSession> battle_request_session);

  typedef net::NetSession<net::after_special_battle_in::After_special_battle_in, net::after_special_battle_out::After_special_battle_out> SpecialBattleResultSession;
  void onResultSpecialSessionCompleted(int error_code,
	  boost::shared_ptr<SpecialBattleResultSession> battle_result_session);

  //����ս���е���Ķ���-սǰ��֪��Ʒ
  void addLocalRewardAfterBattleWin();
  
protected:
  enum
  {
    kDropItemCount = 4
  };
  int current_task_id_;
  int current_checkpoint_id_;
  std::string current_friend_id_;
  int current_friend_card_id_;
  int current_friend_card_sid_;

  // current selected team id -- always been 0 in first version -- only one team with id==0 exist
  int team_id_;
  // characters' status in choosen team
  data::eCharacterStatus characters_status_[data::kMaxCharacterCountInOneTeam];
  
  bool is_drop_item_[kDropItemCount];
  bool is_checkpoint_frist_complete_;

  typedef std::vector<int> ItemContainer;
  ItemContainer item_container_;

  int firstCharactersSid;
  int firstCharactersAttack;
  int firstCharactersLevel;
  int firstCharactersSkillId;
  float firstCharactersPhyDM;
  int firstMonsterData_1;
  int firstMonsterData_2;
protected: // reward data for battle victory
  bool battle_win_;

  int pass_grade_;
  
  uint_16 original_rank_;
  
  // NOTE : this xp is for card, rank xp is for player.
  // Read it directly from checkpoint table is OK cos this value is inalterable
  int gain_xp_;
  int gain_gold_;
  int gain_ap_;
  int gain_xp_for_player_;
  int lucky_star_;
  
  float gain_xp_multiple_;
  float gain_gold_multiple_;
  float gain_item_multiple_;
  
  std::map<uint_32, uint_32> gain_card_map_;
  
protected: // battle conditions & skill chain data
  bool        choosen_friend_; // flag for friend or helper
  uint_32     battle_constions_flag_; // using as bit map

  std::string pvp_oppo_uid_;
  int  pvp_oppo_leader_card_id;
  std::string pvp_oppo_nick_name;

  std::map<uint_32,uint_32> battle_reward_map_;
  std::map<uint_32,uint_32> battle_first_complete_reward_map;
};

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_DATA_H_ */
