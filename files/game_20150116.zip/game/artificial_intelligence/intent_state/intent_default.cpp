#include "game/artificial_intelligence/intent_state/intent_default.h"

#include "engine/animation/skeleton_animation.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/artificial_intelligence/ai_config.h"
#include "game/army/unit/character.h"

#include "game/battle/own_hub.h"

namespace taomee {
namespace ai {

uint_32 IntentDefault::OnEnter(army::MoveObject *unit)
{
  if (unit->motion_state()!=kMotionStateDead)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->
      ChangeMotion(unit, kMotionStateIdle);
  }  
  return kAIResultSuccess;
}  

uint_32 IntentDefault::OnLeave(army::MoveObject *unit)
{
  if (unit->motion_state()!=kMotionStateDead)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->
      ChangeMotion(unit, kMotionStateIdle);
  }  
  return kAIResultSuccess;
}

uint_32 IntentDefault::Update(army::MoveObject *unit, float delta_time)
{
  if (unit->get_force_play_skill())
  {
    if (ForceReleaseSkill(unit))
      unit->set_force_play_skill(false);
    return kAIResultSuccess;
  }

  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }
  // user opration
  if(OnUserOperation(unit, delta_time))
  {
    return kAIResultSuccess;
  }

  CharacterData* char_data = unit->character_card_data();

  // motion's update
  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->
    Update(unit, delta_time);
  
  // then the motion state check
  if (unit->motion_state() == kMotionStateIdle)
  {
    return kAIResultSuccess;
  }

  // move to pos completed
  if (unit->motion_state()==kMotionStateMovePosition)
  {
    if(ret == kMotionResultCompelted)
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateIdle);
      if (unit->owner_hub()->IsRightSideHub())
      {
        //unit->set_anima_direction(kDirectionLeft);
      }
      else
      {
        //unit->set_anima_direction(kDirectionRight);
      }
    }
    else
      return kAIResultSuccess;
  }

  // guard
  if(unit->guard_trigger() &&
    unit->guard_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
    assert(char_data->GetSkillId(kSkillNormalHitFar) != kSkillInvaild);
    unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitFar));
    unit->set_ai_state(kAIStateFight);
    return kAIResultSuccess;
  }

  return kAIResultSuccess;
}
  
} // namespace ai
} // namespace taomee
