//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_cure.cpp
//        Author: robbiepan
//          Date: 2013/10/16 16:19
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/10/16      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/intent_state/intent_cure.h"

#include "engine/animation/skeleton_animation.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/character.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/skill/skill_constants.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/battle/battle_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/own_hub.h"
#include "game/artificial_intelligence/ai_config.h"
#include "game/data_table/character_data_table.h"
#include "game/army/unit/unit_constants.h"

namespace taomee {
namespace ai {
  
uint_32 IntentCure::OnEnter(army::MoveObject *unit)
{
  if (unit->motion_state()!=kMotionStateDead)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->
      ChangeMotion(unit, kMotionStateIdle);
  }  
  return kAIResultSuccess;
}  

uint_32 IntentCure::OnLeave(army::MoveObject *unit)
{
  if (unit->motion_state()!=kMotionStateDead)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->
      ChangeMotion(unit, kMotionStateIdle);
  }  
  return kAIResultSuccess;
}

uint_32 IntentCure::Update(army::MoveObject *unit, float delta_time)
{
  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }
  // user opration
  if(OnUserOperation(unit, delta_time))
  {
    return kAIResultSuccess;
  }

  CharacterData* char_data = unit->character_card_data();

  // motion's update
  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->
    Update(unit, delta_time);

  //near hit
  if(unit->near_attack_trigger() && 
     unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
    unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
    unit->set_ai_state(kAIStateFight);
    return kAIResultSuccess;
  }

//   // become fighter if no other fighter
  if (ai::AIConfig::GetInstance().GetIsAutoFight() 
    && (unit->owner_hub()->troops()->active_ids_count() 
    == unit->owner_hub()->troops()->GetActiveMoveObjectsCountByAttackType(army::kAttackTypeHeal)))
  {
    army::TroopsHub* enemy_troops = unit->owner_hub()->enemy_hub()->troops();
    if (enemy_troops->active_ids_count() != 0)
    {
      //           CCPoint random_enemy_pos = enemy_troops->GetActiveObjectByIndex(0)->current_pos();
      //           unit->target_selection()->set_target_pos(random_enemy_pos);
      //           unit->target_selection()->set_is_forced_move_to(true);
      //           ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateMovePosition);
      uint_32 enemy_id = *(enemy_troops->active_ids().begin());

      unit->target_selection()->set_target_id(enemy_id);
      unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
      unit->set_ai_state(kAIStateFight);
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMoveTarget);
    }
    return kAIResultSuccess;
  }

  /*// search near friendly unit in heal range
  if (ai::AIConfig::GetInstance().GetIsAutoFight())
  {
    int target_index = GetMostLivelessIndex(unit);
    if(target_index != -1)
    {
      if(unit->motion_state() == kMotionStateMovePosition 
        && unit->guard_trigger() 
        &&  unit->guard_trigger()->GetClosestId() != army::kUnexistTargetId)
      {
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateIdle);
//         unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
//         assert(char_data->GetSkillId(kSkillNormalHitFar) != kSkillInvaild);
//         unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitFar));
//         unit->set_ai_state(kAIStateFight);
//         return kAIResultSuccess;
      }
      else if(unit->motion_state() == kMotionStateIdle)
      {
        cocos2d::CCPoint next_pos = battle::GetGarrisonPointForMoveObjectInTile(target_index);
        unit->target_selection()->set_target_id(army::kUnexistTargetId);
        unit->target_selection()->set_target_pos(next_pos);
        //unit->target_selection()->set_is_forced_move_to(true);
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateMovePosition);
        //return kAIResultSuccess;
        return kAIResultSuccess;
      }
    }
  }*/

  // move to pos completed
  if (unit->motion_state() == kMotionStateMovePosition)
  {
    if(ret == kMotionResultCompelted)
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateIdle);
      if (unit->owner_hub()->IsRightSideHub())
      {
        unit->set_anima_direction(kDirectionLeft);
      }
      else
      {
        unit->set_anima_direction(kDirectionRight);
      }
    }
    else
    {
      return kAIResultSuccess;
    }
  }

  // then the motion state check
  if (unit->motion_state() == kMotionStateIdle &&
    (battle::GetTileIndexByCurrentPointPosition(unit->current_pos()) !=
    dynamic_cast<army::Character*>(unit)->garrison_tile_index()))
  {
    if (unit->idle_time() >= 2.0f)
    {
      cocos2d::CCPoint dest_pos = battle::GetGarrisonPointForMoveObjectInTile( \
        dynamic_cast<army::Character*>(unit)->garrison_tile_index());
      unit->target_selection()->set_target_pos(dest_pos);
      ai::AIStateMachine::GetInstance().MotionMachine()->
        ChangeMotion(unit, ai::kMotionStateMovePosition);
      unit->set_idle_time(0);
    }
    else
    {
      unit->set_idle_time(unit->idle_time()+delta_time);
    }
    return kAIResultSuccess;
  }

  // guard(heal)
  if(unit->guard_trigger() &&
    unit->guard_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
    assert(char_data->GetSkillId(kSkillNormalHitFar) != kSkillInvaild);
    unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitFar));
    unit->set_ai_state(kAIStateFight);
    return kAIResultSuccess;
  }

  return kAIResultSuccess;
}


int IntentCure::GetMostLivelessIndex(army::MoveObject* unit)
{
  float lowest_health_ratio = 1, temp_health_ratio;
  CCPoint target_pos;
  army::MoveObject *owner = NULL;
  army::TroopsHub *owner_troop = unit->owner_hub()->troops();
  const std::vector<uint_32>& active_ids = owner_troop->active_ids();
  for (int i = 0; i < active_ids.size(); ++i)
  {
    owner = owner_troop->GetObjectById(active_ids[i]);
    if(owner != unit)
    {
      temp_health_ratio = owner->currnet_health_point() * 1.0 / owner->total_health_point();
      if (temp_health_ratio < lowest_health_ratio)
      {
        lowest_health_ratio = temp_health_ratio;
        target_pos = owner->current_pos();
      }
    }
  }

  // no need to heal
  if (lowest_health_ratio >= 0.9)
  {
    return -1;
  }
   
  int result_index = -1;

  CCPoint target_vector = target_pos - unit->current_pos();
  float target_distance = sqrt(target_vector.x * target_vector.x + target_vector.y + target_vector.y);
  float unit_heal_range = (unit->guard_trigger()->circle_guard_radius() - 1) * 0.5 * (battle::kMapTileMaxHeight + battle::kMapTileMaxLength) * 0.5;
  float move_fix;
  if (target_distance > unit_heal_range)
  {
    move_fix = (target_distance - unit_heal_range) / target_distance;
    target_pos = ccp(unit->current_pos().x + target_vector.x * move_fix, unit->current_pos().y + target_vector.y * move_fix);
    result_index = battle::GetTileIndexByCurrentPointPosition(target_pos);
    if (unit->tile_index() == result_index) 
      result_index = -1;
  }

  return result_index;
}


} // namespace ai
} // namespace taomee

