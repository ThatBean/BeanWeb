//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_fight.cpp
//        Author: peteryu
//          Date: 2013/10/31 15:49
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/31      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/intent_state/intent_monster_fight.h"

#include "engine/base/load_helper.h"
#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/army/unit/monster.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/battle/battle_controller.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/skill/skill_constants.h"
#include "game/skill/skill_data.h"
#include "game/skill/skill_system.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "game/event/event_battle/event_battle_obj.h"

namespace taomee {
namespace ai {
  
uint_32 IntentMonsterFight::OnEnter(army::MoveObject *unit)
{
  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  battle::SkillData* skill_data = battle::BattleController::GetInstance().skill_sys()->skill_data();
  if (skill_data->GetSkillBaseSkillType(unit->selected_skill_id()) &&
      data::IsThisCardAnMonstorBoss(unit->card_id()))
  {
    CharacterData* data = static_cast<CharacterData*>(BaseResDataTable::GetInstance()->GetResDataById(unit->card_id()));
    if (data->GetBodyRange() < 1)
    {
		EventBossReleaseSkill::Emit(unit->selected_skill_id(), unit->move_object_id());
    }
  }
  return kAIResultSuccess;
}  

uint_32 IntentMonsterFight::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

// hit once, return to original ai state
uint_32 IntentMonsterFight::Update(army::MoveObject *unit, float delta_time)
{
  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }
  
  CharacterData* char_data = unit->character_card_data();
  int_32 selected_skill_id = unit->selected_skill_id();
  //1. Check skill
  battle::SkillData* skill_data = battle::BattleController::GetInstance().skill_sys()->skill_data();
  if (selected_skill_id == MW_INVALID_ID 
      || !skill_data->GetSkillBaseIsValid(selected_skill_id)) 
  {
    unit->set_ai_state(unit->ai_orig_state());
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
    return kAIResultSuccess;
  }

  //2. Skill hitting, only update in this code section
  if (skill_data->GetSkillBaseSkillType(selected_skill_id))
  {
    // power skill goes to here
    if(skill_data->GetSkillBasePowerSkill(selected_skill_id))
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateReleaseSkillTriple);

      eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

      if(ret == kMotionResultCompelted)
      {
        unit->set_ai_state(unit->ai_orig_state());
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
      }
    }
    // normal skill goes to here
    else
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateReleaseSkill);

      eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->
        Update(unit, delta_time);

      if(ret == kMotionResultCompelted)
      {
        unit->set_ai_state(unit->ai_orig_state());
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
      }
    }

    return kAIResultSuccess;
  }

  //3. Check target
  if (!skill_data->GetSkillBaseSkillType(selected_skill_id)
      && unit->target_selection()->target_id() == army::kUnexistTargetId) 
  {
    unit->set_ai_state(unit->ai_orig_state());
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
    return kAIResultSuccess;
  }

  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

  //4. Normal hitting
  if(unit->motion_state() == kMotionStateNormalHit)
  {
    //normal hit completed, change to idle 
    if(ret == kMotionResultCompelted)
    {
      unit->set_ai_state(unit->ai_orig_state());
      ai::AIStateMachine::GetInstance().MotionMachine()->
        ChangeMotion(unit, kMotionStateIdle);
      return kAIResultSuccess;
    }
    //in normal hitting, skip
    else
    {
      return kAIResultSuccess;
    }
  }
  //5. Hash to pos
  else if (unit->motion_state() == kMotionStateHashPosition)
  { // move to target motion finished, hash fight pos before hit
    if(ret == kMotionResultCompelted)
    {
      if(unit->normal_skill_cool_time() >= unit->attack_speed())
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateNormalHit);
      else
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
      return kAIResultSuccess;
    }// in hash pos state, skip
    else
    {
      return kAIResultSuccess;
    }
  }

  //hash pos before normal hit
  if (/*unit->last_motion_state() != kMotionStateNormalHit &&*/
      battle::BattleController::GetInstance().tiled_map()->IsAnyMoveObjectInOwnTileTooNearBy(unit->move_object_id(), unit->tile_index()))
  {
    cocos2d::CCPoint target_pos = unit->current_pos();
    cocos2d::CCPoint fitablePos = battle::BattleController::GetInstance().tiled_map()-> \
      FindEmptyFitablePointPositionForMoveObjectFight(unit->move_object_id(), target_pos);
    if (ccpDistanceSQ(fitablePos, target_pos) > 0.1f)
    {
      unit->target_selection()->set_hash_position(fitablePos);
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateHashPosition);
      return kAIResultSuccess;
    }
  }
  unit->target_selection()->set_target_id_point_offset(0);
  if(unit->normal_skill_cool_time() >= unit->attack_speed())
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateNormalHit);
  else
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);

  return kAIResultSuccess;
}
  
} // namespace ai
} // namespace taomee
