//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_warrior.cpp
//        Author: peteryu
//          Date: 2013/10/29 19:45
//   Description: 
//

#include "game/artificial_intelligence/intent_state/intent_monster_warrior.h"

#include "engine/animation/skeleton_animation.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/artificial_intelligence/ai_config.h"

namespace taomee {
namespace ai {
  
uint_32 IntentMonsterWarrior::OnEnter(army::MoveObject *unit)
{
	ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  return kAIResultSuccess;
}  

uint_32 IntentMonsterWarrior::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

uint_32 IntentMonsterWarrior::Update(army::MoveObject *unit, float delta_time)
{
  ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }

  // skill time
  //if(OnMonsterReleaseSkill(unit))
  //  return kAIResultSuccess;   
  
  CharacterData* cardData = unit->character_card_data();

  //near attack anytime
  if(unit->near_attack_trigger() &&
    unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
    unit->target_selection()->set_target_id_point_offset(unit->near_attack_trigger()->
      GetClosestIdPointOffset());
    if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
    {
      if(OnMonsterReleaseSkill(unit))
        return kAIResultSuccess; 

      unit->set_selected_skill_id(this->GetRandomSkill(unit, 
        cardData->GetSkillId(kSkillNormalHitNear)));
      unit->set_ai_state(kAIStateMonsterFight);
    }
    else
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
    }
    return kAIResultSuccess;
  }

  //move
  //need not stay on column
  int stay_col = 0;
  if(unit->stage_stay_column() == -1)
  {
    stay_col = 0;
  }
  else
  {
    stay_col = unit->stage_stay_column();
  }

  cocos2d::CCPoint stay_col_pos = battle::GetCenterPointPositionInTile(
    battle::GetTileIndexByTileCoordinatePos(ccp(stay_col, unit->GetCurrentRowIndex())));

  // firstly born, move to stay column
  if(unit->current_pos().x < stay_col_pos.x && unit->stage_state() == army::kStageBorn)
  {
    unit->target_selection()->set_target_pos(ccp(stay_col_pos.x, unit->current_pos().y));
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, 
      kMotionStateMovePosition);
    unit->set_stage_time(0.0f);
    return kAIResultSuccess;
  }

  //default warrior dose not stay for long time
  if(unit->stage_stay_column() == -1)
  {
    if(unit->stage_state() == army::kStageBorn)
      unit->set_stage_state(army::kStageMoveEnd);
  }
  //guard warrior stay on one column
  else
  {
    if(unit->stage_state() == army::kStageBorn)
      unit->set_stage_state(army::kStageAttack);
    if(unit->stage_state() == army::kStageAttack && unit->stage_time() >= AIConfig::GetInstance().GetNearAttackerAIStayTime())
      unit->set_stage_state(army::kStageMoveEnd);
  }

  if(unit->stage_state() == army::kStageAttack)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle); 
  }
  // nothing to do, move to terminal point
  else if(unit->stage_state() == army::kStageMoveEnd)
  {
	  if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
	  {
	  }
	  else
	  {
		  unit->target_selection()->set_target_pos(ccp(battle::kMapRightMostX, unit->current_pos().y));
		  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMovePosition); 
	  }
	  
  }

  return kAIResultSuccess;
}
  
} // namespace ai
} // namespace taomee
