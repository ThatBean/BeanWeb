//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_monk.h
//        Author: peteryu
//          Date: 2013/10/31 10:54
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/31      add
//                                obsoleted
//////////////////////////////////////////////////////////////

#ifndef INTENT_MONSTER_MONK_H
#define INTENT_MONSTER_MONK_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentMonsterMonk :public AIState
{
public:
  IntentMonsterMonk() {}
  virtual ~IntentMonsterMonk() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif 
