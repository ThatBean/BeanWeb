//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ai_state_machine.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  10:56
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"

#include "game/army/unit/move_object.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "game/artificial_intelligence/intent_state/intent_common.h"
#include "game/artificial_intelligence/intent_state/intent_guard.h"
#include "game/artificial_intelligence/intent_state/intent_fight.h"
#include "game/artificial_intelligence/intent_state/intent_dead.h"
#include "game/artificial_intelligence/intent_state/intent_cure.h"
#include "game/artificial_intelligence/intent_state/intent_celebrate.h"
#include "game/artificial_intelligence/intent_state/intent_monster_warrior.h"
#include "game/artificial_intelligence/intent_state/intent_monster_archer.h"
//#include "game/artificial_intelligence/intent_state/intent_monster_monk.h"
#include "game/artificial_intelligence/intent_state/intent_monster_skiller.h"
#include "game/artificial_intelligence/intent_state/intent_monster_fight.h"
#include "game/artificial_intelligence/intent_state/intent_monster_assassin.h"
#include "game/artificial_intelligence/intent_state/intent_monster_big_boss.h"
//#include "game/artificial_intelligence/intent_state/intent_pvp.h"
#include "game/artificial_intelligence/intent_state/intent_default.h"
#include "game/artificial_intelligence/motion_state/motion_state_constants.h"
#include "game/battle/battle_hub.h"

namespace taomee {
namespace ai {
  
AIStateMachine& AIStateMachine::GetInstance()
{
  static AIStateMachine* X = NULL;
  if (!X)
  {
    X = new AIStateMachine();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
  }
  return *X;
}


AIStateMachine::AIStateMachine()
{
  memset(intentStates, 0, sizeof(AIState*)*kAIStateMax);
  this->Init();
  motion_machine_ = new MotionStateMachine();
  motion_machine_->Init();
}
  
AIStateMachine::~AIStateMachine()
{
  this->ShutDown();
  delete motion_machine_;
}
  
bool AIStateMachine::Init()
{
//  this->registerState(kAIStateCommon, new IntentCommon);
  this->registerState(kAIStateGuard, new IntentGuard);
  this->registerState(kAIStateFight, new IntentFight);
  this->registerState(KAIStateDead, new IntentDead);
  this->registerState(KAIStateCure, new IntentCure);
  this->registerState(kAIStateCelebrate, new IntentCelebrate);
  this->registerState(kAIStateMonsterWarrior, new IntentMonsterWarrior);
  this->registerState(kAIStateMonsterArcher, new IntentMonsterArcher);
  //this->registerState(kAIStateMonsterMonk, new IntentMonsterMonk);
  this->registerState(kAIStateMonsterSkiller, new IntentMonsterSkiller);
  this->registerState(kAIStateMonsterFight, new IntentMonsterFight);
  this->registerState(kAIStateMonsterAssassin, new IntentMonsterAssassin);
  this->registerState(kAIStateMonsterBigBoss, new IntentMonsterBigBoss);
  this->registerState(kAIStateDefault, new IntentDefault);
  return true;
}
  
void AIStateMachine::ShutDown()
{
  for (int i = 0; i<kAIStateMax; ++i)
  {
    if (intentStates[i])
    {
      delete intentStates[i];
      intentStates[i] = NULL;
    }
  }
}
  
bool AIStateMachine::registerState(eAIStateType ai_type,
                                   AIState *state)
{
  assert(ai_type>kAIStateInvalid &&
         ai_type<kAIStateMax);
  // register yet
  if (intentStates[ai_type]) {
    return false;
  }
  else { // empty one, register it
    intentStates[ai_type] = state;
    return true;
  }
}
  
// update all move objects on battle field with delta time  
uint_32 AIStateMachine::Update(float delta_time)
{
  return kAIResultSuccess;
}
  
// update one single unit on battle filed with delta time
uint_32 AIStateMachine::Update(army::MoveObject *unit, float delta_time)
{
  eAIStateType ai_state = unit->ai_state();
  eAIStateType last_ai_state = unit->last_ai_state();
  
  if(!IS_VALID_AI_STATE(ai_state) || !intentStates[ai_state])
  {
    return kAIResultInvalid;
  }

  if(ai_state != last_ai_state)
  {
    if(IS_VALID_AI_STATE(last_ai_state) && intentStates[last_ai_state])
    {
      intentStates[last_ai_state]->OnLeave(unit);
    }

    if(intentStates[ai_state])
    {
      intentStates[ai_state]->OnEnter(unit);
    }

    unit->last_ai_state_ = ai_state;

    CCLOG("ID: %ld, AIState: %s", unit->move_object_id(), GetAIStateName(unit->ai_state()).c_str());
  }
  
  intentStates[ai_state]->Update(unit, delta_time);

  return kAIResultSuccess;
}
  
} // namespace ai
} // namespace taomee
