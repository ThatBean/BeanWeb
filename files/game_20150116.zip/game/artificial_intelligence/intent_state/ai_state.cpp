//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ai_state.cpp
//        Author: peteryu
//          Date: 2013/10/19 10:46
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/19      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/intent_state/ai_state.h"

#include "engine/base/basictypes.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_data_table.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/battle/own_hub.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_controller.h"

namespace taomee {
namespace ai {

bool AIState::OnUserOperation(army::MoveObject* unit, float delta_time)
{
  if(!unit->target_selection()->is_forced_move_to())
  {
    return false;
  }

  GHOST_DEBUG(0);

  CharacterData* char_data = unit->character_card_data();

  eMotionStateType result_motion = kMotionStateIdle;

  // 1.1 drag to monster
  if(unit->target_selection()->choosen_target_id() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->target_selection()->choosen_target_id());
    result_motion = kMotionStateMoveTarget;
    GHOST_DEBUG(1);
  }

  // 1.2 drag to pos
  if(unit->target_selection()->target_position_isvalid() && 
    ccpDistanceSQ(unit->current_pos(), unit->target_selection()->target_position()) != 0)
  {
    result_motion = kMotionStateMovePosition;
    GHOST_DEBUG(2);
  }

  
  // 1.3 we need NOT attack enemy that on the way to target or pos, except previous target

  if(unit->near_attack_trigger() &&
     unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId && 
     unit->near_attack_trigger()->GetClosestId() == unit->target_selection()->choosen_target_id())
  {
    unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
    unit->set_ai_state(kAIStateFight);
    GHOST_DEBUG(3);
    return true;
  }

  // 1.3 we need attack enemy that on the way to target or pos, except previous target
/*
  if(unit->near_attack_trigger() &&
     unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId && 
     unit->near_attack_trigger()->GetClosestId() != unit->target_selection()->previous_target_id())
  {
    unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
    unit->target_selection()->set_previous_target_id(unit->target_selection()->target_id());
    unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
    unit->set_ai_state(kAIStateFight);
    GHOST_DEBUG(3);
    return true;
  }
*/

  // 1.4 user operation over
  if (unit->target_selection()->target_position_isvalid()) 
  {
    GHOST_DEBUG(4);
    if (ccpDistanceSQ(unit->current_pos(), unit->target_selection()->target_position()) < 1.0f)
    {
      unit->target_selection()->resetTargetSelection();
      GHOST_DEBUG(5);
      return true;
    }
  }
  else if(unit->target_selection()->choosen_target_id() == army::kUnexistCardId)
  {
    GHOST_DEBUG(6);
    unit->target_selection()->resetTargetSelection();
    return true;
  }

  GHOST_DEBUG(7);
  if ( (controllable_status_flag_ & ai::kControllableStatus_CannotMove) && 
	  (kMotionStateMovePosition == result_motion || kMotionStateMoveTarget == result_motion ))
  {
	  if ( kMotionStateMovePosition == result_motion )
	  {
		  UpdataUnitDirectionByTargetPoint(unit);
	  }
	  else if (kMotionStateMoveTarget == result_motion)
	  {
		  UpdataUnitDirectionByTatgetId(unit);
	  }
	  ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
	  return false;
  }
  
  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, result_motion);
  ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  return true;
}
  
bool AIState::OnUncontrollableStatus(army::MoveObject* unit, float delta_time)
{
  UpdataControllableStatus(unit, delta_time);

  eMotionStateType cType = unit->motion_state();
  if (controllable_status_flag_ & ai::kControllableStatus_Disable ||
	  cType==kMotionStateKO || cType==kMotionStateStunned || 
	  cType==kMotionStateAttackReflect || cType==kMotionStatePetrifaction)
  {
    // update kMotionStateKO / kMotionStateStunned
    eMotionUpdateResult result = ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
    // change to idle if finished
    if (result == kMotionResultCompelted)
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
    }
    if (cType==kMotionStateStunned || cType==kMotionStatePetrifaction || cType==kMotionStateReleaseSkill)
      unit->target_selection()->resetTargetSelection();
    
    if(unit->anima_node()->getChildByTag(kSkillArmatureTag))
    {
      unit->anima_node()->removeChildByTag(kSkillArmatureTag);
    }

    if (unit->selected_skill_id() != kSkillInvaild) 
      unit->set_selected_skill_id(kSkillInvaild);
    return true;
  }
  else
  {
    return false;
  }
}

void AIState::UpdataUnitDirectionByTargetPoint(army::MoveObject* unit)
{
	cocos2d::CCPoint targetPoint = unit->target_selection()->target_position();
	cocos2d::CCPoint current_pos = unit->current_pos();
	if (abs(targetPoint.x - current_pos.x) > 50)
	{
		if (targetPoint.x>current_pos.x) {
			unit->set_anima_direction(kDirectionRight);
		}
		else {
			unit->set_anima_direction(kDirectionLeft);
		}
	}
}

void AIState::UpdataUnitDirectionByTatgetId(army::MoveObject* unit)
{
	army::MoveObject *target_obj = battle::BattleController::GetInstance().GetObjectById(unit->target_selection()->target_id());
	if(!target_obj || !target_obj->is_active())
		 return;

	cocos2d::CCPoint targetPoint = target_obj->offset_points_count() > 1 ? target_obj->get_pos_by_offset(unit->target_selection()->target_id_point_offset()) : target_obj->current_pos();
	cocos2d::CCPoint current_pos = unit->current_pos();
	if (abs(targetPoint.x - current_pos.x) > 50)
	{
		if (targetPoint.x>current_pos.x) {
			unit->set_anima_direction(kDirectionRight);
		}
		else {
			unit->set_anima_direction(kDirectionLeft);
		}
	}
}

int AIState::UpdataControllableStatus(army::MoveObject* unit, float delta_time)
{
	controllable_status_flag_ = kControllableStatus_Enable;
	if ( unit->check_battle_status_flag( battle::kDamageStunned) ||
		 unit->check_battle_status_flag( battle::kDamageFreeze) ||
		 unit->check_battle_status_flag( battle::kDamagePetrifaction) ||
		 unit->check_battle_status_flag( battle::kDamageRepel) /*|| 
		 unit->check_battle_status_flag( battle::kDamageEnchantment) */)
	{
		controllable_status_flag_ |= kControllableStatus_Disable;
	}

	if ( unit->check_battle_status_flag( battle::kDamageIntertwine) )
	{
		controllable_status_flag_ |= kControllableStatus_CannotMove;
	}
	
	if ( unit->check_battle_status_flag( battle::kDamageSilence))
	{
		controllable_status_flag_ |= kControllableStatus_CannotSkill;
	}

	return controllable_status_flag_;
}

int AIState::GetRandomSkill(army::MoveObject* unit, int normal_skill_id)
{
  CharacterData* char_data = unit->character_card_data();
  if(char_data->GetSkillId(kSkillSkill) == kSkillInvaild)
    return normal_skill_id;

  if(flipProbability(char_data->GetSkillRate() / 100.0f))
    return char_data->GetSkillId(kSkillSkill);

  return normal_skill_id;
}

bool AIState::OnMonsterReleaseSkill(army::MoveObject* unit)
{
  if(unit->stage_state() == army::kStageBorn)
    return false;

  // force release skill goes to here
  if(unit->play_skill_id() != kSkillInvaild)
  {
    unit->set_selected_skill_id(unit->play_skill_id());
    unit->set_play_skill_id(kSkillInvaild);
    unit->set_ai_state(kAIStateMonsterFight);
    return true;
  }

  CharacterData* char_data = unit->character_card_data();
  int skill_id = char_data->GetSkillId(kSkillSkill);

  if(skill_id == kSkillInvaild)
    return false;

  SkillBase *skill_data = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);

  //if(unit->normal_skill_cool_time() >= char_data->GetAtkSpeed())
  {
    if(unit->skill_cool_time() >= skill_data->GetCDTick())
    {
      //if(GetRandomSkill(unit, kSkillInvaild) == skill_id)
      {
        unit->set_selected_skill_id(skill_id);
        unit->set_ai_state(kAIStateMonsterFight);
        return true;
      }
    }
  }

  return false;
}

bool AIState::OnForceCharacterReleaseSkill(army::MoveObject* unit)
{
  CharacterData* char_data = unit->character_card_data();
  int skill_id = char_data->GetSkillId(kSkillSkill);
  if(skill_id == kSkillInvaild)
    return false;
  SkillBase *skill_data = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
  //if(unit->normal_skill_cool_time() >= char_data->GetAtkSpeed())
  {
    if(unit->skill_cool_time() >= skill_data->GetCDTick() + char_data->GetAtkSpeed())
    {
      taomee::army::TroopsHub * troop = unit->owner_hub()->troops();

      if (battle::BattleController::GetInstance().CanSkillBeReseaseOrNot(unit->move_object_id()))
      //if (0 == random_int(troop->active_ids().size()) && ((int)(unit->skill_cool_time() * 10000) % 100 < 15))
        //if(GetRandomSkill(unit, kSkillInvaild) == skill_id)
      {
        unit->set_selected_skill_id(skill_id);
        unit->set_ai_state(kAIStateFight);
        return true;
      }
    }
  }
  return false;
}

bool AIState::ForceReleaseSkill(army::MoveObject* unit)
{
  CharacterData* char_data = unit->character_card_data();
  int skill_id = char_data->GetSkillId(kSkillSkill);

  if(skill_id == kSkillInvaild)
    return false;

  SkillBase *skill_data = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);

  ////if(unit->normal_skill_cool_time() >= char_data->GetAtkSpeed())
  {
    //if(unit->skill_cool_time() >= skill_data->GetCDTick() + char_data->GetAtkSpeed())
    {
      //if (unit->selected_skill_id() == MW_INVALID_ID)
      //{
        unit->set_selected_skill_id(skill_id);
      //}
      unit->set_ai_state(kAIStateFight);
      return true;
    }
  }

  return false;
}

} // namespace taomee
} // namespace ai

