//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_dead.h
//        Author: peteryu
//          Date: 2013/10/10 17:39
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/10      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_DEAD_H
#define INTENT_DEAD_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentDead :public AIState
{
public:
  IntentDead() {}
  virtual ~IntentDead() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif
