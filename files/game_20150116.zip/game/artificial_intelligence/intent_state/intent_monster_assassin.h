//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_assassin.h
//        Author: peteryu
//          Date: 2013/11/11 17:11
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/11/11      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_MONSTER_ASSASSIN_H
#define INTENT_MONSTER_ASSASSIN_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentMonsterAssassin :public AIState
{
public:
  IntentMonsterAssassin() {}
  virtual ~IntentMonsterAssassin() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);

  // search row that have fewest enemy and does not have teammate assassin
  int_8           GetFewestEnemyWithoutAssassinRowNo(army::MoveObject* unit);
};
  
} // namespace ai
} // namespace taomee

#endif 
