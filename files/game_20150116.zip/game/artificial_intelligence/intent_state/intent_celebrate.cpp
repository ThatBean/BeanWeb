//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  intent_celebrate.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-29
//          Time:  2:30
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-29        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/intent_state/intent_celebrate.h"

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/character.h"
#include "engine/animation/skeleton_animation.h"
#include "game/battle/tiled_map/coordinate_helper.h"

namespace taomee {
namespace ai {

uint_32 IntentCelebrate::OnEnter(army::MoveObject *unit)
{
  int_8 tileIdx = dynamic_cast<army::Character*>(unit)->garrison_tile_index();
  cocos2d::CCPoint dest_pos = battle::GetGarrisonPointForMoveObjectInTile(tileIdx);
  if (tileIdx<2*battle::kMapColumnCount)
  {
    dest_pos = ccpAdd(dest_pos, ccp(-0.5f*battle::kMapTileAverageLength, 0));
  }
  unit->target_selection()->set_target_pos(dest_pos);
  unit->set_idle_time(0.0f);
  ai::AIStateMachine::GetInstance().MotionMachine()->
    ChangeMotion(unit, ai::kMotionStateMovePosition);
  return kAIResultSuccess;
}

uint_32 IntentCelebrate::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

uint_32 IntentCelebrate::Update(army::MoveObject *unit, float delta_time)
{
  if (unit->motion_state() == kMotionStateIdle)
  {
    if (unit->idle_time()>1.0f)
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->
        ChangeMotion(unit, ai::kMotionStateNormalHit);
    }
    unit->set_idle_time(unit->idle_time()+delta_time);
  }
  eMotionUpdateResult ret = AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  if (ret == kMotionResultCompelted)
  {
    if (unit->motion_state()==kMotionStateMovePosition)
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->
        ChangeMotion(unit, ai::kMotionStateIdle);
      unit->set_anima_direction(kDirectionLeft);
    }
    else if (unit->is_active() && unit->motion_state()==kMotionStateNormalHit)
    {
      // stop animation
      unit->anima_node()->Stop();
      unit->set_is_active(false);
    }
  }
  return kAIResultSuccess;
}

} // namespace ai
} // namespace taomee