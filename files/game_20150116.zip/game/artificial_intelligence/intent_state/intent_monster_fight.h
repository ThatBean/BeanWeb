//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_fight.h
//        Author: peteryu
//          Date: 2013/10/31 15:49
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/31      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_MONSTER_FIGHT_H
#define INTENT_MONSTER_FIGHT_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentMonsterFight :public AIState
{
public:
  IntentMonsterFight() {}
  virtual ~IntentMonsterFight() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif
