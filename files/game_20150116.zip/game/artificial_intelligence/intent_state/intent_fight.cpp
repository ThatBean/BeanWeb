//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  intent_fight.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  02:27
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/intent_state/intent_fight.h"

#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/unit_constants.h"
#include "game/army/unit/monster.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/battle/battle_controller.h"
#include "game/battle/monster_hub.h"
#include "game/battle/own_hub.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/skill/skill_constants.h"
#include "game/skill/skill_data.h"
#include "game/skill/skill_system.h"

namespace taomee {
namespace ai {
  
uint_32 IntentFight::OnEnter(army::MoveObject *unit)
{
  return kAIResultSuccess;
}  

uint_32 IntentFight::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

/*
  1. Check skill, invalid - return to original state
  2. Skill hitting, motion update - return, motion completed - return to original state
  3. Check target if current skill is normal hit, none target - return to original state
  4. Normal hitting, motion update - return, motion completed - change to idle&return
  5. Hash to pos, motion update - return, motion completed - change to normal hit(hash before normal hit)
  6. Near attack
  7. Far attack
*/
uint_32 IntentFight::Update(army::MoveObject *unit, float delta_time)
{
	// stunned / KO status
	if (OnUncontrollableStatus(unit, delta_time))
	{
		return kAIResultSuccess;
	}
  
	GHOST_DEBUG(16);
	CharacterData* char_data = unit->character_card_data();

	battle::SkillData* skill_data = battle::BattleController::GetInstance().skill_sys()->skill_data();
	int_32 selected_skill_id = unit->selected_skill_id();
	int_32 trigger_skill_id = unit->trigger_skill_id();
	bool is_skill_hit = false;
	bool is_trigger_hit = false;
	bool is_normal_hit = false;
	if ( selected_skill_id != MW_INVALID_ID && skill_data->GetSkillBaseIsValid( selected_skill_id ) )
	{
		is_skill_hit = skill_data->GetSkillBaseSkillType(selected_skill_id);
		is_normal_hit = !is_skill_hit;
	}
	
	if (trigger_skill_id != MW_INVALID_ID && skill_data->GetSkillBaseIsValid( trigger_skill_id ))
	{
		is_trigger_hit = true;
	}

	if ( !is_skill_hit && !is_trigger_hit && !is_normal_hit)
	{
		unit->set_ai_state(unit->ai_orig_state());
		GHOST_DEBUG(17);
		return kAIResultSuccess;
	}
  
	//2. Skill hitting, only update in this code section
	if (is_skill_hit) 
	{
		ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateReleaseSkill);

		eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

		if(ret == kMotionResultCompelted)
		{
			unit->set_selected_skill_id(MW_INVALID_ID);
			unit->set_ai_state(unit->ai_orig_state());
		}

		return kAIResultSuccess;
	}
	else if ( is_trigger_hit )
	{	
		if(unit->normal_skill_cool_time() >= unit->attack_speed())
		{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateTriggerSkill);

			eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

			if(ret == kMotionResultCompelted)
			{
				unit->set_trigger_skill_id(MW_INVALID_ID);
				unit->set_ai_state(unit->ai_orig_state());
			}
		}
		else
		{
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
		}

		return kAIResultSuccess;
	}
	else
	{
		//3. Check target
		int_32 selection_target_id = unit->target_selection()->target_id();
		army::MoveObject *targer_unit = battle::BattleController::GetInstance().GetObjectById(selection_target_id);
		if (( !is_skill_hit &&  selection_target_id == army::kUnexistTargetId ) || 
			!targer_unit || 
			!targer_unit->is_active() || 
			targer_unit->is_temp_dead())
		{
			unit->set_ai_state(unit->ai_orig_state());
			unit->set_current_animation_state(kMotionResultCompelted);
			GHOST_DEBUG(18);
			return kAIResultSuccess;
		}

		eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

		//4. Normal hitting
		if(unit->motion_state() == kMotionStateNormalHit)
		{
			//normal hit completed, change to idle 
			if(ret == kMotionResultCompelted)
			{
				// heal
				army::eCareerType career_type = unit->GetCareerType();
				if (career_type == army::kCareerTypeMonk &&
					selected_skill_id == char_data->GetSkillId(kSkillNormalHitFar))
				{
					ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
					unit->set_ai_state(unit->ai_orig_state());
					return kAIResultSuccess;
				}
				GHOST_DEBUG(19);
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);

				switch(battle::BattleController::GetInstance().getBattleType())
				{
				case battle::kBattleType_Main:
				case battle::kBattleType_SandBox:
					{ 

					}
					break;
				case battle::kBattleType_Pvp:
					{
						if(OnForceCharacterReleaseSkill(unit))
							return kAIResultSuccess;
					}
					break;
				default:
					break;
				}

				return kAIResultSuccess;
			}
			//in normal hitting, skip
			else
			{
				GHOST_DEBUG(20);
				return kAIResultSuccess;
			}
		}
		//5. Hash to pos
		else if (unit->motion_state() == kMotionStateHashPosition)
		{ // move to target motion finished, hash fight pos before hit
			GHOST_DEBUG(21);
			if(ret == kMotionResultCompelted)
			{
				if(unit->normal_skill_cool_time() >= unit->attack_speed())
				{
					ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateNormalHit);
					GHOST_DEBUG(22);
				}
				else
				{
					ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
					GHOST_DEBUG(23);
				}

				switch(battle::BattleController::GetInstance().getBattleType())
				{
				case battle::kBattleType_Main:
				case battle::kBattleType_SandBox:
					{ 

					}
					break;
				case battle::kBattleType_Pvp:
					{
						if(OnForceCharacterReleaseSkill(unit))
							return kAIResultSuccess;
					}
					break;
				default:
					break;
				}

				return kAIResultSuccess;
			}// in hash pos state, skip
			else
			{
				GHOST_DEBUG(24);
				return kAIResultSuccess;
			}
		}
		// 6. attack reflect
		else if (unit->motion_state() == kMotionStateAttackReflect)
		{
			if (ret == kMotionResultCompelted)
			{
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
			}
			else
			{
				return kAIResultSuccess;
			}
		}

		//7. NearAttack
		if(unit->near_attack_trigger() &&
			unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
		{
			GHOST_DEBUG(25);
			//hash pos before normal hit
			if (/*unit->last_motion_state() != kMotionStateNormalHit && */
				battle::BattleController::GetInstance().tiled_map()->IsAnyMoveObjectInOwnTileTooNearBy(unit->move_object_id(), unit->tile_index()))
			{
				cocos2d::CCPoint target_pos = unit->current_pos();
				cocos2d::CCPoint fitablePos = battle::BattleController::GetInstance().tiled_map()-> \
					FindEmptyFitablePointPositionForMoveObjectFight(unit->move_object_id(), target_pos);
				if (ccpDistanceSQ(fitablePos, target_pos) > 0.1f)
				{
					unit->target_selection()->set_hash_position(fitablePos);
					ai::AIStateMachine::GetInstance().MotionMachine()->
						ChangeMotion(unit, kMotionStateHashPosition);
					return kAIResultSuccess;
				}
			}

			unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
			unit->target_selection()->set_target_id_point_offset(unit->near_attack_trigger()->GetClosestIdPointOffset());
			unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
			if(unit->normal_skill_cool_time() >= unit->attack_speed())
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateNormalHit);
			else {
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);

				switch(battle::BattleController::GetInstance().getBattleType())
				{
				case battle::kBattleType_Main:
				case battle::kBattleType_SandBox:
					{ 

					}
					break;
				case battle::kBattleType_Pvp:
					{
						if(OnForceCharacterReleaseSkill(unit))
							return kAIResultSuccess;
					}
					break;
				default:
					break;
				}
			}
			return kAIResultSuccess;
		}

		//8. Far attack, in guard area, we do have far normal hit, hit it
		if(unit->guard_trigger() &&
			unit->guard_trigger()->GetClosestId() != army::kUnexistTargetId &&
			char_data->GetSkillId(kSkillNormalHitFar) != kSkillInvaild)
		{
			unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
			unit->target_selection()->set_target_id_point_offset(unit->guard_trigger()->
				GetClosestIdPointOffset());
			unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitFar));
			if(unit->normal_skill_cool_time() >= unit->attack_speed())
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateNormalHit);
			else {
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);

				switch(battle::BattleController::GetInstance().getBattleType())
				{
				case battle::kBattleType_Main:
				case battle::kBattleType_SandBox:
					{ 

					}
					break;
				case battle::kBattleType_Pvp:
					{
						if(OnForceCharacterReleaseSkill(unit))
							return kAIResultSuccess;
					}
					break;
				default:
					break;
				}
			}
			return kAIResultSuccess;
		}
		else 
		{
			if(selection_target_id == army::kUnexistTargetId)
			{
				unit->set_ai_state(unit->ai_orig_state());
				return kAIResultSuccess;
			}
			//monster or far attack do not track target
			if(selected_skill_id == char_data->GetSkillId(kSkillNormalHitNear))
			{
				if (unit->owner_hub()->IsCharacterHub())
				{
					if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove )
					{
						UpdataUnitDirectionByTatgetId(unit);
					}
					else
					{
						ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMoveTarget);
					}
					return kAIResultSuccess;
				}
			}
		}
		GHOST_DEBUG(26);
		unit->set_ai_state(unit->ai_orig_state());

		switch(battle::BattleController::GetInstance().getBattleType())
		{
		case battle::kBattleType_Main:
		case battle::kBattleType_SandBox:
			{ 

			}
			break;
		case battle::kBattleType_Pvp:
			{
				if(OnForceCharacterReleaseSkill(unit))
					return kAIResultSuccess;
			}
			break;
		default:
			break;
		}

		return kAIResultSuccess;
	}
}
  
} // namespace ai
} // namespace taomee
