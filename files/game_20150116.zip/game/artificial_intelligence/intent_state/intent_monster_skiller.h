//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_skiller.h
//        Author: peteryu
//          Date: 2013/12/5 17:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/12/5      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_MONSTER_SKILLER_H
#define INTENT_MONSTER_SKILLER_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentMonsterSkiller :public AIState
{
public:
  IntentMonsterSkiller() {}
  virtual ~IntentMonsterSkiller() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);

  int             GetDifferentCareerTeamateCount(army::MoveObject* unit);
};
  
} // namespace ai
} // namespace taomee

#endif 
