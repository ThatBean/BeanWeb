//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_dead.cpp
//        Author: peteryu
//          Date: 2013/10/10 17:40
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/10      add
//////////////////////////////////////////////////////////////


#include "game/artificial_intelligence/intent_state/intent_dead.h"

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "engine/animation/skeleton_animation.h"
#include "game/battle/battle_controller.h"

namespace taomee {
namespace ai {
  
uint_32 IntentDead::OnEnter(army::MoveObject *unit)
{
  AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateDead);
  return kAIResultSuccess;
}  

uint_32 IntentDead::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

uint_32 IntentDead::Update(army::MoveObject *unit, float delta_time)
{
  AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);
  return kAIResultSuccess;
}
  
} // namespace ai
} // namespace taomee
