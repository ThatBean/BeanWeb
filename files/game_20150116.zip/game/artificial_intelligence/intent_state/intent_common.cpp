//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  intent_common.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  11:21
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/intent_state/intent_common.h"


#include "engine/animation/skeleton_animation.h"

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "engine/animation/skeleton_animation.h"
#include "game/battle/battle_controller.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/monster_hub.h"
#include "game/army/unit/monster.h"
#include "game/battle/own_hub.h"
#include "game/army/unit/unit_constants.h"
#include "game/skill/skill_constants.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"

namespace taomee {
namespace ai {
  
uint_32 IntentCommon::OnEnter(army::MoveObject *unit)
{
  if (unit->motion_state()!=kMotionStateDead)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->\
      ChangeMotion(unit, kMotionStateMovePosition);
  }  
  return kAIResultSuccess;
}  

uint_32 IntentCommon::OnLeave(army::MoveObject *unit)
{
  if (unit->motion_state()!=kMotionStateDead)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->\
      ChangeMotion(unit, kMotionStateIdle);
  }
  return kAIResultSuccess;
}

uint_32 IntentCommon::Update(army::MoveObject *unit, float delta_time)
{
  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }
  
  CharacterData* cardData = unit->character_card_data();

  // 1 search near attack area firstly, needed for monster that does not have guard area
  if(unit->near_attack_trigger() &&
     unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
    unit->target_selection()->set_target_id_point_offset(unit->near_attack_trigger()->
      GetClosestIdPointOffset());
    unit->set_selected_skill_id(cardData->GetSkillId(kSkillNormalHitNear));
    unit->set_ai_state(kAIStateFight);
    return kAIResultSuccess;
  }

  // 2 search guard area secondly
  if(unit->guard_trigger() &&
    unit->guard_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
    unit->target_selection()->set_target_id_point_offset(unit->guard_trigger()->
      GetClosestIdPointOffset());
    if(cardData->GetSkillId(kSkillNormalHitFar) != kSkillInvaild)
      unit->set_selected_skill_id(cardData->GetSkillId(kSkillNormalHitFar));
    else
      unit->set_selected_skill_id(cardData->GetSkillId(kSkillNormalHitNear));

    unit->set_ai_state(kAIStateFight);
    return kAIResultSuccess;
  }

  // nothing to do, move to terminal point
  if(unit->motion_state() != kMotionStateMovePosition)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->
      ChangeMotion(unit, kMotionStateMovePosition);    
  }

  ai::AIStateMachine::GetInstance().MotionMachine()->Update(unit, delta_time);

  return kAIResultSuccess;
}
  
} // namespace ai
} // namespace taomee
