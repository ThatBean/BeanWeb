//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  intent_celebrate.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-29
//          Time:  2:30
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-29        1         create
//////////////////////////////////////////////////////////////

#ifndef __ChainChronicle__intent_celebrate__
#define __ChainChronicle__intent_celebrate__

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {

class IntentCelebrate :public AIState
{
public:
  IntentCelebrate() {}
  virtual ~IntentCelebrate() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};

} // namespace ai
} // namespace taomee

#endif /* defined(__ChainChronicle__intent_celebrate__) */
