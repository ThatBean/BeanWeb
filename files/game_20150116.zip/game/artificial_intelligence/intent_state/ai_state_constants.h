//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ai_state_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  9:40
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ai_state_constants_h
#define ChainChronicle_ai_state_constants_h

namespace taomee {
namespace ai {

enum eAIStateType
{
  kAIStateInvalid       = -1,
  kAIStateCommon        = 0,
  kAIStateGuard         = 1,
  kAIStateFight         = 2,
  KAIStateDead          = 3,
  KAIStateCure          = 4,
  kAIStateCelebrate     = 5,

  kAIStateMonsterFight            = 6,
  kAIStateMonsterWarrior          = 7,
  kAIStateMonsterArcher           = 8,
  kAIStateMonsterAssassin         = 9,
  kAIStateMonsterSkiller          = 10,
  kAIStateMonsterBigBoss          = 11,

  kAIStateDefault                 = 12,

  kAIStateMax,
};

enum eAIBornLine
{
  kAIBornRandom   = -1,
  kAIBornTop      = 0,
  kAIBornMiddle   = 1,
  kAIBornBottom   = 2,
};


enum eAIUpdateResult
{
  kAIResultInvalid      = -1,
  kAIResultSuccess      = 0,
  kAIResultFailed       = 1,
  kAIResultMax,
};  

#define IS_VALID_AI_STATE(state) (state > kAIStateInvalid && state < kAIStateMax)
#define MONSTER_STAGE_STOP_TIME 20

// get AIStateName by AIStateType, for debug output
static std::string GetAIStateName(eAIStateType type)
{
  switch(type)
  {
  case kAIStateCommon:
    return "kAIStateCommon";
  case kAIStateFight:
    return "kAIStateFight";
  case kAIStateGuard:
    return "kAIStateGuard";
  case kAIStateInvalid:
    return "kAIStateInvalid";
  case KAIStateDead:
    return "kAIStateDead";
  case KAIStateCure:
    return "KAIStateCure";
  case kAIStateCelebrate:
    return "kAIStateCelebrate";
  case kAIStateMonsterWarrior:
    return "kAIStateMonsterWarrior";
  case kAIStateMonsterArcher:
    return "kAIStateMonsterArcher";
  case kAIStateMonsterSkiller:
    return "kAIStateMonsterSkiller";
  case kAIStateMonsterAssassin:
    return "kAIStateMonsterAssassin";
  case kAIStateMonsterFight:
    return "kAIStateMonsterFight";
  case kAIStateMonsterBigBoss:
    return "kAIStateMonsterBigBoss";
  case kAIStateDefault:
    return "kAIStateDefault";
  default:
    return "kAIStateError";
  }
  return "";
}

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ai_state_constants_h
