#ifndef INTENT_DEFAULT_H
#define INTENT_DEFAULT_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentDefault :public AIState
{
public:
  IntentDefault() {}
  virtual ~IntentDefault() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif 
