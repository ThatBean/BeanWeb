//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_warrior.h
//        Author: peteryu
//          Date: 2013/10/29 17:40
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/29      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_MONSTER_WARRIOR_H
#define INTENT_MONSTER_WARRIOR_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentMonsterWarrior :public AIState
{
public:
  IntentMonsterWarrior() {}
  virtual ~IntentMonsterWarrior() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif 
