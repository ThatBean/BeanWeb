//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_warrior.cpp
//        Author: peteryu
//          Date: 2013/10/29 17:41
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/29      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/intent_state/intent_monster_archer.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/artificial_intelligence/ai_config.h"

namespace taomee {
namespace ai {
  
uint_32 IntentMonsterArcher::OnEnter(army::MoveObject *unit)
{
  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  return kAIResultSuccess;
}  

uint_32 IntentMonsterArcher::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

uint_32 IntentMonsterArcher::Update(army::MoveObject *unit, float delta_time)
{
  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()
    ->Update(unit, delta_time);

  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }

  // skill time
  //if(OnMonsterReleaseSkill(unit))
  //  return kAIResultSuccess;

  assert(unit->stage_stay_column() != -1);
  cocos2d::CCPoint stay_col_pos = battle::GetCenterPointPositionInTile(
    battle::GetTileIndexByTileCoordinatePos(ccp(unit->stage_stay_column(), 
    unit->GetCurrentRowIndex())));

  // firstly, move to stay column
  if(unit->current_pos().x < stay_col_pos.x && unit->stage_state() == army::kStageBorn)
  {
    unit->target_selection()->set_target_pos(ccp(stay_col_pos.x, unit->current_pos().y));
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, 
      kMotionStateMovePosition);
    unit->set_stage_time(0.0f);
    return kAIResultSuccess;
  }

  if(unit->stage_state() == army::kStageBorn)
    unit->set_stage_state(army::kStageAttack);
  if(unit->stage_state() == army::kStageAttack && unit->stage_time() >= AIConfig::GetInstance().GetRangAttackerAIStayTime())
    unit->set_stage_state(army::kStageMoveEnd);

  CharacterData* cardData = unit->character_card_data();

  // search near attack area
  if(unit->near_attack_trigger() &&
    unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
    unit->target_selection()->set_target_id_point_offset(unit->near_attack_trigger()->
      GetClosestIdPointOffset());
    if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
    {
      if(OnMonsterReleaseSkill(unit))
        return kAIResultSuccess;

      unit->set_selected_skill_id(this->GetRandomSkill(unit, 
        cardData->GetSkillId(kSkillNormalHitNear)));
      unit->set_ai_state(kAIStateMonsterFight);
    }
    else
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
    }
    return kAIResultSuccess;
  }

  // secondly, idle or far attack 20s
  if(unit->stage_state() == army::kStageAttack)
  {
    if(unit->target_selection()->is_forced_move_to())
    {
      // do not far attack when changing row
      if(unit->motion_state() == kMotionStateMovePosition && ret != kMotionResultCompelted)
      {
        return kAIResultSuccess;
      }
      unit->target_selection()->set_is_forced_move_to(false);
      return kAIResultSuccess;
    }

    if(unit->guard_trigger() &&
      unit->guard_trigger()->GetClosestId() != army::kUnexistTargetId)
    {
      unit->target_selection()->set_target_id(unit->guard_trigger()->GetClosestId());
      unit->target_selection()->set_target_id_point_offset(unit->guard_trigger()->
        GetClosestIdPointOffset());
      assert(cardData->GetSkillId(kSkillNormalHitFar) != kSkillInvaild);
      if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
      {
        if(OnMonsterReleaseSkill(unit))
          return kAIResultSuccess;

        unit->set_selected_skill_id(this->GetRandomSkill(unit, 
          cardData->GetSkillId(kSkillNormalHitFar)));
        unit->set_ai_state(kAIStateMonsterFight);
      }
      else
      {
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
      }
      return kAIResultSuccess;
    }
    // none enemy, change row
    else
    {
      // check other rows in this column, choose another row that does not have archer or wizard
      // search row that not empty
      int_8 next_rand = (random_int(100) % 2) ? -1 : 1;
      int_8 next_row = (unit->GetCurrentRowIndex() + next_rand + battle::kMapRowCount) % battle::kMapRowCount;
      std::list<army::MoveObject*>  row_list;
      unit->owner_hub()->enemy_hub()->GetAllMoveObjectsInOneRowByRowIndex(next_row, row_list);
      if(row_list.empty())
      {
        next_row = (next_row + next_rand + battle::kMapRowCount) % battle::kMapRowCount;
        unit->owner_hub()->enemy_hub()->GetAllMoveObjectsInOneRowByRowIndex(next_row, row_list);
      }
      
      if (row_list.empty())
      { // for all active characters were been killed yet.
        return kAIResultSuccess;
      }

      if(!IsHaveArcherOrWizardOrMonkInTile(unit, battle::GetTileIndexByTileCoordinatePos(
        ccp(unit->GetCurrentColumnIndex(),next_row))))
      {
		  if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
		  {

		  }
		  else
		  {
			  cocos2d::CCPoint next_row_pos = battle::GetGarrisonPointForMoveObjectInTile
				  (battle::GetTileIndexByTileCoordinatePos(ccp(unit->GetCurrentColumnIndex(), next_row)));

			  CCLog("Change Row: %d, %f, %f", next_row, next_row_pos.x, next_row_pos.y);
			  unit->target_selection()->set_target_pos(next_row_pos);
			  unit->target_selection()->set_is_forced_move_to(true);
			  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMovePosition);
		  }
      }
      else
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
      
      return kAIResultSuccess;
    }
  }

  // finally, move to end pos
  if(unit->stage_state() == army::kStageMoveEnd)
  {
	  if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
	  {
	  }
	  else
	  {
		unit->target_selection()->set_target_pos(ccp(battle::kMapRightMostX, unit->current_pos().y));
		ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMovePosition);
	  }
  }
  
  return kAIResultSuccess;
}

bool IntentMonsterArcher::IsHaveArcherOrWizardOrMonkInTile(army::MoveObject* unit, int_8 tile_no )
{
  std::list<army::MoveObject*> obj_list;
  unit->owner_hub()->GetAllMoveObjectsInTileWithIndex(tile_no, obj_list);
  for(std::list<army::MoveObject*>::iterator itr = obj_list.begin(); 
    itr != obj_list.end(); ++itr)
  {
    army::eCareerType career_type = (*itr)->GetCareerType();
    if(career_type == army::kCareerTypeWizard || 
       career_type == army::kCareerTypeArcher ||
       career_type == army::kCareerTypeMonk)
      return true;
  }
  return false;
}


} // namespace ai
} // namespace taomee
