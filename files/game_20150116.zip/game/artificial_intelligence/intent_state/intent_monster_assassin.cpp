//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_assassin.cpp
//        Author: peteryu
//          Date: 2013/11/11 17:11
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/11/11      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/intent_state/intent_monster_assassin.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/battle/battle_hub.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "game/artificial_intelligence/ai_config.h"

namespace taomee {
namespace ai {
  
uint_32 IntentMonsterAssassin::OnEnter(army::MoveObject *unit)
{
  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  return kAIResultSuccess;
}  

uint_32 IntentMonsterAssassin::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

uint_32 IntentMonsterAssassin::Update(army::MoveObject *unit, float delta_time)
{
  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()
    ->Update(unit, delta_time);

  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }

  // skill time
  //if(OnMonsterReleaseSkill(unit))
  //  return kAIResultSuccess;
  
  CharacterData* cardData = unit->character_card_data();

  assert(unit->stage_stay_column() != -1);
  cocos2d::CCPoint stay_col_pos = battle::GetCenterPointPositionInTile(
    battle::GetTileIndexByTileCoordinatePos(ccp(unit->stage_stay_column(), 
                                                unit->GetCurrentRowIndex())));

  // firstly, move to first column
  if(unit->current_pos().x < stay_col_pos.x && unit->stage_state() == army::kStageBorn)
  {
    unit->target_selection()->set_target_pos(ccp(stay_col_pos.x, unit->current_pos().y));
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit,
      kMotionStateMovePosition);
    unit->set_stage_time(0.0f);
    return kAIResultSuccess;
  }

  int select_row = -1;
  if(unit->stage_state() == army::kStageBorn)
  {
    unit->set_stage_state(army::kStageAttack);
    unit->set_stage_time(0.0f);
  }
  //search row path
  if(unit->stage_time() >= AIConfig::GetInstance().GetAssassinAISearchRowTime() && unit->stage_state() == army::kStageAttack)
  {
    unit->set_stage_state(army::kStageMoveEnd);
    unit->target_selection()->resetTargetSelection();
    select_row = GetFewestEnemyWithoutAssassinRowNo(unit);
    // for velocity bug, only multiple once  
    unit->set_move_speed_boost_multiple(0.5f);
  }

  // search near attack area
  if(unit->near_attack_trigger() &&
    unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
    unit->target_selection()->set_target_id_point_offset(unit->near_attack_trigger()->
      GetClosestIdPointOffset());
    if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
    {
      if(OnMonsterReleaseSkill(unit))
        return kAIResultSuccess;

      unit->set_selected_skill_id(this->GetRandomSkill(unit, cardData->GetSkillId(kSkillNormalHitNear)));
      unit->set_ai_state(kAIStateMonsterFight);
    }
    else
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
    }
    return kAIResultSuccess;
  }
  
  // search way in 3s
  if(unit->stage_state() == army::kStageAttack)
  {
    if(unit->target_selection()->is_forced_move_to())
    {
      if(unit->motion_state() == kMotionStateMovePosition && ret != kMotionResultCompelted)
      {
        return kAIResultSuccess;
      }
      unit->target_selection()->set_is_forced_move_to(false);
      return kAIResultSuccess;
    }
    // search next row random
	if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
	{

	}
	else
	{
		int_8 next_row = random_int(battle::kMapRowCount * 100) % battle::kMapRowCount;
		int col_index = unit->GetCurrentColumnIndex();
		cocos2d::CCPoint next_row_pos = battle::GetGarrisonPointForMoveObjectInTile
			(battle::GetTileIndexByTileCoordinatePos(ccp(unit->GetCurrentColumnIndex(), next_row)));

		unit->target_selection()->set_target_pos(ccp(unit->current_pos().x + 1, next_row_pos.y));
		unit->target_selection()->set_is_forced_move_to(true);

		ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMovePosition);
	}

    return kAIResultSuccess;
  }

  //select destination row to move
  if(unit->stage_state() == army::kStageMoveEnd)
  {
    //force move to selected row
    if(unit->target_selection()->is_forced_move_to())
    {
      if(unit->motion_state() == kMotionStateMovePosition && ret != kMotionResultCompelted)
      {
        return kAIResultSuccess;
      }
      unit->target_selection()->set_is_forced_move_to(false);
      unit->reset_move_speed_boost_multiple(0.5f);
      return kAIResultSuccess;
    }

    //first select one row
    if(select_row != -1)
    {
      cocos2d::CCPoint next_row_pos = battle::GetGarrisonPointForMoveObjectInTile
        (battle::GetTileIndexByTileCoordinatePos(ccp(unit->GetCurrentColumnIndex(), select_row)));

      unit->target_selection()->set_target_pos(ccp(unit->current_pos().x + 1, next_row_pos.y));
      unit->target_selection()->set_is_forced_move_to(true);
    }
    else
    {
		if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
		{

		}
		else
		{
			unit->target_selection()->set_target_pos(ccp(battle::kMapRightMostX, unit->current_pos().y));
			ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMovePosition); 
		}
    }
  }

  return kAIResultSuccess;
}

// search row that have fewest enemy and does not have teammate assassin
int_8 IntentMonsterAssassin::GetFewestEnemyWithoutAssassinRowNo(army::MoveObject* unit)
{
  int_8  next_rand = (random_int(100) % 2) ? -1 : 1;
  int_8 cur_row  = unit->GetCurrentRowIndex();
  int_8 next_row = cur_row;
  std::list<army::MoveObject*>  row_list;
  int min_enemy_count = 0x01 << 31;
  int min_enemy_row = -1;
  CharacterData* chara_data = NULL;
  bool is_row_have_assassin = false;

  do 
  {
    row_list.clear();
    is_row_have_assassin = false;

    unit->owner_hub()->GetAllMoveObjectsInOneRowByRowIndex(next_row, row_list);
    for(std::list<army::MoveObject*>::iterator itr = row_list.begin(); 
      itr != row_list.end(); ++itr)
    {
      chara_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter((*itr)->card_id());
      ai::eAIStateType ai_type = (ai::eAIStateType)chara_data->GetMoveType();
      if(ai_type == ai::kAIStateMonsterAssassin && unit->move_object_id() != (*itr)->move_object_id())
      {
        is_row_have_assassin = true;
        continue;
      }
    }

    if(!is_row_have_assassin)
    {
      unit->owner_hub()->enemy_hub()->GetAllMoveObjectsInOneRowByRowIndex(next_row, row_list);

      if(row_list.size() < min_enemy_count)
      {
        min_enemy_count = row_list.size();
        min_enemy_row   = next_row;
      }
    }
    next_row = (next_row + next_rand + battle::kMapRowCount) % battle::kMapRowCount;
  } while (next_row != cur_row);

  return min_enemy_row;
}

  
} // namespace ai
} // namespace taomee
