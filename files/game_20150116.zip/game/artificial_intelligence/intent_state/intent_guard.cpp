//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  intent_guard.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  02:27
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/intent_state/intent_guard.h"
#include "engine/base/basictypes.h"
#include "engine/animation/skeleton_animation.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/character.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/battle/battle_hub.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/skill/skill_constants.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"
#include "engine/base/random_helper.h"
#include "game/artificial_intelligence/ai_config.h"

namespace taomee {
namespace ai {
  
uint_32 IntentGuard::OnEnter(army::MoveObject *unit)
{
  if (unit->is_active())
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  }  
  //unit->target_selection()->set_previous_target_id(army::kUnexistCardId);
  return kAIResultSuccess;
}  

uint_32 IntentGuard::OnLeave(army::MoveObject *unit)
{
  if (unit->is_active())
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  }  
  return kAIResultSuccess;
}

// guarding, search enemy in any motion state with two conditions:
// 1. targetId is an exist id -- searching nearest target to hit,
//    if no other target exist on the road, hit the unique selected target
// 2. targetId is an unexist id -- searching nearest target to hit
uint_32 IntentGuard::Update(army::MoveObject *unit, float delta_time)
{
	if (OnUncontrollableStatus(unit, delta_time))
	{
		return kAIResultSuccess;
	}

	if(OnUserOperation(unit, delta_time))
	{
		return kAIResultSuccess;
	}

	CharacterData* char_data = unit->character_card_data();
	if ( controllable_status_flag_ & kControllableStatus_CannotSkill)
	{
		int skill_id = char_data->GetSkillId(kSkillSkill);
		if (unit->selected_skill_id() != skill_id)
		{
			unit->set_selected_skill_id(kSkillInvaild);
		}
	}


	if ( unit->trigger_skill_id() != kSkillInvaild)
	{
		unit->set_ai_state(kAIStateFight);
		return kAIResultSuccess;
	}


  unit->set_auto_search_tile_index(battle::kUnexistTileIndex);

	// 1 check near hit
	uint_32 near_attack_trigger_closest_id = army::kUnexistTargetId;
	ai::Trigger* near_attack_trigger = unit->near_attack_trigger();
	if ( near_attack_trigger )
	{
		near_attack_trigger_closest_id = near_attack_trigger->GetClosestId();
		if(near_attack_trigger_closest_id != army::kUnexistTargetId)
		{
			unit->target_selection()->set_target_id(near_attack_trigger_closest_id);
			unit->target_selection()->set_target_id_point_offset(near_attack_trigger->GetClosestIdPointOffset());
			unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
			unit->set_ai_state(kAIStateFight);
			GHOST_DEBUG(8);
			return kAIResultSuccess;
		}
	}

	// 2 check guard area
	uint_32 guard_trigger_closest_id = army::kUnexistTargetId;
	ai::Trigger* guard_trigger = unit->guard_trigger();
	if ( guard_trigger )
	{
		guard_trigger_closest_id = guard_trigger->GetClosestId();
		if( guard_trigger_closest_id != army::kUnexistTargetId)
		{
			army::MoveObject *target_obj = battle::BattleController::GetInstance().GetObjectById(guard_trigger_closest_id);
			if ( target_obj )
			{
				unit->target_selection()->set_target_id(guard_trigger_closest_id);
				unit->target_selection()->set_target_id_point_offset(guard_trigger->GetClosestIdPointOffset());
				GHOST_DEBUG(9);
				// determine which normal skill to use, near or far
				if(near_attack_trigger && near_attack_trigger_closest_id == guard_trigger_closest_id)
				{
					unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
					GHOST_DEBUG(10);

					GHOST_DEBUG(13);
					unit->set_ai_state(kAIStateFight);
					return kAIResultSuccess;
				}
				else
				{
					if(char_data->GetSkillId(kSkillNormalHitFar) != kSkillInvaild && 
						target_obj->is_active() &&
						abs(unit->current_pos().y - target_obj->current_pos().y) <= battle::kMapTileMinHeight / 8)
					{
						unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitFar));
						GHOST_DEBUG(11);
						GHOST_DEBUG(13);
						unit->set_ai_state(kAIStateFight);
						return kAIResultSuccess;
					}
					else
					{
						unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
						GHOST_DEBUG(12);
						GHOST_DEBUG(13);
						unit->set_ai_state(kAIStateFight);
						return kAIResultSuccess;
					}
				}
			}
		}
	}
  // end of 2

  // 3. auto fight model 
  battle::BattleController* battle_controller_ins = &(battle::BattleController::GetInstance());
  army::eCareerType career_type = unit->GetCareerType();
  if((ai::AIConfig::GetInstance().GetIsAutoFight() 
      && unit->motion_state() == kMotionStateIdle 
      && unit->idle_time() >= 1.5f 
     && unit->target_selection()->is_forced_move_to() == false) 
    || battle_controller_ins->getBattleType() == battle::kBattleType_Pvp)
  {
    switch(career_type)
    {
    //archer & wizards auto switch row that exists monster
    case army::kCareerTypeArcher:
    case army::kCareerTypeWizard:
      {
        int columnNo = unit->GetCurrentColumnIndex();
        int target_tile_index = -1;


        //need switch row
        if(columnNo >= 0 && columnNo < battle::kMapColumnCount)
        {
          target_tile_index = GetNearestRangeAttackIndex(unit);
          if(target_tile_index != -1)
          {
            cocos2d::CCPoint next_row_pos = battle::GetGarrisonPointForMoveObjectInTile(target_tile_index);
            unit->target_selection()->set_target_pos(next_row_pos);
            unit->target_selection()->set_is_forced_move_to(true);
            dynamic_cast<army::Character*>(unit)->set_garrison_tile_index(target_tile_index);
          }
        }
        break;
      }
    // warrior & knight guard own battle filed
    case army::kCareerTypeKnight:
    case army::kCareerTypeWarrior:
      {
        uint_32 monster_id = GetSameRowFristMonsterInOwnBattleField(unit);
        
        if(monster_id != army::kUnexistTargetId)
        {
          unit->target_selection()->set_target_id(monster_id);
          unit->set_selected_skill_id(char_data->GetSkillId(kSkillNormalHitNear));
          unit->set_ai_state(kAIStateFight);
          return kAIResultSuccess;
        }
        break;
      }
    default:
      break;
    }
  }

	// 4 back to tile
	// then the motion state check
	float cc_sq = 0.0f;
	if ( unit->owner_hub()->IsCharacterHub() )
	{
		army::Character* char_unit = dynamic_cast<army::Character*>(unit);
		cc_sq = ccpDistanceSQ(unit->current_pos(), battle::GetGarrisonPointForMoveObjectInTile(char_unit->garrison_tile_index()));
	}
	if (unit->motion_state() == kMotionStateIdle && cc_sq > 3.0f )
	{
		if (unit->idle_time() >= 2.0f) // TO DO : read from .csv file
		{
			cocos2d::CCPoint dest_pos = battle::GetGarrisonPointForMoveObjectInTile( \
				dynamic_cast<army::Character*>(unit)->garrison_tile_index());
			unit->target_selection()->set_target_pos(dest_pos);
			if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
			{
				//UpdataUnitDirectionByTargetPoint(unit);
			}
			else
			{
				ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, ai::kMotionStateMovePosition);
			}
		}
		else
		{
			unit->set_idle_time(unit->idle_time()+delta_time);
		}
		GHOST_DEBUG(14);
	}
  
  // motion's update at last
  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()->
    Update(unit, delta_time);

  if (ret == kMotionResultCompelted)
  {
     if (unit->motion_state()==kMotionStateMovePosition ||
         unit->motion_state()==kMotionStateMoveTarget ||
         unit->motion_state()==kMotionStateAttackReflect)
     {
       ai::AIStateMachine::GetInstance().MotionMachine()->
         ChangeMotion(unit, ai::kMotionStateIdle);
        if (unit->owner_hub()->IsRightSideHub())
        {
          unit->set_anima_direction(kDirectionLeft);
        }
        else
        {
          unit->set_anima_direction(kDirectionRight);
        }
       GHOST_DEBUG(15);
     }
  }
  
  return kAIResultSuccess;
}

int IntentGuard::GetNearestRangeAttackIndex(army::MoveObject* unit)
{
  if (unit->motion_state() != kMotionStateIdle) return -1;
  
  int unit_row = unit->GetCurrentRowIndex();
  int unit_col = unit->GetCurrentColumnIndex();
  int direction = (random_int(100) % 2) ? 1 : -1;

  bool is_row_has_enemy[battle::kMapRowCount] = {0};
  army::TroopsHub *enemy_troop = unit->owner_hub()->enemy_hub()->troops();
  const std::vector<uint_32>& enemy_active_ids = enemy_troop->active_ids();
  for(int i = 0; i < enemy_active_ids.size(); ++i )
  {
    army::MoveObject *enemy = enemy_troop->GetObjectById(enemy_active_ids[i]);
    int row = enemy->GetCurrentRowIndex();
    int col = enemy->GetCurrentColumnIndex();
    if (0 <= col && col < battle::kMapColumnCount)
      is_row_has_enemy[row] = true;
  }

  bool is_tile_has_ally[battle::kMapRowCount][battle::kMapColumnCount / 2] = {0};
  army::TroopsHub *owner_troop = unit->owner_hub()->troops();
  const std::vector<uint_32>& own_active_ids = owner_troop->active_ids();
  for(int i = 0; i < own_active_ids.size(); ++i )
  {
    army::MoveObject *owner = owner_troop->GetObjectById(own_active_ids[i]);
    if(owner != unit)
    {
      CCPoint current_tile_pos = battle::GetTileCoordinatePosByCurrentPointPosition(owner->current_pos());//battle::GetTileCoordinatePosByTileIndex(owner->tile_index());
      //printf("current_tile_pos %d, %d\n", owner->GetCurrentRowIndex(), owner->GetCurrentColumnIndex() % (battle::kMapColumnCount / 2));
      //printf("current_tile_pos %d, %d\n", (int)current_tile_pos.y, (int)current_tile_pos.x % (battle::kMapColumnCount / 2));
      if (0 <= current_tile_pos.y && battle::kMapRowCount > current_tile_pos.y && 0 <= current_tile_pos.x && battle::kMapColumnCount > current_tile_pos.x)
        is_tile_has_ally[(int)current_tile_pos.y][(int)current_tile_pos.x % (battle::kMapColumnCount / 2)] = true;

      CCPoint garrison_tile_pos = battle::GetTileCoordinatePosByTileIndex(dynamic_cast<army::Character*>(owner)->garrison_tile_index());//battle::GetTileCoordinatePosByTileIndex(owner->tile_index());
      //printf("current_tile_pos %d, %d\n", owner->GetCurrentRowIndex(), owner->GetCurrentColumnIndex() % (battle::kMapColumnCount / 2));
      //printf("current_tile_pos %d, %d\n", (int)current_tile_pos.y, (int)current_tile_pos.x % (battle::kMapColumnCount / 2));
      if (0 <= garrison_tile_pos.y && battle::kMapRowCount > garrison_tile_pos.y && 0 <= garrison_tile_pos.x && battle::kMapColumnCount > garrison_tile_pos.x)
        is_tile_has_ally[(int)garrison_tile_pos.y][(int)garrison_tile_pos.x % (battle::kMapColumnCount / 2)] = true;

      CCPoint target_tile_pos = battle::GetTileCoordinatePosByCurrentPointPosition(owner->target_selection()->target_position());
      //printf("target_tile_pos %d, %d\n", (int)target_tile_pos.y, (int)target_tile_pos.x % (battle::kMapColumnCount / 2));
      if (0 <= target_tile_pos.y && battle::kMapRowCount > target_tile_pos.y && 0 <= target_tile_pos.x && battle::kMapColumnCount > target_tile_pos.x)
        is_tile_has_ally[(int)target_tile_pos.y][(int)target_tile_pos.x % (battle::kMapColumnCount / 2)] = true;
    }
  }




  int result_index= -1;
  //if has target in row, don't move
  if (is_row_has_enemy[unit_row]) {
    return result_index;
  }
  int temp_row, temp_col;
  //first search row
  for(int i = 0; i < 2 * (battle::kMapRowCount) - 1; ++i)
  {
    temp_row = unit_row + (i % 2 ? direction : -direction) * (i / 2);
    if (0 > temp_row || battle::kMapRowCount <= temp_row || is_row_has_enemy[temp_row] == false) continue;
    //search col in this row
    for (int j = 0; j < battle::kMapColumnCount - 1; ++j)
    {
      temp_col = (unit_col % battle::kMapColumnCount / 2) + (j % 2 ? direction : -direction) * (j / 2);
      if (0 > temp_col || battle::kMapColumnCount / 2 <= temp_col || is_tile_has_ally[temp_row][temp_col] == true) continue;
      //pass check then good to go!
      result_index = (temp_row * battle::kMapColumnCount) + temp_col + (unit->owner_hub()->IsRightSideHub() ? battle::kMapColumnCount / 2 : 0);

      //printf("result_index: %d, pos(%d, %d) \n", result_index, temp_row, temp_col);
      //printf("result_index: %d, pos(%d, %d) \n", result_index, temp_row, temp_col);

      return result_index;
    }
  }

  /*
  if (battle::BattleController::GetInstance().tiled_map()->IsAnyMoveObjectInOwnTileTooNearBy(unit->move_object_id(), unit->tile_index()))
  {
    cocos2d::CCPoint target_pos = unit->current_pos();
    cocos2d::CCPoint fitablePos = battle::BattleController::GetInstance().tiled_map()-> \
      FindEmptyFitablePointPositionForMoveObjectFight(unit->move_object_id(), target_pos);
    if (ccpDistanceSQ(fitablePos, target_pos) > 0.1f)
    {
      unit->target_selection()->set_target_pos(fitablePos);
      unit->target_selection()->set_is_forced_move_to(true);
      unit->set_auto_search_tile_index(battle::GetTileIndexByCurrentPointPosition(fitablePos));
    }
    return kAIResultSuccess;
  }
   */


  return result_index;
}
/*
int IntentGuard::GetRowExistsMonster(army::MoveObject* unit)
{
  bool direction = (random_int(100) % 2)?true:false;
  int row = unit->GetCurrentRowIndex();
  int target_row = -1;
  int target_tile_index = battle::kUnexistTileIndex;
  std::list<army::MoveObject*> owner_list;
  //���жϵ�ǰ���Ƿ��й��� �����ֱ�ӹ���
  std::list<army::MoveObject*>  row_list;
  unit->owner_hub()->enemy_hub()->GetAllMoveObjectsInOneValidRowByRowIndex(row, row_list);
  if(row_list.size() > 0)
  {
    owner_list.clear();
    target_tile_index = battle::GetTileIndexByTileCoordinatePos(ccp(unit->GetCurrentColumnIndex(), row));
    unit->owner_hub()->GetAllMoveObjectsInTileWithIndex(target_tile_index, owner_list);
    //do not choose tile that has owner
    if(owner_list.size() == 0)
    {
      target_row = row;
    }
  }
  //û������ϵ��»���µ���Ѱ�ҹ���
  else
  {
    for(int i = 0; i < battle::kMapRowCount; ++i)
    {
      row = direction ? i : (battle::kMapRowCount - i - 1);
      if ( row == unit->GetCurrentColumnIndex() )
        continue;
      row_list.clear();
      unit->owner_hub()->enemy_hub()->GetAllMoveObjectsInOneValidRowByRowIndex(row, row_list);
      if(row_list.size() > 0)
      {
        owner_list.clear();
        target_tile_index = battle::GetTileIndexByTileCoordinatePos(ccp(unit->GetCurrentColumnIndex(), row));
        unit->owner_hub()->GetAllMoveObjectsInTileWithIndex(target_tile_index, owner_list);
        //do not choose tile that has owner
        if(owner_list.size() == 0)
        {
          target_row = row;
          break;
        }
      }
    }
  }

  // do not choose tile that is the target tile of auto search owner
  // it prevents two owner auto search to the same tile
  // this filter can be remove
  army::TroopsHub *owner_troop = unit->owner_hub()->troops();
  if(target_row != -1)
  {
    CCLog("@@@@@Id: %d, Select row: %d , Select tile: %d", unit->move_object_id(), target_row, target_tile_index);
    for(int i = 0; i < owner_troop->active_ids_count(); ++i)
    {
      army::MoveObject *owner = owner_troop->GetActiveObjectByIndex(i);
      CCLog("Id: %d, auto tile: %d", owner->move_object_id(), owner->auto_search_tile_index());
      if(owner != unit && owner->auto_search_tile_index() == target_tile_index)
      {
        target_row = -1;
        break;
      }
    }
  }
  printf("tgt row: %d", target_row);
  return target_row;
}
*/
uint_32 IntentGuard::GetRightMostMonsterInOwnBattleField( army::MoveObject* unit )
{
  /*
  army::TroopsHub *monster_troop = unit->owner_hub()->enemy_hub()->troops();
  //int max_x = -100;
  int right_most_column = 0;
  uint_32 target_monster_id = army::kUnexistTargetId;

  std::vector<army::MoveObject*> temp_monsters;
  for(int i = 0; i < monster_troop->active_ids_count(); ++i)
  {
    army::MoveObject *monster = monster_troop->GetActiveObjectByIndex(i);
    if(/*monster->current_pos().x > max_x && *//*monster->GetCurrentColumnIndex() >= right_most_column)
    {
      //target_monster_id = monster->move_object_id();
      //max_x = monster->current_pos().x;
      temp_monsters.push_back(monster);
    }
  }

  if ( temp_monsters.size() > 0 )
  {
    std::vector<army::MoveObject*>::iterator it = temp_monsters.begin();
    for ( ; it != temp_monsters.end() ; ++ it)
    {
      if ( (*it)->GetCurrentRowIndex() == unit->GetCurrentRowIndex() )
      {
        target_monster_id = (*it)->move_object_id();
        break;
      }      
    }
    if (target_monster_id == army::kUnexistTargetId)
    {
      target_monster_id = (*temp_monsters.begin())->move_object_id();
    }
  }
  */
  army::TroopsHub *enemy_troop = unit->owner_hub()->enemy_hub()->troops();
  int min_dist = 999999999, temp_dist;
  int right_most_column = 0;
  CCPoint unit_pos = unit->current_pos();
  uint_32 target_enemy_id = army::kUnexistTargetId;

  for(int i = 0; i < enemy_troop->active_ids_count(); ++i)
  {
    army::MoveObject *enemy = enemy_troop->GetActiveObjectByIndex(i);

    temp_dist = pow(enemy->current_pos().x - unit_pos.x, 2) + pow(enemy->current_pos().y - unit_pos.y, 2);
    if(temp_dist < min_dist && enemy->GetCurrentColumnIndex() >= right_most_column)
    {
      min_dist = temp_dist;
      target_enemy_id = enemy->move_object_id();
    }
  }

  return target_enemy_id;
}



uint_32 IntentGuard::GetSameRowFristMonsterInOwnBattleField( army::MoveObject* unit )
{
  army::TroopsHub *enemy_troop = unit->owner_hub()->enemy_hub()->troops();
  int min_dist = 999999999, temp_dist;
  bool is_same_row = false, temp_is_same_row;
  int right_most_column = 0;
  CCPoint unit_pos = unit->current_pos();
  int unit_row = unit->GetCurrentRowIndex();
  uint_32 target_enemy_id = army::kUnexistTargetId;

  for(int i = 0; i < enemy_troop->active_ids_count(); ++i)
  {
    army::MoveObject *enemy = enemy_troop->GetActiveObjectByIndex(i);

    temp_dist = pow(enemy->current_pos().x - unit_pos.x, 2) + pow(enemy->current_pos().y - unit_pos.y, 2);
    temp_is_same_row = (enemy->GetCurrentRowIndex() == unit_row);

    if(
      ((is_same_row == false && temp_is_same_row) || (temp_dist < min_dist))
      && (enemy->GetCurrentColumnIndex() >= right_most_column)
      )
    {
      min_dist = temp_dist;
      is_same_row = temp_is_same_row;
      target_enemy_id = enemy->move_object_id();
    }
  }

  return target_enemy_id;
}


} // namespace ai
} // namespace taomee
