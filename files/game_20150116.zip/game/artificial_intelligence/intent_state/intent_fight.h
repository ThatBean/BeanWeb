//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  intent_fight.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  02:27
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_intent_fight_h
#define ChainChronicle_intent_fight_h

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentFight :public AIState
{
public:
  IntentFight() {}
  virtual ~IntentFight() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif // ChainChronicle_intent_fight_h
