//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ai_state_machine.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  10:56
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ai_state_machine_h
#define ChainChronicle_ai_state_machine_h

#include "engine/base/basictypes.h"
#include "game/artificial_intelligence/intent_state/ai_state_constants.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"

#include "engine/platform/SingleInstance.h"

namespace taomee {

namespace army {
  class MoveObject;
}

namespace ai {
 
class AIState;

/**
 * use AIStateMachine::GetInstance() to get the singleton
 */
class AIStateMachine : public SingleInstanceObj
{
public:
  virtual ~AIStateMachine();
  
  static AIStateMachine& GetInstance();

public:
  bool            Init();
  void            ShutDown();
  
  // update all move objects on battle field with delta time
  uint_32         Update(float delta_time);
  // update one single unit on battle filed with delta time
  uint_32         Update(army::MoveObject* unit, float delta_time);
  
  MotionStateMachine* MotionMachine()
  {
    return motion_machine_;
  }
  
private:
  AIStateMachine();

  DISALLOW_COPY_AND_ASSIGN(AIStateMachine);

  bool            registerState(eAIStateType intent_type, AIState* state);
  
private:  
  AIState*            intentStates[kAIStateMax];
  
  MotionStateMachine* motion_machine_;
};
    
} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ai_state_machine_h
