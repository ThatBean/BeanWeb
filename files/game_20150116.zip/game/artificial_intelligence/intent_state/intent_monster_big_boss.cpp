//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_big_boss.cpp
//        Author: peteryu
//          Date: 2014/4/17 16:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/17      add
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/intent_state/intent_monster_big_boss.h"

#include "engine/animation/skeleton_animation.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/coordinate_helper.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/battle/battle_hub.h"
#include "game/game_manager/data_manager.h"
#include "game/army/unit_hub/troops_hub.h"


namespace taomee {
namespace ai {
  
uint_32 IntentMonsterBigBoss::OnEnter(army::MoveObject *unit)
{
  ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle);
  return kAIResultSuccess;
}  

uint_32 IntentMonsterBigBoss::OnLeave(army::MoveObject *unit)
{
  return kAIResultSuccess;
}

uint_32 IntentMonsterBigBoss::Update(army::MoveObject *unit, float delta_time)
{
  eMotionUpdateResult ret = ai::AIStateMachine::GetInstance().MotionMachine()
    ->Update(unit, delta_time);

  // stunned / KO status
  if (OnUncontrollableStatus(unit, delta_time))
  {
    return kAIResultSuccess;
  }

  CharacterData* cardData = unit->character_card_data();
  
  assert(unit->stage_stay_column() != -1);
  cocos2d::CCPoint stay_col_pos = battle::GetCenterPointPositionInTile(
    battle::GetTileIndexByTileCoordinatePos(ccp(unit->stage_stay_column(), 
                                                unit->GetCurrentRowIndex())));
  
  // firstly, move to stay column
  if(unit->current_pos().x < stay_col_pos.x && unit->stage_state() == army::kStageBorn)
  {
    unit->target_selection()->set_target_pos(ccp(stay_col_pos.x, unit->current_pos().y));
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, 
      kMotionStateMovePosition);
    unit->set_stage_time(0.0f);
    return kAIResultSuccess;
  }

  // start release skill every normal_skill_cool_time
  // skill time
  if(OnMonsterReleaseSkill(unit))
    return kAIResultSuccess;

  if(unit->stage_state() == army::kStageBorn)
    unit->set_stage_state(army::kStageAttack);

  // search near attack area
  if(unit->near_attack_trigger() &&
    unit->near_attack_trigger()->GetClosestId() != army::kUnexistTargetId)
  {
    unit->target_selection()->set_target_id(unit->near_attack_trigger()->GetClosestId());
    unit->target_selection()->set_target_id_point_offset(unit->near_attack_trigger()->
      GetClosestIdPointOffset());
    if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
    {
      unit->set_selected_skill_id(this->GetRandomSkill(unit, 
        cardData->GetSkillId(kSkillNormalHitNear)));
      unit->set_ai_state(kAIStateMonsterFight);
    }
    else
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, 
        kMotionStateIdle);
    }
    if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
      unit->set_normal_skill_cool_time(0.0f);
    return kAIResultSuccess;
  }

  if(unit->normal_skill_cool_time() >= cardData->GetAtkSpeed())
    unit->set_normal_skill_cool_time(0.0f);

  // attack stage, idle
  if(unit->stage_state() == army::kStageAttack)
  {
    ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle); 
  }

  return kAIResultSuccess;
}

} // namespace ai
} // namespace taomee
