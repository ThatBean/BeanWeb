//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ai_state.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  9:40
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////
#ifndef ChainChronicle_ai_state_h
#define ChainChronicle_ai_state_h

#include "engine/base/basictypes.h"

#define GHOST_DEBUG_START false
#define GHOST_DEBUG(i) if(GHOST_DEBUG_START){CCLog("GHOST_DEBUG: ID: %ld, Step: %d", unit->move_object_id(), i);}

namespace taomee {
 
namespace army {
  class MoveObject;
}
  
namespace ai {
	
	enum eControllableStatus
	{
		// ��ȫ���Կ���
		kControllableStatus_Enable		= 0,
		// �����ƶ������Էż��ܣ�
		kControllableStatus_CannotMove	= 1,
		// ���ܷż��ܣ������ƶ���
		kControllableStatus_CannotSkill = 2,
		// ��ȫ���ܿ���
		kControllableStatus_Disable		= 4,
	};
class AIState
{
	
public:
  AIState() {}
  virtual ~AIState() {}
  
public:
  virtual uint_32 OnEnter(army::MoveObject* unit) = 0;
  virtual uint_32 OnLeave(army::MoveObject* unit) = 0;
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time) = 0;  

protected:
  // true - response user operation, interrupt normal logic
  // false - non user operation
  bool            OnUserOperation(army::MoveObject* unit, float delta_time);
  // true - stunned/KO status -- can not do anything
  // false - normal status -- can change to other motion / intent
  bool            OnUncontrollableStatus(army::MoveObject* unit, float delta_time);
  // get random skill
  int             GetRandomSkill(army::MoveObject* unit, int normal_skill_id);
  // true - release skill, interrupt monster noraml logic
  // false - need not release skill
  bool            OnMonsterReleaseSkill(army::MoveObject* unit);
  bool            OnForceCharacterReleaseSkill(army::MoveObject* unit);
  bool            ForceReleaseSkill(army::MoveObject* unit);

  int UpdataControllableStatus(army::MoveObject* unit, float delta_time);

  void UpdataUnitDirectionByTargetPoint(army::MoveObject* unit);
  void UpdataUnitDirectionByTatgetId(army::MoveObject* unit);

protected:
	int controllable_status_flag_;
};
  
} // namespace taomee
} // namespace ai


#endif // ChainChronicle_ai_state_h
