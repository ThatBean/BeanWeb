//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_monster_big_boss.h
//        Author: peteryu
//          Date: 2014/4/17 16:00
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/17      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_MONSTER_BIG_BOSS_H
#define INTENT_MONSTER_BIG_BOSS_H

#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentMonsterBigBoss :public AIState
{
public:
  IntentMonsterBigBoss() {}
  virtual ~IntentMonsterBigBoss() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);
};
  
} // namespace ai
} // namespace taomee

#endif 
