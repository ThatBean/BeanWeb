//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: intent_cure.h
//        Author: robbiepan
//          Date: 2013/10/16 16:19
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/10/16      add
//////////////////////////////////////////////////////////////

#ifndef INTENT_CURE_H
#define INTENT_CURE_H


#include "game/artificial_intelligence/intent_state/ai_state.h"

namespace taomee {
namespace ai {
  
class IntentCure :public AIState
{
public:
  IntentCure() {}
  virtual ~IntentCure() {}
  
  virtual uint_32 OnEnter(army::MoveObject* unit);
  virtual uint_32 OnLeave(army::MoveObject* unit);
  
  virtual uint_32 Update(army::MoveObject* unit, float delta_time);


  int GetMostLivelessIndex(army::MoveObject* unit);

};
  
} // namespace ai
} // namespace taomee

#endif // INTENT_CURE_H
