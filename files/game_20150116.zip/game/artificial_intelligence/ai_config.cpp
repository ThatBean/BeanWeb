//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ai_state.cpp
//        Author: peteryu
//          Date: 2013/10/19 10:46
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/10/19      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/ai_config.h"

#include "engine/base/basictypes.h"
#include "engine/script/lua_tinker_manager.h"

#include "game/battle/battle_controller.h"

namespace taomee {
namespace ai {

AIConfig::AIConfig()
  : is_auto_fight_(false)
{
  LoadAIConfig();
}

AIConfig::~AIConfig()
{

}

void AIConfig::LoadAIConfig()
{
  near_attacker_ai_stay_time_ = 
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/ai_config.lua", "GetNearAttackerAIStayTime");
  
  range_attacker_ai_stay_time_ = 
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/ai_config.lua", "GetRangeAttackerAIStayTime");
 
  assassion_ai_search_row_time_ = 
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/ai_config.lua", "GetAssassinAttackerAISearchRowTime");
}

int AIConfig::GetNearAttackerAIStayTime()
{
  return near_attacker_ai_stay_time_;
}

int AIConfig::GetRangAttackerAIStayTime()
{
  return range_attacker_ai_stay_time_;
}

int AIConfig::GetAssassinAISearchRowTime()
{
  return assassion_ai_search_row_time_;
}

bool AIConfig::GetIsAutoFight()
{
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
  case battle::kBattleType_SandBox:
    { 
      return is_auto_fight_;
    }
    break;
  case battle::kBattleType_Pvp:
    {
      return true;
    }
    break;
  default:
    break;
  }
}

void AIConfig::SetIsAutoFightEnable( bool flag )
{
  is_auto_fight_ = flag;
}



} // namespace taomee
} // namespace ai