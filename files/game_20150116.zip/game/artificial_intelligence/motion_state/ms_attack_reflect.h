//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_attack_reflect.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-24
//          Time:  5:54
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-24        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ms_attack_reflect_h
#define ChainChronicle_ms_attack_reflect_h

#include "game/artificial_intelligence/motion_state/motion_state.h"

#include <map>

#include "engine/animation/skeleton_animation.h"

namespace taomee {
namespace ai {
  
class MotionAttackReflect : public MotionState
{
public:
  MotionAttackReflect() {}
  virtual ~MotionAttackReflect() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
  
//public:
//  // notification responser
//  void                        OnAnimationCompleted(const int obj_id,
//                                                   const std::string& name);
  
private:
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber> id_subscriber_map_;
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_attack_reflect_h
