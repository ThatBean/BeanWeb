﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_move_to_pos.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  9:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_move_to_pos.h"

#include "game/battle/battle_controller.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/artificial_intelligence/trigger/target_selection.h"
#include "game/battle/own_hub.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateMoveToPos::OnEnter(army::MoveObject* unit)
{
  this->resetDerection(unit);
  if (unit->weak_state() == ai::kWeakStateStrong || unit->weak_state() == ai::kWeakStateChangeStrong) 
  {
    unit->set_weak_state(ai::kWeakStateStrong);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWalk);
  }
  else if (unit->weak_state() == ai::kWeakStateWeak || unit->weak_state() == ai::kWeakStateChangeWeak) 
  {
    unit->set_weak_state(ai::kWeakStateWeak);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWeakWalk);
  }

  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateMoveToPos::OnLeave(army::MoveObject* unit)
{
  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  unit->set_move_speed(ccp(0.0, 0.0));
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateMoveToPos::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  /*
  if(unit->move_object_id() == 11)
  {
    CCLog("Current pos: %f, %f", unit->current_pos().x, unit->current_pos().y);
    CCLog("Current Target pos: %f, %f", unit->target_selection()->target_position().x, 
      unit->target_selection()->target_position().y);
  }
  */

  if (unit->weak_state() == ai::kWeakStateChangeStrong)
  {
    unit->set_weak_state(ai::kWeakStateStrong);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWalk);
  }
  else if (unit->weak_state() == ai::kWeakStateChangeWeak)
  {
    unit->set_weak_state(ai::kWeakStateWeak);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWeakWalk);
  }

  if (!unit->target_selection()->target_position_isvalid()) 
  {
    return kMotionResultCompelted;
  }

  if(unit->target_selection()->target_position().getLengthSq() == 0)
  {
    return kMotionResultCompelted;
  }

  if(ccpDistanceSQ(unit->current_pos(), unit->target_selection()->target_position()) ==
     (unit->mover_speed_value()*delta_time*unit->mover_speed_value()*delta_time))
  {
    return kMotionResultCompelted;
  }

  if (unit->target_selection()->is_new_direction())
  {
     this->resetDerection(unit);
  }
  CCPoint direction = ccpSub(unit->target_selection()->target_position(), unit->current_pos());
  if(direction.x * unit->move_speed().x + direction.y * unit->move_speed().y <= 0)
  {
    unit->set_current_pos(unit->target_selection()->target_position());
    return kMotionResultCompelted;
  }

  //reduce monster's speed and show warning
  float monster_speed_additional_modifier = 1;
  if (unit->owner_hub()->IsCharacterHub() == false && unit->current_pos().x > battle::kMapRightMostX * 0.5)
  {
    monster_speed_additional_modifier = 0.5;
    if (unit->current_pos().x > battle::kMapRightMostX * 0.6)
      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/WarningUI.lua", "AutoExtendWarningUIToBattleScene");
  }

  cocos2d::CCPoint move_vec = ccp(unit->move_speed().x*delta_time*monster_speed_additional_modifier,
                                  unit->move_speed().y*delta_time*monster_speed_additional_modifier);
  cocos2d::CCPoint new_pos = cocos2d::ccpAdd(move_vec, unit->current_pos());

  
  //cocos2d::CCPoint min_range = ccpAdd(battle::grid_position_x_y(battle::kMapRowCount, 0), ccp(battle::kMapTileMaxLength / 2, battle::kMapTileMaxHeight / 2));
  //cocos2d::CCPoint max_range = ccpAdd(battle::grid_position_x_y(0, battle::kMapColumnCount), ccp(-battle::kMapTileMaxLength / 2, -battle::kMapTileMaxHeight / 2));

  //new_pos.x = new_pos.x < min_range.x ? min_range.x : new_pos.x;
  //new_pos.x = new_pos.x > max_range.x ? max_range.x : new_pos.x;
  //new_pos.y = new_pos.y < min_range.y ? min_range.y : new_pos.y;
  //new_pos.y = new_pos.y > max_range.y ? max_range.y : new_pos.y;
  

  unit->set_current_pos(new_pos);
  return kMotionResultActive;
}
  
void MotionStateMoveToPos::resetDerection(army::MoveObject* unit)
{
  cocos2d::CCPoint new_des_pos = unit->target_selection()->target_position();
  cocos2d::CCPoint current_pos = unit->current_pos();
  float del_x = new_des_pos.x - current_pos.x;
  float del_y = new_des_pos.y - current_pos.y;
  float distance = sqrt(del_x*del_x + del_y*del_y);
  if (fabsf(distance)<0.00001f)
  {
    unit->set_move_speed(cocos2d::CCPointZero);
  }
  else
  {
    del_x = del_x / distance;
    del_y = del_y / distance;
    unit->set_move_speed(ccp(del_x*unit->mover_speed_value(),
                             del_y*unit->mover_speed_value()));
  }  
  //add threshold of turn direction(50 pixel)
  if (abs(new_des_pos.x - current_pos.x) > 50)
  {
     if (new_des_pos.x>current_pos.x) {
       unit->set_anima_direction(kDirectionRight);
     }
     else {
       unit->set_anima_direction(kDirectionLeft);
     }
  }
  unit->target_selection()->set_is_new_direction(false);

}


} // namespace ai
} // namespace taomee


