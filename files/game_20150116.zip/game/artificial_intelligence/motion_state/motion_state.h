//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  motion_state.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  7:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_motion_state_h
#define ChainChronicle_motion_state_h

#include "game/artificial_intelligence/motion_state/motion_state_constants.h"
#include "engine/base/basictypes.h"

namespace taomee {
  
namespace army {
  class MoveObject;
}
  
namespace ai {
  
class MotionState
{
public:
  MotionState() {}
  virtual ~MotionState() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit) = 0;
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit) = 0;
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit,
                                     float delta_time) = 0;
};
  
} // namespace ai
} // namespace taomee

#endif // ChainChronicle_motion_state_h
