//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_idle.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:40
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_idle.h"

#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/move_object.h"
#include "engine/base/random_helper.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateIdle::OnEnter(army::MoveObject* unit)
{
  if (unit->weak_state() == ai::kWeakStateStrong) 
  {
    unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  }
  else
  {
    unit->ChangeAnimationToIndex(army::kUnitAnimationWeak);
  }

  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateIdle::OnLeave(army::MoveObject* unit)
{
  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateIdle::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  if (unit->weak_state() == ai::kWeakStateChangeStrong) 
  {
    unit->set_weak_state(ai::kWeakStateStrong);
    unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  }
  else if (unit->weak_state() == ai::kWeakStateChangeWeak) 
  {
    unit->set_weak_state(ai::kWeakStateWeak);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWeak);
  }
  return kMotionResultActive;
}
  
} // namespace ai
} // namespace taomee
