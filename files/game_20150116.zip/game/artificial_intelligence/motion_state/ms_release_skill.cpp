//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_release_skill.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_release_skill.h"

#include "engine/animation/skeleton_animation.h"
#include "game/army/unit_hub/troops_hub.h"
#include "engine/base/random_helper.h"
#include "game/battle/battle_hub.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/skill/skill_system.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_data_table.h"
#include "engine/animation/projectile_animation.h"
#include "game/passive_ability/auramanager.h"

namespace taomee {
namespace ai {



  enum taomee::AnimationDirection MotionStateReleaseSkill::CheckEnemyForBetterDirection( army::MoveObject* unit )
  {
    enum taomee::AnimationDirection unit_direction, result_direction;
    unit_direction = unit->anima_direction();

    bool is_left_side_has_enemy = false, 
      is_right_side_has_enemy = false, 
      is_same_col_with_enemy = false;

    int unit_column = unit->GetCurrentColumnIndex();
    uint_32 target_enemy_id = army::kUnexistTargetId;

    army::TroopsHub *enemy_troop = unit->owner_hub()->enemy_hub()->troops();

    for(int i = 0; i < enemy_troop->active_ids_count(); ++i)
    {
      army::MoveObject *enemy = enemy_troop->GetActiveObjectByIndex(i);
      int enemy_column = enemy->GetCurrentColumnIndex();

      if (unit_column == enemy_column)
        is_same_col_with_enemy = true;
      else
      {
        if (unit_column > enemy_column) 
          is_left_side_has_enemy = true;
        else 
          is_right_side_has_enemy = true;
      }
    }

    if (is_same_col_with_enemy == true || is_left_side_has_enemy && is_right_side_has_enemy)
      //no change
      result_direction = unit_direction;
    else
    {
      if (is_left_side_has_enemy) 
        result_direction = kDirectionLeft;
      else if (is_right_side_has_enemy)
        result_direction = kDirectionRight;
      else
        //skill is wasted for sure...
        result_direction = unit_direction;
    }

    return result_direction;
  }




eMotionUpdateResult MotionStateReleaseSkill::OnEnter(army::MoveObject* unit)
{
	if( !unit->is_active() || unit->motion_state() == kMotionStateDead)
	{
		return kMotionResultCompelted;
	}
	int selected_skill_id = unit->selected_skill_id() > 0 ? unit->selected_skill_id() : DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(unit->card_id())->GetSkillId(kSkillSkill);
  // set flag for Invincible -- character will not be Effected by enemies in this motion
  int_8 castingType = DataManager::GetInstance().GetSkillDataTable()->GetSkill(selected_skill_id)->GetCastingType();
  if (unit->owner_hub()->IsCharacterHub())
  {
    if ( kCastingType_SingDance == castingType || kCastingType_Continuous == castingType)
    {
      unit->retain_battle_status_flag(battle::kDamageStatusImmune);
      unit->retain_immune_status_flag(battle::kImmuneTypeControl);
    }
    else if ( kCastingType_Once == castingType || kCastingType_Combo == castingType)
    {
      unit->retain_battle_status_flag(battle::kDamageInvincible);
    }
  }

  unit->set_charge_dist(0);
  unit->set_idle_time(0);
  unit->set_normal_skill_cool_time(0.0f);
  unit->set_skill_cool_time(0.0f);
  unit->set_current_animation_state(ai::kMotionResultActive);

  // bug xxx

  unit->target_selection()->set_previous_target_id(unit->target_selection()->target_id());

  //check this direction has enemy
  //AnimationDirection dir = unit->anima_direction();
  AnimationDirection dir = CheckEnemyForBetterDirection(unit);
  unit->set_anima_direction(dir); 

  //release skill
  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
  int  action_loop_count = -1;

  if( kCastingType_SingDance == castingType )
  {
    action_loop_count = -1;
  }
  else
  {
    id_subscriber_map_[unit->move_object_id()] = unit->anima_node()->\
      SubscribeActionEvent<MotionStateReleaseSkill>(this,\
                                                    &MotionStateReleaseSkill::OnAnimationCompleted);
    frame_subscriber_map_[unit->move_object_id()] = unit->anima_node()->\
      SubscribeFrameEvent<MotionStateReleaseSkill>(this, &MotionStateReleaseSkill::OnFrameEvent);
    action_loop_count = skill_sys->skill_data()->GetSkillBaseActionCount(selected_skill_id);
  }

  const std::string& anim_name = skill_sys->skill_data()->GetSkillBaseMotion(selected_skill_id).c_str();
  float anim_speed = skill_sys->skill_data()->GetSkillBaseActionSpeedRate(selected_skill_id);
  if ( !anim_name.empty())
  {
	  unit->ChangeAnimationToIndex( anim_name, action_loop_count, anim_speed);
  }
  
  skill_sys->PlaySkill(selected_skill_id,MW_MAGIC_BREAK_TYPE_SELF,unit->move_object_id(), -1,unit->current_pos().x, unit->current_pos().y);
  
  battle::BattleController::AuraMgr()->AddAurasFromSkill(unit, unit, selected_skill_id);

  unit->near_attack_trigger()->set_is_active(false);
  if (unit->guard_trigger())
  {
	  unit->guard_trigger()->set_is_active(false);
  }

  unit->set_skill_hit_count(0);

  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateReleaseSkill::OnLeave(army::MoveObject* unit)
{
	int selected_skill_id = unit->selected_skill_id() > 0 ? unit->selected_skill_id() : DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(unit->card_id())->GetSkillId(kSkillSkill);
	if (unit->owner_hub()->IsCharacterHub())
	{
		int_8 castingType = DataManager::GetInstance().GetSkillDataTable()->GetSkill(selected_skill_id)->GetCastingType();
		if ( kCastingType_SingDance == castingType || kCastingType_Continuous == castingType)
		{
			unit->release_battle_status_flag(battle::kDamageStatusImmune);
			unit->release_immune_status_flag(battle::kImmuneTypeControl);
		}
		else if ( kCastingType_Once == castingType || kCastingType_Combo == castingType)
		{
			unit->release_battle_status_flag(battle::kDamageInvincible);
		}
	}
  
  unit->set_current_animation_state(ai::kMotionResultCompelted);
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
    id_subscriber_map_.find(unit->move_object_id());
  if(itr != id_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr->second);

  std::map<uint_32, SkeletonAnimation::FrameEventSubscriber>::iterator itr_frame =
    frame_subscriber_map_.find(unit->move_object_id());
  if(itr_frame != frame_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr_frame->second);
  //CCLOG("MotionStateNormalHit OnLeave ID: %d", unit->move_object_id());
  unit->target_selection()->resetTargetSelection();

  unit->near_attack_trigger()->set_is_active(true);
  if (unit->guard_trigger() &&
      false == battle::IsStatusAKindOfSkillForbiddenType(static_cast<battle::eDamageStatus>(unit->battle_status_flag())))
  {
    unit->guard_trigger()->set_is_active(true);
  }

  unit->set_normal_skill_cool_time(0.0f);
  unit->set_skill_cool_time(0.0f);
  unit->set_selected_skill_id(kSkillInvaild);
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateReleaseSkill::Update(army::MoveObject* unit,
                                                 float delta_time)
{
	int selected_skill_id = unit->selected_skill_id() > 0 ? unit->selected_skill_id() : DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(unit->card_id())->GetSkillId(kSkillSkill);
  int_8 castingType = DataManager::GetInstance().GetSkillDataTable()->GetSkill(selected_skill_id)->GetCastingType();
  if( kCastingType_SingDance == castingType )
  {
    if( unit->skill_cool_time() >= DataManager::GetInstance().GetSkillDataTable()->GetSkill(selected_skill_id)->GetDamageTick())
    {
      unit->set_current_animation_state(ai::kMotionResultCompelted);
    }
    return unit->current_animation_state();
  }

  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
  int_32 charge_dist = skill_sys->skill_data()->GetSkillBaseChargeDistance(selected_skill_id);

  if (charge_dist != 0) 
  {
    if (unit->charge_dist() >= charge_dist  ) 
    {
      if (unit->idle_time() >= 0.2f) 
      {
        unit->anima_node()->Resume();
        unit->set_current_animation_state(ai::kMotionResultCompelted);
      }
      else
      {
        unit->set_idle_time(unit->idle_time() + delta_time);
      }
    }
    else
    {
      if (unit->anima_node()->state() == SkeletonAnimation::kStatePaused) 
      {
		// only move in battle field : fixed BUG 104269
        if (battle::GetTileCoordinatePosByCurrentPointPosition(unit->current_pos()).x>=0)
        {
		      unit->set_current_pos(cocos2d::ccpAdd(cocos2d::CCPoint(unit->anima_direction() == kDirectionLeft ? -10 : 10,0), unit->current_pos()));
        }        
        unit->set_charge_dist(unit->charge_dist() + 10);
      }
    }    
  }

  return unit->current_animation_state();
}
  
void MotionStateReleaseSkill::OnAnimationCompleted( const int obj_id, const std::string& name )
{   
  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(obj_id);
  if ( !unit )
  {
	  return;
  }

  // check self damage skill
  unit->DamageSelfBySuicideSkill();

  unit->set_current_animation_state(ai::kMotionResultCompelted);
  int selected_skill_id_ = unit->selected_skill_id() > 0 ? unit->selected_skill_id() : DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(unit->card_id())->GetSkillId(kSkillSkill);
  ReleaseSkillOverEvent::Emit( unit->move_object_id(), selected_skill_id_);
}

void MotionStateReleaseSkill::OnFrameEvent( const int obj_id, const std::string& name )
{
  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(obj_id);
  if(!unit || !unit->is_active() || unit->motion_state() == kMotionStateDead)
  {
    return;
  }
  int selected_skill_id = unit->selected_skill_id() > 0 ? unit->selected_skill_id() : DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(unit->card_id())->GetSkillId(kSkillSkill);
  if (name == GetFrameEventName(kFrameEventPower))
  {
    int skill_id = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(unit->card_id())->GetSkillId(kSkillSkill);
    SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
    if (skillData->GetPowerEffect().length() != 0)
    {
      //���ս��ǰû��Ԥ���سɹ�
      if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(skillData->GetPowerEffect().c_str()) == NULL)
      {
        std::string skeleton_config = kDefaultSkeletonFilePath + skillData->GetPowerEffect() + ".xml";
        std::string skeleton_plist = kDefaultSkeletonFilePath + skillData->GetPowerEffect() + ".plist";
        std::string skeleton_texture = kDefaultSkeletonFilePath + skillData->GetPowerEffect() + ".pvr.ccz";

        CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(),
          skeleton_plist.c_str(),
          skeleton_config.c_str());
      }
      CCArmature* armature_ = CCArmature::create(skillData->GetPowerEffect().c_str());
      unit->anima_node()->addChild(armature_,1,kSkillArmatureTag);
      if (unit->anima_direction() == kDirectionRight)
        armature_->setRotationY(180);
      armature_->getAnimation()->play("bsj", 0, -1, 0);
    }
  }
  else if (name == GetFrameEventName(kFrameEventPower2))
  {
    if(unit->anima_node()->getChildByTag(kSkillArmatureTag))
    {
      unit->anima_node()->removeChildByTag(kSkillArmatureTag);
    }
    SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(selected_skill_id);
    if (skillData->GetPower2Effect().length() != 0)
    {
      //���ս��ǰû��Ԥ���سɹ�
      if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(skillData->GetPower2Effect().c_str()) == NULL)
      {
        std::string skeleton_config = kDefaultSkeletonFilePath + skillData->GetPower2Effect() + ".xml";
        std::string skeleton_plist = kDefaultSkeletonFilePath + skillData->GetPower2Effect() + ".plist";
        std::string skeleton_texture = kDefaultSkeletonFilePath + skillData->GetPower2Effect() + ".pvr.ccz";

        CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(),
          skeleton_plist.c_str(),
          skeleton_config.c_str());
      }
      CCArmature* armature_ = CCArmature::create(skillData->GetPower2Effect().c_str());
      unit->anima_node()->addChild(armature_,1,kSkillArmatureTag);
      if (unit->anima_direction() == kDirectionRight)
        armature_->setRotationY(180);
      armature_->getAnimation()->play("bsj", 0, -1, 0);
    }
  }
  else if (name == GetFrameEventName(kFrameEventRelease))
  {
    if(!unit->is_active() || unit->motion_state() == kMotionStateDead)
    {
      return;
    }

    if(unit->anima_node()->getChildByTag(kSkillArmatureTag))
    {
      unit->anima_node()->removeChildByTag(kSkillArmatureTag);
    }
    
    battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
    skill_sys->PlaySkill(selected_skill_id,MW_MAGIC_BREAK_TYPE_HIT,unit->move_object_id(),
      -1,unit->current_pos().x, unit->current_pos().y);

    uint_32 skill_hit_count = unit->get_skill_hit_count();
    unit->set_skill_hit_count(skill_hit_count + 1);
    
  }
  else if (name == GetFrameEventName(kFrameEventHit))
  {
    if(!unit->is_active() || unit->motion_state() == kMotionStateDead)
    {
      return;
    }

    if(unit->anima_node()->getChildByTag(kSkillArmatureTag))
    {
      unit->anima_node()->removeChildByTag(kSkillArmatureTag);
    }

    battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
    skill_sys->PlaySkill(selected_skill_id,MW_MAGIC_BREAK_TYPE_HIT,unit->move_object_id(),
      -1,unit->current_pos().x, unit->current_pos().y);
    
    //int_32 charge_dist = skill_sys->skill_data()->GetSkillBaseChargeDistance(selected_skill_id_);
    //if (charge_dist != 0) 
    //{
    //  unit->anima_node()->Pause();
    //}
    CCScaleTo* to = CCScaleTo::create(0.2, battle::GetScaleByPosition(unit->anima_node()->getPosition()));  
    unit->anima_node()->runAction(to);
  }
}
} // namespace ai
} // namespace taomee
