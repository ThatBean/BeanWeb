//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ms_ko.cpp
//        Author: peteryu
//          Date: 2013/11/19 17:18
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/11/19      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/motion_state/ms_ko.h"

#include <boost/bind.hpp>
#include <boost/signal.hpp>

#include "engine/base/random_helper.h"
#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateKo::OnEnter(army::MoveObject* unit)
{
  id_subscriber_map_[unit->move_object_id()] = unit->anima_node()->SubscribeActionEvent<MotionStateKo>
    (this, &MotionStateKo::OnAnimationCompleted);
  unit->set_current_animation_state(ai::kMotionResultActive);

  unit->ChangeAnimationToIndex(army::kUnitAnimationDown, 1);
  //unit->HideHealthBar();
  //unit->set_be_skill_hitmove_offset(10);

  unit->retain_battle_status_flag(battle::kDamageRepel);
  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateKo::OnLeave(army::MoveObject* unit)
{
  unit->set_current_animation_state(kMotionResultCompelted);
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
    id_subscriber_map_.find(unit->move_object_id());
  if(itr != id_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr->second);

  unit->release_battle_status_flag(battle::kDamageRepel);
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateKo::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  //if (unit->current_animation_state() == kMotionResultCompelted)
  //{
  //  this->OnLeave(unit);
  //}
  return unit->current_animation_state();
}

void MotionStateKo::OnAnimationCompleted( const int obj_id, const std::string& name )
{
  army::MoveObject *obj = battle::BattleController::GetInstance().GetObjectById(obj_id);
  if ( !obj )
  {
	  CCAssert(obj != NULL, "");
	  return;
  }

  if(name.compare("down"))
  {
    std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
      id_subscriber_map_.find(obj_id);
    if(itr != id_subscriber_map_.end())
      obj->anima_node()->UnsubscribeActionEvent(itr->second);

    obj->ChangeAnimationToIndex(army::kUnitAnimationUp, 1);

    id_subscriber_map_[obj->move_object_id()] = obj->anima_node()->SubscribeActionEvent
      <MotionStateKo>(this, &MotionStateKo::OnAnimationCompleted);
  }
  else if(name.compare("up"))
  {
    obj->set_current_animation_state(kMotionResultCompelted);
  }
  else
  {
    CCAssert(false, "Unkown Animation Name!");
  }
}

} // namespace ai
} // namespace taomee
