//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_intertwine.cpp
//        Author:  vic.tang
//       Version:  1
//          Date:  2014-11-27
//          Time:  17:00
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       vic.tang   2014-11-27     1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_intertwine.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateIntertwine::OnEnter(army::MoveObject* unit)
{
  return kMotionResultActive;
}

eMotionUpdateResult MotionStateIntertwine::OnLeave(army::MoveObject* unit)
{
	return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateIntertwine::Update(army::MoveObject* unit,
                                               float delta_time)
{
  if ( unit->check_battle_status_flag( battle::kDamageIntertwine) )
  {    
    return kMotionResultActive;
  }
  else
  {
    return kMotionResultCompelted;
  }
}
  
} // namespace ai
} // namespace taomee
