//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  motion_state_constants.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-11
//          Time:  7:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-11        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_motion_state_constants_h
#define ChainChronicle_motion_state_constants_h

#include "engine/base/basictypes.h"

namespace taomee {
namespace ai {
  
enum eMotionStateType
{
  kMotionStateInvalid       = -1,
  kMotionStateIdle          = 0,
  kMotionStateMovePosition  = 1,
  kMotionStateMoveTarget    = 2,
  kMotionStateBorn          = 3,
  kMotionStateDead          = 4,
  kMotionStateReleaseSkill  = 5,
  kMotionStateReleaseSkillTriple  = 6,
  kMotionStateNormalHit     = 7,
  kMotionStateStunned       = 8,
  kMotionStateAttackReflect = 9,
  kMotionStateHashPosition  = 10,
  kMotionStateKO            = 11,
  kMotionStatePetrifaction  = 12,
  kMotionStateTriggerSkill  = 13,
  kMotionStateMax,
};

#define WEAK_RATE           20

enum eWeakStateType
{
  kWeakStateStrong          = 0,
  kWeakStateWeak            = 1,   
  kWeakStateChangeWeak      = 2,
  kWeakStateChangeStrong    = 3,
};

enum eMotionUpdateResult
{
  kMotionResultInvalid      = -1,
  kMotionResultActive       = 0,
  kMotionResultInactive     = 1,
  kMotionResultCompelted    = 2,
  kMotionResultFailed       = 3,
  kMotionResultMax,
};  
  
#define IS_VALID_MOTION_STATE(state) (state > kMotionStateInvalid && state < kMotionStateMax)

static std::string GetMotionStateName(eMotionStateType type)
{
  switch(type)
  {
  case kMotionStateBorn:
    return "kMotionStateBorn";
  case kMotionStateDead:
    return "kMotionStateDead";
  case kMotionStateIdle:
    return "kMotionStateIdle";
  case kMotionStateInvalid:
    return "kMotionStateInvalid";
  case kMotionStateMovePosition:
    return "kMotionStateMovePosition";
  case kMotionStateMoveTarget:
    return "kMotionStateMoveTarget";
  case kMotionStateNormalHit:
    return "kMotionStateNormalHit";
  case kMotionStateReleaseSkill:
    return "kMotionStateReleaseSkill";
  case kMotionStateReleaseSkillTriple:
    return "kMotionStateReleaseSkillTriple";
  case kMotionStateStunned:
    return "kMotionStateStunned";
  case kMotionStateAttackReflect:
      return "kMotionStateAttackReflect";
  case kMotionStateHashPosition:
      return "kMotionStateHashPosition";
  case kMotionStateKO:
      return "kMotionStateKO";
  default:
      return "";
  }
  return "";
}

/*
 
//  motion_state_priority[motion1][motion2] == -1 means motion2 has high priority than motion1
//  motion_state_priority[motion1][motion2] == 0  means motion1 & motion2 have same priority
//  motion_state_priority[motion1][motion2] == 1  means motion1 has high priority than motion2
static const uint_32 motion_state_priority[kMotionStateMax][kMotionStateMax] =
  {
  // idle  born  dead  release_skill  move_pos  move_target  hit  stunned  attack_reflect
    { 0,    -1,   -1,      -1,           -1,        -1,       -1,    -1,       -1}, // idle
    { 1,     0,    1,       1,            1,         1,        1,     1,        1}, // born
    { 1,     1,    0,       1,            1,         1,        1,     1,        1}, // dead
    { 1,    -1,   -1,       0,            1,         1,        1,     0,        1}, // release_skill
    { 1,    -1,   -1,      -1,            0,         1,        1,    -1,       -1}, // move_pos
    { 1,    -1,   -1,      -1,            1,         0,        1,    -1,       -1}, // move_target
    { 1,    -1,   -1,      -1,            1,         1,        0,    -1,        1}, // hit
    { 1,    -1,   -1,       0,            1,         1,        1,     0,        1}, // stunned
    { 1,    -1,   -1,      -1,            1,         1,       -1,    -1,        0}, // attack_reflect
  };
 */

static const int_32 motion_state_priority[kMotionStateMax][kMotionStateMax] =
{
          //idle m_pos m_tg born dead r_skill r_skill_t  n_hit stun a_ref h_pos ko
/*idle*/    { 0,  -1,   -1,  -1,  -1,   -1,    -1,        -1,   -1,  -1,   -1,  -1},
/*m_pos*/   { 1,   0,    0,  -1,  -1,   -1,    -1,         0,   -1,  -1,    0,  -1},
/*m_tg*/    { 1,   0,    0,  -1,  -1,   -1,    -1,         0,   -1,  -1,    0,  -1},
/*born*/    { 1,   1,    1,   0,   0,    1,     1,         1,    1,   1,    1,   1},
/*dead*/    { 1,   1,    1,   0,   0,    1,     1,         1,    1,   1,    1,   1},
/*r_skill*/ { 1,   1,    1,  -1,  -1,    0,     0,         1,   -1,   1,    1,  -1},
/*r_skil_t*/{ 1,   1,    1,  -1,  -1,    0,     0,         1,   -1,   1,    1,  -1},
/*n_hit*/   { 1,   0,    0,  -1,  -1,   -1,    -1,         0,   -1,   0,    0,  -1},
/*stun*/    { 1,   1,    1,  -1,  -1,    1,     1,         1,    0,   1,    1,   0},
/*a_ref*/   { 1,   1,    1,  -1,  -1,   -1,    -1,         0,   -1,   0,    0,  -1},
/*h_pos*/   { 1,   0,    0,  -1,  -1,   -1,    -1,         0,   -1,   0,    0,  -1},
/*ko*/      { 1,   1,    1,  -1,  -1,    1,     1,         1,    0,   1,    1,   0}
}; // idle < m_tg == n_hit == m_pos == h_pos < a_ref < r_skill = r_skill_t < {stun == ko} < born == dead


enum eMSPriorityCompare
{
  kMotionPriorityLow  = -1,
  kMotionPrioritySame = 0,
  kMotionPriorityHigh = 1,
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_motion_state_constants_h
