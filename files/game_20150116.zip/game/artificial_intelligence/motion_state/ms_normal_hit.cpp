﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_normal_hit.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:43
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_normal_hit.h"

#include <boost/bind.hpp>
#include <boost/signal.hpp>

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"

#include "engine/animation/animation_constant.h"
#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_hub.h"
#include "game/skill/skill_system.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/character_data_table.h"
#include "game/army/unit/unit_constants.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateNormalHit::OnEnter(army::MoveObject* unit)
{
  if(unit->target_selection()->target_id() == army::kUnexistTargetId)
  {
    unit->set_current_animation_state(kMotionResultCompelted);
    return kMotionResultCompelted;
  }

   int_32 selected_skill_id = unit->selected_skill_id();
  army::MoveObject* target_obj = battle::BattleController::GetInstance().GetObjectById(unit->target_selection()->target_id());
  if( !target_obj || !target_obj->is_active() || target_obj->motion_state() == kMotionStateDead)
  {
    return kMotionResultCompelted;
  }

  unit->set_normal_skill_cool_time(0.0f);

  //add threshold of turn direction(0 pixel)
  if (abs(unit->current_pos().x - target_obj->current_pos().x) > 0)
  {
    if(unit->current_pos().x < target_obj->current_pos().x)
    {
      unit->set_anima_direction(kDirectionRight);
    }
    else
    {
      unit->set_anima_direction(kDirectionLeft);
    }
  }

  army::eCareerType career_type = unit->GetCareerType();
  // do not change monk direction when healing
  if(career_type == army::kCareerTypeMonk)
  {
    CharacterData *char_data = unit->character_card_data();
    if(char_data->GetSkillId(kSkillNormalHitFar) == selected_skill_id)
    {
      if(unit->owner_hub()->IsRightSideHub())
        unit->set_anima_direction(kDirectionLeft);
      else
        unit->set_anima_direction(kDirectionRight);
    }
  }

  id_subscriber_map_[unit->move_object_id()] = unit->anima_node()->
    SubscribeActionEvent<MotionStateNormalHit>(this, &MotionStateNormalHit::OnAnimationCompleted);
  frame_subscriber_map_[unit->move_object_id()] = unit->anima_node()->
    SubscribeFrameEvent<MotionStateNormalHit>(this, &MotionStateNormalHit::OnFrameEvent);

  unit->set_current_animation_state(ai::kMotionResultActive);

  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();

  string action_name = skill_sys->skill_data()->GetSkillBaseMotion(selected_skill_id);
  // fighter crit
  float rand_value = random_0_1();
  float unit_critical = unit->critical_probability( target_obj->level() );
  if ( (rand_value < unit_critical) ) 
  {
    unit->set_critical_hit(true);
  }    
  
  unit->ChangeAnimationToIndex(action_name.c_str(), 
                               skill_sys->skill_data()->GetSkillBaseActionCount(selected_skill_id),
                               skill_sys->skill_data()->GetSkillBaseActionSpeedRate(selected_skill_id));

  skill_sys->PlaySkill(selected_skill_id,MW_MAGIC_BREAK_TYPE_SELF,unit->move_object_id(),
    target_obj->move_object_id(),target_obj->current_pos().x, target_obj->current_pos().y);

  // bug xxx
  unit->target_selection()->set_previous_target_id(unit->target_selection()->target_id());

  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateNormalHit::OnLeave(army::MoveObject* unit)
{
  unit->set_critical_hit(false);
  unit->set_current_animation_state(ai::kMotionResultCompelted);
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
    id_subscriber_map_.find(unit->move_object_id());
  if(itr != id_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr->second);

  std::map<uint_32, SkeletonAnimation::FrameEventSubscriber>::iterator itr_frame =
    frame_subscriber_map_.find(unit->move_object_id());
  if(itr_frame != frame_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr_frame->second);
  //CCLOG("MotionStateNormalHit OnLeave ID: %d", unit->move_object_id());

  unit->add_normal_hit_count();
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateNormalHit::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  return unit->current_animation_state();
}

void MotionStateNormalHit::OnAnimationCompleted( const int obj_id, const std::string& name )
{
	army::MoveObject* unit =battle::BattleController::GetInstance().GetObjectById(obj_id);
	if ( unit )
	{
		unit->set_current_animation_state(ai::kMotionResultCompelted);
	}
}

void MotionStateNormalHit::OnFrameEvent( const int obj_id, const std::string& name )
{
  if (name == GetFrameEventName(kFrameEventHit))
  {
    army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(obj_id);
    if( !unit || !unit->is_active() || unit->motion_state() == kMotionStateDead)
    {
      return;
    }
	int_32 selected_skill_id = unit->selected_skill_id();
    if (unit->target_selection()->target_id() == army::kUnexistTargetId) 
    {
      return;
    }
    army::MoveObject* target_obj = 
		battle::BattleController::GetInstance().GetObjectById(unit->target_selection()->target_id());
    if( !target_obj || !target_obj->is_active() || target_obj->motion_state() == kMotionStateDead)
    {
      return;
    }

    battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
    skill_sys->PlaySkill(selected_skill_id,MW_MAGIC_BREAK_TYPE_TAG,unit->move_object_id(),
                         target_obj->move_object_id(), target_obj->current_pos().x, target_obj->current_pos().y);
  }
}



} // namespace ai
} // namespace taomee
