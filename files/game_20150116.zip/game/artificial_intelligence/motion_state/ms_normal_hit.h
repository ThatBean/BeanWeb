//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_normal_hit.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:42
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ms_normal_hit_h
#define ChainChronicle_ms_normal_hit_h

#include "game/artificial_intelligence/motion_state/motion_state.h"
#include "engine/animation/skeleton_animation.h"
#include <map>

namespace taomee {

class SkeletonAnimation;

namespace ai {

class MotionStateNormalHit : public MotionState
{
public:
  MotionStateNormalHit() {}
  virtual ~MotionStateNormalHit() {// TODO peteryu unsubscribe all subscriberd
  }
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
  void                        OnAnimationCompleted(const int obj_id, const std::string& name);
  void                        OnFrameEvent(const int obj_id, const std::string& name);  

private:
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber> id_subscriber_map_;
  std::map<uint_32, SkeletonAnimation::FrameEventSubscriber> frame_subscriber_map_;
  //SkeletonAnimation::Subscriber animation_subscriber;
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_normal_hit_h
