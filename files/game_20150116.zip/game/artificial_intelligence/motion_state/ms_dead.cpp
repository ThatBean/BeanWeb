//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_dead.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:39
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_dead.h"

#include <boost/bind.hpp>
#include <boost/signal.hpp>

#include "game/army/unit/move_object.h"
#include "engine/base/random_helper.h"
#include "engine/animation/skeleton_animation.h"


#include "game/battle/battle_controller.h"


namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateDead::OnEnter(army::MoveObject* unit)
{
  id_subscriber_map_[unit->move_object_id()] = 
	  unit->anima_node()->SubscribeActionEvent<MotionStateDead>(this, &MotionStateDead::OnAnimationCompleted);
  unit->set_current_animation_state(ai::kMotionResultActive);

  const battle::eDeadReason dead_reason = unit->get_dead_reason();
  if ( dead_reason == battle::kDeadReason_Normal)
  {
	  unit->ChangeAnimationToIndex(army::kUnitAnimationDead, 1);
  }
  else if ( dead_reason == battle::kDeadReason_Suicide)
  {
	  unit->ChangeAnimationToIndex(army::kUnitAnimationDead_2, 1);
  }
  else if ( dead_reason == battle::kDeadReason_Disappear )
  {
	  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle, 1);
  }

  if ( !unit->is_temp_dead())
  {
	  // hide shadow
	  unit->anima_node()->FadeOutShadow();
	  unit->HideHealthBar();
	  unit->set_be_skill_hitmove_offset(0);
	  unit->anima_node()->runAction(cocos2d::CCFadeOut::create(2.0f));
  }
  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateDead::OnLeave(army::MoveObject* unit)
{
  unit->set_current_animation_state(kMotionResultCompelted);
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
    id_subscriber_map_.find(unit->move_object_id());
  if(itr != id_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr->second);

  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateDead::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  if (unit->current_animation_state() == kMotionResultCompelted)
  {
    this->OnLeave(unit);
  }
  return unit->current_animation_state();
}

void MotionStateDead::OnAnimationCompleted( const int obj_id, const std::string& name )
{
	army::MoveObject* unit =battle::BattleController::GetInstance().GetObjectById(obj_id);
	if ( unit )
	{
		unit->set_current_animation_state(ai::kMotionResultCompelted);

		if ( unit->is_temp_dead())
		{
			unit->set_currnet_health_point(3000);
			unit->set_temp_dead(false);
			unit->set_ai_state(unit->ai_orig_state());
		}
	}
}

} // namespace ai
} // namespace taomee
