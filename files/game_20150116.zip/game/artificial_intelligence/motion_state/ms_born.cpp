//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_born.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:37
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_born.h"

#include "game/army/unit/move_object.h"
#include "engine/base/random_helper.h"
#include "engine/animation/skeleton_animation.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateBorn::OnEnter(army::MoveObject* unit)
{
  unit->set_be_skill_hitmove_offset(0);
  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateBorn::OnLeave(army::MoveObject* unit)
{
  
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateBorn::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  
  return kMotionResultActive;
}
  
} // namespace ai
} // namespace taomee
