//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_attack_reflect.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-24
//          Time:  5:54
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-24        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_attack_reflect.h"

//#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
//#include "game/army/unit/character.h"
#include "game/battle/battle_controller.h"
#include "game/battle/own_hub.h"
#include "game/passive_ability/aura.h"

namespace taomee {
namespace ai {

// NOTE : animation(shield refelect by range attack) is not finished
// replace by one status -- show particle named "shielddefense"
// stage_time to keep reflect time interval
  
eMotionUpdateResult MotionAttackReflect::OnEnter(army::MoveObject* unit)
{
  assert(unit->GetCareerType()==army::kCareerTypeKnight);
//  // set motion state
//  unit->set_current_animation_state(ai::kMotionResultActive);
//  // register notification
//  id_subscriber_map_[unit->move_object_id()] = unit->anima_node()->
//    SubscribeActionEvent<MotionAttackReflect>(this, &MotionAttackReflect::OnAnimationCompleted);
//  // play reflect animation
//  if (unit->owner_hub()->IsRightSideHub())
//  {
//    unit->ChangeAnimationToIndex(army::kUnitAnimationDown, 1, 2.0f);
//  }
//  else
//  {
//    unit->ChangeAnimationToIndex(army::kUnitAnimationAttack, 1, 3.0f);
//  }
  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  unit->set_stage_time(0.0f);
  unit->ShowStatusEffectOnWithName("shielddefense", ability::kEffectPositionType_Mid,!(unit->owner_hub()->IsRightSideHub()));
  return kMotionResultActive;
}

eMotionUpdateResult MotionAttackReflect::OnLeave(army::MoveObject* unit)
{
//  // save motion state
//  unit->set_current_animation_state(ai::kMotionResultCompelted);
//  // unregister notification
//  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
//    id_subscriber_map_.find(unit->move_object_id());
//  if(itr != id_subscriber_map_.end())
//    unit->anima_node()->UnsubscribeActionEvent(itr->second);
  // return compeleted state
  unit->RemoveStatusEffectWithName("shielddefense");
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionAttackReflect::Update(army::MoveObject* unit,
                                                float delta_time)
{
  unit->set_stage_time(unit->stage_time()+delta_time);
  if (unit->stage_time()>0.3f)
  {
    return kMotionResultCompelted;
  }  
  return kMotionResultActive;
//  return unit->current_animation_state();
}
  
//void MotionAttackReflect::OnAnimationCompleted(const int obj_id,
//                                               const std::string& name)
//{
//  battle::BattleController::GetInstance().GetObjectById(obj_id)->
//    set_current_animation_state(ai::kMotionResultCompelted);
//}

} // namespace ai
} // namespace taomee