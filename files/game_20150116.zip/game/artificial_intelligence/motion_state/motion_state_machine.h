//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  motion_state_machine.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  10:20
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_motion_state_machine_h
#define ChainChronicle_motion_state_machine_h

#include "engine/base/basictypes.h"
#include "game/artificial_intelligence/motion_state/motion_state_constants.h"

namespace taomee {

namespace army {
  class MoveObject;
}

namespace ai {
  
class MotionState;
  
class MotionStateMachine
{
public:
  MotionStateMachine();
  virtual ~MotionStateMachine();
  
public:
  bool            Init();
  void            ShutDown();
  
  eMotionUpdateResult ChangeMotion(army::MoveObject* unit,
                                   eMotionStateType new_motion_type);
  
  eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
  
  void            StopAllMotions(army::MoveObject* unit);
  // compare two motions priority : only high priority can replace low priority
  // one. That means low priority motion can be replace directly, but high priority
  // can be be replace until it has been finished -- change the last motion into
  // kMotionStateInvalid, and every kinds of new motion can get kMotionPriorityHigh
  // as a return value to replace the finished one
  eMSPriorityCompare MotionStatePriorityCompare(eMotionStateType motion1,
                                                eMotionStateType motion2);
  
private:
  bool            registerState(eMotionStateType motion_type,
                                MotionState* state);
  // skill beat back
  void            SkillHitMove(army::MoveObject* unit, float delta_time);
private:
  MotionState*    motionStates[kMotionStateMax];
};
  
} // namespace ai
} // namespace taomee

#endif // ChainChronicle_motion_state_machine_h
