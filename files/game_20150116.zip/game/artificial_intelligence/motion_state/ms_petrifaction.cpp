//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_petrifaction.cpp
//        Author:  vic.tang
//       Version:  1
//          Date:  2014-11-10
//          Time:  17:00
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       vic.tang   2014-11-10     1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_petrifaction.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStatePetrifaction::OnEnter(army::MoveObject* unit)
{
  unit->StopAnimation();
  return kMotionResultActive;
}

eMotionUpdateResult MotionStatePetrifaction::OnLeave(army::MoveObject* unit)
{
	unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
	unit->target_selection()->set_target_id(army::kUnexistTargetId);
	return kMotionResultCompelted;
}

eMotionUpdateResult MotionStatePetrifaction::Update(army::MoveObject* unit,
                                               float delta_time)
{
  if ( unit->check_battle_status_flag( battle::kDamagePetrifaction) )
  {    
    return kMotionResultActive;
  }
  else
  {
    return kMotionResultCompelted;
  }
}
  
} // namespace ai
} // namespace taomee
