//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ms_release_skill_triple.h
//        Author: peteryu
//          Date: 2014/4/17 20:08
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/17      add
//////////////////////////////////////////////////////////////

#ifndef MS_RELEASE_SKILL_TRIPLE_H
#define MS_RELEASE_SKILL_TRIPLE_H

#include "game/artificial_intelligence/motion_state/motion_state.h"
#include "engine/animation/skeleton_animation.h"

namespace taomee {
namespace ai {

class MotionStateReleaseSkillTriple : public MotionState
{
public:
  MotionStateReleaseSkillTriple() {}
  virtual ~MotionStateReleaseSkillTriple() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  void                        OnAnimationCompleted(const int obj_id, const std::string& name);
  void                        OnFrameEvent(const int obj_id, const std::string& name);  

  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);

private:
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber> id_subscriber_map_;
  std::map<uint_32, SkeletonAnimation::FrameEventSubscriber> frame_subscriber_map_;
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_release_skill_h
