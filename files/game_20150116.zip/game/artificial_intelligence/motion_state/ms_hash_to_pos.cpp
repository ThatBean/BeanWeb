//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_hash_to_pos.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-19
//          Time:  9:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-19        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_hash_to_pos.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/artificial_intelligence/trigger/target_selection.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateHashToPos::OnEnter(army::MoveObject* unit)
{
  this->resetDerection(unit);
  unit->ChangeAnimationToIndex(army::kUnitAnimationWalk);
  
  return kMotionResultActive;
}

eMotionUpdateResult MotionStateHashToPos::OnLeave(army::MoveObject* unit)
{
  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  unit->set_move_speed(ccp(0.0, 0.0));
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateHashToPos::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  if (fabsf(unit->current_pos().y-unit->target_selection()->hash_position().y)<
      (unit->mover_speed_value()*delta_time))
  {
    unit->set_current_pos(unit->target_selection()->hash_position());
    return kMotionResultCompelted;
  }  
  
  cocos2d::CCPoint move_vec = ccp(unit->move_speed().x*delta_time,
                                  unit->move_speed().y*delta_time);
  unit->set_current_pos(cocos2d::ccpAdd(move_vec, unit->current_pos()));
  return kMotionResultActive;
}

void MotionStateHashToPos::resetDerection(army::MoveObject* unit)
{
  cocos2d::CCPoint new_des_pos = unit->target_selection()->hash_position();
  cocos2d::CCPoint current_pos = unit->current_pos();
  float del_x = new_des_pos.x - current_pos.x;
  float del_y = new_des_pos.y - current_pos.y;
  float distance = sqrt(del_x*del_x + del_y*del_y);
  if (fabsf(distance)<0.00001f)
  {
    unit->set_move_speed(cocos2d::CCPointZero);
  }
  else
  {
    del_x = del_x / distance;
    del_y = del_y / distance;
    unit->set_move_speed(ccp(del_x*unit->mover_speed_value(),
                             del_y*unit->mover_speed_value()));
  }  
}

} // namespace ai
} // namespace taomee