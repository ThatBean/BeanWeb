//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ms_ko.h
//        Author: peteryu
//          Date: 2013/11/19 17:17
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/11/19      add
//////////////////////////////////////////////////////////////
#ifndef MS_KO_H
#define MS_KO_H

#include "game/artificial_intelligence/motion_state/motion_state.h"
#include "engine/animation/skeleton_animation.h"
#include <map>

namespace taomee {
namespace ai {

class MotionStateKo : public MotionState
{
public:
  MotionStateKo() {}
  virtual ~MotionStateKo() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
  void                        OnAnimationCompleted(const int obj_id, const std::string& name);
private:
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber> id_subscriber_map_;
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_dead_h
