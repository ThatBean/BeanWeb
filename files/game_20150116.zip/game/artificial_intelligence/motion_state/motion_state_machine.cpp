﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  motion_state_machine.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  10:20
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/motion_state_machine.h"

#include "game/army/unit/move_object.h"
#include "game/artificial_intelligence/motion_state/ms_attack_reflect.h"
#include "game/artificial_intelligence/motion_state/ms_dead.h"
#include "game/artificial_intelligence/motion_state/ms_hash_to_pos.h"
#include "game/artificial_intelligence/motion_state/ms_idle.h"
#include "game/artificial_intelligence/motion_state/ms_move_to_pos.h"
#include "game/artificial_intelligence/motion_state/ms_move_to_target.h"
#include "game/artificial_intelligence/motion_state/ms_normal_hit.h"
#include "game/artificial_intelligence/motion_state/ms_release_skill.h"
#include "game/artificial_intelligence/motion_state/ms_stunned.h"
#include "game/artificial_intelligence/motion_state/ms_petrifaction.h"
#include "game/artificial_intelligence/motion_state/ms_intertwine.h"
#include "game/artificial_intelligence/motion_state/ms_ko.h"
#include "game/artificial_intelligence/motion_state/ms_release_skill_triple.h"
#include "game/artificial_intelligence/motion_state/ms_trigger_skill.h"
#include "game/battle/own_hub.h"

namespace taomee {
namespace ai {

MotionStateMachine::MotionStateMachine()
{
  memset(motionStates, 0, sizeof(MotionState*)*kMotionStateMax);
}
  
MotionStateMachine::~MotionStateMachine()
{
  this->ShutDown();
}
  
bool MotionStateMachine::Init()
{
  this->registerState(kMotionStateMovePosition, new MotionStateMoveToPos);
  this->registerState(kMotionStateMoveTarget, new MotionStateMoveToTarget);
  this->registerState(kMotionStateIdle, new MotionStateIdle);
  this->registerState(kMotionStateNormalHit, new MotionStateNormalHit);
  this->registerState(kMotionStateReleaseSkillTriple, new MotionStateReleaseSkillTriple);
  this->registerState(kMotionStateDead, new MotionStateDead);
  this->registerState(kMotionStateReleaseSkill, new MotionStateReleaseSkill);
  this->registerState(kMotionStateStunned, new MotionStateStunned);
  this->registerState(kMotionStateAttackReflect, new MotionAttackReflect);
  this->registerState(kMotionStateHashPosition, new MotionStateHashToPos);
  this->registerState(kMotionStateKO, new MotionStateKo);
  this->registerState(kMotionStatePetrifaction, new MotionStatePetrifaction);
  this->registerState(kMotionStateTriggerSkill, new MotionStateTriggerSkill);

  for(int i = 0; i < kMotionStateMax; ++i)
  {
    for(int j = 0; j < kMotionStateMax; ++j)
    {
      eMotionStateType state1 = (eMotionStateType)i;
      eMotionStateType state2 = (eMotionStateType)j;
      bool is_right = true;
      if(motion_state_priority[state1][state2] == 0)
      {
        if(motion_state_priority[state2][state1] != 0)
          is_right = false;
      }
      else if(motion_state_priority[state1][state2] != -motion_state_priority[state2][state1])
        is_right = false;
      if(!is_right)
        CCAssert(false, "Motion State Priority is not Symmetric!");
    }
  }

  return true;
}
  
void MotionStateMachine::ShutDown()
{
  for (int i = 0; i<kMotionStateMax; ++i)
  {
    if (motionStates[i])
    {
      delete motionStates[i];
      motionStates[i] = NULL;
    }
  }
}
  
eMotionUpdateResult MotionStateMachine::Update(army::MoveObject *unit,
                                               float delta_time)
{
  eMotionStateType motion_state = unit->motion_state();
  eMotionUpdateResult ret;
  if(IS_VALID_MOTION_STATE(motion_state) && motionStates[motion_state])
  {
    ret = motionStates[motion_state]->Update(unit, delta_time);
  }
  else
    ret = kMotionResultInactive;

  SkillHitMove(unit, delta_time);
  return ret;
}
  
eMotionUpdateResult MotionStateMachine::ChangeMotion(army::MoveObject* unit,
                                                     eMotionStateType new_motion_type)
{
  eMotionStateType motion_state = unit->motion_state();

  if(!IS_VALID_MOTION_STATE(new_motion_type) || !motionStates[new_motion_type])
  {
    return kMotionResultInvalid;
  }

  if(IS_VALID_MOTION_STATE(motion_state) &&
     new_motion_type != kMotionStateIdle &&
     motion_state_priority[motion_state][new_motion_type] == 1)
  {
    return kMotionResultInvalid;      
//  CCAssert(false, "Low priority motion state can not directly change to high");
  }

  if(motion_state != new_motion_type)
  {
    if(IS_VALID_MOTION_STATE(motion_state) && motionStates[motion_state])
    {
      motionStates[motion_state]->OnLeave(unit);
    }

    unit->set_current_animation_state(kMotionResultActive);
    motionStates[new_motion_type]->OnEnter(unit);

    unit->motion_state_       = new_motion_type;
    unit->last_motion_state_  = motion_state;

    CCLOG("--ID: %ld, MotionState: %s", unit->move_object_id(), 
      GetMotionStateName(unit->motion_state()).c_str());
  }

  return kMotionResultActive;
}
  
void MotionStateMachine::StopAllMotions(army::MoveObject* unit) {
  if(IS_VALID_MOTION_STATE(unit->motion_state()))
    motionStates[unit->motion_state()]->OnLeave(unit);
}
  
eMSPriorityCompare MotionStateMachine::
  MotionStatePriorityCompare(eMotionStateType motion1,
                             eMotionStateType motion2)
{
  assert(motion1>kMotionStateInvalid && motion1<kMotionStateMax);
  if (motion2<=kMotionStateInvalid || motion2>=kMotionStateMax)
  {
    return kMotionPriorityHigh;
  }
  return static_cast<eMSPriorityCompare>(motion_state_priority[motion1][motion2]);
}
  
bool MotionStateMachine::registerState(eMotionStateType motion_type,
                                       MotionState *state) {
  assert(motion_type>kMotionStateInvalid &&
         motion_type<kMotionStateMax);
  // register yet
  if (motionStates[motion_type]) {
    return false;
  }
  else { // empty one, register it
    motionStates[motion_type] = state;
    return true;
  }
}

void MotionStateMachine::SkillHitMove( army::MoveObject* unit, float delta_time )
{
  float offset = unit->be_skill_hitmove_offset() * unit->repeal_distance_multiple();

  if (offset > 0 &&
    !(unit->check_battle_status_flag(battle::kDamageInvincible)) &&
    !(unit->check_battle_status_flag(battle::kDamageStatusImmune)))
  {
    unit->set_be_skill_hitmove_offset(0);
    
    int direction = unit->anima_direction() == kDirectionRight ? -1 : 1;
    int move_delta = 10;
    CCMoveBy* step_01 = CCMoveBy::create(0.025f, ccp(direction * move_delta, 0));
    CCMoveBy* step_02 = CCMoveBy::create(0.05f, ccp(- direction * move_delta * 1.5f, 0));
    CCMoveBy* step_03 = CCMoveBy::create(0.025f, ccp(direction * move_delta * 0.5f, 0));
    unit->anima_node()->runAction(CCSequence::create(step_01, step_02, step_03, NULL));
  }
  return;

  
  //unit->set_be_skill_hitmove_offset(0);
  //return;
  if (offset > 0 &&
      !(unit->check_battle_status_flag(battle::kDamageInvincible)) &&
      !(unit->check_battle_status_flag(battle::kDamageStatusImmune)))
  {
    int_32 back_offset = unit->be_skill_hitmove_offset() > 5 ? 5 : unit->be_skill_hitmove_offset();
    float unit_pos_x = unit->current_pos().x;
    cocos2d::CCPoint tile_pos = battle::GetTileCoordinatePosByCurrentPointPosition(unit->current_pos());
    if (unit->anima_direction() == kDirectionRight) 
    {
      back_offset = 0 - back_offset;
      // can not repeal out of battle grids(left direction)
      if (battle::grid_position_x_y(tile_pos.y, 0).x>unit_pos_x+back_offset)
      {
        back_offset = 0;
      }
    }
    else
    {
      // can not repeal out of battle grids(right direction)
      if (battle::grid_position_x_y(tile_pos.y, battle::kMapColumnCount).x<unit_pos_x+back_offset)
      {
        back_offset = 0;
      }
    }
    unit->set_current_pos(cocos2d::ccpAdd(cocos2d::CCPoint(back_offset,0), unit->current_pos()));
    unit->set_be_skill_hitmove_offset(unit->be_skill_hitmove_offset() - abs(back_offset)); 
    unit->set_be_skill_resetmove_offset(unit->be_skill_resetmove_offset() + abs(back_offset)); 
  }
  else if (unit->be_skill_resetmove_offset() > 0)
  {
    int_32 back_offset = unit->be_skill_resetmove_offset() > 5 ? 5 : unit->be_skill_resetmove_offset();
    float unit_pos_x = unit->current_pos().x;
    cocos2d::CCPoint tile_pos = battle::GetTileCoordinatePosByCurrentPointPosition(unit->current_pos());
    if (!(unit->anima_direction() == kDirectionRight)) 
    {
      back_offset = 0 - back_offset;
      // can not repeal out of battle grids(left direction)
      if (battle::grid_position_x_y(tile_pos.y, 0).x>unit_pos_x+back_offset)
      {
        back_offset = 0;
      }
    }
    else
    {
      // can not repeal out of battle grids(right direction)
      if (battle::grid_position_x_y(tile_pos.y, battle::kMapColumnCount).x<unit_pos_x+back_offset)
      {
        back_offset = 0;
      }
    }
    unit->set_current_pos(cocos2d::ccpAdd(cocos2d::CCPoint(back_offset,0), unit->current_pos()));
    unit->set_be_skill_resetmove_offset(unit->be_skill_resetmove_offset() - abs(back_offset));
  }




}

} // namespace ai
} // namespace taomee