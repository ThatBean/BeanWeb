//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ms_release_skill_triple.cpp
//        Author: peteryu
//          Date: 2014/4/17 20:09
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/17      add
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_release_skill_triple.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/battle/battle_hub.h"
#include "game/army/unit/move_object.h"
#include "game/battle/battle_controller.h"
#include "game/skill/skill_system.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_data_table.h"
#include "game/effect/action_change_color.h"
#include "game/shader/shader_manager.h"
#include "game/effect/action_change_add_self_color.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateReleaseSkillTriple::OnEnter(army::MoveObject* unit)
{
  int_8 castingType = DataManager::GetInstance().GetSkillDataTable()->GetSkill(unit->selected_skill_id())->GetCastingType();
  if (unit->owner_hub()->IsCharacterHub())
  {
	  if ( kCastingType_SingDance == castingType || kCastingType_Continuous == castingType)
	  {
		  unit->retain_battle_status_flag(battle::kDamageStatusImmune);
		  unit->retain_immune_status_flag(battle::kImmuneTypeControl);
	  }
	  else if ( kCastingType_Once == castingType || kCastingType_Combo == castingType)
	  {
		  unit->retain_battle_status_flag(battle::kDamageInvincible);
	  }
  }
  
  if(!unit->is_active() || unit->motion_state() == kMotionStateDead)
  {
    return kMotionResultCompelted;
  }
  
  unit->set_charge_dist(0);
  unit->set_idle_time(0);
  unit->set_normal_skill_cool_time(0.0f);
  unit->set_skill_cool_time(0.0f);
  unit->set_current_animation_state(ai::kMotionResultActive);

  // bug xxx

  unit->target_selection()->set_previous_target_id(unit->target_selection()->target_id());
  AnimationDirection dir = unit->anima_direction();
  unit->set_anima_direction(dir); 

  /*
  if(unit->owner_hub()->IsRightSideHub())
  {
    unit->set_anima_direction(kDirectionLeft);
  }
  else
  {
    unit->set_anima_direction(kDirectionRight);
  }
  */
  //release skill
  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
  int  action_loop_count = -1;

  if( kCastingType_SingDance == castingType )
  {
    action_loop_count = -1;
  }
  else
  {
    id_subscriber_map_[unit->move_object_id()] = unit->anima_node()->\
      SubscribeActionEvent<MotionStateReleaseSkillTriple>(this,\
                                                    &MotionStateReleaseSkillTriple::OnAnimationCompleted);
    frame_subscriber_map_[unit->move_object_id()] = unit->anima_node()->\
      SubscribeFrameEvent<MotionStateReleaseSkillTriple>(this, &MotionStateReleaseSkillTriple::OnFrameEvent);
    action_loop_count = skill_sys->skill_data()->GetSkillBaseActionCount(unit->selected_skill_id());
  }

  unit->set_skill_triple_state(army::kSkillTripleStateReady);

  unit->ChangeAnimationToIndex(
    skill_sys->skill_data()->GetSkillBasePowerMotion1(unit->selected_skill_id()).c_str(),
    1,
    skill_sys->skill_data()->GetSkillBaseActionSpeedRate(unit->selected_skill_id()));

  //skill_sys->PlaySkill(unit->selected_skill_id(),MW_MAGIC_BREAK_TYPE_SELF,unit->move_object_id(),
  //  -1,unit->current_pos().x, unit->current_pos().y);
  
  unit->near_attack_trigger()->set_is_active(false);
  if (unit->guard_trigger())
  {
	  unit->guard_trigger()->set_is_active(false);
  }

  return kMotionResultActive;
}
    
eMotionUpdateResult MotionStateReleaseSkillTriple::OnLeave(army::MoveObject* unit)
{
  if (unit->owner_hub()->IsCharacterHub())
  {
	  int_8 castingType = DataManager::GetInstance().GetSkillDataTable()->GetSkill(unit->selected_skill_id())->GetCastingType();
	  if ( kCastingType_SingDance == castingType || kCastingType_Continuous == castingType)
	  {
		  unit->release_battle_status_flag(battle::kDamageStatusImmune);
		  unit->release_immune_status_flag(battle::kImmuneTypeControl);
	  }
	  else if ( kCastingType_Once == castingType || kCastingType_Combo == castingType)
	  {
		  unit->release_battle_status_flag(battle::kDamageInvincible);
	  }
  }
  
  unit->set_current_animation_state(ai::kMotionResultCompelted);
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
    id_subscriber_map_.find(unit->move_object_id());
  if(itr != id_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr->second);

  std::map<uint_32, SkeletonAnimation::FrameEventSubscriber>::iterator itr_frame =
    frame_subscriber_map_.find(unit->move_object_id());
  if(itr_frame != frame_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr_frame->second);
  //CCLOG("MotionStateNormalHit OnLeave ID: %d", unit->move_object_id());
  unit->target_selection()->resetTargetSelection();

  unit->near_attack_trigger()->set_is_active(true);
  if (unit->guard_trigger() &&
      false == battle::IsStatusAKindOfSkillForbiddenType(static_cast<battle::eDamageStatus>(unit->battle_status_flag())))
  {
    unit->guard_trigger()->set_is_active(true);
  }

//  // Special for SKILL OGI TYPE 43 && 44.
//  SkillDataTable* skill_data_table = DataManager::GetInstance().GetSkillDataTable();
//  if(isSpecial43And44SkillType(unit))
//  {
//    
//  }

  unit->set_normal_skill_cool_time(0.0f);
  unit->set_skill_cool_time(0.0f);
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateReleaseSkillTriple::Update(army::MoveObject* unit,
                                                 float delta_time)
{
  int_8 castingType = DataManager::GetInstance().GetSkillDataTable()->GetSkill(unit->selected_skill_id())->GetCastingType();
  if(kCastingType_SingDance == castingType )
  {
    if(unit->skill_cool_time() >= DataManager::GetInstance().GetSkillDataTable()\
      ->GetSkill(unit->selected_skill_id())->GetDamageTick())
    {
      unit->set_current_animation_state(ai::kMotionResultCompelted);
    }
    return unit->current_animation_state();
  }

  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
  int_32 charge_dist = skill_sys->skill_data()->GetSkillBaseChargeDistance(unit->selected_skill_id());

  if (charge_dist != 0) 
  {
    if (unit->charge_dist() >= charge_dist  ) 
    {
      if (unit->idle_time() >= 0.2f) 
      {
        unit->anima_node()->Resume();
        unit->set_current_animation_state(ai::kMotionResultCompelted);
      }
      else
      {
        unit->set_idle_time(unit->idle_time() + delta_time);
      }
    }
    else
    {
      if (unit->anima_node()->state() == SkeletonAnimation::kStatePaused) 
      {
		// only move in battle field : fixed BUG 104269
        if (battle::GetTileCoordinatePosByCurrentPointPosition(unit->current_pos()).x>=0)
        {
		  unit->set_current_pos(cocos2d::ccpAdd(cocos2d::CCPoint(-10,0), unit->current_pos()));
        }        
        unit->set_charge_dist(unit->charge_dist() + 10);
      }
    }    
  }

  if(unit->skill_triple_state() == army::kSkillTripleStateEnd)
    return unit->current_animation_state();
  else
    return kMotionResultActive;
}
  
void MotionStateReleaseSkillTriple::OnAnimationCompleted( const int obj_id, const std::string& name )
{   
  army::MoveObject* unit = battle::BattleController::GetInstance().
    GetObjectById(obj_id);
  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
  int_32 charge_dist = skill_sys->skill_data()->GetSkillBaseChargeDistance(unit->selected_skill_id());
  if (charge_dist != 0) 
  {
    unit->anima_node()->Pause();
  }
  else
  {
    unit->set_current_animation_state(ai::kMotionResultCompelted);
  }

  switch(unit->skill_triple_state())
  {
  case army::kSkillTripleStateReady:
    {
      unit->set_skill_triple_state(army::kSkillTripleStateAccPower);
      CCLog("kSkillTripleStateReady");
      int_32 repeat_count = skill_sys->skill_data()->GetSkillBasePowerTime(unit->selected_skill_id());
      unit->ChangeAnimationToIndex(
        skill_sys->skill_data()->GetSkillBasePowerMotion2(unit->selected_skill_id()).c_str(),
        repeat_count,
        skill_sys->skill_data()->GetSkillBaseActionSpeedRate(unit->selected_skill_id()));
      unit->anima_node()->GetArmatureNode()->runAction(
        ActionChangeAddSelfColor::create(0.5, repeat_count, 1.0, 2.0));
      //notify skill system play acc power animation
      break;
    }
  case army::kSkillTripleStateAccPower:
    unit->set_skill_triple_state(army::kSkillTripleStateRelease);
    CCLog("kSkillTripleStateAccPower");
    unit->ChangeAnimationToIndex(
      skill_sys->skill_data()->GetSkillBasePowerMotion3(unit->selected_skill_id()).c_str(),
      1,
      skill_sys->skill_data()->GetSkillBaseActionSpeedRate(unit->selected_skill_id()));

    //notify skill system player release animation

    break;
  case army::kSkillTripleStateRelease:
    CCLog("kSkillTripleStateRelease");
    unit->set_skill_triple_state(army::kSkillTripleStateEnd);

    break;
  }
}

void MotionStateReleaseSkillTriple::OnFrameEvent( const int obj_id, const std::string& name )
{
  army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(obj_id);
  if ( !unit )
  {
	  return;
  }
  

  if (name == GetFrameEventName(kFrameEventHit))
  {
    if(!unit->is_active() || unit->motion_state() == kMotionStateDead)
    {
      return;
    }

    battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
    skill_sys->PlaySkill(unit->selected_skill_id(),MW_MAGIC_BREAK_TYPE_TAG,unit->move_object_id(),
      -1,unit->current_pos().x, unit->current_pos().y);
    
    // check self damage skill
    unit->DamageSelfBySuicideSkill();

    int_32 charge_dist = skill_sys->skill_data()->GetSkillBaseChargeDistance(unit->selected_skill_id());
    if (charge_dist != 0) 
    {
      unit->anima_node()->Pause();
    }
  }

  if(unit->skill_triple_state() == army::kSkillTripleStateRelease)
  {
    //notify skill system when hit appear
    CCLog("kSkillTripleStateRelease hit");
  }
}




} // namespace ai
} // namespace taomee
