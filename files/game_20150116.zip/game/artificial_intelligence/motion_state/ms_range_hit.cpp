//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ms_range_hit.cpp
//        Author: peteryu
//          Date: 2013/9/27 14:39
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/9/27      add
//////////////////////////////////////////////////////////////
#include "game/artificial_intelligence/motion_state/ms_range_hit.h"
#include <boost/bind.hpp>
#include <boost/signal.hpp>

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/motion_state/motion_state_machine.h"

#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/move_object.h"
#include "engine/base/random_helper.h"


#include "game/battle/battle_controller.h"
#include "game/skill/skill_system.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateRangeHit::OnEnter(army::MoveObject* unit)
{
  id_subscriber_map_[unit->move_object_id()] = unit->anima_node()->SubscribeActionEvent<MotionStateRangeHit>
    (this, &MotionStateRangeHit::OnAnimationCompleted);
  unit->set_current_animation_state(ai::kMotionResultActive);

  army::MoveObject* target_obj = 
	  battle::BattleController::GetInstance().GetObjectById(unit->target_selection()->target_id());
  if ( target_obj)
  {
	  battle::SkillSystem* skill_sys =  battle::BattleController::GetInstance().skill_sys();
	  skill_sys->PlaySkill(unit->selected_skill_id(), MW_MAGIC_BREAK_TYPE_TAG,
		  unit->move_object_id(), target_obj->move_object_id(),
		  target_obj->current_pos().x, target_obj->current_pos().y);
  }

  return kMotionResultActive;
}

eMotionUpdateResult MotionStateRangeHit::OnLeave(army::MoveObject* unit)
{
  unit->set_current_animation_state(ai::kMotionResultCompelted);
  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber>::iterator itr =
    id_subscriber_map_.find(unit->move_object_id());
  if(itr != id_subscriber_map_.end())
    unit->anima_node()->UnsubscribeActionEvent(itr->second);

  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateRangeHit::Update(army::MoveObject* unit,
  float delta_time)
{
  return unit->current_animation_state();
}

void MotionStateRangeHit::OnAnimationCompleted( const int obj_id, const std::string& name )
{
	army::MoveObject* unit = battle::BattleController::GetInstance().GetObjectById(obj_id);
	if ( unit )
	{
		unit->set_current_animation_state(ai::kMotionResultCompelted);
	}
	
}


} // namespace ai
} // namespace taomee
