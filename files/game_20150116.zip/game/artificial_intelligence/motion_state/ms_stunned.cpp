//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_stunned.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_stunned.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/random_helper.h"
#include "game/army/unit/move_object.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
namespace ai {

eMotionUpdateResult MotionStateStunned::OnEnter(army::MoveObject* unit)
{
  // play aniamtion by stunned type
  unit->StopAnimation();
  if ( !unit->check_battle_status_flag(battle::kDamagePetrifaction))
  {
	  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  }
  
  return kMotionResultActive;
}

eMotionUpdateResult MotionStateStunned::OnLeave(army::MoveObject* unit)
{
  // play idle animation
  unit->target_selection()->set_target_id(army::kUnexistTargetId);
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateStunned::Update(army::MoveObject* unit,
                                               float delta_time)
{
  battle::eDamageStatus currentType = static_cast<battle::eDamageStatus>(unit->battle_status_flag());
  if (battle::IsStatusAKindOfStunType(currentType))
  {    
    return kMotionResultActive;
  }
  else
  {
    return kMotionResultCompelted;
  }
}
  
} // namespace ai
} // namespace taomee
