﻿//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_move_to_target.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-12
//          Time:  10:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-12        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/motion_state/ms_move_to_target.h"

#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/move_object.h"
#include "game/army/unit/unit_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/tiled_map.h"

namespace taomee {
namespace ai {
  
eMotionUpdateResult MotionStateMoveToTarget::OnEnter(army::MoveObject* unit)
{
  if (unit->weak_state() == ai::kWeakStateStrong || unit->weak_state() == ai::kWeakStateChangeStrong) 
  {
    unit->set_weak_state(ai::kWeakStateStrong);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWalk);
  }
  else if (unit->weak_state() == ai::kWeakStateWeak || unit->weak_state() == ai::kWeakStateChangeWeak) 
  {
    unit->set_weak_state(ai::kWeakStateWeak);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWeakWalk);
  }

  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateMoveToTarget::OnLeave(army::MoveObject* unit)
{
  unit->ChangeAnimationToIndex(army::kUnitAnimationIdle);
  return kMotionResultCompelted;
}

eMotionUpdateResult MotionStateMoveToTarget::Update(army::MoveObject* unit,
                                                    float delta_time)
{
  if (unit->weak_state() == ai::kWeakStateChangeStrong) 
  {
    unit->set_weak_state(ai::kWeakStateStrong);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWalk);
  }
  else if (unit->weak_state() == ai::kWeakStateChangeWeak) 
  {
    unit->set_weak_state(ai::kWeakStateWeak);
    unit->ChangeAnimationToIndex(army::kUnitAnimationWeakWalk);
  }

  if(unit->target_selection()->target_id() == army::kUnexistTargetId)
    return kMotionResultCompelted;

  army::MoveObject *target_obj = battle::BattleController::GetInstance()\
                                           .GetObjectById(unit->target_selection()->target_id());
  
  // TO DO : check target id reset method
  if(!target_obj || !target_obj->is_active())
    return kMotionResultCompelted;



  //calc direction

  cocos2d::CCPoint cur_pos = unit->current_pos();
  cocos2d::CCPoint target_pos = target_obj->offset_points_count() > 1 ? target_obj->get_pos_by_offset(unit->target_selection()->target_id_point_offset()) : target_obj->current_pos();
  //if (target_obj->owner_hub()->)
  if(ccpDistanceSQ(cur_pos, target_pos) <= (delta_time*unit->mover_speed_value()*delta_time*unit->mover_speed_value()))
  {    
    unit->set_current_pos(target_pos);
    cocos2d::CCPoint fitablePos = battle::BattleController::GetInstance().tiled_map()-> \
      FindEmptyFitablePointPositionForMoveObjectFight(unit->move_object_id(), target_pos);
    if (ccpDistanceSQ(fitablePos, target_pos) <= 1.0f)
    {
      return kMotionResultCompelted;
    }
    else
    {
      target_pos = fitablePos;
    }
  }

  float del_x = target_pos.x - cur_pos.x;
  float del_y = target_pos.y - cur_pos.y;
  float distance = sqrt(del_x*del_x + del_y*del_y);

  del_x = del_x / distance;
  del_y = del_y / distance;
  
  cocos2d::CCPoint new_pos = ccp(cur_pos.x + del_x * delta_time * unit->mover_speed_value(),
    cur_pos.y + del_y * delta_time * unit->mover_speed_value());

  
  //cocos2d::CCPoint min_range = ccpAdd(battle::grid_position_x_y(battle::kMapRowCount, 0), ccp(battle::kMapTileMaxLength / 2, battle::kMapTileMaxHeight / 2));
  //cocos2d::CCPoint max_range = ccpAdd(battle::grid_position_x_y(0, battle::kMapColumnCount), ccp(-battle::kMapTileMaxLength / 2, -battle::kMapTileMaxHeight / 2));

  //new_pos.x = new_pos.x < min_range.x ? min_range.x : new_pos.x;
  //new_pos.x = new_pos.x > max_range.x ? max_range.x : new_pos.x;
  //new_pos.y = new_pos.y < min_range.y ? min_range.y : new_pos.y;
  //new_pos.y = new_pos.y > max_range.y ? max_range.y : new_pos.y;
  


  unit->set_current_pos(new_pos);

  if (target_pos.x - cur_pos.x > 2.0) {
    unit->set_anima_direction(kDirectionRight);
  }
  else {
    unit->set_anima_direction(kDirectionLeft);
  }

  return kMotionResultActive;
}
    
} // namespace ai
} // namespace taomee

