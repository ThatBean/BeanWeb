//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_intertwine.h
//        Author:  vic.tang
//       Version:  1
//          Date:  2014-11-27
//          Time:  17:00
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       vic.tang     2014-11-27        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ms_intertwine_h
#define ChainChronicle_ms_intertwine_h

#include "game/artificial_intelligence/motion_state/motion_state.h"

namespace taomee {
namespace ai {

class MotionStateIntertwine : public MotionState
{
public:
  MotionStateIntertwine() {}
  virtual ~MotionStateIntertwine() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
 
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_stunned_h
