//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_stunned.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:45
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ms_stunned_h
#define ChainChronicle_ms_stunned_h

#include "game/artificial_intelligence/motion_state/motion_state.h"

namespace taomee {
namespace ai {

class MotionStateStunned : public MotionState
{
public:
  MotionStateStunned() {}
  virtual ~MotionStateStunned() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
 
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_stunned_h
