//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_move_to_pos.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:44
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ms_release_skill_h
#define ChainChronicle_ms_release_skill_h

#include "game/artificial_intelligence/motion_state/motion_state.h"
#include "engine/animation/skeleton_animation.h"
namespace taomee {

namespace ai {

class MotionStateReleaseSkill : public MotionState
{
public:
  MotionStateReleaseSkill() {}
  virtual ~MotionStateReleaseSkill() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  void                        OnAnimationCompleted(const int obj_id, const std::string& name);
  void                        OnFrameEvent(const int obj_id, const std::string& name);  

  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);

private:
	enum taomee::AnimationDirection CheckEnemyForBetterDirection( army::MoveObject* unit );

  std::map<uint_32, SkeletonAnimation::ActionEventSubscriber> id_subscriber_map_;
  std::map<uint_32, SkeletonAnimation::FrameEventSubscriber> frame_subscriber_map_;
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_release_skill_h
