//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_idle.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-16
//          Time:  2:40
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-16        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_ms_idle_h
#define ChainChronicle_ms_idle_h

#include "game/artificial_intelligence/motion_state/motion_state.h"

namespace taomee {
namespace ai {

class MotionStateIdle : public MotionState
{
public:
  MotionStateIdle() {}
  virtual ~MotionStateIdle() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
  
};

} // namespace ai
} // namespace taomee

#endif // ChainChronicle_ms_idle_h
