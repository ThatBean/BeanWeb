//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  ms_hash_to_pos.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-19
//          Time:  9:55
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-19        1         create
//////////////////////////////////////////////////////////////

#ifndef __ChainChronicle__ms_hash_to_pos__
#define __ChainChronicle__ms_hash_to_pos__

#include "game/artificial_intelligence/motion_state/motion_state.h"

namespace taomee {
namespace ai {

class MotionStateHashToPos : public MotionState
{
public:
  MotionStateHashToPos() {}
  virtual ~MotionStateHashToPos() {}
  
public:
  virtual eMotionUpdateResult OnEnter(army::MoveObject* unit);
  virtual eMotionUpdateResult OnLeave(army::MoveObject* unit);
  
  virtual eMotionUpdateResult Update(army::MoveObject* unit, float delta_time);
  
private:
  // calculate derection for move animation and move speed along x&y axis
  void resetDerection(army::MoveObject* unit);
};

} // namespace ai
} // namespace taomee

#endif /* defined(__ChainChronicle__ms_hash_to_pos__) */
