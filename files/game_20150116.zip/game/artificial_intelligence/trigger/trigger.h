//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  trigger.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-10
//          Time:  2:35
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-10        1         create
//////////////////////////////////////////////////////////////

#ifndef AI_TRIGGER_TRIGGER_H_
#define AI_TRIGGER_TRIGGER_H_
#pragma once

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/geometry/geometry.h"
#include "game/army/unit/unit_constants.h"

enum eTriggerType
{
  kTriggerAttack,
  kTriggerGuard
};

enum eTriggerTroopType
{
  kTriggerTroopNone       = 0, //for non-attacking ai
  kTriggerTroopEnemey     = 0x01 << 0,
  kTriggerTroopTeamate    = 0x01 << 1,
  kTriggerTroopSelf       = 0x01 << 2
};

enum eTriggerConditionType
{
  kTriggerConditionShapeArea    = 0,
  kTriggerConditionCure         = 0x01 << 0,
  kTriggerConditionScript       = 0x01 << 1,
  kTriggerConditionMax
};

const uint_32 kTriggerConditionCount        = 3;

class CharacterData;

#define SQUARE(x) ((x) * (x))
#define SQUARE_SUM(x, y)

namespace taomee {
namespace army
{
  class MoveObject;
  class TroopsHub;
}

namespace ai {

class Trigger {
public:
  Trigger(army::MoveObject *unit, eTriggerType trigger_type, uint_32 trigger_troop_type, 
    uint_32 trigger_condition_type = kTriggerConditionShapeArea);
  ~Trigger();

  void                Update(float delta_time);
  uint_32             GetClosestId()
  {
    if (!is_active_)
    {
      return army::kUnexistTargetId;
    }
    return ((range_list_.size() == 0) ? army::kUnexistTargetId : (*range_list_.begin()));
  }
  uint_32             GetClosestIdPointOffset()
  {
    return closest_id_point_offset_;
  }
  std::list<uint_32>& GetRangeList()
  {
    return range_list_;
  }
  
  void set_circle_guard_radius(float newRadius)
  {
    circle_guard_radius_ = newRadius;
  }
  float circle_guard_radius() { return circle_guard_radius_; }
  void  reset_circle_guard_radius();
  
  void  set_is_active(bool activeFlag)
  {
    is_active_ = activeFlag;
  }
  void  set_is_active_except_healer(bool activeFlag);
  bool  is_active() { return is_active_; }
  
  uint_32 get_trigger_condition_type ();
  void set_trigger_condition_type (uint_32 trigger_condition_type);

protected:
  void                PickObjectInAttackRange(army::TroopsHub* troops);
  void                PickObjectInGuardRange(army::TroopsHub* troops);
  void                PickObjectNotFullOfBlood();
  void                PickObjectByScript();
  void                ConvertAndFilterSelf(std::list<army::MoveObject*> &obj_list);

protected:
  bool                is_active_;
  army::MoveObject    *unit_;
  CharacterData       *char_data;
  std::list<uint_32>  range_list_;
  float               min_distance_sq_;
  int                 closest_id_point_offset_;

  eTriggerType        trigger_type_;
  uint_32             trigger_troop_type_;
  uint_32             trigger_condition_type_;
  
  float               circle_guard_radius_;  

private:
  DISALLOW_COPY_AND_ASSIGN(Trigger);
};

}  // namespace ai
}  // namespace taomee

#endif  // AI_TRIGGER_TRIGGER_H_
