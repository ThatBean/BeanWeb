//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  priority_queue.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-10
//          Time:  2:35
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-10        1         create
//////////////////////////////////////////////////////////////

#ifndef iwar_PriorityQueue_h
#define iwar_PriorityQueue_h

#include <cassert>
#include "engine/base/basictypes.h"

using namespace std;

namespace taomee {
namespace ai {

template<class T>
void Swap(T& a, T& b)
{
    T temp = a;
    a = b;
    b = temp;
}

template <typename keyType>
class PriorityQueue
{
private:
    std::vector<keyType> heap;
    int                  curSize;
    int                  maxSize;
    
    void ReorderUpwards(std::vector<keyType>& heap, int nodeIndex)
    {
        while ( nodeIndex>1 && (heap[nodeIndex/2] < heap[nodeIndex]) ) 
        {
            Swap(heap[nodeIndex/2], heap[nodeIndex]);
            nodeIndex /= 2;
        }
    }    
    
    void ReorderDownwards(std::vector<keyType>& heap, int nodeIndex, int heapSize)
    {
        while (2*nodeIndex < heapSize)
        {
            int childIndex = 2*nodeIndex;
            if ( (childIndex<heapSize)&&(heap[childIndex]<heap[childIndex+1]) ) {
                ++childIndex;
            }
            if (heap[nodeIndex]<heap[childIndex]) {
                Swap(heap[nodeIndex],heap[childIndex]);
                nodeIndex = childIndex;
            }
            else
            {
                break;
            }
        }
    }
    
public:
    PriorityQueue(int maxSize):maxSize(maxSize), curSize(0)
    {
        heap.assign(maxSize+1, keyType());         
    }
    
    bool empty()const{return (curSize==0);}
    
    void insert(const keyType item)
    {
        assert(curSize+1 <= maxSize);
        heap[++curSize] = item;
        ReorderUpwards(heap, curSize);
    }
    
    keyType pop()
    {
        Swap(heap[1], heap[curSize]);
        ReorderDownwards(heap, 1, curSize-1);
        return heap[curSize--];
    }
    
    const keyType& peek()const{return heap[curSize];}
};

template <typename T>
class PriorityQueueLow
{
private:
    std::vector<T> heap;
    int            curSize;
    int            maxSize;
    
    void reorderUpwards(std::vector<T>& _heap, int nodeIndex)
    {
        while ((nodeIndex>1) && (_heap[nodeIndex/2]>_heap[nodeIndex]))
        {
            Swap(_heap[nodeIndex/2], _heap[nodeIndex]);
            nodeIndex /= 2;
        }
    }
    
    void reorderDownWards(std::vector<T>& _heap, int nodeIndex, int heapSize)
    {
        while ( nodeIndex*2<=heapSize ) {
            int child = 2*nodeIndex;
            if ((child<heapSize) && (_heap[child]>_heap[child+1])) {
                ++child;
            }
            if (_heap[nodeIndex]>_heap[child]) {
                Swap(_heap[child], _heap[nodeIndex]);
                nodeIndex = child;
            }
            else
            {
                break;
            }
        }
    }
public:
    PriorityQueueLow(int _maxSize):maxSize(_maxSize), curSize(0)
    {
        heap.assign(maxSize+1,T());
    }
    
    bool empty()const{return curSize==0;}
    
    void insert(const T item)
    {
        assert(curSize+1<=maxSize);
        heap[++curSize]=item;
        reorderUpwards(heap, curSize);
    }
    
    T pop()
    {
        Swap(heap[1], heap[curSize]);
        reorderDownWards(heap, 1, curSize-1);
        return heap[curSize--];
    }
    
    const T& peek() {return heap[1];}
};

template <class KeyType>
class IndexedPriorityQueueLow
{
private:
    std::vector<KeyType>&   vecKeys;
    std::vector<int>        heap;
    std::vector<int>        indexHeap;
    
    int                     curSize,
                            maxSize;
    
private:
  void swap(int a, int b)
    {
        int temp = heap[a]; heap[a] = heap[b]; heap[b] = temp;
        indexHeap[heap[a]] = a; indexHeap[heap[b]] = b;
    }
    
    void reorderUpwards(int nodeIndex)
    {
        while ((nodeIndex>1) && (vecKeys[heap[nodeIndex/2]]>vecKeys[heap[nodeIndex]])) 
        {
            swap(nodeIndex/2, nodeIndex);
            nodeIndex /= 2;
        }
    }
    
    void reorderDownwards(int nodeIndex, int heapSize)
    {
        while (2*nodeIndex<=heapSize) 
        {
            int child = 2*nodeIndex;
            if ((child<heapSize) && (vecKeys[heap[child]]>vecKeys[heap[child+1]])) {
                ++child;
            }
            if (vecKeys[heap[nodeIndex]]>vecKeys[heap[child]]) {
                swap(child, nodeIndex);
                nodeIndex = child;
            }
            else
            {
                break;
            }
        }
    }
public:
    IndexedPriorityQueueLow(std::vector<KeyType>&   keys,
                            int                 _maxSzie):vecKeys(keys),
                                                          maxSize(_maxSzie),
                                                          curSize(0)
    {
        heap.assign(maxSize+1, 0);
        indexHeap.assign(maxSize+1, 0);
    }
    
    bool empty()const{return (curSize==0);}
    
    void insert(const int nodeIndex)
    {
        assert(curSize+1<=maxSize);
        heap[++curSize] = nodeIndex;
        indexHeap[nodeIndex] = curSize;
        reorderUpwards(curSize);
    }
    
    int pop()
    {
        swap(1, curSize);
        reorderDownwards(1, curSize-1);
        return heap[curSize--];
    }
    
    void changePriority(const int nodeIndex)
    {
        reorderUpwards(indexHeap[nodeIndex]);
    }
  
    void clear()
    {
        heap.clear();
        indexHeap.clear();
    }
  
    void assign() {
        heap.assign(heap.size(), 0);
        indexHeap.assign(indexHeap.size(), 0);
    }
};

}  // namespace ai
}  // namespace taomee

#endif
