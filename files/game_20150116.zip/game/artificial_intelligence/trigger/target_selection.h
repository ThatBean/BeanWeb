//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  target_selection.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-10
//          Time:  2:35
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-10        1         create
//////////////////////////////////////////////////////////////

#ifndef target_selection_h
#define target_selection_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/tiled_map/map_constants.h"
#include "game/army/unit/move_object.h"
#include "game/passive_ability/aura.h"
#include "game/event/event_battle/event_battle_obj.h"

namespace taomee {
namespace ai {

template <class owner_type>
class TargetSelection {
public:
  TargetSelection(owner_type* owner, 
                  uint_32 targetId,
                  cocos2d::CCPoint targetPos = cocos2d::CCPointZero,
                  uint_32 choosenTargetId = army::kUnexistTargetId)
  : owner_(owner),
    is_new_direction_(false),
    is_forced_move_to_(false),
    target_id_(targetId),
    target_id_point_offset_(0),
    target_position_(targetPos),
    hash_position_(battle::kUnexistCoordinatePoint),
    choosen_target_id_(choosenTargetId),
    previous_target_id_(army::kUnexistTargetId),
	first_in_place(true)
  {}
  
  ~TargetSelection() {}
  
public:
  const owner_type*  owner() { return owner_; }
  
  // flag for redirection in move motion
  bool is_new_direction() { return is_new_direction_; }
  void set_is_new_direction(bool is_new) { is_new_direction_ = is_new; }
  
  // this flag is only for user's operation : move unit to target position forcely
  bool is_forced_move_to() 
  { 
	  return is_forced_move_to_;
  }
  void set_is_forced_move_to(bool is_force)
  {
	  is_forced_move_to_ = is_force;
  }
  
  // set & get target id
  void set_target_id(int_32 targetId)
  {
    target_id_ = targetId;
  }
  const int_32 target_id() { return target_id_; }

  // set & get target id point offset
  void set_target_id_point_offset(int target_id_point_offset)
  {
    target_id_point_offset_ = target_id_point_offset;
  }
  int_32 target_id_point_offset(){return target_id_point_offset_;}
  
  // set & get current hit target id
  void set_choosen_target_id(int_32 targetId)
  {
    choosen_target_id_ = targetId;
  }
  const int_32 choosen_target_id() { return choosen_target_id_; }
 
  // set & get target position
  void set_target_pos(cocos2d::CCPoint targetPos)
  {
    if(ccpDistanceSQ(target_position_, targetPos) < 0.1f)
      is_new_direction_ = false;
    else
      is_new_direction_ = true;
    target_position_ = targetPos;
  }
  cocos2d::CCPoint& target_position() {
    return target_position_;
  }
  
  void set_hash_position(cocos2d::CCPoint targetPos)
  {
    hash_position_ = targetPos;
  }
  cocos2d::CCPoint& hash_position() {
    return hash_position_;
  }

  bool  target_position_isvalid()
  {
    if (target_position_.x == -1 && target_position_.y == -1) 
    {
      return false;
    }
    return true;
  }

  int_32 previous_target_id()
  {
    return previous_target_id_;
  }
  void set_previous_target_id(int_32 previous_target_id)
  {
    previous_target_id_ = previous_target_id;
  }
  
public:
  void resetTargetSelection() {
    is_new_direction_ = false;
    is_forced_move_to_ = false;
    target_id_ = army::kUnexistTargetId;
    target_id_point_offset_ = 0;
    target_position_ = battle::kUnexistCoordinatePoint;
    hash_position_ = battle::kUnexistCoordinatePoint;
    choosen_target_id_ = army::kUnexistTargetId;
    previous_target_id_ = army::kUnexistTargetId;
	if ( first_in_place )
	{
		first_in_place = false;
		MoveObjFirstInPlace::Emit(owner_->move_object_id());
	}
  }
  
  void initWithTargetSelec(TargetSelection<owner_type>* targetSelec) {
    is_new_direction_ = targetSelec->is_new_direction();
    is_forced_move_to_ = targetSelec->is_forced_move_to();
    target_id_ = targetSelec->target_id();
    target_id_point_offset_ = targetSelec->target_id_point_offset();
    target_position_ = targetSelec->target_position();
    choosen_target_id_ = targetSelec->choosen_target_id();
    hash_position_ = targetSelec->hash_position();
  }
  
private:
  owner_type*       owner_;
  
  bool              is_new_direction_;
  bool              is_forced_move_to_;
  int_32            choosen_target_id_;
  int_32            target_id_;
  int_32            target_id_point_offset_;
  // for user drag operation
  int_32            previous_target_id_;
  cocos2d::CCPoint  target_position_;
  cocos2d::CCPoint  hash_position_;
  
  bool first_in_place;
private:
  DISALLOW_COPY_AND_ASSIGN(TargetSelection);
};

}  // namespace ai
}  // namespace taomee
#endif
