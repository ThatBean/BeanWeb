//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  trigger.cc
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-10
//          Time:  2:35
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-10        1         create
//////////////////////////////////////////////////////////////

#include "game/artificial_intelligence/trigger/trigger.h"

#include "engine/base/basictypes.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/army/unit/move_object.h"
#include "game/army/unit_hub/troops_hub.h"
#include "game/army/unit_hub/summon_troops_hub.h"
#include "game/battle/battle_hub.h"
#include "game/army/unit/unit_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/tiled_map/tiled_map.h"
#include "game/data_table/character_data_table.h"
#include "game/game_manager/data_manager.h"

namespace taomee {
namespace ai {

Trigger::Trigger(army::MoveObject *unit, 
  eTriggerType trigger_type, 
  uint_32 trigger_troop_type,
  uint_32 trigger_condition_type/*default = kTriggerConditionShapeArea*/)
  : is_active_(true),
    unit_(unit),
    trigger_type_(trigger_type),
    trigger_troop_type_(trigger_troop_type),
    trigger_condition_type_(trigger_condition_type)
{
  char_data = unit_->character_card_data();
  circle_guard_radius_ = char_data->GetPatrolParam1();
  unit_->set_base_circle_guard_radius(circle_guard_radius_);
}

Trigger::~Trigger()
{

}
  


uint_32 Trigger::get_trigger_condition_type () 
{
  return trigger_condition_type_;
}

void Trigger::set_trigger_condition_type (uint_32 trigger_condition_type) 
{
  if (trigger_condition_type  < kTriggerConditionMax) 
 {
   trigger_condition_type_ = trigger_condition_type;
  }
}





void Trigger::set_is_active_except_healer(bool activeFlag)
{
  if (unit_->GetCareerType()==army::kCareerTypeMonk)
  {
    return;
  }
  is_active_ = activeFlag;
}
  
void Trigger::reset_circle_guard_radius()
{
  circle_guard_radius_ = char_data->GetPatrolParam1();
}

void Trigger::Update( float delta_time )
{
  if(!is_active_)
    return;
  
  if(range_list_.size() != 0)
    range_list_.clear();

  min_distance_sq_        = 100000000.0f;  
  closest_id_point_offset_= 0;

  if((trigger_troop_type_ & kTriggerTroopEnemey) && (trigger_troop_type_ & kTriggerTroopTeamate))
  {
    if(trigger_type_ == kTriggerAttack)
    {
      PickObjectInAttackRange(unit_->owner_hub()->troops());
	  PickObjectInAttackRange(unit_->owner_hub()->summon_troops());
      PickObjectInAttackRange(unit_->owner_hub()->enemy_hub()->troops());
	  PickObjectInAttackRange(unit_->owner_hub()->enemy_hub()->summon_troops());
    }
    else if(trigger_type_ == kTriggerGuard)
    {
      if(char_data->GetPatrolType() == kPatrolAreaCircle)
	  {
        PickObjectInGuardRange(unit_->owner_hub()->troops());
		PickObjectInGuardRange(unit_->owner_hub()->summon_troops());
	  }
      else
      {
        std::vector<int_8> tile_list;
        battle::BattleController::GetInstance().tiled_map()->GetRangeQuadrangleTilesList(
			tile_list, unit_->tile_index(), char_data->GetPatrolParam1(), unit_->owner_hub()->IsRightSideHub());
        battle::BattleController::GetInstance().GetAllMoveObjectsInTilesWithIndexList(
			tile_list, range_list_, NULL, unit_->current_pos());
        if( !(trigger_troop_type_ & kTriggerTroopSelf) && 
            range_list_.size() > 0 &&
            (*range_list_.begin()) == unit_->move_object_id())
        {
          range_list_.pop_front();
        }
      }
    }
  }
  else if(trigger_troop_type_ & kTriggerTroopEnemey)
  {
    if(trigger_type_ == kTriggerAttack)
    {
		if ( unit_->check_battle_status_flag( battle::kDamageEnchantment))
		{
			PickObjectInAttackRange(unit_->owner_hub()->troops());
			PickObjectInAttackRange(unit_->owner_hub()->summon_troops());
		}
		else
		{
			PickObjectInAttackRange(unit_->owner_hub()->enemy_hub()->troops());
			PickObjectInAttackRange(unit_->owner_hub()->enemy_hub()->summon_troops());
		}
    }
    else if(trigger_type_ == kTriggerGuard)
    {
      if(char_data->GetPatrolType() == kPatrolAreaCircle)
	  {
		  if ( unit_->check_battle_status_flag( battle::kDamageEnchantment))
		  {
			  PickObjectInGuardRange(unit_->owner_hub()->troops());
			  PickObjectInGuardRange(unit_->owner_hub()->summon_troops());
		  }
		  else
		  {
			  PickObjectInGuardRange(unit_->owner_hub()->enemy_hub()->troops());
			  PickObjectInGuardRange(unit_->owner_hub()->enemy_hub()->summon_troops());
		  }
	  }
      else
      {
		  std::vector<int_8> tile_list;
		  battle::BattleController::GetInstance().tiled_map()->GetRangeQuadrangleTilesList(
			  tile_list,unit_->tile_index(), char_data->GetPatrolParam1(),unit_->owner_hub()->IsRightSideHub());
		  if ( unit_->check_battle_status_flag( battle::kDamageEnchantment))
		  {
			  battle::BattleController::GetInstance().GetAllMoveObjectsInTilesWithIndexList(
				  tile_list, range_list_, unit_->owner_hub(), unit_->current_pos());
		  }
		  else
		  {
			  battle::BattleController::GetInstance().GetAllMoveObjectsInTilesWithIndexList(
				  tile_list, range_list_, unit_->owner_hub()->enemy_hub(), unit_->current_pos());
		  }
      }
    }
  }
  else if(trigger_troop_type_ & kTriggerTroopTeamate)
  {
    if(trigger_type_ == kTriggerAttack)
    {
      PickObjectInAttackRange(unit_->owner_hub()->troops());
    }
    else if(trigger_type_ == kTriggerGuard)
    {
      if(char_data->GetPatrolType() == kPatrolAreaCircle)
        PickObjectInGuardRange(unit_->owner_hub()->troops());
      else
      {
        std::vector<int_8> tile_list;
        battle::BattleController::GetInstance().tiled_map()->GetRangeQuadrangleTilesList(
          tile_list, unit_->tile_index(), char_data->GetPatrolParam1(),
          unit_->owner_hub()->IsRightSideHub());
        battle::BattleController::GetInstance().GetAllMoveObjectsInTilesWithIndexList(tile_list,
          range_list_, unit_->owner_hub(), unit_->current_pos());
        if( !(trigger_troop_type_ & kTriggerTroopSelf) && 
            range_list_.size() > 0 &&
            (*range_list_.begin()) == unit_->move_object_id())
        {
          range_list_.pop_front();
        }
      }
    }
  }

  // filter the list with the given condition
  for(int i = 0; i < kTriggerConditionCount; ++i)
  {
    switch(trigger_condition_type_ & (0x01 << i))
    {
    case kTriggerConditionCure:
      {
        PickObjectNotFullOfBlood();
        break;
      }
    case kTriggerConditionScript:
      {
        PickObjectByScript();
        break;
      }
    default:
      break;
    }
  }
}

void Trigger::PickObjectInAttackRange( army::TroopsHub* troops )
{
  army::MoveObject* obj = NULL;   

  float unit_attack_range = char_data->GetAttackRange() * battle::kMapTileMinHeight;
  float other_body_range = 0.0f;
  float cur_distance_sq = 0.0f;
  float attack_body_distance_sq = 0.0f;

  for(int i = 0; i < troops->active_ids_count(); ++i)
  {
    obj = troops->GetActiveObjectByIndex(i);

	if ( obj->is_temp_dead())
	{
		continue;
	}

    if(!(trigger_troop_type_ & kTriggerTroopSelf))
    {
      if(obj->move_object_id() == this->unit_->move_object_id() )
        continue;
    }

    other_body_range = obj->character_card_data()->GetAttackRange() * battle::kMapTileMinHeight;

    attack_body_distance_sq = SQUARE(unit_attack_range + other_body_range);

    for(int off_set = 0; off_set < unit_->offset_points_count(); ++off_set)
    {
      for(int i = 0; i < obj->offset_points_count(); ++i)
      {
        cur_distance_sq = ccpDistanceSQ(unit_->get_pos_by_offset(off_set), obj->get_pos_by_offset(i));
        if(cur_distance_sq <= attack_body_distance_sq)
        {
          if(cur_distance_sq < min_distance_sq_)
          {
            min_distance_sq_ = cur_distance_sq;
            closest_id_point_offset_ = i;
            range_list_.push_front(obj->move_object_id());
          }
          else
          {
            range_list_.push_back(obj->move_object_id());
          }
        }
      }
    }
    
  }
}

void Trigger::PickObjectInGuardRange( army::TroopsHub* troops )
{
  army::MoveObject* obj = NULL;   

  // guard area type is circle
  if(char_data->GetPatrolType() == kPatrolAreaCircle)
  {
    float unit_guard_range = circle_guard_radius_ * battle::kMapTileMinHeight;
    float other_body_range = 0.0f;
    float cur_distance_sq = 0.0f;
    float guard_body_distance_sq = 0.0f;

    for(int i = 0; i < troops->active_ids_count(); ++i)
    {
      obj = troops->GetActiveObjectByIndex(i);

	  if ( obj->is_temp_dead())
	  {
		  continue;
	  }

      if(!(trigger_troop_type_ & kTriggerTroopSelf))
      {
        if(obj->move_object_id() == this->unit_->move_object_id() )
          continue;
      }

      other_body_range = obj->character_card_data()->GetAttackRange() * battle::kMapTileMinHeight;

      guard_body_distance_sq = SQUARE(unit_guard_range + other_body_range);

      for(int i = 0; i < obj->offset_points_count(); ++i)
      {
        cur_distance_sq = ccpDistanceSQ(unit_->current_pos(), obj->get_pos_by_offset(i));
        if(cur_distance_sq <= guard_body_distance_sq)
        {
          if(cur_distance_sq < min_distance_sq_)
          {
            min_distance_sq_ = cur_distance_sq;
            closest_id_point_offset_ = i;
            range_list_.push_front(obj->move_object_id());
          }
          else
          {
            range_list_.push_back(obj->move_object_id());
          }
        }
      }
    }
  }
}

void Trigger::PickObjectNotFullOfBlood()
{
  std::list<uint_32>::iterator itr = range_list_.begin();
  army::MoveObject *obj = NULL;

  while(itr != range_list_.end())
  {
    obj = battle::BattleController::GetInstance().GetObjectById(*itr);

    if( obj && obj->currnet_health_point() >= obj->total_health_point())
    {
      std::list<uint_32>::iterator pos = itr;
      itr = range_list_.erase(pos);
    }
    else
    {
      ++itr;
    }
  }
}

void Trigger::PickObjectByScript()
{
  //check the target id by script
  int target_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
    "script/battle/lua_trigger_condition.lua", 
    "PickObject",
    unit_->move_object_id(),
    trigger_type_
  );

  if (target_id < 0)
  {
    return;
  }
  
  //search the target id in list. Found or not, clear other ids in list
  std::list<uint_32>::iterator itr = range_list_.begin();
  uint_32 unit_id;
  army::MoveObject *obj = NULL;

  while(itr != range_list_.end())
  {
    unit_id = *itr;
    if (target_id == unit_id)
    {
      
      range_list_.push_front(target_id);
      return;
    }
    ++itr;
  }

  //claer anyway
  range_list_.clear();
}

void Trigger::ConvertAndFilterSelf( std::list<army::MoveObject*> &obj_list )
{
  for(std::list<army::MoveObject*>::iterator itr = obj_list.begin(); 
    itr != obj_list.end(); ++itr)
  {
    if(trigger_troop_type_ & kTriggerTroopSelf)
    {
      range_list_.push_back((*itr)->move_object_id());
    }
    else
    {
      if((*itr)->move_object_id() != unit_->move_object_id())
      {
        range_list_.push_back((*itr)->move_object_id());
      }
    }
  }
}



}  // namespace ai
}  // namespace taomee


