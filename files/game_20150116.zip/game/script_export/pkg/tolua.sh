tolua++ -L basic.lua -tCocos2d -o ../lua_client_export.cpp lua_client_export.pkg
