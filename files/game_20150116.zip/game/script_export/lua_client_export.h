//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: lua_client_export.h
//        Author: robbiepan
//          Date: 2013/9/9 10:52
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/9      add
//////////////////////////////////////////////////////////////

#ifndef LUA_CLIENT_EXPORT_H
#define LUA_CLIENT_EXPORT_H

#include "tolua_fix.h"
#include "cocos2d.h"

#pragma warning(disable:4800)

extern "C" {
#include "tolua++.h"
#include "tolua_fix.h"
}

USING_NS_CC;

TOLUA_API int  tolua_lua_client_export_open (lua_State* tolua_S);
#endif