//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: shader_manager.cpp
//        Author: peteryu
//          Date: 2013/9/27 11:40
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2013/9/27      add
//////////////////////////////////////////////////////////////

#include "shader_manager.h"
#include "game/shader/shader_program/program_change_color.h"
#include "game/shader/shader_program/program_change_add_color.h"
#include "game/shader/shader_program/program_change_add_self_color.h"
#include "game/shader/shader_program/program_change_to_color.h"

namespace taomee{
namespace shader{

const GLchar *shader_gray_scale_frag =
#include "game/shader/shader_src/shader_gray_scale_frag.h"
const GLchar *shader_gray_scale_vert =
#include "game/shader/shader_src/shader_gray_scale_vert.h"

const GLchar *shader_bright_scale_frag =
#include "game/shader/shader_src/shader_bright_scale_frag.h"
const GLchar *shader_bright_scale_vert =
#include "game/shader/shader_src/shader_bright_scale_vert.h"

const GLchar *shader_bright_scale_white_frag =
#include "game/shader/shader_src/shader_bright_scale_white_frag.h"
const GLchar *shader_bright_scale_white_vert =
#include "game/shader/shader_src/shader_bright_scale_white_vert.h"

const GLchar *shader_change_color_time_frag =
#include "game/shader/shader_src/shader_change_color_time_frag.h"
const GLchar *shader_change_color_time_vert =
#include "game/shader/shader_src/shader_change_color_time_vert.h"

const GLchar *shader_target_area_frag = 
#include "game/shader/shader_src/shader_target_area_frag.h"
const GLchar *shader_target_area_vert = 
#include "game/shader/shader_src/shader_target_area_vert.h"

const GLchar *shader_head_mask_frag = 
#include "game/shader/shader_src/shader_head_mask_frag.h"
const GLchar *shader_head_mask_vert =
#include "game/shader/shader_src/shader_head_mask_vert.h"

const GLchar *shader_twinkle_frag = 
#include "game/shader/shader_src/shader_twinkle_frag.h"
const GLchar *shader_twinkle_vert = 
#include "game/shader/shader_src/shader_twinkle_vert.h"

const GLchar *shader_dark_frag = 
#include "game/shader/shader_src/shader_dark_frag.h"
const GLchar *shader_dark_vert = 
#include "game/shader/shader_src/shader_dark_vert.h"

const GLchar *shader_polygon_image_bright_frag = 
#include "game/shader/shader_src/shader_polygon_image_bright_frag.h"
const GLchar *shader_polygon_image_bright_vert = 
#include "game/shader/shader_src/shader_polygon_image_bright_vert.h"

const GLchar *shader_blur_frag = 
#include "game/shader/shader_src/shader_blur_frag.h"
const GLchar *shader_blur_vert = 
#include "game/shader/shader_src/shader_blur_vert.h"

const GLchar *shader_change_add_self_color_frag = 
#include "game/shader/shader_src/shader_change_add_self_color_frag.h"
const GLchar *shader_change_add_self_color_vert = 
#include "game/shader/shader_src/shader_change_add_self_color_vert.h"

const GLchar *shader_change_add_color_frag = 
#include "game/shader/shader_src/shader_change_add_color_frag.h"
const GLchar *shader_change_add_color_vert = 
#include "game/shader/shader_src/shader_change_add_color_vert.h"

const GLchar *shader_change_to_color_frag = 
#include "game/shader/shader_src/shader_change_to_color_frag.h"
const GLchar *shader_change_to_color_vert = 
#include "game/shader/shader_src/shader_change_to_color_vert.h"

const GLchar *shader_grass_frag = 
#include "game/shader/shader_src/shader_grass_frag.h"
const GLchar *shader_grass_vert = 
#include "game/shader/shader_src/shader_grass_vert.h"

const GLchar *shader_grass_reverse_frag = 
#include "game/shader/shader_src/shader_grass_reverse_frag.h"
const GLchar *shader_grass_reverse_vert = 
#include "game/shader/shader_src/shader_grass_reverse_vert.h"

const GLchar *shader_polishing_vert = 
#include "game/shader/shader_src/shader_polishing_vert.h"
const GLchar *shader_polishing_frag = 
#include "game/shader/shader_src/shader_polishing_frag.h"

const GLchar *shader_polishing_rotate_frag = 
#include "game/shader/shader_src/shader_polishing_rotate_frag.h"

const GLchar *shader_frozen_frag =
#include "game/shader/shader_src/shader_frozen_frag.h"
const GLchar *shader_frozen_vert =
#include "game/shader/shader_src/shader_frozen_vert.h"

const GLchar *shader_bright_forever_frag =
#include "game/shader/shader_src/shader_bright_forever_frag.h"
const GLchar *shader_bright_forever_vert =
#include "game/shader/shader_src/shader_bright_scale_vert.h"

static ShaderManager *s_SharedShaderManager = NULL;

ShaderManager* ShaderManager::GetInstance(void)
{
  if (!s_SharedShaderManager)
  {
    s_SharedShaderManager = new ShaderManager();
    s_SharedShaderManager->Init();
    s_SharedShaderManager->LoadAllShader();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&s_SharedShaderManager);
}
  
  return s_SharedShaderManager;
}

void ShaderManager::purgeShaderManager(void)
{
  if(s_SharedShaderManager)
    delete s_SharedShaderManager;
}

ShaderManager::ShaderManager()
{
  
}

ShaderManager::~ShaderManager()
{
}

bool ShaderManager::Init(void)
{
    SShaderInfo[kShaderGray].name = "shader_gray";
    SShaderInfo[kShaderGray].vertexStr = shader_gray_scale_vert;
    SShaderInfo[kShaderGray].fragStr = shader_gray_scale_frag;

    SShaderInfo[kShaderBrightScale].name = "shader_bright_scale";
    SShaderInfo[kShaderBrightScale].vertexStr = shader_bright_scale_vert;
    SShaderInfo[kShaderBrightScale].fragStr = shader_bright_scale_frag;

    SShaderInfo[kShaderBrightScaleWhite].name = "shader_bright_scale_white";
    SShaderInfo[kShaderBrightScaleWhite].vertexStr = shader_bright_scale_white_vert;
    SShaderInfo[kShaderBrightScaleWhite].fragStr = shader_bright_scale_white_frag;
   
    SShaderInfo[kShaderChangeColorTime].name = "shader_change_color_time";
    SShaderInfo[kShaderChangeColorTime].vertexStr = shader_change_color_time_vert;
    SShaderInfo[kShaderChangeColorTime].fragStr = shader_change_color_time_frag;

    SShaderInfo[kShaderTargetArea].name = "shader_target_area";
    SShaderInfo[kShaderTargetArea].vertexStr = shader_target_area_vert;
    SShaderInfo[kShaderTargetArea].fragStr = shader_target_area_frag;

    SShaderInfo[kShaderHeadMask].name = "shader_head_mask";
    SShaderInfo[kShaderHeadMask].vertexStr = shader_head_mask_vert;
    SShaderInfo[kShaderHeadMask].fragStr = shader_head_mask_frag;

    SShaderInfo[kShaderTwinkle].name = "shader_twinkle";
    SShaderInfo[kShaderTwinkle].vertexStr = shader_twinkle_vert;
    SShaderInfo[kShaderTwinkle].fragStr = shader_twinkle_frag;

    SShaderInfo[kShaderDark].name = "shader_dark";
    SShaderInfo[kShaderDark].vertexStr = shader_dark_vert;
    SShaderInfo[kShaderDark].fragStr = shader_dark_frag;

    SShaderInfo[kShaderPolygonImageBright].name = "shader_polygon_image_bright";
    SShaderInfo[kShaderPolygonImageBright].vertexStr = shader_polygon_image_bright_vert;
    SShaderInfo[kShaderPolygonImageBright].fragStr = shader_polygon_image_bright_frag;

    SShaderInfo[kShaderBlur].name = "shader_blur";
    SShaderInfo[kShaderBlur].vertexStr = shader_blur_vert;
    SShaderInfo[kShaderBlur].fragStr = shader_blur_frag;

    SShaderInfo[kShaderChangeAddSelfColor].name = "shader_change_add_self_color";
    SShaderInfo[kShaderChangeAddSelfColor].vertexStr = shader_change_add_self_color_vert;
    SShaderInfo[kShaderChangeAddSelfColor].fragStr = shader_change_add_self_color_frag;

    SShaderInfo[kShaderChangeAddColor].name = "shader_change_add_color";
    SShaderInfo[kShaderChangeAddColor].vertexStr = shader_change_add_color_vert;
    SShaderInfo[kShaderChangeAddColor].fragStr = shader_change_add_color_frag;

    SShaderInfo[kShaderChangeToColor].name = "shader_change_to_color";
    SShaderInfo[kShaderChangeToColor].vertexStr = shader_change_to_color_vert;
    SShaderInfo[kShaderChangeToColor].fragStr = shader_change_to_color_frag;

    SShaderInfo[kShaderGrass].name = "shader_grass";
    SShaderInfo[kShaderGrass].vertexStr = shader_grass_vert;
    SShaderInfo[kShaderGrass].fragStr = shader_grass_frag;

    SShaderInfo[kShaderGrassReverse].name = "shader_grass_reverse";
    SShaderInfo[kShaderGrassReverse].vertexStr = shader_grass_reverse_vert;
    SShaderInfo[kShaderGrassReverse].fragStr = shader_grass_reverse_frag;

    SShaderInfo[kShaderPolishing].name = "shader_polishing";
    SShaderInfo[kShaderPolishing].vertexStr = shader_polishing_vert;
    SShaderInfo[kShaderPolishing].fragStr = shader_polishing_frag;

    SShaderInfo[kShaderPolishingRotate].name = "shader_polishing_rotate";
    SShaderInfo[kShaderPolishingRotate].vertexStr = shader_polishing_vert;
    SShaderInfo[kShaderPolishingRotate].fragStr = shader_polishing_rotate_frag;
    
	SShaderInfo[kShaderFrozen].name = "shader_frozen";
	SShaderInfo[kShaderFrozen].vertexStr = shader_frozen_vert;
	SShaderInfo[kShaderFrozen].fragStr = shader_frozen_frag;

  SShaderInfo[kShaderBrighterForever].name = "shader_bright_forever";
  SShaderInfo[kShaderBrighterForever].vertexStr = shader_bright_forever_vert;
  SShaderInfo[kShaderBrighterForever].fragStr = shader_bright_forever_frag;
	
	return true;
}

void ShaderManager::ReloadAllShaders()
{
  for(int i = 0; i < kShaderCount; ++i)
  {
    //CCShaderCache::sharedShaderCache()->removeProgram(SShaderInfo[eShaderType(i)].name);
    CCGLProgram *program = CCShaderCache::sharedShaderCache()->programForKey(SShaderInfo[eShaderType(i)].name);
    //CCGLProgram *program = CompileShader(eShaderType(i));
    if(program != NULL)
    {
      program->reset();
      RecompileShader(program, eShaderType(i));
    }
  }
  CHECK_GL_ERROR_DEBUG();
}

void ShaderManager::LoadAllShader()
{
  for(int i = 0; i < kShaderCount; ++i)
  {
    CCGLProgram *program = CompileShader(eShaderType(i));
    if(program != NULL)
    {
      CCShaderCache::sharedShaderCache()->addProgram(program, 
        SShaderInfo[eShaderType(i)].name);
    }
  }
}

void ShaderManager::RecompileShader(CCGLProgram* program, const eShaderType shader_type)
{
  program->initWithVertexShaderByteArray(SShaderInfo[shader_type].vertexStr,
    SShaderInfo[shader_type].fragStr);
  program->addAttribute(kCCAttributeNamePosition, kCCVertexAttrib_Position);
  program->addAttribute(kCCAttributeNameColor, kCCVertexAttrib_Color);
  program->addAttribute(kCCAttributeNameTexCoord, kCCVertexAttrib_TexCoords);
  program->link();
  program->updateUniforms();
}

CCGLProgram* ShaderManager::CompileShader( const eShaderType shader_type )
{
  CCGLProgram *program = NULL;
  switch (shader_type)
  {
  case kShaderChangeColorTime:
  	program = new ProgramChangeColor();
    break;
  case kShaderChangeAddSelfColor:
    program = new ProgramChangeAddSelfColor();
    break;
  case kShaderChangeAddColor:
    program = new ProgramChangeAddColor();
    break;
  case kShaderChangeToColor:
    program = new ProgramChangeToColor();
    break;
  default:
    program = new CCGLProgram();
    break;
  }

  program->initWithVertexShaderByteArray(SShaderInfo[shader_type].vertexStr,
    SShaderInfo[shader_type].fragStr);
  program->addAttribute(kCCAttributeNamePosition, kCCVertexAttrib_Position);
  program->addAttribute(kCCAttributeNameColor, kCCVertexAttrib_Color);
  program->addAttribute(kCCAttributeNameTexCoord, kCCVertexAttrib_TexCoords);
  program->link();
  program->updateUniforms();
  program->autorelease();

  return program;
}

CCGLProgram* ShaderManager::GetShaderWithType(const eShaderType shader_type)
{
  CCGLProgram *program = NULL;
  if(shader_type >= 0 && shader_type < kShaderCount)
  {
    program = CCShaderCache::sharedShaderCache()->programForKey\
      (SShaderInfo[shader_type].name);
  }
  else if(shader_type == kShaderDefault)
  {
    program = CCShaderCache::sharedShaderCache()->programForKey\
      (kCCShader_PositionTextureColor);
  }
  return program;
}

} //namespace shader
} //namespace taomee
