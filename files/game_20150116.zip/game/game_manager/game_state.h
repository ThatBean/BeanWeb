//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: game_state.h
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#ifndef GAME_STATE_H_
#define GAME_STATE_H_

#include "engine/base/state_machine/state.h"

#include "engine/base/basictypes.h"

namespace taomee
{

class GameManager;
class TransitionScene;

// game state load resource
class GameStateLoadResource : public State<GameManager>
{
public:
  virtual ~GameStateLoadResource();

  static GameStateLoadResource* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

private:
  GameStateLoadResource();
  DISALLOW_COPY_AND_ASSIGN(GameStateLoadResource);
};

//
class GameStateRestartMap : public State<GameManager>
{
public:
  virtual ~GameStateRestartMap();

  static GameStateRestartMap* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();
private:
  GameStateRestartMap();
  DISALLOW_COPY_AND_ASSIGN(GameStateRestartMap);
};

// game state map
class GameStateMap : public State<GameManager>
{
public:
  virtual ~GameStateMap();

  static GameStateMap* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();

public:
  void set_come_back(bool come_back) { come_back_ = come_back; }

private:
  GameStateMap();
  DISALLOW_COPY_AND_ASSIGN(GameStateMap);

private:
  bool come_back_;
};

// game state battle
class GameStateBattle : public State<GameManager>
{
public:
  virtual ~GameStateBattle();

  static GameStateBattle* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();

private:
  GameStateBattle();
  DISALLOW_COPY_AND_ASSIGN(GameStateBattle);
};

// game state pvp battle
class GameStatePvpBattle : public State<GameManager>
{
public:
  virtual ~GameStatePvpBattle();

  static GameStatePvpBattle* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();

private:
  GameStatePvpBattle();
  DISALLOW_COPY_AND_ASSIGN(GameStatePvpBattle);
};

// game state pvp battle
class GameStateBattleSandBox : public State<GameManager>
{
public:
  virtual ~GameStateBattleSandBox();

  static GameStateBattleSandBox* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();

private:
  GameStateBattleSandBox();
  DISALLOW_COPY_AND_ASSIGN(GameStateBattleSandBox);
};

class GameFriendState : public State<GameManager>
{
public:
  virtual ~GameFriendState();

  static GameFriendState* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();

private:
  GameFriendState();
  DISALLOW_COPY_AND_ASSIGN(GameFriendState);
};

//////////////////////////////////////////////////////////////////////////

class GameArenaState : public State<GameManager>
{
public:
  virtual ~GameArenaState();
  static GameArenaState* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

  virtual std::string GetName();
private:
  GameArenaState();
  DISALLOW_COPY_AND_ASSIGN(GameArenaState);
};

// game state transition
class GameStateTransition : public State<GameManager>
{
public:
  virtual ~GameStateTransition();

  static GameStateTransition* Instance();

  virtual void Enter(GameManager* game_manager);
  virtual void UpdateEachFrame(GameManager* game_manager, float delta);
  virtual void Exit(GameManager* game_manager);

public:
  void set_next_state(State<GameManager>* next_state) { next_state_ = next_state; }

private:
  GameStateTransition();
  DISALLOW_COPY_AND_ASSIGN(GameStateTransition);

private:
  State<GameManager>* next_state_;

  TransitionScene* transition_scene_;  
};

} /* namespace taomee */
#endif /* GAME_STATE_H_ */
