//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: data_sync_module.cpp
//        Author: leohou
//       Version:
//          Date: Nov 11, 2013
//          Time: 3:53:17 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     3:53:17 AM
//
//////////////////////////////////////////////////////////////

#include "game/game_manager/data_sync_module.h"

#include "game/account/account_manager.h"
#include "game/game_manager/game_manager.h"
#include "game/user_data/character_info.h"
#include "game/user_data/user_info.h"
#include "game/game_manager/data_manager.h"
#include "engine/base/game_time.h"
#include "game/battle/battle_data.h"
#include "game/battle/battle_controller.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/user_data/mail_info.h"
#include "engine/base/utils_string.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/scene/loading_sence/login_controller.h"
#include "network/net_manager.h"
#include "network/proto/user_info_out.h"
#include "network/proto/get_daily_task_cfg_in.h"
#include "network/proto/get_daily_task_cfg_out.h"
#include "network/proto/choose_role_in.h"
#include "game/user_data/user_data_constants.h"
#include "game/data_table/data_constant.h"
#include "engine/platform/DataStatisticalManager.h"
#include "game/user_data/user_data_constants.h"

using namespace cocos2d;


namespace taomee {

std::string DataSyncModule::backup_nick_name_ = "";

DataSyncModule::DataSyncModule()
: local_user_data_(NULL),
  server_user_data_(NULL)
{

}

DataSyncModule::~DataSyncModule()
{
  local_user_data_ = NULL;
  SAFE_DEL(server_user_data_);
}

void DataSyncModule::doLoop()
{
	FetchState fetch_state = next_fetch_state_;

	switch (fetch_state)
	{
	case kFetchUserInfoOutState:
		{
			next_fetch_state_ = kFetchFriendInfoOutState;
			this->fetchServerUserData();
			break;
		}
	case kFetchFriendInfoOutState:
		{
			next_fetch_state_ = kFetchComplete;
		  this->fetchFriendInfo();
			break;
		}
	case kFetchComplete:
		{	
			next_fetch_state_ = kUnkownState;
			fetchUserDataComplete();
			break;
		}
	default:
		break;
	}
}

void DataSyncModule::UpdateUserDataFromServer()
{
  next_fetch_state_ = kFetchUserInfoOutState;
	doLoop();
}

void DataSyncModule::fetchServerUserData()
{
  boost::shared_ptr<UserInfoSession> user_info_session = boost::make_shared<UserInfoSession>();
  user_info_session->SubscribeReciveBodyComplete(this, &DataSyncModule::onFetchServerUserDataCompleted);

  net::User_info_in user_info_in;
  user_info_in.set_cmd(GetHttpActionIDByName("user_getUserData"));
  user_info_in.set_session(account::AccountManager::GetInstance().session());

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  user_info_in.set_userid(os.str());

  user_info_session->set_message_in(user_info_in);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(user_info_session);
}

void DataSyncModule::onFetchServerUserDataCompleted(int error_code,
                                                    boost::shared_ptr<UserInfoSession> user_info_session)
{
  server_user_data_ = new net::User_info_out();
  *server_user_data_ = user_info_session->get_message_out();

  this->updateLocalUserInfo();
  //this->updateFragmentData();
  this->updateCardData();
  this->updateEquipData();
  this->updateMissionData();
  this->updateMailData();
  this->updateSpecialCardData();  
  this->updateSkillData();

  const net::Info& server_user_info = server_user_data_->get_info();
  //LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/newbie_guide_manager.lua", "setCurrentNewbieStepFromServer",server_user_info.get_newbie_guide_step());
  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/framework/CPlusToLuaInterface.lua", "setCurrentNewbieStepFromServer",server_user_info.get_newbie_guide_step());

  SAFE_DEL(server_user_data_);
  //��ʱ�����ź���
  FriendController::GetInstance().SendGetFriendListRequest();
  FriendController::GetInstance().SendGetRequestListRequest(); 
	doLoop(); 
}

void DataSyncModule::fetchFriendInfo()
{
	doLoop();
}

void DataSyncModule::fetchUserDataComplete()
{
	GameManager::GetInstance().OnGetUserDataCompleted();
}


void DataSyncModule::updateLocalUserInfo()
{
  const net::Info& server_user_info = server_user_data_->get_info();
  // set basic user info
  taomee::account::AccountManager::GetInstance().setUserIDFromServer(server_user_info.get_userid());
  local_user_data_->set_user_id(atoi(server_user_info.get_userid().c_str()));
  local_user_data_->set_role_id(server_user_info.get_role());
  local_user_data_->set_current_city_map_id(server_user_info.get_last_scene_id());
  local_user_data_->set_nick_name(server_user_info.get_nick());
  local_user_data_->set_ap(server_user_info.get_ap());
  local_user_data_->set_xp(server_user_info.get_xp());
  local_user_data_->set_ap_recover_time_period(server_user_info.get_ap_period());
  local_user_data_->set_ap_recover_time_delta(server_user_info.get_ap_recover_time_delta());
  local_user_data_->set_rank(server_user_info.get_level());
  local_user_data_->set_max_card_count(server_user_info.get_max_cards());
  local_user_data_->set_cumulative_bought_gems(server_user_info.get_consume_gems());
  local_user_data_->set_charge(server_user_info.get_charge_num());
  //local_user_data_->set_up_star(server_user_info.get_rarity_step());
  //local_user_data_->set_max_equip_count(server_user_info.get_equip_pack_cap());
  local_user_data_->set_charge_hint_delta(server_user_info.get_charge_hint_delta());
  local_user_data_->set_challengeReward_list(server_user_data_->get_challenge_reward());
  local_user_data_->set_timestamp_dif(server_user_info.get_stamp());
  local_user_data_->set_last_checkin_stamp(server_user_info.get_last_checkin_stamp());
  local_user_data_->set_checkin_days(server_user_info.get_checkin_days());
  local_user_data_->set_online_gift_time(taomee::getServerTime());
  local_user_data_->set_online_gift_count(server_user_info.get_ol_bonus_cnt());
  local_user_data_->set_is_arena_opened(server_user_info.get_arena_is_open()?true:false);
  local_user_data_->set_is_get_first_charge(server_user_info.get_charge1st_bonus_is_get()?true:false);
  local_user_data_->set_offline_exp(server_user_data_->get_offline_exp());
  local_user_data_->setRegisterStamp(server_user_info.get_register_stamp());
  local_user_data_->setSkillPoint(server_user_info.get_skill_point().get_point());
  local_user_data_->setSkillpointPeriod(server_user_info.get_skill_point().get_period());
  local_user_data_->setSkillPointRecoverTimeDelta(server_user_info.get_skill_point().get_recover_time_delta());


  // set all items in user data
  for (std::vector<std::vector<int> >::const_iterator it = server_user_data_->get_items().begin();
    it != server_user_data_->get_items().end(); ++it)
  {
    uint_8 item_type = BaseResDataTable::GetInstance()->GetResDataById((*it)[0])->getType();
    if (item_type == kNormalItemType)
    {
      local_user_data_->SetItemCountWithType((*it)[0], (*it)[1]);
    }
    else if (item_type == kEquipmentType)
    {
      local_user_data_->SetEquipCountByID((*it)[0], (*it)[1]);
    }
    else if (item_type == kFragmentType)
    {
      local_user_data_->AddFragmentToList((*it)[0], (*it)[1]);
    }
  }

  for (std::vector<std::vector<int> >::const_iterator it = server_user_data_->get_charge_history().begin();
	  it != server_user_data_->get_charge_history().end(); ++it)
  {
	  local_user_data_->set_chargeList((*it)[0], (*it)[1]);
  }

  // vip cfg
  const std::vector<int>& vip_cfg = server_user_info.get_vip_charge_cfg();
  int_8 idx = 0;
  for (std::vector<int>::const_iterator it = vip_cfg.begin();
    it != vip_cfg.end(); ++it)
  {
    DataManager::GetInstance().GetVipDataTable()->AddVipData(idx++, (*it));
  }

  local_user_data_->set_vip(DataManager::GetInstance().GetVipDataTable()->GetVipByCharge(server_user_info.get_charge_num()));
}

void DataSyncModule::updateSpecialCardData()
{
   FriendController::GetInstance().InitAssistCard(-1);
	 const std::vector<std::vector<int > >& special_cards = server_user_data_->get_special_cards();
   std::vector<std::vector<int> >::const_iterator it = special_cards.begin();
   for (; it != special_cards.end(); ++it)
   {
      const std::vector<int>& value = *it;
      int card_sid = value.at(0);
      //int card_id = value.at(1);
      int flag = value.at(1);
      
      if ((flag & taomee::data::kRoleCard) != 0)
      {
      }
      if ((flag & taomee::data::kAssistCard) != 0)
      {
        FriendController::GetInstance().InitAssistCard(card_sid);
      }
  }
  FriendController::GetInstance().CheckAssistCardValid();

}

void DataSyncModule::updateCardData()
{
  const std::vector<net::Cards>& server_card_data = server_user_data_->get_cards();

  std::list<data::CharacterInfo*> card_list;
  //assert(server_card_data.size());
  for (std::vector<net::Cards>::const_iterator card_iter = server_card_data.begin();
      card_iter != server_card_data.end(); ++card_iter)
  {
    BaseResData* baseData = BaseResDataTable::GetInstance()->GetResDataById(card_iter->get_cardid());
    // assist card info
    if ( baseData->getType() != kCharacterType)
    {
      assert(0);
    }
    else // character card id
    {
      // set card basic info
      data::CharacterInfo* current_card_item = new data::CharacterInfo
                                  (card_iter->get_id(),card_iter->get_cardid());
      current_card_item->set_xp(card_iter->get_xp());      
      current_card_item->set_level(card_iter->get_level());
       current_card_item->set_up_star(card_iter->get_uprarity_step());
      current_card_item->setEvolveStep(card_iter->get_evolve_step());
      current_card_item->setBreakExp(card_iter->get_break_xp());
      current_card_item->set_break_times(card_iter->get_break_lv());     
      
      card_list.push_back(current_card_item);
    }
  }

  local_user_data_->InitCharacterCardDataInUserInfo(card_list);
  
  // delloc
  for (std::list<data::CharacterInfo*>::iterator it = card_list.begin();
       it != card_list.end(); ++it)
  {
    delete (*it);
  }
  card_list.clear();
  // set have got card list 
  //local_user_data_->set_have_got_character_card_id_list(server_user_data_->get_character());
  // set team info
  const std::vector<net::Teams> teams = server_user_data_->get_teams();
  for (std::vector<net::Teams>::const_iterator it = teams.begin();
       it != teams.end(); ++it)
  {
    uint_32 tempIds[data::kMaxCharacterCountInOneTeam] = { data::kUnexistCharacterId };
    int idx = it->get_seq();

    tempIds[0] = it->get_role0();
    tempIds[1] = it->get_role1();
    tempIds[2] = it->get_role2();
    tempIds[3] = it->get_role3();
    tempIds[4] = it->get_role4();
    //tempIds[5] = it->get_role5();

    local_user_data_->set_teams_ids(idx, tempIds);
  }
  local_user_data_->set_default_team_index(data::kDefaultTeamIndex);
}

void DataSyncModule::updateEquipData()
{
  const std::vector<net::Equip>& server_equip_data = server_user_data_->get_equip();

  std::vector<net::Equip>::const_iterator it = server_equip_data.begin();
  for ( ; it != server_equip_data.end(); ++it )
  {
    data::CharacterInfo* card_info = local_user_data_->GetCharacterCardBySequenceId(it->get_card_sid());
    if (card_info)
    {
      data::CharacterEquipInfo* equipInfo = card_info->getEquipmentInfoByIndex(it->get_seq());
      equipInfo->setCardSID(it->get_card_sid());
      equipInfo->setSID(it->get_id());
    }
    else
    {
      assert(false);
    }
  }
}


void DataSyncModule::updateSkillData()
{
	const std::vector<net::Skill>& server_skill_data = server_user_data_->get_skill();
	local_user_data_->skills().clear();
	std::list<data::SkillInfo*> skill_list;
	std::vector<net::Skill>::const_iterator it = server_skill_data.begin();
	for( ;it !=server_skill_data.end();++it)
	{
		data::SkillInfo* sData = new data::SkillInfo(it->get_skill_id(),it->get_card_sid(),it->get_level());

		skill_list.push_back(sData);
		int id= it->get_skill_id();
		int sid = it->get_card_sid();
		int lv =it->get_level();
	}
	local_user_data_->InitSkillListInUserInfo(skill_list);


	for (std::list<data::SkillInfo*>::iterator it = skill_list.begin(); it != skill_list.end(); ++it)
	{
		delete(*it);
	}
	skill_list.clear();
}


void DataSyncModule::updateMissionData()
{
	for(std::vector<int >::const_iterator it = server_user_data_->get_taskEx().begin();
			it != server_user_data_->get_taskEx().end(); ++it)
	{
		local_user_data_->initMissionComplete(*it);
	}

  const std::vector<std::vector<int > >& chpList = server_user_data_->get_chp_win();

  int_32 listSize = chpList.size(); 

  for (int_32 idx = 0; idx < listSize; ++idx)
  {
    int_32 chp_id = chpList.at(idx).at(0);
    int_32 chp_count = chpList.at(idx).at(1);
    int_32 chp_reset_count = chpList.at(idx).at(2);
    local_user_data_->initCheckPointPassSuccess(chp_id, chp_count, chp_reset_count);
  }

  for(std::vector<int >::const_iterator it = server_user_data_->get_chpbox_get().begin();
    it != server_user_data_->get_chpbox_get().end(); ++it)
  {
    local_user_data_->AddMainMissionBoxComplete(*it);
  }
}

void DataSyncModule::updateFragmentData()
{
  const std::vector<std::vector<int > >& fragments = server_user_data_->get_fragment();

  local_user_data_->fragments().clear();
  std::list<data::FragmentInfo*> fragment_list;

  int_32 listSize = fragments.size(); 
  for (int_32 idx = 0; idx < listSize; ++idx)
  {
    int_32 fragment_id = fragments.at(idx).at(0);
    int_32 fragment_count = fragments.at(idx).at(1);
    data::FragmentInfo* eData = new data::FragmentInfo(fragment_id, fragment_count);
    fragment_list.push_back(eData);
  }

  local_user_data_->InitFragmentDataInUserInfo(fragment_list);

  for (std::list<data::FragmentInfo*>::iterator it = fragment_list.begin();
    it != fragment_list.end(); ++it)
  {
    delete (*it);
  }
  fragment_list.clear();
}

void DataSyncModule::updateMailData()
{
  const std::vector<net::Mail_list>& mailList = server_user_data_->get_mail_list();
  int_32 listSize = mailList.size();
  std::list<data::MailChiefInfo*>& mailChiefList = local_user_data_->getMailList();
  for (int_32 idx = 0; idx < listSize; ++idx)
  {
    int_32 emailTime = mailList.at(idx).get_info().at(0);
    int_32 sendTime = mailList.at(idx).get_info().at(1);
    int_32 isRead = mailList.at(idx).get_info().at(2);
    int_32 isAttach = mailList.at(idx).get_info().at(3);
    
	data::MailChiefInfo* m_info = new data::MailChiefInfo(emailTime, sendTime, isRead, isAttach, mailList.at(idx).get_title() );
	mailChiefList.push_back(m_info);
  }

  /*const std::vector<net::Sys_mails>& sysMailList = server_user_data_->get_sys_mails();
  listSize = sysMailList.size();
  std::list<data::MailInfo*>& sys_mails = local_user_data_->sys_mails();
  for (int_32 idx = 0; idx < listSize; ++idx)
  {
  int_32 sid = sysMailList.at(idx).get_info().at(0);
  int_32 rid = sysMailList.at(idx).get_info().at(1);
  int_32 num = sysMailList.at(idx).get_info().at(2);
  int_32 desc_id = sysMailList.at(idx).get_info().at(3);

  data::MailInfo* m_info = new data::MailInfo(sid, data::kMailTypeNone, rid, num, desc_id, sysMailList.at(idx).get_desc() );
  sys_mails.push_back(m_info);
  }*/
}

void DataSyncModule::CommitBonusMission(int mission_id)
{
  boost::shared_ptr<BonusMissionSession> bonus_mission_session = boost::make_shared<BonusMissionSession>();
  bonus_mission_session->SubscribeReciveBodyComplete(this, &DataSyncModule::onCommitBonusMissionCompleted);

  BonusMissionIn bonus_mission_in;
  bonus_mission_in.set_action("battle_bonusBattle");
  bonus_mission_in.set_session(account::AccountManager::GetInstance().session());

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  bonus_mission_in.set_userid(os.str());

  bonus_mission_in.set_taskid(mission_id);

  bonus_mission_session->set_message_in(bonus_mission_in);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(bonus_mission_session);
}

void DataSyncModule::onCommitBonusMissionCompleted(int error_code,
                                                   boost::shared_ptr<BonusMissionSession> bonus_mission_session)
{
  battle::BattleController::GetInstance().battle_data()->ClearGainCardsMap();
  const std::vector<net::bouns_battle_ready_out::Cards>& cards = bonus_mission_session->get_message_out().get_cards();
  for (std::vector<net::bouns_battle_ready_out::Cards>::const_iterator it = cards.begin();
       it != cards.end(); ++it)
  {
    battle::BattleController::GetInstance().battle_data()->AddOneGainCardMap(it->get_id(), it->get_cardid());
    DataManager::GetInstance().user_info()->InsertOneNewCardWithSequenceIdAndCardId(it->get_id(), it->get_cardid());
  }
}

void DataSyncModule::CommitTeamInfo(int team_index)
{
  assert(team_index >= data::kDefaultTeamIndex && team_index < data::kMaxTeamsCount);
  boost::shared_ptr<TeamInfoSession> team_info_session = boost::make_shared<TeamInfoSession>();
  team_info_session->SubscribeReciveBodyComplete(this, &DataSyncModule::onCommitTeamInfoCompleted);

  TeamInfoIn team_info_in;
  team_info_in.set_cmd(GetHttpActionIDByName("card_saveTeamInfo"));
  team_info_in.set_session(account::AccountManager::GetInstance().session());

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  team_info_in.set_userid(os.str());
  
  std::vector<net::card_save_team_info_in::Teams> teams_info_vec;
  net::card_save_team_info_in::Teams teams_info;
  std::vector< std::vector<int> > team_member;
  
  for (int index = 0; index < data::kMaxCharacterCountInOneTeam; index++)
  {
      uint_32 seq_id = local_user_data_->GetTeamCharacterIDByIndex(team_index, index);
      if(seq_id == 0)
          continue;

      std::vector< int > cards;
      cards.push_back(index);
      cards.push_back(seq_id);
      team_member.push_back(cards);
  }
  teams_info.set_seq(team_index);
  teams_info.set_team(team_member);
  teams_info_vec.push_back(teams_info);
  team_info_in.set_teams(teams_info_vec);
  team_info_session->set_message_in(team_info_in);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(team_info_session);
}

void DataSyncModule::onCommitTeamInfoCompleted(int error_code,
                                               boost::shared_ptr<TeamInfoSession> team_info_session)
{
  //LuaTinkerManager::GetInstance()\
  //  .CallLuaFunc<int>("script/ui/ui_team.lua", "TeamChangeResult", error_code); 
  //return;
}

void DataSyncModule::CommitUserEventNotify(int key)
{
  boost::shared_ptr<UserEventNotifySession> user_event_notify_session = boost::make_shared<UserEventNotifySession>();
  user_event_notify_session->SubscribeReciveBodyComplete(this, &DataSyncModule::onCommitUserEventNotifyCompleted);

  UserEventNotifyIn user_event_notify_in;
  user_event_notify_in.set_cmd(GetHttpActionIDByName("user_evenNotify"));
  user_event_notify_in.set_session(account::AccountManager::GetInstance().session());
  user_event_notify_in.set_key(key);

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  user_event_notify_in.set_userid(os.str());

  user_event_notify_session->set_message_in(user_event_notify_in);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(user_event_notify_session);
}

void DataSyncModule::onCommitUserEventNotifyCompleted(int error_code,
  boost::shared_ptr<UserEventNotifySession> user_event_notify_session)
{
	int key = user_event_notify_session->get_message_in().get_key();

	if(key == data::kItemCostEKReviveWithReviveGem)
	{
		int _count = DataManager::GetInstance().user_info()->GetItemCountByType(key) - 1;
		DataManager::GetInstance().user_info()->SetItemCountWithType(key, _count);
	}
	if (key == data::kItemCostEKReviveWithGem)
	{
		int gemcount =  DataManager::GetInstance().user_info()->CurrentReviveGem();
		int _count = DataManager::GetInstance().user_info()->GetItemCountByType(data::kItemTypeGem) - gemcount;
	    DataManager::GetInstance().user_info()->SetItemCountWithType(data::kItemTypeGem, _count);
	}
//   LuaTinkerManager::GetInstance()\
//     .CallLuaFunc<int>("script/ui/ui_item_list.lua", "UserItemResult", user_event_notify_session->get_message_in().get_key(),error_code);

  return;
}

bool DataSyncModule::CommitCreateName(int role_id, const std::string& name )
{
  int name_len = GetUtf8StrLenDiffEnAndCn(name.c_str());
  if( name_len > 12 )
    return false;

  boost::shared_ptr<SetNickSession> set_nick_session = boost::make_shared<SetNickSession>();
  set_nick_session->SubscribeReciveBodyComplete(this, &DataSyncModule::onCommitCreateNameCompleted);

  string unicode_name = ConvertUft8ToUnicodeString(name);

  SetNickIn set_nick_in_data;
  set_nick_in_data.set_cmd(GetHttpActionIDByName("user_setNick"));
  set_nick_in_data.set_session(account::AccountManager::GetInstance().session());

  std::ostringstream os;
  os << account::AccountManager::GetInstance().user_id();
  set_nick_in_data.set_userid(os.str());
  set_nick_in_data.set_nick(unicode_name);
  set_nick_in_data.set_role(role_id);
  set_nick_session->set_message_in(set_nick_in_data);

  net::NetManager& http_client = net::NetManager::GetInstance();
  http_client.SendSession(set_nick_session);
  return true;
}

void DataSyncModule::onCommitCreateNameCompleted( int error_code, boost::shared_ptr<SetNickSession> set_nick_session )
{
  if (error_code == 0)
  {
    GameManager::GetInstance().OnCreateRoleCompleted();
  }
  else
  {
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/CreateRoleUI.lua", "GlobalConfirmNameFailedRedirector", error_code);
  }
}





} /* namespace taomee */
