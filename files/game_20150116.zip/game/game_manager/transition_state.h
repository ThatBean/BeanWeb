//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: transition_state.h
//        Author: leohou
//       Version:
//          Date: Nov 27, 2013
//          Time: 4:59:19 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     4:59:19 AM
//
//////////////////////////////////////////////////////////////

#ifndef TRANSITION_STATE_H_
#define TRANSITION_STATE_H_

#include "engine/base/state_machine/state.h"

#include "engine/base/basictypes.h"

namespace taomee {

class TransitionScene;

// purge cached data
class TransitionStatePurgeCache : public State<TransitionScene>
{
public:
  virtual ~TransitionStatePurgeCache();

  static TransitionStatePurgeCache* Instance();

  virtual void Enter(TransitionScene* transition_scene);
  virtual void UpdateEachFrame(TransitionScene* transition_scene, float delta);
  virtual void Exit(TransitionScene* transition_scene);

private:
  TransitionStatePurgeCache();
  DISALLOW_COPY_AND_ASSIGN(TransitionStatePurgeCache);
};


// get resource list
class TransitionStateGetResource : public State<TransitionScene>
{
public:
  virtual ~TransitionStateGetResource();

  static TransitionStateGetResource* Instance();

  virtual void Enter(TransitionScene* transition_scene);
  virtual void UpdateEachFrame(TransitionScene* transition_scene, float delta);
  virtual void Exit(TransitionScene* transition_scene);

private:
  TransitionStateGetResource();
  DISALLOW_COPY_AND_ASSIGN(TransitionStateGetResource);
};


// load resource
class TransitionStateLoadResource : public State<TransitionScene>
{
public:
  virtual ~TransitionStateLoadResource();

  static TransitionStateLoadResource* Instance();

  virtual void Enter(TransitionScene* transition_scene);
  virtual void UpdateEachFrame(TransitionScene* transition_scene, float delta);
  virtual void Exit(TransitionScene* transition_scene);

private:
  TransitionStateLoadResource();
  DISALLOW_COPY_AND_ASSIGN(TransitionStateLoadResource);
};

} /* namespace taomee */
#endif /* TRANSITION_STATE_H_ */
