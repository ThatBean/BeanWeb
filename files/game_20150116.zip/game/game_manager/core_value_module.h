//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: core_value_module.h
//        Author: coldouyang
//          Date: 2014/7/11 15:15
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/11      add
//////////////////////////////////////////////////////////////

#ifndef CORE_VALUE_HELPER_H
#define CORE_VALUE_HELPER_H

class CoreValueModule
{
public:
  
/************************************************************************/
/* ����ͨ�����߹ؿ� ��ɫ����                                             */
/************************************************************************/
  static int GetMainCheckpointUserRewardEXP(int checkpointID, bool isFirst);
  
/************************************************************************/
/* ����ͨ��ʱ���ƻ�ȡ����                                                */
/************************************************************************/
  static int GetMainCheckpointCardRewardXP(int CheckpointMainData);

  static int GetDailyCheckpointUserRewardEXP(int checkpointID, bool isFirst);
  static int GetDailyCheckpointCardRewardXP(int checkpointID);

/************************************************************************/
/* ���㿨�Ƶ�ĳ�ȼ�����ľ���                                             */
/************************************************************************/
  static int GetCardXPRequiredForLevel(int card_id, int level);

/************************************************************************/
/* ����װ��ǿ������
/************************************************************************/
  static int GetEquipStrengthCost(int equip_id, int level);
/************************************************************************/
/* ����װ������
/************************************************************************/
  static int GetEquipmentSell(int equip_id, int level);

/************************************************************************/
/* ���㿨�ƺϳ�ʱ�ṩ�ľ���                                              */
/************************************************************************/
  static int GetCardComposeProvideXP(int card_sid);

/************************************************************************/
/* ���㿨�ƻ�ԭʱ���صĽ��                                             */
/************************************************************************/
  static int GetCardRevertMoney(int card_sid);

/************************************************************************/
/* ���㿨�ƻ�ԭʱ���صĽ��                                             */
/************************************************************************/
  static int GetCardDecomposeMoney(int card_sid);
protected:
private:
};

#endif