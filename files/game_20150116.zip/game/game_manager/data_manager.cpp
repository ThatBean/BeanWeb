//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: data_manager.cpp
//        Author: robbiepan
//          Date: 2013/9/12 15:44
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/12      add
//////////////////////////////////////////////////////////////
#include "data_manager.h"
#include "engine/base/basictypes.h"
#include "engine/base/game_math.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/handle_delegate.h"
#include "game/scene/loading_sence/update_controller.h"
#include "game/game_manager/data_sync_module.h"
#include "game/data_table/checkpointmain_data_table.h"
#include "game/data_table/checkpointdaily_data_table.h"
#include "game/data_table/checkpointcha_data_table.h"
#include "game/data_table/mission_data_table.h"
#include "game/data_table/checkpointbox_data_table.h"
#include "game/data_table//daily_Lv_table.h"
#include "engine/script/lua_tinker_manager.h"
//sachin

USING_NS_CC;

namespace {
template <class TableDataType>
void LoadSingleTable(TableDataType** data_table, std::string table_file_name)
{
  if(*data_table == NULL)
  {
    *data_table = new TableDataType();
    if(!(*data_table)->InitWithFileName(table_file_name.c_str()))
    {
      CCLog(" loadfile failed: %s", table_file_name.c_str());
    }
  }
}
template <class TableDataType>
void RegisterAsyncLoadHandle(TableDataType** data_table, std::string table_file_name)
{
  using namespace  taomee;
  typedef HandleDelegate1<TableDataType**, std::string> HandleDelegateType;
  boost::function<void (TableDataType**, std::string)> handle_function = &LoadSingleTable <TableDataType>;
  boost::shared_ptr<HandleDelegateType> handle_delegate = boost::make_shared<HandleDelegateType>(
    data_table,
    handle_function,  table_file_name);
  UpdateController::GetInstance().RegisterLoadFunctionHandle(handle_delegate);
}
}

int DataManager::mCurrentLanguageType = -1;


DataManager& DataManager::GetInstance()
{
  static DataManager* X = NULL;
  if (!X)
  {
    X = new DataManager();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
  }
  return *X;
}

DataManager::DataManager()
  :ability_data_table_(NULL)
  ,skill_brk_table_(NULL)
  ,skill_table_(NULL)
  ,skill_attack_range_table_(NULL)
  ,character_data_table_(NULL)
  ,projectiles_data_table_(NULL)
  ,drama_data_table_(NULL)
  ,freshman_data_table_(NULL)
  ,rank_data_table_(NULL)
  ,buff_data_table_(NULL)
  ,aura_data_table_(NULL)
  ,grade_reward_data_table_(NULL)
  ,box_list_data_table_(NULL)
  ,item_list_data_table_(NULL)
  ,tavern_data_table_(NULL)
  ,activity_notify_data_table_(NULL)
  ,mail_msg_data_table_(NULL)
  ,server_list_data_table_(NULL)
  ,card_capacity_data_table_(NULL)
  ,role_data_table_(NULL)
  ,checkpoint_main_data_table_(NULL)
  ,checkpoint_daily_data_table_(NULL)
  ,checkpoint_cha_data_table_(NULL)
  ,mission_data_table_(NULL)
  ,pvp_award_data_table_(NULL)
  ,announcement_data_table_(NULL)
  ,pvp_rank_award_data_table_(NULL)
  ,flop_data_table_(NULL)
  ,activity_level_data_table_(NULL)
  ,activity_dayth_data_table_(NULL)
  ,vip_data_table_(NULL)
  ,vipbox_data_table_(NULL)
  ,checkpoint_box_data_table_(NULL)
  ,fragment_data_table(NULL)
  ,equip_data_table_(NULL)
  ,strengthen_cost_data_table(NULL)
  ,elite_data_table(NULL)
  ,language_data_table(NULL)
  ,language_drama_data_table(NULL)
  ,shop_data_table(NULL)
  ,quality_data_table(NULL)
  ,daily_work_table(NULL)
  ,break_out_data_table(NULL)
  ,up_rarity_data_table(NULL)
  ,challenge_data_table(NULL)
  ,dailycheckin_data_table(NULL)
  ,limitGift_data_table(NULL)
  ,monthfragment_data_table(NULL)
  ,babel_data_table(NULL)
  ,secretshop_data_table(NULL)
  ,onlinegift_data_table(NULL)
  ,cdkey_reward_data_table(NULL)
  ,daily_tasks_data_table(NULL)
  ,function_Data_Table(NULL)
  ,email_data_table(NULL)
  ,DailyLevel_Data_Table(NULL)
  ,show_activity_data_table(NULL)
  ,random_box_map_data_table(NULL)
  ,evolve_data_table(NULL)
  ,skillgrowth_data_table(NULL)
{
  user_info_ = new data::UserInfo();
  calculator_ = new BornCalculator(this);
  data_sync_module_ = new DataSyncModule();
  data_sync_module_->set_local_user_data(user_info_);
}

DataManager::~DataManager()
{
  SAFE_DEL(ability_data_table_); 
  SAFE_DEL(skill_brk_table_); 
  SAFE_DEL(skill_table_); 
  SAFE_DEL(skill_attack_range_table_); 
  SAFE_DEL(character_data_table_); 
  SAFE_DEL(projectiles_data_table_); 
  SAFE_DEL(drama_data_table_); 
  SAFE_DEL(freshman_data_table_); 
  SAFE_DEL(rank_data_table_);
  SAFE_DEL(buff_data_table_); 
  SAFE_DEL(aura_data_table_);
  SAFE_DEL(grade_reward_data_table_);
  SAFE_DEL(box_list_data_table_); 
  SAFE_DEL(item_list_data_table_); 
  SAFE_DEL(tavern_data_table_); 
  SAFE_DEL(activity_notify_data_table_); 
  SAFE_DEL(mail_msg_data_table_); 
  SAFE_DEL(server_list_data_table_); 
  SAFE_DEL(card_capacity_data_table_); 
  SAFE_DEL(role_data_table_); 
  SAFE_DEL(checkpoint_main_data_table_); 
  SAFE_DEL(checkpoint_daily_data_table_); 
  SAFE_DEL(checkpoint_cha_data_table_); 
  SAFE_DEL(mission_data_table_); 
  SAFE_DEL(pvp_award_data_table_);
  SAFE_DEL(announcement_data_table_); 
  SAFE_DEL(pvp_rank_award_data_table_); 
  SAFE_DEL(flop_data_table_); 
  SAFE_DEL(activity_level_data_table_); 
  SAFE_DEL(activity_dayth_data_table_); 
  SAFE_DEL(vip_data_table_); 
  SAFE_DEL(vipbox_data_table_); 
  SAFE_DEL(checkpoint_box_data_table_); 
  SAFE_DEL(fragment_data_table); 
  SAFE_DEL(equip_data_table_); 
  SAFE_DEL(strengthen_cost_data_table); 
  SAFE_DEL(elite_data_table); 
  //SAFE_DEL(language_data_table); 
  //SAFE_DEL(language_drama_data_table); 
  SAFE_DEL(shop_data_table); 
  SAFE_DEL(quality_data_table); 
  SAFE_DEL(daily_work_table); 
  SAFE_DEL(break_out_data_table); 
  SAFE_DEL(up_rarity_data_table); 
  SAFE_DEL(challenge_data_table); 
  SAFE_DEL(dailycheckin_data_table); 
  SAFE_DEL(limitGift_data_table); 
  SAFE_DEL(monthfragment_data_table); 
  SAFE_DEL(babel_data_table); 
  SAFE_DEL(secretshop_data_table); 
  SAFE_DEL(onlinegift_data_table); 
  SAFE_DEL(cdkey_reward_data_table); 
  SAFE_DEL(daily_tasks_data_table);
  SAFE_DEL(function_Data_Table);
  SAFE_DEL(email_data_table);
  SAFE_DEL(DailyLevel_Data_Table);
  SAFE_DEL(show_activity_data_table);
  SAFE_DEL(random_box_map_data_table);
  SAFE_DEL(evolve_data_table);
  SAFE_DEL(skillgrowth_data_table);
  SAFE_DEL(user_info_); 
  SAFE_DEL(calculator_); 
  
  SAFE_DEL(data_sync_module_); 
}

void DataManager::Init()
{
  GameMath::Init();
  load();
}

void DataManager::setLanguageType(int type)
{
  if (type != mCurrentLanguageType)
  {
    mCurrentLanguageType = type;
    /*�ݲ�֧��!
    if (language_data_table)
    {
      //1.����  RegisterAsyncLoadHandle<LanguageDataTable>(&language_data_table,"csv_language.csv");
      LanguageDataTable::ResetLanguageDataTable();
      CC_SAFE_DELETE(language_data_table);
      language_data_table = NULL;
      LoadSingleTable<LanguageDataTable>(&language_data_table, "csv_language.csv");
    }
    */
    std::string lan = "cn";
    switch (mCurrentLanguageType)  
    {  
    case kLanguageEnglish:  
      lan = "en";  
      break;  
    case kLanguageChinese:
      lan = "cn";  
      break;  
    case kLanguageFrench:  
      break;  
    case kLanguageGerman:  
      break;
    case kLanguageItalian:  
      break;
    case kLanguageRussian:  
      break;
    case kLanguageSpanish:   
      break;
    case kLanguageKorean:
      lan = "ko";
      break;  
    }
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/language_loader.lua", "SetLanguage", lan.c_str());
    bool isSupport = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/language_loader.lua", "IsLanguageSupport", lan.c_str());
    if (isSupport && mCurrentLanguageType != kLanguageChinese)
    {
      cocos2d::extension::CCSGUIReader::setLanguageSuffix(lan.c_str());
      int count = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/language_font_config.lua", "GetSupportMultiFontCount");
      for (int i = 1; i <= count; ++i)
      {
        const char* name = LuaTinkerManager::GetInstance().CallLuaFunc<const char*>("script/config/language_font_config.lua", "GetSupportMultiFontNameByIndex", i);
        cocos2d::extension::CCSGUIReader::addSupportMultiFontName(name);
      }
    }
  }
}

bool DataManager::ReloadFile()
{
  SAFE_DEL(skill_brk_table_);
  SAFE_DEL(skill_table_);
  SAFE_DEL(skill_attack_range_table_);

  //SAFE_DEL(character_data_table_);
  SAFE_DEL(aura_data_table_);

  if (!loadSkill()) 
  {
    return false; 
  }  

  //   if(character_data_table_ == NULL)
//   {
//     character_data_table_ = new CharacterDataTable();
//     if(!character_data_table_->InitWithFileName("character.csv"))
//     {
//       CCLog(" loadfile failed: character.csv");
//     }
//   }
  return true;
}

bool DataManager::load()
{    
  RegisterAsyncLoadHandle<SkillBrkDataTable>(&skill_brk_table_, "skillbrk.csv");
  RegisterAsyncLoadHandle<SkillDataTable>(&skill_table_, "skill.csv");
  RegisterAsyncLoadHandle<SkillAttackRangeTable>(&skill_attack_range_table_, "skillAttackRange.csv");
  RegisterAsyncLoadHandle<TavernDataTable>(&tavern_data_table_, "tavern.csv");
  RegisterAsyncLoadHandle<CharacterDataTable>(&character_data_table_, "character.csv");
  RegisterAsyncLoadHandle<ProjectilesDataTable>(&projectiles_data_table_, "projectiles.csv");
  RegisterAsyncLoadHandle<DramaDataTable>(&drama_data_table_, "drama.csv");
  RegisterAsyncLoadHandle<FreshmanDataTable>(&freshman_data_table_, "freshman.csv");
  RegisterAsyncLoadHandle<RankDataTable>(&rank_data_table_, "gamelevel.csv");
  RegisterAsyncLoadHandle<AbilityDataTable>(&ability_data_table_, "ability.csv");
  RegisterAsyncLoadHandle<AuraDataTable>(&aura_data_table_, "aura.csv");

  RegisterAsyncLoadHandle<GradeRewardDataDataTable>(&grade_reward_data_table_, "grade_reward.csv");

  RegisterAsyncLoadHandle<BuffDataTable>(&buff_data_table_, "buff.csv");
  RegisterAsyncLoadHandle<BoxlistDataTable>(&box_list_data_table_, "boxlist.csv");
  RegisterAsyncLoadHandle<ItemlistDataTable>(&item_list_data_table_, "itemlist.csv");
  RegisterAsyncLoadHandle<ActivitynotificationDataTable>(&activity_notify_data_table_, "activityNotification.csv");
  RegisterAsyncLoadHandle<MailmessageDataTable>(&mail_msg_data_table_, "mailmessage.csv");
  RegisterAsyncLoadHandle<ServerListDataTable>(&server_list_data_table_, "serverList.csv");
  RegisterAsyncLoadHandle<CardcapacityDataTable>(&card_capacity_data_table_, "cardCapacity.csv");
  RegisterAsyncLoadHandle<RoleDataTable>(&role_data_table_, "role.csv");
  RegisterAsyncLoadHandle<CheckpointMainDataTable>(&checkpoint_main_data_table_, "checkpointMain.csv");
  RegisterAsyncLoadHandle<CheckpointDailyDataTable>(&checkpoint_daily_data_table_, "checkpointDaily.csv");
  RegisterAsyncLoadHandle<CheckpointChaDataTable>(&checkpoint_cha_data_table_, "checkpointCha.csv");
  RegisterAsyncLoadHandle<PvpawardDataTable>(&pvp_award_data_table_, "pvpaward.csv");
  RegisterAsyncLoadHandle<AnnouncementDataTable>(&announcement_data_table_,"announcement.csv");
  RegisterAsyncLoadHandle<PvpRankAwardDataTable>(&pvp_rank_award_data_table_,"pvpRankAward.csv");
  RegisterAsyncLoadHandle<FlopDataTable>(&flop_data_table_, "flop.csv");
  RegisterAsyncLoadHandle<ActivityLevelDataTable>(&activity_level_data_table_,"activityLevel.csv");
  RegisterAsyncLoadHandle<ActivityDaythDataTable>(&activity_dayth_data_table_,"activityDayth.csv");
  RegisterAsyncLoadHandle<VipDataTable>(&vip_data_table_,"vip.csv");
  RegisterAsyncLoadHandle<CheckpointBoxDataTable>(&checkpoint_box_data_table_,"checkpointBox.csv");
  RegisterAsyncLoadHandle<FragmentDataTable>(&fragment_data_table,"fragment.csv");
  RegisterAsyncLoadHandle<EquipDataTable>(&equip_data_table_,"equip.csv");
  RegisterAsyncLoadHandle<StrengthencostDataTable>(&strengthen_cost_data_table,"strengthencost.csv");
  RegisterAsyncLoadHandle<EliteDataTable>(&elite_data_table,"elite.csv");
  RegisterAsyncLoadHandle<LanguageDataTable>(&language_data_table,"csv_language.csv");
  RegisterAsyncLoadHandle<LanguageDramaDataTable>(&language_drama_data_table,"csv_language_drama.csv");
  RegisterAsyncLoadHandle<ShopDataTable>(&shop_data_table, "shop.csv");
  RegisterAsyncLoadHandle<QualityDataTable>(&quality_data_table,"quality.csv");
  RegisterAsyncLoadHandle<DailyWorkDataTable>(&daily_work_table,"dailywork.csv");
  RegisterAsyncLoadHandle<LimitGiftDataTable>(&limitGift_data_table,"limitedgift.csv");
  RegisterAsyncLoadHandle<ChallengeDataTable>(&challenge_data_table,"challenge.csv");
  RegisterAsyncLoadHandle<VipBoxDataTable>(&vipbox_data_table_,"vipbox.csv");
  RegisterAsyncLoadHandle<NewbreakoutDataTable>(&break_out_data_table, "newbreakout.csv");
  RegisterAsyncLoadHandle<NewuprarityDataTable>(&up_rarity_data_table, "uprarity.csv");
  RegisterAsyncLoadHandle<DailycheckinDataTable>(&dailycheckin_data_table,"dailycheckin.csv");
  RegisterAsyncLoadHandle<MonthfragmentDataTable>(&monthfragment_data_table,"monthfragment.csv");
  RegisterAsyncLoadHandle<BabelDataTable>(&babel_data_table,"babel.csv");

  RegisterAsyncLoadHandle<SecretshopDataTable>(&secretshop_data_table,"secretshop.csv");
  RegisterAsyncLoadHandle<OnlinegiftDataTable>(&onlinegift_data_table,"onlinegift.csv");
  RegisterAsyncLoadHandle<Cdkey_rewardDataTable>(&cdkey_reward_data_table,"cdkey_reward.csv");
  RegisterAsyncLoadHandle<dailyTaskDataTable>(&daily_tasks_data_table,"dailytasks.csv");
  RegisterAsyncLoadHandle<FunctionDataTable>(&function_Data_Table, "function.csv");
  RegisterAsyncLoadHandle<EmailDataTable>(&email_data_table, "email.csv");
  RegisterAsyncLoadHandle<DailyLevelDataTable>(&DailyLevel_Data_Table,"dailylv.csv");
  RegisterAsyncLoadHandle<ShowActivityDataTable>(&show_activity_data_table, "ShowActivity.csv");
  RegisterAsyncLoadHandle<RandomBoxMapDataTable>(&random_box_map_data_table, "random_box_map.csv");
  RegisterAsyncLoadHandle<EvolveDataTable>(&evolve_data_table, "evolve.csv");
  RegisterAsyncLoadHandle<SkillGrowthDataTable>(&skillgrowth_data_table,"skillgrowth.csv");
  std::string lan = "";
  switch (mCurrentLanguageType)  
  {  
  case kLanguageEnglish:  
    break;  
  case kLanguageChinese:
    break;  
  case kLanguageFrench:  
    break;  
  case kLanguageGerman:  
    break;
  case kLanguageItalian:  
    break;
  case kLanguageRussian:  
    break;
  case kLanguageSpanish:   
    break;
  case kLanguageKorean:
    lan = "_agoko";
    break;  
  }
  string path = "mission" + lan + ".csv";
  RegisterAsyncLoadHandle<MissionDataTable>(&mission_data_table_, path.c_str());

  return true;
}

bool DataManager::loadSkill()
{
  LoadSingleTable<SkillBrkDataTable>(&skill_brk_table_, "skillbrk.csv");
  LoadSingleTable<SkillDataTable>(&skill_table_, "skill.csv");
  LoadSingleTable<SkillAttackRangeTable>(&skill_attack_range_table_, "skillAttackRange.csv");
  LoadSingleTable<TavernDataTable>(&tavern_data_table_, "tavern.csv");

  //The "BaseResDataTable::GetInstance()->AddResDataToTable(data->cid, data);" at void CharacterDataTable::parseRow(vector<string> &row)
  //LoadSingleTable<CharacterDataTable>(&character_data_table_, "character.csv");
  LoadSingleTable<AuraDataTable>(&aura_data_table_, "aura.csv");
  return true;
}

AbilityDataTable* DataManager::GetAbilityDataTable()
{
  return ability_data_table_;
}

CharacterDataTable* DataManager::GetCharacterDataTable()
{
  return character_data_table_;
}

SkillBrkDataTable* DataManager::GetSkillBrkTable()
{
  return skill_brk_table_;
}

SkillDataTable* DataManager::GetSkillDataTable()
{
  return skill_table_;
}

SkillAttackRangeTable* DataManager::GetSkillAttackRangeTable()
{
  return skill_attack_range_table_;
}

ProjectilesDataTable* DataManager::GetProjectilesDataTable()
{
  return projectiles_data_table_;
}

DramaDataTable* DataManager::GetDramaDataTable()
{
  return drama_data_table_;
}


FreshmanDataTable* DataManager::GetFreshmanDataTable()
{
  return freshman_data_table_;
}

RankDataTable* DataManager::GetRankDataTable()
{
  return rank_data_table_;
}

AuraDataTable* DataManager::GetAuraDataTable()
{
	return aura_data_table_;
}

GradeRewardDataDataTable* DataManager::GetGradeRewardDataDataTable()
{
	return grade_reward_data_table_;
}

BuffDataTable* DataManager::GetBuffDataTable()
{
  return buff_data_table_;
}

BoxlistDataTable* DataManager::GetBoxlistDataTable()
{
  return box_list_data_table_;
}

ItemlistDataTable* DataManager::GetItemlistDataTable() 
{
  return item_list_data_table_;
}

TavernDataTable* DataManager::GetTavernDataTable()
{
  return tavern_data_table_;
}

ActivitynotificationDataTable* DataManager::GetActivitNotifyDataTable()
{
  return activity_notify_data_table_;
}

data::UserInfo* DataManager::user_info()
{
  return user_info_;
}

BornCalculator* DataManager::calculator()
{
  return calculator_;
}

DataSyncModule* DataManager::data_sync_module()
{
  return data_sync_module_;
}

MailmessageDataTable* DataManager::GetMailMessageDataTable()
{
  return mail_msg_data_table_;
}


ServerListDataTable* DataManager::GetServerListDataTable()
{
  return server_list_data_table_;
}
void DataManager::setServerList(ServerListDataTable *table)
{
    server_list_data_table_ = table;
}

CardcapacityDataTable* DataManager::GetCardCapacityDataTable()
{
  return card_capacity_data_table_;
}

RoleDataTable* DataManager::GetRoleDataTable()
{
  return role_data_table_;
}

CheckpointMainDataTable* DataManager::GetCheckpointMainDataTable()
{
	return checkpoint_main_data_table_;
}

CheckpointDailyDataTable* DataManager::GetCheckpointDailyDataTable()
{
	return checkpoint_daily_data_table_;
}

CheckpointChaDataTable*  DataManager::GetCheckpointChaDataTable()
{
	return checkpoint_cha_data_table_;
}

MissionDataTable*  DataManager::GetMissionDataTable()
{
	return mission_data_table_;
}

PvpawardDataTable* DataManager::GetPvpAwardDataTable()
{
  return pvp_award_data_table_;
}

AnnouncementDataTable*  DataManager::GetAnnouncementDataTable()
{
  return announcement_data_table_;
}

PvpRankAwardDataTable* DataManager::GetPvpRankAwardDataTable()
{
  return pvp_rank_award_data_table_;
}

FlopDataTable* DataManager::GetFlopDataTable()
{
  return flop_data_table_;
}

ActivityLevelDataTable* DataManager::GetActivityLevelDataTable()
{
  return activity_level_data_table_;
}

ActivityDaythDataTable*  DataManager::GetActivityDaythDataTable()
{
  return activity_dayth_data_table_;
}

VipDataTable* DataManager::GetVipDataTable()
{
  return vip_data_table_;
}

VipBoxDataTable* DataManager::GetVipBoxDataTable()
{
  return vipbox_data_table_;
}

CheckpointBoxDataTable* DataManager::GetCheckpointBoxDataTable()
{
  return checkpoint_box_data_table_;
}

FragmentDataTable* DataManager::GetFragmentDataTable()
{
  return fragment_data_table;
}
EquipDataTable* DataManager::GetEquipDataTable()
{
  return equip_data_table_;
}

StrengthencostDataTable* DataManager::GetStrengthenDataTable()
{
	return strengthen_cost_data_table;
}

int DataManager::getRoleCardId()
{
    RoleData* data = GetRoleDataTable()->GetRole(user_info_->role_id());
    return data->GetCardID();
}