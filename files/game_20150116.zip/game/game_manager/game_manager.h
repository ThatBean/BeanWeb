//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: game_manager.h
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#ifndef GAME_MANAGER_H_
#define GAME_MANAGER_H_

#include "cocos2d.h"
#include "engine/base/basictypes.h"
#include "game/user_interface/template_scene.h"
#include "game/game_manager/core_value_module.h"
#include <boost/asio.hpp>
#include <boost/bind.hpp>

#include "engine/platform/SingleInstance.h"
#include "network/net_client_tcp/sample_tcp_client.h"

namespace taomee
{

template <typename Entity>
class UpdateHelper;

template <typename Entity>
class StateMachine;

template <typename Entity>
class State;
  
class GameManager : public SingleInstanceObj
{
public:
  virtual ~GameManager();

  static GameManager& GetInstance();

  StateMachine<GameManager>* GetStateMachine()
  {
    return game_state_machine_;
  }

  boost::asio::io_service& ui_message_loop()
  {
    return ui_message_loop_;
  }
  
  bool  is_in_city_state() const { return is_in_city_state_; }
  void  CityStateEnd() { is_in_city_state_ = false; }

  bool  is_in_battle_state() const { return is_in_battle_state_; }
  void  BattleStateEnd() { is_in_battle_state_ = false; }

  void  SetNextMapState(State<GameManager>* next_state) 
  { 
     pre_game_state_ =  next_game_state_;
     next_game_state_ = next_state;
  }
  State<GameManager>*   GetNextMapState(){return next_game_state_;}
  State<GameManager>*   GetPreMapState() { return pre_game_state_; }
  void UpdateEachFrame(float delta);

public:
  void StartGame();

  void OnLoadResourceCompleted();
  void OnLoginAuthCompleted(bool is_new_player);
  void OnGetUserDataCompleted();
	void OnCreateRoleCompleted();

	void OnLoginCompleted();


  void StartCity();
  void RestartCity();

  void StartBattle();
  void OnBattleCompleted();
  
  void StartPvp();
  void OnPvpCompleted();

  void StartBattleSandBox();
  void OnBattleSandBoxCompleted();
  
  void OpenFriendUI();
  void OnFriendUIClosed();

  void OpenArenaUI();
  void OnArenaUIClosed();

  void OnSwitchCityMap();

  void GoToMissionSelect(int country_id, int castle_id);

  void AddUILayerOnCurrentScene(cocos2d::CCLayer *layer,int nZOrder = 0);
  void SetCurrentTemplateScene(ui::TemplateScene* scene) { current_template_scene_ = scene; }
  ui::TemplateScene* getCurrentTemplateScene() {return current_template_scene_;}

  void showUserCenter();
public:
  void OnAppReactiveToForeground();
  void OnAPPEnterBackground();

public:
  void LoadResource();

  void onNotificationLogouOut(boost::shared_ptr<XPacket> pack);
private:
  void poll();

  void transitToState(State<GameManager>* next_state);


private:
  GameManager();
  DISALLOW_COPY_AND_ASSIGN(GameManager);
  
private:
  bool  is_in_city_state_;
  bool  is_in_battle_state_;

private:
  StateMachine<GameManager>*  game_state_machine_;
  UpdateHelper<GameManager>*  update_helper_;

  boost::asio::io_service     ui_message_loop_;
  State<GameManager>*         next_game_state_;
  State<GameManager>*         pre_game_state_;
  ui::TemplateScene*          current_template_scene_;

  boost::BOOST_SIGNALS_NAMESPACE::connection nnc_com_logou_out;
};

} /* namespace taomee */
#endif /* GAME_MANAGER_H_ */
