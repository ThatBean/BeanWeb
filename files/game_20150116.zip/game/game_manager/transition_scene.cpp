//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: transition_scene.cpp
//        Author: leohou
//       Version:
//          Date: Nov 25, 2013
//          Time: 12:42:24 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     12:42:24 AM
//
//////////////////////////////////////////////////////////////

#include "game/game_manager/transition_scene.h"

#include "engine/base/basictypes.h"
#include "engine/base/state_machine/state.h"
#include "engine/base/state_machine/state_machine.h"

#include "game/game_manager/transition_state.h"
#include "game/user_interface/ui_constants.h"
#include "engine/animation/projectile_animation.h"
#include "engine/animation/skeleton_animation_cache_manager.h"
#include "engine/animation/projectile_animation_cache_manager.h"
#include "engine/particle/particle_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/shader/shader_manager.h"
#include "engine/ui_factory/ui_factory.h"
#include "../../common/cocos2dx/extensions/CocoStudio/Armature/utils/CCSpriteFrameCacheHelper.h"
#include "engine/sound/sound_manager.h"
#include "engine/asprite/AspriteManager.h"

using namespace cocos2d;

namespace taomee {

TransitionScene::TransitionScene()
: transition_state_machine_(NULL),
  transition_over_(false)
{
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "enterFightSceneNotifyHdr");//隐藏主界�?  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/ui_net_waitting.lua", "OnTransitionSceneBegin");
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/multitude_layer_manager.lua", "CleanAllLayer");
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/ui_common_card_cell.lua", "ResetCommonCellObjCache");

  transition_state_machine_ = new StateMachine<TransitionScene>(this);
}

TransitionScene::~TransitionScene()
{
  //LuaTinkerManager::GetInstance().CallLuaFunc("script/ui/multitude_layer_manager.lua", "CleanAllLayer");
  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/ui_net_waitting.lua", "OnTransitionSceneEnd");
  SAFE_DEL(transition_state_machine_);
}

bool TransitionScene::init()
{
  CCScene::init();

  CCLayer* layer = CCLayer::create();
  layer->setContentSize(ui::ui_design_size);

  layer->ignoreAnchorPointForPosition(false);
  layer->setAnchorPoint(ccp(0.5f, 0.5f));
  layer->setPosition(ccp(this->getContentSize().width * 0.5f,
                         this->getContentSize().height * 0.5f));
  this->addChild(layer);

  cocos2d::extension::UILayer* ui_layer = cocos2d::extension::UILayer::create();
  ui_layer->scheduleUpdate();
  ui_layer->addWidget(UIFactory::createWidgetFromFile("res/ui/agoui_battle_loading.json"));
  layer->addChild(ui_layer);

  cocos2d::extension::UIImageView* sprite_image = dynamic_cast<cocos2d::extension::UIImageView*>(ui_layer->getWidgetByName("Image_Sprite"));

  ProjectileAnimation* ani = new ProjectileAnimation();
  ani->initWithName("loading_star_01");
  sprite_image->getRenderer()->addChild(ani);
  ani->release();
  UILabel* lab = dynamic_cast<UILabel*>(ui_layer->getWidgetByName("tips_label"));

  char* strContent = LuaTinkerManager::GetInstance().CallLuaFunc<char*>("script/config/loadingTips_config.lua", "GetLuaTextbyLevel", DataManager::GetInstance().user_info()->rank());
  lab->setText(strContent);



  

  cocos2d::extension::UIImageView* sprite_point[3];
  sprite_point[0] = dynamic_cast<cocos2d::extension::UIImageView*>(ui_layer->getWidgetByName("Image_Loading_0"));
  sprite_point[1] = dynamic_cast<cocos2d::extension::UIImageView*>(ui_layer->getWidgetByName("Image_Loading_1"));
  sprite_point[2] = dynamic_cast<cocos2d::extension::UIImageView*>(ui_layer->getWidgetByName("Image_Loading_2"));


//   for (int i = 0; i < 3; ++i) 
//   {
//     sprite_point[i]->setVisible(false);
//     CCDelayTime* delay = CCDelayTime::create(i*0.2f);
//     CCBlink* blink = CCBlink::create(40,30);  
//     CCSequence* seq =  CCSequence::create(delay, blink, NULL);
//     sprite_point[i]->runAction(seq);  
//   }  

  this->scheduleUpdate();
  transition_state_machine_->ChangeState(TransitionStatePurgeCache::Instance());
  return true;
}

void TransitionScene::update(float delta_time)
{
  transition_state_machine_->UpdateEachFrame(delta_time);
}

void TransitionScene::PurgeCacheData()
{

  SkeletonAnimationCacheManager::GetInstance().CleanAllCacheSkeletonAnimation();
  cocos2d::extension::CCSpriteFrameCacheHelper::sharedSpriteFrameCacheHelper()->removeAllTextureAtlas();
  CCArmatureDataManager::sharedArmatureDataManager()->removeAll();
  ProjectileAnimationCacheManager::GetInstance().CleanAllCacheProjectileAnimation();
  ParticleManager::GetInstance().ClearAllCachePartile();
  AspriteManager::GetInstance().ClearAllAsprite();
  //CCSpriteFrameCache::sharedSpriteFrameCache()->removeUnusedSpriteFrames();
  CCSpriteFrameCache::sharedSpriteFrameCache()->removeSpriteFrames();
  CCDirector::sharedDirector()->purgeCachedData();
  CCTextureCache::sharedTextureCache()->removeUnusedTextures();  
}

void TransitionScene::OnLoadResourceCompleted()
{
  this->unscheduleUpdate();
  transition_over_ = true;
}

} /* namespace taomee */
