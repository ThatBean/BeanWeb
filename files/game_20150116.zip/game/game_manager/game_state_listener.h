//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: game_state_listener.h
//        Author: coldouyang
//          Date: 2014/7/23 16:30
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/23      add
//////////////////////////////////////////////////////////////

#ifndef GAME_STATE_LISTENER_H
#define GAME_STATE_LISTENER_H

#include "cocos2d.h"


class GameStateListener
{
public:

  GameStateListener() 
  {
    //cocos2d::CCNotificationCenter::sharedNotificationCenter()->addObserver(this, callfuncO_selector(GameStateListener::OnGameRestart), )
  };
  virtual ~GameStateListener()
  {
    
  };
  /************************************************************************/
  /* ��Ϸ����                                                              */
  /************************************************************************/
  virtual void OnGameRestart() { cocos2d::CCLog("Receive GameRestart Event"); };
};

#endif