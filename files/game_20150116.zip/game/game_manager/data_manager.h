//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: data_manager.h
//        Author: robbiepan
//          Date: 2013/9/12 15:43
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     robbiepan    2013/9/12      add
//////////////////////////////////////////////////////////////

#ifndef DATA_MANAGER_H
#define DATA_MANAGER_H
#include "game/user_data/user_data_constants.h"
#include "game/data_table/ability_data_table.h"
#include "game/data_table/aura_data_table.h"
#include "game/data_table/grade_reward_data_table.h"
#include "game/data_table/skill_brk_data_table.h"
#include "game/data_table/skill_data_table.h"
#include "game/data_table/skill_attack_range_table.h"
#include "game/data_table/character_data_table.h"
#include "game/data_table/projectiles_data_table.h"
#include "game/data_table/drama_data_table.h"
#include "game/data_table/freshman_data_table.h"
#include "game/data_table/rank_data_table.h"
#include "game/data_table/buff_data_table.h"
#include "game/data_table/boxlist_data_table.h"
#include "game/data_table/itemlist_data_table.h"
#include "game/data_table/tavern_data_table.h"
#include "game/data_table/activitynotification_data_table.h"
#include "game/data_table/mailmessage_data_table.h"
#include "game/data_table/serverlist_data_table.h"
#include "game/data_table/cardcapacity_data_table.h"
#include "game/data_table/role_data_table.h"
#include "game/data_table/pvpaward_data_table.h"
#include "game/data_table/announcement_data_table.h"
#include "game/data_table/pvprankaward_data_table.h"
#include "game/data_table/flop_data_table.h"
#include "game/data_table/activity_level_data_table.h"
#include "game/data_table/activity_dayth_data_table.h"
#include "game/data_table/vip_data_table.h"
#include "game/data_table/vipbox_data_table.h"
#include "game/data_table/equip_data_table.h"
#include "game/user_data/user_info.h"
#include "game/game_manager/born_calculator.h"
#include "game/data_table/fragment_data_table.h"
#include "game/data_table/strengthencost_data_table.h"
#include "game/data_table/language_data_table.h"
#include "game/data_table/language_drama_data_table.h"
#include "game/data_table/shop_data_table.h"
#include "game/data_table/checkpointmain_data_table.h"
#include "game/data_table/elite_data_table.h"
#include "game/data_table/quality_data_table.h"
#include "game/data_table/daily_work_table.h"
#include "game/data_table/newbreakout_data_table.h"
#include "game/data_table/newuprarity_data_table.h"
#include "game/data_table/challenge_data_table.h"
#include "game/data_table/limit_gift_table.h"
#include "game/data_table/dailycheckin_data_table.h"
#include "game/data_table/monthfragment_data_table.h"
#include "game/data_table/babel_data_table.h"
#include "game/data_table/secretshop_data_table.h"
#include "game/data_table/onlinegift_data_table.h"
#include "game/data_table/cdkey_reward_data_table.h"
#include "game/data_table/dailytasks_data_table.h"
#include "game/data_table/function_data_table.h"
#include "game/data_table/email_data_table.h"
#include "game/data_table/daily_Lv_table.h"
#include "game/data_table/showactivity_data_table.h"
#include "game/data_table/random_box_map_data_table.h"
#include "game/data_table/evolve_data_table.h"
#include "game/data_table/skillgrowth_data_table.h"

#include "engine/platform/SingleInstance.h"
using namespace taomee;

namespace taomee
{
  class BornCalculator;
  class DataSyncModule;
}

class CheckpointMainDataTable;
class CheckpointDailyDataTable;
class CheckpointChaDataTable;
class CheckpointBoxDataTable;
class MissionDataTable;
//class PvpSkillInfoDataTable;

class DataManager : public SingleInstanceObj
{
public:
  static DataManager& GetInstance();

  virtual ~DataManager();
  void                        Init();
  // reload
  bool                        ReloadFile();
  
public: // getter & setter
  AbilityDataTable*           GetAbilityDataTable();
  CharacterDataTable*         GetCharacterDataTable();
  SkillBrkDataTable*          GetSkillBrkTable();
  SkillDataTable*             GetSkillDataTable();
  SkillAttackRangeTable*      GetSkillAttackRangeTable();
  ProjectilesDataTable*       GetProjectilesDataTable();
  DramaDataTable*             GetDramaDataTable();
  FreshmanDataTable*          GetFreshmanDataTable();
  RankDataTable*              GetRankDataTable();
  BuffDataTable*              GetBuffDataTable();
  AuraDataTable*              GetAuraDataTable();
  GradeRewardDataDataTable*   GetGradeRewardDataDataTable();
  BoxlistDataTable*           GetBoxlistDataTable();
  ItemlistDataTable*          GetItemlistDataTable();
  TavernDataTable*            GetTavernDataTable();
  ActivitynotificationDataTable* GetActivitNotifyDataTable();
  MailmessageDataTable*       GetMailMessageDataTable();
  ServerListDataTable*        GetServerListDataTable();
  CardcapacityDataTable*      GetCardCapacityDataTable();
  RoleDataTable*              GetRoleDataTable();
  CheckpointMainDataTable*    GetCheckpointMainDataTable();
  CheckpointDailyDataTable*   GetCheckpointDailyDataTable();
  CheckpointChaDataTable*     GetCheckpointChaDataTable();
  MissionDataTable*           GetMissionDataTable();
  PvpawardDataTable*          GetPvpAwardDataTable();
  AnnouncementDataTable*      GetAnnouncementDataTable();
  PvpRankAwardDataTable*      GetPvpRankAwardDataTable();
  FlopDataTable*              GetFlopDataTable();
  ActivityLevelDataTable*     GetActivityLevelDataTable();
  ActivityDaythDataTable*     GetActivityDaythDataTable();
  VipDataTable*               GetVipDataTable();
  VipBoxDataTable*            GetVipBoxDataTable();  
  CheckpointBoxDataTable*     GetCheckpointBoxDataTable();
  FragmentDataTable*          GetFragmentDataTable();
  EquipDataTable*             GetEquipDataTable();
  StrengthencostDataTable*	  GetStrengthenDataTable();
  inline EliteDataTable*      GetEliteDataTable(){ return elite_data_table; };
  inline LanguageDataTable*   GetLanguageDataTable() { return language_data_table; };
  inline LanguageDramaDataTable* GetLanguageDramaDataTable() { return language_drama_data_table; };
  ShopDataTable*              GetShopDataTable() { return shop_data_table; };
  QualityDataTable*           GetQualityDataTable() { return quality_data_table; };
  DailyWorkDataTable*         GetDailyWorkTable() { return daily_work_table; };
  NewbreakoutDataTable*          GetBreakOutDataTable() { return break_out_data_table; }
  NewuprarityDataTable*          GetUpRarityDataTable() { return up_rarity_data_table; }
  ChallengeDataTable*         getChallengeDataTable() {return challenge_data_table;};
  LimitGiftDataTable*         getLimitGiftDataTable() {return limitGift_data_table;};
  DailycheckinDataTable*         getDailycheckinDataTable() {return dailycheckin_data_table;};
  MonthfragmentDataTable*         getMonthfragmentDataTable() {return monthfragment_data_table;};
  BabelDataTable*	GetBabelDataTable(){return babel_data_table;};
  SecretshopDataTable*         getSecretshopDataTable() {return secretshop_data_table;};
  OnlinegiftDataTable*         getOnlinegiftDataTable() {return onlinegift_data_table;};
  Cdkey_rewardDataTable*       getCDKeyDataTable() {return cdkey_reward_data_table;};
  dailyTaskDataTable*       getDailyTaskDataTable() {return daily_tasks_data_table;};
  FunctionDataTable*	getFunctionDataTable()	{return function_Data_Table;};
  EmailDataTable*	getEmailDataTable()	{return email_data_table;};
  DailyLevelDataTable* getDailyLevelTable() {return DailyLevel_Data_Table;};
  ShowActivityDataTable* getShowActivityDataTable() {return show_activity_data_table;};
  RandomBoxMapDataTable* getRandomBoxMapDataTable() { return random_box_map_data_table; }
  EvolveDataTable* getEvolveDataTable() { return evolve_data_table; }
  SkillGrowthDataTable* getSkillGrowthTable(){return skillgrowth_data_table;}


  taomee::data::UserInfo*     user_info();
  taomee::BornCalculator*     calculator();
  
  taomee::DataSyncModule*     data_sync_module();
  void setServerList(ServerListDataTable *table);

  static void  setLanguageType(int type);
  static int   getCurrentLanguageType(){ return mCurrentLanguageType; };
  int                      getRoleCardId();
private:
  DataManager();
  DISALLOW_COPY_AND_ASSIGN(DataManager);

  // loadfile
  bool                        load();  
  bool                        loadSkill();
  
private:
  AbilityDataTable*           ability_data_table_;
  AuraDataTable*              aura_data_table_;
  GradeRewardDataDataTable*   grade_reward_data_table_;
  SkillBrkDataTable*          skill_brk_table_;
  SkillDataTable*             skill_table_;
  SkillAttackRangeTable*      skill_attack_range_table_;
  CharacterDataTable*         character_data_table_;
  ProjectilesDataTable*       projectiles_data_table_;
  DramaDataTable*             drama_data_table_;
  FreshmanDataTable*          freshman_data_table_;
  RankDataTable*              rank_data_table_;
  BuffDataTable*              buff_data_table_;
  BoxlistDataTable*           box_list_data_table_;
  ItemlistDataTable*          item_list_data_table_;
  TavernDataTable*            tavern_data_table_;
  ActivitynotificationDataTable* activity_notify_data_table_;
  MailmessageDataTable*       mail_msg_data_table_;
  ServerListDataTable*        server_list_data_table_;
  CardcapacityDataTable*      card_capacity_data_table_;
  RoleDataTable*              role_data_table_;
  CheckpointMainDataTable*    checkpoint_main_data_table_;
  CheckpointDailyDataTable*   checkpoint_daily_data_table_;
  CheckpointChaDataTable*     checkpoint_cha_data_table_;
  MissionDataTable*           mission_data_table_;
  PvpawardDataTable*          pvp_award_data_table_;
  AnnouncementDataTable*      announcement_data_table_;
  PvpRankAwardDataTable*      pvp_rank_award_data_table_;
  FlopDataTable*              flop_data_table_;
  ActivityLevelDataTable*     activity_level_data_table_;
  ActivityDaythDataTable*     activity_dayth_data_table_;
  VipDataTable*               vip_data_table_;
  VipBoxDataTable*            vipbox_data_table_;
  CheckpointBoxDataTable*     checkpoint_box_data_table_;
  FragmentDataTable*          fragment_data_table;
  EquipDataTable*             equip_data_table_;
  StrengthencostDataTable*	  strengthen_cost_data_table;
  EliteDataTable*             elite_data_table;
  LanguageDataTable*          language_data_table;
  LanguageDramaDataTable*     language_drama_data_table;
  ShopDataTable*              shop_data_table;
  QualityDataTable*           quality_data_table;
  DailyWorkDataTable*		      daily_work_table;
  
  NewbreakoutDataTable*          break_out_data_table;
  NewuprarityDataTable*          up_rarity_data_table;
  ChallengeDataTable*		  challenge_data_table;
  DailycheckinDataTable*		  dailycheckin_data_table;
  LimitGiftDataTable*		  limitGift_data_table;
  MonthfragmentDataTable*		  monthfragment_data_table;
  BabelDataTable*              babel_data_table;
  SecretshopDataTable*		  secretshop_data_table;
  OnlinegiftDataTable*		  onlinegift_data_table;
  Cdkey_rewardDataTable*    cdkey_reward_data_table;
  dailyTaskDataTable*  daily_tasks_data_table;
  FunctionDataTable*	function_Data_Table;
  EmailDataTable* email_data_table;
  DailyLevelDataTable *DailyLevel_Data_Table;
  ShowActivityDataTable *show_activity_data_table;
  RandomBoxMapDataTable*  random_box_map_data_table;  
  EvolveDataTable* evolve_data_table;
  SkillGrowthDataTable* skillgrowth_data_table;

  data::UserInfo*             user_info_;
  BornCalculator*             calculator_;

  DataSyncModule*             data_sync_module_;
  public:
  static int                  mCurrentLanguageType;
};

#endif
