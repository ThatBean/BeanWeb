//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: game_manager.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#include "game/game_manager/game_manager.h"

#include "engine/base/basictypes.h"
#include "engine/base/update_helper.h"
#include "engine/base/state_machine/state_machine.h"
#include "engine/platform/display_mem.h"
#include "engine/particle/particle_manager.h"
#include "game/account/account_manager.h"
#include "game/battle/battle_controller.h"
#include "game/major_city/city_view/city_controller.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/game_state.h"
#include "game/game_manager/game_state_scene_transition.h"
// #include "game/pvp/pvp_controller.h"
#include "game/scene/loading_sence/login_controller.h"
#include "game/scene/arena_scene/arena_controller.h"
#include "network/net_manager.h"
#include "network/net_client_tcp/sample_tcp_client.h"
#include "engine/script/lua_tinker_manager.h"
#include "CCLuaEngine.h"
#include "game/game_manager/game_logger_manager.h"
#include "engine/event_system/event_manager.h"
#include "game/event/universal_event.h"
#include "engine/platform/DataStatisticalManager.h"
#if CC_TARGET_PLATFORM == CC_PLATFORM_IOS
#import "SDKManager.h"
#endif

namespace {
const std::size_t kConcurrencyHint = 1;
}

namespace taomee {

namespace
{
// T:: Next sceneController
template <class T>
void TransitToState(T next_controller, State<GameManager>* next_state)
{
  assert(next_state != NULL);
  //assert(GameManager::GetInstance().GetStateMachine()->CurrentState() !=
  //       GameStateSceneTransition<T>::Instance());
  GameManager::GetInstance().SetNextMapState(next_state);

  GameStateSceneTransition<T>::Instance()->set_next_state(next_state);
  GameStateSceneTransition<T>::Instance()->set_next_scene_controller(next_controller);
  GameManager::GetInstance().ui_message_loop().post(boost::bind(&StateMachine<GameManager>::ChangeState,
                                                                GameManager::GetInstance().GetStateMachine(),
                                                                GameStateSceneTransition<T>::Instance()));
}
} //namesapce anonymous
  
GameManager& GameManager::GetInstance()
{
  static GameManager* X = NULL;
  if (!X)
  {
    X = new GameManager();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
  }
  return *X;
}

GameManager::GameManager()
: is_in_city_state_(false),
  is_in_battle_state_(false),
  game_state_machine_(NULL),
  update_helper_(NULL),
  ui_message_loop_(kConcurrencyHint),
  pre_game_state_(NULL),
  current_template_scene_(NULL)
{
  game_state_machine_ = new StateMachine<GameManager>(this);
  update_helper_ = new UpdateHelper<GameManager>(this);
  update_helper_->ScheduleUpdate(kUpdateEachFrame);
}

GameManager::~GameManager()
{
  nnc_com_logou_out.disconnect();
  SAFE_DEL(game_state_machine_);
  
  update_helper_->UnscheduleUpdate(kUpdateEachFrame);
  CC_SAFE_RELEASE_NULL(update_helper_);
}

void GameManager::StartGame() {
  //LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/main.lua","ResetAllLoadFile");
  game_state_machine_->ChangeState(GameStateLoadResource::Instance());
}


void GameManager::UpdateEachFrame(float delta)
{
  game_state_machine_->UpdateEachFrame(delta);
  
  ParticleManager::GetInstance().UpdateEachFrame(delta);
  
  this->poll();

//#ifdef DEBUG
	// lua memory: xxKB
	int lua_use_memory = lua_getgccount(cocos2d::CCLuaEngine::defaultEngine()->getLuaStack()->getLuaState());
  cocos2d::CCDirector::sharedDirector()->updateMemoryValue(usedMemory(), lua_use_memory);
//#endif
  net::NetManager::GetInstance().Poll();
	net::SampleTcpClient::GetInstance().Poll();
}

void GameManager::showUserCenter()
{
#ifdef TargetForPP
	SDKManager::showUserCenter();
#endif
}

void GameManager::poll()
{
  ui_message_loop_.reset();
  ui_message_loop_.poll_one();
}


void GameManager::LoadResource()
{
  DataManager::GetInstance().Init();
  ParticleManager::GetInstance().LoadAll();
}


void GameManager::OnLoadResourceCompleted()
{
  LoginController::GetInstance().HandleFSMMessage(LoginController::FSMSTART);
}

void GameManager::OnLoginAuthCompleted(bool is_new_player)
{
  LoginController::GetInstance().set_is_new_player(is_new_player);
  LoginController::GetInstance().HandleFSMMessage(LoginController::AUTHOK);
}

void GameManager::transitToState(State<GameManager>* next_state)
{
  assert(next_state != NULL);
  assert(game_state_machine_->CurrentState() != GameStateTransition::Instance());
  GameManager::GetInstance().SetNextMapState(next_state);

  GameStateTransition::Instance()->set_next_state(next_state);
  ui_message_loop_.post(boost::bind(&StateMachine<GameManager>::ChangeState,
                                    game_state_machine_,
                                    GameStateTransition::Instance()));
}

void GameManager::OnGetUserDataCompleted()
{
  LoginController::GetInstance().HandleFSMMessage(LoginController::GETUSERDATACOMPLETE);
  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/formulaUI/FormulaHelper.lua", "BuildEquipmentFormulaMap");
}


void GameManager::OnCreateRoleCompleted()
{
	LoginController::GetInstance().HandleFSMMessage(LoginController::NETRESPONDSELECTSUCESS);
}

void GameManager::OnLoginCompleted()
{
    DataStatisticalManager::getInstance()->syncAccountInfo();
    GameLoggerManager::GetInstance()->setPlayerId(DataManager::GetInstance().user_info()->nick_name());
    GameLoggerManager::GetInstance()->setAccountId(account::AccountManager::GetInstance().user_id_str());
    GameLoggerManager::GetInstance()->setServerId(net::constants::GetCurrentServerNetworkId());
    GameLoggerManager::GetInstance()->setZoneId(1);//1����
    GameLoggerManager::GetInstance()->setSiteId(1);//ƽ̨��1Ĭ�ϱ�ʾ����
    GameLoggerManager::GetInstance()->setGameId(601);//601Ĭ�ϲ�����ϷID
    GameLoggerManager::GetInstance()->start();
    
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/scene/main_map_controller.lua", "OnLoginCompleted");

    //register
    nnc_com_logou_out = net::SampleTcpClient::GetInstance().
      SubscribeNotifyMsgReciverComplete<GameManager>(
      static_cast<int>(com_logout_cmd), this,
      &GameManager::onNotificationLogouOut);
}

void GameManager::onNotificationLogouOut(boost::shared_ptr<XPacket> pack)
{

  int event_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/event_contants.lua", 
    "GetEventIdWithStrkey", 
    "NetTcpLogouOut");
  event::UniversalEventWithIdParm* connected_tcp_event = event::UniversalEventWithIdParm::create(event_id);
  EventManager::GetInstance().Emit(connected_tcp_event);

  //LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/event_contants.lua","OnReceiveTcpDisConnect");
}

void GameManager::StartCity()
{
  is_in_city_state_ = true;
  TransitToState<city::CityController*>(&city::CityController::GetInstance(), 
    GameStateMap::Instance());
}

void GameManager::RestartCity()
{
  is_in_city_state_ = true;
  TransitToState<city::CityController*>(&city::CityController::GetInstance(), 
    GameStateRestartMap::Instance());
}

void GameManager::StartBattle()
{
  is_in_battle_state_ = true;
  //this->transitToState(GameStateBattle::Instance());
  TransitToState<battle::BattleController*>(&battle::BattleController::GetInstance(), 
                                            GameStateBattle::Instance());
}

void GameManager::OnBattleCompleted()
{
  switch(battle::BattleController::GetInstance().getBattleType())
  {
  case battle::kBattleType_Main:
  case battle::kBattleType_Pvp:
    { 
// 		int BackTypeId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/main_mission_util.lua", "QueryIsNeedToGoBack");
// 		//�ж�����
// 		if (BackTypeId==100)
// 		{
// 			TransitToState<city::CityController*>(&city::CityController::GetInstance(), GameStateMap::Instance());
// 		}
// 		else
// 		{
// 			TransitToState<city::CityController*>(&city::CityController::GetInstance(), GameStateMap::Instance());
// 			
// 			LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua", "OpenCheckpointSelectUI",BackTypeId);
// 		}

		TransitToState<city::CityController*>(&city::CityController::GetInstance(), GameStateMap::Instance());
	}
    break;
  //case battle::kBattleType_Pvp:
  //  {
  //    TransitToState<ArenaController*>(&ArenaController::GetInstance(), GameArenaState::Instance());
  //  }
  //  break;
  case battle::kBattleType_SandBox:
    {
      TransitToState<city::CityController*>(&city::CityController::GetInstance(), GameStateMap::Instance());
    }
    break;
  default:
    break;
  }

  // LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/framework/CPlusToLuaInterface.lua", "exitFightSceneNotifyHdr", battle::BattleController::GetInstance().getBattleType());//�˳�ս��
}

void GameManager::StartPvp()
{
  //TransitToState<pvp::PvpController*>(&pvp::PvpController::GetInstance(),
  TransitToState<battle::BattleController*>(&battle::BattleController::GetInstance(),
    GameStatePvpBattle::Instance());
}  
void GameManager::OnPvpCompleted()
{
  TransitToState<city::CityController*>(&city::CityController::GetInstance(),
    GameStateMap::Instance());
}

void GameManager::StartBattleSandBox()
{
  TransitToState<battle::BattleController*>(&battle::BattleController::GetInstance(),
    GameStateBattleSandBox::Instance());
}

void GameManager::OnBattleSandBoxCompleted()
{
  TransitToState<city::CityController*>(&city::CityController::GetInstance(),
                                        GameStateMap::Instance());
}

void GameManager::OpenFriendUI()
{
  //MainMapController::GetInstance().End();
  //this->transitToState(GameFriendState::Instance());
  TransitToState<FriendController*>(&FriendController::GetInstance(), 
      GameFriendState::Instance());
}

void GameManager::OnFriendUIClosed()
{
  //GameStateMap::Instance()->set_come_back(true);
  //this->transitToState(GameStateMap::Instance());
  TransitToState<city::CityController*>(&city::CityController::GetInstance(), 
      GameStateMap::Instance());
}

void GameManager::OpenArenaUI()
{
  TransitToState<ArenaController*>(&ArenaController::GetInstance(), 
    GameArenaState::Instance());
}

void GameManager::OnArenaUIClosed()
{
  TransitToState<city::CityController*>(&city::CityController::GetInstance(), 
    GameStateMap::Instance());
}

void GameManager::OnSwitchCityMap()
{
  TransitToState<city::CityController*>(&city::CityController::GetInstance(), 
    GameStateMap::Instance());
}

void GameManager::GoToMissionSelect(int country_id, int castle_id)
{
//   MainMapController::GetInstance().SetLocationMissionData(country_id, castle_id);
//   if (game_state_machine_->IsInState(*GameStateMap::Instance()))
//   {
//     MainMapController::GetInstance().ComeBackToMainMap();
//   } else
//   {
//     GameStateMap::Instance()->set_come_back(true);
//     //this->transitToState(GameStateMap::Instance());
//     TransitToState<MainMapController*>(&MainMapController::GetInstance(), 
//         GameStateMap::Instance());
//   }
}
  
void GameManager::OnAppReactiveToForeground()
{
  
}

void GameManager::OnAPPEnterBackground()
{
  if (is_in_battle_state_)
  {
    battle::BattleController::GetInstance().AppEnterBackgroundDuringBattleState();
  }
}

void GameManager::AddUILayerOnCurrentScene(cocos2d::CCLayer *layer,int nZOrder)
{
  //assert(current_template_scene_ != NULL);
  if (current_template_scene_ == NULL) return;
  current_template_scene_->AddLayerOnUILayer(layer, 0,nZOrder);
}
  
} /* namespace taomee */
