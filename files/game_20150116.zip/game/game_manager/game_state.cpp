//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: game_state.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#include "game/game_manager/game_state.h"

#include "engine/base/state_machine/state_machine.h"
#include "engine/base/load_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/sound/sound_manager.h"
#include "game/account/account_manager.h"
#include "game/battle/battle_controller.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/data_sync_module.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/transition_scene.h"
// #include "game/pvp/pvp_controller.h"
#include "game/scene/friend_scene/friend_controller.h"
#include "game/scene/loading_sence/login_controller.h"
#include "game/scene/arena_scene/arena_controller.h"
#include "game/user_interface/template_scene.h"
#include "game/major_city/city_view/city_controller.h"

namespace
{
const std::string kStateNameMap = "map";
const std::string kStateNameBattle = "battle";
const std::string kStateNamePvp = "pvp";
const std::string kStateNameBattleSandBox = "sandbox";
const std::string kStateNameTeam = "team";
const std::string kStateNameCardOp = "cardop";
const std::string kStateNameCardView = "cardview";
const std::string kStateNameTavern = "tavern";
const std::string kStateNameFriend = "friend";
const std::string kStateNameBook = "tutorial";
const std::string kStateNameDecompose = "decompose";
const std::string kStateNameEquipment = "equipment";
const std::string kStateNameDailyWork = "dailywork";
const std::string kStateNameArena = "arena";
}


namespace taomee
{

/**
 * load resource state
 */
GameStateLoadResource::GameStateLoadResource()
{
}

GameStateLoadResource::~GameStateLoadResource()
{
}

GameStateLoadResource* GameStateLoadResource::Instance()
{
  static GameStateLoadResource load_resource_state;
  return &load_resource_state;
}

void GameStateLoadResource::Enter(GameManager* game_manager)
{
  LoginController::GetInstance().Start();
}

void GameStateLoadResource::UpdateEachFrame(GameManager* game_manager, float delta)
{
  // do nothing
  LoginController::GetInstance().UpdateEachFrame(delta);
}

void GameStateLoadResource::Exit(GameManager* game_manager)
{
  LoginController::GetInstance().End();
}

/************************************************************************/
/* Restart Map                                                         */
/************************************************************************/
GameStateRestartMap::GameStateRestartMap()
{

}

GameStateRestartMap::~GameStateRestartMap()
{
}

GameStateRestartMap* GameStateRestartMap::Instance()
{
  static GameStateRestartMap map_state;
  return &map_state;
}

void GameStateRestartMap::Enter(GameManager* game_manager)
{
  city::CityController::GetInstance().Restart();
  city::CityController::GetInstance().Start();
}

void GameStateRestartMap::UpdateEachFrame(GameManager* game_manager, float delta)
{
  // do nothing
  city::CityController::GetInstance().UpdateEachFrame(delta);
}

void GameStateRestartMap::Exit(GameManager* game_manager)
{
  if(game_manager->GetNextMapState() == GameStateMap::Instance())
  {
    city::CityController::GetInstance().SetCitySceneChangeState(city::kCitySceneChangeStateSwitchScene);
  }
  else if (game_manager->GetNextMapState() == GameStateBattle::Instance())
  {
    city::CityController::GetInstance().SetCitySceneChangeState(city::kCitySceneChangeStateBattle);
  }
  {
    city::CityController::GetInstance().SetCitySceneChangeState(city::kCitySceneChangeStateOtherScene);
  }
  city::CityController::GetInstance().End();
}

std::string GameStateRestartMap::GetName()
{
  return kStateNameMap;
}


//***************************************************************************/

/**
 * map state
 */
GameStateMap::GameStateMap()
: come_back_(false)
{

}

GameStateMap::~GameStateMap()
{
}

GameStateMap* GameStateMap::Instance()
{
  static GameStateMap map_state;
  return &map_state;
}

void GameStateMap::Enter(GameManager* game_manager)
{
  city::CityController::GetInstance().Start();
  
}

void GameStateMap::UpdateEachFrame(GameManager* game_manager, float delta)
{
  // do nothing
  city::CityController::GetInstance().UpdateEachFrame(delta);
}

void GameStateMap::Exit(GameManager* game_manager)
{
  if(game_manager->GetNextMapState() == GameStateMap::Instance())
  {
    city::CityController::GetInstance().SetCitySceneChangeState(city::kCitySceneChangeStateSwitchScene);
  }
  else if (game_manager->GetNextMapState() == GameStateBattle::Instance())
  {
    city::CityController::GetInstance().SetCitySceneChangeState(city::kCitySceneChangeStateBattle);
  }
  else
  {
    city::CityController::GetInstance().SetCitySceneChangeState(city::kCitySceneChangeStateOtherScene);
  }
  city::CityController::GetInstance().End();
}

std::string GameStateMap::GetName()
{
  return kStateNameMap;
}

/**
 * battle state
 */
GameStateBattle::GameStateBattle()
{
}

GameStateBattle::~GameStateBattle()
{
}

GameStateBattle* GameStateBattle::Instance()
{
  static GameStateBattle battle_state;
  return &battle_state;
}

void GameStateBattle::Enter(GameManager* game_manager)
{
  battle::BattleController::GetInstance().Start(battle::kBattleType_Main);
}

void GameStateBattle::UpdateEachFrame(GameManager* game_manager, float delta)
{
  // do nothing
}

void GameStateBattle::Exit(GameManager* game_manager)
{
  // do nothing
	uint_16 city_id = DataManager::GetInstance().user_info()->get_current_city_map_id();
	int music_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/city_map/city_map_contants.lua", "GetCityMapBackgroundMuiscById", city_id);
	if (music_id > 0)
	{
		SoundManager::GetInstance().PlayBackgroundMusic(music_id, true);
	}

}

std::string GameStateBattle::GetName()
{
  return kStateNameBattle;
}


///////////////////////////////////////////////////
/*
 * pvp battle
 */
GameStatePvpBattle::GameStatePvpBattle()
{
}
  
GameStatePvpBattle::~GameStatePvpBattle()
{
}
  
GameStatePvpBattle* GameStatePvpBattle::Instance()
{
  static GameStatePvpBattle pvp_battle_state;
  return &pvp_battle_state;
}
  
void GameStatePvpBattle::Enter(GameManager* game_manager)
{
  battle::BattleController::GetInstance().Start(battle::kBattleType_Pvp);
}

void GameStatePvpBattle::UpdateEachFrame(GameManager* game_manager, float delta)
{
  //pvp::PvpController::GetInstance().UpdateEachFrame(delta);
}

void GameStatePvpBattle::Exit(GameManager* game_manager)
{
  //pvp::PvpController::GetInstance().End();
}

std::string GameStatePvpBattle::GetName()
{
  return kStateNamePvp;
}


///////////////////////////////////////////////////
/*
 * GameStateBattleSandBox battle
 */
GameStateBattleSandBox::GameStateBattleSandBox()
{
}
  
GameStateBattleSandBox::~GameStateBattleSandBox()
{
}
  
GameStateBattleSandBox* GameStateBattleSandBox::Instance()
{
  static GameStateBattleSandBox battle_sandbox_state;
  return &battle_sandbox_state;
}
  
void GameStateBattleSandBox::Enter(GameManager* game_manager)
{
  battle::BattleController::GetInstance().Start(battle::kBattleType_SandBox);
}

void GameStateBattleSandBox::UpdateEachFrame(GameManager* game_manager, float delta)
{
  battle::BattleController::GetInstance().UpdateEachFrame(delta);
}

void GameStateBattleSandBox::Exit(GameManager* game_manager)
{
  //pvp::PvpController::GetInstance().End();
}

std::string GameStateBattleSandBox::GetName()
{
  return kStateNameBattleSandBox;
}


GameFriendState::GameFriendState()
{
}

GameFriendState::~GameFriendState()
{
}

GameFriendState* GameFriendState::Instance()
{
  static GameFriendState tavern_state;
  return &tavern_state;
}

void GameFriendState::Enter(GameManager* game_manager)
{
  FriendController::GetInstance().Start();
}

void GameFriendState::UpdateEachFrame(GameManager* game_manager, float delta)
{
  // do nothing
}

void GameFriendState::Exit(GameManager* game_manager)
{
  FriendController::GetInstance().End();
}

std::string GameFriendState::GetName()
{
  return kStateNameFriend;
}
//////////////////////////////////////////////////////////////////////////


GameArenaState::GameArenaState()
{
}

GameArenaState::~GameArenaState()
{
}

GameArenaState* GameArenaState::Instance()
{
  static GameArenaState arena_state;
  return &arena_state;
}

void GameArenaState::Enter(GameManager* game_manager)
{
  ArenaController::GetInstance().Start();
}

void GameArenaState::UpdateEachFrame(GameManager* game_manager, float delta)
{
  // do nothing
}

void GameArenaState::Exit(GameManager* game_manager)
{
  ArenaController::GetInstance().End();
}

std::string GameArenaState::GetName()
{
  return kStateNameArena;
}

/**
 * transition state
 */
GameStateTransition::GameStateTransition()
: next_state_(NULL),
  transition_scene_(NULL)  
{
}

GameStateTransition::~GameStateTransition()
{  
}

GameStateTransition* GameStateTransition::Instance()
{
  static GameStateTransition transition_state;
  return &transition_state;
}

void GameStateTransition::Enter(GameManager* game_manager)
{
  assert(next_state_ != NULL);  
  // switch to transition scene
  transition_scene_ = TransitionScene::create();
  transition_scene_->set_next_state_name(next_state_->GetName());

  if (CCDirector::sharedDirector()->getRunningScene() != NULL) {
    CCDirector::sharedDirector()->replaceScene(transition_scene_);
  } else {
    CCDirector::sharedDirector()->runWithScene(transition_scene_);
  }
}

void GameStateTransition::UpdateEachFrame(GameManager* game_manager, float delta)
{  
  if (transition_scene_->transition_over())
  {
    assert(next_state_ != NULL);
    game_manager->GetStateMachine()->ChangeState(next_state_);
  }
}

void GameStateTransition::Exit(GameManager* game_manager)
{
  next_state_ = NULL;
  transition_scene_ = NULL;  
}

} /* namespace taomee */
