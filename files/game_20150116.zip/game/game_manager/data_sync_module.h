//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: data_sync_module.h
//        Author: leohou
//       Version:
//          Date: Nov 11, 2013
//          Time: 3:53:17 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     3:53:17 AM
//
//////////////////////////////////////////////////////////////

#ifndef DATA_SYNC_MODULE_H_
#define DATA_SYNC_MODULE_H_

#include "network/session/net_session.hpp"
#include "network/proto/bouns_battle_ready_in.h"
#include "network/proto/bouns_battle_ready_out.h"
#include "network/proto/save_team_info_in.h"
#include "network/proto/card_save_team_info_in.h"
#include "network/proto/user_info_in.h"
#include "network/proto/user_info_out.h"
#include "network/proto/user_event_notify_in.h"
#include "network/proto/set_nick_in.h"

namespace taomee {

namespace data {
class UserInfo;
}

namespace net {
class User_info_out;
namespace get_daily_task_cfg_in
{
class Get_daily_task_cfg_in;
}

namespace get_daily_task_cfg_out
{
class Get_daily_task_cfg_out;
}
}
// namespace choose_role_in
// {
// class Choose_role_in;
// }

class DataSyncModule {
public:
  DataSyncModule();
  virtual ~DataSyncModule();

  bool CommitCreateName(int role_id, const std::string& name);

  void UpdateUserDataFromServer();

  void set_local_user_data(data::UserInfo* local_user_data)
  {
    local_user_data_ = local_user_data;
  }

  void CommitBonusMission(int mission_id);
  void CommitTeamInfo(int team_index = 0);

  void CommitUserEventNotify(int key);

private:
  typedef net::NetSession<net::User_info_in, net::User_info_out> UserInfoSession;
	typedef net::NetSession<net::get_daily_task_cfg_in::Get_daily_task_cfg_in,
		net::get_daily_task_cfg_out::Get_daily_task_cfg_out> DailyMissionInfoSession;

	enum FetchState
	{
		kUnkownState,
		kFetchUserInfoOutState,
		kFetchFriendInfoOutState,
		kFetchComplete,
	};

  enum MailOpType
  {
    kMailOpTypeNormal = 1,
    kMailOpTypeSystem = 2,

  };

	void doLoop();
  void fetchServerUserData();
	void onFetchServerUserDataCompleted(int error_code,
			boost::shared_ptr<UserInfoSession> user_info_session);
			
	void fetchFriendInfo();


	void fetchUserDataComplete();

  void updateLocalUserInfo();
  void updateCardData();
  void updateEquipData();
  void updateSkillData();
  void updateMissionData();
  void updateMailData();
  void updateFragmentData();
  void updateSpecialCardData();


  typedef net::set_nick_in::Set_nick_in SetNickIn;
  typedef net::NetSession<SetNickIn, void> SetNickSession;
  void onCommitCreateNameCompleted(int error_code,
    boost::shared_ptr<SetNickSession> set_nick_session);

  typedef net::bouns_battle_ready_in::Bouns_battle_ready_in BonusMissionIn;
  typedef net::bouns_battle_ready_out::Bouns_battle_ready_out BonusMissionOut;
  typedef net::NetSession<BonusMissionIn, BonusMissionOut> BonusMissionSession;
  void onCommitBonusMissionCompleted(int error_code,
                                     boost::shared_ptr<BonusMissionSession> bonus_mission_session);

  typedef net::card_save_team_info_in::Card_save_team_info_in TeamInfoIn;
  typedef net::NetSession<TeamInfoIn, void> TeamInfoSession;
  void onCommitTeamInfoCompleted(int error_code,
                             boost::shared_ptr<TeamInfoSession> team_info_session);

  typedef net::user_event_notify_in::User_event_notify_in UserEventNotifyIn;
  typedef net::NetSession<UserEventNotifyIn, void> UserEventNotifySession;
  void onCommitUserEventNotifyCompleted(int error_code,
                            boost::shared_ptr<UserEventNotifySession> user_event_notify_session);
private:
  data::UserInfo* local_user_data_;
  net::User_info_out* server_user_data_;
  //back utf8 nick name before send request
  //nick name will be converted to unicode when sending request
  static std::string  backup_nick_name_;

	boost::signal <void ()> fetch_complete_signal_;
	FetchState next_fetch_state_;
};

} /* namespace taomee */
#endif /* DATA_SYNC_MODULE_H_ */
