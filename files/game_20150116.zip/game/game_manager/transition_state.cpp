//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: transition_state.cpp
//        Author: leohou
//       Version:
//          Date: Nov 27, 2013
//          Time: 4:59:19 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     4:59:19 AM
//
//////////////////////////////////////////////////////////////

#include "game/game_manager/transition_state.h"

#include "engine/base/state_machine/state_machine.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/transition_scene.h"

namespace taomee {

// purge cache state
TransitionStatePurgeCache::TransitionStatePurgeCache()
{

}

TransitionStatePurgeCache::~TransitionStatePurgeCache()
{

}

TransitionStatePurgeCache* TransitionStatePurgeCache::Instance()
{
  static TransitionStatePurgeCache purge_cache_state;
  return &purge_cache_state;
}

void TransitionStatePurgeCache::Enter(TransitionScene* transition_scene)
{
  // do nothing
}

void TransitionStatePurgeCache::UpdateEachFrame(TransitionScene* transition_scene, float delta)
{
  transition_scene->PurgeCacheData();
  transition_scene->GetStateMachine()->ChangeState(TransitionStateGetResource::Instance());
}

void TransitionStatePurgeCache::Exit(TransitionScene* transition_scene)
{
  // do nothing
}


// get resource list
TransitionStateGetResource::TransitionStateGetResource()
{

}

TransitionStateGetResource::~TransitionStateGetResource()
{

}

TransitionStateGetResource* TransitionStateGetResource::Instance()
{
  static TransitionStateGetResource get_resource_state;
  return &get_resource_state;
}

void TransitionStateGetResource::Enter(TransitionScene* transition_scene)
{
  //LuaTinkerManager::GetInstance()
  //  .CallLuaFunc<int>("script/resource/resource_loader.lua", "get_resource_list", transition_scene->next_state_name().c_str());
}

void TransitionStateGetResource::UpdateEachFrame(TransitionScene* transition_scene, float delta)
{
  transition_scene->GetStateMachine()->ChangeState(TransitionStateLoadResource::Instance());
}

void TransitionStateGetResource::Exit(TransitionScene* transition_scene)
{
  // do nothing
}


// load resource state
TransitionStateLoadResource::TransitionStateLoadResource()
{

}

TransitionStateLoadResource::~TransitionStateLoadResource()
{

}

TransitionStateLoadResource* TransitionStateLoadResource::Instance()
{
  static TransitionStateLoadResource load_resource_state;
  return &load_resource_state;
}

void TransitionStateLoadResource::Enter(TransitionScene* transition_scene)
{
  // do nothing
}

void TransitionStateLoadResource::UpdateEachFrame(TransitionScene* transition_scene, float delta)
{
  //if (LuaTinkerManager::GetInstance()
  //  .CallLuaFunc<bool>("script/resource/resource_loader.lua", "load_resource"))
  //{
    transition_scene->OnLoadResourceCompleted();
  //}
}

void TransitionStateLoadResource::Exit(TransitionScene* transition_scene)
{
  // do nothing
}


} /* namespace taomee */
