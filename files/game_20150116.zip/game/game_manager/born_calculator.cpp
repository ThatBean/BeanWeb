//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  born_calculator.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-28
//          Time:  21:27
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-28        1         create
//////////////////////////////////////////////////////////////

#include "game/game_manager/born_calculator.h"
#include "engine/script/lua_tinker_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/core_value_module.h"

namespace taomee {

BornCalculator::BornCalculator(DataManager* dataMana)
  : manager(dataMana)
{
  
}

BornCalculator::~BornCalculator()
{
  
}

uint_32 BornCalculator::
  HPCalculatorForMonsterByCardIdAndLevel(uint_32 cardId, uint_8 level,float des_hp_mult)
{
  CharacterData* characData = manager->GetCharacterDataTable()->GetCharacter(cardId);
  uint_32 hp = characData->GetIniHp() + des_hp_mult*level;
  return hp;
}

uint_32 BornCalculator::PhyAttackCalculatorForMonsterByCardIdAndLevel(uint_32 cardId, uint_8 level,float des_att_mult)
{
  CharacterData* characData = manager->GetCharacterDataTable()->GetCharacter(cardId);
  uint_32 ap = characData->GetIniPhysicsAttack() + des_att_mult*level;
  return ap;
}

uint_32 BornCalculator::MagAttackCalculatorForMonsterByCardIdAndLevel(uint_32 cardId, uint_8 level,float des_att_mult)
{
	CharacterData* characData = manager->GetCharacterDataTable()->GetCharacter(cardId);
	uint_32 mag_attack = characData->GetIniMagicAttack() + des_att_mult*level;
	return mag_attack;
}

LUA_INTERFACE float BornCalculator::PropertyCalculatorForCharacterByCardIdAndType( uint_32 card_id, uint_8 property, uint_16 level /*= 1*/ )
{
  float value = 0;
  value += manager->GetCharacterDataTable()->GetCharacter(card_id)->getInitPropertyByType(property);
  value += (level-1)*manager->GetCharacterDataTable()->GetCharacter(card_id)->getAddPropertyByType(property);
  return value;
}

LUA_INTERFACE float BornCalculator::PropertyCalculatorForCharacterByInfoAndType( data::CharacterInfo* characInfo, uint_8 property )
{
  if ( NULL == characInfo )
    return 0;
  CharacterData* pData =  DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(characInfo->card_id());
  if ( NULL == pData )
    return 0;
  float value = 0;
  //װ������
  for (int i = 0; i < data::kCharacterEquipmentMaxCount; ++i)
  {
    /*uint_32 equipmentSid = characInfo->GetCharacterEquipmentSidByPart(i);
    if (equipmentSid != 0)
    {
    data::EquipInfo* eInfo = manager->user_info()->GetEquipInfoBySid(equipmentSid);      
    value += manager->GetEquipDataTable()->GetEquip(eInfo->getID())->getPropertyByType(property);
    }*/
  }
  //֮ǰ����װ������
  if (characInfo->getEvolveStep() > 0)
  {
    for (int i = characInfo->getEvolveStep(); i > 0; --i)
    {
      std::list<int> pre_equip_list = manager->getEvolveDataTable()->GetEvolve(characInfo->card_id()*100+i)->GetEquipIDs();
      for (std::list<int>::iterator itor = pre_equip_list.begin(); itor != pre_equip_list.end(); ++itor)
      {
        value += manager->GetEquipDataTable()->GetEquip(*itor)->getPropertyByType(property);
      }
    }
  }
  //���ײ�������
  if (characInfo->getEvolveStep() > 0 && property <= kAttrTypeMDef)
  {
    value += manager->getEvolveDataTable()->GetEvolve(characInfo->card_id()*100+characInfo->getEvolveStep())->GetPropAdd().at(property);
  }
  //��������
  value += manager->GetCharacterDataTable()->GetCharacter(characInfo->card_id())->getInitPropertyByType(property);
  value += (characInfo->level()-1)*manager->GetCharacterDataTable()->GetCharacter(characInfo->card_id())->getAddPropertyByType(property);
  //��������
  int current_star = characInfo->up_star()+pData->GetRarity();
  if (current_star > 0 && current_star <= 5 && property <= kAttrTypeMDef)
  {
    value += current_star*manager->GetUpRarityDataTable()->GetNewuprarity(characInfo->card_id()*10 + current_star)->GetPropAdd().at(property);
  }
  //ͻ������
  if (characInfo->break_times() > 0)
  {

  }

  return value;
}

// level xp
LUA_INTERFACE uint_32 BornCalculator::LevelUpXPCalculatorForCharacterByCardIdAndNextLevel(uint_32 cardId, uint_8 level)
{
  assert(level>=1);
  uint_32 xp = 0;
  xp = CoreValueModule::GetCardXPRequiredForLevel(cardId, level + 1);
  return xp;
}

LUA_INTERFACE uint_32 BornCalculator::TotalLevelUpXPCalculatorForCharacterByCardIdAndCurrentLevel(uint_32 cardId,
  uint_8 currentLevel)
{
  if (currentLevel==1)
  {
    return 0;
  }
  uint_32 xp = 0;
  uint_8 lIdx = 1;
  while (lIdx < currentLevel)
  {
    xp += CoreValueModule::GetCardXPRequiredForLevel(cardId, lIdx);
  } 

  return xp;
}

} // namespace taome