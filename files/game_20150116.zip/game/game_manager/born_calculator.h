//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  born_calculator.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-10-28
//          Time:  21:27
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-10-28        1         create
//////////////////////////////////////////////////////////////

#ifndef __ChainChronicle__born_calculator__
#define __ChainChronicle__born_calculator__

#include "engine/base/basictypes.h"

class DataManager;

namespace taomee {
  
namespace data
{
  class CharacterInfo;
  class EquipInfo;
  class EquipSuitResult;
}
  
class BornCalculator
{
public:
  BornCalculator(DataManager* dataMana);
  ~BornCalculator();
  
public:
  // health points
  uint_32 HPCalculatorForMonsterByCardIdAndLevel(uint_32 cardId, uint_8 level,float des_hp_mult);

  // phy attack value
  uint_32 PhyAttackCalculatorForMonsterByCardIdAndLevel(uint_32 cardId, uint_8 level,float des_att_mult);

  // mag attack value
  uint_32 MagAttackCalculatorForMonsterByCardIdAndLevel(uint_32 cardId, uint_8 level,float des_att_mult);

  //���㿨�Ƶ�����ֵ
  LUA_INTERFACE float PropertyCalculatorForCharacterByCardIdAndType(uint_32 cardId, uint_8 property, uint_16 level = 1);
  LUA_INTERFACE float PropertyCalculatorForCharacterByInfoAndType(data::CharacterInfo* pInfo, uint_8 property);

  // level up xp
  LUA_INTERFACE uint_32 LevelUpXPCalculatorForCharacterByCardIdAndNextLevel(uint_32 cardId, uint_8 level);
  LUA_INTERFACE uint_32 TotalLevelUpXPCalculatorForCharacterByCardIdAndCurrentLevel(uint_32 cardId, uint_8 level);
private:
  DataManager* manager;
};

} // namespace taomee

#endif /* defined(__ChainChronicle__born_calculator__) */
