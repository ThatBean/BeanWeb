//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: game_logger_manager.h
//        Author: coldouyang
//          Date: 2014/9/2 18:35
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/9/2      add
//////////////////////////////////////////////////////////////

#ifndef GAME_LOGGER_MANAGER_H
#define GAME_LOGGER_MANAGER_H

#include "cocos2d.h"

#include "engine/platform/SingleInstance.h"

class GameLoggerManager : public SingleInstanceObj
{

public:
  
  static GameLoggerManager* GetInstance();

  virtual ~GameLoggerManager();

public:

  void          start();//����
  void          reset();
  
  void          setGameId(int id) { game_id_ = id; }
  void          setZoneId(int id) { zone_id_ = id; }
  void          setServerId(int id) { svr_id_ = id; }
  void          setSiteId(int id) { site_id_ = id; }

  void          setAccountId(const std::string& id) { acct_id_ = id; }
  void          setPlayerId(const std::string& id) { player_id_ = id; }

  void          sendSession(const char* stid_name, const char* sstid_name, const char* item_name = "");

public:

  /************************************************************************/
  /*----------����ͳ��------------------------
  --[[
  Log_Stats.card = { title = "card" }
  Log_Stats.card_of_user = { title = "���ӵ��" }
  Log_Stats.card_battle = { title = "ս������" }
  Log_Stats.card_break = { title = "break" }
  Log_Stats.card_advanced = { title = "����" }
  --]]
  /************************************************************************/
  /*
  void        log_card_of_user(const std::string& card_id, const std::string& get_level);
  void        log_card_battle(const std::string& card_id, bool is_pvp);
  void        log_card_break(const std::string& card_id, const std::string& break_time);
  void        log_card_advanced(const std::string& card_id);
  */

  /************************************************************************/
  /*--------------����ͳ��---------
  Log_Stats.mission = { title = "����ͳ��" }
  Log_Stats.mission_newbee_rate = { title = "�������������" }
  Log_Stats.mission_main_rate = { title = "��������ÿ�������" }
  Log_Stats.mission_daily_rate = { title = "�ճ�����ÿ�������" }
  /************************************************************************/
  void        log_mission_newbee_rate(int guide_id);
  void        log_mission_main_rate(int mission_id);
  void        log_mission_daily_rate(int daily_mission_id);
  /************************************************************************/
  /* ս��ͳ��
  Log_Stats.battle = { title = "ս��ͳ��" }
  Log_Stats.battle_checkpoint_pass = { title = "����ͨ�ش���" }
  Log_Stats.battle_checkpoint_faile = { title = "����ս�ܴ���" }
  Log_Stats.battle_pvp_person = { title = "������ս������" }
  /************************************************************************/
  void        log_battle_checkpoint_pass(int checkpoint_id);
  void        log_battle_checkpoint_faile(int checkpoint_id);
  void        log_battle_pvp_person();

  /************************************************************************/
  /*-------------����ͳ��-----------
  Log_Stats.boost = { title = "����ͳ��" }
  Log_Stats.boost_buy = { title = "���߹������" }
  Log_Stats.boost_from_box = { title = "ͨ�������ȡ����" }
  /************************************************************************/
  void        log_boost_buy(int item_id);
  void        log_boost_from_box(int item_id);//TODO
  
  /************************************************************************/
  /*-------------VIPͳ��--------------
  Log_Stats.vip = { title = "VIP" }
  Log_Stats.vip_purchase = { title = "��������" }
  Log_Stats.vip_none_player = { title = "��VIP�û�" }
  /************************************************************************/
  void        log_vip_purchase();//TODO
  void        log_vip_none_player();//TODO

  /************************************************************************/
  /*-----------���-------------------
  Log_Stats.gift = { title = "���" }
  Log_Stats.gift_get = { title = "�����ȡ����" }
  Log_Stats.gift_none_get = { title = "δ��ȡ������" }
  Log_Stats.gift_get_none_use = { title = "��ȡδ����ʹ�����" }
  /************************************************************************/
  void        log_gift_get();
  void        log_gift_none_get();//HOW?
  void        log_gift_get_none_use();

  /************************************************************************/
  /*-----------�--------------------
  Log_Stats.activity = { title = "�" }
  Log_Stats.activity_person = { title = "���������" }
  Log_Stats.activity_consume_diamond = { title = "�����ħ����" }
  Log_Stats.activity_consume_gold = { title = "����Ľ��" }
  Log_Stats.activity_consume_ap = { title = "���������" }
  /************************************************************************/
  void        log_activity_person();
  void        log_activity_consume_diamond();
  void        log_activity_consume_gold();
  void        log_activity_consume_ap();

private:

  GameLoggerManager();

  const char*   getStatTitle(const char* key);
  const char*   getItemFormat(const char* key);
  //StatLogger*   stat_logger_;

private:

  int           game_id_;
  int32_t       zone_id_;
  int32_t       svr_id_;
  int32_t       site_id_;
  int           isgame_;

  std::string   acct_id_;
  std::string   player_id_;

  bool          has_init_;
  std::string   base_url_;
};

#endif