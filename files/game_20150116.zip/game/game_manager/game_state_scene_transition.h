//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: game_state_scene_transition.h
//        Author: Sachin
//          Date: 2013/12/30 12:15
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     Sachin    2013/12/30      add
//////////////////////////////////////////////////////////////

#ifndef GAME_STATE_SCENE_TRANSITION_H
#define GAME_STATE_SCENE_TRANSITION_H

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/state_machine/state.h"
#include "engine/base/load_helper.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/transition_scene.h"

#include "game/battle/battle_controller.h"
#include "game/scene/friend_scene/friend_controller.h"

using namespace cocos2d;
namespace taomee
{
// game state transition
// T: Next SceneController  impl "T::Prepare" method
template <class T>
class GameStateSceneTransition : public State<GameManager>
{
public:
  GameStateSceneTransition():next_state_(NULL),
      transition_scene_(NULL),
      load_helper_(NULL),
      next_scene_controller_(NULL)
  {

  }
  virtual ~GameStateSceneTransition()
  {
    SAFE_DEL(load_helper_);

  }

  static GameStateSceneTransition* Instance()
  {
    static GameStateSceneTransition transition_state;
    return &transition_state;
  }

  virtual void Enter(GameManager* game_manager)
  {
    assert(next_state_ != NULL);
    assert(load_helper_ == NULL);
    load_helper_ = new LoadHelper();
    next_scene_controller_->Prepare(load_helper_);
    // switch to transition scene
    transition_scene_ = TransitionScene::create();
    transition_scene_->set_next_state_name(next_state_->GetName());

    if (CCDirector::sharedDirector()->getRunningScene() != NULL) 
    {
      CCDirector::sharedDirector()->replaceScene(transition_scene_);
    } 
    else 
    {
      CCDirector::sharedDirector()->runWithScene(transition_scene_);
    }
  }

  virtual void UpdateEachFrame(GameManager* game_manager, float delta)
  {
    load_helper_->UpdateEachFrame(delta);
    if (transition_scene_->transition_over() && load_helper_->IsComplete())
    {
      assert(next_state_ != NULL);
      game_manager->GetStateMachine()->ChangeState(next_state_);
    }
  }

  virtual void Exit(GameManager* game_manager)
  {
    next_state_ = NULL;
    transition_scene_ = NULL;
    SAFE_DEL(load_helper_);
  }

public:
  void set_next_state(State<GameManager>* next_state) { next_state_ = next_state; }
  void set_next_scene_controller(T next_scene_controller)
  {
    next_scene_controller_ = next_scene_controller;
  }
private:  
  DISALLOW_COPY_AND_ASSIGN(GameStateSceneTransition);

private:
  State<GameManager>* next_state_;

  TransitionScene* transition_scene_;
  T next_scene_controller_;
  LoadHelper* load_helper_;
};
} // namespace taomee
#endif //GAME_STATE_SCENE_TRANSITION_H