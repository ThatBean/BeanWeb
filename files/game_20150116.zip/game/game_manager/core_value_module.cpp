//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: core_value_module.cpp
//        Author: coldouyang
//          Date: 2014/7/11 15:16
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/7/11      add
//////////////////////////////////////////////////////////////
//CoreValueModule
#include "game/game_manager/core_value_module.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/checkpointdaily_data_table.h"
#include "game/data_table/checkpointcha_data_table.h"
#include "game/data_table/elite_data_table.h"
#include <stdio.h>
#include <float.h>
#include <math.h>

int CoreValueModule::GetDailyCheckpointUserRewardEXP(int checkpointID, bool isFirst)
{
  CheckpointDailyData* data = DataManager::GetInstance().GetCheckpointDailyDataTable()->GetCheckpointdaily(checkpointID);
  assert(data);
  int exp = 0;
  exp += data->GetReceivelexp();
  return exp;
}
//��ɫrank����
/************************************************************************/
/* ͨ�ط�Boss�ؿ����rank����=C+(int(lv/5)+1)*50 
lvΪ�ؿ����ŵȼ���
C��ͨģʽ=40������ģʽ=90������ģʽ=140��
Boss�ؿ�=��ͨģʽ����*2��
����rank�ȼ�ͨ��������ã� */
/************************************************************************/
int CoreValueModule::GetMainCheckpointUserRewardEXP(int checkpointID, bool isFirst)
{
  if ( (checkpointID >= 1 && checkpointID <= 1999) || ( checkpointID >= 10000 && checkpointID <= 29999 ) )
  {
    CheckpointMainData* data = DataManager::GetInstance().GetCheckpointMainDataTable()->GetCheckpointmain(checkpointID);
    if (data != NULL)
    {
      int exp = 0;
      if (isFirst)
      {
        exp += data->GetFirst_rank_exp();
      }
      exp += data->GetReceivelexp();
      return exp;
    }
  }
  else if (checkpointID >= 2000 && checkpointID <= 2999)
  {
    return DataManager::GetInstance().GetCheckpointChaDataTable()->GetCheckpointcha(checkpointID)->GetReceivelexp();
  }
  else if ( checkpointID >= 3000 && checkpointID <= 3999 )
  {
    return GetDailyCheckpointUserRewardEXP(checkpointID, isFirst);
  }
  else if (checkpointID >= 90000)
  {
    return DataManager::GetInstance().GetEliteDataTable()->GetEliteByCheckPointID(checkpointID)->GetRankexp();
  }
  return 0;
}

int CoreValueModule::GetDailyCheckpointCardRewardXP(int checkpointID)
{
  CheckpointDailyData* data = DataManager::GetInstance().GetCheckpointDailyDataTable()->GetCheckpointdaily(checkpointID);
  assert(data);
  return data->GetCard_exp();
}
/************************************************************************/
/*ͨ�ػ�ȡ���ƾ���=int(lv/3)*5+��ֵ�������lvΪ��Ӧ�Ĺؿ��ȼ��������ѶȲ�ͬ����ֵ=30��40��50��                                                                     */
/************************************************************************/
int CoreValueModule::GetMainCheckpointCardRewardXP(int checkpointID)
{
  if ( (checkpointID >= 1 && checkpointID <= 1999) || ( checkpointID >= 10000 && checkpointID <= 29999 ) )
  {
    CheckpointMainData* data = DataManager::GetInstance().GetCheckpointMainDataTable()->GetCheckpointmain(checkpointID);
    if (data != NULL)
    {
      return data->GetCard_exp();
    }
  }
  else if (checkpointID >= 2000 && checkpointID <= 2999)
  {
    return DataManager::GetInstance().GetCheckpointChaDataTable()->GetCheckpointcha(checkpointID)->GetCard_exp();
  }
  else if ( checkpointID >= 3000 && checkpointID <= 3999 )
  {
    return GetDailyCheckpointCardRewardXP(checkpointID);
  }
  else if (checkpointID >= 90000)
  {
    return DataManager::GetInstance().GetEliteDataTable()->GetEliteByCheckPointID(checkpointID)->GetCardexp();
  }
  return 0;
}

/************************************************************************/
/*���ƾ���
/*  �������������� =int(���Ƶȼ�*2+(���Ƶȼ�-1)^3*0.1)*10+30(������)
/************************************************************************/
int CoreValueModule::GetCardXPRequiredForLevel(int card_id, int lv)
{
  CharacterData* data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
  assert(data);
  float lv_1 = lv - 1;
  return int(lv * 2 + pow(lv_1, 3) * 0.1) * 10 + 30;
}

/************************************************************************/
/*װ��ǿ������ = װ��ǿ��������ֵ*(int(lv/10)^2*2+lv+1)*5(������)
/************************************************************************/
int CoreValueModule::GetEquipStrengthCost(int equip_id, int lv)
{
  EquipData* data = DataManager::GetInstance().GetEquipDataTable()->GetEquip(equip_id);
  assert(data);
  int lv_tag = int(lv / 10);
  float strenghValue = 0;
  //if (data->GetEquipFlag1() == data::kEquipAttrTypePhyAtk ||
	 // data->GetEquipFlag1() == data::kEquipAttrTypeMagAtk)//attack
  //{
  //  strenghValue += data->GetFlag1GrowthValue()*3;
  //}
  //else
  //{
  //  strenghValue += data->GetFlag1GrowthValue();
  //}

  //if (data->GetEquipFlag2() == data::kEquipAttrTypePhyAtk ||
	 // data->GetEquipFlag2() == data::kEquipAttrTypeMagAtk)//attack
  //{
  //  strenghValue += data->GetFlag2GrowthValue()*3;
  //}
  //else
  //{
  //  strenghValue += data->GetFlag2GrowthValue();
  //}

  return strenghValue*(pow((float)lv_tag, 2) * 2 + lv + 1) * 5;
}

/************************************************************************/
/*װ��������� = װ��ǿ��������ֵ*(int (lv/10)*( int (lv/10)+1)*(2* int (lv/10)+1) *4+lv*(lv+3)/2) (������)
/************************************************************************/
int CoreValueModule::GetEquipmentSell(int equip_id, int lv)
{
  EquipData* data = DataManager::GetInstance().GetEquipDataTable()->GetEquip(equip_id);
  assert(data);
  float strenghValue = 0;
  //int tag = data->GetEquipFlag1();
  //if (tag == data::kEquipAttrTypeHp)//HP
  //{
  //  strenghValue += data->GetFlag1GrowthValue();
  //}
  //else
  //{
  //  strenghValue += data->GetFlag1GrowthValue() * 3;
  //}

  //tag = data->GetEquipFlag2();
  //if (tag == data::kEquipAttrTypeHp)//HP
  //{
  //  strenghValue += data->GetFlag2GrowthValue();
  //}
  //else
  //{
  //  strenghValue += data->GetFlag2GrowthValue() * 3;
  //}
  int sellMoney = strenghValue * (int (lv / 10) * (int(lv / 10) + 1) * (2 * int(lv / 10) + 1) * 4 + lv * (lv + 3) / 2);
  return sellMoney;
}


/************************************************************************/
/*���ƺϳ�ʱ���㾭�� =baseExp*�����Ƶȼ�*0.25+0.75��(������)��
/*  baseExp=pow(2�������Ǽ�)*100(������)
/************************************************************************/
int CoreValueModule::GetCardComposeProvideXP(int card_sid)
{
  taomee::data::CharacterInfo* info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(card_sid);
  CharacterData* data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(info->card_id());
  assert(data);
  
  int lv = info->level();  
  int rarity = info->getRarity();
  float baseExp = pow(2.0, rarity) * 100;
  int exp = baseExp * (lv * 0.25 + 0.75);
  return exp;
}

/************************************************************************/
/*���ƻ�ԭ���ȼ��ۺϽ��=(���ƺϳɻ��㾭��-baseExp)*2(������)
/*  baseExp=pow(2�������Ǽ�)*100(������)
/************************************************************************/
int CoreValueModule::GetCardRevertMoney(int card_sid)
{
  int exp = GetCardComposeProvideXP(card_sid);
  taomee::data::CharacterInfo* info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(card_sid);
  int money = 0;
  int lv = info->level();  
  int rarity = info->getRarity();
  float baseExp = pow(2.0, rarity) * 100;

  money = (exp-baseExp)*2;
  return money;
}

/************************************************************************/
/*�����������ȼ��ۺϽ��=���ƺϳɻ��㾭��*2(������)
/************************************************************************/
int CoreValueModule::GetCardDecomposeMoney(int card_sid)
{
  int exp = GetCardComposeProvideXP(card_sid);

  return exp*2;
}