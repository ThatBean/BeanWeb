//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: transition_scene.h
//        Author: leohou
//       Version:
//          Date: Nov 25, 2013
//          Time: 12:42:23 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     12:42:23 AM
//
//////////////////////////////////////////////////////////////

#ifndef TRANSITION_SCENE_H_
#define TRANSITION_SCENE_H_

#include "engine/base/cocos2d_wrapper.h"

namespace taomee {

template <typename Entity>
class StateMachine;

class TransitionScene : public cocos2d::CCScene {
public:
  
  TransitionScene();
  virtual ~TransitionScene();

  CREATE_FUNC(TransitionScene);
  virtual bool init();

  virtual void update(float delta_time);

  StateMachine<TransitionScene>* GetStateMachine()
  {
    return transition_state_machine_;
  }

public:
  bool transition_over() const { return transition_over_; }

  std::string next_state_name() const { return next_state_name_; }
  void set_next_state_name(const std::string& next_state_name)
  {
    next_state_name_ = next_state_name;
  }


  void PurgeCacheData();
  void OnLoadResourceCompleted();


private:
  StateMachine<TransitionScene>* transition_state_machine_;

  std::string next_state_name_;
  bool transition_over_;
};

} /* namespace taomee */
#endif /* TRANSITION_SCENE_H_ */
