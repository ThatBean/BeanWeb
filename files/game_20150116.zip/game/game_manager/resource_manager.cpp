//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: resource_manager.cpp
//        Author: peteryu
//       Version:
//          Date: Dec 23, 2013
//          Time: 4:59:19 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      peteryu     4:59:19 AM
//
//////////////////////////////////////////////////////////////
#include "game/game_manager/resource_manager.h"

#include "game/game_manager/data_manager.h"
#include "engine/animation/animation_constant.h"
#include "engine/base/cocos2d_wrapper.h"

using namespace cocos2d;
using namespace cocos2d::extension;

namespace taomee {

ResourceManager::ResourceManager()
{

}

ResourceManager::~ResourceManager()
{

}

void ResourceManager::LoadAnimationByCardId(int card_id)
{
  string name = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id)
    ->GetName();

  std::string skeleton_config = kDefaultSkeletonFilePath + name + ".xml";
  std::string skeleton_plist = kDefaultSkeletonFilePath + name + ".plist";
  std::string skeleton_texture = kDefaultSkeletonFilePath + name + ".pvr.ccz";

  CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(),
    skeleton_plist.c_str(),
    skeleton_config.c_str());
}

void ResourceManager::LoadAnimationPngByCardId( int card_id )
{
  string name = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id)
    ->GetName();

  std::string skeleton_texture = kDefaultSkeletonFilePath + name + ".pvr.ccz";
  CCTextureCache::sharedTextureCache()->addImage(skeleton_texture.c_str());
}



} /* namespace taomee */
