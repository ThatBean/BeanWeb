//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: resource_manager.h
//        Author: peteryu
//       Version:
//          Date: Dec 23, 2013
//          Time: 4:59:19 AM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      peteryu     4:59:19 AM
//
//////////////////////////////////////////////////////////////

#ifndef RESOURCE_MANAGER_H_
#define RESOURCE_MANAGER_H_

#include "engine/platform/SingleInstance.h"

namespace taomee {

class ResourceManager : public SingleInstanceObj
{
public:
  ~ResourceManager();
  ResourceManager();

  static ResourceManager& GetInstance()
  {
    static ResourceManager* X = NULL;
    if (!X)
    {
      X = new ResourceManager();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }

  void LoadAnimationByCardId(int card_id);
  void LoadAnimationPngByCardId(int card_id);

private:
  
};

} /* namespace taomee */
#endif /* TRANSITION_STATE_H_ */
