//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: game_logger_manager.cpp
//        Author: coldouyang
//          Date: 2014/9/2 18:34
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/9/2      add
//////////////////////////////////////////////////////////////
#include "game/game_manager/game_logger_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/platform/platform_control.h"
#include "network/session/net_get_session_for_lua.h"
#include "network/net_constant.h"
#include "network/net_util/util.h"
#include "network/net_manager.h"

GameLoggerManager::GameLoggerManager()
{

}

GameLoggerManager::~GameLoggerManager()
{

}

GameLoggerManager* GameLoggerManager::GetInstance()
{
  static GameLoggerManager* M_ = NULL;
  if (M_ == NULL)
  {
    M_ = new GameLoggerManager();
    M_->reset();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&M_);
  }
  return M_;
}

void GameLoggerManager::start()
{
  game_id_ = 608;
  PlatformControl::GetPlatformControl()->SetConsoleWarrningColor(true);
  cocos2d::CCLog("***** Log Module Start *****");
  cocos2d::CCLog("game_id = %d", game_id_);
  cocos2d::CCLog("zone_id = %d", zone_id_);
  cocos2d::CCLog("server_id = %d", svr_id_);
  cocos2d::CCLog("site_id = %d", site_id_);
  
  cocos2d::CCLog("player_id = %s", player_id_.c_str());
  cocos2d::CCLog("account_id = %s", acct_id_.c_str());

  std::string url = taomee::net::NetGetSessionForLua::getStatLogUrl();
  char msg[512] = {'\0'};
  sprintf(msg, "%sgameid=%d&uid=%s", url.c_str(), game_id_,acct_id_.c_str());
  base_url_ = msg;
  cocos2d::CCLog("!!! BaseUrl=%s", base_url_.c_str());
  PlatformControl::GetPlatformControl()->SetConsoleWarrningColor(false);
  has_init_ = true;
}

void GameLoggerManager::reset()
{
  has_init_ = false;
  game_id_ = -1;
  zone_id_ = -1;
  svr_id_ = -1;
  site_id_ = -1;
  isgame_ = false;

  acct_id_.clear();
  player_id_.clear();
  base_url_.clear();
}

const char* GameLoggerManager::getStatTitle(const char* key)
{
    return LuaTinkerManager::GetInstance().CallLuaFunc<char*>("script/logger/stat_config.lua", "getStatTitle", key);
}

const char* GameLoggerManager::getItemFormat(const char* key)
{
  return LuaTinkerManager::GetInstance().CallLuaFunc<char*>("script/logger/stat_config.lua", "getItemFormat", key);
}

void GameLoggerManager::sendSession(const char* stid_name, const char* sstid_name, const char* item_name)
{
  PlatformControl::GetPlatformControl()->SetConsoleWarrningColor(true);
  //cocos2d::CCLog("!!!StatLog: statname=%s,sub_stat_name=%s,acct_id=%s,player_id=%s", stat_name.c_str(), sub_stat_name.c_str(), acct_id.c_str(), player_id.c_str());
  taomee::net::NetGetSessionForLua session;
  char msg[512] = {'\0'};

  int stid_len = strlen(stid_name);
  int sstid_len = strlen(sstid_name);
  int item_len = strlen(item_name);
  if (item_len > 0)
  {
    sprintf(msg, "%s&stid=%s&sstid=%s&item=%s&stidlen=%d&sstidlen=%d&itemlen=%d", base_url_.c_str(), stid_name, sstid_name, item_name, stid_len, sstid_len, item_len );
  }
  else
  {
    sprintf(msg, "%s&stid=%s&sstid=%s&stidlen=%d&sstidlen=%d", base_url_.c_str(), stid_name, sstid_name, stid_len, sstid_len );
  } 
  cocos2d::CCLog("!!! SendLogUrl[%s]", msg);
  session.setUrl(msg);
  session.SetIsSpecDataForLog(true);
  session.setForceWaitingLevel(1);
  session.setForceSendUntilSuccessFlag(false);
  taomee::net::NetManager::GetInstance().SendGetSession(&session);
  PlatformControl::GetPlatformControl()->SetConsoleWarrningColor(false);
}

//////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////// ����ͳ�� //////////////////////////////////////////////////////
void  GameLoggerManager::log_mission_newbee_rate(int guide_id)
{

  const char* stat_name = getStatTitle("mission");
  const char* sub_stat_name = getStatTitle("mission_newbee_rate");
  const char* item_format = getItemFormat("mission_newbee_rate");
  char temp[256];
  sprintf(temp, item_format, guide_id);
  sendSession(stat_name, sub_stat_name, temp);
}

void  GameLoggerManager::log_mission_main_rate(int mission_id)
{
  const char* stat_name = getStatTitle("mission");
  const char* sub_stat_name = getStatTitle("mission_main_rate");
  const char* item_format = getItemFormat("mission_main_rate");
  char temp[256];
  sprintf(temp, item_format, mission_id);
  sendSession(stat_name, sub_stat_name, temp);
}

void  GameLoggerManager::log_mission_daily_rate(int daily_mission_id)
{
  const char* stat_name = getStatTitle("mission");
  const char* sub_stat_name = getStatTitle("mission_daily_rate");
  const char* item_format = getItemFormat("mission_daily_rate");
  char temp[256];
  sprintf(temp, item_format, daily_mission_id);
  sendSession(stat_name, sub_stat_name, temp);
}

////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////// ս��ͳ�� /////////////////////////////////////////////////////
void        GameLoggerManager::log_battle_checkpoint_pass(int checkpoint_id)
{
  const char* stat_name = getStatTitle("battle");
  const char* sub_stat_name = getStatTitle("battle_checkpoint_pass");
  const char* item_format = getItemFormat("battle_checkpoint_pass");
  char temp[256];
  sprintf(temp, item_format, checkpoint_id);
  sendSession(stat_name, sub_stat_name, temp);
}

void        GameLoggerManager::log_battle_checkpoint_faile(int checkpoint_id)
{
  const char* stat_name = getStatTitle("battle");
  const char* sub_stat_name = getStatTitle("battle_checkpoint_faile");
  const char* item_format = getItemFormat("battle_checkpoint_faile");
  char temp[256];
  sprintf(temp, item_format, checkpoint_id);
  sendSession(stat_name, sub_stat_name, temp);
}

void        GameLoggerManager::log_battle_pvp_person()
{
  const char* stat_name = getStatTitle("battle");
  const char* sub_stat_name = getStatTitle("battle_pvp_person");
  sendSession(stat_name, sub_stat_name);
}

////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////// ����ͳ�� /////////////////////////////////////////////////////
void        GameLoggerManager::log_boost_buy(int item_id)
{
  const char* stat_name = getStatTitle("boost");
  const char* sub_stat_name = getStatTitle("boost_buy");
  const char* item_format = getItemFormat("boost_buy");
  char temp[256];
  sprintf(temp, item_format, item_id);
  sendSession(stat_name, sub_stat_name, temp);
}

void        GameLoggerManager::log_boost_from_box(int item_id)
{
  const char* stat_name = getStatTitle("boost");
  const char* sub_stat_name = getStatTitle("boost_from_box");
  const char* item_format = getItemFormat("boost_from_box");
  char temp[256];
  sprintf(temp, item_format, item_id);
  sendSession(stat_name, sub_stat_name, temp);
}

////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////// VIPͳ�� /////////////////////////////////////////////////////
void        GameLoggerManager::log_vip_purchase()
{
  const char* stat_name = getStatTitle("vip");
  const char* sub_stat_name = getStatTitle("vip_purchase");
  sendSession(stat_name, sub_stat_name);
}

void        GameLoggerManager::log_vip_none_player()
{
  const char* stat_name = getStatTitle("vip");
  const char* sub_stat_name = getStatTitle("vip_none_player");
  sendSession(stat_name, sub_stat_name);
}

////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////// ���ͳ�� /////////////////////////////////////////////////////
void        GameLoggerManager::log_gift_get()
{
  const char* stat_name = getStatTitle("gift");
  const char* sub_stat_name = getStatTitle("gift_get");
  sendSession(stat_name, sub_stat_name);
}

void        GameLoggerManager::log_gift_none_get()
{
  const char* stat_name = getStatTitle("gift");
  const char* sub_stat_name = getStatTitle("gift_none_get");
  sendSession(stat_name, sub_stat_name);
}

void        GameLoggerManager::log_gift_get_none_use()
{
  const char* stat_name = getStatTitle("gift");
  const char* sub_stat_name = getStatTitle("gift_get_none_use");
  sendSession(stat_name, sub_stat_name);
}

////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////// �ͳ�� /////////////////////////////////////////////////////
void        GameLoggerManager::log_activity_person()
{
  const char* stat_name = getStatTitle("activity");
  const char* sub_stat_name = getStatTitle("activity_person");
  sendSession(stat_name, sub_stat_name);
}

void        GameLoggerManager::log_activity_consume_diamond()
{
  const char* stat_name = getStatTitle("activity");
  const char* sub_stat_name = getStatTitle("activity_consume_diamond");
  sendSession(stat_name, sub_stat_name);
}

void        GameLoggerManager::log_activity_consume_gold()
{
  const char* stat_name = getStatTitle("activity");
  const char* sub_stat_name = getStatTitle("activity_consume_gold");
  sendSession(stat_name, sub_stat_name);
}

void        GameLoggerManager::log_activity_consume_ap()
{
  const char* stat_name = getStatTitle("activity");
  const char* sub_stat_name = getStatTitle("activity_consume_ap");
  sendSession(stat_name, sub_stat_name);
}