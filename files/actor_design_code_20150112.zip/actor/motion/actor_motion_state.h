#ifndef ACTOR_MOTION_STATE_H
#define ACTOR_MOTION_STATE_H

#include "game/actor/template_class/state.h"

namespace actor {

  class Actor;

  enum eActorMotionState
  {
    kActorMotionStateIdle,
    kActorMotionStateMove,
    kActorMotionStateAttack,
    kActorMotionStateSpecial,
    kActorMotionStateBorn,
    kActorMotionStateDead,
    kActorMotionState
  };


  class MotionState : public State<Actor>
  {
  public:
    virtual ~MotionState();

    static const int     STATE_TYPE;


  private:
    MotionState();
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_H
