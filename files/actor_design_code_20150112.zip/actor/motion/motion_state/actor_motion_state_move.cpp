#include "actor_motion_state_move.h"

namespace actor {

  const int MotionStateMove::STATE_TYPE = kActorMotionStateMove;

  MotionStateMove* MotionStateMove::Instance()
  {
    static MotionStateMove instance;
    return &instance;
  }


  void MotionStateMove::OnEnter(Actor* actor)
  {

  }

  void MotionStateMove::OnExit(Actor* actor)
  {

  }

  void MotionStateMove::Update(Actor* actor, float delta_time)
  {

  }

} // namespace actor