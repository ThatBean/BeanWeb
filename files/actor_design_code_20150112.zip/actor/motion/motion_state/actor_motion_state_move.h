#ifndef ACTOR_MOTION_STATE_MOVE_H
#define ACTOR_MOTION_STATE_MOVE_H

#include "game/actor/motion/actor_motion_state.h"


namespace actor {

  class MotionStateMove : public MotionState
  {
  public:
    virtual ~MotionStateMove();
    static MotionStateMove* Instance();
    static const int     STATE_TYPE;

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);

  private:
    MotionStateMove();
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_MOVE_H
