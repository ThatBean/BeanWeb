﻿#include "actor_motion_state_machine.h"

namespace actor {

  eActorMotionState MotionStateMachine::GetCurrentMotionStateType()
  {
    if (current_state_)
    {
      return eActorMotionState(current_state_->GetStateType());
    }
    return kActorMotionState;
  }

} // namespace actor