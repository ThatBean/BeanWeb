#ifndef ACTOR_MOTION_STATE_MACHINE_H
#define ACTOR_MOTION_STATE_MACHINE_H

#include "game/actor/template_class/state_machine.h"
#include "actor_motion_state.h"

namespace actor {
  class Actor;

  class MotionStateMachine : public StateMachine<Actor>
  {
  public:
    MotionStateMachine(Actor* actor) 
      : StateMachine<Actor>(actor) {}

    eActorMotionState GetCurrentMotionStateType();
  };

} // namespace actor

#endif // ACTOR_MOTION_STATE_MACHINE_H
