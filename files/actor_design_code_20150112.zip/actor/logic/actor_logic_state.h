#ifndef ACTOR_LOGIC_STATE_H
#define ACTOR_LOGIC_STATE_H

#include "game/actor/template_class/state.h"

namespace actor {

  class Actor;

  enum eActorLogicState
  {
    kActorLogicStateIdle,
    kActorLogicStateMove,
    kActorLogicStateAttack,
    kActorLogicStateSpecial,
    kActorLogicStateBorn,
    kActorLogicStateDead,
    kActorLogicState
  };


  class LogicState : public State<Actor>
  {
  public:
    virtual ~LogicState();

    static const int     STATE_TYPE;


  private:
    LogicState();
  };

} // namespace actor


#endif // ACTOR_LOGIC_STATE_H
