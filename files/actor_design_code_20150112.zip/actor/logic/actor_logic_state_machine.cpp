#include "actor_logic_state_machine.h"

namespace actor {
  
  eActorLogicState LogicStateMachine::GetCurrentLogicStateType()
  {
    if (current_state_)
    {
      return eActorLogicState(current_state_->GetStateType());
    }
    return kActorLogicState;
  }

} // namespace actor