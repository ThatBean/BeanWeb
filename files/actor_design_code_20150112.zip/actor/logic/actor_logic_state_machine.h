#ifndef ACTOR_LOGIC_STATE_MACHINE_H
#define ACTOR_LOGIC_STATE_MACHINE_H

#include "game/actor/template_class/state_machine.h"
#include "actor_logic_state.h"

namespace actor {
  class Actor;
  
  class LogicStateMachine : public StateMachine<Actor>
  {
    public:
      LogicStateMachine(Actor* actor) 
        : StateMachine<Actor>(actor) {}
      
      eActorLogicState GetCurrentLogicStateType();
  };

} // namespace actor

#endif // ACTOR_LOGIC_STATE_MACHINE_H
