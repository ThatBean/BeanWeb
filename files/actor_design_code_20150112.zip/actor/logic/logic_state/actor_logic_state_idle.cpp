#include "actor_logic_state_idle.h"

namespace actor {

  const int LogicStateIdle::STATE_TYPE = kActorLogicStateIdle;

  LogicStateIdle* LogicStateIdle::Instance()
  {
    static LogicStateIdle instance;
    return &instance;
  }


  void LogicStateIdle::OnEnter(Actor* actor)
  {

  }

  void LogicStateIdle::OnExit(Actor* actor)
  {

  }

  void LogicStateIdle::Update(Actor* actor, float delta_time)
  {
    //CheckAttackRangeTrigger (Check enemy)

  }

} // namespace actor