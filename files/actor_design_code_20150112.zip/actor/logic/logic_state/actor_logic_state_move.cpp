#include "actor_logic_state_move.h"

namespace actor {

  const int LogicStateMove::STATE_TYPE = kActorLogicStateMove;

  LogicStateMove* LogicStateMove::Instance()
  {
    static LogicStateMove instance;
    return &instance;
  }


  void LogicStateMove::OnEnter(Actor* actor)
  {

  }

  void LogicStateMove::OnExit(Actor* actor)
  {

  }

  void LogicStateMove::Update(Actor* actor, float delta_time)
  {
    //Position
    //Target
    
    //CheckAttackRangeTrigger (Check enemy)

  }

} // namespace actor