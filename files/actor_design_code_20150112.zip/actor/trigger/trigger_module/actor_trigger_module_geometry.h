#ifndef ACTOR_TRIGGER_MODULE_GEOMETRY_H
#define ACTOR_TRIGGER_MODULE_GEOMETRY_H


#include "game/actor/trigger/actor_trigger_module.h"


namespace actor 
{
  enum eActorTriggerGeometryFlag
  {
    kActorTriggerGeometryDistance   = 1 << 0,
    kActorTriggerGeometryDirection  = 1 << 1,
    kActorTriggerGeometryLocation   = 1 << 2,
    kActorTriggerGeometry
  };


  class ActorTriggerModuleGeometry : public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleGeometry();

  public:
    static ActorTriggerModuleGeometry* Instance();
    ~ActorTriggerModuleGeometry();

    bool     Update(Actor* actor, uint_32 trigger_flag, std::list<Actor*>* actor_list);

    bool     UpdateDistance(Actor* actor, std::list<Actor*>* actor_list);
    bool     UpdateDirection(Actor* actor, std::list<Actor*>* actor_list);
    bool     UpdateLocation(Actor* actor, std::list<Actor*>* actor_list);

  private:
    static const eActorTriggerModule trigger_module_type_;

  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_GEOMETRY_H