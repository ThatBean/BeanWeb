#include "actor_trigger_module_geometry.h"

#include "game/actor/actor.h"

namespace actor 
{
  const eActorTriggerModule ActorTriggerModuleGeometry::trigger_module_type_ = kActorTriggerModuleGeometry;
  
  ActorTriggerModuleGeometry* ActorTriggerModuleGeometry::Instance()
  {
    static ActorTriggerModuleGeometry instance;
    return &instance;
  }

  ActorTriggerModuleGeometry::ActorTriggerModuleGeometry()
  {

  }

  ActorTriggerModuleGeometry::~ActorTriggerModuleGeometry()
  {

  }

  bool ActorTriggerModuleGeometry::Update(Actor* actor, uint_32 trigger_flag, std::list<Actor*>* actor_list)
  {
    bool is_triggered = false;
    if (trigger_flag & kActorTriggerGeometryDistance) { is_triggered |= UpdateDistance(actor, actor_list); }
    if (trigger_flag & kActorTriggerGeometryDirection) { is_triggered |= UpdateDirection(actor, actor_list); }
    if (trigger_flag & kActorTriggerGeometryLocation) { is_triggered |= UpdateLocation(actor, actor_list); }
    return is_triggered;
  }

  bool     ActorTriggerModuleGeometry::UpdateDistance(Actor* actor, std::list<Actor*>* actor_list)
  {
    bool is_triggered = false;
    return is_triggered;
  }
  bool     ActorTriggerModuleGeometry::UpdateDirection(Actor* actor, std::list<Actor*>* actor_list)
  {
    bool is_triggered = false;
    return is_triggered;
  }
  bool     ActorTriggerModuleGeometry::UpdateLocation(Actor* actor, std::list<Actor*>* actor_list)
  {
    bool is_triggered = false;
    return is_triggered;
  }

}  // namespace actor