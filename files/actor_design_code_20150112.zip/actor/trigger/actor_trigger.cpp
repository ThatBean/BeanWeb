#include "actor_trigger.h"

#include "game/actor/actor.h"
#include <assert.h>

namespace actor {

  ActorTrigger::ActorTrigger(Actor* actor)
    :actor_(actor_),
    is_triggered_(false)
  {
    trigger_module_config_list_.clear();
  }

  void ActorTrigger::AddTriggerModuleConfig(ActorTriggerModule* trigger_module, uint_32 trigger_module_flag)
  {
    assert(trigger_module);
    sTriggerModuleConfig* trigger_module_config = new sTriggerModuleConfig();
    
    trigger_module_config->trigger_module = trigger_module;
    trigger_module_config->trigger_module_flag = trigger_module_flag;

    trigger_module_config_list_.push_back(trigger_module_config);
  }

  void ActorTrigger::Update()  // loop trigger module
  {
    std::list<Actor*>* triggered_actor_list = actor_->GetActorExtEnv()->GetActorList();
    std::list<sTriggerModuleConfig*>::iterator iterator_tmc = trigger_module_config_list_.begin();
    is_triggered_ = false;
    while (iterator_tmc != trigger_module_config_list_.end())
    {
      sTriggerModuleConfig* trigger_module_config = *iterator_tmc; 
      //the triggered_actor_list will be screened (un-triggered actor will be removed from list)
      bool is_module_triggered = trigger_module_config->trigger_module->Update(
        actor_, 
        trigger_module_config->trigger_module_flag, 
        triggered_actor_list);
      is_triggered_ = is_triggered_ || is_module_triggered;

      ++iterator_tmc;
    }

    //collect actor id
    std::list<Actor*>::iterator iterator_ta = triggered_actor_list->begin();
    triggered_actor_id_list_.clear();
    while (iterator_ta != triggered_actor_list->end())
    {
      Actor* actor = *iterator_ta;
      triggered_actor_id_list_.push_back(actor->GetActorId());
    }

    delete triggered_actor_list;  //clean up
  }
}  // namespace actor


