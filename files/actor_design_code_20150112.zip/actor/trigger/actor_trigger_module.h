#ifndef ACTOR_TRIGGER_MODULE_H
#define ACTOR_TRIGGER_MODULE_H


#include "engine/base/basictypes.h"


namespace actor 
{
  
  class Actor;

  enum eActorTriggerModule
  {
    kActorTriggerModuleFraction,
    kActorTriggerModuleGeometry,
    kActorTriggerModuleStatus,
    kActorTriggerModuleScript,  //lua
    kActorTriggerModule
  };


  enum eActorTriggerFactionFlag
  {
    kActorTriggerFactionAlly  = 1 << 0,
    kActorTriggerFactionEnemy = 1 << 1,
    kActorTriggerFactionSelf  = 1 << 2,
    kActorTriggerFaction
  };
  

  enum eActorTriggerStatusFlag
  {
    kActorTriggerStatusWeak  = 1 << 0,
    kActorTriggerStatusDead  = 1 << 1,
    kActorTriggerStatusIdle  = 1 << 2,
    kActorTriggerStatus
  };



  class ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  public:
    ActorTriggerModule();
    ~ActorTriggerModule();

    virtual bool     Update(Actor* actor, uint_32 trigger_flag, std::list<Actor*>* actor_list) = 0;

    eActorTriggerModule   GetTriggerModuleType() { return trigger_module_type_; }

  private:
    static const eActorTriggerModule trigger_module_type_;
    
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_H