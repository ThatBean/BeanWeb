#include "actor_control.h"

#include "game/actor/actor.h"

namespace actor {

  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor),
    actor_control_type_(kActorControl)
  {

  }

  void ActorControl::Update()
  {
    switch (actor_control_type_)
    {
    }
  }

} // namespace actor