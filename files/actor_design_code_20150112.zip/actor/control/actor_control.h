#ifndef ACTOR_CONTROL_H
#define ACTOR_CONTROL_H



#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  enum eActorLogicState;

  enum eActorControlType
  {
    kActorControlManual,  //will check user input
    kActorControlAuto,    //will issue command automatically
    kActorControl
  };

  //enum eActorControlManualType
  //enum eActorControlAutoType


  class ActorControl
  {
  public:
    ActorControl(Actor* actor);
    ~ActorControl();

    void Update();


  private:

    void  ChangeControl(eActorControlType);
    bool  LogicStateChangeCheck(eActorLogicState new_logic_state);


    Actor*               actor_;
    eActorControlType    actor_control_type_;


  };
} // namespace actor


#endif // ACTOR_CONTROL_H
