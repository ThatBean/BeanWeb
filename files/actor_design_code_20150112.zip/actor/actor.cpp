#include "actor.h"

#include "logic/logic_state/actor_logic_state_idle.h"
#include "logic/logic_state/actor_logic_state_move.h"

#include "engine/base/basictypes.h"
//#include "engine/script/lua_tinker_manager.h"

namespace actor {


  Actor::Actor()
    : actor_type_(kActor),
    actor_attack_type_(kActorAttack),
    actor_career_type_(kActorCareer)
  {
    Init();
  }

  Actor::~Actor()
  {

  }

  void Actor::Init()
  {
    actor_control_ = new ActorControl(this);

    actor_trigger_active_ = new ActorTrigger(this);
    actor_trigger_passive_ = new ActorTrigger(this);

    logic_state_machine_ = new LogicStateMachine(this);
    motion_state_machine_ = new MotionStateMachine(this);
    //logic_state_machine_->ChangeState(LogicStateIdle::Instance());
    //printf("%d", logic_state_machine_->GetCurrentLogicStateType());
    //int near_attacker_ai_stay_time_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/ai_config.lua", "GetNearAttackerAIStayTime");
  }

  void Actor::Update(float delta_time)
  {
    actor_control_->Update();

    actor_trigger_active_->Update();
    actor_trigger_passive_->Update();

    logic_state_machine_->Update(delta_time);
    motion_state_machine_->Update(delta_time);
  }

  eActorLogicState Actor::GetCurrentLogicState()
  {
    return logic_state_machine_->GetCurrentLogicStateType();
  }

} // namespace actor