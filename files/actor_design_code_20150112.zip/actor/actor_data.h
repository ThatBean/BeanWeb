#ifndef ACTOR_DATA_H
#define ACTOR_DATA_H

namespace actor {

  enum eActorType
  {
    kActorCharacter,
    kActorMonster,
    kActorBoss,
    kActor
  };


  enum eActorAttackType
  {
    kActorAttackMelee,
    kActorAttackRange,
    kActorAttackHealing,
    kActorAttack
  };


  enum eActorCareerType
  {
    kActorCareerWarrior,
    kActorCareerKnight,
    kActorCareerPriest,
    kActorCareerWizard,
    kActorCareerArcher,
    kActorCareerBoss,
    kActorCareer
  };


  class ActorData
  {
  public:

  private:
    eActorType           actor_type_;
    eActorAttackType     actor_attack_type_;
    eActorCareerType     actor_career_type_;
    int*          actor_animation_node;
    int*          actor_health_bar;
    //BuffData*       actor_buff_data_; //store actor buff data
  };



} // namespace actor


#endif // ACTOR_DATA_H