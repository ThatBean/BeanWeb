#ifndef ACTOR_ACTOR_H
#define ACTOR_ACTOR_H

#include "control/actor_control.h"
#include "trigger/actor_trigger.h"
#include "logic/actor_logic_state_machine.h"
#include "motion/actor_motion_state_machine.h"

namespace actor {

  class ActorExtEnv;  //ActorExternalEnvironment, the map / battlefield where actors live in (Actor Pool)
  class ActorData;


  class Actor
  {
  public:
    Actor();
    ~Actor();

    void    Init();
    void    Update(float delta_time);

    eActorLogicState GetCurrentLogicState();

  public:
    //The link upwards to actor pool
    void             SetActorExtEnv(ActorExtEnv* actor_ext_env) { actor_ext_env_ = actor_ext_env; }
    ActorExtEnv*     GetActorExtEnv() { return actor_ext_env_; }

    void             SetActorId(int actor_id) { actor_id_ = actor_id; }
    int              GetActorId() { return actor_id_; }

  private:
    int              actor_id_;  //where this actor is stored in ExtEnv
    ActorExtEnv*     actor_ext_env_;
    
    ActorData*       actor_data_;

    ActorControl*         actor_control_; //Manual or Auto, may change Logic State

    ActorTrigger*       actor_trigger_active_;  //positive, self target searching
    ActorTrigger*       actor_trigger_passive_;  //negative, triggered by other actor

    LogicStateMachine*    logic_state_machine_; //manage Motion 
    MotionStateMachine*   motion_state_machine_;  //manage Position and Animation

    //BuffData*       actor_buff_data_; //store actor buff data

  };



} // namespace actor


#endif // actor/actor.h
