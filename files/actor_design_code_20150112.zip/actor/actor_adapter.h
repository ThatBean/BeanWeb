#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H

#include "engine/base/basictypes.h"

namespace actor {

class ActorAdapter
{
private:
  ActorAdapter();
public:
  ~ActorAdapter();

  static ActorAdapter& GetInstance()
  {
    static ActorAdapter* X = NULL;
    if (!X)
    {
      X = new ActorAdapter();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }

  void    LoadAIConfig();
  
  int     GetNearAttackerAIStayTime();
  int     GetRangAttackerAIStayTime();
  int     GetAssassinAISearchRowTime();
  bool    GetIsAutoFight();

  void    SetIsAutoFightEnable(bool flag);

private:
  int     near_attacker_ai_stay_time_;
  int     range_attacker_ai_stay_time_;
  int     assassion_ai_search_row_time_;
  bool    is_auto_fight_;
};

} // namespace actor


#endif // ACTOR_ADAPTER_H
