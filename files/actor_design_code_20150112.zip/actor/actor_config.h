//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2012 TaoMee Inc. 
//
//      FileName: ai_config.h
//        Author: peteryu
//          Date: 2014/4/22 14:25
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     peteryu    2014/4/22      add
//////////////////////////////////////////////////////////////
#ifndef AI_CONFIG_H
#define AI_CONFIG_H

#include "engine/base/basictypes.h"

#include "engine/platform/SingleInstance.h"

namespace taomee {
namespace ai {

class AIConfig : public SingleInstanceObj
{
private:
  AIConfig();
public:
  ~AIConfig();

  static AIConfig& GetInstance()
  {
    static AIConfig* X = NULL;
    if (!X)
    {
      X = new AIConfig();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X);
    }
    return *X;
  }

  void    LoadAIConfig();
  
  int     GetNearAttackerAIStayTime();
  int     GetRangAttackerAIStayTime();
  int     GetAssassinAISearchRowTime();
  bool    GetIsAutoFight();

  void    SetIsAutoFightEnable(bool flag);

private:
  int     near_attacker_ai_stay_time_;
  int     range_attacker_ai_stay_time_;
  int     assassion_ai_search_row_time_;
  bool    is_auto_fight_;
};
  
} // namespace taomee
} // namespace ai


#endif // ChainChronicle_ai_state_h
