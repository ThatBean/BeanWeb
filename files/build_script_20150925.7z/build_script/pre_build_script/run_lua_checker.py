#!/usr/bin/python
#coding:utf-8 

import os
import sys
import base64

#add python module path
sys.path.append("../build_process/python_module")
import generate_file_list
import run_shell_command


TARGET_FILE_EXT = ".lua"
OUTPUT_FILE_PREFIX = ""

LUAC_EXE_PATH = "luac"
LUAC_OPTION = "-p"	#parse only


# usage: luac [options] [filenames].
# Available options are:
  # -        process stdin
  # -l       list
  # -o name  output to file 'name' (default is "luac.out")
  # -p       parse only
  # -s       strip debug information
  # -v       show version information
  # --       stop handling options


def FormatLuaFile(source_file_path, result_file_path):
	global LUAC_EXE_PATH
	global LUAC_OPTION
	
	command = LUAC_EXE_PATH
	command += " " + LUAC_OPTION
	#command += " -o " + result_file_path	#parse only, no output
	command += " " + source_file_path
	
	result_data = run_shell_command.RunShellCommmand(command)
	
	#save to result file
	# f2 = open(result_file_path, 'wb')
	# f2.write(result_data)
	# f2.close()
	
# Check lua file
# USAGE:
#	> python <script_file>.py <source file dir>
#	> <source file dir> = ./
# SAMPLE:
#	> python <script_file>.py 
#	> python <script_file>.py ./lua_files/

if (__name__ == "__main__"):
	
	# global TARGET_FILE_EXT
	
	PATH_SRC_FILE_DIR = "./"
	
	if len(sys.argv) > 1:
		if sys.argv[1]:
			PATH_SRC_FILE_DIR = sys.argv[1]
	
	#print(sys.argv, len(sys.argv), PATH_SRC_FILE_DIR, IS_REMOVE_SRC_FILE)
	print("Target Dir:",PATH_SRC_FILE_DIR)
	
	print("===Start Check Lua===")
	
	#get file list
	file_list = generate_file_list.GetFileList(PATH_SRC_FILE_DIR, TARGET_FILE_EXT, OUTPUT_FILE_PREFIX)
	
	print("Total File:", len(file_list))
	
	for file_path_data in file_list:
		#get file path
		source_file_path = file_path_data[0]
		result_file_path = file_path_data[1]
		
		print(">> Checking", source_file_path)
		
		FormatLuaFile(source_file_path = source_file_path, result_file_path = result_file_path)
		
		#remove the source file
		# if IS_REMOVE_SRC_FILE:
			# print(">>>> Removing", source_file_path)
			# os.remove(source_file_path)
		
	print("===Finished Check Lua===")
	print("Total File:", len(file_list))