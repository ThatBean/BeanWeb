#!/usr/bin/python
#coding:utf-8 

import os
import sys
import base64

#add python module path
sys.path.append("../build_process/python_module")
import generate_file_list
import run_shell_command


TARGET_FILE_EXT = ".lua"
OUTPUT_FILE_PREFIX = ""

LUA_EXE_PATH = "lua"
LUA_FORMAT_SCRIPT_PATH = "lua-indenter.lua"
LUA_FORMAT_OPTION = "--tabsize=1 -nb -ab -rs"


def FormatLuaFile(source_file_path, result_file_path):
	global LUA_EXE_PATH
	global LUA_FORMAT_SCRIPT_PATH
	global LUA_FORMAT_OPTION
	
	command = LUA_EXE_PATH
	command += " " + LUA_FORMAT_SCRIPT_PATH
	command += " " + source_file_path
	command += " " + LUA_FORMAT_OPTION
	
	result_data = run_shell_command.RunShellCommmand(command)
	
	#save to result file
	f2 = open(result_file_path, 'wb')
	f2.write(result_data)
	f2.close()
	
# Format lua file
# USAGE:
#	> python <script_file>.py <source file dir> <is delete source file>
#	> <source file dir> = ./
#	> <is delete source file> = false
# SAMPLE:
#	> python <script_file>.py 
#	> python <script_file>.py ./lua_files/
#	> python <script_file>.py ./lua_files/ true

if (__name__ == "__main__"):
	
	# global TARGET_FILE_EXT
	# global OUTPUT_FILE_PREFIX
	
	PATH_SRC_FILE_DIR = "./"
	IS_REMOVE_SRC_FILE = False
	
	if len(sys.argv) > 1:
		if sys.argv[1]:
			PATH_SRC_FILE_DIR = sys.argv[1]
	
	if len(sys.argv) > 2:
		if sys.argv[2]:
			IS_REMOVE_SRC_FILE = True
	
	#print(sys.argv, len(sys.argv), PATH_SRC_FILE_DIR, IS_REMOVE_SRC_FILE)
	print("Target Dir:",PATH_SRC_FILE_DIR)
	print("Is Remove Source:", IS_REMOVE_SRC_FILE)
	
	print("===Start Format Lua===")
	
	#get file list
	file_list = generate_file_list.GetFileList(PATH_SRC_FILE_DIR, TARGET_FILE_EXT, OUTPUT_FILE_PREFIX)
	
	print("Total File:", len(file_list))
	
	for file_path_data in file_list:
		#get file path
		source_file_path = file_path_data[0]
		result_file_path = file_path_data[1]
		
		print(">> Formating", source_file_path)
		
		FormatLuaFile(source_file_path = source_file_path, result_file_path = result_file_path)
		
		#remove the source file
		if IS_REMOVE_SRC_FILE:
			print(">>>> Removing", source_file_path)
			os.remove(source_file_path)
		
	print("===Finished Format Lua===")
	print("Total File:", len(file_list))