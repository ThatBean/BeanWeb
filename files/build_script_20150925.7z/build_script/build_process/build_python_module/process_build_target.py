#!/usr/bin/python
#coding:utf-8 

import env_info
import JSON_file_reader

##should be json
valid_build_target_list = {
	"" : "TARGET_RELEASE",
	"debug" : "TARGET_DEBUG",
	"release" : "TARGET_RELEASE",
	"TDP" : "TARGET_SDK_TDP_RELEASE",
	"PP" : "TARGET_SDK_PP_RELEASE",
	"91" : "TARGET_SDK_91_RELEASE",
	"XY" : "TARGET_SDK_XY_RELEASE",
	"TBT" : "TARGET_SDK_TBT_RELEASE",
	"CM" : "TARGET_SDK_CM_RELEASE",
}
##check execute_build.py xcode_target_list

def _check_valid(build_target):
	if (build_target in valid_build_target_list):
		return
	else:
		print("[Error] build target not valid:", build_target)
		exit(1)


def ProcessBuildTarget(build_target):
	_check_valid(build_target)
	return valid_build_target_list[build_target]
	