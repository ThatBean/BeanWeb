#!/bin/bash

## MOVED TO PYTHON SCRIPT
## MOVED TO PYTHON SCRIPT
## MOVED TO PYTHON SCRIPT

#WORKSPACE
#LANG_VERSION
#PRODUCT_NAME
#GLOBAL_PROJECT
#PLATFORM
#PATH_PRODUCT_VERSION_SPECIFIC
#CURRENT_DEVELOP_VERSION
#NEXT_DISTRIBUTION_VERSION_CODE
#CURRENT_VERSION_BUILD_NUMBER
#ANT_BUILD_VERSION (debug release)

#PATH_PROJECT=${WORKSPACE}/${GLOBAL_PROJECT}/${PLATFORM}
#PATH_NDK_MODULE_0=${WORKSPACE}
#PATH_NDK_MODULE_1=${WORKSPACE}
#PATH_NDK_MODULE_2=${WORKSPACE}/library/cocos2dx
#PATH_NDK_MODULE_3=${WORKSPACE}/library/cocos2dx/cocos2dx/platform/third_party/android/prebuilt/
#PATH_PRODUCT_VERSION_SPECIFIC=${PATH_PRODUCT_VERSION_SPECIFIC}
#FILE_VERSION_CONFIG=${PATH_PROJECT}/ant.properties
#FILE_MANIFEST=${PATH_PROJECT}/AndroidManifest.xml
#STRING_PRODUCT_NAME=${CURRENT_VERSION_BUILD_NUMBER}.${PRODUCT_NAME}_v${CURRENT_DEVELOP_VERSION}_Debug
#STRING_VERSION_NAME=${CURRENT_DEVELOP_VERSION}
#STRING_VERSION_CODE=${NEXT_DISTRIBUTION_VERSION_CODE}


function failed() {
	echo "Failed: $@" >&2
	exit 1
}

# -e      If return is not 0, exit immediately
# -x      Expand and print each command
set -ex

if [ ${ANT_BUILD_VERSION} == "" ]
then
	ANT_BUILD_VERSION=debug
	echo set ANT_BUILD_VERSION to default: "debug"
fi

echo "*************************** Build Android App ***************************"


echo [ANT_BUILD_VERSION] ${ANT_BUILD_VERSION}
echo [PATH_PROJECT] ${PATH_PROJECT}
echo [PATH_PRODUCT_VERSION_SPECIFIC] ${PATH_PRODUCT_VERSION_SPECIFIC}
echo [STRING_PRODUCT_NAME] ${STRING_PRODUCT_NAME}

###
# first, need to revert files may changed in last build
#####
svn revert ${FILE_VERSION_CONFIG}
svn revert ${FILE_MANIFEST}


###
# replace and switch
#####

if [ "$ANDROID_CM_STORE_SWITCH" != "[CHOOSE ONE BELOW]" ]; then
	echo "** Android CM Store Version Switch **"
	# node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/assets $ANDROID_CM_STORE_SWITCH
	# node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/jni $ANDROID_CM_STORE_SWITCH
	PATH_NODE_SCRIPT=${WORKSPACE}/build_script/node_script
	node ${PATH_NODE_SCRIPT}/version_file.js ${PATH_NODE_SCRIPT}/version_file_config_android_cm.json ${PATH_PROJECT} $ANDROID_CM_STORE_SWITCH
fi

if [ "${ANDROID_PACKAGE_NAME_REPLACE}" != "" ]
then
	echo "Replace Android Package Name to ${ANDROID_PACKAGE_NAME_REPLACE}"
	sed "s/package=\".*\"/package=\"${ANDROID_PACKAGE_NAME_REPLACE}\"/" ${PATH_PROJECT}/AndroidManifest.xml > ${PATH_PROJECT}/temp
	rm ${PATH_PROJECT}/AndroidManifest.xml
	mv ${PATH_PROJECT}/temp ${PATH_PROJECT}/AndroidManifest.xml
fi

if [ "${ANDROID_APP_NAME_REPLACE}" != "" ]
then
	echo "Replace Android App Name to ${ANDROID_APP_NAME_REPLACE}"
	sed "s/\<string name=\"app_name\"\>.*\<\/string\>/\<string name=\"app_name\"\>${ANDROID_APP_NAME_REPLACE}\<\/string\>/" ${PATH_PROJECT}/res/values/strings.xml > ${PATH_PROJECT}/res/values/temp
	rm ${PATH_PROJECT}/res/values/strings.xml
	mv ${PATH_PROJECT}/res/values/temp ${PATH_PROJECT}/res/values/strings.xml
fi





###
# clean
#####
cd ${PATH_PROJECT}
# ant clean, remove bin and gen directory
ant clean
echo "clean"
# remove libs/armeabi
rm -rf libs/armeabi
# remove library under obj/local/armeabi
# NOTE: the objs under obj/local/armeabi are not needed to remove  
find obj/local/armeabi/ -maxdepth 1 -type f | xargs rm -f


###
# update version
#####
cat >> ${FILE_VERSION_CONFIG} << INPUT
version.name=${STRING_VERSION_NAME}
version.code=${STRING_VERSION_CODE}
INPUT
# remove version from AndroidManifest.xml, or the version cannot be updated
# option -i on mac and linux are different
if [ "`uname`" == "Darwin" ]
then
	sed -i "" 's/android:versionCode=\"[\.0-9]*\"//' ${FILE_MANIFEST}
	sed -i "" 's/android:versionName=\"[\.0-9]*\"//' ${FILE_MANIFEST}
elif [ "`uname`" == "Linux" ]
then
	sed -i 's/android:versionCode=\"[\.0-9]*\"//' ${FILE_MANIFEST}
	sed -i 's/android:versionName=\"[\.0-9]*\"//' ${FILE_MANIFEST}
else
	echo "Error: Unknow System"
	exit 1
fi


###
# copy asset
#####
cd ${PATH_PROJECT}
script/copy_asset.sh


###
# configure source
#####
cd ${PATH_PROJECT}
script/configure_src.sh


###
# ndk build
#####
cd ${PATH_PROJECT}
export NDK_MODULE_PATH=${PATH_NDK_MODULE_0}:${PATH_NDK_MODULE_1}:${PATH_NDK_MODULE_2}:${PATH_NDK_MODULE_3}
ndk-build NDK_DEBUG=0 || failed "ndk build"


###
# ant
#####
cd ${PATH_PROJECT}
ant ${ANT_BUILD_VERSION} || failed "ant build"


###
# move apk
#####
cd ${PATH_PROJECT}/bin
# -p      Create intermediate directories as required.  If this option is not specified, the full path prefix of each operand must already exist.  On the other hand, with this option specified, no error will be reported if a directory given as an operand already exists.  Intermediate directories are created with permission bits of rwxrwxrwx (0777) as modified by the current umask, plus write and search permission for the owner.
# -v      Be verbose when creating directories, listing them as they are created.
mkdir -pv ${PATH_PRODUCT_VERSION_SPECIFIC}
cp *-${ANT_BUILD_VERSION}.apk ${PATH_PRODUCT_VERSION_SPECIFIC}/${STRING_PRODUCT_NAME}.apk

rm -rf ${PATH_PRODUCT_VERSION_SPECIFIC}/0_NEW_*
cp *-${ANT_BUILD_VERSION}.apk ${PATH_PRODUCT_VERSION_SPECIFIC}/0_NEW_${STRING_PRODUCT_NAME}.apk


# revert
svn revert ${FILE_VERSION_CONFIG}
svn revert ${FILE_MANIFEST}
svn revert ${PATH_PROJECT}/AndroidManifest.xml
svn revert ${PATH_PROJECT}/res/values/strings.xml