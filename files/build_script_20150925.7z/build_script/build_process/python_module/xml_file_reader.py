#!/usr/bin/python
#coding:utf-8 

import xml.etree.ElementTree as ElementTree
import os


##--------------------------------------------------------------------------------------
class XmlFileReader:
	##--------------------------------------------------------------------------------------
	def __init__(self):
		# nothing
		print("init XmlFileReader")
		
	##--------------------------------------------------------------------------------------
	def write_file(self, file_name, loaded_obj):
		if (not os.path.isfile(file_name)):
			print("[error] not a file!", file_name)
			exit(1)
		else:
			self._save_xml(file_name, loaded_obj)
			return
	
	##--------------------------------------------------------------------------------------
	def _save_xml(self, file_name, loaded_obj):
		serialized_obj = ElementTree.tostring(loaded_obj, "unicode", "xml") 
		
		file = open(file_name, 'w')
		file.write(serialized_obj)
		file.close()

	##--------------------------------------------------------------------------------------
	def read_file(self, file_name):
		if (not os.path.isfile(file_name)):
			print("[error] not a file!", file_name)
			exit(1)
		else:
			res_string = self._get_xml_text(file_name)
			loaded_obj = ElementTree.fromstring(res_string)
			return loaded_obj
	
	##--------------------------------------------------------------------------------------
	def _get_xml_text(self, file_name):
		file = open(file_name, 'rb')
		xml_text = file.read().decode("utf-8")
		file.close()
		
		return xml_text
		

##--------------------------------------------------------------------------------------	


if __name__ == "__main__":
	import sys
	self_module_name = sys.argv[0].split(".")[0]
	print('''
#xml File Reader#
load xml formatted file
will return python object, or None

Usage:
	import %s
	xfr = %s.XmlFileReader()
	print(xfr.read_file("config.xml"))
	''' % (self_module_name, self_module_name))