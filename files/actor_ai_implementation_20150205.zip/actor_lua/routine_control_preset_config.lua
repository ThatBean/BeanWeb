local function DEBUG_PRINT(...)
	--print(...)
	return
end


local RoutineControlPresetConfig = {}

RoutineControlPresetConfig.ROUTINE_START = "ROUTINE_START"
RoutineControlPresetConfig.ROUTINE_END = "ROUTINE_END"
RoutineControlPresetConfig.ROUTINE_BACK = "ROUTINE_BACK"
RoutineControlPresetConfig.ROUTINE_TRIGGER = "ROUTINE_TRIGGER"	--will check ever update, expensive

RoutineControlPresetConfig.PRESET_ROUTINE = {}
RoutineControlPresetConfig.PRESET_ROUTINE.SKIP = {
	update_func = function(routine_control, routine_data)
		return false
	end
}
RoutineControlPresetConfig.PRESET_ROUTINE.STUCK = {
	update_func = function(routine_control, routine_data)
		return true
	end
}



RoutineControlPresetConfig.SWITCH_CONDITION = {}
RoutineControlPresetConfig.SWITCH_CONDITION.NO_CONDITION = function (switch_list, routine_control)
	return switch_list[1]
end
RoutineControlPresetConfig.SWITCH_CONDITION.RANDOM = function (switch_list, routine_control)
	return switch_list[math.random(#switch_list)]
end
RoutineControlPresetConfig.SWITCH_CONDITION.HEALTH_PERCENT = function (...)
	local percent_range_list = {...}
	--dri(percent_range_list, 2, 4, 99)
	return function (switch_list, routine_control)
		local health_percent = routine_control:GetActorHealthPercent()
		for index, percent_range in pairs(percent_range_list) do
			if (health_percent >= percent_range[1] and health_percent <= percent_range[2]) then
				return switch_list[index]
			end
		end
		return nil
	end
end


RoutineControlPresetConfig.BOOL_CONDITION = {}
RoutineControlPresetConfig.BOOL_CONDITION.NO_CONDITION = function (routine_control, routine_data)
	return true
end
RoutineControlPresetConfig.BOOL_CONDITION.UPDATE_FINISH = function (routine_control, routine_data) --means exit on next time idle
	if (routine_data._UPDATE_FINISH_STAT) then
		routine_data._UPDATE_FINISH_STAT = nil
		return false
	else
		routine_data._UPDATE_FINISH_STAT = true
		return false
	end
end
RoutineControlPresetConfig.BOOL_CONDITION.TIME = function (condition_type, condition_data)
	local condition_time = condition_data
	
	if (condition_type == "since_control_start") then
		return function (routine_control, routine_data)
			return condition_time > routine_control:GetControlTimeTotal()
		end
	end
	if (condition_type == "since_routine_pack_start") then
		return function (routine_control, routine_data)
			return condition_time > routine_control:GetControlTimeRoutinePack()
		end
	end
	if (condition_type == "since_routine_start") then
		return function (routine_control, routine_data)
			return condition_time > routine_control:GetControlTimeRoutine()
		end
	end
end
RoutineControlPresetConfig.BOOL_CONDITION.ACTOR_DATA = function (condition_type, condition_data)
	if (condition_type == "position") then
		return function (routine_control, routine_data)
			assert(false)
			return PointUtil:getDistance(routine_control:GetActorPosition(), condition_data) > 0.5
		end
	end
end



local function ConvertRoutinePackArrangement(routine_pack_arrangement)
	local next_name_getter_func_list = {
		ROUTINE_TRIGGER = {},
	}
	for index, arrangement in ipairs(routine_pack_arrangement) do
		local routine_pack_name = arrangement[1]
		local next_routine_pack_name_list = arrangement[2]
		local next_routine_pack_switch_func = arrangement[3] or function () return next_routine_pack_name_list[1] end
		local next_name_getter_func = function (routine_control)
			DEBUG_PRINT("[auto][next_name_getter_func] ", routine_pack_name)
			local next_routine_pack_name = next_routine_pack_switch_func(next_routine_pack_name_list, routine_control)
			return next_routine_pack_name
		end
		
		if ("ROUTINE_TRIGGER" == routine_pack_name) then
			table.insert(next_name_getter_func_list["ROUTINE_TRIGGER"], next_name_getter_func)
		else
			next_name_getter_func_list[routine_pack_name] = next_name_getter_func
		end
		
		DEBUG_PRINT("[auto-create][next_name_getter_func] ", routine_pack_name)
	end
	
	--dri(next_name_getter_func_list, 1, 5, 999)
	
	return next_name_getter_func_list
end



local function ConvertRoutinePackRoutineList(routine_pack_routine_list)
	local routine_pack_update_func_list = {}
	for routine_pack_name, routine_list in pairs(routine_pack_routine_list) do
		local routine_update_func_list = {}
		for index, routine in ipairs(routine_list) do
			local update_func
			if (routine.routine_update 
				or routine.enter_condition 
				or routine.end_condition) 
			then
				update_func = function(routine_control, routine_data)
					if (routine.enter_condition) then
						if (not routine.enter_condition(routine_control, routine_data)) then
							return false
						end
					end
					if (routine.routine_update) then
						if (not routine.routine_update(routine_control, routine_data)) then
							return false
						end
					end
					if (routine.end_condition) then
						if (not routine.end_condition(routine_control, routine_data)) then
							return false
						end
					end
				end
			else
				update_func = routine.update_func or function(routine_control, routine_data) 
					return false
				end
			end
			routine_update_func_list[index] = update_func
		end
		routine_pack_update_func_list[routine_pack_name] = routine_update_func_list
	end
	
	--dri(routine_pack_update_func_list, 1, 5, 999)
	
	return routine_pack_update_func_list
end


local function CombineRoutinePackConfig(config_To, config_From)
	if (not config_From) then
		return
	end
	config_To = config_To or {}
	for routine_pack_name, routine_pack_func in pairs(config_From) do
		config_To[routine_pack_name] = config_To[routine_pack_name] or {}
		config_To[routine_pack_name].next_name_getter_func = routine_pack_func
	end
	
	--dri(config_To, 1, 5, 999)
	
end
local function CombineRoutineConfig(config_To, config_From)
	if (not config_From) then
		return
	end
	config_To = config_To or {}
	for routine_pack_name, routine_pack in pairs(config_From) do
		config_To[routine_pack_name] = config_To[routine_pack_name] or {}
		config_To[routine_pack_name].routine_list = config_To[routine_pack_name].routine_list or {}
		local routine_list = config_To[routine_pack_name].routine_list
		for routine_index, routine_update_func in ipairs(routine_pack) do
			routine_list[routine_index] = routine_list[routine_index] or {}
			routine_list[routine_index].update_func = routine_update_func
		end
	end
	
	--dri(config_To, 1, 5, 999)
	
end
local function SetRoutinePackInfo(routine_pack_list)
	if (not routine_pack_list) then
		return
	end
	
	for routine_pack_name, routine_pack in pairs(routine_pack_list) do
		routine_pack.name = routine_pack_name
		routine_pack.current_routine_index = 1
		
		if (routine_pack_name == "ROUTINE_START") then
			routine_pack.routine_list = {RoutineControlPresetConfig.PRESET_ROUTINE.SKIP}
		end
		if (routine_pack_name == "ROUTINE_END") then
			routine_pack.routine_list = {RoutineControlPresetConfig.PRESET_ROUTINE.STUCK}
		end
	end
end

RoutineControlPresetConfig.ConvertRoutinePack = function (routine_config)
	local next_name_getter_func_list = ConvertRoutinePackArrangement(routine_config.routine_pack_arrangement)
	local routine_pack_update_func_list = ConvertRoutinePackRoutineList(routine_config.routine_pack_routine_list)
	
	local trigger_func_list = next_name_getter_func_list["ROUTINE_TRIGGER"]
	next_name_getter_func_list["ROUTINE_TRIGGER"] = nil
	
	local routine_pack_list = {}
	CombineRoutinePackConfig(routine_pack_list, next_name_getter_func_list)
	CombineRoutineConfig(routine_pack_list, routine_pack_update_func_list)
	SetRoutinePackInfo(routine_pack_list)
	
	local routine_global_data = routine_config.routine_global_data
	
	local routine_config = {
		trigger_func_list = trigger_func_list,
		routine_pack_list = routine_pack_list,
		routine_global_data = routine_global_data,
	}
	
	--dri(routine_config, 1, 5, 999)
	
	return routine_config
end

return RoutineControlPresetConfig