local RoutineControl = require("script/actor/routine_control")
local RoutineControlPresetConfig = require("script/actor/routine_control_preset_config")


local function DEBUG_PRINT(...)
	--print(...)
	return
end


local _next_lua_auto_data_id = 1	--should be > 0
function _get_valid_lua_auto_data_id()
	_next_lua_auto_data_id = _next_lua_auto_data_id + 1
	return _next_lua_auto_data_id
end

--#################################################################################################

local notice = "C++ interface, in actor_control_auto_data"

local _routine_pool = {}

function InitRoutine(actor_script_exporter)
	DEBUG_PRINT("[InitRoutine]")
	
	local lua_auto_data_id = _get_valid_lua_auto_data_id()
	local actor_script_exporter = tolua.cast(actor_script_exporter, "actor::ActorScriptExporter")
	
	_routine_pool[lua_auto_data_id] = RoutineControl.new()
	_routine_pool[lua_auto_data_id]:Init(actor_script_exporter)
	
	return lua_auto_data_id
end

function AddRoutineData(lua_auto_data_id, key, value)
	DEBUG_PRINT("[AddRoutineData] id", lua_auto_data_id, "key", key, "value", value)
	
	if (_routine_pool[lua_auto_data_id]) then
		_routine_pool[lua_auto_data_id]:GlobalData()[key] = value
	end
end

function LoadRoutine(lua_auto_data_id, overload_routine_name)
	DEBUG_PRINT("[LoadRoutine] id", lua_auto_data_id)
	
		
	if (_routine_pool[lua_auto_data_id]) then
		local routine_control = _routine_pool[lua_auto_data_id]
		local routine_name = overload_routine_name or routine_control:GlobalData()["ROUTINE_NAME"]
		local routine_script_path = RoutineControl._lua_routine_config_script_path .. tostring(routine_name)
		local routine_config_create_func = require(routine_script_path)
		local routine_config = routine_config_create_func(RoutineControlPresetConfig)
		routine_control:LoadConfig(routine_config)
		
		print("Loaded Routine:", routine_name)
		--dri(routine_control:GlobalData(), 1, 5, 999)
	end
end


function UpdateRoutine(lua_auto_data_id, delta_time)
	DEBUG_PRINT("[UpdateRoutine] id", lua_auto_data_id)
	
	if (_routine_pool[lua_auto_data_id]) then
		_routine_pool[lua_auto_data_id]:Update(delta_time)
	end
end

function ClearRoutine(lua_auto_data_id)
	DEBUG_PRINT("[ClearRoutine] id", lua_auto_data_id)
	
	if (_routine_pool[lua_auto_data_id]) then
		_routine_pool[lua_auto_data_id]:Clear()
		_routine_pool[lua_auto_data_id] = nil
	end
end