local CharacterRoutine = {
	Born = function (born_grid_x, born_grid_y) 
		return function(routine_control, routine_data)
			local born_grid_x = born_grid_x or routine_control:GlobalData()["born_grid_x"] or math.random(1, 3)
			local born_grid_y = born_grid_y or routine_control:GlobalData()["born_grid_y"] or math.random(1, 3)
			
			local actor_position = routine_control:GetActorPosition()
			local born_positon
			
			if (born_grid_x <= 0) then
				return false
			end
			
			if (born_grid_y > 0) then
				born_positon = routine_control:GetPositionFromGrid(born_grid_x, born_grid_y)
			else
				born_positon = routine_control:GetPositionFromGrid(born_grid_x, 1)
				born_positon = ccp(born_positon.x, actor_position.y)
			end
			
			--check reached position
			if (math.abs(actor_position.x - born_positon.x) < 20 and math.abs(actor_position.y - born_positon.y) < 20) then
				return true
			end
			
			routine_control:GetActorRoutineControlData():SetPosition(ccp(born_positon.x, born_positon.y), actor.kActorControlPriorityMoveManual)	--manual, no targeting
			return true
		end 
	end,
	Guard = function () 
		return function(routine_control, routine_data)
			routine_control:SetActorIsAutoGuard(true)
			return true
		end 
	end,
}



return function (RoutineControlPresetConfig)
	local RC = RoutineControlPresetConfig
	local routine_config_raw = {
		routine_pack_arrangement = {
			{RC.ROUTINE_START, {"P1"}, RC.SWITCH_CONDITION.NO_CONDITION},
			{"P1", {"P2"}, RC.SWITCH_CONDITION.NO_CONDITION},
			{"P2", {RC.ROUTINE_END}, RC.SWITCH_CONDITION.NO_CONDITION},
		},
		routine_pack_routine_list = {
			P1 = {	--Boss Born
				{
					routine_update = CharacterRoutine.Born(),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.TIME("since_routine_start", 0.5),
				},
			},
			P2 = {	--Guard And Attack
				{
					routine_update = CharacterRoutine.Guard(),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.NO_CONDITION,
				},
			},
		},
		routine_global_data = {
		
		},
	}
	local routine_config = RC.ConvertRoutinePack(routine_config_raw)
	return routine_config
end