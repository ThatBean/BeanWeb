#include "actor_logic_state_idle.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateIdle::STATE_TYPE = kActorLogicStateIdle;

  LogicStateIdle* LogicStateIdle::Instance()
  {
    static LogicStateIdle instance;
    return &instance;
  }


  void LogicStateIdle::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(true);
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIdle));
  }

  void LogicStateIdle::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);

    if (actor->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter
      && IsPositionInGrid(actor->GetActorData()->GetMotionData()->GetPosition()))
    {
      ActorSpecifiedDataCharacter* specified_data = dynamic_cast<ActorSpecifiedDataCharacter*>(actor->GetActorData()->GetSpecifiedData());
      specified_data->SetLastIdleGrid(GetGridFromPosition(actor->GetActorData()->GetMotionData()->GetPosition()));
    }
  }

  void LogicStateIdle::Update(Actor* actor, float delta_time)
  {
    //check trigger
    if (actor->GetActorData()->GetControlData()->IsSet() == false
      && actor->GetActorData()->GetControlData()->GetCountdown() == 0
      && IsPositionInGrid(actor->GetActorData()->GetMotionData()->GetPosition())) //logic only run when actor entered grid
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdownGuard();

      if (CommonCheckAttackTrigger(actor))
      {
        //goto Attack, commit attack
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
        return;
      }

      if (CommonCheckGuardTrigger(actor))
      {
        //goto Move, move closer and guard
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
        return;
      }

      if (actor->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter)
      {
        //if the actor is a character, run some nasty check
        ActorSpecifiedDataCharacter* specified_data = dynamic_cast<ActorSpecifiedDataCharacter*>(actor->GetActorData()->GetSpecifiedData());
        cocos2d::CCPoint grid_position = GetGridFromPosition(actor->GetActorData()->GetMotionData()->GetPosition());
        
        //check overlap
        if (actor->GetActorExtEnv()->CheckActorGridOverlap(actor) || specified_data->IsGridIdleValid(grid_position) == false)
        {
          cocos2d::CCPoint grid_position = specified_data->GetValidGrid();
          //goto Move, move away from grid
          actor->GetActorData()->GetControlData()->SetPosition(GetPositionFromGrid(grid_position), kActorControlPriorityMoveAuto);
          actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
          return;
        }

        //check snap to grid
        if (GetPositionFromGrid(grid_position).getDistance(actor->GetActorData()->GetMotionData()->GetPosition()) > 2.0f)
        {
          actor->GetActorData()->GetControlData()->SetPosition(GetPositionFromGrid(grid_position), kActorControlPriorityMoveAuto);
        }
      }
    }
  }
} // namespace actor