#include "actor_logic_state_attack.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateAttack::STATE_TYPE = kActorLogicStateAttack;

  LogicStateAttack* LogicStateAttack::Instance()
  {
    static LogicStateAttack instance;
    return &instance;
  }

  void LogicStateAttack::OnEnter(Actor* actor)
  {
    //make sure there is a skill in control data
    //make sure there is a skill in control data
    ActorSkillData* skill_data = actor->GetActorData()->GetSkillData();
    ActorControlData* control_data = actor->GetActorData()->GetControlData();

    // not special attack, check if target in normal attack range
    if (control_data->IsSetSkill() == false)
    {
      switch (skill_data->GetNormalAttackTriggeredType())
      {
      case kActorAttackMelee:
        control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackMelee), kActorControlPriorityAttackNormalAuto);
        break;
      case kActorAttackRanged:
        control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackRanged), kActorControlPriorityAttackNormalAuto);
        break;
      case kActorAttackHeal:
        control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackHeal), kActorControlPriorityAttackNormalAuto);
        break;
      case kActorAttack:
      default:
        //no target for normal attack, attack failed, pop back to idle
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
        break;
      }

      if (skill_data->GetTriggeredAttackTrigger())
      {
        //Upgrade to power skill?
        //Upgrade to power skill?
        if (actor->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter 
          && (skill_data->GetActorNormalAttackCount() + skill_data->GetActorPowerAttackCount() + skill_data->GetActorSpecialAttackCount()) % 4 == 3)
        {
          control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackPower), kActorControlPriorityAttackPowerAuto);
        }
        //Upgrade to power skill?
        //Upgrade to power skill?

        //to adapter, set target
        actor->GetActorData()->GetSkillData()->AddSkillTarget(*skill_data->GetTriggeredAttackTrigger()->GetTriggeredActorIdList()->begin());
      }

    }
    //make sure there is a skill in control data
    //make sure there is a skill in control data

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateAttack));

    //skill init 
    //skill init 
    //skill init 
    actor->GetActorData()->GetSkillData()->CommitSkill(control_data->GetSkill());
    //skill init 
    //skill init 
    //skill init 
  }

  void LogicStateAttack::OnExit(Actor* actor)
  {

  }

  void LogicStateAttack::Update(Actor* actor, float delta_time)
  {
    //Wait for Skill system and Motion System to finish
    if (actor->GetActorData()->GetSkillData()->GetIsSkillFinished()
      && actor->GetActorData()->GetMotionData()->GetIsMotionAnimationEnded())
    {
      //not matter skill is successful released or countered

      //clear control data
      actor->GetActorData()->GetControlData()->ResetSkill();

      //back to idle
      actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
    }

  }

} // namespace actor