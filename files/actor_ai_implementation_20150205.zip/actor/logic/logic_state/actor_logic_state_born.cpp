#include "actor_logic_state_born.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateBorn::STATE_TYPE = kActorLogicStateBorn;

  LogicStateBorn* LogicStateBorn::Instance()
  {
    static LogicStateBorn instance;
    return &instance;
  }


  void LogicStateBorn::OnEnter(Actor* actor)
  {

    //decide animation?
    //

    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateBorn));

    //reset CD
    actor->GetActorData()->GetControlData()->SetCountdown(0.5f);
  }

  void LogicStateBorn::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(true);
  }

  void LogicStateBorn::Update(Actor* actor, float delta_time)
  {
    //check trigger
    if (actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      //goto Move, move to guard area
      actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
    }
  }

} // namespace actor