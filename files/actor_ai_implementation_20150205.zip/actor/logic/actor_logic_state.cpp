#include "actor_logic_state.h"

#include "logic_state/actor_logic_state_idle.h"
#include "logic_state/actor_logic_state_move.h"
#include "logic_state/actor_logic_state_attack.h"
#include "logic_state/actor_logic_state_incontrollable.h"
#include "logic_state/actor_logic_state_born.h"
#include "logic_state/actor_logic_state_dead.h"

#include "game/actor/actor.h"

namespace actor {
  const int LogicState::STATE_TYPE = kActorLogicState;

  LogicState* GetActorLogicState(eActorLogicState state_type)
  {
    switch(state_type)
    {
    case kActorLogicStateIdle:
      return LogicStateIdle::Instance();
      break;
    case kActorLogicStateMove:
      return LogicStateMove::Instance();
      break;
    case kActorLogicStateAttack:
      return LogicStateAttack::Instance();
      break;
    case kActorLogicStateIncontrollable:
      return LogicStateIncontrollable::Instance();
      break;
    case kActorLogicStateBorn:
      return LogicStateBorn::Instance();
      break;
    case kActorLogicStateDead:
      return LogicStateDead::Instance();
      break;
    default:
      return 0;
      break;
    }
  }


  //{CONDITIONALLY} 
  //Update Attack/GuardTrigger
  bool CommonCheckGuardTrigger(Actor* actor)
  {
    if (actor->GetActorData()->GetControlData()->GetMaximumControlPriority() > kActorControlPriorityCheckGuardAuto)
      return false;

    ActorTrigger* guard_trigger = actor->GetActorData()->GetSkillData()->GetGuardTrigger();

    if (!guard_trigger) return false;

    guard_trigger->Update();
    
    if (guard_trigger->GetIsTriggered())
      //if (actor->GetActorData()->GetControlData()->GetTarget())
      actor->GetActorData()->GetControlData()->SetTarget(*(guard_trigger->GetTriggeredActorIdList()->begin()), kActorControlPriorityMoveAuto);
    
    return guard_trigger->GetIsTriggered();
  }

  /* attack trigger:
      if priority <= kActorControlPriorityCheckAttackAuto:
          will select any target from triggered list
      else
          meaning target is set by user, check only selected target
          or position is set by user, check no target
  */
  bool CommonCheckAttackTrigger(Actor* actor)
  {
    int target_actor_id = ACTOR_ID_INVALID;
    
    if (actor->GetActorData()->GetControlData()->GetMaximumControlPriority() > kActorControlPriorityCheckAttackAuto)
    {
      if (actor->GetActorData()->GetControlData()->IsSetTarget())
        target_actor_id = actor->GetActorData()->GetControlData()->GetTarget(); //user set target
      else
        return false;//user set position, ignore all
    }
    
    ActorSkillData* skill_data = actor->GetActorData()->GetSkillData();
    skill_data->UpdateNormalAttackTrigger();

    if (skill_data->GetNormalAttackIsTriggered())
    {
      //if (actor->GetActorData()->GetControlData()->GetTarget())
      int triggered_actor_id = *(skill_data->GetTriggeredAttackTrigger()->GetTriggeredActorIdList()->begin());

      if (target_actor_id != ACTOR_ID_INVALID && triggered_actor_id != target_actor_id)
        return false; //target is user selected, but not show
      else
        actor->GetActorData()->GetControlData()->SetTarget(triggered_actor_id, kActorControlPriorityMoveAuto);
    }
    return skill_data->GetNormalAttackIsTriggered();
  }

} // namespace actor