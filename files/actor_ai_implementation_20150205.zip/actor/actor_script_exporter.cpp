#include "actor_script_exporter.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  ActorScriptExporter::ActorScriptExporter(Actor* actor)
    :actor_(actor)
  {

  }

  ActorScriptExporter::~ActorScriptExporter()
  {

  }

  //export to lua // common static
  
  cocos2d::CCPoint ActorScriptExporter::GetPositionFromGrid(int grid_x, int grid_y)
  {
    return actor::GetPositionFromGrid(grid_x, grid_y);
  }
  cocos2d::CCPoint ActorScriptExporter::GetGridFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridFromPosition(position);
  }
  int ActorScriptExporter::GetGridXFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridXFromPosition(position);
  }
  int ActorScriptExporter::GetGridYFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridYFromPosition(position);
  }


  void ActorScriptExporter::ScriptAssert(bool expression, const std::string& message)
  {
    assert(expression);
    printf("[ActorScriptExporter][Assert] %s", message.c_str());
  }


  //export to lua // actor based

  float ActorScriptExporter::GetActorHealthPercent()
  {
    assert(actor_);
    return actor_->GetActorData()->GetBasicData()->GetCurrentHealth() * 100.0f / actor_->GetActorData()->GetBasicData()->GetTotalHealth();
  }

  cocos2d::CCPoint ActorScriptExporter::GetActorPosition()
  {
    assert(actor_);
    return actor_->GetActorData()->GetMotionData()->GetPosition();
  }



  void ActorScriptExporter::SetActorIsAutoGuard(bool is_auto)
  {
    assert(actor_);
    actor_->GetActorData()->GetControlData()->SetIsAutoGuard(is_auto);
  }


  ActorControlDataBase* ActorScriptExporter::GetActorRoutineControlData()
  {
    assert(actor_);
    return actor_->GetControl()->GetActorControlRoutine()->GetRoutineControlData();
  }


  void ActorScriptExporter::ActorScriptAssert(bool expression, const std::string& message)
  {
    assert(actor_);
    ScriptAssert(expression, message);
  }
} // namespace actor