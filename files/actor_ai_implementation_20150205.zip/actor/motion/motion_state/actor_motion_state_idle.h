#ifndef ACTOR_MOTION_STATE_IDLE_H
#define ACTOR_MOTION_STATE_IDLE_H

#include "game/actor/motion/actor_motion_state.h"


namespace actor {

  class MotionStateIdle : public MotionState
  {
  public:
    virtual ~MotionStateIdle() {}
    static MotionStateIdle* Instance();
    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);
    
    void CheckWeakStatus(Actor* actor);
  private:
    MotionStateIdle() {}
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_IDLE_H
