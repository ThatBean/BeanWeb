﻿#include "actor_motion_state_machine.h"

#include "game/actor/actor.h"

namespace actor {

  eActorMotionState MotionStateMachine::GetCurrentMotionStateType()
  {
    if (current_state_)
    {
      return eActorMotionState(current_state_->GetStateType());
    }
    return kActorMotionState;
  }


  void MotionStateMachine::Update(float delta_time)
  { 
    if (current_state_) 
      current_state_->Update(entity_, delta_time); 
  }

  void MotionStateMachine::ChangeState(State<Actor>* next_state)
  {
    if (current_state_) 
      current_state_->OnExit(entity_);
    last_state_ = current_state_;
    if (next_state) 
      next_state->OnEnter(entity_);
    current_state_ = next_state;
  }

} // namespace actor