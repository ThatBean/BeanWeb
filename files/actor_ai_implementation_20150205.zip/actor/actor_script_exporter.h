#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorControlDataBase;

  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

    //export to lua for data
  public:
    static cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
    static cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
    static int GetGridXFromPosition(cocos2d::CCPoint position);
    static int GetGridYFromPosition(cocos2d::CCPoint position);

    static void ScriptAssert(bool expression, const std::string& message);

  public:
    float GetActorHealthPercent();  //
    cocos2d::CCPoint GetActorPosition();
    ActorControlDataBase* GetActorRoutineControlData();

    void SetActorIsAutoGuard(bool is_auto);
    
    void ActorScriptAssert(bool expression, const std::string& message);
    //export to lua for data

  private:
    Actor* actor_;  //keep actor pointer
  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H