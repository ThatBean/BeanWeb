#ifndef ACTOR_LOGIC_DATA_H
#define ACTOR_LOGIC_DATA_H

namespace actor {

  class Actor;
  class ActorTrigger;
  
  
  class ActorLogicData
  {
  public:
    ActorLogicData();
    ~ActorLogicData();
    
    void Init();


    void SetIsStateIdle(bool is_state_idle) { is_state_idle_ = is_state_idle; }
    bool GetIsStateIdle() { return is_state_idle_; }

    void SetIsMuteMove(bool is_mute_move) { is_mute_move_ = is_mute_move; }
    bool GetIsMuteMove() { return is_mute_move_; }
    
    void SetIsMuteAttack(bool is_mute_attack) { is_mute_attack_ = is_mute_attack; }
    bool GetIsMuteAttack() { return is_mute_attack_; }

    void SetIsImmuneIncontrollable(bool is_immune_incontrollable) { is_immune_incontrollable_ = is_immune_incontrollable; }
    bool GetIsImmuneIncontrollable() { return is_immune_incontrollable_; }

  private:
    bool is_state_idle_;

    bool is_mute_move_;
    bool is_mute_attack_;

    bool is_immune_incontrollable_;
  };
} // namespace actor


#endif // ACTOR_LOGIC_DATA_H