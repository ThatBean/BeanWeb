#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger.h"

namespace actor {
  //ActorData
  ActorData::ActorData(Actor* actor)
    :actor_(actor),
    specified_data_(NULL)
  {
    Init();
  }

  ActorData::~ActorData()
  {
    delete basic_data_;
    delete skill_data_;
    delete buff_data_;

    delete user_control_data_;
    delete control_data_;
    delete logic_data_;
    delete motion_data_;

    if (specified_data_) delete specified_data_;
  }

  void ActorData::Init()
  {
    basic_data_ = new ActorBasicData();
    skill_data_ = new ActorSkillData();
    buff_data_ = new ActorBuffData();

    user_control_data_ = new ActorControlDataBase();
    control_data_ = new ActorControlData();
    logic_data_ = new ActorLogicData();
    motion_data_ = new ActorMotionData();

    ResetSpecifiedData();
  }

  void ActorData::Update(float delta_time)
  {
    basic_data_->Update(delta_time);
    
    user_control_data_->Update(delta_time);
    control_data_->Update(delta_time);

    if (specified_data_) specified_data_->Update(delta_time);
  }

  void ActorData::ResetSpecifiedData()
  {
    if (specified_data_) delete specified_data_;

    switch (GetBasicData()->GetActorType())
    {
    case kActorCharacter:
      specified_data_ = new ActorSpecifiedDataCharacter(actor_);
      break;
    case kActorEnemyPawn:
      specified_data_ = new ActorSpecifiedDataEnemyPawn(actor_);
      break;
    case kActorEnemyBoss:
      specified_data_ = new ActorSpecifiedDataEnemyBoss(actor_);
      break;
    default:
      specified_data_ = NULL;
      break;
    }
  }

  void ActorData::SetActorAdapter(ActorAdapter* actor_adapter)
  {
    basic_data_->SetActorAdapter(actor_adapter);
    skill_data_->SetActorAdapter(actor_adapter);
    buff_data_->SetActorAdapter(actor_adapter);
    motion_data_->SetActorAdapter(actor_adapter);
  }

  //ActorData

} // namespace actor