#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/battle/damage/damage_constants.h"

namespace actor {

  const unsigned long ACTOR_BUFF_FLAG_MOVE_AUTO = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft;

  const unsigned long ACTOR_BUFF_FLAG_MOVE_LOCK =0
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | taomee::battle::kDamageIntertwine;

  const unsigned long ACTOR_BUFF_FLAG_ANIMATION_LOCK =0
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction;

  const unsigned long ACTOR_BUFF_FLAG_COLORED = 0
    | taomee::battle::kDamageFireProperty
    | taomee::battle::kDamageFireProperty;

  const unsigned long ACTOR_BUFF_FLAG_INCONTROLLABLE = ACTOR_BUFF_FLAG_MOVE_AUTO | ACTOR_BUFF_FLAG_MOVE_LOCK;


  ActorBuffData::ActorBuffData()
    : is_buff_finished_(true),
    is_incontrollable_finished_(true)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }

  void ActorBuffData::UpdateIncontrollable()
  {
    bool is_incontrollable = ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_INCONTROLLABLE) != 0);

    SetIsIncontrollableFinished(is_incontrollable == false);
  }



  //currently in adapter
  uint_32 ActorBuffData::GetActorBuffFlag() 
  { 
    return actor_adapter_->battle_status_flag(); 
  }

} // namespace actor