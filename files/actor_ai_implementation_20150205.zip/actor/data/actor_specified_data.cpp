#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  bool ActorSpecifiedData::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionInGrid(position);
  }

  bool ActorSpecifiedData::IsGridValid(cocos2d::CCPoint grid_position)
  {
    return grid_position.x >= 1
      && grid_position.x <= 6
      && grid_position.y >= 1
      && grid_position.y <= 3;
  }


  cocos2d::CCPoint ActorSpecifiedData::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
      return SnapToGrid(position);
    else
      return SnapYToGrid(position);
  }

  bool ActorSpecifiedData::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    if (IsGridValid(grid_position))
    {
      switch (GetActorHomeDirection())
      {
      case kActorAnimationDirectionLeft:
        return grid_position.x <= 3;
        break;
      case  kActorAnimationDirectionRight:
        return grid_position.x >= 4;
        break;
      default:
        assert(false);
        return true;
        break;
      }
    }
    return false;
  }


  std::list<cocos2d::CCPoint>* ActorSpecifiedData::GetValidGridList(std::map<Actor*, cocos2d::CCPoint>* actor_grid_map)  //need delete after use
  {
    std::list<cocos2d::CCPoint>* valid_grid_list = new std::list<cocos2d::CCPoint>;
    int grid_position_taken[6][3] = {0};

    std::map<Actor*, cocos2d::CCPoint>::iterator iterator = actor_grid_map->begin();
    while (iterator != actor_grid_map->end())
    {
      Actor* ref_actor = iterator->first;

      if (ref_actor != actor_)
      {
        if (ref_actor->GetActorData()->GetSpecifiedData()->GetActorHomeDirection() == GetActorHomeDirection()
          && ref_actor->GetLogicStateMachine()->GetCurrentLogicStateType() == kActorLogicStateIdle)
        {
          cocos2d::CCPoint ref_grid_position = iterator->second;
          grid_position_taken[(int)(ref_grid_position.x - 1)][(int)(ref_grid_position.y - 1)] += 1;
        }
      }

      ++iterator;
    }

    //search nearest valid grid
    int i, j;
    int start_grid_x = (GetActorHomeDirection() == kActorAnimationDirectionLeft) ? 1 : 4;
    for (i = start_grid_x; i <= start_grid_x + 2; i++)
    {
      for (j = 1; j <= 3; j++)
      {
        cocos2d::CCPoint grid_position = ccp(i, j);
        if (grid_position_taken[i - 1][j - 1] == 0 && IsGridIdleValid(grid_position))
        {
          valid_grid_list->push_back(grid_position);
        }
      }
    }

    return valid_grid_list;
  }

  cocos2d::CCPoint ActorSpecifiedData::GetValidGrid(
    cocos2d::CCPoint preferred_grid_position, 
    std::map<Actor*, cocos2d::CCPoint>* actor_grid_map, 
    eActorSpecifiedGridPreferenceType prefer_type)
  {
    std::list<cocos2d::CCPoint>* valid_grid_list = GetValidGridList(actor_grid_map);
    
    bool is_backup_grid_position_valid = false;
    cocos2d::CCPoint backup_grid_position;
    float nearest_valid_grid_distance = 99999;

    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;

        if (IsGridIdleValid(grid_position))
        {
          float distance = preferred_grid_position.getDistance(grid_position);

          if (distance == 0)
          {
            backup_grid_position = preferred_grid_position;
            is_backup_grid_position_valid = true;
            break;  //stop searching
          }

          bool is_keep = false;

          switch (prefer_type)
          {
          case kActorSpecifiedGridPreferNear:
            is_keep = nearest_valid_grid_distance > distance;
            break;
          case kActorSpecifiedGridPreferNearX:
            if (abs(backup_grid_position.x - preferred_grid_position.x) < abs(grid_position.x - preferred_grid_position.x))
            {
              if (abs(backup_grid_position.x - preferred_grid_position.x) == abs(grid_position.x - preferred_grid_position.x))
                is_keep = nearest_valid_grid_distance > distance;
              else
                is_keep = true;
            }
            break;
          case kActorSpecifiedGridPreferNearY:
            if (abs(backup_grid_position.y - preferred_grid_position.y) < abs(grid_position.y - preferred_grid_position.y))
            {
              if (abs(backup_grid_position.y - preferred_grid_position.y) == abs(grid_position.y - preferred_grid_position.y))
                is_keep = nearest_valid_grid_distance > distance;
              else
                is_keep = true;
            }
            break;
          }

          if (is_keep)
          {
            nearest_valid_grid_distance = distance;
            backup_grid_position = grid_position;
          }
          is_backup_grid_position_valid = true;
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    if (is_backup_grid_position_valid)
    {
      (*actor_grid_map)[actor_] = backup_grid_position;  //prevent another actor move to 
      return backup_grid_position;
    }

    //so sad the lame makeshift position
    return ccp(GetActorHomeDirection() == kActorAnimationDirectionLeft ? 2 : 5, 2);
  }

  //ActorSpecifiedDataCharacter================================================================
  ActorSpecifiedDataCharacter::ActorSpecifiedDataCharacter(Actor* actor)
    :ActorSpecifiedData(actor),
    is_limit_grid_x_(false)
  {
  }

  bool ActorSpecifiedDataCharacter::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
      return is_limit_grid_x_ ? GetGridXFromPosition(position) != 1 : true;
    else
      return false;
  }

  bool ActorSpecifiedDataCharacter::IsGridValid(cocos2d::CCPoint grid_position)
  {
    bool is_valid = ActorSpecifiedData::IsGridValid(grid_position);
    if (is_valid)
      return is_limit_grid_x_ ? grid_position.x > 1 : true;
    else
      return false;
  }

  void ActorSpecifiedDataCharacter::SetLastIdleGrid(cocos2d::CCPoint grid_position) 
  { 
    if (IsGridIdleValid(grid_position))
      last_idle_grid_position_ = grid_position; 
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::GetValidGrid()
  {
    if (IsGridIdleValid(last_idle_grid_position_) == false)
    {
      last_idle_grid_position_ = ccp(GetActorHomeDirection() == kActorAnimationDirectionLeft ? 2 : 5, 2);
    }

    return ActorSpecifiedData::GetValidGrid(
      last_idle_grid_position_, 
      actor_->GetActorExtEnv()->GetActorGridMap(), 
      kActorSpecifiedGridPreferNear);
  }

  //ActorSpecifiedDataCharacter================================================================

  //ActorSpecifiedDataEnemyPawn================================================================
  ActorSpecifiedDataEnemyPawn::ActorSpecifiedDataEnemyPawn(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyPawn::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
      return true;
    else
    {
      return IsPositionYInGrid(position.y);
    }
  }
  //ActorSpecifiedDataEnemyPawn================================================================

  //ActorSpecifiedDataEnemyBoss================================================================
  ActorSpecifiedDataEnemyBoss::ActorSpecifiedDataEnemyBoss(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyBoss::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
      return true;
    else
    {
      return IsPositionYInGrid(position.y);
    }
  }
  //ActorSpecifiedDataEnemyBoss================================================================
} // namespace actor