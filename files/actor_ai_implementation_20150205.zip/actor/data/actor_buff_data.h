#ifndef ACTOR_BUFF_DATA_H
#define ACTOR_BUFF_DATA_H

#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;

  enum eActorIncontrollableMotionType
  {
    kActorIncontrollableMotionFreezed,  //Animation Stopped, No Move, No Direction Change
    kActorIncontrollableMotionDelayed,  //Animation Idle, No Move, No Direction Change
    kActorIncontrollableMotionRunHome,  //Animation Move, Move To Left/Right Most, Normal Direction Change
    kActorIncontrollableMotionPushBack, //Animation Stopped, Move Backwards a little, No Direction Change
    kActorIncontrollableMotion
  };

  enum eActorBuffColorType  //These Type will be converted to color or shader
  {
    kActorBuffColorFreezed,
    kActorBuffColorOnFire,
    kActorBuffColorPosioned,
    kActorBuffColorShocked,
    kActorBuffColorStoned,
    kActorBuffColorEtc,
    kActorBuffColor
  };

  enum eActorBuffAnimationType  //These will be overload animation, mostly used in motion Incontrollable
  {
    kActorBuffAnimationIdle,
    kActorBuffAnimationMove,
    kActorBuffAnimationAttacked,
    kActorBuffAnimationEtc,
    kActorBuffAnimation
  };

  class ActorBuffData
  {
  public:
    ActorBuffData();
    ~ActorBuffData();

    void UpdateIncontrollable();

    void SetIsBuffFinished(bool is_buff_finished) { is_buff_finished_ = is_buff_finished; }
    bool GetIsBuffFinished() { return is_buff_finished_; }

    void SetIsIncontrollableFinished(bool is_incontrollable_finished) { is_incontrollable_finished_ = is_incontrollable_finished; }
    bool GetIsIncontrollableFinished() { return is_incontrollable_finished_; }

    void SetIncontrollableMotion(eActorIncontrollableMotionType incontrollable_motion) { incontrollable_motion_ = incontrollable_motion; }
    eActorIncontrollableMotionType GetIncontrollableMotion() { return incontrollable_motion_; }

    //currently in adapter
    uint_32 GetActorBuffFlag();

    //messy but messy, link MoveObject data
    void SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }
  
  private:
    bool is_buff_finished_;
    bool is_incontrollable_finished_;

    uint_32 actor_buff_flag_;

    //Only When State Incontrollable
    eActorIncontrollableMotionType incontrollable_motion_;

    //below data is used to customize buff animation, should be maintained by buff system
    //These can be applied to all motion state
    //These only change animation color or add effect animation
    //For buff color
    bool is_set_color_;
    bool is_set_shader_;

    //For buff effect
    bool is_set_effect_;  
    //add more below
    //add more below
    //add more below
    //add more below
    //add more below

  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*       actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_BUFF_DATA_H