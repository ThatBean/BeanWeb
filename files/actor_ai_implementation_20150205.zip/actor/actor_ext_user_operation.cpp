#include "actor_ext_user_operation.h"

#include "actor.h"
#include "actor_ext_env.h"

namespace actor {
  ActorExtUserOperation::ActorExtUserOperation(ActorExtEnv* actor_ext_env)
  {
    actor_ext_env_ = actor_ext_env;
    Clear();
  }


  void ActorExtUserOperation::Clear()
  {
    operation_state_ = kActorExtUserOperation;
    is_operation_from_set_ = false;
    is_operation_to_set_ = false;
  }

  eActorExtUserOperationType ActorExtUserOperation::UpdateTouchStart(cocos2d::CCPoint touch_position)
  {
    //currently touch must start from actor
    Actor* touched_actor = actor_ext_env_->GetActorByPosition(touch_position);

    if (touched_actor != NULL   //not deleted
      && touched_actor->GetActorData()->GetBasicData()->GetIsDeadStatus() != true  //not dead
      && (touched_actor->GetControl()->GetControlType() & kActorControlManual))  //accept manual control
    {
      SetTouchFromData(touched_actor->GetActorId(), touch_position);
      operation_state_ = kActorExtUserOperationSelected;
      return operation_state_;
    }

    Clear();
    return kActorExtUserOperationCanceled;
  }

  eActorExtUserOperationType ActorExtUserOperation::UpdateTouchMove(cocos2d::CCPoint touch_position)
  {
    Actor* from_actor = actor_ext_env_->GetActorById(operation_from_actor_id_);
    if (!from_actor 
      || from_actor->GetIsActorActive() == false
      || from_actor->GetActorData()->GetBasicData()->GetIsDeadStatus() == true)  //dead
    {
      //actor dead, cancel touch
      Clear();
      return kActorExtUserOperationCanceled;
    }


    Actor* touched_actor = actor_ext_env_->GetActorByPosition(touch_position);

    if (touched_actor != NULL   //not deleted
      && touched_actor != from_actor   //not the same as "to_actor"
      && touched_actor->GetActorData()->GetBasicData()->GetIsDeadStatus() != true)  //not dead
    {
      SetTouchToData(touched_actor->GetActorId(), touch_position);

      bool is_same_faction = (
          from_actor->GetActorData()->GetBasicData()->GetFactionType() 
          == touched_actor->GetActorData()->GetBasicData()->GetFactionType()
        );

      if (is_same_faction)
        operation_state_ = kActorExtUserOperationSwitch;
      else
        operation_state_ = kActorExtUserOperationAttack;
      return operation_state_;
    }

    if (from_actor->GetActorData()->GetSpecifiedData()->IsPositionValid(touch_position)) //actor to valid moving position
    {
      SetTouchToData(ACTOR_ID_INVALID, from_actor->GetActorData()->GetSpecifiedData()->PositionCorrection(touch_position));
      operation_state_ = kActorExtUserOperationMove;
      return operation_state_;
    }
    else
    {
      // maye be movee or still attack/switch
      return kActorExtUserOperationSkip;
    }

    //invalid moving position
    Clear();
    return kActorExtUserOperationCanceled;
  }

  eActorExtUserOperationType ActorExtUserOperation::UpdateTouchEnd()
  {
    Actor* from_actor = actor_ext_env_->GetActorById(operation_from_actor_id_);
    if (!from_actor)
    {
      //actor dead, cancel touch
      Clear();
      return kActorExtUserOperationCanceled;
    }
    
    switch (operation_state_)
    {
    case kActorExtUserOperationAttack:
      from_actor->GetActorData()->GetUserControlData()->SetTarget(operation_to_actor_id_, kActorControlPriorityMoveManual);
      break;
    case kActorExtUserOperationMove:
      from_actor->GetActorData()->GetUserControlData()->SetPosition(operation_to_position_, kActorControlPriorityMoveManual);
      break;
    case kActorExtUserOperationSwitch:
      {
        Actor* to_actor = actor_ext_env_->GetActorById(operation_to_actor_id_);
        if (!to_actor)
        {
          //actor dead, cancel touch
          Clear();
          return kActorExtUserOperationCanceled;
        }
        from_actor->GetActorData()->GetUserControlData()->SetPosition(to_actor->GetActorData()->GetMotionData()->GetPosition(), kActorControlPriorityMoveManual);
        to_actor->GetActorData()->GetUserControlData()->SetPosition(from_actor->GetActorData()->GetMotionData()->GetPosition(), kActorControlPriorityMoveManual);
      }
      break;
    default:
      assert(false);
      break;
    }

    Clear();
    return kActorExtUserOperationFinished;
  }


  void ActorExtUserOperation::SetTouchFromData(int actor_id, cocos2d::CCPoint position)
  {
    is_operation_from_set_ = true;
    operation_from_actor_id_ = actor_id;
    operation_from_position_ = position;

    //in case
    operation_to_actor_id_ = ACTOR_ID_INVALID;
    operation_to_position_ = position;
  }

  void ActorExtUserOperation::SetTouchToData(int actor_id, cocos2d::CCPoint position)
  {
    is_operation_to_set_ = true;
    operation_to_actor_id_ = actor_id;
    operation_to_position_ = position;
  }

} // namespace actor