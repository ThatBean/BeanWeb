#ifndef ACTOR_CONTROL_H
#define ACTOR_CONTROL_H

#include "actor_control_routine.h"

#include "game/actor/logic/actor_logic_state.h"
#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  class ActorControlDataBase;

  enum eActorControlType
  {
    kActorControlManual   = 1 << 0,   //will check user input
    kActorControlAuto     = 1 << 1,   //will issue command automatically
    kActorControlSemiAuto = (1 << 0) + (1 << 1),   //will issue command automatically
    kActorControl = 0
  };

  //enum eActorControlManualType

  enum eActorControlAutoType
  {
    kActorControlAutoCharacter,
    kActorControlAutoEnemyPawn,
    kActorControlAutoEnemyBoss,
    kActorControlAutoType
  };

  class ActorControl
  {
  public:
    ActorControl(Actor* actor);
    ~ActorControl();

    void Update(float delta_time);

    eActorControlType GetControlType() { return actor_control_type_; };
    void SetControlType(eActorControlType control_type) { actor_control_type_ = control_type; };

    void SetActorControlRoutine(ActorControlRoutine* actor_control_routine);
    ActorControlRoutine* GetActorControlRoutine();

  protected:
    void UpdateManual();
    void UpdateAuto();
    void UpdateBuff();

    //void UpdateAutoAttack();
    void UpdateAutoGuard();

    void ApplyControlData(ActorControlDataBase* from_control_data, ActorControlDataBase* to_control_data);

    eActorLogicState DecideLogicState();  //check set priority
    bool ControlLogicStateChange(eActorLogicState new_logic_state); //check if exterior logic state change valid, if true, change

  private:
    Actor*               actor_;
    eActorControlType    actor_control_type_;

    //if change of logic state needed
    eActorLogicState     result_logic_state_type_;
    
    ActorControlRoutine* actor_control_routine_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_H
