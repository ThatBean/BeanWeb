#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

namespace actor {


  //#####################################################################


  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor),
    actor_control_type_(kActorControl),
    actor_control_routine_(NULL)
  {

  }

  ActorControl::~ActorControl()
  {
    if (actor_control_routine_)
    {
      actor_control_routine_->Clear();
      delete actor_control_routine_;
    }
  }

  void ActorControl::Update(float delta_time)
  {
    if (!actor_control_type_)
    {
      assert(false);
      return;
    }

    if (actor_control_routine_)
      actor_control_routine_->Update(delta_time);

    if (actor_control_type_ & kActorControlManual) UpdateManual();
    if (actor_control_type_ & kActorControlAuto) UpdateAuto();
    
    UpdateBuff();

    result_logic_state_type_ = DecideLogicState();
    if (ControlLogicStateChange(result_logic_state_type_))
      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type_));
  }

  void ActorControl::UpdateManual()
  {
    ActorControlDataBase* user_control_data = actor_->GetActorData()->GetUserControlData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
    
    ApplyControlData(user_control_data, control_data);
  }

  void ActorControl::UpdateAuto()
  {
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() != kActorLogicStateIdle)
      return;

    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    //check and apply routine control
    if (actor_control_routine_)
    {
      ActorControlDataBase* routine_control_data = actor_control_routine_->GetRoutineControlData();
      ApplyControlData(routine_control_data, control_data);
    }

//     if (control_data->GetIsAutoAttack())
//       UpdateAutoAttack();

    if (control_data->GetIsAutoGuard())
      UpdateAutoGuard();
  }

  void ActorControl::UpdateBuff()
  {
    actor_->GetActorData()->GetBuffData()->UpdateIncontrollable();
    if (actor_->GetActorData()->GetBuffData()->GetIsIncontrollableFinished() == false)
    {
      ActorControlData* control_data = actor_->GetActorData()->GetControlData();
      control_data->SetIncontrollable(kActorControlIncontrollableBuff, kActorControlPriorityIncontrollable);
    }
  }

  void ActorControl::UpdateAutoGuard()
  {
    if (actor_->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserSupport
      && GetIsAllyActorAuto() == false)  //user actor auto subject to battle control
      return;
    
    ActorTrigger* guard_trigger = actor_->GetActorData()->GetControlData()->GetGuardTriggerAuto();
    if (guard_trigger)
    {
      guard_trigger->Update();
      if (guard_trigger->GetIsTriggered())
      {
        int target_id = *(guard_trigger->GetTriggeredActorIdList()->begin());
        Actor* target_actor = *(guard_trigger->GetTriggeredActorList()->begin());
        //move to target

        switch (actor_->GetActorData()->GetBasicData()->GetCareerType())
        {
        case kActorCareerWarrior:
        case kActorCareerKnight:
          //for melee character
          actor_->GetActorData()->GetControlData()->SetTarget(target_id, kActorControlPriorityMoveAuto);
          break;
        case kActorCareerArcher:
        case kActorCareerWizard:
        case kActorCareerPriest:
          //for ranged character
          {
            std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

            bool is_target_at_grid_y[3] = {false, false, false};
            
            std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
            while (iterator != triggered_actor_list->end())
            {
              Actor* target_actor = *iterator;
              int target_grid_y = GetGridYFromPosition(target_actor->GetActorData()->GetMotionData()->GetPosition());
              is_target_at_grid_y[target_grid_y - 1] = true;
              ++iterator;
            }

            cocos2d::CCPoint actor_grid = GetGridFromPosition(actor_->GetActorData()->GetMotionData()->GetPosition());
            if (is_target_at_grid_y[(int)(actor_grid.y) - 1])
              return; // target in row

            //find best grid
            bool is_target_grid_position_valid = false;
            float target_grid_distance_min = 99999;
            cocos2d::CCPoint target_grid_position;

            std::list<cocos2d::CCPoint>* valid_grid_list = actor_->GetActorData()->GetSpecifiedData()->GetValidGridList(actor_->GetActorExtEnv()->GetActorGridMap());
            if (valid_grid_list->size() > 0)
            {
              std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
              while (iterator != valid_grid_list->end())
              {
                cocos2d::CCPoint grid_position = *iterator;
                if (is_target_at_grid_y[(int)(grid_position.y) - 1])
                {
                  float target_grid_distance = grid_position.getDistance(actor_grid);
                  if (target_grid_distance < target_grid_distance_min)
                  {
                    is_target_grid_position_valid = true;
                    target_grid_distance_min = target_grid_distance;
                    target_grid_position = grid_position;
                  }
                }

                ++iterator;
              }
            }

            delete valid_grid_list;

            if (is_target_grid_position_valid)
              actor_->GetActorData()->GetControlData()->SetPosition(GetPositionFromGrid(target_grid_position), kActorControlPriorityMoveAuto);
          }
          break;
        }
      }
    }
  }


  void ActorControl::ApplyControlData(ActorControlDataBase* from_control_data, ActorControlDataBase* to_control_data)
  {
    if (!from_control_data || !to_control_data)
    {
      assert(false);
      return;
    }

    if (from_control_data->IsSet())
    {
      if (from_control_data->IsSetPosition())
      {
        cocos2d::CCPoint set_position = from_control_data->GetPosition();
        eActorControlPriority control_priority = from_control_data->GetPositionPriority();

        //check position
        to_control_data->SetPosition(set_position, control_priority);
        if (to_control_data->GetTargetPriority() <= control_priority)
          to_control_data->ResetTarget();
        //check position
      }

      if (from_control_data->IsSetTarget())
      {
        int set_target = from_control_data->GetTarget();
        eActorControlPriority control_priority = from_control_data->GetTargetPriority();

        //check target
        to_control_data->SetTarget(set_target, control_priority);
        if (to_control_data->GetPositionPriority() <= control_priority)
          to_control_data->ResetPosition();
        //check target
      }

      if (from_control_data->IsSetSkill())
      {
        int set_skill = from_control_data->GetSkill();
        eActorControlPriority control_priority = from_control_data->GetSkillPriority();

        //check skill
        to_control_data->SetSkill(set_skill, control_priority);

        if (control_priority == kActorControlPriorityAttackSpecialManual)
        {
          //flush actor logic state, re-enter to overload current skill
          actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
        }
        //check skill
      }

      if (from_control_data->IsSetIncontrollable())
      {
        eActorControlIncontrollableType set_incontrollable = from_control_data->GetIncontrollable();
        eActorControlPriority control_priority = from_control_data->GetIncontrollablePriority();

        //check incontrollable
        to_control_data->SetIncontrollable(set_incontrollable, control_priority);
        //check incontrollable
      }

      from_control_data->Reset(); //clear user data
    }
  }




  eActorLogicState ActorControl::DecideLogicState()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    switch (control_data->GetMaximumControlPriority())
    {
    case kActorControlPriorityMoveAuto:
    case kActorControlPriorityMoveManual:
      if (control_data->IsSetTarget()) control_data->ResetPosition();
      if (control_data->IsSetPosition()) control_data->ResetTarget(); //no use
      return kActorLogicStateMove;
      break;
    case kActorControlPriorityAttackNormalAuto:
    case kActorControlPriorityAttackPowerAuto:
    case kActorControlPriorityAttackNormalManual:
    case kActorControlPriorityAttackSpecialManual:
      control_data->ResetPosition();
      control_data->ResetTarget();
      return kActorLogicStateAttack;
      break;
    case kActorControlPriorityIncontrollable:
      control_data->ResetPosition();
      control_data->ResetTarget();
      control_data->ResetSkill();
      return kActorLogicStateIncontrollable;
      break;
    case kActorControlPriorityMin:
      return kActorLogicState;  //nothing set
      break;
    case kActorControlPriorityMax:
    default:
      assert(false);  //error priority
      break;
    }

    return kActorLogicState;
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState new_logic_state)
  {
    if (new_logic_state == kActorLogicState)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == kActorLogicStateDead)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == new_logic_state)
      return false;

    ActorLogicData* logic_data = actor_->GetActorData()->GetLogicData();

    switch(new_logic_state)
    {
    case kActorLogicStateMove:
      if (logic_data->GetIsMuteMove())
        return false;
      break;
    case kActorLogicStateAttack:
      if (logic_data->GetIsMuteAttack())
        return false;
      break;
    case kActorLogicStateIncontrollable:
      //if (logic_data->GetIsMuteAttack())
        //return false;
      break;
    default:
      break;
    }

    return true;
  }


  void ActorControl::SetActorControlRoutine(ActorControlRoutine* actor_control_routine)
  {
    if (actor_control_routine_) 
    {
      actor_control_routine_->Clear();
      delete actor_control_routine_;
    }
    actor_control_routine_ = actor_control_routine;
  }
  ActorControlRoutine* ActorControl::GetActorControlRoutine()
  {
    return actor_control_routine_;
  }
} // namespace actor