#include "actor_ext_env.h"

#include "actor.h"
#include "actor_ext_user_operation.h"

//#include "game/battle/tiled_map/coordinate_helper.h"

namespace actor {
    ActorExtEnv::ActorExtEnv()
      :actor_next_valid_id_(1)
    {
      actor_map_.clear();
      actor_id_list_.clear();
      actor_ext_user_operation_ = new ActorExtUserOperation(this);

      actor_focus_map_.clear();
    }

    ActorExtEnv::~ActorExtEnv()
    {
      Clear();
    }

    void ActorExtEnv::Clear()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        
        //delete actor;

        ++iterator;
      }

      actor_map_.clear();
      actor_id_list_.clear();

      actor_focus_map_.clear();
    }


    void ActorExtEnv::Update(float delta_time)
    {
      delta_time = delta_time > 0.05f ? 0.05f : delta_time; //prevent debug lag
      
      //update grid
      UpdateActorGridMap();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        if (actor->GetIsActorActive() == true)
          actor->Update(delta_time);

        ++iterator;
      }
    }

    int ActorExtEnv::AddActor(Actor* actor) //will return actor_id
    {
      int actor_id = actor_next_valid_id_;
      
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      
      AddActor(actor_id, actor);
      return actor_id;
    }

    void ActorExtEnv::AddActor(int actor_id, Actor* actor) //alternative, predefined actor_id
    {
      assert(actor_map_.find(actor_id) == actor_map_.end());

      if (actor->GetActorId() > 0)
      {
        RemoveActor(actor->GetActorId());
      }

      actor->SetActorId(actor_id);
      actor->SetActorExtEnv(this);
      actor_map_[actor_id] = actor;
      actor_id_list_.push_back(actor_id);
      
      actor_next_valid_id_ = (actor_id > actor_next_valid_id_ ? actor_id : actor_next_valid_id_) + 1;
    }

    Actor* ActorExtEnv::RemoveActor(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        Actor* actor = actor_map_.at(actor_id);
        actor_map_.erase(actor_id);
        std::list<int>::iterator iterator = actor_id_list_.begin();
        while (iterator != actor_id_list_.end())
        {
          if (*iterator == actor_id)
          {
            actor_id_list_.erase(iterator);
            break;
          }
          ++iterator;
        }
        actor->SetActorExtEnv(NULL);
        return actor;
      }
      else
      {
        assert(false);
        return NULL;
      }
    }

    Actor* ActorExtEnv::GetActorById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
        return actor_map_.at(actor_id);
      else
        return NULL;
    }

    int ActorExtEnv::GetActorCount()
    {
      return actor_id_list_.size();
    }

    std::list<Actor*>* ActorExtEnv::GetActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetIsActorActive() == true 
          && IsPositionInGrid(actor->GetActorData()->GetMotionData()->GetPosition()) == true
          && actor->GetActorData()->GetBasicData()->GetIsDeadStatus() == false)
          actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }

    std::list<Actor*>* ActorExtEnv::GetAllActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }






    //should move ? should move
    //position/animation related
    Actor* ActorExtEnv::GetActorByPosition(cocos2d::CCPoint actor_position)
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        if (actor->GetActorData()->GetMotionData()->IsPointInAnimation(actor_position))
          return actor;

        ++iterator;
      }

      return NULL;
    }
    //position/animation related



    //for actor grid need, update every Update()
    void ActorExtEnv::UpdateActorGridMap()
    {
      actor_grid_map_.clear();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;
        cocos2d::CCPoint actor_position = actor->GetActorData()->GetMotionData()->GetPosition();

        if (actor->GetIsActorActive() && IsPositionInGrid(actor_position))
          actor_grid_map_[actor] = GetGridFromPosition(actor_position);

        ++iterator;
      }
    }
    bool ActorExtEnv::CheckActorGridOverlap(Actor* actor)
    {
      cocos2d::CCPoint actor_position = actor->GetActorData()->GetMotionData()->GetPosition();

      if (IsPositionInGrid(actor_position) == false)
        return false;
      
      cocos2d::CCPoint actor_grid_position = GetGridFromPosition(actor_position);
      eActorFactionType actor_faction = actor->GetActorData()->GetBasicData()->GetFactionType();

      std::map<Actor*, cocos2d::CCPoint>::iterator iterator = actor_grid_map_.begin();
      while (iterator != actor_grid_map_.end())
      {
        Actor* ref_actor = iterator->first;
        cocos2d::CCPoint ref_actor_grid_position = iterator->second;

        if (actor != ref_actor 
          && actor_grid_position.equals(ref_actor_grid_position))
        {
          if (actor_faction == ref_actor->GetActorData()->GetBasicData()->GetFactionType()
            && ref_actor->GetLogicStateMachine()->GetCurrentLogicStateType() == kActorLogicStateIdle)
            return true;
        }

        ++iterator;
      }

      return false;
    }



    //for skill pause need
    void ActorExtEnv::AddActorFocusById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        actor_focus_map_[actor_id] = actor_map_[actor_id];
      }
      else
        assert(false);
    }

    void ActorExtEnv::PauseActorByFocus()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;

        if (actor_focus_map_.find(actor_id) != actor_focus_map_.end())
          actor->SetIsActorPause(false);
        else
          actor->SetIsActorPause(true);

        ++iterator;
      }
    }

    void ActorExtEnv::ClearActorPause()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        actor->SetIsActorPause(false);

        ++iterator;
      }
    }
    //should move ? should move

} // namespace actor