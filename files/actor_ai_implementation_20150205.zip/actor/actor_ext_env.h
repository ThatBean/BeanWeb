#ifndef ACTOR_EXT_ENV_H
#define ACTOR_EXT_ENV_H

#include "cocos2d.h"
#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  class ActorExtUserOperation;


  const int ACTOR_ID_INVALID = -1;


  // the map / battlefield where actors live in (Actor Pool)
  class ActorExtEnv  //ActorExternalEnvironment
  {
  public:
    ActorExtEnv();
    ~ActorExtEnv();

    void      Clear();
    void      Update(float delta_time);

    int       AddActor(Actor* actor); //will return actor_id
    void      AddActor(int actor_id, Actor* actor); //alternative, predefined actor_id

    Actor*    RemoveActor(int actor_id);

    Actor*    GetActorById(int actor_id);
    
    int                       GetActorCount();
    std::list<Actor*>*        GetActorList();  //should delete after use, alive and in grid actor only, mostly used in trigger raw actor list
    std::list<Actor*>*        GetAllActorList();  //should delete after use, alive or dead

    std::map<int, Actor*>*    GetActorMap() { return &actor_map_; }
    std::list<int>*           GetActorIdList() { return &actor_id_list_; }
    
    //std::map<int, Actor*>*    GetActorListByType(specific_actor_type actor_type);
    //std::list<int>*           GetActorIdListByType(specific_actor_type actor_type);


    //for touch
    ActorExtUserOperation* GetUserOperation() { return actor_ext_user_operation_; }

  public:
    //should move ? should move
    //position/animation related
    Actor*    GetActorByPosition(cocos2d::CCPoint actor_position);
    //position/animation related

    //for actor grid need, update every Update()
    void UpdateActorGridMap();
    std::map<Actor*, cocos2d::CCPoint>* GetActorGridMap() { return &actor_grid_map_; }
    bool CheckActorGridOverlap(Actor* actor);


    //for skill pause need
    void AddActorFocusById(int actor_id);
    void ClearActorFocus() { actor_focus_map_.clear(); }
    void PauseActorByFocus();
    void ClearActorPause();
    //should move ? should move

  private:
    std::map<int, Actor*>     actor_map_;
    std::list<int>            actor_id_list_;
    int                       actor_next_valid_id_;

    ActorExtUserOperation*    actor_ext_user_operation_;

    //for actor grid need, update every Update()
    std::map<Actor*, cocos2d::CCPoint>     actor_grid_map_;


    //for skill pause need
    std::map<int, Actor*>     actor_focus_map_;
  };

} // namespace actor


#endif // ACTOR_EXT_ENV_H