#include "actor.h"

#include "logic/logic_state/actor_logic_state_idle.h"
#include "logic/logic_state/actor_logic_state_move.h"

#include "engine/base/basictypes.h"
//#include "engine/script/lua_tinker_manager.h"

namespace actor {


  Actor::Actor()
    :is_actor_active_(false),
    is_actor_pause_(false),
    actor_id_(ACTOR_ID_INVALID),
    actor_ext_env_(NULL),
    actor_script_exporter_(NULL)
  {
    Init();
  }

  Actor::~Actor()
  {
    if (actor_data_) delete actor_data_;
    if (actor_control_) delete actor_control_;
    if (logic_state_machine_) delete logic_state_machine_;
    if (motion_state_machine_)  delete motion_state_machine_;
    if (actor_script_exporter_) delete actor_script_exporter_;

    //the actor_ext_env_ will remove left actors when destructed
    // so if the actor is deleted, unlink from actor_ext_env_
    if (actor_ext_env_) actor_ext_env_->RemoveActor(actor_id_);
  }

  void Actor::Init()
  {
    actor_script_exporter_ = new ActorScriptExporter(this);

    actor_data_ = new ActorData(this);
    
    actor_control_ = new ActorControl(this);

    logic_state_machine_ = new LogicStateMachine(this);
    motion_state_machine_ = new MotionStateMachine(this);
    //logic_state_machine_->ChangeState(LogicStateIdle::Instance());
    //printf("%d", logic_state_machine_->GetCurrentLogicStateType());
    //int near_attacker_ai_stay_time_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/ai_config.lua", "GetNearAttackerAIStayTime");
  }

  void Actor::Update(float delta_time)
  {
    if (GetIsActorActive() == false)
      return;
    
    //update mostly timers in ActorData
    actor_data_->Update(delta_time);

    if (is_actor_pause_ == true)
      return;
    
    //deal with user control and auto
    actor_control_->Update(delta_time);
    
    //update actor-side buff data&logic
    //actor_buff_->Update(); 

    //update actor-side skill data&logic
    //actor_skill_->Update(); 
    
    //Manage Both Logic State & Motion State 
    logic_state_machine_->Update(delta_time);
    
    //Manage Position and Animation
    motion_state_machine_->Update(delta_time);
  }



  void Actor::SetIsActorPause(bool is_actor_pause) 
  { 
    if (is_actor_pause_ == is_actor_pause)
      return;
    
    actor_data_->GetMotionData()->SetAnimationPause(is_actor_pause);
    actor_data_->GetSkillData()->SetSkillPause(is_actor_pause);

    is_actor_pause_ = is_actor_pause; 
  }
} // namespace actor