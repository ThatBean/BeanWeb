#include "actor_trigger_module_geometry.h"

#include "game/actor/actor.h"

namespace actor 
{
  const eActorTriggerModule ActorTriggerModuleGeometry::trigger_module_type_ = kActorTriggerModuleGeometry;
  const uint_32 ActorTriggerModuleDataGeometry::TARGET_MODULE_TYPE = kActorTriggerModuleGeometry;
  

  void ActorTriggerModuleDataGeometry::SetTriggerFlagShape(float radius_max, float radius_min/* = 0*/, float ratio_y/* = 1.0*/)
  {
    SetTriggerFlagShape(kActorTriggerGeometryShapeCircle, radius_max, radius_min, ratio_y);
  }
  void ActorTriggerModuleDataGeometry::SetTriggerFlagShape(eActorTriggerGeometryShape shape, float radius_max, float radius_min/* = 0*/, float ratio_y/* = 1.0*/)
  {
    AddTriggerFlag(kActorTriggerGeometryFlagShape);
    SetShape(shape);
    SetRadius(radius_max, radius_min);
    SetRatioY(ratio_y);
  }
  void ActorTriggerModuleDataGeometry::SetTriggerFlagDirection(bool is_direction_left_or_front, bool is_direction_relative/* = true*/)
  {
    AddTriggerFlag(kActorTriggerGeometryFlagDirection);
    SetDirection(is_direction_left_or_front, is_direction_relative);
  }
  void ActorTriggerModuleDataGeometry::SetTriggerFlagLocation(cocos2d::CCPoint center_location, bool is_location_relative/* = true*/)
  {
    AddTriggerFlag(kActorTriggerGeometryFlagLocation);
    SetLocation(center_location, is_location_relative);
  }


  void ActorTriggerModuleDataGeometry::ResetQuickFilter()
  {
    _filter_is_use_rectangle_max_ = false;
    _filter_is_use_rectangle_min_ = false;
    _filter_is_use_circle_ = false;
    _filter_is_use_direction_ = false;
  }
  
  bool ActorTriggerModuleDataGeometry::InitQuickFilter(Actor* actor)
  {
    ResetQuickFilter();

    _filter_actor_position_ = actor->GetActorData()->GetMotionData()->GetPosition();

    if (GetTriggerFlag() & kActorTriggerGeometryFlagDirection)
    {
      _filter_is_use_direction_ = true;
      _filter_keep_left_side_ = GetIsDirectionLeft(actor->GetActorData()->GetMotionData()->GetAnimationDirection() == kActorAnimationDirectionLeft);
    }
    
    if (GetTriggerFlag() & kActorTriggerGeometryFlagLocation)
    {
      if (_filter_is_use_direction_ && is_location_relative_)
      {
        float dist_x = abs(center_location_.x - _filter_actor_position_.x);
        dist_x = _filter_keep_left_side_ ? -dist_x : dist_x;
        _filter_shape_center_ = ccp(dist_x + _filter_actor_position_.x, center_location_.y + _filter_actor_position_.y);
      }
      else
      {
        _filter_shape_center_ = center_location_;
      }
    }
    else
    {
      _filter_shape_center_ = _filter_actor_position_;
    }

    if (GetTriggerFlag() & kActorTriggerGeometryFlagShape)
    {
      if (radius_max_ <= 0 || radius_max_ < radius_min_)
      {
        assert(false);
        return false;
      }
      
      switch (shape_)
      {
      case kActorTriggerGeometryShapeCircle:
        _filter_is_use_circle_ = true;
        break;
      case kActorTriggerGeometryShapeRectangle:
        _filter_is_use_rectangle_max_ = true;
        _filter_rectangle_max_ = CCRect(
                _filter_shape_center_.x - radius_max_, 
                _filter_shape_center_.y - radius_max_ * ratio_y_, 
                2 * radius_max_, 
                2 * radius_max_ * ratio_y_);

        if (radius_min_ > 0)
        {
          _filter_is_use_rectangle_min_ = true;
          _filter_rectangle_min_ = CCRect(
                  _filter_shape_center_.x - radius_min_, 
                  _filter_shape_center_.y - radius_min_ * ratio_y_, 
                  2 * radius_min_, 
                  2 * radius_min_ * ratio_y_);
        }
        break;
      default:
        assert(false);
        return false;
        break;
      }
    }

    return true;
  }

  bool ActorTriggerModuleDataGeometry::QuickFilter(Actor* ref_actor)
  {
    cocos2d::CCPoint ref_actor_position = ref_actor->GetActorData()->GetMotionData()->GetPosition();
    cocos2d::CCRect ref_actor_box = ref_actor->GetActorData()->GetMotionData()->GetAnimationBox();

    //decide direction
    if (_filter_is_use_direction_ && (ref_actor_position.x < _filter_actor_position_.x) != _filter_keep_left_side_)
      return true;

    
//     //decide rect with point
//     if (_filter_is_use_rectangle_max_ && _filter_rectangle_max_.containsPoint(ref_actor_position) == false)
//       return true;
//     if (_filter_is_use_rectangle_min_ && _filter_rectangle_min_.containsPoint(ref_actor_position) == true)
//       return true;

    //decide rect with rect
    if (_filter_is_use_rectangle_max_ && _filter_rectangle_max_.intersectsRect(ref_actor_box) == false)
      return true;
    if (_filter_is_use_rectangle_min_ && _filter_rectangle_min_.intersectsRect(ref_actor_box) == true)
      return true;

//     //decide circle
//     if (_filter_is_use_circle_)
//     {
//       //here we use a trick on y axis transform
//       cocos2d::CCPoint distance_vector_with_ratio = ccp(_filter_shape_center_.x - ref_actor_position.x, (_filter_shape_center_.y - ref_actor_position.y) / ratio_y_);
//       float distance_with_ratio = distance_vector_with_ratio.getLength();
//       if (distance_with_ratio < radius_min_ || distance_with_ratio > radius_max_)
//         return true;
//     }

    //decide circle
    if (_filter_is_use_circle_)
    {
      //currently we don't support radius_min_ with circle-rect
      assert(radius_min_ <= 0);

      //apply the rect w/h to distance
      float distance_x = abs(_filter_shape_center_.x - ref_actor_box.getMidX()) - ref_actor_box.size.width * 0.5;
      float distance_y = abs(_filter_shape_center_.y - ref_actor_box.getMidY()) - ref_actor_box.size.height * 0.5;

      distance_x = distance_x < 0 ? 0 : distance_x;
      distance_y = distance_y < 0 ? 0 : distance_y;

      distance_y /= ratio_y_; //here we use a trick on y axis transform

      cocos2d::CCPoint distance_vector_with_ratio = ccp(distance_x, distance_y);
      float distance_with_ratio = distance_vector_with_ratio.getLength();
      if (distance_with_ratio > radius_max_)
        return true;
    }
    
    return false; //don't filter
  }







  ActorTriggerModuleGeometry* ActorTriggerModuleGeometry::Instance()
  {
    static ActorTriggerModuleGeometry instance;
    return &instance;
  }


  bool ActorTriggerModuleGeometry::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataGeometry* trigger_module_data = dynamic_cast<ActorTriggerModuleDataGeometry*>(trigger_module_data_);

    assert(trigger_module_data);

    UpdateGeometry(actor, trigger_module_data, actor_list);
    
    return (actor_list->size() > 0);
  }

  void ActorTriggerModuleGeometry::UpdateGeometry(Actor* actor, ActorTriggerModuleDataGeometry* trigger_module_data, std::list<Actor*>* actor_list)
  {
    bool is_filter_needed = trigger_module_data->InitQuickFilter(actor);
    if (is_filter_needed == false) return;

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* ref_actor = *iterator;

      bool is_filter = trigger_module_data->QuickFilter(ref_actor);

      if (is_filter)
        actor_list->erase(iterator++);
      else
        ++iterator;
    }
  }

}  // namespace actor