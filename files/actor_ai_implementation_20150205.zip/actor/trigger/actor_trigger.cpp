#include "actor_trigger.h"

#include "game/actor/actor.h"
#include <assert.h>

namespace actor {

  ActorTrigger::ActorTrigger(Actor* actor)
    :actor_(actor),
    is_triggered_(false)
  {
    triggered_actor_list_ = NULL;
    triggered_actor_id_list_ = new std::list<int>;
    trigger_module_config_list_.clear();
  }

  ActorTrigger::~ActorTrigger()
  {
    ClearTriggerModuleConfig();
    ClearTriggeredList();
    delete triggered_actor_id_list_;
  }

  void ActorTrigger::AddTriggerModuleConfig(ActorTriggerModule* trigger_module, ActorTriggerModuleData* trigger_module_data)
  {
    assert(trigger_module);
    sTriggerModuleConfig* trigger_module_config = new sTriggerModuleConfig();
    
    trigger_module_config->trigger_module = trigger_module;
    trigger_module_config->trigger_module_data = trigger_module_data;

    trigger_module_config_list_.push_back(trigger_module_config);
  }

  void ActorTrigger::ClearTriggerModuleConfig()
  {
    std::list<TriggerModuleConfig*>::iterator iterator = trigger_module_config_list_.begin();

    while (iterator != trigger_module_config_list_.end())
    {
      sTriggerModuleConfig* trigger_module_config = *iterator;
      delete trigger_module_config->trigger_module_data;
      delete trigger_module_config;

      ++iterator;
    }

    trigger_module_config_list_.clear();
  }


  void ActorTrigger::Update()  // loop trigger module
  {
    //clear previous result
    ClearTriggeredList();
    
    triggered_actor_list_ = actor_->GetActorExtEnv()->GetActorList();
    std::list<sTriggerModuleConfig*>::iterator iterator_tmc = trigger_module_config_list_.begin();
    
    while (iterator_tmc != trigger_module_config_list_.end() && triggered_actor_list_->size() > 0)
    {
      sTriggerModuleConfig* trigger_module_config = *iterator_tmc; 
      //the triggered_actor_list will be screened (un-triggered actor will be removed from list)
      bool is_module_triggered = trigger_module_config->trigger_module->Update(
        actor_, 
        trigger_module_config->trigger_module_data, 
        triggered_actor_list_);
      //is_triggered_ = is_triggered_ || is_module_triggered;

      ++iterator_tmc;
    }

    //collect actor id
    std::list<Actor*>::iterator iterator_ta = triggered_actor_list_->begin();
    while (iterator_ta != triggered_actor_list_->end())
    {
      Actor* actor = *iterator_ta;
      triggered_actor_id_list_->push_back(actor->GetActorId());

      ++iterator_ta;
    }

    is_triggered_ = (triggered_actor_id_list_->size() > 0);

    //delete triggered_actor_list;  //clean up
  }

  void ActorTrigger::ClearTriggeredList()
  {
    triggered_actor_id_list_->clear();

    if (triggered_actor_list_)
    {
      delete triggered_actor_list_;
      triggered_actor_list_ = NULL;
    }
  }

}  // namespace actor


