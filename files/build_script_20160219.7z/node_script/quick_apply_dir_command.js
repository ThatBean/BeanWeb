require('./Dr.js');

//quick apply command to folder under certain dir

var global_args = process.argv;

var NODE_EXE_PATH = global_args[0];
var SCRIPT_FILE_PATH = global_args[1];
var APPLY_ROOT_DIR = global_args[2];	//root search dir
var COMMAND_PART_1 = global_args[3];	//command to run part 1
//optional
var COMMAND_PART_2 = global_args[4] || ''; //command to run part 2

var usuage = '' 
	+ '<NODE_EXE_PATH>' 
	+ ' + ' + '<SCRIPT_FILE_PATH>' 
	+ ' + ' + '<APPLY_ROOT_DIR>'
	+ ' + ' + '<COMMAND_PART_1>'
	+ ' [optional:'
	+ ' + ' + '<COMMAND_PART_2>'
	+ ' ]';
var get_arg = '' 
	+ NODE_EXE_PATH 
	+ ' + ' + SCRIPT_FILE_PATH 
	+ ' + ' + (COMMAND_PART_1 || '<COMMAND_PART_1>')
	+ ' + ' + (APPLY_ROOT_DIR || '<APPLY_ROOT_DIR>')
	+ ' [optional: '
	+ ' + ' + (COMMAND_PART_2 || '<COMMAND_PART_2>')
	+ ' ]';

if (global_args.length < 4) {
	Dr.log('[Usuage]\n' + usuage);
	Dr.log('[Get]\n' + get_arg);
	Dr.log('[Error] required arguments missing!');
	process.exit(-1);
}

Dr.log('[Usuage]\n' + usuage);
Dr.log('[Get]\n' + get_arg);

var job_func_list = [];
var run_job_func = function () {
	var next_job_func = job_func_list.shift();
	if (next_job_func) {
		next_job_func(run_job_func);
	}
	else {
		Dr.log('All job finished...');
	}
}



//check pass

var Path = Dr.require('path');

Dr.loadLocalScript('./Dr.node.js', function () {
	Dr.loadScriptByList([
		'./module/command.js',
		'./module/file.js',
	], function () {
		Dr.log("All script loaded");
		
		Dr.LoadAll();
		
		var Command = Dr.Get('Command');
		var Directory = Dr.Get('Directory');
		
		
		var push_job_func = function (target_path) {
			var cmd_command = ([
				COMMAND_PART_1,
				target_path,
				COMMAND_PART_2
			]).join(' ');
			
			var command_config = {
				cwd: process.cwd(),
				stdoutStream: process.stdout,
				stderrStream: process.stdout,
			};
			
			job_func_list.push(function (callback) {
				console.log('[Command] cmd_command:', cmd_command);
				command_config.callback = function (code, signal) {
					if (code == 0) {
						callback();
					}
					else {
						Dr.log('[Error] code:', code, signal);
						process.exit(-1);
					}
				};
				Command.run(cmd_command, command_config);
			})
		}

		
		var directory = Directory.create(APPLY_ROOT_DIR);
		
		push_job_func(APPLY_ROOT_DIR);
		
		directory.walk(function (path, name, type) {
			if (type == 'Directory') {
				var current_path = Path.join(path, name);
				
				push_job_func(current_path);
			}
			else {
				//console.log('[Skipped]', ' - ', path, ' - ', name, ' - ', type);
			}
		}, true);
		
		//run each func
		run_job_func();
		
		//Dr.startREPL();
	});
});