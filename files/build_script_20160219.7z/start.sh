#!/bin/bash


cd ../

## now working directory should be client/
export WORKSPACE=`pwd` 



cd ./build_script/

## svn permission problem
chmod +x ./build_process/build_bash_script/*


echo "*************************** Pre - Build ***************************"

# if [ "$ANDROID_CM_STORE_SWITCH" != "[CHOOSE ONE BELOW]" ]; then
	# echo "** Android CM Store Version Switch **"
	# node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/assets $ANDROID_CM_STORE_SWITCH
	# node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/jni $ANDROID_CM_STORE_SWITCH
	# node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/ $ANDROID_CM_STORE_SWITCH
# fi

echo "*************************** Start Build ***************************"


cd ./node_script/

if [ "$IS_BUILD_FOR_LOCAL" == "true" ]; then 
	node job_command.js job_command_config_local.json
else
	node job_command.js job_command_config.json
fi