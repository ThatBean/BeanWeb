#!/usr/bin/python
#coding:utf-8 

import os
import sys
import xml.etree.ElementTree as ElementTree

# print(sys.path)
# exit(0)

#add python module path
sys.path.append("../build_process/python_module")	# from current dir
sys.path.append("./build_script/build_process/python_module")	# from program/client dir
import generate_file_list
import xml_file_reader


# special bone_name needed to perserve
SPECIAL_BONE_NAME_LIST = [
	"dandao",
	"xuetiao",
	"something",
]


def mute_print(*arguments):
	pass

	
DEBUG_PRINT = mute_print	
# DEBUG_PRINT = print	




# quick get plist key - dict element pair
def get_plist_key_dict_element_pair_map_under_xml_element(xml_element):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" get_plist_key_dict_element_pair_map_under_xml_element ")
	DEBUG_PRINT("=======================================================")
	
	xml_dict_list = xml_element.findall("./dict")
	xml_key_list = xml_element.findall("./key")
	
	if (len(xml_dict_list) != len(xml_key_list)):
		print("mismatching count of <key> <dict> under", xml_element)
		assert False, "found mismatching count of <key> <dict>"
	
	pair_map = {}
	for index in range(0, len(xml_dict_list)):
		text_key = xml_key_list[index].text
		pair_map[text_key] = {
			"text_key" : text_key,
			"xml_key" : xml_key_list[index],
			"xml_dict" : xml_dict_list[index],
		}
	return pair_map
	
	
	
	
	
def get_texture_info_from_texture_atlas(xml_skeleton):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" get_texture_info_from_texture_atlas ")
	DEBUG_PRINT("=======================================================")
	
	xml_TextureAtlas = xml_skeleton.find("./TextureAtlas")
	DEBUG_PRINT("get xml_TextureAtlas", xml_TextureAtlas.attrib["name"])
	
	texture_name_list = []
	texture_info_map = {}	# used to decide if texture is duplicate
	
	xml_SubTexture_list = xml_TextureAtlas.findall("./SubTexture")
	for xml_SubTexture in xml_SubTexture_list:
		DEBUG_PRINT("get xml_SubTexture", xml_SubTexture.attrib["name"])
		texture_name = xml_SubTexture.attrib["name"]
		
		if (texture_name not in texture_name_list):
			texture_name_list.append(texture_name)
			texture_info_map[texture_name] = xml_SubTexture.attrib["cocos2d_pX"]
			texture_info_map[texture_name] += "|" + xml_SubTexture.attrib["cocos2d_pY"]
			texture_info_map[texture_name] += "|" + xml_SubTexture.attrib["width"]
			texture_info_map[texture_name] += "|" + xml_SubTexture.attrib["height"]
		else:
			print(texture_name)
			print(texture_name_list)
			assert (False), "found duplicate texture_name in <TextureAtlas><SubTexture>"
		
		
	# flush <SubTexture> data
	for xml_SubTexture in xml_SubTexture_list:
		xml_TextureAtlas.remove(xml_SubTexture)
		
	# re-create <SubTexture> data with texture_name_list(repack_plist_texture_name)
	for repack_plist_texture_name in texture_name_list:
		xml_SubTexture = ElementTree.SubElement(xml_TextureAtlas, "SubTexture")
		xml_SubTexture.attrib["name"] = repack_plist_texture_name
	
	print("get total texture name:", len(texture_name_list), "(texture_name/repack_plist_texture_name)")
	
	return {
		# "texture_name_list" : texture_name_list	# no use later
		"texture_info_map" : texture_info_map
	}
	
	
	
	
def repack_plist_frames_texture(frames_key_dict_pair, skeleton_texture_info_map, repack_texture_name_prefix):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" repack_plist_frames_texture ")
	DEBUG_PRINT("=======================================================")
	
	xml_frames_dict = frames_key_dict_pair["xml_dict"]
	
	key_dict_pair_map = get_plist_key_dict_element_pair_map_under_xml_element(xml_frames_dict)
	
	duplication_key_list = []
	rename_needed_duplication_key_list = []
	repack_plist_texture_key_map = {}		# source texture frame name - repacked name
	
	repack_texture_key_index = 0
	
	# loop and de-duplication
	for frame_key in key_dict_pair_map.keys():
		if (frame_key in duplication_key_list):
			continue	# skip duplication
		if (frame_key in rename_needed_duplication_key_list):
			continue	# skip rename needed duplication
		
		repack_texture_key_index += 1
		repack_plist_texture_key_map[frame_key] = repack_texture_name_prefix + "t" + str(repack_texture_key_index) + ".png"
		
		frame_key_dict_pair = key_dict_pair_map[frame_key]
		text_xml_dict = ElementTree.tostring(frame_key_dict_pair["xml_dict"], "utf-8", "xml") 
		text_skeleton_texture_info = skeleton_texture_info_map[os.path.splitext(frame_key)[0]]
		
		rename_needed_duplicate_index = 0
		for match_frame_key in key_dict_pair_map.keys():
			if (match_frame_key in duplication_key_list):
				continue	# skip duplication
			if (match_frame_key in rename_needed_duplication_key_list):
				continue	# skip rename needed duplication
			if (match_frame_key == frame_key):
				continue	# skip self
			
			match_frame_key_dict_pair = key_dict_pair_map[match_frame_key]
			
			# check duplication by SIMPLY MATCH PLIST RE-GENERATED TEXT BETWEEN <dict></dict> AND MATCH XML <SubTexture> INFO
			match_text_xml_dict = ElementTree.tostring(match_frame_key_dict_pair["xml_dict"], "utf-8", "xml") 
			match_text_skeleton_texture_info = skeleton_texture_info_map[os.path.splitext(match_frame_key)[0]]
			
			if (match_text_xml_dict == text_xml_dict):
				# PLIST RE-GENERATED TEXT BETWEEN <dict></dict> duplicate
				
				if (text_skeleton_texture_info == match_text_skeleton_texture_info):
					# complete redundent duplicate
					print("found plist frame texture duplication, repack_key:", repack_plist_texture_key_map[frame_key])
					print("[new] ---- ", match_frame_key)
					DEBUG_PRINT(match_text_xml_dict)
					DEBUG_PRINT(match_text_skeleton_texture_info)
					print("[exist] -- ", frame_key)
					DEBUG_PRINT(text_xml_dict)
					DEBUG_PRINT(text_skeleton_texture_info)
					
					repack_plist_texture_key_map[match_frame_key] = repack_plist_texture_key_map[frame_key]	# redirect key map
					
					duplication_key_list.append(match_frame_key)
				else:
					# rename needed duplicate and mark dup index in repack texture name
					# this kind of duplicate is needed for save additional positioning info in <SubTexture>
					rename_needed_duplicate_index += 1
					repack_plist_texture_key_map[match_frame_key] = repack_texture_name_prefix + "t" + str(repack_texture_key_index) + "d" + str(rename_needed_duplicate_index) + ".png"
					
					rename_needed_duplication_key_list.append(match_frame_key)
	
	# remove duplicate xml elements in duplication_key_list (not rename_needed_duplication_key_list)
	for duplication_key in duplication_key_list:
		xml_frames_dict.remove(key_dict_pair_map[duplication_key]["xml_key"])
		xml_frames_dict.remove(key_dict_pair_map[duplication_key]["xml_dict"])
		del key_dict_pair_map[duplication_key]
	
	# replace key to repack key
	for frame_key in key_dict_pair_map.keys():
		frame_key_dict_pair = key_dict_pair_map[frame_key]
		frame_key_dict_pair["xml_key"].text = repack_plist_texture_key_map[frame_key]
	
	# remove ".png" extension for xml TextureAtlas SubTexture name
	repack_plist_texture_key_map_no_ext = {}
	for frame_key in repack_plist_texture_key_map.keys():
		repack_plist_texture_key = repack_plist_texture_key_map[frame_key]
		
		frame_key_no_ext = os.path.splitext(frame_key)[0]
		repack_plist_texture_key_no_ext = os.path.splitext(repack_plist_texture_key)[0]
		
		repack_plist_texture_key_map_no_ext[frame_key_no_ext] = repack_plist_texture_key_no_ext
	
	duplication_key_list_no_ext = []
	for frame_key in duplication_key_list:
		
		frame_key_no_ext = os.path.splitext(frame_key)[0]
		
		duplication_key_list_no_ext.append(frame_key_no_ext)
	
	
	print("get duplication plist texture count", len(duplication_key_list))
	DEBUG_PRINT(duplication_key_list)
	print("get rename needed duplication plist texture count", len(rename_needed_duplication_key_list))
	DEBUG_PRINT(rename_needed_duplication_key_list)
	print("get repack plist texture count", len(repack_plist_texture_key_map_no_ext))
	DEBUG_PRINT(repack_plist_texture_key_map_no_ext)
	
	
	return {
		"duplication_key_list" : duplication_key_list_no_ext,
		"repack_plist_texture_key_map" : repack_plist_texture_key_map_no_ext,
	}
	
	
	
	
	
def RepackPlistFile(source_file_path, result_file_path):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" RepackPlistFile ")
	DEBUG_PRINT("=======================================================")
	
	
	# set right ext
	source_xml_file_path = os.path.splitext(source_file_path)[0] + ".xml"
	source_plist_file_path = os.path.splitext(source_file_path)[0] + ".plist"
	result_file_path = os.path.splitext(result_file_path)[0] + ".plist"
	
	repack_texture_name_prefix = os.path.splitext(os.path.basename(source_file_path))[0] + "_"	# to prevent resource name duplication in multiple files( by using file names)
	
	
	xfr = xml_file_reader.XmlFileReader()
	
	xml_skeleton = xfr.read_file(source_xml_file_path)	# same as <skeleton>
	xml_plist = xfr.read_file(source_plist_file_path)	# same as <plist>
	
	# check basic info
	print("[XML BASIC INFO]", 
		"name:", xml_skeleton.attrib["name"], 
		"frameRate:", xml_skeleton.attrib["frameRate"], 
		"version:", xml_skeleton.attrib["version"])
	print("[PLIST BASIC INFO]", 
		"version:", xml_plist.attrib["version"])
	
	
	
	# check xml skeleton first
	skeleton_texture_info_result = get_texture_info_from_texture_atlas(xml_skeleton)
	# skeleton_texture_name_list = skeleton_texture_info_result["texture_name_list"]	# not used
	skeleton_texture_info_map = skeleton_texture_info_result["texture_info_map"]
	
	# check plist next
	key_dict_pair_map = get_plist_key_dict_element_pair_map_under_xml_element(xml_plist.find("./dict"))
	# print(key_dict_pair_map)
	frames_key_dict_pair = key_dict_pair_map["frames"]
	
	# repack
	repack_plist_result = repack_plist_frames_texture(frames_key_dict_pair, skeleton_texture_info_map, repack_texture_name_prefix)
	repack_plist_texture_key_map = repack_plist_result["repack_plist_texture_key_map"]
	duplication_key_list = repack_plist_result["duplication_key_list"]
	
	DEBUG_PRINT(repack_plist_texture_key_map)
	
	def repack_plist_success_callback():
		# save back when success
		xfr.write_file(result_file_path, xml_plist)
	
	return {
		"repack_plist_texture_key_map" : repack_plist_texture_key_map,
		"duplication_key_list" : duplication_key_list,
		"repack_plist_success_callback" : repack_plist_success_callback,
	}










def repack_and_get_texture_name_from_texture_atlas(xml_skeleton, repack_plist_texture_key_map, duplication_key_list):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" repack_and_get_texture_name_from_texture_atlas ")
	DEBUG_PRINT("=======================================================")
	
	xml_TextureAtlas = xml_skeleton.find("./TextureAtlas")
	DEBUG_PRINT("get xml_TextureAtlas", xml_TextureAtlas.attrib["name"])
	
	texture_name_list = []
	
	xml_SubTexture_list = xml_TextureAtlas.findall("./SubTexture")
	for xml_SubTexture in xml_SubTexture_list:
		DEBUG_PRINT("get xml_SubTexture", xml_SubTexture.attrib["name"])
		texture_name = xml_SubTexture.attrib["name"]
		
		if (texture_name not in repack_plist_texture_key_map):
			print(texture_name)
			print(repack_plist_texture_key_map)
			assert False, "found non-plist texture in <TextureAtlas>"
		
		# use repack name
		repack_plist_texture_name = repack_plist_texture_key_map[texture_name]
		
		if (repack_plist_texture_name not in texture_name_list):
			texture_name_list.append(repack_plist_texture_name)
	
	# flush <SubTexture> data, and re-name <SubTexture> data with repack_plist_texture_key_map(repack_plist_texture_name)
	for xml_SubTexture in xml_SubTexture_list:
		texture_name = xml_SubTexture.attrib["name"]
		if ((texture_name in repack_plist_texture_key_map) and (texture_name not in duplication_key_list)):
			xml_SubTexture.attrib["name"] = repack_plist_texture_key_map[texture_name]
			
			# loose redundent data
			if ("x" in xml_SubTexture.attrib): del xml_SubTexture.attrib["x"]
			if ("y" in xml_SubTexture.attrib): del xml_SubTexture.attrib["y"]
		else:
			xml_TextureAtlas.remove(xml_SubTexture)
	
	print("get total texture name:", len(texture_name_list), "(texture_name/repack_plist_texture_name)")
	return texture_name_list
	
	
	
def get_texture_ref_from_armatures(xml_skeleton, repack_plist_texture_key_map):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" get_texture_ref_from_armatures ")
	DEBUG_PRINT("=======================================================")
	
	xml_armatures = xml_skeleton.find("./armatures")
	xml_armature_list = xml_armatures.findall("./armature")
	
	assert (len(xml_armature_list) == 1), "found multiple TAG <armature> in <armatures>"
	
	texture_name_ref = {}	# texture_name - bone_name + display_index
	texture_name_ref_reverse = {}	# bone_name + display_index - texture_name
	
	for xml_armature in xml_armature_list:
		DEBUG_PRINT("get xml_armature", xml_armature.attrib["name"])
		xml_bone_list = xml_armature.findall("./b")
		for xml_bone in xml_bone_list:
			bone_name = xml_bone.attrib["name"]
			DEBUG_PRINT("get xml_bone", bone_name)
			display_index = 0
			xml_display_list = xml_bone.findall("./d")
			for xml_display in xml_display_list:
				DEBUG_PRINT("get xml_display", display_index, xml_display.attrib["name"])
				
				texture_name = xml_display.attrib["name"]
				
				# use repack name
				repack_plist_texture_name = repack_plist_texture_key_map[texture_name]
				
				ref_key = bone_name + "|" + str(display_index)
				
				texture_name_ref[repack_plist_texture_name] = ref_key
				texture_name_ref_reverse[ref_key] = repack_plist_texture_name
				
				display_index += 1
	
	print("get total texture_name_ref:", len(texture_name_ref), "(texture_name/repack_plist_texture_name)")
	print("get total texture_name_ref_reverse:", len(texture_name_ref_reverse), "(bone + display_index)")
	return {
		# "texture_name_ref" : texture_name_ref,		# no use after
		"texture_name_ref_reverse" : texture_name_ref_reverse,
	}
	
	
	
	
def get_move_bone_texture_link_from_animations(xml_skeleton, texture_data_map, texture_name_ref_reverse):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" get_move_bone_texture_link_from_animations ")
	DEBUG_PRINT("=======================================================")
	
	xml_animations = xml_skeleton.find("./animations")
	xml_animation_list = xml_animations.findall("./animation")
	
	global SPECIAL_BONE_NAME_LIST
	
	assert (len(xml_animation_list) == 1), "found multiple TAG <animation> in <animations>"
	
	move_bone_texture_link = {} # move_name + bone_name - related texture_name
	
	for xml_animation in xml_animation_list:
		DEBUG_PRINT("get xml_animation", xml_animation.attrib["name"])
		xml_move_list = xml_animation.findall("./mov")
		for xml_move in xml_move_list:
			move_name = xml_move.attrib["name"]
			DEBUG_PRINT("get xml_move", move_name)
			
			xml_bone_list = xml_move.findall("./b")
			for xml_bone in xml_bone_list:
				bone_name = xml_bone.attrib["name"]
				link_key = move_name + "|" + bone_name
				DEBUG_PRINT("get xml_bone", bone_name)
				frame_index = 0
				
				xml_frame_list = xml_bone.findall("./f")
				for xml_frame in xml_frame_list:
					DEBUG_PRINT("get xml_frame", frame_index)
					
					display_index = int(xml_frame.attrib["dI"] or -1)
					if (display_index >= 0):
						ref_key = bone_name + "|" + str(display_index)
						texture_name = texture_name_ref_reverse[ref_key]
						
						if (link_key not in move_bone_texture_link):
							move_bone_texture_link[link_key] = []
						
						if (texture_name not in move_bone_texture_link[link_key]):
							move_bone_texture_link[link_key].append(texture_name)
						
						# preserve special bone name by SPECIAL_BONE_NAME_LIST
						for special_bone_name in SPECIAL_BONE_NAME_LIST:
							if (bone_name.find(special_bone_name) != -1):
								# texture_data_map[texture_name]["repack_bone_name"] = bone_name
								if (bone_name not in texture_data_map[texture_name]["special_repack_bone_name_list"]):
									DEBUG_PRINT("get special bone", bone_name, texture_name, link_key)
									texture_data_map[texture_name]["special_repack_bone_name_list"].append(bone_name)
								break
						
					frame_index += 1
				
	print("get total move_bone_texture_link:", len(move_bone_texture_link), "(move + bone)")
	return move_bone_texture_link
	
	
	
def repack_texture_link(move_bone_texture_link, texture_data_map):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" repack_texture_link ")
	DEBUG_PRINT("=======================================================")
	
	# first distribute multi_link_index
	multi_link_index = 1
	for link_key in move_bone_texture_link.keys():
		link_data = move_bone_texture_link[link_key]
		
		if (len(link_data) == 0):
			# strange or just error?
			print(link_key, link_data)
			assert (len(link_data) != 0), "found <mov><bone> with no <SubTexture> in any frame"
			pass
		elif (len(link_data) == 1):
			# may be just this time no link use, skip for next loop
			pass
		else:
			# first check exist multi_link_index
			exist_multi_link_index = None
			for texture_name in link_data:
				if ("multi_link_index" in texture_data_map[texture_name]):
					texture_multi_link_index = texture_data_map[texture_name]["multi_link_index"]
					
					# check conflict
					if (exist_multi_link_index != None and exist_multi_link_index != texture_multi_link_index):
						print("found conflict multi_link_index:", exist_multi_link_index, texture_multi_link_index)
						# need to merge all index to one common multi_link_index by flushing texture_multi_link_index --> exist_multi_link_index in all texture_data_map
						print("flushing multi_link_index", texture_multi_link_index, "->", exist_multi_link_index)
						
						DEBUG_PRINT("texture_name", texture_name)
						DEBUG_PRINT("link_data", link_data)
						
						for texture_data in texture_data_map:
							if ("multi_link_index" in texture_data and texture_data["multi_link_index"] == texture_multi_link_index):
								texture_data["multi_link_index"] = exist_multi_link_index
					
					# record
					exist_multi_link_index = texture_multi_link_index
			
			if (exist_multi_link_index == None):
				exist_multi_link_index = multi_link_index
				multi_link_index += 1
			
			# flush multi_link_index
			for texture_name in link_data:
				texture_data_map[texture_name]["multi_link_index"] = exist_multi_link_index
	
	print("current multi_link_index:", multi_link_index)
	
	DEBUG_PRINT("---------------------------------")
	DEBUG_PRINT(texture_data_map)
	DEBUG_PRINT("---------------------------------")
	
	# then fill single_link_index
	single_link_index = 1
	for texture_name in texture_data_map.keys():
		texture_data = texture_data_map[texture_name]
		if ("multi_link_index" in texture_data):
			# already set
			pass
		else:
			#need set
			texture_data["single_link_index"] = single_link_index
			single_link_index += 1
	
	print("current single_link_index:", single_link_index)
	
	
	# set repack_bone_name
	for texture_name in texture_data_map.keys():
		texture_data = texture_data_map[texture_name]
		if ("single_link_index" in texture_data):
			texture_data["repack_bone_name"] = "s" + str(texture_data["single_link_index"])
		elif ("multi_link_index" in texture_data):
			texture_data["repack_bone_name"] = "m" + str(texture_data["multi_link_index"])
		else:
			print(texture_name, texture_data)
			assert (False), "found possible unlinked texture"
		
	
	def _add_repack_bone_name_to_repack_link_data_map(repack_bone_name, texture_name, link_key, repack_link_data_map):
		if (repack_bone_name not in repack_link_data_map):
			repack_link_data_map[repack_bone_name] = {
				"texture_name_list" : [],
				"link_key_list" : [],
				"duplicate_count" : 1,		# how many armature bone copy is needed, count later when "regenerate_armatures_from_repacked_link"
			}
		
		if (texture_name not in repack_link_data_map[repack_bone_name]["texture_name_list"]):
			repack_link_data_map[repack_bone_name]["texture_name_list"].append(texture_name)
			
		if (link_key not in repack_link_data_map[repack_bone_name]["link_key_list"]):
			DEBUG_PRINT("add <link_key_list>:", link_key, repack_bone_name, texture_name)
			repack_link_data_map[repack_bone_name]["link_key_list"].append(link_key)
	
	
	# generate repack_link_data
	repack_link_data_map = {} # repack_bone_name - {[texture_name], [move_name + bone_name], duplicate_count}
	for link_key in move_bone_texture_link.keys():
		link_data = move_bone_texture_link[link_key]
		for texture_name in link_data:
			texture_data = texture_data_map[texture_name]
			is_set_special_bone_name = False
			
			# check in special_repack_bone_name_list first
			for repack_bone_name in texture_data["special_repack_bone_name_list"]:
				if (link_key.find(repack_bone_name) != -1):
					DEBUG_PRINT("add special repack_bone_name", repack_bone_name, texture_name, link_key)
					_add_repack_bone_name_to_repack_link_data_map(repack_bone_name, texture_name, link_key, repack_link_data_map)
					is_set_special_bone_name = True
					break
			
			# then default if not found
			if (is_set_special_bone_name == False and "repack_bone_name" in texture_data):
				repack_bone_name = texture_data["repack_bone_name"]
				_add_repack_bone_name_to_repack_link_data_map(repack_bone_name, texture_name, link_key, repack_link_data_map)
			
			
	# set repack_display_index or each bone
	for repack_bone_name in repack_link_data_map.keys():
		repack_link_data = repack_link_data_map[repack_bone_name]
		repack_display_index = 0
		for texture_name in repack_link_data["texture_name_list"]:
			texture_data_map[texture_name]["repack_display_index"] = repack_display_index
			
			repack_display_index += 1
	
	
	# generate link_repack
	move_bone_link_repack = {} # move_name + bone_name - repack_bone_name
	for repack_bone_name in repack_link_data_map.keys():
		repack_link_data = repack_link_data_map[repack_bone_name]
		for link_key in repack_link_data["link_key_list"]:
			move_bone_link_repack[link_key] = repack_bone_name
			
	
	return {
		"repack_link_data_map" : repack_link_data_map,
		"move_bone_link_repack" : move_bone_link_repack,
	}
	
	
def replace_bone_name_in_animation_from_repacked_link(xml_skeleton, texture_data_map, repack_link_data_map, move_bone_link_repack, texture_name_ref_reverse):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" replace_bone_name_in_animation_from_repacked_link ")
	DEBUG_PRINT("=======================================================")
	
	xml_animations = xml_skeleton.find("./animations")
	xml_animation_list = xml_animations.findall("./animation")
	
	for xml_animation in xml_animation_list:
		DEBUG_PRINT("get xml_animation", xml_animation.attrib["name"])
		xml_move_list = xml_animation.findall("./mov")
		for xml_move in xml_move_list:
			move_name = xml_move.attrib["name"]
			DEBUG_PRINT("get xml_move", move_name)
			
			duplicate_count_map = {}	# bone_name - duplicate_count
			
			xml_bone_list = xml_move.findall("./b")
			for xml_bone in xml_bone_list:
				bone_name = xml_bone.attrib["name"]
				DEBUG_PRINT("get xml_bone", bone_name)
				
				link_key = move_name + "|" + bone_name
				repack_bone_name = move_bone_link_repack[link_key]
				
				# get duplicate_index
				if (repack_bone_name not in duplicate_count_map):
					duplicate_count_map[repack_bone_name] = 1	# map record count, but index starts from 0
				else:
					duplicate_count_map[repack_bone_name] += 1
				
				duplicate_index = duplicate_count_map[repack_bone_name] - 1
				
				# replace bone_name
				if (duplicate_index == 0):
					xml_bone.attrib["name"] = repack_bone_name
				else:
					xml_bone.attrib["name"] = repack_bone_name + "d" + str(duplicate_index)
				
				frame_index = 0
				xml_frame_list = xml_bone.findall("./f")
				for xml_frame in xml_frame_list:
					DEBUG_PRINT("get xml_frame", frame_index)
					
					display_index = int(xml_frame.attrib["dI"] or -1)
					if (display_index >= 0):
						# replace display_index
						ref_key = bone_name + "|" + str(display_index)
						texture_name = texture_name_ref_reverse[ref_key]
						repack_display_index = texture_data_map[texture_name]["repack_display_index"]
						xml_frame.attrib["dI"] = str(repack_display_index)
					
					# loose redundent data in <animations><animation><mov><b><f> (remove attrib "x", "y")
					if ("x" in xml_frame.attrib): del xml_frame.attrib["x"]
					if ("y" in xml_frame.attrib): del xml_frame.attrib["y"]
					
					frame_index += 1
			
			# update max duplicate_count
			for repack_bone_name in duplicate_count_map.keys():
				repack_link_data_map[repack_bone_name]["duplicate_count"] = max(duplicate_count_map[repack_bone_name], repack_link_data_map[repack_bone_name]["duplicate_count"])
			
			
def regenerate_armatures_from_repacked_link(xml_skeleton, repack_link_data_map):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" regenerate_armatures_from_repacked_link ")
	DEBUG_PRINT("=======================================================")
	
	xml_armatures = xml_skeleton.find("./armatures")
	xml_armature_list = xml_armatures.findall("./armature")
	
	for xml_armature in xml_armature_list:
		DEBUG_PRINT("get xml_armature", xml_armature.attrib["name"])
		
		# remove all <b><d> under <armature>
		# loose redundent data in <armatures><b> (remove all attrib but "name")
		xml_bone_list = xml_armature.findall("./b")
		for xml_bone in xml_bone_list:
			xml_armature.remove(xml_bone) 
		
		# rebuild <b><d> from repack_link_data_map
		for repack_bone_name in repack_link_data_map.keys():
			repack_link_data = repack_link_data_map[repack_bone_name]
			
			# duplicate repack_bone_name by duplicate_count (index from 0)
			for duplicate_index in range(0, repack_link_data["duplicate_count"]):
				# new bone
				xml_bone = ElementTree.SubElement(xml_armature, "b") 
				
				if (duplicate_index == 0):
					xml_bone.attrib["name"] = repack_bone_name
				else:
					xml_bone.attrib["name"] = repack_bone_name + "d" + str(duplicate_index)
				
				for texture_name in repack_link_data["texture_name_list"]:
					# new display
					xml_display = ElementTree.SubElement(xml_bone, "d") 
					xml_display.attrib["name"] = texture_name

	

def RepackXmlFile(source_file_path, result_file_path, repack_plist_texture_key_map, duplication_key_list):
	DEBUG_PRINT("=======================================================")
	DEBUG_PRINT(" RepackXmlFile ")
	DEBUG_PRINT("=======================================================")
	
	# set right ext
	source_file_path = os.path.splitext(source_file_path)[0] + ".xml"
	result_file_path = os.path.splitext(result_file_path)[0] + ".xml"
	
	xfr = xml_file_reader.XmlFileReader()
	
	xml_element_root = xfr.read_file(source_file_path)
	DEBUG_PRINT(xml_element_root)
	xml_skeleton = xml_element_root	# same as <skeleton>
	
	
	#check count assert (currently cocos must read and need only 1 of each these tag)
	xml_armatures_list = xml_skeleton.findall("./armatures")
	xml_animations_list = xml_skeleton.findall("./animations")
	xml_TextureAtlas_list = xml_skeleton.findall("./TextureAtlas")
	assert (len(xml_armatures_list) == 1), "found multiple TAG <armatures>"
	assert (len(xml_animations_list) == 1), "found multiple TAG <animations>"
	assert (len(xml_TextureAtlas_list) == 1), "found multiple TAG <TextureAtlas>"
	
	
	# in <animation><mov>, we get <b> + "dI" for <SubTexture>, by check <armature><b>[dI]
	# all <SubTexture> in single <mov> should be placed in single <b>
	
	
	# count resource <SubTexture> and match with plist resource
	texture_name_list = repack_and_get_texture_name_from_texture_atlas(xml_skeleton, repack_plist_texture_key_map, duplication_key_list)
	
	# create texture_data_map for most data storage
	texture_data_map = {}	# name - {data}
	for texture_name in texture_name_list:
		texture_data_map[texture_name] = {
			"name" : texture_name,	# repack_plist_texture_name, for debug, no actural use
			"special_repack_bone_name_list" : [],	# special_repack_bone_name_list for special bone name preserve
		}
	
	DEBUG_PRINT("get empty texture_data_map:", texture_data_map)
	
	# get reference of texture_name - bone_name + display_index (source data, not repacked)
	ref_result = get_texture_ref_from_armatures(xml_skeleton, repack_plist_texture_key_map)
	# texture_name_ref = ref_result["texture_name_ref"]
	texture_name_ref_reverse = ref_result["texture_name_ref_reverse"]
	
	# check bone link
	move_bone_texture_link = get_move_bone_texture_link_from_animations(xml_skeleton, texture_data_map, texture_name_ref_reverse)
	DEBUG_PRINT(move_bone_texture_link)
	
	DEBUG_PRINT("=========================================")
	
	DEBUG_PRINT(texture_data_map)
	
	
	# exit(0)
	
	
	# repack and re-assign bone name
	repack_result = repack_texture_link(move_bone_texture_link, texture_data_map)
	repack_link_data_map = repack_result["repack_link_data_map"]
	move_bone_link_repack = repack_result["move_bone_link_repack"]
	DEBUG_PRINT(repack_link_data_map)
	DEBUG_PRINT("=======================================")
	DEBUG_PRINT(move_bone_link_repack)
	
	
	# exit(0)
	
	
	# replace bone_name in <animations><animation><mov><b>
	replace_bone_name_in_animation_from_repacked_link(xml_skeleton, texture_data_map, repack_link_data_map, move_bone_link_repack, texture_name_ref_reverse)
	
	# regenerate <armatures>
	regenerate_armatures_from_repacked_link(xml_skeleton, repack_link_data_map)
	
	
	# print(xml_armatures)
	# print(xml_animations)
	# print(xml_TextureAtlas)
	# print(xml_TextureAtlas.attrib)
	# del xml_TextureAtlas.attrib["name"]
	
	
	def repack_xml_success_callback():
		# save back when success
		xfr.write_file(result_file_path, xml_skeleton)
	
	return {
		"repack_xml_success_callback" : repack_xml_success_callback,
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
# Repack Skeleton Animation xml file for cocos2dx (Dragon CCBone Version 2.0)
# will reorder/merge/rename bone name in xml
# will remove useless infomation (tag and attributes)
# USAGE:
#	> python <script_file>.py <source file or source file dir>
#	> <source file or source file dir> = ./
# SAMPLE:
#	> python <script_file>.py ./xml/
#	> python <script_file>.py test.xml

if (__name__ == "__main__"):
	
	PATH_SRC = "./"
	TARGET_FILE_EXT = ".xml"
	ENCRYPTED_FILE_PREFIX = ""	#over write file
	
	if (len(sys.argv) >= 2) and sys.argv[1]:
		PATH_SRC = sys.argv[1]
	else:
		print("<source file or source file dir> not specified, use default ./")
		PATH_SRC = "./"
	
	print("Target Ext:",TARGET_FILE_EXT)
	print("Target Dir:",PATH_SRC)
	
	print("===Start Repacking===")
	
	#get file list
	file_list = generate_file_list.GetFileList(path = PATH_SRC, target_file_ext = TARGET_FILE_EXT, output_file_prefix = ENCRYPTED_FILE_PREFIX)
	
	for file_path_data in file_list:
		#get file path
		source_file_path = file_path_data[0]
		result_file_path = file_path_data[1]
		
		print(">> Repacking", source_file_path)
		
		# check plist first
		repack_plist_result = RepackPlistFile(source_file_path, result_file_path)
		repack_plist_texture_key_map = repack_plist_result["repack_plist_texture_key_map"]
		duplication_key_list = repack_plist_result["duplication_key_list"]
		repack_plist_success_callback = repack_plist_result["repack_plist_success_callback"]
		
		
		# then check xml
		repack_xml_result = RepackXmlFile(source_file_path, result_file_path, repack_plist_texture_key_map, duplication_key_list)
		repack_xml_success_callback = repack_xml_result["repack_xml_success_callback"]
		
		
		print(">> Saving", result_file_path)
		# only save on final success
		repack_plist_success_callback()
		repack_xml_success_callback()
		
	print("===Finished Repacking===")
	print("Total File:", len(file_list))