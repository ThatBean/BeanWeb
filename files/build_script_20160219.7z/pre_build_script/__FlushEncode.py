#!/usr/bin/python
#coding:utf-8 

import os

##--------------------------------------------------------------------------------------
def get_file_path_data(file_path, file_name, target_file_ext, output_file_prefix):
	
	target_file_ext = target_file_ext or ""
	output_file_prefix = output_file_prefix or ""
		
	if (file_path and file_name and (not target_file_ext or os.path.splitext(file_name)[1] == target_file_ext) and (not output_file_prefix or file_name[0] != output_file_prefix)):
		
		source_file_path = os.path.join(file_path, file_name)
		result_file_path = os.path.join(file_path, output_file_prefix + file_name)
		
		return [source_file_path, result_file_path]
	else:
		return None

def GetFileList(path, target_file_ext, output_file_prefix):
	
	print("[GetFileList] searching:", path, target_file_ext, output_file_prefix)
	
	target_file_ext = target_file_ext or ""
	output_file_prefix = output_file_prefix or ""
	
	file_list = []
	
	if os.path.isdir(path):
		print("[GetFileList] path is dir, search files...", path)
		for file_name in os.listdir(path):
			file_path = path
			if os.path.isfile(os.path.join(file_path, file_name)):
			
				path_data = get_file_path_data(file_path, file_name, target_file_ext, output_file_prefix)
				if path_data:
					file_list.append(path_data)
			
			if os.path.isdir(os.path.join(file_path, file_name)):
				# print("[GetFileList] file is sub-dir, search sub-dir...")
				
				sub_file_list = GetFileList(os.path.join(file_path, file_name), target_file_ext, output_file_prefix)
				if sub_file_list:
					file_list.extend(sub_file_list)
				
			
	elif os.path.isfile(path):
		print("[GetFileList] path is file, return directly...", path)
		file_path = os.path.dirname(path)
		file_name = os.path.basename(path)
		
		path_data = get_file_path_data(file_path, file_name, target_file_ext, output_file_prefix)
		if path_data:
			file_list.append(path_data)
		
	else:
		print("[GetFileList] <path> not found! path:", path)
		exit(1)
	
	return file_list
##--------------------------------------------------------------------------------------	













import os
import sys
import string
import codecs
import shutil


DECODE_LIST = [
	"gb2312",
	"gbk",
	"utf_8",
	"utf_8_sig",	
]

def TryDecode(file_data):
	#try decode
	for decode_codec in DECODE_LIST:
		try:
			file_data = file_data.decode(decode_codec)
			return file_data
		except:
			# print("-- decode " + decode_codec + " Failed")
			pass
		
	return 


def EncodeToUTF8(file_name):
	try:
		# print('Encoding: ' + file_name)

		#read
		source_file = open(file_name)
		file_data = source_file.read()
		source_file.close()
		
		# drop nasty BOM
		if (
			file_data[:3] == codecs.BOM
			or file_data[:3] == codecs.BOM_BE
			or file_data[:3] == codecs.BOM_LE
			or file_data[:3] == codecs.BOM_UTF8
		):
			file_data = file_data[3:]
		
		
		#try decode
		file_data = TryDecode(file_data)
		if (not file_data):
			print("[Failed]: " + file_name)
			return
		
		#encode
		file_data = file_data.encode("gb2312")

		#replace EOL
		# file_data = file_data.replace('\r\n', '\n')
		# file_data = file_data.replace('\r', '\n') 

		#save
		target_file = open(file_name, 'w')
		target_file.write(file_data)
		target_file.close()
		
	except:
		print("[Error]: " + file_name)





if __name__ == "__main__":
	PATH_SRC_FILE_DIR = "./"
	
	if len(sys.argv) >= 2:
		if sys.argv[1]:
			PATH_SRC_FILE_DIR = sys.argv[1]
	
	
	#get file list
	file_list = GetFileList(PATH_SRC_FILE_DIR, "", "")
	
	for file_path_data in file_list:
		#get file path
		source_file_path = file_path_data[0]
		result_file_path = file_path_data[1]
		
		EncodeToUTF8(source_file_path)
		
	print("===Finished Encrypting===")
	print("Total File:", len(file_list))
	
	