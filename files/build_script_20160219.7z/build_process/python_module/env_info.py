#!/usr/bin/python
#coding:utf-8 

import os


##--------------------------------------------------------------------------------------
def GetEnvInfo (key = None):
	sys_env_list = os.environ
	
	if (key != None):
		if (key in sys_env_list):
			return sys_env_list[key]
	else:
		return sys_env_list
	
##--------------------------------------------------------------------------------------
def SetEnvInfo (key, value = None):
	sys_env_list = os.environ
	
	if (key != None):
		if (value != None):
			sys_env_list[str(key)] = str(value)
		else:
			if (key in sys_env_list):		
				del sys_env_list[str(key)]
	else:
		print("[SetEnvInfo][Error] no key provided")
		exit(1)

##--------------------------------------------------------------------------------------	











if __name__ == "__main__":
	import sys
	self_module_name = sys.argv[0].split(".")[0]
	print('''
#Env Info#
get and set system environment info

Usage:
	import %s
	value = %s.GetEnvInfo ("KEY")
	%s.GetEnvInfo ("KEY", "value")
	''' % (self_module_name, self_module_name, self_module_name))
	
	#print(GetEnvInfo ("HOME"))
	#print(GetEnvInfo ("USERNAME"))
	#print(GetEnvInfo ())
	#print(SetEnvInfo ("Bean", 2))
	#print(GetEnvInfo ("Bean"))
	#print(GetEnvInfo ("BEAN"))
	#print(GetEnvInfo ())