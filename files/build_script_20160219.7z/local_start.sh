#!/bin/bash

# if [ "$BUILD_TARGET" == "[CHOOSE ONE BELOW]" ]; then echo "BUILD_TARGET" should not be "[CHOOSE ONE BELOW]"; exit 1; fi

# export IS_BUILD_FOR_LOCAL=true
# export BUILD_TARGET=android_debug
# export OVERWRITE_PRODUCT_NAME=AGO
# export DEBUG_SKIP_BUILD=0
# export IS_GENERATE_VERSION_FILE=0
# export ANT_BUILD_VERSION=debug
# export ANDROID_BUILD_VERSION_CODE=-1
# export ANDROID_CM_STORE_SWITCH=DEFAULT
# export ANDROID_APP_NAME_REPLACE=
# export ANDROID_PACKAGE_NAME_REPLACE=


export IS_BUILD_FOR_LOCAL=true
export BUILD_TARGET=ios_tdp_relase
export OVERWRITE_PRODUCT_NAME=AGO
export DEBUG_SKIP_BUILD=0
export IS_GENERATE_VERSION_FILE=0
export ANT_BUILD_VERSION=debug
export ANDROID_BUILD_VERSION_CODE=-1
export ANDROID_CM_STORE_SWITCH=DEFAULT
export ANDROID_APP_NAME_REPLACE=
export ANDROID_PACKAGE_NAME_REPLACE=



echo IS_BUILD_FOR_LOCAL is set as: $IS_BUILD_FOR_LOCAL
echo BUILD_TARGET is set as: $BUILD_TARGET
echo OVERWRITE_PRODUCT_NAME is set as: $OVERWRITE_PRODUCT_NAME
echo DEBUG_SKIP_BUILD is set as: $DEBUG_SKIP_BUILD
echo IS_GENERATE_VERSION_FILE is set as: $IS_GENERATE_VERSION_FILE
echo ANT_BUILD_VERSION is set as: $ANT_BUILD_VERSION
echo ANDROID_BUILD_VERSION_CODE is set as: $ANDROID_BUILD_VERSION_CODE
echo ANDROID_CM_STORE_SWITCH is set as: $ANDROID_CM_STORE_SWITCH
echo ANDROID_APP_NAME_REPLACE is set as: $ANDROID_APP_NAME_REPLACE
echo ANDROID_PACKAGE_NAME_REPLACE is set as: $ANDROID_PACKAGE_NAME_REPLACE


# get job config filename
export BUILD_CONFIG_EXT=./build_config_ext_$BUILD_TARGET.json
echo BUILD_CONFIG_EXT is set as: $BUILD_CONFIG_EXT



cd ../../

chmod +x ./client/build_script/start.sh
chmod +x ./client/build_script/build_process/build_bash_script/*.sh

chmod +x ./client/project/android/script/*.sh
chmod +x ./client/project/android_channel/liebao/script/*.sh
chmod +x ./client/project/android_channel/tdp/script/*.sh


cd ./client/build_script/

./start.sh
