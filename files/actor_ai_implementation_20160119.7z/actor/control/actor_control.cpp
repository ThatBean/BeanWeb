#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/actor_script_exporter.h"
#include "game/actor/trigger/actor_trigger.h"
#include "game/actor/logic/actor_logic_state_machine.h"

namespace actor {


  //#####################################################################


  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor)
  {

  }

  ActorControl::~ActorControl()
  {

  }

  void ActorControl::Update(float delta_time)
  {
    //for Debug quick watch
    Actor* debug_actor = actor_;
    ActorData* debug_actor_data = actor_->GetActorData();
    
    UpdateAuto();
    UpdateManual();
    UpdateStatus(); //Buff
    UpdateLogic();  //LogicState
  }



  void ActorControl::UpdateManual()
  {
    //nothing special for manual
  }

  void ActorControl::UpdateAuto()
  {
    if (actor_->GetActorData()->GetActorStatusBool(kActorStatusControlIsAuto) //preset AUTO (enemy)
      || (actor_->GetActorData()->GetActorStatusBool(kActorStatusControlIsManual) && ActorScriptExporter::GetIsAutoControl())) //UserManual + AUTO: On
    {
      if (actor_->GetActorData()->GetActorStatus(kActorStatusControlAutoReleaseSpecialSkillType) != kActorControlAutoReleaseSkillInvalid)
      {
        UpdateAutoReleaseSpecialSkill();
      }

      if (actor_->GetActorData()->GetActorStatus(kActorStatusLogicState) == kActorLogicStateIdle
        && actor_->GetActorData()->GetActorStatus(kActorStatusControlAutoGuardType) != kActorControlAutoGuardInvalid)
      {
        UpdateAutoGuard();
      }
    }
  }

  void ActorControl::UpdateStatus()
  {
    ActorBuffData* buff_data = actor_->GetActorData()->GetBuffData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    //update incontrollable
    buff_data->UpdateIncontrollable();

    //check if incontrollable
    if (actor_->GetActorData()->GetActorStatusBool(kActorStatusBuffIsIncontrollable) == true)
      control_data->AddIdOperation(kActorControlOperationTypeIncontrollable, kActorControlPriorityIncontrollable, kActorIncontrollableBuff);  //mute other operation with higher priority
    else
      control_data->RemoveOperationData(kActorControlOperationTypeIncontrollable);

    //update shader
    actor_->GetActorData()->SetActorStatus(kActorStatusBuffShaderType, buff_data->UpdateShader());
  }

  void ActorControl::UpdateLogic()
  {
    eActorLogicState result_logic_state_type = DecideLogicState();

    bool is_change_state = ControlLogicStateChange(result_logic_state_type);
    
    if (is_change_state)
    {
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateLogic] ControlLogicStateChange PASS result_logic_state_type:%d control_priority:%d", 
        result_logic_state_type, 
        actor_->GetActorData()->GetControlData()->GetMaxPriority());

      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type));
    }
  }


  //decide logic state, this will be checked every update
  eActorLogicState ActorControl::DecideLogicState()
  {
    //check is actor dead
    if (actor_->GetIsActorAlive() == false)
    {
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][DecideLogicState] actor dead");
      return kActorLogicStateDead;
    }

    //check control logic
    switch (actor_->GetActorData()->GetControlData()->GetMaxPriorityOperationType())
    {
    case kActorControlOperationPositionMove:
    case kActorControlOperationIdTargetMove:
      return kActorLogicStateMove;
      break;
    case kActorControlOperationIdTargetAttack:
    case kActorControlOperationIdSkillAttack:
    case kActorControlOperationTypeSkillAttack:
      return kActorLogicStateAttack;
      break;
    case kActorControlOperationTypeIncontrollable:
      return kActorLogicStateIncontrollable;
      break;
    case kActorControlOperationTypeBorn:
      return kActorLogicStateBorn;
      break;
    case kActorControlOperationTypeDead:
      return kActorLogicStateDead;
      break;
    case kActorControlOperation:
      return kActorLogicStateIdle;  //nothing set, default to Idle
      break;
    default:
      assert(false);  //error type
      return kActorLogicState;
      break;
    }
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState next_logic_state_type)
  {
    eActorLogicState current_logic_state_type = (eActorLogicState)actor_->GetActorData()->GetActorStatus(kActorStatusLogicState);

    if (current_logic_state_type == next_logic_state_type
      || next_logic_state_type == kActorLogicState)
      return false;

    switch (next_logic_state_type)
    {
    case kActorLogicStateMove:
      if (actor_->GetActorData()->GetActorStatusBool(kActorStatusIsMuteMove)
        || actor_->GetActorData()->GetActorStatusBool(kActorStatusBuffIsMuteMove))
      {
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetMove);
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationPositionMove);
        return false;
      }
      break;
    case kActorLogicStateAttack:
      if (actor_->GetActorData()->GetActorStatusBool(kActorStatusIsMuteAttack)
        || actor_->GetActorData()->GetActorStatusBool(kActorStatusBuffIsMuteAttack))
      {
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetAttack);  //can't attack at all
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdSkillAttack);  //can't attack at all
        actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeSkillAttack);  //can't attack at all
        return false;
      }
      break;
    }

    return true;
  }


  void ActorControl::UpdateAutoGuard()
  {
    //check trigger
    ActorTrigger* auto_trigger = actor_->GetActorData()->GetSkillData()->GetAutoTrigger();
    if (auto_trigger)
    {
      auto_trigger->Update();
      if (auto_trigger->GetIsTriggered())
      {
        switch(actor_->GetActorData()->GetActorStatus(kActorStatusControlAutoGuardType))
        {
        case kActorControlAutoGuardDefault:
          switch (actor_->GetActorData()->GetActorStatus(kActorStatusSkillAttackType))
          {
          case kActorAttackMelee:
            {
              if (actor_->GetActorData()->GetActorStatus(kActorStatusCareer) == kActorCareerWarrior)
                UpdateAutoGuardMelee(auto_trigger);//for melee character
              if (actor_->GetActorData()->GetActorStatus(kActorStatusCareer) == kActorCareerKnight)
                UpdateAutoGuardMeleeX(auto_trigger);//special for home defenders
            }
            break;
          case kActorAttackRanged:
            if (rand() > 0.7f * RAND_MAX) 
              UpdateAutoGuardRangedNearestX(auto_trigger); //for ranged character
            else
              UpdateAutoGuardRangedNearestY(auto_trigger); //for ranged character
            break;
          }
          break;
        case kActorControlAutoGuardPreferY:
          switch (actor_->GetActorData()->GetActorStatus(kActorStatusSkillAttackType))
          {
          case kActorAttackMelee:
            UpdateAutoGuardMeleeY(auto_trigger); //special for home defenders
            break;
          case kActorAttackRanged:
            UpdateAutoGuardRangedNearestY(auto_trigger); //for ranged character
            break;
          }
          break;
        case kActorControlAutoGuard:
        default:
          assert(false);
          break;
        }
      }
    }
  }


  void ActorControl::UpdateAutoReleaseSpecialSkill()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
    ActorSkillData* skill_data = actor_->GetActorData()->GetSkillData();

    int skill_id_special = actor_->GetActorData()->GetSkillData()->GetSkillIdByType(kActorSkillSpecial);
    if (skill_id_special == ACTOR_INVALID_ID)
      return;

    bool is_special_skill_ready = skill_data->GetSkillInfoById(skill_id_special)
      ? skill_data->IsSkillValid(skill_id_special)
      : false;
    
    switch (actor_->GetActorData()->GetActorStatus(kActorStatusControlAutoReleaseSpecialSkillType))
    {
    case kActorControlAutoReleaseSkillWithPause:
      {
        if (is_special_skill_ready)
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSpecialSkill] UpdateAutoReleaseSpecialSkill WithPause PASS AutoReleaseSpecialSkill");
          AutoReleaseSpecialSkill(actor_->GetScriptObjectId());//more directly
        }
      }
      break;
    case kActorControlAutoReleaseSkillNoPause:
      {
        if (is_special_skill_ready)
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSpecialSkill] UpdateAutoReleaseSpecialSkill NoPause PASS SetSkill:%d", skill_id_special);
          actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdSkillAttack, kActorControlPriorityAttackSpecialAuto, skill_id_special);
        }
      }
      break;
    case kActorControlAutoReleaseSkillWithProbability:
      {
        if (actor_->GetActorData()->GetActorStatus(kActorStatusLogicState) == kActorLogicStateIdle
          && ((rand() % 100) < actor_->GetActorData()->GetActorStatus(kActorStatusControlAutoReleaseSpecialSkillProbability) * 100))
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSpecialSkill] UpdateAutoReleaseSpecialSkill WithProbability PASS SetSkill:%d", skill_id_special);
          actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdSkillAttack, kActorControlPriorityAttackSpecialAuto, skill_id_special);
        }
      }
      break;
    case kActorControlAutoReleaseSkillByAttackCount:
      {
        int count = actor_->GetActorData()->GetActorStatus(kActorStatusControlAutoReleaseSpecialSkillCount);
        if (actor_->GetActorData()->GetActorStatus(kActorStatusLogicState) == kActorLogicStateIdle
          && (int)actor_->GetActorData()->GetActorAttribute(kActorAttributeAttackCount) % count == (count - 1))
        {
          actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoReleaseSpecialSkill] UpdateAutoReleaseSpecialSkill WithProbability PASS SetSkill:%d", skill_id_special);
          actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdSkillAttack, kActorControlPriorityAttackSpecialAuto, skill_id_special);
        }
      }
      break;
    case kActorControlAutoReleaseSkill:
    default:
      assert(false);
      break;
    }
  }

  void ActorControl::UpdateAutoGuardMelee(ActorTrigger* auto_trigger)
  {
    int target_id = *(auto_trigger->GetTriggeredActorIdList()->begin());
    actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id); //move to target
    actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoGuardMelee] target_id:%d", target_id);
  }

  void ActorControl::UpdateAutoGuardMeleeX(ActorTrigger* auto_trigger)
  {
    std::list<Actor*>* triggered_actor_list = auto_trigger->GetTriggeredActorList();

    int target_id = -1;
    float target_position_x_min = 9999999;
    eActorAnimationDirection home_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorStatusHomeDirection);
    float home_position_x = (home_direction == kActorAnimationDirectionLeft ? 0 : 1500);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      if (target_position_x_min > abs(home_position_x - target_position.x))
      {
        target_position_x_min = abs(home_position_x - target_position.x);
        target_id = target_actor->GetScriptObjectId();
      }
      ++iterator;
    }

    if (target_id >= 0 && target_position_x_min > 0)
    {
      //move to target
      actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id);
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoGuardMeleeX] target_id:%d", target_id);
    }
  }


  void ActorControl::UpdateAutoGuardMeleeY(ActorTrigger* auto_trigger)
  {
    std::list<Actor*>* triggered_actor_list = auto_trigger->GetTriggeredActorList();

    int target_id = -1;
    bool has_same_grid_y_target = false;
    float target_distance_min = 9999999;
    cocos2d::CCPoint actor_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
    int actor_grid_y= GetGridYFromPositionY(actor_position.y);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

      float target_distance = actor_position.getDistance(target_position);
      bool is_same_grid_y_target = (GetGridYFromPositionY(target_position.y) == actor_grid_y);

      if ( (has_same_grid_y_target == false && is_same_grid_y_target == true) //same grid y first, highest priority
        || (has_same_grid_y_target == is_same_grid_y_target && target_distance_min > target_distance) ) //then distance
      {
        target_distance_min = target_distance;
        has_same_grid_y_target = is_same_grid_y_target;
        target_id = target_actor->GetScriptObjectId();
      }

      ++iterator;
    }

    if (target_id >= 0 && target_distance_min > 0)
    {
      //move to target
      actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id);
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateAutoGuardMeleeY] target_id:%d", target_id);
    }
  }

  void ActorControl::UpdateAutoGuardRangedNearestX(ActorTrigger* auto_trigger)
  {
    // -- the grid-y of the closest to home enemy
    std::list<Actor*>* triggered_actor_list = auto_trigger->GetTriggeredActorList();

    int target_grid_y = -1;
    float target_position_x_min = 9999999;
    eActorAnimationDirection home_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorStatusHomeDirection);
    float home_position_x = (home_direction == kActorAnimationDirectionLeft ? 0 : 1500);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      if (target_position_x_min > abs(home_position_x - target_position.x))
      {
        target_position_x_min = abs(home_position_x - target_position.x);
        target_grid_y = GetGridYFromPositionY(target_position.y);
      }
      ++iterator;
    }

    if (target_grid_y > 0 && target_position_x_min > 0)
    {
      bool is_grid_y_valid[GRID_Y_RANGE] = {false, false, false};
      is_grid_y_valid[target_grid_y - 1] = true;
      actor_->GetActorData()->GetLog()->AddLog("[ActorControl][UpdateAutoGuardRangedNearestX]");
      ApplyAutoRangedPosition(is_grid_y_valid);
    }
  }

  void ActorControl::UpdateAutoGuardRangedNearestY(ActorTrigger* auto_trigger)
  {
    // -- the least-moving-possible-grid-y change
    std::list<Actor*>* triggered_actor_list = auto_trigger->GetTriggeredActorList();

    bool is_grid_y_valid[GRID_Y_RANGE] = {false, false, false};

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      int target_grid_y = GetGridYFromPositionY(target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).y);
      is_grid_y_valid[target_grid_y - 1] = true;
      ++iterator;
    }

    actor_->GetActorData()->GetLog()->AddLog("[ActorControl][UpdateAutoGuardRangedNearestY]");
    ApplyAutoRangedPosition(is_grid_y_valid);
  }

  void ActorControl::ApplyAutoRangedPosition(bool is_grid_y_valid[])  //find the valid position close to home base line
  {
    cocos2d::CCPoint actor_grid = GetGridFromPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));
    if (is_grid_y_valid[(int)(actor_grid.y) - 1])
      return; // target and actor already in row

    //set target Grid to home base line
    eActorAnimationDirection actor_home_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorStatusHomeDirection);
    cocos2d::CCPoint target_grid = ccp(actor_home_direction == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT : GRID_X_RANGE_RIGHT, actor_grid.y);

    //find best grid (is_grid_y_valid + nearest available)
    bool is_target_grid_position_valid = false;
    float target_grid_distance_min = 99999;
    cocos2d::CCPoint target_grid_position;

    //std::list<cocos2d::CCPoint>* valid_grid_list = actor_->GetActorData()->GetSpecifiedData()->GetValidGridList(actor_->GetActorExtEnv()->GetActorExtGrid()->GetActorGridList());
    std::list<cocos2d::CCPoint>* valid_grid_list = actor_->GetActorExtEnv()->GetActorExtGrid()->GetValidGridList(actor_);
    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;
        if (is_grid_y_valid[(int)(grid_position.y) - 1])
        {
          float target_grid_distance = grid_position.getDistance(target_grid);
          if (target_grid_distance < target_grid_distance_min)
          {
            is_target_grid_position_valid = true;
            target_grid_distance_min = target_grid_distance;
            target_grid_position = grid_position;
          }
        }
        ++iterator;
      }
    }

    delete valid_grid_list;

    //move to grid
    if (is_target_grid_position_valid)
    {
      actor_->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveManual, GetPositionFromGrid(target_grid_position));

      actor_->GetActorExtEnv()->GetActorExtGrid()->GetActorGridList()->push_back(std::pair<Actor*, cocos2d::CCPoint>(actor_, target_grid_position));  //prevent another actor move to 
      actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][ApplyAutoRangedPosition] target_grid_position:(%f,%f)", target_grid_position.x, target_grid_position.y);
    }
  }


  void ActorControl::UpdateSpecialGuard(int type)
  {
    //check trigger
    ActorTrigger* auto_trigger = actor_->GetActorData()->GetSkillData()->GetAutoTrigger();
    if (auto_trigger)
    {
      bool is_pause = auto_trigger->GetIsPause();
      auto_trigger->SetIsPause(false);
      auto_trigger->Update();
      if (auto_trigger->GetIsTriggered())
      {
        switch (type)
        {
        case 0:
        default:
          switch (actor_->GetActorData()->GetActorStatus(kActorStatusSkillAttackType))
          {
          case kActorAttackMelee:
            {
              Actor* target_actor = *(auto_trigger->GetTriggeredActorList()->begin());
              int target_id = target_actor->GetScriptObjectId();
              float distance = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).getDistance(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));
              if (distance <= GetGridBoxAverageWidth() * 3)
              {
                actor_->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityCheckAttackAuto, target_id); //move to target
                actor_->GetActorData()->GetLog()->AddLogF("[ActorControl][UpdateSpecialGuard] type:%d, target_id:%d", type, target_id);
              }
              else
              {
                actor_->GetActorData()->GetLog()->AddErrorLogF("[ActorControl][UpdateSpecialGuard] too far, dropped target actor %d", target_id);
              }
            }
            break;
          }
          break;
        }
      }
      auto_trigger->SetIsPause(is_pause);
    }
    else
    {
      actor_->GetActorData()->GetLog()->AddErrorLogF("[ActorControl][UpdateSpecialGuard] no GuardTriggerAuto!");
      assert(false);
    }
  }

} // namespace actor