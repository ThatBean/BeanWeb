#ifndef ACTOR_TRIGGER_PREDEFINED_H
#define ACTOR_TRIGGER_PREDEFINED_H

#include "actor_trigger.h"
#include "actor_trigger_module.h"

namespace actor {

  class Actor;

  enum eActorPredefinedTriggerType
  {
    kActorPredefinedAttackTriggerCircle = 1000,
    kActorPredefinedAttackTriggerRect,
    kActorPredefinedAttackTriggerHeal,

    kActorPredefinedGuardTriggerCircle = 2000,
    kActorPredefinedGuardTriggerRect,

    kActorPredefinedAutoTriggerNearFirst = 3000,
    kActorPredefinedAutoTriggerSameRowFirst,

    kActorPredefinedTrigger = -1
  };


  ActorTrigger* GetPredefinedAttackTrigger(eActorPredefinedTriggerType predefined_trigger_type, Actor* actor, float size_multiplier = 1.0f);
  ActorTrigger* GetPredefinedGuardTrigger(eActorPredefinedTriggerType predefined_trigger_type, Actor* actor, float size_multiplier = 1.0f);
  ActorTrigger* GetPredefinedAutoTrigger(eActorPredefinedTriggerType predefined_trigger_type, Actor* actor);

} // namespace actor


#endif // ACTOR_TRIGGER_PREDEFINED_H
