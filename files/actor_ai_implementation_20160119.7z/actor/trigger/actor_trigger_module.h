#ifndef ACTOR_TRIGGER_MODULE_H
#define ACTOR_TRIGGER_MODULE_H


#include "engine/base/basictypes.h"


namespace actor 
{
  
  class Actor;

  enum eActorTriggerModule
  {
    kActorTriggerModuleActorData,
    kActorTriggerModuleFaction,
    kActorTriggerModuleGeometry,
    kActorTriggerModuleStatus,
    kActorTriggerModuleScript,  //lua
    kActorTriggerModuleActive,  //will cause target status change, maybe a bad idea
    kActorTriggerModuleSort,  //
    kActorTriggerModule
  };

  

  class  ActorTriggerModuleData
  {
  public:
    ActorTriggerModuleData()
      :trigger_flag_(0)
    {}
    ActorTriggerModuleData(const ActorTriggerModuleData& source)
      :trigger_flag_(source.trigger_flag_)
    {}
    virtual ~ActorTriggerModuleData() {}

    void      SetTriggerFlag(uint_32 trigger_flag) { trigger_flag_ = trigger_flag; }
    void      AddTriggerFlag(uint_32 trigger_flag) { trigger_flag_ |= trigger_flag; }
    uint_32   GetTriggerFlag() { return trigger_flag_; }

    virtual eActorTriggerModule   GetTargetTriggerModuleType() = 0;
  private:
    uint_32 trigger_flag_; 
  };



  class ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  public:
    ActorTriggerModule() {}
    ~ActorTriggerModule() {}

    virtual bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data, std::list<Actor*>* actor_list) = 0;

    virtual eActorTriggerModule   GetTriggerModuleType() = 0;
  };
  
  ActorTriggerModule* GetActorTriggerModule(eActorTriggerModule module_type);
  ActorTriggerModuleData* GetActorTriggerModuleData(eActorTriggerModule module_type, uint_32 trigger_flag = 0);
  ActorTriggerModuleData* GetActorTriggerModuleDataCopy(ActorTriggerModuleData* module_data);

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_H