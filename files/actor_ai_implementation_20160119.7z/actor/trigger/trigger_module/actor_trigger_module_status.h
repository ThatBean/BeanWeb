#ifndef ACTOR_TRIGGER_MODULE_STATUS_H
#define ACTOR_TRIGGER_MODULE_STATUS_H


#include "game/actor/trigger/actor_trigger_module.h"


namespace actor 
{
  enum eActorTriggerStatusFlag
  {
    kActorTriggerStatusFlagHealthRatio  = 1 << 0,
    //kActorTriggerStatusFlagHealthRatio  = 1 << 1,
    //kActorTriggerStatusFlagHealthRatio  = 1 << 2,
    kActorTriggerStatusFlag = 0
  };


  class ActorTriggerModuleDataStatus: public ActorTriggerModuleData
  {
  public:
    virtual eActorTriggerModule   GetTargetTriggerModuleType() { return kActorTriggerModuleStatus; }

    ActorTriggerModuleDataStatus() 
      : ActorTriggerModuleData(),
      health_ratio_min_(-1),
      health_ratio_max_(-1)
    {

    }

    ActorTriggerModuleDataStatus(const ActorTriggerModuleDataStatus& source) 
      : ActorTriggerModuleData(source),
      health_ratio_min_(source.health_ratio_min_),
      health_ratio_max_(source.health_ratio_max_)
    {

    }

    void  SetHealthRatio(float ratio_a, float ratio_b = 0);
    float GetHealthRatioMax() { return health_ratio_max_; }
    float GetHealthRatioMin() { return health_ratio_min_; }

    //faster loop filter
    void  ResetQuickFilter();
    bool  InitQuickFilter(Actor* actor);  //return init result: true = need filter, false = keep all
    bool  QuickFilter(Actor* ref_actor);  //return is_filtered: true = remove, false = keep

  private:
    float health_ratio_min_;
    float health_ratio_max_;

    //quick filter data
    bool  _filter_is_use_health_ratio_;
  };

  class ActorTriggerModuleStatus: public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleStatus() {}

  public:
    static ActorTriggerModuleStatus* Instance();
    ~ActorTriggerModuleStatus() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateStatus(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list);
//     void     UpdateDirection(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list);
//     void     UpdateLocation(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list);

    virtual eActorTriggerModule   GetTriggerModuleType() { return kActorTriggerModuleStatus; }
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_STATUS_H