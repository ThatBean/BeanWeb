#include "actor_trigger_module_actor_data.h"

#include "game/actor/actor.h"

namespace actor 
{
  void ActorTriggerModuleDataActorData::SetFilterAttribute(eActorTriggerActorDataFilterMethod filter_method, eActorAttributeType filter_data_type, float filter_value, float tolerance)
  { 
    AddTriggerFlag(kActorTriggerActorDataFlagAttribute);
    filter_method_attribute_ = filter_method;
    filter_data_type_attribute_ = filter_data_type;
    filter_value_attribute_ = filter_value;
    tolerance_attribute_ = tolerance;
  }

  void ActorTriggerModuleDataActorData::SetFilterStatus(eActorTriggerActorDataFilterMethod filter_method, eActorStatusType filter_data_type, int filter_value, float tolerance)
  { 
    AddTriggerFlag(kActorTriggerActorDataFlagStatus);
    filter_method_status_ = filter_method;
    filter_data_type_status_ = filter_data_type;
    filter_value_status_ = filter_value;
    tolerance_status_ = tolerance;
  }

  void ActorTriggerModuleDataActorData::SetFilterPosition(eActorTriggerActorDataFilterMethod filter_method, eActorPositionType filter_data_type, cocos2d::CCPoint filter_value, float tolerance)
  { 
    AddTriggerFlag(kActorTriggerActorDataFlagPosition);
    filter_method_position_ = filter_method;
    filter_data_type_position_ = filter_data_type;
    filter_value_position_ = filter_value;
    tolerance_position_ = tolerance;
  }

  void ActorTriggerModuleDataActorData::ResetQuickFilter()
  {
    _filter_is_use_attribute_ = false;
    _filter_is_use_status_ = false;
    _filter_is_use_position_ = false;
    _filter_is_use_alive_actor_ = false;
  }
  bool ActorTriggerModuleDataActorData::InitQuickFilter(Actor* actor)  //return init result: true = need filter, false = keep all
  {
    ResetQuickFilter();

    if (GetTriggerFlag() & kActorTriggerActorDataFlagAttribute) _filter_is_use_attribute_ = true;
    if (GetTriggerFlag() & kActorTriggerActorDataFlagStatus) _filter_is_use_status_ = true;
    if (GetTriggerFlag() & kActorTriggerActorDataFlagPosition) _filter_is_use_position_ = true;
    if (GetTriggerFlag() & kActorTriggerActorDataFlagAliveActor) _filter_is_use_alive_actor_ = true;

    return _filter_is_use_attribute_ 
      || _filter_is_use_status_ 
      || _filter_is_use_position_ 
      || _filter_is_use_alive_actor_;
  }
  bool ActorTriggerModuleDataActorData::QuickFilter(Actor* ref_actor)  //return is_filtered: true = remove, false = keep
  {
    if (_filter_is_use_attribute_)
    {
      float ref_actor_data_value = ref_actor->GetActorData()->GetActorAttribute(filter_data_type_attribute_);

      switch (filter_method_attribute_)
      {
      case kActorTriggerActorDataFilterMethodEqual:
        if (ref_actor_data_value != filter_value_attribute_) return true;
        break;
      case kActorTriggerActorDataFilterMethodEqualNot:
        if (ref_actor_data_value == filter_value_attribute_) return true;
        break;
      case kActorTriggerActorDataFilterMethodApproximate:
        if (abs(ref_actor_data_value - filter_value_attribute_) > tolerance_attribute_ * filter_value_attribute_) return true;
        break;
      }
    }

    if (_filter_is_use_status_)
    {
      int ref_actor_data_value = ref_actor->GetActorData()->GetActorStatus(filter_data_type_status_);

      switch (filter_method_status_)
      {
      case kActorTriggerActorDataFilterMethodEqual:
        if (ref_actor_data_value != filter_value_status_) return true;
        break;
      case kActorTriggerActorDataFilterMethodEqualNot:
        if (ref_actor_data_value == filter_value_status_) return true;
        break;
      case kActorTriggerActorDataFilterMethodApproximate:
        if (abs(ref_actor_data_value - filter_value_status_) > tolerance_status_) return true;
        break;
      }
    }

    if (_filter_is_use_position_)
    {
      cocos2d::CCPoint ref_actor_data_value = ref_actor->GetActorData()->GetActorPosition(filter_data_type_position_);

      switch (filter_method_position_)
      {
      case kActorTriggerActorDataFilterMethodEqual:
        if (!ref_actor_data_value.equals(filter_value_position_)) return true;
        break;
      case kActorTriggerActorDataFilterMethodEqualNot:
        if (ref_actor_data_value.equals(filter_value_position_)) return true;
        break;
      case kActorTriggerActorDataFilterMethodApproximate:
        if (ref_actor_data_value.getDistance(filter_value_position_) > tolerance_position_) return true;
        break;
      }
    }

    if (_filter_is_use_alive_actor_)
    {
      if (ref_actor->GetIsActorAlive() == false) return true;
    }

    return false;
  }


  ActorTriggerModuleActorData* ActorTriggerModuleActorData::Instance()
  {
    static ActorTriggerModuleActorData instance;
    return &instance;
  }

  bool ActorTriggerModuleActorData::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataActorData* trigger_module_data = dynamic_cast<ActorTriggerModuleDataActorData*>(trigger_module_data_);

    assert(trigger_module_data);

    UpdateActorData(actor, trigger_module_data, actor_list);

    return (actor_list->size() > 0);
  }

  void ActorTriggerModuleActorData::UpdateActorData(Actor* actor, ActorTriggerModuleDataActorData* trigger_module_data, std::list<Actor*>* actor_list)
  {
    bool is_filter_needed = trigger_module_data->InitQuickFilter(actor);
    if (is_filter_needed == false) return;

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* ref_actor = *iterator;

      bool is_filter = trigger_module_data->QuickFilter(ref_actor);

      if (is_filter)
        actor_list->erase(iterator++);
      else
        ++iterator;
    }
  }

}  // namespace actor