#ifndef ACTOR_TRIGGER_MODULE_SORT_H
#define ACTOR_TRIGGER_MODULE_SORT_H


#include "game/actor/trigger/actor_trigger_module.h"


namespace actor 
{
  enum eActorTriggerSortFlag
  {
    kActorTriggerSortFlagDistance   = 1 << 0,
    kActorTriggerSortFlagHealth     = 1 << 1,
    kActorTriggerSortFlagDiffGridY  = 1 << 2,
    kActorTriggerSortFlag = 0
  };

  class ActorTriggerModuleDataSort : public ActorTriggerModuleData
  {
  public:
    virtual eActorTriggerModule   GetTargetTriggerModuleType() { return kActorTriggerModuleSort; }

    ActorTriggerModuleDataSort()
      :ActorTriggerModuleData(),
      is_reverse_(false)
    {

    }

    ActorTriggerModuleDataSort(const ActorTriggerModuleDataSort& source)
      :ActorTriggerModuleData(source),
      is_reverse_(source.is_reverse_)
    {

    }

    void  SetIsReverse(bool is_reverse) { is_reverse_ = is_reverse; }
    bool  GetIsReverse() { return is_reverse_; }


  private:
    bool  is_reverse_;
  };

  class ActorTriggerModuleSort : public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleSort() {}

  public:
    static ActorTriggerModuleSort* Instance();
    ~ActorTriggerModuleSort() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateDistance(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list);
    void     UpdateHealth(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list);
    void     UpdateDiffGridY(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list);

    virtual eActorTriggerModule   GetTriggerModuleType() { return kActorTriggerModuleSort; }
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_SORT_H