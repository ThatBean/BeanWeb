#include "actor_animation_effect.h"

#include "game/actor/actor.h"

#include "game/actor/actor_adapter.h"

#include "engine/script/lua_tinker_manager.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/effect_config_data_table.h"

#include "engine/animation/projectile_animation.h"

namespace actor {

  //ActorAnimationEffect
  ActorAnimationEffect::ActorAnimationEffect(Actor* actor)
    : actor_(actor)
    , effect_node_(NULL)
  {
    //
  }

  ActorAnimationEffect::~ActorAnimationEffect()
  {
    Clear();
  }

  void ActorAnimationEffect::Clear()
  {
    if (effect_node_)
    {
      if (effect_node_->getTag() == kActorAnimationProjectileName)
      {
        effect_node_->release();
      }

      effect_node_->removeFromParentAndCleanup(true);
      effect_node_ = NULL;
    }
  }

  void ActorAnimationEffect::Init()
  {
    int effect_id = actor_->GetActorData()->GetActorStatus(kActorStatusEffectConfigId);

    //loop effect timeline item and save link
    EffectConfigData* effect_config_data = DataManager::GetInstance().GetEffectConfigDataTable()->GetEffectConfig(effect_id);

    //check valid
    if (!effect_config_data)
    {
      CCLog("[ActorAnimationEffect][Init] missing effect config id: %d", effect_id);
      assert(false);
      return;
    }
    //check valid

    Clear();

    //animation
    switch (effect_config_data->GetAnimationType())
    {
    case kActorAnimationNone:
      {
        effect_node_ = cocos2d::CCSprite::create(); //invisible

#ifdef WIN32
        bool is_show_effect_debug_sprite = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_show_effect_debug_sprite");
        if (is_show_effect_debug_sprite)
        {
          cocos2d::CCSprite* effect_node_sprite = (cocos2d::CCSprite*)effect_node_;
          effect_node_sprite->initWithFile("textures/battle/agoui_effect_debug_marker.png");
        }
#endif

        effect_node_->setTag(kActorAnimationNone);
      }
      break;
    case kActorAnimationArmatureName:
      {
        std::string armature_name = effect_config_data->GetAnimationName();
        std::string movement_name = "bsj";

        CCArmature* armature_animation = CCArmature::create();

        if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
        {
          std::string skeleton_config = taomee::kDefaultSkeletonFilePath + armature_name + ".xml";
          std::string skeleton_plist = taomee::kDefaultSkeletonFilePath + armature_name + ".plist";
          std::string skeleton_texture = taomee::kDefaultSkeletonFilePath + armature_name + ".pvr.ccz";
          CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
        }
        armature_animation->init(armature_name.c_str());
        armature_animation->getAnimation()->play(movement_name.c_str(), 0, -1, 0);

        effect_node_ = armature_animation;

        effect_node_->setTag(kActorAnimationArmatureName);
      }
      break;
    case kActorAnimationProjectileName:
      {
        std::string projectile_name = effect_config_data->GetAnimationName();

        taomee::ProjectileAnimation* projectile_animation = new taomee::ProjectileAnimation();
        projectile_animation->initWithName(projectile_name.c_str());
        projectile_animation->setPositionType(kCCPositionTypeRelative);
        //projectile_animation->release();

        effect_node_ = projectile_animation;

        effect_node_->setTag(kActorAnimationProjectileName);
      }
      break;
    default:
      CCLog("[ActorAnimationEffect][Init] error effect animation type: %d", effect_config_data->GetAnimationType());
      assert(false);
      break;
    }


    //size debug
//     bool is_show_skeleton_animation_box = true;//LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_show_actor_box");
//     if (effect_node_ && is_show_skeleton_animation_box)
//     {
//       
// 
//       CCDrawNode* debug_box_draw_node = CCDrawNode::create();
//       CCRect rect_box = cocos2d::CCRect(
//         -effect_config_data->GetTriggerRangeWidth() * 0.5 + (actor_->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight 
//           ? effect_config_data->GetTriggerRangeX()
//           : -effect_config_data->GetTriggerRangeX()), 
//         -effect_config_data->GetTriggerRangeHeight() * 0.5 + effect_config_data->GetTriggerRangeY(), 
//         effect_config_data->GetTriggerRangeWidth(), 
//         effect_config_data->GetTriggerRangeHeight());
//       CCPoint vertex_list[4]={
//         ccp(rect_box.getMinX(), rect_box.getMinY()), ccp(rect_box.getMaxX(), rect_box.getMinY()),
//         ccp(rect_box.getMaxX(), rect_box.getMaxY()), ccp(rect_box.getMinX(), rect_box.getMaxY())};
//         ccColor4F fill_color = {1, 0, 0, 0.1};  //transparent
//         float debug_box_border_width = 3;
//         ccColor4F border_color = {1, 1, 0, 1};  //yellow
//         debug_box_draw_node->drawPolygon(vertex_list, 4, fill_color, debug_box_border_width, border_color);
//         effect_node_->addChild(debug_box_draw_node, -1);
//     }
  }


  void ActorAnimationEffect::Update(float delta_time)
  {
    
  }

  cocos2d::CCRect ActorAnimationEffect::GetEffectBox()
  {
    CCPoint effect_position = effect_node_->getPosition();
    return cocos2d::CCRect(effect_position.x, effect_position.y, 0, 0);
  }
  //ActorAnimationEffect
} // namespace actor