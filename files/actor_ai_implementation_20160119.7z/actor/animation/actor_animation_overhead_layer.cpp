#include "actor_animation_overhead_layer.h"

#include "game/actor/actor.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"

namespace actor {

  //ActorAnimationOverheadLayer
  ActorAnimationOverheadLayer::ActorAnimationOverheadLayer(Actor* actor)
    :actor_(actor),
    overhead_layer_(NULL),
    health_bar_layer_(NULL),
    health_bar_widget_(NULL),
    health_bar_bg_widget_(NULL),
    health_bar_left_time_(0)
  {

  }

  ActorAnimationOverheadLayer::~ActorAnimationOverheadLayer()
  {
    Clear();
  }

  void ActorAnimationOverheadLayer::Clear()
  {
    //overhead_layer_ will be cleared with skeleton_animation_node_
    if (health_bar_widget_) health_bar_widget_->release();
    if (health_bar_bg_widget_) health_bar_bg_widget_->release();

    overhead_layer_ = NULL;
    health_bar_widget_ = NULL;
    health_bar_bg_widget_ = NULL;
  }

  void ActorAnimationOverheadLayer::Init()
  {
    //create UILayer for health bar update
    overhead_layer_ = UILayer::create();
    overhead_layer_->scheduleUpdate();
    
    health_bar_layer_ = UIFactory::createWidgetFromFile("ui/agoui_battle_actor_health_bar.json");
    health_bar_layer_->setScale(1.2);
    overhead_layer_->addWidget(health_bar_layer_);

    ActorBuffStatusBitSet status_bit_set = actor_->GetActorData()->GetBuffData()->GetBuffStatusBitFlag();

    UIImageView* icon_widget = dynamic_cast<UIImageView*>(overhead_layer_->getWidgetByName("ImageView_Icon"));
    if (status_bit_set.test(kActorBuffStatusElementFire)) icon_widget->loadTexture("agoui_element_1.png", UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementWater)) icon_widget->loadTexture("agoui_element_2.png", UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementWind)) icon_widget->loadTexture("agoui_element_3.png", UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementLight)) icon_widget->loadTexture("agoui_element_4.png", UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementDark)) icon_widget->loadTexture("agoui_element_5.png", UI_TEX_TYPE_PLIST);
    else icon_widget->loadTexture("agoui_element_0.png", UI_TEX_TYPE_PLIST);

    UILabelBMFont* title_widget = dynamic_cast<UILabelBMFont*>(overhead_layer_->getWidgetByName("LabelBMFont_Title"));
    title_widget->setVisible(false);

    health_bar_widget_ = dynamic_cast<UILoadingBar*>(overhead_layer_->getWidgetByName("LoadingBar_Fg"));
    health_bar_widget_->setPercent(100);
    health_bar_widget_->retain();

    health_bar_bg_widget_ = dynamic_cast<UILoadingBar*>(overhead_layer_->getWidgetByName("LoadingBar_Bg"));
    health_bar_bg_widget_->setIsHaveAni(true);
    health_bar_bg_widget_->setPercent(100);
    health_bar_bg_widget_->retain();

    ccColor3B color_health_bar_character_user = ccc3(60, 240, 70);
    ccColor3B color_health_bar_character_yellow = ccc3(255, 200, 0);
    ccColor3B color_health_bar_monster_red = ccc3(200, 0, 0);
    ccColor3B color_health_bar_monster_boss_red = ccc3(255, 0, 0);
    ccColor3B color_health_bar_bg = ccc3(200, 0, 0);

    if (actor_->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport)
    {
      health_bar_widget_->setColor(color_health_bar_character_user);
    }
    else
    {
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance))
      {
      case kActorAppearanceCharacter:
        health_bar_widget_->setColor(color_health_bar_character_yellow);
        break;
      case kActorAppearanceEnemyPawn:
        health_bar_widget_->setColor(color_health_bar_monster_red);
        break;
      case kActorAppearanceEnemyBoss:
        health_bar_widget_->setColor(color_health_bar_monster_boss_red);
        break;
      }
    }

    health_bar_bg_widget_->setColor(color_health_bar_bg);
  }



  void ActorAnimationOverheadLayer::Update(float delta_time)
  {
    //always
    //health bar auto hiding
    if (actor_->GetActorData()->GetActorStatusBool(kActorStatusAnimationIsHealthChanged))
    {
      actor_->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsHealthChanged, false);
//       if (health_bar_layer_)
//       {
//         health_bar_left_time_ = ACTOR_ANIMATION_HEALTH_DISPLAY_TIME;
//         health_bar_layer_->setVisible(true);
//       }
    }


    if (health_bar_layer_ && health_bar_layer_->isVisible())
    {
//       health_bar_left_time_ -= delta_time;
// 
//       if (health_bar_left_time_ <= 0) health_bar_layer_->setVisible(false);
      if (health_bar_widget_ && health_bar_bg_widget_)
      {
        float health_percent = 100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax);
        health_bar_widget_->setPercent(health_percent);
        health_bar_bg_widget_->setPercent(health_percent);
      }
    }
  }
} // namespace actor