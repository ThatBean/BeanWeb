#include "actor_animation.h"

#include "game/actor/actor.h"

#include "game/actor/animation/actor_animation_skeleton_animation.h"
#include "game/actor/animation/actor_animation_overhead_layer.h"
#include "game/actor/animation/actor_animation_bottom_sync_layer.h"
#include "game/actor/animation/actor_animation_effect.h"

#include "game/actor/motion/actor_motion_state_machine.h"

#include "game/actor/actor_script_exporter.h"
#include "game/actor/actor_adapter.h"

#include "engine/script/lua_tinker_manager.h"

#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_color.h"

#include "engine/animation/projectile_animation.h"
#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/unit_constants.h"

namespace actor {

  //ActorAnimation
  ActorAnimation::ActorAnimation(Actor* actor)
    :actor_(actor),
    actor_node_(NULL),

    animation_skeleton_animation_(NULL),
    animation_overhead_layer_(NULL),
    animation_bottom_sync_layer_(NULL),
    animation_effect_(NULL),

    label_debug_info_widget_(NULL),

    program_shader_color_(NULL),
    shader_color_left_time_(0),
    shader_color_total_time_(0)
  {
    shader_type_ = taomee::shader::kShaderDefault;
  }

  ActorAnimation::~ActorAnimation()
  {
    Clear();
  }

  void ActorAnimation::Clear()
  {
    while (animation_queue_map_.empty() == false)
    {
      RemoveAnimationQueue(animation_queue_map_.begin()->first);
    }

    if (animation_bottom_sync_layer_) delete animation_bottom_sync_layer_;
    if (animation_overhead_layer_) delete animation_overhead_layer_;
    if (animation_skeleton_animation_) 
    {
      delete animation_skeleton_animation_;
      actor_node_ = NULL; //same node
    }
    if (animation_effect_) 
    {
      delete animation_effect_;
      actor_node_ = NULL; //same node
    }

    if (actor_node_) actor_node_->removeFromParentAndCleanup(true);

    animation_bottom_sync_layer_ = NULL;
    animation_overhead_layer_ = NULL;
    animation_skeleton_animation_ = NULL;
    animation_effect_ = NULL;

    actor_node_ = NULL;

    label_debug_info_widget_ = NULL;

    program_shader_color_ = NULL;
    shader_color_left_time_ = 0;
    shader_color_total_time_ = 0;

    shader_type_ = taomee::shader::kShaderDefault;
  }

  void ActorAnimation::Init(eActorAnimationModelType animation_model_type)
  {
    actor_->GetActorData()->InitActorStatus(kActorStatusAnimationModel, animation_model_type);

    //init actor_node_
    assert(actor_node_ == NULL);
    if (animation_model_type & kActorAnimationModuleSkeletonAnimation) //replace actor_node_
    {
      int card_id = actor_->GetActorData()->GetActorStatus(kActorStatusCardId);

      animation_skeleton_animation_ = new ActorAnimationSkeletonAnimation(actor_);
      animation_skeleton_animation_->Init(
        actor_->GetScriptObjectName(), 
        actor_->GetActorData()->GetActorAttribute(kActorAttributeAnimationScale));

      actor_node_ = animation_skeleton_animation_->GetSkeletonAnimationNode();
    }
    if (animation_model_type & kActorAnimationModuleEffect) //replace actor_node_
    {
      animation_effect_ = new ActorAnimationEffect(actor_);
      animation_effect_->Init();

      actor_node_ = animation_effect_->GetEffectNode();
    }
    if (!actor_node_) //default actor_node_
    {
      CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/agoui_icon/agoui_icon_ex.plist", "ui/agoui_icon/agoui_icon_ex.pvr.ccz");
      std::string file_name;
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusCareer))
      {
      case kActorCareerWarrior:
        file_name = "agoui_job_0.png";
        break;
      case kActorCareerKnight:
        file_name = "agoui_job_4.png";
        break;
      case kActorCareerPriest:
        file_name = "agoui_job_3.png";
        break;
      case kActorCareerWizard:
        file_name = "agoui_job_2.png";
        break;
      case kActorCareerArcher:
        file_name = "agoui_job_1.png";
        break;
      default:
        file_name = "agoui_boss_flag.png";
        break;
      }
      CCSprite* default_sprite_node = CCSprite::createWithSpriteFrameName(file_name.c_str());
      default_sprite_node->setAnchorPoint(ccp(0.5f, 0.5f));
      actor_node_ = default_sprite_node;
    }

    if (animation_model_type & kActorAnimationModuleOverheadLayer) 
    {
      animation_overhead_layer_ = new ActorAnimationOverheadLayer(actor_);
      animation_overhead_layer_->Init();
      cocos2d::extension::UILayer* overhead_layer = animation_overhead_layer_->GetOverheadLayer();
      overhead_layer->setPosition(ccp(0, GetActorVisualHeight()));
      actor_node_->addChild(overhead_layer);
    }

    if (animation_model_type & kActorAnimationModuleBottomSyncLayer) 
    {
      animation_bottom_sync_layer_ = new ActorAnimationBottomSyncLayer(actor_);
      animation_bottom_sync_layer_->Init();
    }

    //size debug
    bool is_show_skeleton_animation_box = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_show_actor_box");
    if (is_show_skeleton_animation_box)
    {
      CCDrawNode* debug_box_draw_node = CCDrawNode::create();
      CCRect rect_box = GetActorBox();
      rect_box.origin = ccpSub(rect_box.origin, actor_node_->getPosition());
      CCPoint vertex_list[4]={
        ccp(rect_box.getMinX(), rect_box.getMinY()), ccp(rect_box.getMaxX(), rect_box.getMinY()),
        ccp(rect_box.getMaxX(), rect_box.getMaxY()), ccp(rect_box.getMinX(), rect_box.getMaxY())};
      ccColor4F fill_color = {1, 0, 0, 0.1};  //transparent
      float debug_box_border_width = 3;
      ccColor4F border_color = {1, 1, 0, 1};  //yellow
      debug_box_draw_node->drawPolygon(vertex_list, 4, fill_color, debug_box_border_width, border_color);
      actor_node_->addChild(debug_box_draw_node, -1);
    }

    //debug info
    bool is_show_debug_info = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_show_actor_info");
    if (is_show_debug_info)
    {
      if (label_debug_info_widget_) label_debug_info_widget_->removeFromParentAndCleanup(true);
      label_debug_info_widget_ = cocos2d::CCLabelBMFont::create();
      label_debug_info_widget_->setFntFile("ui/font/font_2.fnt"); // TODO: use relative path
      label_debug_info_widget_->setPosition(ccp(GetActorBox().size.width * (- 0.5), -20));
      label_debug_info_widget_->setAnchorPoint(ccp(0, 1));
      label_debug_info_widget_->setScale(0.4);
      label_debug_info_widget_->setZOrder(99999);
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance))
      {
      case kActorAppearanceCharacter:
        label_debug_info_widget_->setColor(ccc3(200, 255, 255));
        break;
      case kActorAppearanceEnemyBoss:
        label_debug_info_widget_->setColor(ccc3(255, 200, 255));
        break;
      case kActorAppearanceEnemyPawn:
        label_debug_info_widget_->setColor(ccc3(255, 255, 200));
        break;
      }
      actor_node_->addChild(label_debug_info_widget_);
    }

  }



  void ActorAnimation::Update(float delta_time)
  {
    //pause
    bool is_status_pause = actor_->GetActorData()->GetActorStatusBool(kActorStatusAnimationIsPaused);

    if (animation_skeleton_animation_) animation_skeleton_animation_->Update(delta_time);
    if (animation_overhead_layer_) animation_overhead_layer_->Update(delta_time);
    if (animation_bottom_sync_layer_) animation_bottom_sync_layer_->Update(delta_time);

    //always
    //animation position
    if (actor_node_)
    {
      cocos2d::CCPoint data_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint animation_position = actor_node_->getPosition();

      if (actor_->GetActorData()->GetSpecifiedData()->IsPositionValid(data_position) == false
        && actor_->GetActorData()->GetSpecifiedData()->IsPositionValid(animation_position) == true) //check position, only moving out of box is blocked
      {
        actor_->GetActorData()->GetLog()->AddErrorLogF("[kActorPositionAnimation] moving out of box is blocked (%f, %f)", data_position.x, data_position.y);

//         if (actor_->GetActorData()->GetActorStatus(kActorStatusMotionState) == kActorMotionStateMove)
//         {
          actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetMove);
          actor_->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationPositionMove);
//         }

        actor_->GetActorData()->SetActorPosition(kActorPositionAnimation, animation_position);

        cocos2d::CCPoint valid_position = GetPositionFromGrid(actor_->GetActorExtEnv()->GetActorExtGrid()->GetValidGrid(actor_));
        actor_->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveAuto, valid_position);
      }
      else
      {
        actor_node_->setPosition(data_position);
      }
    }

    //except focused
    //animation scale and z-order
    if (actor_node_ && actor_->GetActorData()->GetActorStatusBool(kActorStatusAnimationIsFocused) == false)
    {
      cocos2d::CCPoint animation_position = actor_node_->getPosition();

      // TODO: need better logic
      int animation_z_order = (int(9999 - animation_position.y) << 8) + actor_->GetScriptObjectId() % (1 << 8);
      
      assert(animation_z_order > 0);

      actor_node_->setZOrder(animation_z_order);


      // TODO: need better logic(the scale doesn't make much sense, attack range will not scale)
      float animation_scale_factor = 0.85f;
      float animation_scale = 1;
      float position_y_max = GetPositionFromGrid(1, 3).y;
      float position_y_min = GetPositionFromGrid(1, 1).y;

      if (animation_position.y > position_y_max)
        animation_scale = animation_scale_factor;
      else if (animation_position.y < position_y_min)
        animation_scale = 1.0f;
      else
        animation_scale = animation_scale_factor + (1 - animation_scale_factor) * (position_y_max - animation_position.y) / (position_y_max - position_y_min);

      actor_node_->setScale(animation_scale * 0.8f);
    }


    //update color shader
    if (program_shader_color_)
    {
      if (shader_color_left_time_ > 0) 
      {
        shader_color_left_time_ -= delta_time;
        taomee::shader::ProgramChangeColor* program_shader_color = (taomee::shader::ProgramChangeColor*)program_shader_color_;
        float time_progress = shader_color_left_time_ / shader_color_total_time_ * 2.0; //0 ~ 1 opacity++, 1 ~ 2 opacity--
        float color_opacity = (time_progress <= 1 ? time_progress : 2 - time_progress);
        program_shader_color->SetTime(color_opacity);
      }
      else 
      {
        RemoveColorShader();
      }
    }

    //update typed shader
    if (actor_->GetActorData()->GetActorStatus(kActorStatusBuffShaderType) != shader_type_)
    {
      SetStatusShader(actor_->GetActorData()->GetActorStatus(kActorStatusBuffShaderType));
    }

    //debug info
    if (label_debug_info_widget_)
    {
      cocos2d::CCPoint position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint grid = GetGridFromPosition(position);

      char debug_basic_info[1024];  //please don't overflow
      sprintf(debug_basic_info, " ID:%d CID:%d \n HP:%d%% EN:%d%% \n [%d,%d] [%d,%d] \n", 
        actor_->GetScriptObjectId(), 
        actor_->GetActorData()->GetActorStatus(kActorStatusCardId), 
        int(100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax)),
        actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyMax) > 0 
          ? int(100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyMax))
          : 0,
        int(position.x), int(position.y),
        int(grid.x), int(grid.y));

      std::string debug_info_string = debug_basic_info;

      debug_info_string += ((ActorScriptExporter*)actor_->GetScriptExporter())->GetDebugText(8);

      label_debug_info_widget_->setString(debug_info_string.c_str());
    }
  }


  cocos2d::CCRect ActorAnimation::GetActorBox()
  {
    if (animation_skeleton_animation_) 
    {
      return GetAnimationSkeletonAnimation()->GetSkeletonAnimationBox();
    }
    else if (animation_effect_) 
    {
      return GetAnimationEffect()->GetEffectBox();
    }
    else 
    {
      CCPoint actor_position = actor_node_->getPosition();
      CCSize actor_size = actor_node_->getContentSize();
      return cocos2d::CCRect(
        actor_position.x - actor_size.width * 0.5, 
        actor_position.y - actor_size.height * 0.5, 
        actor_size.width, 
        actor_size.height);
    }
  }

  float ActorAnimation::GetActorVisualHeight()
  {
    if (animation_skeleton_animation_) 
      return animation_skeleton_animation_->GetSkeletonAnimationNode()->GetBonePositionInSkeleton(taomee::kBoneTypeHealthBar).y;
    else 
    {
      cocos2d::CCRect actor_box = GetActorBox();
      return actor_box.getMaxY();
    }
  }

  cocos2d::CCPoint ActorAnimation::GetActorRangeAttackAnchor()
  {
    if (animation_skeleton_animation_) 
      return animation_skeleton_animation_->GetSkeletonAnimationNode()->GetBonePositionInSkeletonParent(taomee::kBoneTypeProjectile);
    else 
    {
      return GetActorCenterAnchor();
    }
  }


  cocos2d::CCPoint ActorAnimation::GetActorCenterAnchor()
  {
    cocos2d::CCRect actor_box = GetActorBox();
    return ccp(actor_box.getMidX(), actor_box.getMidY());
  }


  bool ActorAnimation::ChangeMovement(const std::string& movement_name, const int cycle_count/* = -1*/, const float speed/* = 1.0f*/)
  {
    if (animation_skeleton_animation_)
    {
      return GetAnimationSkeletonAnimation()->ChangeMovement(movement_name, cycle_count, speed);
    }
    else 
    {
      assert(false);
      return false;
    }
  }


  void ActorAnimation::CleanAnimationDead()
  {
    RemoveColorShader();

    SetStatusShader(taomee::shader::kShaderDefault);

    if (animation_skeleton_animation_)
    {
      animation_skeleton_animation_->GetSkeletonAnimationNode()->FadeOutShadow();
    }

    if (animation_overhead_layer_)
    {
      animation_overhead_layer_->GetOverheadLayer()->setVisible(false);
    }
  }



  void ActorAnimation::SetColorShader(cocos2d::ccColor4F shader_color, float last_time)
  {
    if (actor_->GetIsActorAlive() == false) return;
    if (shader_type_ != taomee::shader::kShaderDefault) return;

    shader_color_total_time_ = last_time;
    shader_color_left_time_ = last_time;
    if (!program_shader_color_ && animation_skeleton_animation_)
    {
      taomee::shader::ProgramChangeColor* program_shader_color = (taomee::shader::ProgramChangeColor*)taomee::shader::ShaderManager::GetInstance()->GetShaderWithType(taomee::shader::kShaderChangeColorTime);
      program_shader_color_ = program_shader_color;
      shader_color_ = shader_color;

      program_shader_color->SetTime(0.0f);
      program_shader_color->SetColor(shader_color);
      taomee::shader::SetAllNodeWithShader(animation_skeleton_animation_->GetSkeletonAnimationNode()->GetArmatureNode(), program_shader_color); //actor animation only
      //taomee::shader::SetAllNodeWithShader(actor_node_, program_shader_color);  //will set shader for health bar & other node
    }
  }


  void ActorAnimation::RemoveColorShader()
  {
    if (program_shader_color_)
    {
      program_shader_color_ = NULL; //first clear color shader
      SetStatusShader(shader_type_);  //then reset shader to status shader
    }
  }


  void ActorAnimation::SetStatusShader(int shader_type)
  {
    shader_type_ = shader_type;
    
    if (program_shader_color_) program_shader_color_ = NULL;  //interrupt color shader

    if (animation_skeleton_animation_) taomee::shader::SetAllNodeWithShaderType(animation_skeleton_animation_->GetSkeletonAnimationNode()->GetArmatureNode(), (taomee::shader::eShaderType)shader_type_);
    else taomee::shader::SetAllNodeWithShaderType(actor_node_, (taomee::shader::eShaderType)shader_type_);
  }

  cocos2d::CCNode* ActorAnimation::AddArmatureAnimation(cocos2d::CCPoint position_offset, const std::string & armature_name, const std::string & animation_name)
  {
    if (armature_name.size()==0) return NULL;

    CCArmature* armature_animation = CCArmature::create();
    actor_node_->addChild(armature_animation);

    if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
    {
      std::string skeleton_config = taomee::kDefaultSkeletonFilePath+armature_name+".xml";
      std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+armature_name+".plist";
      std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+armature_name+".pvr.ccz";
      CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
    }
    armature_animation->init(armature_name.c_str());
    armature_animation->getAnimation()->play(animation_name.c_str(), 0, -1, 0);
    armature_animation->setPosition(position_offset);
    armature_animation->setRotationY(actor_->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight ? 180 : 0); 

    return armature_animation;
  }

  cocos2d::CCNode* ActorAnimation::AddProjectileAnimation(cocos2d::CCPoint position_offset, const std::string& projectile_name)
  {
    if (projectile_name.size()==0) return NULL;

    taomee::ProjectileAnimation* projectile_animation = new taomee::ProjectileAnimation();
    actor_node_->addChild(projectile_animation);

    projectile_animation->initWithName(projectile_name.c_str());
    projectile_animation->setPositionType(kCCPositionTypeRelative);
    projectile_animation->setPosition(position_offset);
    //projectile_animation->setPosition(ccpAdd(projectile_animation->getPosition(), position_offset));
    //projectile_animation->setParticleFlipX(actor_->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight ? true : false); 
    projectile_animation->release();

    return projectile_animation;
  }

  void ActorAnimation::RemoveAnimationByTag(int tag)
  {
    actor_node_->removeChildByTag(tag);
  }


  ActorAnimationQueue* ActorAnimation::CreateAnimationQueue()
  {
    ActorAnimationQueue* animation_queue = new ActorAnimationQueue;
    animation_queue->Attach(this);

    assert(animation_queue_map_.find(animation_queue->m_uID) == animation_queue_map_.end());

    animation_queue_map_[animation_queue->m_uID] = animation_queue;

    return animation_queue;
  }

  ActorAnimationQueue* ActorAnimation::GetAnimationQueue(unsigned int animation_queue_id)
  {
    if (animation_queue_map_.find(animation_queue_id) != animation_queue_map_.end())
      return animation_queue_map_[animation_queue_id];
    else
      return NULL;
  }


  void ActorAnimation::RemoveAnimationQueue(unsigned int animation_queue_id)
  {
    if (animation_queue_map_.find(animation_queue_id) != animation_queue_map_.end())
    {
      ActorAnimationQueue* animation_queue = animation_queue_map_[animation_queue_id];

      animation_queue_map_.erase(animation_queue_id);

      delete animation_queue;
    }
  }


  //ActorAnimation

  float ActorAnimation::GetAnimationMovementDuration(
    cocos2d::extension::CCArmature* armature, 
    const std::string & movement_name, 
    int duration_to/* = -1*/, 
    int duration_tween/* = -1*/)
  {
    return GetAnimationMovementDuration(
      armature->getAnimation()->getAnimationData()->name,
      movement_name,
      armature->getAnimation()->getAnimationInternal(),
      armature->getAnimation()->getSpeedScale(),
      duration_to,
      duration_tween);
  }

  float ActorAnimation::GetAnimationMovementDuration(
    const std::string & animation_name, 
    const std::string & movement_name, 
    float frame_per_second/* = 1.0f / 24.0f*/,
    float speed_scale/* = 1.0f*/,
    int duration_to/* = -1*/, 
    int duration_tween/* = -1*/)
  {
    if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(animation_name.c_str()) == NULL)
    {
      std::string skeleton_config = taomee::kDefaultSkeletonFilePath+animation_name+".xml";
      std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+animation_name+".plist";
      std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+animation_name+".pvr.ccz";
      CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
    }

    CCAnimationData* animation_data = CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(animation_name.c_str());

    if (!animation_data)
    {
      CCLog("[ActorAnimation][GetAnimationMovementDuration] Error not found animation_name: %s", animation_name.c_str());
      return 0.0f;
    }

    CCMovementData* movement_data = animation_data->getMovement(movement_name.c_str());

    if (!movement_data)
    {
      CCLog("[ActorAnimation][GetAnimationMovementDuration] Error not found movement_name: %s, from animation_name: %s", movement_name.c_str(), animation_name.c_str());
      return 0.0f;
    }

    //movement_data->duration is not use , just as reference, the CCTween may generate more frames

    //get parameter like <CCArmatureAnimation::play>
    speed_scale = speed_scale * movement_data->scale;

    duration_to = (duration_to == -1) ? movement_data->durationTo : duration_to;

    duration_tween = (duration_tween == -1) ? movement_data->durationTween : duration_tween;
    duration_tween = (duration_tween == 0) ? movement_data->duration : duration_tween;


    //get frame count
    int frame_count = duration_to + duration_tween;


    return frame_per_second * frame_count * speed_scale;
  }
























  ActorAnimationQueue::ActorAnimationQueue() 
    : CCObject()
    , actor_animation_(NULL)
    , armature_(NULL)
    , projectile_(NULL)
  {

  }

  ActorAnimationQueue::~ActorAnimationQueue() 
  {
    Detach();
  }

  void ActorAnimationQueue::OnArmatureMovementEvent(cocos2d::extension::CCArmature* armature, cocos2d::extension::MovementEventType event_type, const char* movement_name)
  {
    switch (event_type)
    {
    case COMPLETE:
      //CCLog("[ActorAnimationQueue][OnArmatureMovementEvent] get COMPLETE");
      break;
    case LOOP_COMPLETE:
      //CCLog("[ActorAnimationQueue][OnArmatureMovementEvent] get LOOP_COMPLETE");
      break;
    default:
      //CCLog("[ActorAnimationQueue][OnArmatureMovementEvent] get %d", event_type);
      return;
      break;
    }

    if (armature_->getAnimation()->getIsComplete() && current_data_.loop_count == 0)
    {
      AutoPlayNext(); //finished current loop. auto play next
    }
    else
    {
      armature_->getAnimation()->play(current_data_.animation_name.c_str(), 0, -1, 1); //loop
      armature_->getAnimation()->setMovementEventCallFunc(this, (SEL_MovementEventCallFunc)(&ActorAnimationQueue::OnArmatureMovementEvent));
      if (current_data_.loop_count != -1) current_data_.loop_count--;
    }
  }

  void ActorAnimationQueue::Append(const ActorAnimationQueueData& animation_data)
  {
    data_queue_.push_back(animation_data);
  }

  void ActorAnimationQueue::Attach(ActorAnimation* actor_animation)
  {
    assert(actor_animation != NULL);

    Detach();

    actor_animation_ = actor_animation;
  }

  void ActorAnimationQueue::Detach()
  {
    CleanCurrent();

    if (actor_animation_)
    {
      ActorAnimation* actor_animation = actor_animation_;
      actor_animation_ = NULL;
      actor_animation->RemoveAnimationQueue(this->m_uID);
    }
  }

  void ActorAnimationQueue::AutoPlayNext()
  {
    CleanCurrent();
    
    if (actor_animation_ && data_queue_.size() > 0)
    {
      current_data_ = *(data_queue_.begin());
      data_queue_.pop_front();  //pop out

      switch (current_data_.animation_type)
      {
      case kActorAnimationQueueDataArmature:
        PlayArmature();
        break;
      case kActorAnimationQueueDataProjectile:
        PlayProjectile();
        break;
      default:
        assert(false);
        break;
      }
    }
    else
    {
      //CCLog("[ActorAnimationQueue][AutoPlayNext] Empty, detach & init self destroy");
      Detach();
    }
  }


  void ActorAnimationQueue::AutoPlayAndDetach()
  {
    if (CheckCanAutoFinish() == true)
    {
      //just play on and release for auto delete
      AutoPlayNext();
    }
    else
    {
      //no auto delete, stop manually
      Detach();
    }
  }

  bool CheckAnimationQueueDataCanAutoFinish(ActorAnimationQueueData* animation_queue_data)
  {
    //check blank, invalid data
    if (animation_queue_data->animation_name.empty())
      return true;

    switch (animation_queue_data->animation_type)
    {
    case kActorAnimationQueueDataArmature:
      return (animation_queue_data->loop_count >= 0); //by loop
    case kActorAnimationQueueDataProjectile:
      return false; //always loop
    case kActorAnimationQueueData:
    default:
      return true;  //just invalid
    }
  }


  bool ActorAnimationQueue::CheckCanAutoFinish()
  {
    bool can_auto_finish = true;

    can_auto_finish &= CheckAnimationQueueDataCanAutoFinish(&current_data_);

    std::list<ActorAnimationQueueData>::iterator iterator = data_queue_.begin();
    while (can_auto_finish == true && iterator != data_queue_.end())
    {
      ActorAnimationQueueData* animation_queue_data = &(*iterator);
      can_auto_finish &= CheckAnimationQueueDataCanAutoFinish(animation_queue_data);

      iterator ++;
    }

    return can_auto_finish;
  }

  void ActorAnimationQueue::PlayArmature()
  {
    std::string armature_name = current_data_.armature_name;
    std::string animation_name = current_data_.animation_name;
    int loop_count = current_data_.loop_count;
    cocos2d::CCPoint position = current_data_.position;

    cocos2d::CCNode* added_animation = actor_animation_->AddArmatureAnimation(position, armature_name, animation_name);

    if (added_animation)
    {
      //CCLog("[ActorAnimationQueue][PlayArmature] name: %s name: %s loop : %d", armature_name.c_str(), animation_name.c_str(), loop_count);
      armature_ = dynamic_cast<CCArmature*>(added_animation);

      armature_->getAnimation()->setMovementEventCallFunc(this, (SEL_MovementEventCallFunc)(&ActorAnimationQueue::OnArmatureMovementEvent));

      added_animation->setRotation(current_data_.rotation);
      if (current_data_.is_filp_x) added_animation->setRotationY(180);

      if (current_data_.loop_count != -1) current_data_.loop_count--;
    }
    else 
    {
      if (loop_count >= 0)
      {
        //CCLog("[ActorAnimationQueue][PlayArmature] Skipped. name: %s name: %s loop : %d", armature_name.c_str(), animation_name.c_str(), loop_count);
        AutoPlayNext(); //instant finished this part
      }
      else
      {
        //CCLog("[ActorAnimationQueue][PlayArmature] Fake Looping. name: %s name: %s loop : %d", armature_name.c_str(), animation_name.c_str(), loop_count);
        CleanCurrent(); //noting to play just wait like looping
      }
    }
  }


  void ActorAnimationQueue::PlayProjectile()
  {
    std::string animation_name = current_data_.animation_name;
    cocos2d::CCPoint position = current_data_.position;

    cocos2d::CCNode* added_animation = actor_animation_->AddProjectileAnimation(position, animation_name);

    if (added_animation)
    {
      //CCLog("[ActorAnimationQueue][PlayProjectile] Looping. name: %s", animation_name.c_str());
      projectile_ = dynamic_cast<taomee::ProjectileAnimation*>(added_animation);

      projectile_->setFlipX(current_data_.is_filp_x);
      projectile_->setRotation(current_data_.rotation);
    }
    else 
    {
      //CCLog("[ActorAnimationQueue][PlayProjectile] Fake Looping. name: %s", animation_name.c_str());
      CleanCurrent(); //noting to play just wait like looping
    }
  }


  void ActorAnimationQueue::CleanCurrent()
  {
    if (armature_)
    {
      armature_->getAnimation()->setMovementEventCallFunc(NULL, NULL);
      armature_->removeFromParentAndCleanup(true);
      armature_ = NULL;
    }

    if (projectile_)
    {
      projectile_->removeFromParentAndCleanup(true);
      projectile_ = NULL;
    }

    current_data_.animation_name = "";
    current_data_.armature_name = "";
    current_data_.animation_type = kActorAnimationQueueData;
    current_data_.loop_count = 0;
    current_data_.position.x = 0;
    current_data_.position.y = 0;
  }



} // namespace actor