#include "actor_ext_env.h"

#include "actor.h"

#include "game/actor/skill/actor_skill.h"
#include "game/actor/buff/actor_buff.h"

#include "actor_ext/actor_ext_damage.h"
#include "actor_ext/actor_ext_effect.h"
#include "actor_ext/actor_ext_grid.h"
#include "actor_ext/actor_ext_user_operation.h"

namespace actor {
  ActorExtEnv::ActorExtEnv()
    :is_pause_(false)
  {
    actor_map_.clear();

    actor_focus_map_.clear();

    actor_ext_damage_ = new ActorExtDamage(this);
    actor_ext_effect_ = new ActorExtEffect(this);
    actor_ext_grid_ = new ActorExtGrid(this);
    actor_ext_user_operation_ = new ActorExtUserOperation(this);
  }

  ActorExtEnv::~ActorExtEnv()
  {
    Clear();

    if (actor_ext_damage_) delete actor_ext_damage_;
    if (actor_ext_effect_) delete actor_ext_effect_;
    if (actor_ext_grid_) delete actor_ext_grid_;
    if (actor_ext_user_operation_) delete actor_ext_user_operation_;

    actor_ext_damage_ = NULL;
    actor_ext_effect_ = NULL;
    actor_ext_grid_ = NULL;
    actor_ext_user_operation_ = NULL;
  }

  void ActorExtEnv::Clear()
  {
    if (actor_ext_damage_) actor_ext_damage_->Clear();
    if (actor_ext_effect_) actor_ext_effect_->Clear();

    std::map<int, Actor*>::iterator actor_iterator = actor_map_.begin();
    while(actor_iterator != actor_map_.end())
    {
      Actor* actor = actor_iterator->second;
      actor->GetActorData()->GetLog()->AddErrorLogF("[Error][ActorExtEnv][Clear] possible leaking actor, ID:%d", actor->GetScriptObjectId());
      assert(false);
      actor->UnLinkScript();
      delete actor;
      ++actor_iterator;
    }
    actor_map_.clear();

    actor_focus_map_.clear();

    if (actor_ext_grid_) actor_ext_grid_->Clear();
    if (actor_ext_user_operation_) actor_ext_user_operation_->Clear();
  }


  void ActorExtEnv::Update(float delta_time)
  {
    //update damage
    actor_ext_damage_->Update(delta_time);

    //update effect
    actor_ext_effect_->Update(delta_time);

    //update grid
    actor_ext_grid_->UpdateActorGridList();

    std::map<int, Actor*>::iterator iterator = actor_map_.begin();
    while(iterator != actor_map_.end())
    {
      Actor* actor = iterator->second;
      if (actor->GetScriptObjectIsActive()) actor->Update(delta_time);
      ++iterator;
    }
  }


  Actor* ActorExtEnv::CreateActor() //will return actor_id
  {
    int actor_id = GetValidId();
      
    //add code here if actor id needs following some strange rule
    //add code here if actor id needs following some strange rule

    return CreateActor(actor_id);
  }

  Actor* ActorExtEnv::CreateActor(int actor_id) //alternative, predefined actor_id
  {
    if (actor_map_.find(actor_id) != actor_map_.end())
    {
      assert(false);
      return actor_map_[actor_id];
    }
    else
    {
      Actor* actor = new Actor;
      actor_map_[actor_id] = actor;
      actor->LinkScript(actor_id, this);  //script object
      return actor;
    }
  }

  void ActorExtEnv::RemoveActor(int actor_id)
  {
    if (actor_map_.find(actor_id) != actor_map_.end())
    {
      Actor* actor = actor_map_[actor_id];

      RemoveActorFocusById(actor_id);
        
      actor_map_.erase(actor_id);
      actor->UnLinkScript();
      delete actor;
    }
    else
    {
      assert(false);
    }
  }

  Actor* ActorExtEnv::GetActorById(int actor_id)
  {
    if (actor_map_.find(actor_id) != actor_map_.end()) return actor_map_[actor_id];
    else return NULL;
  }

  std::list<Actor*>* ActorExtEnv::GetActorList()  //should delete after use
  {
    std::list<Actor*>* actor_list = new std::list<Actor*>;
    std::map<int, Actor*>::iterator iterator = actor_map_.begin();
    while (iterator != actor_map_.end())
    {
      Actor* actor = iterator->second;
      if (actor->GetIsActorAlive() && IsPositionXInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)))
        actor_list->push_back(actor);
      ++iterator;
    }
    return actor_list;
  }


  //should move ? should move
  //for skill pause need
  void ActorExtEnv::AddActorFocusById(int actor_id)
  {
    if (actor_map_.find(actor_id) != actor_map_.end()) 
    {
      Actor* actor = actor_map_[actor_id];
      actor_focus_map_[actor_id] = actor;
      actor_map_[actor_id]->GetActorData()->GetLog()->AddErrorLogF("[ActorExtEnv][AddActorFocusById] Current Focused:%d", actor_focus_map_.size());

      //raise ZOrder logic
      actor->GetAnimation()->GetActorNode()->setZOrder((9999 << 8) + actor->GetAnimation()->GetActorNode()->getZOrder());
      actor->GetAnimation()->GetActorNode()->runAction(CCScaleTo::create(0.2f, 1.0f));

      actor->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsFocused, true);
    }
    else 
    {
      assert(false);
    }
  }

  void ActorExtEnv::RemoveActorFocusById(int actor_id)
  {
    if (actor_focus_map_.find(actor_id) != actor_focus_map_.end()) 
    {
      Actor* actor = actor_focus_map_[actor_id];

      //recover logic in ActorAnimation Update
      actor->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsFocused, false);

      actor_focus_map_.erase(actor_id);
    }
  }


  void ActorExtEnv::ClearActorFocus()
  {
    while (!actor_focus_map_.empty())
    {
      RemoveActorFocusById(actor_focus_map_.begin()->first);
    }
  }

  void ActorExtEnv::PauseActorExceptFocus()
  {
    std::map<int, Actor*>::iterator iterator = actor_map_.begin();
    while (iterator != actor_map_.end())
    {
      int actor_id = iterator->first;
      Actor* actor = iterator->second;

      if (actor_focus_map_.find(actor_id) != actor_focus_map_.end()) 
      {
        actor->GetActorData()->GetLog()->AddLogF("[ActorExtEnv][PauseActorExceptFocus] Focused");
        actor->SetIsPause(false);
      }
      else 
      {
        actor->GetActorData()->GetLog()->AddLogF("[ActorExtEnv][PauseActorExceptFocus] Paused");
        actor->SetIsPause(true);
      }

      ++iterator;
    }
  }

  void ActorExtEnv::ClearActorPause()
  {
    std::map<int, Actor*>::iterator iterator = actor_map_.begin();
    while (iterator != actor_map_.end())
    {
      Actor* actor = iterator->second;
      actor->SetIsPause(false);

      ++iterator;
    }
  }

  void ActorExtEnv::SetIsPause(bool is_pause) 
  { 
    if (is_pause) PauseActorExceptFocus();
    else ClearActorPause();
    is_pause_ = is_pause; 
  }



  void ActorExtEnv::ApplyEmitIdDataList(std::list<EmitIdData>& emit_id_data_list, int actor_id, const ActorSkillLinkData& skill_link_data)
  {
    //check actor
    Actor* actor = GetActorById(actor_id);

    if (!actor || !actor->GetScriptObjectIsActive())
    {
      return;
    }

    //loop and create
    for (std::list<EmitIdData>::iterator iterator = emit_id_data_list.begin(); iterator != emit_id_data_list.end(); iterator ++)
    {
      EmitIdData &emit_id_data = *iterator;

      bool is_success_by_chance = (emit_id_data.fail_chance <= rand());

      if (is_success_by_chance == false)
      {
        continue;
      }

      switch (emit_id_data.type)
      {
      case kActorEmitEffectTimeline:
        actor_ext_effect_->CreateEffectTimeline(ACTOR_INVALID_ID, emit_id_data.id, skill_link_data);
        break;
      case kActorEmitBuff:
        actor->GetBuff()->AddBuff(ACTOR_INVALID_ID, emit_id_data.id, skill_link_data);
        break;
      }
    }
  }

} // namespace actor