#ifndef ACTOR_CONTROL_DATA_H
#define ACTOR_CONTROL_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;

  enum eActorControlOperationType {
    kActorControlOperationPositionMove = 1,
    kActorControlOperationIdTargetMove,

    //kActorControlOperationPositionAttack, //nonsense
    kActorControlOperationIdTargetAttack,
    kActorControlOperationIdSkillAttack,
    kActorControlOperationTypeSkillAttack,

    kActorControlOperationTypeBorn,
    kActorControlOperationTypeDead,
    kActorControlOperationTypeIncontrollable,

    kActorControlOperation = 0
  };

  typedef struct sActorControlOperationData {
    eActorControlOperationType operation_type;
    eActorControlPriority priority;
    int data_id;
    cocos2d::CCPoint data_position;
  } ActorControlOperationData;

  //#########################################################################################################
  //#########################################################################################################
  class ActorControlData
  {
  public:
    ActorControlData();
    ~ActorControlData();
    
    virtual void    Update(float delta_time);

    virtual void    Reset();
    virtual bool    IsSetOperation();

    eActorControlPriority GetMaxPriority();
    eActorControlOperationType GetMaxPriorityOperationType();

    void AddIdOperation(eActorControlOperationType operation_type, eActorControlPriority priority, int data_id);
    void AddPositionOperation(eActorControlOperationType operation_type, eActorControlPriority priority, cocos2d::CCPoint data_position);
    
    ActorControlOperationData* GetOperationData(eActorControlOperationType operation_type);
    int               GetIdOperationData(eActorControlOperationType operation_type);
    cocos2d::CCPoint  GetPositionOperationData(eActorControlOperationType operation_type);

    bool CheckOperationData(eActorControlOperationType operation_type);
    bool CheckTopOperationData(eActorControlOperationType operation_type);  //check exist and top priority
    void RemoveOperationData(eActorControlOperationType operation_type);

    void              SetCountdown(float countdown) { countdown_ = countdown; }
    float             GetCountdown() { return countdown_; }

  protected:
    void              UpdateCountdown(float delta_time) { countdown_ = (countdown_ <= delta_time ? 0 : countdown_ - delta_time); }

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  private:
    std::map<eActorControlOperationType, sActorControlOperationData> operation_data_map_;

    float             countdown_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_DATA_H