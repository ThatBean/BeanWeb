#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {

  ActorSpecifiedData::ActorSpecifiedData(Actor* actor)
    :actor_(actor)
  {

  }


  void ActorSpecifiedData::Update(float delta_time)
  {
    //
  }


  bool ActorSpecifiedData::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionInGrid(position);
  }

  bool ActorSpecifiedData::IsGridValid(cocos2d::CCPoint grid_position)
  {
    return grid_position.x >= GRID_X_RANGE_LEFT
      && grid_position.x <= GRID_X_RANGE_RIGHT
      && grid_position.y >= GRID_Y_RANGE_TOP
      && grid_position.y <= GRID_Y_RANGE_BOTTOM;
  }


  cocos2d::CCPoint ActorSpecifiedData::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
      return SnapToGrid(position);
    else
      return SnapYToGrid(position);
  }

  bool ActorSpecifiedData::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);  //for enemy pawn / boss
  }


  //ActorSpecifiedDataCharacter================================================================
  ActorSpecifiedDataCharacter::ActorSpecifiedDataCharacter(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataCharacter::IsPositionValid(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
    {
      cocos2d::CCPoint grid_position = GetGridFromPosition(position);
      if (actor_->GetActorData()->GetActorStatusBool(kActorStatusSpecifiedIsLimitGridX) && ((int)(grid_position.x) < 2))
        return (position.x > (GetPositionFromGrid(ccp(2,grid_position.y)).x));
      else
        return true;
    }
    else
      return false;
  }

  bool ActorSpecifiedDataCharacter::IsGridValid(cocos2d::CCPoint grid_position)
  {
    bool is_valid = ActorSpecifiedData::IsGridValid(grid_position);
    
    if (is_valid && actor_->GetActorData()->GetActorStatusBool(kActorStatusSpecifiedIsLimitGridX))
    {
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusHomeDirection))
      {
      case kActorAnimationDirectionLeft:
        is_valid = grid_position.x <= PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT;
        break;
      case kActorAnimationDirectionRight:
        is_valid = grid_position.x >= PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT;
        break;
      default:
        assert(false);
        is_valid = true;
        break;
      }
    }

    return is_valid;
  }

  bool ActorSpecifiedDataCharacter::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);  //not different from Valid
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
    {
      if (IsPositionValid(position))
        return SnapToGrid(position);
      else
      {
        cocos2d::CCPoint grid_position = GetGridFromPosition(position);

        if (actor_->GetActorData()->GetActorStatusBool(kActorStatusSpecifiedIsLimitGridX) && ((int)(grid_position.x) == 1))
          grid_position.x = 2;  // TODO: strange logic
        
        return GetPositionFromGrid(grid_position);
      }
    }
    else
      return SnapYToGrid(position);
  }


  //ActorSpecifiedDataCharacter================================================================

  //ActorSpecifiedDataEnemyPawn================================================================
  ActorSpecifiedDataEnemyPawn::ActorSpecifiedDataEnemyPawn(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }


  void ActorSpecifiedDataEnemyPawn::Update(float delta_time)
  {
    cocos2d::CCPoint grid_position = GetGridFromPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));

    // TODO: need move? | show enemy warning
    if (grid_position.x >= (GRID_X_RANGE_RIGHT_MIDDLE - 1))
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/battleOverlayUI/BattleOverlayUI.lua", 
        "CallFuncBattleOverlayUI", 
        "NotifySubDisplay",
        "NOTIFIER_WARNING", 
        "warning");
    }

    // TODO: need move? | reduce enemy's speed
    if (grid_position.x >= GRID_X_RANGE_RIGHT_MIDDLE)
    {
      ActorAttributeData* speed_attribute = actor_->GetActorData()->GetActorAttributeData(kActorAttributeSpeedMove);
      speed_attribute->Set(speed_attribute->GetAdd(), 0.5);
    }

    if (grid_position.x > GRID_X_RANGE_RIGHT)
    {
      actor_->Emit(std::string("EnemyPassRightBorder"));
      AlertEnemyPassRightBorder(actor_->GetScriptObjectId());
    }
  }


  bool ActorSpecifiedDataEnemyPawn::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionYInGrid(position);
  }
  //ActorSpecifiedDataEnemyPawn================================================================

  //ActorSpecifiedDataEnemyBoss================================================================
  ActorSpecifiedDataEnemyBoss::ActorSpecifiedDataEnemyBoss(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  void ActorSpecifiedDataEnemyBoss::Update(float delta_time)
  {
    cocos2d::CCPoint grid_position = GetGridFromPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));

    // TODO: need move? | show enemy warning
    if (grid_position.x >= (GRID_X_RANGE_RIGHT_MIDDLE - 1))
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/battleOverlayUI/BattleOverlayUI.lua", 
        "CallFuncBattleOverlayUI", 
        "NotifySubDisplay",
        "NOTIFIER_WARNING", 
        "warning");
    }

    // TODO: need move? | reduce enemy's speed
    if (grid_position.x >= GRID_X_RANGE_RIGHT_MIDDLE)
    {
      ActorAttributeData* speed_attribute = actor_->GetActorData()->GetActorAttributeData(kActorAttributeSpeedMove);
      speed_attribute->Set(speed_attribute->GetAdd(), 0.5);
    }

    if (grid_position.x > GRID_X_RANGE_RIGHT)
    {
      actor_->Emit(std::string("EnemyPassRightBorder"));
      AlertEnemyPassRightBorder(actor_->GetScriptObjectId());
    }
  }

  bool ActorSpecifiedDataEnemyBoss::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionYInGrid(position);
  }
  //ActorSpecifiedDataEnemyBoss================================================================
} // namespace actor