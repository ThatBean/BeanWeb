#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_animation_data_typedef.h"

namespace actor {

  //ActorMotionData
  ActorMotionData::ActorMotionData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }

  ActorMotionData::~ActorMotionData()
  {

  }

  void ActorMotionData::Update(float delta_time)
  {

  }

  //link OnDataOperation to selected signal
  void ActorMotionData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorPositionData(kActorPositionMotionMoveTarget)->Connect<ActorMotionData>(this, &ActorMotionData::OnDataOperation);
  }

  //callback for data operation signal
  void ActorMotionData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

    switch (actor_data_type)
    {
    case kActorPositionMotionMoveTarget:
      {
        switch (operation_type)
        {
        //case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            ActorData* actor_data = signal_data->actor_data;

            cocos2d::CCPoint move_target_position = actor_data->GetActorPosition(kActorPositionMotionMoveTarget);
            cocos2d::CCPoint animation_position = actor_data->GetActorPosition(kActorPositionAnimation);

            //cache speed unit
            cocos2d::CCPoint move_speed_unit = ccpSub(move_target_position, animation_position).normalize();
            actor_data->SetActorPosition(kActorPositionMotionMoveSpeedUnit, move_speed_unit);

            //check if direction change
            bool is_change_direction = abs(animation_position.x - move_target_position.x) >= ACTOR_DIRECTION_CHANGE_THRESHOLD;
            if (is_change_direction)
            {
              bool is_facing_left = move_target_position.x < animation_position.x;
              if (is_facing_left) actor_data->SetActorStatus(kActorStatusAnimationDirection, kActorAnimationDirectionLeft);
              else actor_data->SetActorStatus(kActorStatusAnimationDirection, kActorAnimationDirectionRight);
            }
          }
          break;
        }
      }
      break;
    }
  }
  //ActorMotionData


} // namespace actor