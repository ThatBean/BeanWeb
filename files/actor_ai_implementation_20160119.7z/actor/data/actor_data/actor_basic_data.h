#ifndef ACTOR_BASIC_DATA_H
#define ACTOR_BASIC_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;

  class ActorBasicData
  {
  public:
    ActorBasicData(ActorData* actor_data);

    void Update(float delta_time);

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);

    //currently in adapter

    const std::string DeadAnimationName();  //return dead animation name

  private:
    ActorData*    actor_data_;

    float         time_recover_tick_;
  };


} // namespace actor


#endif // ACTOR_BASIC_DATA_H