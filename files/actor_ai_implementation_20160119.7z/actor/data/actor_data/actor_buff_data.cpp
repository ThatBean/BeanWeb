#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "game/actor/buff/actor_buff.h"
#include "game/actor/skill/actor_skill.h"

#include "game/data_table/buff_config_data_table.h"

#include "game/battle/damage/damage_constants.h"
#include "game/shader/shader_manager.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {


  ActorBuffStatusBitSet get_buff_status_bit_set(const eActorBuffStatusType* status_type_array, int status_type_array_size)
  {
    ActorBuffStatusBitSet status_bit_set;
    for (int i = 0; i < status_type_array_size; i ++) status_bit_set.set(status_type_array[i]);
    return status_bit_set;
  }


  // init buff bit set
  const eActorBuffStatusType actor_buff_status_array_incontrollable[] = {
    kActorBuffStatusAutoMove,
    kActorBuffStatusStiff,
    kActorBuffStatusFear,
    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
    kActorBuffStatusStun,
    kActorBuffStatusCharmed,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_INCONTROLLABLE = get_buff_status_bit_set(actor_buff_status_array_incontrollable, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_incontrollable));


  const eActorBuffStatusType actor_buff_status_array_move_lock[] = {
    kActorBuffStatusMuteMove,
    kActorBuffStatusStiff,
    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
    kActorBuffStatusStun,
    kActorBuffStatusInterwine,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_MOVE_LOCK = get_buff_status_bit_set(actor_buff_status_array_move_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_move_lock));


  const eActorBuffStatusType actor_buff_status_array_move_auto[] = {
    kActorBuffStatusAutoMove,
    kActorBuffStatusFear,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_MOVE_AUTO = get_buff_status_bit_set(actor_buff_status_array_move_auto, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_move_auto));


  const eActorBuffStatusType actor_buff_status_array_attack_lock[] = {
    kActorBuffStatusStiff,
    kActorBuffStatusFear,
    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
    kActorBuffStatusStun,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_LOCK = get_buff_status_bit_set(actor_buff_status_array_attack_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_lock));


  const eActorBuffStatusType actor_buff_status_array_attack_normal_lock[] = {
    kActorBuffStatusBlind,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_NORMAL_LOCK = ACTOR_BUFF_STATUS_ATTACK_LOCK 
    | get_buff_status_bit_set(actor_buff_status_array_attack_normal_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_normal_lock));



  const eActorBuffStatusType actor_buff_status_array_attack_power_lock[] = {
    kActorBuffStatusBlind,
    kActorBuffStatusSlience,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_POWER_LOCK = ACTOR_BUFF_STATUS_ATTACK_LOCK 
    | get_buff_status_bit_set(actor_buff_status_array_attack_power_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_power_lock));



  const eActorBuffStatusType actor_buff_status_array_attack_special_lock[] = {
    kActorBuffStatusSlience,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_SPECIAL_LOCK = ACTOR_BUFF_STATUS_ATTACK_LOCK 
    | get_buff_status_bit_set(actor_buff_status_array_attack_special_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_special_lock));


  const eActorBuffStatusType actor_buff_status_array_animation_lock[] = {
    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ANIMATION_LOCK = get_buff_status_bit_set(actor_buff_status_array_animation_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_animation_lock));








  //ActorBuffStatusData
  ActorBuffStatusData::ActorBuffStatusData()
  {
    Clear();
  }

  ActorBuffStatusData::~ActorBuffStatusData()
  {

  }

  void ActorBuffStatusData::Clear()
  {
    stack_active_ = 0;
    stack_immune_ = 0;
  }

  bool ActorBuffStatusData::GetIsActive()
  {
    return !GetIsImmune() && stack_active_ > 0;
  }

  bool ActorBuffStatusData::GetIsImmune()
  {
    return stack_immune_ > 0;
  }

  void ActorBuffStatusData::StackState(eActorBuffStatusStateType status_state) 
  { 
    switch (status_state)
    {
    case kActorBuffStatusStateAdd:
      stack_active_++;
      break;
    case kActorBuffStatusStateSub:
      stack_active_--;
      break;
    case kActorBuffStatusStateImmuneAdd:
      stack_immune_++;
      break;
    case kActorBuffStatusStateImmuneSub:
      stack_immune_--;
      break;
    default:
      assert(false);
      break;
    }
  }
  //ActorBuffStatusData















  //ActorBuffData
  ActorBuffData::ActorBuffData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }



  //link OnDataOperation to selected signal
  void ActorBuffData::ConnectDataSignal()
  {
    //add data signal
    //actor_data_->GetActorStatusData(kActorStatusBuffIsPauseAnimation)->Connect<ActorBuffData>(this, &ActorBuffData::OnDataOperation);
  }

  //callback for data operation signal
  void ActorBuffData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

//     switch (actor_data_type)
//     {
//     case kActorStatusBuffIsPauseAnimation:
//       {
//         switch (operation_type)
//         {
//         case kActorDataOperationReset:
//         case kActorDataOperationSet:
//           {
//             bool is_pause = actor_data_->GetActorStatusBool(kActorStatusBuffIsPauseAnimation);
// 
//             actor_data_->GetActorStatusData(kActorStatusAnimationIsPaused)->Stack(is_pause);
//           }
//           break;
//         }
//       }
//       break;
//     }
  }

  bool ActorBuffData::RegisterBuff(ActorBuffLinkData* buff_link_data) //return is success
  {
    bool is_success = true;

    //check buff_id
    if (is_success)
    {
      if (buff_id_register_map_.find(buff_link_data->buff_id) != buff_id_register_map_.end())
      {
        switch (buff_id_register_map_[buff_link_data->buff_id].register_type)
        {
        case kActorBuffConfigStackDropNew:
          {
            is_success = false;
          }
          break;
        case kActorBuffConfigStackCreate:
          {
            //register self
            buff_id_register_map_[buff_link_data->buff_id].buff_list.push_back(buff_link_data);
          }
          break;
        case kActorBuffConfigStackReset:
          {
            ActorBuffLinkData* existing_buff_link_data = *(buff_id_register_map_[buff_link_data->buff_id].buff_list.begin());
            existing_buff_link_data->StackReset(*buff_link_data);
            is_success = false;
          }
          break;
        case kActorBuffConfigStackMerge:
          {
            ActorBuffLinkData* existing_buff_link_data = *(buff_id_register_map_[buff_link_data->buff_id].buff_list.begin());
            existing_buff_link_data->StackMerge(*buff_link_data);
            is_success = false;
          }
          break;
        default:
          assert(false);
          break;
        }
      }
      else
      {
        //register self
        buff_id_register_map_[buff_link_data->buff_id].register_type = buff_link_data->buff_config_data->GetStackType();
        buff_id_register_map_[buff_link_data->buff_id].buff_list.push_back(buff_link_data);
      }
    }

    //check keyword
    if (is_success)
    {
      std::set<std::string>& keyword_set = buff_link_data->buff_config_data->GetKeywordSet();
      for (std::set<std::string>::iterator iterator = keyword_set.begin(); iterator != keyword_set.end(); iterator ++)
      {
        std::string buff_keyword = *iterator;

        if (buff_keyword_register_map_.find(buff_keyword) != buff_keyword_register_map_.end())
        {
          //found overlap keyword

          switch (buff_keyword_register_map_[buff_keyword].register_type)
          {
          case kActorBuffConfigReplaceAddNew:
            {
              //register self
              buff_keyword_register_map_[buff_keyword].buff_list.push_back(buff_link_data);
            }
            break;
          case kActorBuffConfigReplaceReplacePrevious:
          case kActorBuffConfigReplaceReplacePreviousOnly:
            {
              //replace_previous (by keyword)
              buff_link_data->actor_buff->DeactivateBuffByKeyword(buff_keyword);
            }
            break;
          default:
            assert(false);
            break;
          }
        }
        else
        {
          //no overlap keyword
          switch (buff_link_data->buff_config_data->GetReplaceType())
          {
          case kActorBuffConfigReplaceAddNew:
          case kActorBuffConfigReplaceReplacePrevious:
            {
              //register self
              buff_keyword_register_map_[buff_keyword].register_type = buff_link_data->buff_config_data->GetReplaceType();
              buff_keyword_register_map_[buff_keyword].buff_list.push_back(buff_link_data);
            }
            break;
          case kActorBuffConfigReplaceReplacePreviousOnly:
            {
              is_success = false;
              UnregisterBuff(buff_link_data); //revert buff_id_register_map_
            }
            break;
          default:
            assert(false);
            break;
          }
        }
      }
    }

    return is_success;
  }




  void ActorBuffData::UnregisterBuff(ActorBuffLinkData* buff_link_data)
  {
    //check buff_id
    {
      std::list<ActorBuffLinkData*>& buff_list = buff_id_register_map_[buff_link_data->buff_id].buff_list;
      std::list<ActorBuffLinkData*>::iterator iterator = buff_list.begin();
      while (iterator != buff_list.end())
      {
        if ((*iterator)->buff_key == buff_link_data->buff_key)
        {
          iterator = buff_list.erase(iterator);
        }
        else
        {
          iterator ++;
        }
      }
      if (buff_list.empty())
      {
        buff_id_register_map_.erase(buff_link_data->buff_id);
      }
    }

    //check keyword
    std::set<std::string>& keyword_set = buff_link_data->buff_config_data->GetKeywordSet();
    for (std::set<std::string>::iterator buff_keyword_iterator = keyword_set.begin(); buff_keyword_iterator != keyword_set.end(); buff_keyword_iterator ++)
    {
      std::string buff_keyword = *buff_keyword_iterator;

      std::list<ActorBuffLinkData*>& buff_list = buff_keyword_register_map_[buff_keyword].buff_list;
      std::list<ActorBuffLinkData*>::iterator iterator = buff_list.begin();
      while (iterator != buff_list.end())
      {
        if ((*iterator)->buff_key == buff_link_data->buff_key)
        {
          iterator = buff_list.erase(iterator);
        }
        else
        {
          iterator ++;
        }
      }
      if (buff_list.empty())
      {
        buff_keyword_register_map_.erase(buff_keyword);
      }
    }
  }



  bool ActorBuffData::CheckBuffKeyword(const std::string& buff_keyword)
  {
    return (buff_keyword_register_map_.find(buff_keyword) != buff_keyword_register_map_.end());
  }


  void ActorBuffData::AddBuffStatusBitSet(ActorBuffStatusBitSet buff_status_bit_set, eActorBuffStatusStateType buff_status_state)
  {
    for (int i = 0; i < buff_status_bit_set.size(); i++)
    {
      if (buff_status_bit_set[i]) buff_status_map_[eActorBuffStatusType(i)].StackState(buff_status_state);
    }
  }
  void ActorBuffData::RemoveBuffStatusBitSet(ActorBuffStatusBitSet buff_status_bit_set)
  {
    for (int i = 0; i < buff_status_bit_set.size(); i++)
    {
      if (buff_status_bit_set[i]) buff_status_map_.erase(eActorBuffStatusType(i));
    }
  }
  bool ActorBuffData::CheckBuffStatusBitSet(ActorBuffStatusBitSet buff_status_bit_set)
  {
    bool is_all_set = true;
    for (int i = 0; i < buff_status_bit_set.size(); i++)
    {
      if (buff_status_bit_set[i]) is_all_set &= (buff_status_map_.find(eActorBuffStatusType(i)) != buff_status_map_.end());
    }
    return is_all_set;
  }

  ActorBuffStatusBitSet ActorBuffData::GetBuffStatusBitFlag()
  {
    ActorBuffStatusBitSet status_bit_set;
    for (std::map<eActorBuffStatusType, ActorBuffStatusData>::iterator iterator = buff_status_map_.begin(); iterator != buff_status_map_.end(); iterator ++)
    {
      status_bit_set.set(iterator->first, iterator->second.GetIsActive());
    }
    return status_bit_set;
  }





  //currently in adapter
  void ActorBuffData::UpdateIncontrollable()
  {
    ActorBuffStatusBitSet status_bit_set = GetBuffStatusBitFlag();

    actor_data_->SetActorStatusBool(kActorStatusBuffIsIncontrollable, (status_bit_set & ACTOR_BUFF_STATUS_INCONTROLLABLE).any());

    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteMove, (status_bit_set & ACTOR_BUFF_STATUS_MOVE_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttack, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttackNormal, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_NORMAL_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttackPower, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_POWER_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttackSpecial, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_SPECIAL_LOCK).any());


    bool is_pause_animation = (status_bit_set & ACTOR_BUFF_STATUS_ANIMATION_LOCK).any();
    if (is_pause_animation != actor_data_->GetActorStatusBool(kActorStatusBuffIsPauseAnimation)) 
    {
      actor_data_->SetActorStatusBool(kActorStatusBuffIsPauseAnimation, is_pause_animation);
      actor_data_->GetActorStatusData(kActorStatusAnimationIsPaused)->Stack(is_pause_animation);
    }

    //actor_data_->SetActorStatusBool(kActorStatusBuffIsChangeColor, ((buff_flag & ACTOR_BUFF_FLAG_COLORED) != 0));  // TODO:
    //actor_data_->SetActorStatusBool(kActorStatusBuffForceMoveAuto, ((buff_flag & ACTOR_BUFF_FLAG_MOVE_AUTO) == 0));  // TODO:
  }











  int ActorBuffData::UpdateShader()
  {
    ActorBuffStatusBitSet status_bit_set = GetBuffStatusBitFlag();

    if (status_bit_set[kActorBuffStatusFreeze]) return taomee::shader::kShaderFrozen;
    if (status_bit_set[kActorBuffStatusPetrify]) return taomee::shader::kShaderGray;
    if (status_bit_set[kActorBuffStatusInvisible]) return taomee::shader::kShaderBlur;

    return taomee::shader::kShaderDefault;
  }



  std::string ActorBuffData::GetDebugInfo(Actor* actor, const std::string& pre_text)
  {
    std::ostringstream string_stream;  // associate stream buffer to stream

    ActorBuffData* actor_buff_data = actor->GetActorData()->GetBuffData();

    string_stream << pre_text << " >BuffStatusBitFlag:" << actor_buff_data->GetBuffStatusBitFlag().to_string() << std::endl;

    string_stream << pre_text << " >RegisteredBuffKeywordCount:" << actor_buff_data->buff_keyword_register_map_.size() << std::endl;
    for (std::map<std::string, ActorBuffRegisterData>::iterator iterator = actor_buff_data->buff_keyword_register_map_.begin(); iterator != actor_buff_data->buff_keyword_register_map_.end(); iterator ++)
    {
      const std::string& buff_keyword = iterator->first;
      ActorBuffRegisterData& buff_reg_data = iterator->second;
      string_stream << pre_text << " >>Keyword:" << buff_keyword << " Type:" << buff_reg_data.register_type << std::endl;

      for (std::list<ActorBuffLinkData*>::iterator iterator_buff = buff_reg_data.buff_list.begin(); iterator_buff != buff_reg_data.buff_list.end(); iterator_buff ++)
      {
        ActorBuffLinkData* buff_link_data = *iterator_buff;
        string_stream << pre_text << " >>>Keyword:" << buff_keyword << " RegisteredBuffId:" << buff_link_data->buff_id << std::endl;
      }
    }

    string_stream << pre_text << " >RegisteredBuffIdCount:" << actor_buff_data->buff_id_register_map_.size() << std::endl;
    for (std::map<int, ActorBuffRegisterData>::iterator iterator = actor_buff_data->buff_id_register_map_.begin(); iterator != actor_buff_data->buff_id_register_map_.end(); iterator ++)
    {
      int buff_id = iterator->first;
      ActorBuffRegisterData& buff_reg_data = iterator->second;
      string_stream << pre_text << " >>BuffId:" << buff_id << " Type:" << buff_reg_data.register_type << std::endl;

      for (std::list<ActorBuffLinkData*>::iterator iterator_buff = buff_reg_data.buff_list.begin(); iterator_buff != buff_reg_data.buff_list.end(); iterator_buff ++)
      {
        ActorBuffLinkData* buff_link_data = *iterator_buff;
        string_stream << pre_text << " >>>BuffId:" << buff_id << " RegisteredBuffId:" << buff_link_data->buff_id << std::endl;
      }
    }

    return string_stream.str();
  }
  //ActorBuffData


} // namespace actor