#ifndef ACTOR_SKILL_DATA_H
#define ACTOR_SKILL_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"


class ASkillControl; 


namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;
  class ActorTrigger;


  class ActorSkillData
  {
  public:
    ActorSkillData(ActorData* actor_data, Actor* actor);
    ~ActorSkillData();

    void Reset();

    void Update(float delta_time);

    //link OnDataOperation to selected signal
    void ConnectDataSignal();
    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);


    bool IsSkillValid(int skill_id);
    bool CheckAttackTrigger();
    bool CheckGuardTrigger();


    void            AddSkillInfo(ActorSkillInfo& skill_info);
    ActorSkillInfo* GetSkillInfoById(int skill_id);
    eActorSkillType GetSkillTypeById(int skill_id);
    int             GetSkillIdByType(int skill_type, int skip_count = 0);

    int   NextSkill();

    void  CycleSkillCycleList();
    void  SetSkillCycleList(std::string& skill_cycle_string);

    void          SetAttackTrigger(ActorTrigger* trigger) { attack_trigger_ = trigger; }
    ActorTrigger* GetAttackTrigger() { return attack_trigger_; }
    void          SetGuardTrigger(ActorTrigger* trigger) { guard_trigger_ = trigger; }
    ActorTrigger* GetGuardTrigger() { return guard_trigger_; }
    void          SetAutoTrigger(ActorTrigger* trigger) { auto_trigger_ = trigger; }
    ActorTrigger* GetAutoTrigger() { return auto_trigger_; }

    void CommitSkill(int skill_id, int pre_selected_target_actor_id);
    void FinishedSkill(int skill_id);

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  private:
    ActorData*    actor_data_;
    Actor*        actor_;

    std::map<int, ActorSkillInfo>    skill_info_map_;
    std::list<int>    skill_cycle_list_;  //pop_front and push_back

    ActorTrigger*       attack_trigger_;  //target searching by <attack range>, mostly checked in Logic Idle/Move, if true, commit attack
    ActorTrigger*       guard_trigger_;  //target searching by <guard range>, mostly checked in Logic Idle/Move, if true, auto move(approach) and wait attack_trigger
    ActorTrigger*       auto_trigger_; //target searching by <auto range>(full screen normally), checked in Control Auto, if true, auto move(approach) and wait attack_trigger
  };

} // namespace actor


#endif // ACTOR_SKILL_DATA_H