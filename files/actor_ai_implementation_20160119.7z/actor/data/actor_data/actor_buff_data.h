#ifndef ACTOR_BUFF_DATA_H
#define ACTOR_BUFF_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorBuff;
  class ActorBuffLinkData;
  class ActorSkillLinkData;


  //also animation tag
  enum eActorAnimationPositionType
  {
    kActorAnimationPositionTop      = 7890001,
    kActorAnimationPositionMiddle   = 7890002,
    kActorAnimationPositionBottom   = 7890003,
    kActorAnimationPosition
  };
  
  
  typedef struct sActorBuffRegisterData {
    int register_type;
    std::list<ActorBuffLinkData*> buff_list;
  } ActorBuffRegisterData;



  class ActorBuffStatusData
  {
  public:
    ActorBuffStatusData();
    ~ActorBuffStatusData();

    void Clear();

    bool GetIsActive();
    bool GetIsImmune();

    void StackActive(int stack) { stack_active_ += stack; }
    void StackImmune(int stack) { stack_immune_ += stack; }

    void StackState(eActorBuffStatusStateType status_state);

  public:
    int stack_active_;
    int stack_immune_;
  };
  



  //buff data storage on the Actor, mainly for buff interaction (other data will be on Buff / Effect Object)
  class ActorBuffData
  {
  public:
    ActorBuffData(ActorData* actor_data);
    ~ActorBuffData();

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);

    bool RegisterBuff(ActorBuffLinkData* buff_link_data); //return is success
    void UnregisterBuff(ActorBuffLinkData* buff_link_data);

    //keyword: mark only, for "buff grouping", deal replace and stack
    bool CheckBuffKeyword(const std::string& buff_keyword);

    //status, logic linked, will cause actor behavior change
    void AddBuffStatusBitSet(ActorBuffStatusBitSet buff_status_bit_set, eActorBuffStatusStateType buff_status_state);
    void RemoveBuffStatusBitSet(ActorBuffStatusBitSet buff_status_bit_set);
    bool CheckBuffStatusBitSet(ActorBuffStatusBitSet buff_status_bit_set);

    ActorBuffStatusBitSet GetBuffStatusBitFlag();
    
    //currently in adapter
    void UpdateIncontrollable();
    int UpdateShader();

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  private:
    ActorData*    actor_data_;

    std::map<std::string, ActorBuffRegisterData> buff_keyword_register_map_;  //buff grouped by keyword, for replace check
    std::map<int, ActorBuffRegisterData> buff_id_register_map_;  //buff by buff_id, for stack check

    std::map<eActorBuffStatusType, ActorBuffStatusData> buff_status_map_;
  };


} // namespace actor


#endif // ACTOR_BUFF_DATA_H