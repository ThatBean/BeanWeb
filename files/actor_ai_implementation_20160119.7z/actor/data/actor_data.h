#ifndef ACTOR_DATA_H
#define ACTOR_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"

#include "game/actor/actor_adapter.h"

// include specialized data operation class
#include "actor_data/actor_basic_data.h"
#include "actor_data/actor_skill_data.h"
#include "actor_data/actor_buff_data.h"
#include "actor_data/actor_control_data.h"
#include "actor_data/actor_logic_data.h"
#include "actor_data/actor_motion_data.h"
#include "actor_data/actor_damage_data.h"
#include "actor_data/actor_specified_data.h"

#include "game/actor/template_class/actor_data_class.h"
#include "game/actor/template_class/actor_data_map_class.h"
#include "game/actor/template_class/data_log.h"

#include "cocos2d.h"



namespace actor {

  class Actor;
  class ActorData;

  class ActorDataSignalData;

  typedef ActorTemplateAttributeData<ActorDataSignalData> ActorAttributeData;
  typedef ActorTemplateStatusData<ActorDataSignalData> ActorStatusData;
  typedef ActorTemplatePositionData<ActorDataSignalData> ActorPositionData;

  typedef ActorTemplateAttributeDataMap<ActorDataSignalData, eActorAttributeType> ActorAttributeMap;
  typedef ActorTemplateStatusDataMap<ActorDataSignalData, eActorStatusType> ActorStatusMap;
  typedef ActorTemplatePositionDataMap<ActorDataSignalData, eActorPositionType> ActorPositionMap;

  class ActorDataSignalData 
  {
  public:
    ActorDataSignalData() 
      : key(-1)
      , type(-1)
      , actor_data(NULL)
    {}
    ~ActorDataSignalData() {}

    int key;  //for specific, non-default
    int type; //for data class type
    ActorData* actor_data;  //self reference
  };


  class ActorData
  {
  public:
    ActorData(Actor* actor);
    ~ActorData();

    void Init(eActorModelType actor_model_type = kActorModelActor);
    void ResetData();

    void ConnectDataSignal();

    void Update(float delta_time);

    //// Data with predefined enum keys
    bool CheckActorAttribute(eActorAttributeType data_key) { return attribute_map_.Check(data_key); }
    ActorAttributeData* GetActorAttributeData(eActorAttributeType data_key) { return attribute_map_.GetData(data_key); }
    
    void  InitActorAttribute(eActorAttributeType data_key, float base = 0, float add = 0, float multiplier = 1, float extra = 0) 
    { 
      ActorAttributeData* data = attribute_map_.GetData(data_key);
      data->SetDefault(data_key, &default_attribute_signal_data_);
      data->Init(base, add, multiplier, extra);
    }
    void  SetActorAttribute(eActorAttributeType data_key, float add = 0, float multiplier = 1, float extra = 0) { attribute_map_.Set(data_key, add, multiplier, extra); }
    void  AddActorAttribute(eActorAttributeType data_key, float add = 0, float multiplier = 0, float extra = 0) { attribute_map_.Add(data_key, add, multiplier, extra); }
    float GetActorAttribute(eActorAttributeType data_key) { return attribute_map_.Get(data_key); }
    

    //direct access to ActorStatusData
    bool CheckActorStatus(eActorStatusType data_key) { return status_map_.Check(data_key); }
    ActorStatusData* GetActorStatusData(eActorStatusType data_key) { return status_map_.GetData(data_key); }

    void  InitActorStatus(eActorStatusType data_key, int status) 
    { 
      ActorStatusData* data = status_map_.GetData(data_key);
      data->SetDefault(data_key, &default_status_signal_data_);
      data->Init(status);
    }
    void  SetActorStatus(eActorStatusType data_key, int status) { status_map_.Set(data_key, status); }
    int   GetActorStatus(eActorStatusType data_key) { return status_map_.Get(data_key); }

    void  InitActorStatusBool(eActorStatusType data_key, bool bool_status) 
    { 
      ActorStatusData* data = status_map_.GetData(data_key);
      data->SetDefault(data_key, &default_status_signal_data_);
      data->InitBool(bool_status);
    }
    void  SetActorStatusBool(eActorStatusType data_key, bool bool_status) { status_map_.SetBool(data_key, bool_status); }
    bool  GetActorStatusBool(eActorStatusType data_key) { return status_map_.GetBool(data_key); }


    //direct access to ActorPositionData
    bool CheckActorPosition(eActorPositionType data_key) { return position_map_.Check(data_key); }
    ActorPositionData* GetActorPositionData(eActorPositionType data_key) { return position_map_.GetData(data_key); }

    void  InitActorPosition(eActorPositionType data_key, cocos2d::CCPoint position) 
    { 
      ActorPositionData* data = position_map_.GetData(data_key);
      data->SetDefault(data_key, &default_position_signal_data_);
      data->Init(position);
    }
    void  SetActorPosition(eActorPositionType data_key, cocos2d::CCPoint position) { position_map_.Set(data_key, position); }
    cocos2d::CCPoint&   GetActorPosition(eActorPositionType data_key) { return position_map_.Get(data_key); }



    ActorAttributeMap*  GetAttributeMap() { return &attribute_map_; }
    ActorStatusMap*     GetStatusMap() { return &status_map_; }
    ActorPositionMap*   GetPositionMap() { return &position_map_; }


    //Actor*                GetActor() { return actor_; } //should not often be accessed directly in data

    ActorBasicData*       GetBasicData() { return basic_data_; }
    ActorSkillData*       GetSkillData() { return skill_data_; }
    ActorBuffData*        GetBuffData() { return buff_data_; }
    ActorDamageData*      GetDamageData() { return damage_data_; }

    ActorControlData*     GetControlData() { return control_data_; }
    ActorLogicData*       GetLogicData() { return logic_data_; }
    ActorMotionData*      GetMotionData() { return motion_data_; }

    ActorSpecifiedData*   GetSpecifiedData();

    //debug use log record
    DataLog* GetLog() { return data_log_; }

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  private:
    Actor*                actor_; //should not often be accessed directly in data
    
    DataLog*              data_log_; //debug use

    //key reserved, limited to declared type enum only
    ActorAttributeMap     attribute_map_;
    ActorStatusMap        status_map_;
    ActorPositionMap      position_map_;

    ActorDataSignalData   default_attribute_signal_data_;
    ActorDataSignalData   default_status_signal_data_;
    ActorDataSignalData   default_position_signal_data_;

    //Notice:
    // data in ActorData should avoid obtaining a direct pointer of Actor (Actor* actor_)
    // instead, a pointer of ActorData with actor back link is better
    ActorBasicData*       basic_data_;
    ActorSkillData*       skill_data_;
    ActorBuffData*        buff_data_; //store actor buff data
    ActorDamageData*      damage_data_;

    ActorControlData*     control_data_;      //processed control data to be used in logic / motion
    ActorLogicData*       logic_data_;        //logic input and output, (directly change this can affect logic in next Logic Update)
    ActorMotionData*      motion_data_;       //keep motion data(speed, target ...), mostly for animation

    ActorSpecifiedData*   specified_data_;    //different for each type of actor(mostly by Appearance), provide different function with the same name
  };



} // namespace actor


#endif // ACTOR_DATA_H