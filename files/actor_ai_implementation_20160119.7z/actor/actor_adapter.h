#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H

#include "game/actor/typedef/actor_data_typedef.h"

#include "game/army/unit/unit_constants.h"
#include "game/battle/damage/damage_constants.h"

#include "engine/animation/animation_constant.h"

#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

USING_NS_CC;
USING_NS_CC_EXT;

namespace actor {
  class Actor;
  class ActorExtEnv;
  
  //String operation
  //Search the string for space(the ' ', '\n', '\r', '\t'), and remove it, NOTE: will change source string
  std::string& ActorStringRemoveSpace(std::string& source_string);

  //Split the string at characters that matches any of the characters specified in delimiter_string.
  //delimiter can be ",|. " for multi-match split
  std::list<std::string>* ActorStringSplit(const std::string& source_string, const std::string& delimiter);




  //Parse
  eActorAttributeType ParseActorAttributeType(const std::string& source_string);
  eActorStatusType ParseActorStatusType(const std::string& source_string);
  eActorAnimationType ParseAnimationType(const std::string& source_string);
  eActorAnimationLayerType ParseAnimationLayerType(const std::string& source_string);
  eActorAnimationDisplayType ParseAnimationDisplayType(const std::string& source_string);
  eActorMovementOriginType ParseMovementOriginType(const std::string& source_string);
  eActorMovementType ParseMovementType(const std::string& source_string);

  std::list<EmitIdData> ParseEmitIdDataList(const std::string& source_string);

  ActorBuffStatusBitSet ParseBuffStatusBitSet(const std::string& source_string);



  //Routine (Called in LogicStateBorn)
  void InitRoutineConfigData(Actor* actor, int routine_config_id = ACTOR_INVALID_ID);




  //Element 
  // 0 for nothing, 1+ for advantage, -1- for disadvantage
  int GetElementCorrectionPositive(const ActorBuffStatusBitSet& source, const ActorBuffStatusBitSet& target);
  int GetElementCorrectionNegative(const ActorBuffStatusBitSet& source, const ActorBuffStatusBitSet& target);




  //MISC
  // TODO: Remove if possible
  ActorExtEnv* GetActorExtEnvAdapter();
  void AlertEnemyPassRightBorder(int actor_id);
  void AutoReleaseSpecialSkill(int actor_id); //Special skill with pause, for auto control
  void ShowDamageLabel(DamagePackage* damage_package, int actor_id, float damage_value);

} // namespace actor


#endif // ACTOR_ADAPTER_H
