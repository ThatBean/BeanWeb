#ifndef ACTOR_EXT_ENV_H
#define ACTOR_EXT_ENV_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/template_class/script_object.h"
#include "game/actor/template_class/actor_signal_hub.h"

#include "cocos2d.h"
#include "engine/base/basictypes.h"


namespace actor {
  
  class ActorExtDamage;
  class ActorExtEffect;
  class ActorExtGrid;
  class ActorExtUserOperation;

  class Actor;

  class ActorSkillLinkData;



  // the map / battlefield where actors live in (Actor Pool)
  class ActorExtEnv : public ScriptObjectPool  //ActorExternalEnvironment
  {
  public:
    ActorExtEnv();
    ~ActorExtEnv();

    void      Clear();
    void      Update(float delta_time);
  
  public:
    Actor*    CreateActor(); //will return actor with auto generated valid id
    Actor*    CreateActor(int actor_id); //alternative, provide predefined valid id
    void      RemoveActor(int actor_id);
    Actor*    GetActorById(int actor_id); //return NUll, if not found. For most class, just keep the actor id is enough

    std::list<Actor*>*        GetActorList();  //should delete after use, alive and in grid actor only, mostly used in trigger raw actor list
    std::map<int, Actor*>*    GetActorMap() { return &actor_map_; }

    //should move ? should move
    //for skill pause need
    void AddActorFocusById(int actor_id);
    void RemoveActorFocusById(int actor_id);
    void ClearActorFocus();

    void PauseActorExceptFocus();
    void ClearActorPause();

    void SetIsPause(bool is_pause);

    //for damage
    ActorExtDamage*         GetActorExtDamage() { return actor_ext_damage_; }
    //for effect
    ActorExtEffect*         GetActorExtEffect() { return actor_ext_effect_; }
    //for geometry
    ActorExtGrid*           GetActorExtGrid() { return actor_ext_grid_; }
    //for touch
    ActorExtUserOperation*  GetUserOperation() { return actor_ext_user_operation_; }

    //for effect buff emit
    void ApplyEmitIdDataList(std::list<EmitIdData>& emit_id_data_list, int actor_id, const ActorSkillLinkData& skill_link_data);

    //signal event
    ActorSignalHub<ActorEventData>* GetSignalHub() { return &signal_hub_; };

  private:
    std::map<int, Actor*>         actor_map_;

    ActorExtDamage*           actor_ext_damage_;
    ActorExtEffect*           actor_ext_effect_;
    ActorExtGrid*             actor_ext_grid_;
    ActorExtUserOperation*    actor_ext_user_operation_;

    //for skill pause need
    std::map<int, Actor*>     actor_focus_map_;
    bool                      is_pause_;

    //signal event
    ActorSignalHub<ActorEventData>    signal_hub_;
  };

} // namespace actor


#endif // ACTOR_EXT_ENV_H