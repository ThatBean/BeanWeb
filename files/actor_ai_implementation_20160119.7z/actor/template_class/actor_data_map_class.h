#ifndef ACTOR_DATA_MAP_CLASS_H
#define ACTOR_DATA_MAP_CLASS_H

#include "actor_data_class.h"


namespace cocos2d {
  class CCPoint;
}

namespace actor {
  template <typename t_data, typename t_key>
  class ActorTemplateAttributeDataMap {
  public:
    //direct access to AttributeData
    std::map< t_key, ActorTemplateAttributeData<t_data> >* GetDataMap() { return &data_map_; }
	
    bool Check(t_key data_key) { return (data_map_.find(data_key) != data_map_.end()); }
    ActorTemplateAttributeData<t_data>* GetData(t_key data_key) { return &(data_map_[data_key]); }
	
    //quick access
    void  Set(t_key data_key, float add = 0, float multiplier = 1, float extra = 0) { data_map_[data_key].Set(add, multiplier, extra); }
    void  Add(t_key data_key, float add = 0, float multiplier = 0, float extra = 0) { data_map_[data_key].Add(add, multiplier, extra); }
    float Get(t_key data_key) { return data_map_[data_key].Get(); }

  private:
    std::map< t_key, ActorTemplateAttributeData<t_data> > data_map_;
  };


  template <typename t_data, typename t_key>
  class ActorTemplateStatusDataMap {
  public:
    //direct access to StatusData
    std::map< t_key, ActorTemplateStatusData<t_data> >* GetDataMap() { return &data_map_; }
	
    bool Check(t_key data_key) { return (data_map_.find(data_key) != data_map_.end()); }
    ActorTemplateStatusData<t_data>* GetData(t_key data_key) { return &(data_map_[data_key]); }
	
    //quick access
    void  Set(t_key data_key, int status) { data_map_[data_key].Set(status); }
    int   Get(t_key data_key) { return data_map_[data_key].Get(); }
	
    void  SetBool(t_key data_key, bool bool_status) { data_map_[data_key].SetBool(bool_status); }
    bool  GetBool(t_key data_key) { return data_map_[data_key].GetBool(); }

  private:
    std::map< t_key, ActorTemplateStatusData<t_data> > data_map_;
  };


  template <typename t_data, typename t_key>
  class ActorTemplatePositionDataMap {
  public:
    //direct access to PositionData
    std::map< t_key, ActorTemplatePositionData<t_data> >* GetDataMap() { return &data_map_; }
	
    bool Check(t_key data_key) { return (data_map_.find(data_key) != data_map_.end()); }
    ActorTemplatePositionData<t_data>* GetData(t_key data_key) { return &(data_map_[data_key]); }
	
    //quick access
    void  Set(t_key data_key, cocos2d::CCPoint position) { data_map_[data_key].Set(position); }
    cocos2d::CCPoint&   Get(t_key data_key) { return data_map_[data_key].Get(); }

  private:
    std::map< t_key, ActorTemplatePositionData<t_data> > data_map_;
  };
} // namespace actor


#endif // ACTOR_DATA_MAP_CLASS_H