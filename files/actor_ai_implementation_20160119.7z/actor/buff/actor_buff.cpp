#include "actor_buff.h"

#include "actor_buff_mod.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext/actor_ext_damage.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/buff_config_data_table.h"
#include "game/data_table/buff_status_animation_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


/*
  Actor Buff
    Buff is Data with Update or Event on an Actor, or what a Effect will create.
    Buff will always be added to an Actor
    Buff will interact with other existing Buff, and has replacement rules and stack rules

    Life Span:
      Init: 
        need: buff_id
        optional: source_effect_link(id + ...), source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update / OnEvent: 
        (may or may not), mod something

      Clear: 
        self removal, when time out, Buff replacement, or actor dead
*/


namespace actor {


  static int DEBUG_ACTOR_BUFF_LINK_DATA_COUNT = 0;
  static int DEBUG_ACTOR_BUFF_COUNT = 0;


  static std::map<int, bool> buff_key_map;
  int RequestBuffKey(int start_from)
  {
    int possible_valid_id = start_from;
    if (start_from == ACTOR_INVALID_ID) possible_valid_id = buff_key_map.size() > 0 ? buff_key_map.rbegin()->first + 1 : 0; //guess best id
    while (buff_key_map.find(possible_valid_id) != buff_key_map.end()) possible_valid_id++; //check valid
    buff_key_map[possible_valid_id] = true;
    return possible_valid_id;
  }
  void ReturnBuffKey(int buff_key)
  {
    buff_key_map.erase(buff_key);
  }



  float get_buff_condition_check_data_type(ActorBuffLinkData* buff_link_data, eActorBuffConfigCheckDataType check_data_type)
  {
    switch (check_data_type)
    {
    case kActorBuffConfigCheckDataHealthPercent:
      return 100.0f 
        * buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent)
        / buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeHealthMax);
    case kActorBuffConfigCheckDataAttackCount:
      return buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeAttackCount);
    case kActorBuffConfigCheckDataAttackCountNormal:
      return buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeAttackNormalCount);
    case kActorBuffConfigCheckDataAttackCountPower:
      return buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeAttackPowerCount);
    case kActorBuffConfigCheckDataAttackCountSpecial:
      return buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeAttackSpecialCount);
    case kActorBuffConfigCheckDataAttackCountPowerSpecial:
      return buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeAttackPowerCount)
        + buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeAttackSpecialCount);
    case kActorBuffConfigCheckDataKillCount:
      return buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttribute(kActorAttributeKillCount);
    default:
      assert(false);
      return 0.0f;
    }
  }





  //ActorBuffLinkData
  ActorBuffLinkData::ActorBuffLinkData()
    : buff_key(ACTOR_INVALID_ID)

    , stack_count(1)
    , applied_count(0)
    , applied_time(0.0f)

    , buff_id(ACTOR_INVALID_ID)
    , actor_buff(NULL)

    , buff_config_data(NULL)
    , buff_mod_data_(NULL)
    , apply_data_(NULL)

    , event_data_damage_package(NULL)

    , applied_attribute_type(kActorAttribute)
    , revert_attribute_add(0.0f)
    , revert_attribute_multiplier(0.0f)
    , revert_attribute_extra(0.0f)

    , applied_status_state_type(kActorBuffStatusState)

    , is_active_(false)

    , trigger_time_current_(0.0f)
    , trigger_condition_check_data_reference_(0)
    , is_trigger_condition_check_data_pass_(false)

    , buff_animation_id_(ACTOR_INVALID_ID)
    , revert_tick_count_current_(0)
  {
    DEBUG_ACTOR_BUFF_LINK_DATA_COUNT ++;
  }


  ActorBuffLinkData::~ActorBuffLinkData()
  {
    DEBUG_ACTOR_BUFF_LINK_DATA_COUNT --;

    RemoveEffectAnimation();

    Clear();
  }

  void ActorBuffLinkData::Clear()
  {
    buff_key = ACTOR_INVALID_ID;

    stack_count = 1;
    applied_count = 0;
    applied_time = 0;

    buff_id = ACTOR_INVALID_ID;
    actor_buff = NULL;
    buff_config_data = NULL;
    skill_link_data.Clear();

    if (buff_mod_data_)
    {
      buff_mod_data_->Clear();
      delete buff_mod_data_;
    }
    buff_mod_data_ = NULL;
    apply_data_ = NULL;

    event_data_damage_package = NULL;

    applied_attribute_type = kActorAttribute;
    revert_attribute_add = 0.0f;
    revert_attribute_multiplier = 0.0f;
    revert_attribute_extra = 0.0f;

    applied_status_state_type = kActorBuffStatusState;
    applied_buff_status_bit_set.reset();

    is_active_ = false;

    trigger_time_current_ = 0;
    trigger_condition_check_data_reference_ = 0;
    is_trigger_condition_check_data_pass_ = false;

    buff_animation_id_ = ACTOR_INVALID_ID;
    revert_tick_count_current_ = 0;
  }


  void ActorBuffLinkData::Init()
  {
    assert(buff_key != ACTOR_INVALID_ID);
    assert(buff_id != ACTOR_INVALID_ID);
    assert(actor_buff);

    buff_config_data = DataManager::GetInstance().GetBuffConfigDataTable()->GetBuffConfig(buff_id);

    //check valid
    if (!buff_config_data)
    {
      CCLog("[ActorBuffLinkData][Init] missing buff config id: %d", buff_id);
      assert(false);
      return;
    }
    //check valid

    buff_mod_data_ = buff_config_data->GetBuffModDataCopy();
    apply_data_ = buff_config_data->GetApplyData();

    is_active_ = true;
  }


  void ActorBuffLinkData::StackReset(const ActorBuffLinkData& buff_link_data)
  {
    if (buff_config_data->GetStackLimit() > 0 && buff_config_data->GetStackLimit() >= stack_count)
    {
      applied_time = 0.0f;
      applied_count = 0.0f;

      stack_count ++;
    }
  }

  void ActorBuffLinkData::StackMerge(const ActorBuffLinkData& buff_link_data)
  {
    if (buff_config_data->GetStackLimit() > 0 && buff_config_data->GetStackLimit() >= stack_count)
    {
      if (apply_data_->apply_flag & kActorBuffConfigApplyLimitTime)
        applied_time -= buff_link_data.apply_data_->limit_time;
      if (apply_data_->apply_flag & kActorBuffConfigApplyLimitCount)
        applied_count -= buff_link_data.apply_data_->limit_count;

      stack_count ++;
    }
  }


  void ActorBuffLinkData::Update(float delta_time)
  {
    //active check
    if (is_active_ == false)
    {
      return;
    }

    if (
      (apply_data_->apply_flag & kActorBuffConfigApplyLimitCount && apply_data_->limit_count <= applied_count)
      || (apply_data_->apply_flag & kActorBuffConfigApplyLimitTime && apply_data_->limit_time <= applied_time)
      )
    {
      Deactivate();
      return;
    }
    

    if (apply_data_->apply_flag & kActorBuffConfigApplyLimitTime)
    {
      applied_time += delta_time;

      float current_revert_start_time = apply_data_->revert_start_time + (apply_data_->limit_time - apply_data_->revert_start_time) / (apply_data_->revert_tick_count - revert_tick_count_current_ - 1);
      if (applied_time >= current_revert_start_time)
      {
        //revert attribute only
        if (applied_attribute_type != kActorAttribute)
        {
          float revert_tick_attribute_add = revert_attribute_add / (apply_data_->revert_tick_count - revert_tick_count_current_);
          float revert_tick_attribute_multiplier = revert_attribute_multiplier / (apply_data_->revert_tick_count - revert_tick_count_current_);
          float revert_tick_attribute_extra = revert_attribute_extra / (apply_data_->revert_tick_count - revert_tick_count_current_);

          revert_attribute_add -= revert_tick_attribute_add;
          revert_attribute_multiplier -= revert_tick_attribute_multiplier;
          revert_attribute_extra -= revert_tick_attribute_extra;

          actor_buff->GetActor()->GetActorData()->AddActorAttribute(
            applied_attribute_type, 
            revert_tick_attribute_add, 
            revert_tick_attribute_multiplier, 
            revert_tick_attribute_extra);
        }

        revert_tick_count_current_ ++;
      }
    }

    if (apply_data_->apply_flag & kActorBuffConfigApplyTriggerTime)
    {
      trigger_time_current_ += delta_time;

      if (apply_data_->trigger_time <= trigger_time_current_)
      {
        ExecutBuffMod();
      }
    }

    if (apply_data_->apply_flag & kActorBuffConfigApplyTriggerCondition)
    {
      bool is_condition_check_pass = false;


      //check condition
      if (apply_data_->apply_flag & kActorBuffConfigApplyTriggerCondition)
      {
        switch (apply_data_->trigger_condition)
        {
        case kActorBuffConfigConditionCheckValuePerChange:
          {
            float check_data_current = get_buff_condition_check_data_type(this, eActorBuffConfigCheckDataType(apply_data_->trigger_condition_extra_data_int));
            float compare_value = apply_data_->trigger_condition_extra_data_float;
            is_condition_check_pass = (trigger_condition_check_data_reference_ + compare_value) <= check_data_current;
            if (is_condition_check_pass)
            {
              trigger_condition_check_data_reference_ = check_data_current;
            }
          }
          break;
        case kActorBuffConfigConditionCheckValuePerAbove:
          {
            float check_data_current = get_buff_condition_check_data_type(this, eActorBuffConfigCheckDataType(apply_data_->trigger_condition_extra_data_int));
            float compare_value = apply_data_->trigger_condition_extra_data_float;
            is_condition_check_pass = (trigger_condition_check_data_reference_ - compare_value) >= check_data_current 
              && is_trigger_condition_check_data_pass_ == false;
            is_trigger_condition_check_data_pass_ = is_condition_check_pass;
          }
          break;
        case kActorBuffConfigConditionCheckValuePerBelow:
          {
            float check_data_current = get_buff_condition_check_data_type(this, eActorBuffConfigCheckDataType(apply_data_->trigger_condition_extra_data_int));
            float compare_value = apply_data_->trigger_condition_extra_data_float;
            is_condition_check_pass = (trigger_condition_check_data_reference_ + compare_value) <= check_data_current 
              && is_trigger_condition_check_data_pass_ == false;
            is_trigger_condition_check_data_pass_ = is_condition_check_pass;
          }
          break;
        }
      }

      if (is_condition_check_pass)
      {
        ExecutBuffMod();
      }
    }
  }


  bool ActorBuffLinkData::GetIsActive()
  {
    return is_active_;
  }

  void ActorBuffLinkData::Deactivate()
  {
    is_active_ = false;
  }


  void ActorBuffLinkData::ExecutBuffMod()
  {
    if (is_active_ == false)
    {
      return;
    }

    // ActorBuffModTypedData result_data = buff_mod_data->Execute(this);
    if (buff_mod_data_)
      buff_mod_data_->Execute(this);

    applied_count ++;
    trigger_time_current_ = 0;

    CreateEffectAnimation();
  }

  void ActorBuffLinkData::ClearBuffMod()
  {
    AdvanceAndRemoveEffectAnimation();

    //revert buff mod if set "is_revert_on_end"
    if (apply_data_->is_revert_on_end && actor_buff && actor_buff->GetActor()->GetIsActorAlive())
    {
      if (applied_attribute_type != kActorAttribute)
      {
        actor_buff->GetActor()->GetActorData()->AddActorAttribute(
          applied_attribute_type, 
          revert_attribute_add, 
          revert_attribute_multiplier, 
          revert_attribute_extra);
      }

      if (applied_status_state_type != kActorBuffStatusState)
      {
        switch (applied_status_state_type)
        {
        case kActorBuffStatusStateAdd:
          actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(applied_buff_status_bit_set, kActorBuffStatusStateSub);
          break;
        case kActorBuffStatusStateSub:
          actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(applied_buff_status_bit_set, kActorBuffStatusStateAdd);
          break;
        case kActorBuffStatusStateImmuneAdd:
          actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(applied_buff_status_bit_set, kActorBuffStatusStateImmuneSub);
          break;
        case kActorBuffStatusStateImmuneSub:
          actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(applied_buff_status_bit_set, kActorBuffStatusStateImmuneAdd);
          break;
        default:
          assert(false);
          break;
        }
      }

    }

    return;
  }


  void ActorBuffLinkData::OnCreate()
  {
    if (apply_data_->apply_flag & kActorBuffConfigApplyTriggerOnCreate)
    {
      ExecutBuffMod();
    }

    if (apply_data_->apply_flag & kActorBuffConfigApplyTriggerCondition)
    {
      //init trigger condition data
      switch (apply_data_->trigger_condition)
      {
      case kActorBuffConfigConditionCheckValuePerChange:
      case kActorBuffConfigConditionCheckValuePerAbove:
      case kActorBuffConfigConditionCheckValuePerBelow:
        //init reference value
        trigger_condition_check_data_reference_ = get_buff_condition_check_data_type(this, eActorBuffConfigCheckDataType(apply_data_->trigger_condition_extra_data_int));
        is_trigger_condition_check_data_pass_ = false;
        break;
      }
    }
  }

  void ActorBuffLinkData::OnEvent(eActorEventType event_type, int linked_value, ActorEventData* event_data)
  {
    if (is_active_ && apply_data_->trigger_event == event_type)
    {
      switch (event_type)
      {
      case kActorEventActorKill:
        if (linked_value != actor_buff->GetActor()->GetScriptObjectId())
          break;
      case kActorEventActorBorn:
      case kActorEventActorDead:
        {
          assert(event_data->data_type == kActorEventDataActor);

          Actor* actor = actor_buff->GetActor();
          Actor* event_actor = event_data->data_value.actor;

          bool is_self = (actor == event_actor);
          bool is_ally = (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == event_actor->GetActorData()->GetActorStatus(kActorStatusFaction));
          bool is_enemy = !is_ally;

          bool is_valid = false;

          if (apply_data_->trigger_event_filter_flag & kActorBuffConfigEventFilterSelf) is_valid |= is_self;
          if (apply_data_->trigger_event_filter_flag & kActorBuffConfigEventFilterAlly) is_valid |= is_ally;
          if (apply_data_->trigger_event_filter_flag & kActorBuffConfigEventFilterEnemy) is_valid |= is_enemy;

          if (is_valid)
          {
            ExecutBuffMod();
          }
        }
        break;
      case kActorEventDamageGenerate:
      case kActorEventDamageReceive:
        {
          assert(event_data->data_type == kActorEventDataDamagePackage);

          event_data_damage_package = event_data->data_value.damage_package;

          ExecutBuffMod();

          event_data_damage_package = NULL;
        }
        break;
      }
    }
  }
  //ActorBuffLinkData



  void quick_append_buff_status_animation(ActorAnimationQueue* animation_queue, const CCPoint& position, int loop_count, int animation_type, const std::string& animation_name)
  {
    switch (animation_type)
    {
    case kActorAnimationArmatureName:
      {
        actor::ActorAnimationQueueData queue_data; 

        queue_data.position = position;
        queue_data.animation_type = actor::kActorAnimationQueueDataArmature;
        queue_data.animation_name = "bsj";
        queue_data.armature_name = animation_name;
        queue_data.loop_count = loop_count;

        animation_queue->Append(queue_data);
      }
      break;
    case kActorAnimationProjectileName:
      {
        actor::ActorAnimationQueueData queue_data; 

        queue_data.position = position;
        queue_data.animation_type = actor::kActorAnimationQueueDataProjectile;
        queue_data.animation_name = animation_name;

        animation_queue->Append(queue_data);
      }
      break;
    case kActorAnimationNone:
      break;
    case kActorAnimationEffectId:
    default:
      assert(false);
      break;
    }
  }


  void ActorBuffLinkData::CreateEffectAnimation()
  {
    RemoveEffectAnimation();

    assert(buff_animation_id_ == ACTOR_INVALID_ID);

    if (buff_config_data->GetStatusAnimationId() > 0)
    {
      BuffStatusAnimationData* buff_status_animation_data = DataManager::GetInstance().GetBuffStatusAnimationDataTable()->GetBuffStatusAnimation(buff_config_data->GetStatusAnimationId());

      //get position
      cocos2d::CCPoint animation_position;

      float actor_height = actor_buff->GetActor()->GetAnimation()->GetActorVisualHeight();
      switch (buff_status_animation_data->GetDisplayType())
      {
      case kActorAnimationDisplayAboveActor:
        animation_position = ccp( 0, actor_height + 50);
        break;
      case kActorAnimationDisplayOnActor:
        animation_position = ccp( 0, 0.5f * actor_height);
        break;
      case kActorAnimationDisplayBelowActor:
        animation_position = CCPointZero;
        break;
      default:
        assert(false);
        break;
      }

      actor::ActorAnimationQueue* animation_queue = actor_buff->GetActor()->GetAnimation()->CreateAnimationQueue();

      quick_append_buff_status_animation(animation_queue, animation_position, 1, 
        buff_status_animation_data->GetEffectTypeStart(), buff_status_animation_data->GetEffectNameStart());
      quick_append_buff_status_animation(animation_queue, animation_position, -1, 
        buff_status_animation_data->GetEffectTypeLoop(), buff_status_animation_data->GetEffectNameLoop());
      quick_append_buff_status_animation(animation_queue, animation_position, 1, 
        buff_status_animation_data->GetEffectTypeEnd(), buff_status_animation_data->GetEffectNameEnd());

      buff_animation_id_ = animation_queue->GetId();

      AdvanceEffectAnimation(); //play the first
    }
  }

  void ActorBuffLinkData::AdvanceEffectAnimation()
  {
    if (buff_animation_id_ > 0 && actor_buff)
    {
      actor::ActorAnimationQueue* animation_queue = actor_buff->GetActor()->GetAnimation()->GetAnimationQueue(buff_animation_id_);

      if (animation_queue)
      {
        //just play next
        animation_queue->AutoPlayNext();
      }
      else
      {
        //clean up buff_animation_id
        RemoveEffectAnimation();
      }
    }
  }


  void ActorBuffLinkData::AdvanceAndRemoveEffectAnimation()
  {
    if (buff_animation_id_ > 0 && actor_buff)
    {
      actor::ActorAnimationQueue* animation_queue = actor_buff->GetActor()->GetAnimation()->GetAnimationQueue(buff_animation_id_);

      if (animation_queue)
      {
        //just play on and release for auto delete
        animation_queue->AutoPlayAndDetach();
        buff_animation_id_ = ACTOR_INVALID_ID; 
      }
      else
      {
        //clean up buff_animation_id
        RemoveEffectAnimation();
      }
    }
  }

  void ActorBuffLinkData::RemoveEffectAnimation()
  {
    if (buff_animation_id_ > 0 && actor_buff)
    {
      actor_buff->GetActor()->GetAnimation()->RemoveAnimationQueue(buff_animation_id_);
      buff_animation_id_ = ACTOR_INVALID_ID;
    }
  }














  //ActorBuff
  ActorBuff::ActorBuff(Actor* actor)
    : actor_(actor)
  {
    Clear();

    DEBUG_ACTOR_BUFF_COUNT ++;
  }

  ActorBuff::~ActorBuff()
  {
    Clear();

    DEBUG_ACTOR_BUFF_COUNT --;
  }

  void ActorBuff::Clear()
  {
    std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin();
    while (iterator != buff_link_data_map_.end())
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      iterator ++;  //

      RemoveBuff(buff_link_data->buff_key);
    }
    buff_link_data_map_.clear();
  }

  void ActorBuff::Update(float delta_time)
  { 
    for (std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin(); iterator != buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      buff_link_data->Update(delta_time);
    }

    std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin();
    while (iterator != buff_link_data_map_.end())
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      iterator ++;  //

      if (!buff_link_data->GetIsActive()) 
      {
        buff_link_data->ClearBuffMod();
        RemoveBuff(buff_link_data->buff_key);
      }
    }
  }

  ActorBuffLinkData* ActorBuff::AddBuff(int buff_key, int buff_id, const ActorSkillLinkData& skill_link_data)
  {
    BuffConfigData* buff_config_data = DataManager::GetInstance().GetBuffConfigDataTable()->GetBuffConfig(buff_id);

    //check valid
    if (!buff_config_data)
    {
      CCLog("[ActorBuff][AddBuff] missing buff config id: %d", buff_id);
      assert(false);
      return NULL;
    }
    //check valid

    buff_key = RequestBuffKey(buff_key);

    if (buff_link_data_map_.find(buff_key) != buff_link_data_map_.end())
    {
      CCLog("[ActorBuff][AddBuff] duplicate buff key: %d", buff_key);
      assert(false);
    }

    ActorBuffLinkData* buff_link_data = new ActorBuffLinkData;

    buff_link_data->buff_key = buff_key;
    buff_link_data->buff_id = buff_id;
    buff_link_data->actor_buff = this;
    buff_link_data->skill_link_data = skill_link_data;
    
    buff_link_data->Init();

    if (actor_->GetActorData()->GetBuffData()->RegisterBuff(buff_link_data))
    {
      buff_link_data_map_[buff_key] = buff_link_data;
      buff_link_data->OnCreate();
      return buff_link_data;
    }
    else
    {
      buff_link_data_map_.erase(buff_key);
      ReturnBuffKey(buff_key);
      return NULL;
    }
  }


  void ActorBuff::RemoveBuff(int buff_key)
  {
    if (buff_link_data_map_.find(buff_key) != buff_link_data_map_.end())
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/actor/buff/lua_buff_mod.lua", 
        "RemoveLuaBuffModByActor", 
        actor_->GetScriptObjectId(),
        buff_key);

      actor_->GetActorData()->GetBuffData()->UnregisterBuff(buff_link_data_map_[buff_key]);
      
      delete buff_link_data_map_[buff_key];

      buff_link_data_map_.erase(buff_key);

      ReturnBuffKey(buff_key);
    }
  }

  void ActorBuff::DeactivateBuffByKeyword(const std::string& buff_keyword)
  {
    for (std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin(); iterator != buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      if (buff_link_data->buff_config_data->GetKeywordSet().find(buff_keyword) != buff_link_data->buff_config_data->GetKeywordSet().end())
      {
        buff_link_data->Deactivate();
      }
    }
  }

  void ActorBuff::DeactivateBuffById(int buff_id)
  {
    for (std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin(); iterator != buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      if (buff_link_data->buff_id == buff_id)
      {
        buff_link_data->Deactivate();
      }
    }
  }

  void ActorBuff::DeactivateBuffByStatus(const ActorBuffStatusBitSet& buff_status_bit_set)
  {
    for (std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin(); iterator != buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      if ((buff_link_data->applied_buff_status_bit_set & buff_status_bit_set).any())
      {
        buff_link_data->Deactivate();
      }
    }
  }

  void ActorBuff::DeactivateBuffByType(const std::string& buff_type)
  {
    for (std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin(); iterator != buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      if (buff_link_data->buff_config_data->GetIsPositive())
      {
        buff_link_data->Deactivate();
      }
    }
  }


  void ActorBuff::OnEvent(int signal_type, int linked_value, ActorEventData* event_data)
  {
    eActorEventType event_type = eActorEventType(signal_type);

    for (std::map<int, ActorBuffLinkData*>::iterator iterator = buff_link_data_map_.begin(); iterator != buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      buff_link_data->OnEvent(event_type, linked_value, event_data);
    }
  }

  std::string ActorBuff::GetDebugInfo(Actor* actor, const std::string& pre_text)
  {
    std::ostringstream string_stream;  // associate stream buffer to stream

    ActorBuff* actor_buff = actor->GetBuff();

    string_stream << pre_text << " >BuffCount:" << actor_buff->buff_link_data_map_.size() << std::endl;

    for (std::map<int, ActorBuffLinkData*>::iterator iterator = actor_buff->buff_link_data_map_.begin(); iterator != actor_buff->buff_link_data_map_.end(); iterator ++)
    {
      ActorBuffLinkData* buff_link_data = iterator->second;

      string_stream << pre_text << " >" << buff_link_data->buff_key << " BuffId:" << buff_link_data->buff_id << std::endl;
      string_stream << pre_text << " >" << buff_link_data->buff_key << " StackCount:" << buff_link_data->stack_count << std::endl;
      string_stream << pre_text << " >" << buff_link_data->buff_key << " AppliedCount:" << buff_link_data->applied_count << std::endl;
      string_stream << pre_text << " >" << buff_link_data->buff_key << " AppliedTime:" << buff_link_data->applied_time << std::endl;
    }

    return string_stream.str();
  }
  //ActorBuff

} // namespace actor