#include "actor_buff_mod_buff_mod_damage.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModDamage
  ActorBuffModTypedData ActorBuffModBuffModDamage::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyDamageMod:
      {
        if (!buff_link_data->event_data_damage_package)
        {
          buff_link_data->Deactivate();
          break;
        }

        const std::string& damage_data_type_string = buff_mod_data->GetExecutedArgument(0).GetString();
        float mod_value = buff_mod_data->GetExecutedArgument(1).GetNumber();

        bool is_heal = false;
        DamageAttributeData* damage_attribute_data = NULL;

        if (damage_data_type_string == "damage_health_total")
        {
          damage_attribute_data = buff_link_data->event_data_damage_package->GetAttributeData(kActorDamageAttributeHealth);
        }
        else if (damage_data_type_string == "damage_physical")
        {
          damage_attribute_data = buff_link_data->event_data_damage_package->GetAttributeData(kActorDamageAttributePhysical);
        }
        else if (damage_data_type_string == "damage_magical")
        {
          damage_attribute_data = buff_link_data->event_data_damage_package->GetAttributeData(kActorDamageAttributeMagical);
        }
        else if (damage_data_type_string == "heal_health_total")
        {
          damage_attribute_data = buff_link_data->event_data_damage_package->GetAttributeData(kActorDamageAttributeHealth);
          is_heal = true;
        }
        else if (damage_data_type_string == "heal_physical")
        {
          damage_attribute_data = buff_link_data->event_data_damage_package->GetAttributeData(kActorDamageAttributePhysical);
          is_heal = true;
        }
        else if (damage_data_type_string == "heal_magical")
        {
          damage_attribute_data = buff_link_data->event_data_damage_package->GetAttributeData(kActorDamageAttributeMagical);
          is_heal = true;
        }
        else
        {
          assert(false);
          buff_link_data->Deactivate();
          break;
        }

        if (damage_attribute_data)
        {
          mod_value = MAX(-1.0f * damage_attribute_data->GetBase(), mod_value); //Base + mod_value >= 0 , prevent damage - heal conversion

          //damage (result should >= 0)
          //heal (result should <= 0)
          if (is_heal) mod_value *= -1.0f; //Base + mod_value <= 0 

          damage_attribute_data->Add(mod_value, 0, 0);
        }
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModDamage][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModDamage

} // namespace actor