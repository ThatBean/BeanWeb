#include "actor_buff_mod_buff_mod_script.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModScript
  ActorBuffModTypedData ActorBuffModBuffModScript::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    ActorBuffModTypedData result_data;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyScriptMod:
    case kActorBuffModKeyScriptModNumber:
    case kActorBuffModKeyScriptModBool:
      {
        /*
          ABOUT Buff Script:

          CREATE
            The first time Execute will send to Lua[CreateLuaBuffMod]:
              ActorBuffLinkData* buff_link_data, 
              the Executed Argument(<string> ScriptName + <string> Arguments)

            Lua will Create BuffScriptMod, save buff_link_data, and return <number> lua_buff_mod_id

            <number> lua_buff_mod_id will replace <string> ScriptName

          EXECUTE
            Execute will send Lua[ExecuteLuaBuffMod]:
              <number> lua_buff_mod_id,
              the Executed Argument(<number> lua_buff_mod_id + <string> Arguments)

            So the type of the first Argument is important

          REMOVE
            On every ActorBuffLinkData deconstruction, Lua[RemoveLuaBuffModByActor] will pass:
              actor_id,
              buff_key

            On every ActorBuff deconstruction, Lua[RemoveLuaBuffModByActor] will pass:
              actor_id

            This should clear all Lua Buff Mod
        */
        int lua_buff_mod_id = ACTOR_INVALID_ID;

        eActorBuffModDataType data_type = buff_mod_data->GetExecutedArgument(0).GetDataType();
        switch (data_type)
        {
        case kActorBuffModDataString:
          {
            //first time execute
            lua_buff_mod_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/actor/buff/lua_buff_mod.lua", 
              "CreateLuaBuffMod", 
              buff_mod_data->GetExecutedArgument(0).GetString().c_str(),
              buff_link_data);

            //save to replace ScriptName
            buff_mod_data->GetArgument(0).SetNumber(kActorBuffModDataNumber, lua_buff_mod_id);
            buff_mod_data->GetExecutedArgument(0).SetNumber(kActorBuffModDataNumber, lua_buff_mod_id);
          }
          break;
        case kActorBuffModDataNumber:
          {
            //has lua_buff_mod_id
            lua_buff_mod_id = buff_mod_data->GetExecutedArgument(0).GetNumber();
          }
          break;
        default:
          CCLog("[ActorBuffModBuffModScript][Execute] error ExecutedArgument 0 data_type %d", data_type);
          assert(false);
          buff_link_data->Deactivate();
          break;
        }

        if (lua_buff_mod_id != ACTOR_INVALID_ID)
        {
          //create lua argument_data_table
          lua_tinker::table argument_data_table = QuickPackLuaArgumentTable(buff_mod_data->GetExecutedArgumentList(), 1);

          switch (buff_mod_key_type_)
          {
          case kActorBuffModKeyScriptMod:
            {
              LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/actor/buff/lua_buff_mod.lua", 
                "ExecuteLuaBuffMod", 
                lua_buff_mod_id,
                argument_data_table);
              result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
            }
            break;
          case kActorBuffModKeyScriptModNumber:
            {
              float result_number = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/actor/buff/lua_buff_mod.lua", 
                "ExecuteLuaBuffMod", 
                lua_buff_mod_id,
                argument_data_table);
              result_data.SetNumber(kActorBuffModDataNumber, result_number);
            }
            break;
          case kActorBuffModKeyScriptModBool:
            {
              bool result_bool = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/actor/buff/lua_buff_mod.lua", 
                "ExecuteLuaBuffMod", 
                lua_buff_mod_id,
                argument_data_table);
              result_data.SetBool(kActorBuffModDataBool, result_bool);
            }
            break;
          }
        }
        else
        {
          buff_link_data->Deactivate();
        }
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModScript][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    return result_data;
  }
  //ActorBuffModBuffModScript

} // namespace actor