#include "actor_buff_mod_bool.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "engine/base/random_helper.h"


namespace actor {

  //ActorBuffModBool
  ActorBuffModTypedData ActorBuffModBool::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    bool result_bool = false;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyBoolNot:
      {
        result_bool = !buff_mod_data->GetExecutedArgument(0).GetBool();
      }
      break;
    case kActorBuffModKeyBoolNumber:
      {
        const std::string& true_condition = buff_mod_data->GetExecutedArgument(0).GetString();
        float number_value = buff_mod_data->GetExecutedArgument(1).GetNumber();

        if (true_condition == "positive")
          result_bool = (number_value > 0);
        else if (true_condition == "negative")
          result_bool = (number_value < 0);
        else if (true_condition == "zero")
          result_bool = (number_value == 0);
        else
          assert(true_condition == "positive" 
          || true_condition == "negative" 
          || true_condition == "zero");
      }
      break;
    case kActorBuffModKeyBoolExistStatus:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        ActorBuffStatusBitSet actor_status_bit_set = actor->GetActorData()->GetBuffData()->GetBuffStatusBitFlag();

        result_bool = true;

        std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin();
        iterator ++;  //skip first argument
        for ( ; iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          ActorBuffStatusBitSet test_status_bit_set = ParseBuffStatusBitSet(iterator->GetString());
          result_bool &= (actor_status_bit_set & test_status_bit_set).any();
        }
      }
      break;
    case kActorBuffModKeyBoolExistKeyword:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        result_bool = true;

        std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin();
        iterator ++;  //skip first argument
        for ( ; iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          result_bool &= actor->GetActorData()->GetBuffData()->CheckBuffKeyword(iterator->GetString());
        }
      }
      break;
    case kActorBuffModKeyBoolCheckDamage:
      {
        if (!buff_link_data->event_data_damage_package)
        {
          buff_link_data->Deactivate();
          break;
        }

        const std::string& damage_check_type = buff_mod_data->GetExecutedArgument(0).GetString();

        if (damage_check_type == "critical")
        {
          result_bool = buff_link_data->event_data_damage_package->GetStatusBool(kActorDamageStatusIsCritical);
        }
        else if (damage_check_type == "miss")
        {
          result_bool = buff_link_data->event_data_damage_package->GetStatusBool(kActorDamageStatusIsMissed);
        }
        else
        {
          assert(damage_check_type == "critical" 
            || damage_check_type == "miss");
          buff_link_data->Deactivate();
          break;
        }
      }
      break;
    case kActorBuffModKeyBoolMod:
      {
        const std::string& bool_operation_type = buff_mod_data->GetExecutedArgument(0).GetString();
        bool bool_1 = buff_mod_data->GetExecutedArgument(1).GetBool();
        bool bool_2 = buff_mod_data->GetExecutedArgument(2).GetBool();

        if (bool_operation_type == "and")
        {
          result_bool = (bool_1 && bool_2);
        }
        else if (bool_operation_type == "or")
        {
          result_bool = (bool_1 || bool_2);
        }
        else if (bool_operation_type == "xor")
        {
          result_bool = (bool_1 != bool_2);
        }
        else
        {
          assert(bool_operation_type == "and" 
            || bool_operation_type == "or"
            || bool_operation_type == "xor");
          buff_link_data->Deactivate();
          break;
        }
      }
      break;
    case kActorBuffModKeyBoolRandom:
      {
        float true_chance = buff_mod_data->GetExecutedArgument(0).GetNumber();

        result_bool = (random_0_1() <= true_chance);
      }
      break;
    default:
      CCLog("[ActorBuffModBool][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBool(kActorBuffModDataBool, result_bool);
    return result_data;
  }
  //ActorBuffModBool

} // namespace actor