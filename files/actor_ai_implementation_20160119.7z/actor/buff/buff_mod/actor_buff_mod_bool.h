#ifndef ACTOR_BUFF_MOD_BOOL_H
#define ACTOR_BUFF_MOD_BOOL_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {

  class ActorBuffModBool : public ActorBuffMod
  {
  public:
    ActorBuffModBool(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffModBool; };
  };

} // namespace actor


#endif // ACTOR_BUFF_MOD_BOOL_H