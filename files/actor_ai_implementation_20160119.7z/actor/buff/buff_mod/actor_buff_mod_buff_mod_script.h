#ifndef ACTOR_BUFF_MOD_BUFF_MOD_SCRIPT_H
#define ACTOR_BUFF_MOD_BUFF_MOD_SCRIPT_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {
  class ActorBuffModBuffModScript : public ActorBuffMod
  {
  public:
    ActorBuffModBuffModScript(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffMod; };
  };

  class ActorBuffModBuffModScriptNumber : public ActorBuffModBuffModScript
  {
  public:
    ActorBuffModBuffModScriptNumber(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffModBuffModScript(buff_mod_key_type)
    {}

    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataNumber; };
  };

  class ActorBuffModBuffModScriptBool : public ActorBuffModBuffModScript
  {
  public:
    ActorBuffModBuffModScriptBool(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffModBuffModScript(buff_mod_key_type)
    {}

    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBool; };
  };
} // namespace actor


#endif // ACTOR_BUFF_MOD_BUFF_MOD_SCRIPT_H