#ifndef ACTOR_BUFF_MOD_H
#define ACTOR_BUFF_MOD_H

#include "game/actor/actor_adapter.h"

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/battle/data/battle_data_typedef.h"

#include "game/battle/battle_controller.h"

#include "engine/script/lua_tinker_manager.h"

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorBuff;
  class ActorBuffLinkData;

  class ActorBuffMod;
  class ActorBuffModData;

  //used for buff customization
  // value get
  // value set
  // simple logic


  //by return result type
  enum eActorBuffModDataType {
    //direct usable value
    kActorBuffModDataNumber = 1,
    kActorBuffModDataBool,
    kActorBuffModDataString,
    kActorBuffModDataBuffMod,

    //execute mod for value
    kActorBuffModDataBuffModNumber,  //a buff mod will generate a number
    kActorBuffModDataBuffModBool,  //a buff mod will generate a bool
    kActorBuffModDataBuffModString,  //a buff mod will generate a string
    //kActorBuffModDataBuffModBuffMod,  //a buff mod will generate a buff mod(not gonna happen)

    //mark for parsing, represent 0 ~ n count of execute/direct value, stop till one or more empty value is meet
    kActorBuffModDataMoreNumber,
    kActorBuffModDataMoreBool,
    kActorBuffModDataMoreString,
    kActorBuffModDataMoreBuffMod,
    kActorBuffModDataMore,  //more Buff Mod or String

    kActorBuffModData = -1
  };


  enum eActorBuffModKeyType {
    kActorBuffModKeyNumber = 1,
    
    kActorBuffModKeyNumberFromActor,
    kActorBuffModKeyNumberFromSkill,
    kActorBuffModKeyNumberFromDamage,
    kActorBuffModKeyNumberFromBuff,
    kActorBuffModKeyNumberFromBattle,
    kActorBuffModKeyNumberFromPool,
    kActorBuffModKeyNumberMod,
    kActorBuffModKeyNumberRandom,
    kActorBuffModKeyNumberFromScript,

    kActorBuffModKeyBoolNot,
    kActorBuffModKeyBoolNumber,
    kActorBuffModKeyBoolExistStatus,
    kActorBuffModKeyBoolExistKeyword,
    kActorBuffModKeyBoolCheckDamage,
    kActorBuffModKeyBoolMod,
    kActorBuffModKeyBoolRandom,

    kActorBuffModKeyApplyIf,

    kActorBuffModKeyActorAttributeMod,
    kActorBuffModKeyActorStatusMod,
    kActorBuffModKeyActorPositionMod,

    kActorBuffModKeyStatusAdd,
    kActorBuffModKeyStatusImmune,
    kActorBuffModKeyStatusRemove,

    kActorBuffModKeyDamageMod,

    kActorBuffModKeyEmitEffectTimeline,

    kActorBuffModKeyBuffAddById,
    kActorBuffModKeyBuffRemoveById,
    kActorBuffModKeyBuffRemoveByStatus,
    kActorBuffModKeyBuffRemoveByKeyword,
    kActorBuffModKeyBuffRemoveByType,

    kActorBuffModKeyScriptMod,
    kActorBuffModKeyScriptModNumber,
    kActorBuffModKeyScriptModBool,

    kActorBuffModKey = -1
  };


  //packed typed data
  class ActorBuffModTypedData
  {
  public:
    ActorBuffModTypedData();
    ~ActorBuffModTypedData();

    ActorBuffModTypedData(const ActorBuffModTypedData& typed_data);

  public:
    void Clear();

    eActorBuffModDataType GetDataType() const { return data_type_; }

    void SetBuffMod(eActorBuffModDataType data_type, ActorBuffModData* value);
    void SetNumber(eActorBuffModDataType data_type, float value);
    void SetBool(eActorBuffModDataType data_type, bool value);
    void SetString(eActorBuffModDataType data_type, std::string& value);

    ActorBuffModData* GetBuffMod(eActorBuffModDataType data_type = kActorBuffModDataBuffMod) const;
    float GetNumber(eActorBuffModDataType data_type = kActorBuffModDataNumber) const;
    bool GetBool(eActorBuffModDataType data_type = kActorBuffModDataBool) const;
    const std::string& GetString(eActorBuffModDataType data_type = kActorBuffModDataString) const;

  private:
    eActorBuffModDataType data_type_;

    ActorBuffModData* data_buff_mod_data_;
    float data_number_;
    bool data_bool_;
    std::string data_string_;
  };




  //data store
  class ActorBuffModData
  {
  public:
    ActorBuffModData(eActorBuffModDataType buff_mod_data_type, eActorBuffModKeyType buff_mod_key_type);
    ~ActorBuffModData();

    ActorBuffModData(const ActorBuffModData& buff_mod_data);

    virtual void Clear();

    virtual void AppendArgument(ActorBuffModTypedData& argument); //no remove method
    virtual ActorBuffModTypedData& GetArgument(int index = 0);

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data);  //will apply mod to linked actor

    virtual eActorBuffModDataType GetBuffModDataType() { return buff_mod_data_type_; }
    virtual eActorBuffModKeyType GetBuffModKeyType() { return buff_mod_key_type_; };

  public:
    virtual void ClearExecutedArgument();
    virtual void ExecuteArgument(ActorBuffLinkData* buff_link_data);  //will generate executed_argument_list(either direct copy or loop)

    virtual ActorBuffModTypedData& GetExecutedArgument(int index = 0);
    virtual std::list<ActorBuffModTypedData>& GetExecutedArgumentList() { return executed_argument_list_; }

  protected:
    eActorBuffModDataType buff_mod_data_type_;
    eActorBuffModKeyType buff_mod_key_type_;
    std::list<ActorBuffModTypedData> argument_list; //buff_key - buff_id | the buff related to this actor
    std::list<ActorBuffModTypedData> executed_argument_list_; //buff_key - buff_id | the buff related to this actor

  };




  //processor, packed logic
  class ActorBuffMod
  {
  public:
    ActorBuffMod(eActorBuffModKeyType buff_mod_key_type);

    virtual eActorBuffModDataType GetBuffModDataType() { assert(false); return kActorBuffModData; } //= 0;
    virtual eActorBuffModKeyType GetBuffModKeyType() { return buff_mod_key_type_; };

  public:
    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data) { assert(false); ActorBuffModTypedData typed_data; return typed_data; } //= 0;

  protected:
    eActorBuffModKeyType buff_mod_key_type_;

  };

  //the buff_mod_string_list will be consumed during parse(size change), but require delete it outside
  ActorBuffModData* ParseActorBuffModData(std::list<std::string>* buff_mod_string_list);


  ActorBuffMod* GetActorBuffMod(eActorBuffModKeyType buff_mod_key);
  ActorBuffModData* CreateActorBuffModData(eActorBuffModKeyType buff_mod_key);

  Actor* QuickGetSelectedActor(ActorBuffLinkData* buff_link_data, const std::string& selected_actor_type);

  taomee::battle::BattleController* QuickGetBattleController();
  
  lua_tinker::table QuickPackLuaArgumentTable(const std::list<ActorBuffModTypedData>& argument_list, int skip_count = 0);
  
  battle_data::eBattleAttributeType ParseBattleAttributeType(const std::string& source_string);
  battle_data::eBattleStatusType ParseBattleStatusType(const std::string& source_string);
} // namespace actor


#endif // ACTOR_BUFF_MOD_H