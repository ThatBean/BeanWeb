#ifndef ACTOR_LINK_DATA_TYPEDEF_H
#define ACTOR_LINK_DATA_TYPEDEF_H

#include "actor_data_typedef.h"

#include <list>


class SkillConfigData;
class EffectConfigData;


namespace actor {


  //skill needed link data, NOTE: only link up(effect hold link too)
  class ActorSkillLinkData 
  {
  public:
    ActorSkillLinkData()
    {
      Clear();
    }

    void Clear()
    {
      skill_key = ACTOR_INVALID_ID;

      skill_id = ACTOR_INVALID_ID;
      skill_level = 0;
      skill_config_data = NULL;

      actor_id = ACTOR_INVALID_ID;
      actor_level = 0;

      target_actor_id_list.clear();
    }

  public:
    int skill_key;

    int skill_id;
    int skill_level;  //quick access
    SkillConfigData* skill_config_data; //quick access

    int actor_id;
    int actor_level;  //quick access

    std::list<int> target_actor_id_list;

    //effect link?
  };




  //effect needed link data
  class ActorEffectLinkData 
  {
  public:
    ActorEffectLinkData()
    {
      Clear();
    }

    void Clear()
    {
      effect_key = ACTOR_INVALID_ID;
      effect_id = ACTOR_INVALID_ID;
      effect_timeline_id = ACTOR_INVALID_ID;
      effect_timeline_item_index = ACTOR_INVALID_ID;
      effect_config_data = NULL;
      skill_link_data.Clear();
    }

  public:
    int effect_key;
    int effect_id;

    int effect_timeline_id;
    int effect_timeline_item_index;

    EffectConfigData* effect_config_data; //quick access

    ActorSkillLinkData skill_link_data;
  };


} // namespace actor


#endif // ACTOR_LINK_DATA_TYPEDEF_H