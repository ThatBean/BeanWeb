#ifndef ACTOR_DATA_TYPEDEF_H
#define ACTOR_DATA_TYPEDEF_H

#ifndef CALC_ARRAY_LEN_BY_SIZE_OF
#define CALC_ARRAY_LEN_BY_SIZE_OF(array) ( sizeof( array ) / sizeof( array[0] ) )
#endif

#include <sstream>
#include <string>
#include <bitset>

namespace actor {

  const int ACTOR_INVALID_ID = -1;


  const float ACTOR_CONTROL_COUNTDOWN = 0.5f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_IDLE_CHECK = 0.1f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_MOVE_CHECK = 0.05f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_DEAD = 1.5f; //control update interval, in second.


  const int GRID_Y_RANGE = 3;
  const int GRID_Y_RANGE_TOP = 1;
  const int GRID_Y_RANGE_MIDDLE = 2;
  const int GRID_Y_RANGE_BOTTOM = 3;
//   const int GRID_Y_RANGE_MIDDLE = (GRID_Y_RANGE_TOP + GRID_Y_RANGE) * 0.5;
//   const int GRID_Y_RANGE_BOTTOM = GRID_Y_RANGE_TOP + (GRID_Y_RANGE - 1);

  const int GRID_X_RANGE = 6;
  const int GRID_X_RANGE_LEFT = 1;
  //const float GRID_X_RANGE_MIDDLE = 3.5;
  const int GRID_X_RANGE_RIGHT = 6;
  const int GRID_X_RANGE_LEFT_MIDDLE = 2;
  const int GRID_X_RANGE_RIGHT_MIDDLE = 5;
//   const float GRID_X_RANGE_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE) * 0.5;
//   const int GRID_X_RANGE_RIGHT = GRID_X_RANGE_LEFT + (GRID_X_RANGE - 1);
//   const int GRID_X_RANGE_LEFT_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE_MIDDLE) * 0.5;
//   const int GRID_X_RANGE_RIGHT_MIDDLE = (GRID_X_RANGE_MIDDLE + GRID_X_RANGE_RIGHT) * 0.5;


  // for player controlled actor in PVE
  const int PLAYER_IDLE_VALID_GRID_X_RANGE = 4;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = 4;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = 3;
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = GRID_X_RANGE_LEFT + (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = GRID_X_RANGE_RIGHT - (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);

} // namespace actor


namespace actor {

  enum eActorModuleType {
    kActorModuleScriptExporter  = 1 << 0,
    kActorModuleData            = 1 << 1,
    kActorModuleAnimation       = 1 << 2,
    kActorModuleControl         = 1 << 3,
    kActorModuleLogic           = 1 << 4,
    kActorModuleMotion          = 1 << 5,
    kActorModuleSkill           = 1 << 6,
    kActorModuleBuff            = 1 << 7,

    kActorModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_MODEL_ACTOR = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleSkill
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_MODEL_EFFECT = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | kActorModuleAnimation
    | 0;
  const unsigned long ACTOR_MODEL_DATA = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | 0;


  //data dependency
  const unsigned long ACTOR_DATA_DEPENDENCY_BASIC = 0
    | kActorModuleLogic
    | kActorModuleMotion
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_SKILL = 0
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleSkill
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_BUFF = 0
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_DAMAGE = 0
    | kActorModuleAnimation
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_CONTROL = 0
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleBuff
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleScriptExporter
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_LOGIC = 0
    | kActorModuleLogic
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_MOTION = 0
    | kActorModuleMotion
    | 0;


  enum eActorAnimationModuleType {
    kActorAnimationModuleSkeletonAnimation  = 1 << 0,
    kActorAnimationModuleOverheadLayer      = 1 << 1,
    kActorAnimationModuleBottomSyncLayer    = 1 << 2,
    kActorAnimationModuleEffect             = 1 << 3,
    //kActorAnimationModule = 1 << 0,
    kActorAnimationModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR = 0
    | kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleOverheadLayer
    | kActorAnimationModuleBottomSyncLayer
    | 0;
  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR_LITE = 0
    | kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleOverheadLayer
    | 0;
  const unsigned long ACTOR_ANIMATION_MODEL_EFFECT = 0
    | kActorAnimationModuleEffect
//     | kActorAnimationModuleOverheadLayer
//     | kActorAnimationModuleBottomSyncLayer
    | 0;
  const unsigned long ACTOR_ANIMATION_MODEL_DATA = 0
//     | kActorAnimationModuleSkeletonAnimation
//     | kActorAnimationModuleOverheadLayer
//     | kActorAnimationModuleBottomSyncLayer
    | 0;


  //Model
  enum eActorModelType {
    kActorModelActor = ACTOR_MODEL_ACTOR,
    kActorModelEffect = ACTOR_MODEL_EFFECT,
    kActorModelData = ACTOR_MODEL_DATA,
    //kActorModel = 1 << 0,
    kActorModel = -1
  };
  enum eActorAnimationModelType {
    kActorAnimationModelActor = ACTOR_ANIMATION_MODEL_ACTOR,
    kActorAnimationModelActorLite = ACTOR_ANIMATION_MODEL_ACTOR_LITE,
    kActorAnimationModelEffect = ACTOR_ANIMATION_MODEL_EFFECT,
    kActorAnimationModelData = ACTOR_ANIMATION_MODEL_DATA,
    //kActorAnimationModel = 1 << 0,
    kActorAnimationModel = -1
  };
}



namespace actor {
  
  //BELOW WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //BELOW WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //BELOW WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]


  //Data
  enum eActorDataClassType {
    kActorDataClassAttribute = 1,
    kActorDataClassStatus,
    kActorDataClassPosition,
    kActorDataClass = -1
  };

  enum eActorAttributeType  //independent float value //from 1 to 9999
  {
    kActorAttributeInvalid = 0, //min

    //basic
    kActorAttributeTimeActive,
    
    //Health & Energy
    kActorAttributeHealthMax,  //normal
    kActorAttributeHealthCurrent,  //battle only
    kActorAttributeHealthRecover,  //recover per second, dispense by 0.2sec

    kActorAttributeEnergyMax,
    kActorAttributeEnergyCurrent,
    kActorAttributeEnergyRecover,

    //Factor
    kActorAttributeFactorCritical,
    kActorAttributeFactorCriticalResist,
    kActorAttributeFactorCriticalExtra,

    kActorAttributeFactorHit,

    kActorAttributeFactorDodge,
    kActorAttributeFactorDodgeExtra,

    kActorAttributeFactorDamageAdjust,
    kActorAttributeFactorDamageAdjustResist,
    kActorAttributeFactorDamageAdjustExtra,

    kActorAttributeFactorSkillDamage,
    kActorAttributeFactorSkillDamageResist,

    //Speed
    kActorAttributeSpeedAttack,
    kActorAttributeSpeedMove,

    //Damage Related
    kActorAttributeAttackPhysical,
    kActorAttributeAttackMagical,
    kActorAttributeAttackCritical,

    kActorAttributeDefensePhysical,
    kActorAttributeDefenseMagical,
    kActorAttributeDefenseCritical,

    //Trigger Related
    kActorAttributeTriggerSizeScaleAttack,
    kActorAttributeTriggerSizeScaleGuard,

    kActorAttributeAttackAreaRadius, //by the number of grid, not pixel
    kActorAttributeAttackAreaWidth, //by the number of grid, not pixel
    kActorAttributeAttackAreaHeight, //by the number of grid, not pixel

    kActorAttributeGuardAreaRadius, //by the number of grid, not pixel
    kActorAttributeGuardAreaWidth, //by the number of grid, not pixel
    kActorAttributeGuardAreaHeight, //by the number of grid, not pixel

    //kActorAttributeDamage,
    kActorAttributeDamageAddition,  //for all kinds, applied last
    kActorAttributeDamageAdditionPhysical,
    kActorAttributeDamageAdditionMagical,
    kActorAttributeDamageAdditionCritical,
    kActorAttributeDamageAdditionHealth,
    kActorAttributeDamageAdditionEnergy,

    kActorAttributeDamageReduction, //for all kinds, applied last
    kActorAttributeDamageReductionPhysical,
    kActorAttributeDamageReductionMagical,
    kActorAttributeDamageReductionCritical,
    kActorAttributeDamageReductionHealth,
    kActorAttributeDamageReductionEnergy,


    //Statistic Related
    kActorAttributeKillCount,
    
    kActorAttributeAttackCount,
    kActorAttributeAttackNormalCount,
    kActorAttributeAttackPowerCount,
    kActorAttributeAttackSpecialCount,


    kActorAttributeLogicInvalid = 1000,

    kActorAttributeMotionInvalid = 2000,

    kActorAttributeControlInvalid = 3000,

    kActorAttributeBuffInvalid = 4000,

    kActorAttributeSkillInvalid = 5000,

    kActorAttributeAnimationInvalid = 6000,
    kActorAttributeAnimationScale,

    kActorAttributeSpecifiedInvalid = 7000,

    kActorAttribute = 9999  //max
  };

  enum eActorStatusType  //independent bool/enum/int value //from 10000 to 19999
  {
    kActorStatusInvalid = 10000,  //min
    
    //Basic
    kActorStatusActorId,  //actor_id access for actor_data, for actor, use script object id
    kActorStatusActorModel, //eActorModelType
    kActorStatusAnimationModel, //eActorAnimationModelType

    kActorStatusCardId,
    kActorStatusEffectConfigId, //for ExtEffect - Actor
    kActorStatusLevel,

    kActorStatusFaction,
    kActorStatusHomeDirection,

    kActorStatusAppearance,
    kActorStatusCareer,

    kActorStatusAttackAreaType, //eActorPredefinedTriggerType
    kActorStatusGuardAreaType, //eActorPredefinedTriggerType
    kActorStatusAutoAreaType, //eActorPredefinedTriggerType

    kActorStatusLogicState,
    kActorStatusMotionState,

    //same use as buff status, but for control/routine
    kActorStatusIsIncontrollable,
    kActorStatusIsMuteMove,
    kActorStatusIsMuteAttack,
    kActorStatusIsMuteAttackNormal,
    kActorStatusIsMuteAttackPower,
    kActorStatusIsMuteAttackSpecial,
    kActorStatusIsMuteGuard,

    kActorStatusBornType, //
    kActorStatusDeadType, //

    kActorStatusIsDisableUserOperation, //accept manual control, use to mute ally switch

    //AcceptDamage(Immune = do not accept)
    kActorStatusAcceptDamage,
    kActorStatusAcceptDamagePhysical,
    kActorStatusAcceptDamageMagical,
    kActorStatusAcceptDamageCritical,
    kActorStatusAcceptDamageIce,
    kActorStatusAcceptDamageFire,
    kActorStatusAcceptDamageWind,

    //Logic & Motion
    kActorStatusLogicInvalid = 11000,

    kActorStatusMotionInvalid = 12000,
    kActorStatusMotionIsBusy,  //IsMotionAnimationEnded

    kActorStatusControlInvalid = 13000,
    kActorStatusControlIsAuto,
    kActorStatusControlIsManual,
    kActorStatusControlIsCounterAttack,
    kActorStatusControlAutoGuardType,
    kActorStatusControlAutoReleaseSpecialSkillType,
    kActorStatusControlAutoReleaseSpecialSkillCount,
    kActorStatusControlAutoReleaseSpecialSkillProbability,

    kActorStatusBuffInvalid = 14000,
    kActorStatusBuffShaderType,
    kActorStatusBuffIsPauseAnimation,
    kActorStatusBuffIsChangeColor,
    kActorStatusBuffIsIncontrollable,
    kActorStatusBuffIsMuteMove,
    kActorStatusBuffIsMuteAttack,
    kActorStatusBuffIsMuteAttackNormal,
    kActorStatusBuffIsMuteAttackPower,
    kActorStatusBuffIsMuteAttackSpecial,
    kActorStatusBuffIsMuteGuard,

    kActorStatusSkillInvalid = 15000,
    kActorStatusSkillCurrentSkillId,
    kActorStatusSkillIsBusy,
    kActorStatusSkillIsPaused,
    kActorStatusSkillAttackType,  //type of attack -> decide attack trigger
    kActorStatusSkillGuardType,   //type of guard -> decide guard trigger
    kActorStatusSkillAutoType,    //type of auto attack -> decide auto attack trigger

    kActorStatusAnimationInvalid = 16000,
    kActorStatusAnimationIsPaused,
    kActorStatusAnimationIsFocused,
    kActorStatusAnimationDirection,
    kActorStatusAnimationIsHealthChanged,

    kActorStatusSpecifiedInvalid = 17000,
    kActorStatusSpecifiedIsLimitGridX,

    kActorStatus = 19999  //max
  };

  enum eActorPositionType  //independent CCPoint value //from 20000 to 29999
  {
    kActorPositionInvalid = 20000,  //min

    //Info
    kActorPositionAnimation,  // will apply to ActorNode in Animation update, so use as ActorPosition
    kActorPositionTargetGridBorn,  // for actor routine - Born

    kActorPositionLogicInvalid = 21000,

    kActorPositionMotionInvalid = 22000,
    kActorPositionMotionMoveTarget,     //  Target move position
    kActorPositionMotionMoveSpeedUnit,     // Normalized speed vector(the Direction)

    kActorPositionControlInvalid = 23000,
    
    kActorPositionBuffInvalid = 24000,

    kActorPositionSkillInvalid = 25000,

    kActorPositionAnimationInvalid = 26000,

    kActorPositionSpecifiedInvalid = 27000,
    //kActorPositionSpecifiedLastIdleGrid,

    kActorPosition = 29999  //max
  };




  //Animation
  enum eActorAnimationDirection {
    kActorAnimationDirectionLeft = 1,
    kActorAnimationDirectionRight,

    kActorAnimationDirection = -1
  };
  enum eActorAnimationType {
    kActorAnimationNone = 1,
    kActorAnimationEffectId,
    kActorAnimationArmatureName,
    kActorAnimationProjectileName,

    kActorAnimation = -1
  };
  enum eActorAnimationLayerType {
    kActorAnimationLayerTop = 1,
    kActorAnimationLayerActor,
    kActorAnimationLayerBottom,

    kActorAnimationLayer = -1
  };
  enum eActorAnimationDisplayType {
    kActorAnimationDisplayAboveActor = 1,
    kActorAnimationDisplayOnActor,
    kActorAnimationDisplayBelowActor,

    kActorAnimationDisplay = -1
  };




  //Movement
  enum eActorMovementOriginType {
    kActorMovementOriginSourceActorLocation = 1,
    kActorMovementOriginSourceActorAttackAnchor,
    kActorMovementOriginScreenCenter,

    kActorMovementOrigin = -1
  };
  enum eActorMovementType {
    kActorMovementNone = 1,
    kActorMovementTagActor,
    kActorMovementLine,
    kActorMovementHoming,
    kActorMovementCycleActor,

    kActorMovement = -1
  };




  //Actor Type
  enum eActorFactionType {
    kActorFactionUserSupport  = 1 << 0,    //where user are
    kActorFactionUserOppose   = 1 << 1,   //who attacks user
    kActorFactionNeutral      = (1 << 0) + (1 << 1), //usually for some special actor that doesn't attack, or attack both
    kActorFaction             = -1
  };
  enum eActorAppearanceType {
    kActorAppearanceCharacter = 1,
    kActorAppearanceEnemyPawn,
    kActorAppearanceEnemyBoss,
    kActorAppearance = -1
  };
  enum eActorCareerType {
    kActorCareerWarrior = 1,
    kActorCareerKnight,
    kActorCareerPriest,
    kActorCareerWizard,
    kActorCareerArcher,
    kActorCareer = -1
  };
  enum eActorEnergyType {
    kActorEnergyMana = 1,
    kActorEnergyAnger,
    kActorEnergy = -1,
  };
  enum eActorAttackType {
    kActorAttackMelee   = 1 << 0,
    kActorAttackRanged  = 1 << 1,
    kActorAttackHeal    = 1 << 2,
    kActorAttack = 0
  };
  enum eActorGuardType {
    kActorGuardMelee = 1, //Circle
    kActorGuardRanged, //Rectangle front & same row
    kActorGuard = -1
  };
  enum eActorAutoType {
    kActorAutoNearFirst = 1, //full screen, pick nearest valid
    kActorAutoSameRowFirst, //full screen, pick closest row & nearest valid
    kActorAuto = -1
  };


  

  //priority of control
  //need to keep update in lua
  enum eActorControlPriority {
    kActorControlPriorityMin = 0,

    kActorControlPriorityCheckGuardAuto, //skill check guard(result in auto move to target)

    kActorControlPriorityMoveAuto,

    kActorControlPriorityCheckAttackAuto, //skill check attack(result in auto normal attack)
    kActorControlPriorityCounterAttackAuto, //commit counter attack priority

    kActorControlPriorityAttackNormalAuto,
    kActorControlPriorityAttackNormalManual,
    
    kActorControlPriorityMoveManual,  //user move operation priority

    kActorControlPriorityAttackPowerAuto,
    kActorControlPriorityAttackSpecialAuto,
    kActorControlPriorityAttackSpecialManual,

    kActorControlPriorityIncontrollable,
    kActorControlPriorityBorn,
    kActorControlPriorityDead,  //normally max priority

    kActorControlPriorityMax,

    kActorControlPriority = -1
  };


  enum eActorIncontrollableType {  //the reason why the actor is incontrollable
    kActorIncontrollableBuff = 1,
    kActorIncontrollableSkill,
    kActorIncontrollableScript,
    kActorIncontrollableOther,
    kActorIncontrollable = -1
  };


  enum eActorControlAutoGuardType {
    kActorControlAutoGuardInvalid = -1,
    kActorControlAutoGuardDefault = 1,
    kActorControlAutoGuardPreferY,  //will first respond to enemy with same grid Y
    kActorControlAutoGuard = -1
  };
  enum eActorControlAutoReleaseSkillType {
    kActorControlAutoReleaseSkillInvalid = -1,
    kActorControlAutoReleaseSkillNoPause = 1,
    kActorControlAutoReleaseSkillWithPause,
    kActorControlAutoReleaseSkillWithProbability,
    kActorControlAutoReleaseSkillByAttackCount,
    kActorControlAutoReleaseSkill = -1
  };



  //Damage
  enum eActorDamageAttributeType {
    //basic
    kActorDamageAttributeFactorDamageAdjustRate = 1,
    kActorDamageAttributeFactorCriticalExtendRate = 2,
    kActorDamageAttributeFactorDamageExtendRate = 3,
    //kActorDamageAttributeFactor

    kActorDamageAttributePhysical  = 1 << 8,
    kActorDamageAttributeMagical   = 1 << 9,  //mix of Elemental?
    kActorDamageAttributeCritical  = 1 << 10,

    //modify directly
    kActorDamageAttributeHealth    = 1 << 11,   //Should be Healing, and should have (damage_value < 0)
    kActorDamageAttributeEnergy    = 1 << 12,   //Should be Energy Charging, and should have (damage_value < 0)

    //for calculation
    kActorDamageAttribute = 0,
  };
  enum eActorDamageStatusType {
    kActorDamageStatusCountAddProcessActor = 1,
    kActorDamageStatusCountSubProcessActor,

    kActorDamageStatusIsMissed,
    kActorDamageStatusIsCritical,

    kActorDamageStatusIsSuicide,
    kActorDamageStatusIsHeal,
    
    kActorDamageStatusSourceActorId,
    kActorDamageStatusSourceActorLevel,

    kActorDamageStatusSourceSkillId,
    kActorDamageStatusSourceSkillLevel,
    kActorDamageStatusSourceSkillType,

    kActorDamageStatusSourceBuffId,
    kActorDamageStatusSourceEffectId,

    kActorDamageStatusTargetActorId,

    kActorDamageStatus = -1
  };




  //Logic
  enum eActorBornType {
    kActorBornDefault = 1,  //default
    kActorBornFadeIn,
    kActorBornDropIn,
    kActorBornBounceIn,
    kActorBornExplode,
    kActorBornBeam,

    kActorBorn = -1,
  };
  enum eActorDeadType {
    kActorDeadDefault = 1,  //default
    kActorDeadFadeOut,
    kActorDeadDropOut,
    kActorDeadBounceOut,
    kActorDeadExplode,
    kActorDeadBeam,

    kActorDead = -1,
  };




  //Skill
  enum eActorSkillType {
    kActorSkillNormal   = 1 << 0,
    kActorSkillPower    = 1 << 1,
    kActorSkillSpecial  = 1 << 2,
    kActorSkillBornWith = 1 << 3, //auto release at born
    kActorSkillOverload = 1 << 4,
    kActorSkill = 0
  };

  class ActorSkillInfo {
  public:
    ActorSkillInfo()
      : skill_id(ACTOR_INVALID_ID)
      , skill_type(kActorSkill)
      , skill_level(0)
      , skill_damage_scale(0.0f)
      , skill_energy_cost(0.0f)
      , skill_energy_recover(0.0f)
      , skill_cooldown(0.0f)
      , skill_cooldown_current(0.0f)
    {}

    ActorSkillInfo(const ActorSkillInfo& source)
      : skill_id(source.skill_id)
      , skill_type(source.skill_type)
      , skill_level(source.skill_level)
      , skill_damage_scale(source.skill_damage_scale)
      , skill_energy_cost(source.skill_energy_cost)
      , skill_energy_recover(source.skill_energy_recover)
      , skill_cooldown(source.skill_cooldown)
      , skill_cooldown_current(source.skill_cooldown_current)
    {}

  public:
    int skill_id;
    eActorSkillType skill_type;

    int skill_level;
    float skill_damage_scale;

    float skill_energy_cost;
    float skill_energy_recover;

    float skill_cooldown; //value to reset to
    float skill_cooldown_current; //current cooldown
  };




  //Buff
  enum eActorBuffStatusStateType { 
    kActorBuffStatusStateAdd = 1,
    kActorBuffStatusStateSub,
    kActorBuffStatusStateImmuneAdd,
    kActorBuffStatusStateImmuneSub,

    kActorBuffStatusState = -1
  };
  enum eActorBuffStatusType { //each status represents on, off, immune
    kActorBuffStatusDebug = 1,
    //kActorBuffStatusAll, //Multi-Status

    //kActorBuffStatusElementAll, //Multi-Status
    kActorBuffStatusElementFire,
    kActorBuffStatusElementWater,
    kActorBuffStatusElementWind,
    kActorBuffStatusElementLight,
    kActorBuffStatusElementDark,

    kActorBuffStatusAutoMove,
    kActorBuffStatusMuteMove,

    //kActorBuffStatusMuteAttack, //Multi-Status
    kActorBuffStatusMuteAttackNormal,
    kActorBuffStatusMuteAttackPower,
    kActorBuffStatusMuteAttackSpecial,

    //kActorBuffStatusMuteReceiveDamageAll, //Multi-Status
    kActorBuffStatusMuteReceiveDamagePhysical,
    kActorBuffStatusMuteReceiveDamageMagical,

    kActorBuffStatusStiff, //Apply BuffId: 1
    
    kActorBuffStatusBlind,
    kActorBuffStatusFear,
    kActorBuffStatusFreeze,
    kActorBuffStatusInvisible,
    kActorBuffStatusPetrify,
    kActorBuffStatusSlience,
    kActorBuffStatusStun,
    kActorBuffStatusCharmed,
    kActorBuffStatusInterwine,

    kActorBuffStatusMax,

    kActorBuffStatus = -1
  };
  typedef std::bitset<kActorBuffStatusMax> ActorBuffStatusBitSet;


  //ABOVE WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //ABOVE WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //ABOVE WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]




  //Actor Signal(Event)
  enum eActorEventType {
    kActorEventActorBorn = 1,
    kActorEventActorDead,
    kActorEventActorKill,

    kActorEventDamageGenerate,
    kActorEventDamageReceive,

    kActorEvent = -1
  };
  enum eActorEventDataType {
    kActorEventDataAttribute = 1,
    kActorEventDataStatus,

    kActorEventDataActor,
    kActorEventDataDamagePackage,

    kActorEventData = -1
  };

  class Actor;
  class DamagePackage;

  class ActorEventData
  {
  public:
    ActorEventData()
      : data_type(kActorEventData)
    {}

    ActorEventData(Actor* actor)
      : data_type(kActorEventDataActor)
    {
      data_value.actor = actor;
    }

    ActorEventData(DamagePackage* damage_package)
      : data_type(kActorEventDataDamagePackage)
    {
      data_value.damage_package = damage_package;
    }

  public:
    eActorEventDataType data_type;
    union {
      float attribute;
      int status;

      Actor* actor;
      DamagePackage* damage_package;
    } data_value;
  };



  //Actor EmitId
  enum eActorEmitType {
    kActorEmitEffectTimeline = 1,
    kActorEmitBuff,

    kActorEmit = -1
  };

  class EmitIdData
  {
  public:
    EmitIdData()
      : id(ACTOR_INVALID_ID)
      , type(kActorEmit)
      , fail_chance(0.0f)
    {}

    int id;
    eActorEmitType type;
    float fail_chance;
  };


} // namespace actor


#endif // ACTOR_DATA_TYPEDEF_H