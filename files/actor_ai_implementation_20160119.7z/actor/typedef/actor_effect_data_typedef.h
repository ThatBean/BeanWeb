#ifndef ACTOR_EFFECT_DATA_TYPEDEF_H
#define ACTOR_EFFECT_DATA_TYPEDEF_H

#include "actor_data_typedef.h"

#include <string>

namespace actor {

  //EffectConfig
  enum eActorEffectConfigTriggerRangeType {
    kActorEffectConfigTriggerRangeAll = 1,
    kActorEffectConfigTriggerRangeCircle,
    kActorEffectConfigTriggerRangeRectangle,

    kActorEffectConfigTriggerRange = -1
  };


  
  //EffectTimeline
  enum eActorEffectTimelineDirectionReferenceType {
    kActorEffectTimelineDirectionReferenceFixRight = 1,
    kActorEffectTimelineDirectionReferenceActorFront,

    kActorEffectTimelineDirectionReference = -1
  };

  enum eEffectTimelineMovementDataType {
    kEffectTimelineMovementDataPositionRandom = 1,
    kEffectTimelineMovementDataHoming,
    kEffectTimelineMovementDataCycle,

    kEffectTimelineMovementData = -1
  };

  class EffectTimelineAnimationData
  {
  public:
    EffectTimelineAnimationData()
      : id(ACTOR_INVALID_ID)
      , animation_type(kActorAnimation)
      , layer_type(kActorAnimationLayer)
    {}

    int id;
    std::string name;
    eActorAnimationType animation_type;
    eActorAnimationLayerType layer_type;
  };

} // namespace actor

#endif // ACTOR_EFFECT_DATA_TYPEDEF_H