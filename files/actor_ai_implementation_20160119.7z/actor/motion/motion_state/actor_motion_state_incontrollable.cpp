#include "actor_motion_state_incontrollable.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_animation_data_typedef.h"

namespace actor {

  const int MotionStateIncontrollable::STATE_TYPE = kActorMotionStateIncontrollable;

  MotionStateIncontrollable* MotionStateIncontrollable::Instance()
  {
    static MotionStateIncontrollable instance;
    return &instance;
  }

  void MotionStateIncontrollable::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateIncontrollable][OnExit]");
    //should assist buff system to adjust actor animation
    switch (actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationTypeIncontrollable))
    {
    case kActorIncontrollableBuff:
      {
        ActorBuffStatusBitSet status_bit_set = actor->GetActorData()->GetBuffData()->GetBuffStatusBitFlag();

        if (status_bit_set[kActorBuffStatusStiff])
        {
          //actor->GetAnimation()->ChangeMovement(kActorAnimationMovementDead);
          actor->GetAnimation()->ChangeMovement(kActorAnimationMovementStiff);  //not yet
        }
        else
        {
          actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
        }
      }
      break;
    case kActorIncontrollableSkill:
      //should check
      actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
      break;
    case kActorIncontrollableScript:
      //for future?
      actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
      break;
    case kActorIncontrollable:
    default:
      actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
      break;
    }

    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);
  }

  void MotionStateIncontrollable::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateIncontrollable][OnExit]");
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false); //for Force Exit
  }

  void MotionStateIncontrollable::Update(Actor* actor, float delta_time)
  {
    //Give Motion control to Buff system
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusBuffIsIncontrollable) == false)
    {
      //back to idle
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
    }
  }

} // namespace actor