#include "actor_motion_state_born.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_animation_data_typedef.h"

namespace actor {

  const int MotionStateBorn::STATE_TYPE = kActorMotionStateBorn;

  MotionStateBorn* MotionStateBorn::Instance()
  {
    static MotionStateBorn instance;
    return &instance;
  }


  void MotionStateBorn::OnEnter(Actor* actor)
  {
    actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);

    //reset CD
    actor->GetActorData()->GetControlData()->SetCountdown(0.5f);

  }

  void MotionStateBorn::OnExit(Actor* actor)
  {
    //reset CD
    actor->GetActorData()->GetControlData()->SetCountdown(0.0f);
  }

  void MotionStateBorn::Update(Actor* actor, float delta_time)
  {
    if (actor->GetActorData()->GetControlData()->GetCountdown() <= 0)
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
  }

} // namespace actor