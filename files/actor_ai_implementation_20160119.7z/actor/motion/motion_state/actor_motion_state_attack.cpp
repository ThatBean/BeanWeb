#include "actor_motion_state_attack.h"

#include "game/actor/actor.h"
#include "game/actor/skill/actor_skill.h"
#include "game/actor/trigger/actor_trigger.h"

namespace actor {

  const int MotionStateAttack::STATE_TYPE = kActorMotionStateAttack;

  MotionStateAttack* MotionStateAttack::Instance()
  {
    static MotionStateAttack instance;
    return &instance;
  }

  void MotionStateAttack::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateAttack][OnEnter]");
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);
  }

  void MotionStateAttack::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateAttack][OnExit]");

    //check exit data state
    if (actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId) != ACTOR_INVALID_ID
      || actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) != false
      || actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) != false)
    {
      actor->GetActorData()->GetLog()->AddErrorLogF("[MotionStateAttack][OnExit] abnormal skill exit: skill_id:%d, motion_is_busy:%s, skill_is_busy:%s", 
        actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId), 
        actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) ? "true" : "false");
    }

    actor->GetSkill()->EndSkill(); //end skill again, for safe?

    actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false); //for Force Exit

  }

  void MotionStateAttack::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[MotionStateAttack][Update]");

    //check strange idle(no operation, no skill playing)
    if ((actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdSkillAttack) == false 
      && actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationTypeSkillAttack) == false)
      || actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][Update] skill:%s motion_busy:%s skill_busy:%s",
        actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdSkillAttack) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) ? "true" : "false");
      //reset for state exit
      actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
      return;
    }

    //get current skill id
    int skill_id = ACTOR_INVALID_ID;
    if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdSkillAttack))
      skill_id = actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationIdSkillAttack);
    else if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationTypeSkillAttack))
      skill_id = actor->GetActorData()->GetSkillData()->GetSkillIdByType((eActorSkillType)actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationTypeSkillAttack));
    else
    {
      actor->GetActorData()->GetLog()->AddErrorLogF("[MotionStateAttack][Update] <!> skill_id not found in ControlData!");

      assert(false);

      actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
      return;
    }

    //check skill change during skill releasing(rare but true)
    if (actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId) == skill_id)
    {
      //check if current skill finished
      if (actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) == false)
      {
        //current skill normally finished
        actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][Update][SkillFinish] skill_id:%d", skill_id);

        //recover energy, reset cooldown
        ActorSkillInfo* skill_info = actor->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);
        if (skill_info)
        {
          actor->GetActorData()->AddActorAttribute(kActorAttributeEnergyCurrent, skill_info->skill_energy_recover);
          skill_info->skill_cooldown_current = skill_info->skill_cooldown;
        }

        actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
        actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
        return;
      }
      else
      {
        //same, waiting for skill animation(check skill)

        //keep skill_cooldown_current to skill_cooldown
        ActorSkillInfo* skill_info = actor->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);
        if (skill_info) 
        {
          skill_info->skill_cooldown_current = skill_info->skill_cooldown;
        }
      }
    }
    else
    {
      //skill set/changed, start/restart skill
      if (actor->GetActorData()->GetSkillData()->IsSkillValid(skill_id)) //check skill cooldown/energy
      {
        actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][Update][SkillStart] <!> skill_id:%d", skill_id);

        //change actor facing, increase skill hit chance
        CheckEnemyForBetterDirection(actor);

        //for melee target
        int pre_selected_target_actor_id = actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdTargetAttack)
          ? actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationIdTargetAttack) : ACTOR_INVALID_ID;

        //set skill
        actor->GetActorData()->GetSkillData()->CommitSkill(skill_id, pre_selected_target_actor_id);

        //record current skill
        actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, skill_id);

        //check skill release successful, should be set in skill 
        if (actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) == false)// actor->GetActorData()->SetActorStatusBool(kActorStatusSkillIsBusy, true);
        {
          actor->GetActorData()->GetLog()->AddErrorLogF("[MotionStateAttack][Update][SkillStart] <!> failed to start skill: %d", skill_id);
        }
        else
        {
          //cost energy, reset cool down
          ActorSkillInfo* skill_info = actor->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);
          if (skill_info)
          {
            actor->GetActorData()->AddActorAttribute(kActorAttributeEnergyCurrent, skill_info->skill_energy_cost);
            skill_info->skill_cooldown_current = skill_info->skill_cooldown;
          }
        }
      }
      else
      {
        //invalid skill
        actor->GetActorData()->GetLog()->AddErrorLogF("[MotionStateAttack][Update] <!> invalid skill to release! skill_id: %d", skill_id);

        assert(false);

        actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
        actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
        return;
      }
    }
  }





  //if all the enemy is behind the actor, change the direction.
  void MotionStateAttack::CheckEnemyForBetterDirection(Actor* actor)
  {
    ActorControlData* control_data = actor->GetActorData()->GetControlData();

    float actor_position_x = actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
    bool is_actor_facing_left = (actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionLeft);
    bool is_need_change_direction = false;


    if (control_data->CheckOperationData(kActorControlOperationIdTargetAttack))
    {
      //check for preset target attack, only check this target
      Actor* target_actor = actor->GetActorExtEnv()->GetActorById(control_data->GetIdOperationData(kActorControlOperationIdTargetAttack));
      if (target_actor && target_actor->GetIsActorAlive())
      {
        bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
        //if the enemy is in front of the actor, don't change the direction (0 | 1 | 0 = false)
        is_need_change_direction = !(is_actor_facing_left == is_enemy_at_left_side);
      }
    }
    else
    {
      //check for special skill, need check all enemy
      std::list<Actor*>* actor_list = actor->GetActorExtEnv()->GetActorList();
      if (!actor_list || actor_list->size() == 0) return;

      is_need_change_direction = true;
      bool is_enemy_exist = false;

      int actor_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction);

      std::list<Actor*>::iterator iterator = actor_list->begin();
      while (iterator != actor_list->end())
      {
        Actor* target_actor = *iterator;

        if (target_actor->GetActorData()->GetActorStatus(kActorStatusFaction) != actor_faction)
        {
          bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
          //if there is one enemy in front of the actor, don't change the direction (1 & 0 & 1 = false)
          is_need_change_direction &= !(is_actor_facing_left == is_enemy_at_left_side);
          is_enemy_exist = true;
        }
        ++iterator;
      }

      delete actor_list;

      //or no enemy at all
      is_need_change_direction &= is_enemy_exist;
    }


    if (is_need_change_direction)
    {
      actor->GetActorData()->GetLog()->AddLogF("[CheckEnemyForBetterDirection] change direction, is_change_to_right:%d", is_actor_facing_left);
      actor->GetActorData()->SetActorStatus(kActorStatusAnimationDirection, is_actor_facing_left ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);
    }
  }
} // namespace actor