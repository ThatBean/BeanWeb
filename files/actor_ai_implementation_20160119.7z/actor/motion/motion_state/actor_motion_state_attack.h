#ifndef ACTOR_MOTION_STATE_ATTACK_H
#define ACTOR_MOTION_STATE_ATTACK_H

#include "game/actor/motion/actor_motion_state.h"


namespace actor {

  class MotionStateAttack : public MotionState
  {
  public:
    virtual ~MotionStateAttack() {}
    static MotionStateAttack* Instance();
    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);

    void InitSkill(Actor* actor); //pass skill info to skill system
    void CheckEnemyForBetterDirection(Actor* actor);  //change actor facing, increase skill hit chance
  private:
    MotionStateAttack() {}
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_ATTACK_H
