#include "actor_motion_state_dead.h"

#include "game/actor/actor.h"
#include "game/actor/animation/actor_animation.h"
#include "game/actor/animation/actor_animation_skeleton_animation.h"

#include "engine/animation/skeleton_animation.h"

namespace actor {

  const int MotionStateDead::STATE_TYPE = kActorMotionStateDead;

  MotionStateDead* MotionStateDead::Instance()
  {
    static MotionStateDead instance;
    return &instance;
  }


  void MotionStateDead::OnEnter(Actor* actor)
  {
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);

    actor->GetAnimation()->CleanAnimationDead();

    std::string movement_name = actor->GetActorData()->GetBasicData()->DeadAnimationName();

    actor->GetAnimation()->ChangeMovement(movement_name, 1);

    if (actor->GetAnimation()->GetAnimationSkeletonAnimation())
    {
      actor->GetAnimation()->GetActorNode()->runAction(cocos2d::CCFadeOut::create(ACTOR_CONTROL_COUNTDOWN_DEAD));
    }

    //reset CD
    actor->GetActorData()->GetControlData()->SetCountdown(ACTOR_CONTROL_COUNTDOWN_DEAD);
  }

  void MotionStateDead::OnExit(Actor* actor)
  {
    //reset CD
    actor->GetActorData()->GetControlData()->SetCountdown(0.0f);
  }

  void MotionStateDead::Update(Actor* actor, float delta_time)
  {
    if (actor->GetActorData()->GetControlData()->GetCountdown() <= 0)
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
  }

} // namespace actor