#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "game/actor/template_class/actor_signal_hub.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;
  class ActorControlData;
  class ActorSkillData;

  typedef std::string (*ActorDebugInfoFunction)(Actor* actor, const std::string& pre_text);

  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

  //CPP
  public:
    void Init();
    void Clear();

    void Update(float delta_time);

    //for data signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);

  private:
    Actor*  actor_;  //keep actor pointer
    float   cached_delta_time_;
    float   update_min_delta_time_;

  //LUA
  //actor_based
  //actor_based
  public: 
    void ActorDataSignalConnect(int data_class_type, int actor_data_type);
    void ActorDataSignalDisconnect(int data_class_type, int actor_data_type);
  private:
    std::map<int, std::map<int, ActorSignalConnection > > lua_signal_connection_map_;

  public: 
    //direct access to ActorAttributeData
    bool  CheckActorAttribute(int data_key);
    void  ResetActorAttribute(int data_key);
    void  InitActorAttribute(int data_key, float base = 0, float add = 0, float multiplier = 1, float extra = 0);
    void  SetActorAttribute(int data_key, float add = 0, float multiplier = 1, float extra = 0);
    void  AddActorAttribute(int data_key, float add = 0, float multiplier = 0, float extra = 0);
    float GetActorAttribute(int data_key);

    //direct access to ActorStatusData
    bool  CheckActorStatus(int data_key);
    void  ResetActorStatus(int data_key);
    void  InitActorStatus(int data_key, int status);
    void  SetActorStatus(int data_key, int status);
    int   GetActorStatus(int data_key);
    void  InitActorStatusBool(int data_key, bool bool_status);
    void  SetActorStatusBool(int data_key, bool bool_status);
    bool  GetActorStatusBool(int data_key);

    //direct access to ActorPositionData
    bool  CheckActorPosition(int data_key);
    void  ResetActorPosition(int data_key);
    void  InitActorPosition(int data_key, cocos2d::CCPoint position);
    void  SetActorPosition(int data_key, cocos2d::CCPoint position);
    cocos2d::CCPoint&   GetActorPosition(int data_key);

    //special operation
    ActorControlData* GetActorControlData();
    ActorSkillData* GetActorSkillData();

    void UpdateSpecialGuard(int type);

    void ShowActorLog(int max_line);

  public:
    void AddDebugText(const std::string& debug_text_string);  //set text from lua
    std::string GetDebugText(int max_line); //for actor animation to display
  private:
    std::list<std::string> debug_text_string_list_;

  public:
    void ShowActorDebugInfo(const std::string& debug_info_type);
    void RegisterActorDebugInfoFunction(const std::string& debug_info_type, ActorDebugInfoFunction debug_info_function);
  private:
    std::map<std::string, ActorDebugInfoFunction> actor_debug_info_function_map_;


  //static method
  //static method
  public: //global
    static void SetIsAutoControl(bool is_auto_control) { is_auto_control_ = is_auto_control; }
    static bool GetIsAutoControl() { return is_auto_control_; }
  private:
    static bool is_auto_control_;

  public: //global
    static cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
    static cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
    static int GetGridXFromPositionX(float position_x);
    static int GetGridYFromPositionY(float position_y);


    //for debug
    //for debug
    static void ScriptAssert(bool expression, const std::string& message);


    //danger...
    //danger...
    static void SimulateTouchAt(float x, float y); 
    static void SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id);  //touch_event_id = 0, 1, 2, 3; safer to use CCTOUCHBEGAN etc
    static cocos2d::CCSet* GetTouchSet(float x, float y);  //this will get a modified static touch set in c++
    static bool TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node);

  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H