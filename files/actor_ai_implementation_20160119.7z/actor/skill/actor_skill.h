#ifndef ACTOR_SKILL_H
#define ACTOR_SKILL_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/typedef/actor_link_data_typedef.h"
#include "game/actor/typedef/actor_skill_data_typedef.h"

#include "engine/animation/skeleton_animation.h"

#include "cocos2d.h"

namespace actor {

  class Actor;


  //one skill per actor, or no skill at all, check logic state attack
  //mainly pack data, play actor animation, emit Effect or Buff
  class ActorSkill
  {
  public:
    ActorSkill(Actor* actor_);
    ~ActorSkill();

    void Clear(); //will force end skill

    void Update(float delta_time);

    void StartSkill(int skill_id);  //all skill starts here
    void EndSkill();  //all skill ends here

    void SetIsPause(bool is_pause);

    ActorSkillLinkData& GetSkillLinkData() { return skill_link_data_; }

  private:
    //packed logic by event
    void OnStart();
    void OnMovement();
    void OnHit();
    void OnEnd();

    //animation event
    void AttachActorAnimationEvent();
    void DetachActorAnimationEvent();
    void OnActorAnimationMovementEvent(cocos2d::extension::CCArmature* armature,
      cocos2d::extension::MovementEventType event_type,
      const char* movement_name);
    void OnActorAnimationFrameEvent(cocos2d::extension::CCBone *bone,
      const char* frame_event_name,
      int origin_frame_index,
      int current_frame_index);

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  private:
    Actor* actor_;

    int skill_hit_count_;

    float skill_speed_scale_;

    ActorSkillLinkData skill_link_data_;

    std::list<ActorSkillMovementData> movement_data_list_;
    
    eActorSkillMovementModType movement_mod_type_;
    cocos2d::CCPoint  movement_mod_position_data_;

    taomee::SkeletonAnimation::ActionEventSubscriber  movement_event_connection_;
    taomee::SkeletonAnimation::FrameEventSubscriber   frame_event_connection_;
  };

} // namespace actor


#endif // ACTOR_SKILL_H