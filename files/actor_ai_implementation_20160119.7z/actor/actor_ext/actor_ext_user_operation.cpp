#include "actor_ext_user_operation.h"

#include "actor_ext_grid.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext_env.h"

namespace actor {
  ActorExtUserOperation::ActorExtUserOperation(ActorExtEnv* actor_ext_env)
  {
    actor_ext_env_ = actor_ext_env;
    Clear();
  }


  void ActorExtUserOperation::Clear()
  {
    operation_state_ = kActorExtUserOperation;
    is_operation_from_set_ = false;
    is_operation_to_set_ = false;
  }

  eActorExtUserOperationType ActorExtUserOperation::UpdateTouchStart(cocos2d::CCPoint touch_position)
  {
    //currently touch must start within grid
    if (!IsPositionInGrid(touch_position)) return kActorExtUserOperationCanceled;

    Actor* touched_actor = GetActorByPosition(touch_position, true);

    if (touched_actor)
    {
      SetTouchFromData(touched_actor->GetScriptObjectId(), touch_position);
      operation_state_ = kActorExtUserOperationSelected;
      return operation_state_;
    }

    Clear();
    return kActorExtUserOperationCanceled;
  }

  eActorExtUserOperationType ActorExtUserOperation::UpdateTouchMove(cocos2d::CCPoint touch_position)
  {
    Actor* from_actor = actor_ext_env_->GetActorById(operation_from_actor_id_);
    if (!from_actor || from_actor->GetIsActorAlive() == false)
    {
      Clear(); //actor invalid, cancel touch
      return kActorExtUserOperationCanceled;
    }

    //check actor
    Actor* touched_actor = GetActorByPosition(touch_position, false);
    if (touched_actor && touched_actor != from_actor)   //not the same as "to_actor"
    {
      SetTouchToData(touched_actor->GetScriptObjectId(), touch_position);
      bool is_same_faction = (from_actor->GetActorData()->GetActorStatus(kActorStatusFaction) == touched_actor->GetActorData()->GetActorStatus(kActorStatusFaction));
      if (is_same_faction)
        operation_state_ = kActorExtUserOperationSwitch;
      else
        operation_state_ = kActorExtUserOperationAttack;
      return operation_state_;
    }

    //check position
    if (from_actor->GetActorData()->GetSpecifiedData()->IsGridValid(GetGridFromPosition(touch_position))) //actor to valid moving position
    {
      SetTouchToData(ACTOR_INVALID_ID, from_actor->GetActorData()->GetSpecifiedData()->PositionCorrection(touch_position));
      operation_state_ = kActorExtUserOperationMove;
      return operation_state_;
    }

    // maybe move or still attack/switch
    return kActorExtUserOperationSkip;
  }

  eActorExtUserOperationType ActorExtUserOperation::UpdateTouchEnd()
  {
    Actor* from_actor = actor_ext_env_->GetActorById(operation_from_actor_id_);
    if (!from_actor)
    {
      Clear();
      return kActorExtUserOperationCanceled;
    }
    
    switch (operation_state_)
    {
    case kActorExtUserOperationAttack:
      from_actor->GetActorData()->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveManual, operation_to_actor_id_);
      break;
    case kActorExtUserOperationMove:
      from_actor->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveManual, operation_to_position_);
      break;
    case kActorExtUserOperationSwitch:
      {
        Actor* to_actor = actor_ext_env_->GetActorById(operation_to_actor_id_);
        if (!to_actor)
        {
          Clear();
          return kActorExtUserOperationCanceled;
        }
        from_actor->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveManual, to_actor->GetActorData()->GetActorPosition(kActorPositionAnimation));
        to_actor->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveManual, from_actor->GetActorData()->GetActorPosition(kActorPositionAnimation));
      }
      break;
    default:
      assert(false);
      break;
    }

    Clear();
    return kActorExtUserOperationFinished;
  }


  void ActorExtUserOperation::SetTouchFromData(int actor_id, cocos2d::CCPoint position)
  {
    is_operation_from_set_ = true;
    operation_from_actor_id_ = actor_id;
    operation_from_position_ = position;

    //in case
    operation_to_actor_id_ = ACTOR_INVALID_ID;
    operation_to_position_ = position;
  }

  void ActorExtUserOperation::SetTouchToData(int actor_id, cocos2d::CCPoint position)
  {
    is_operation_to_set_ = true;
    operation_to_actor_id_ = actor_id;
    operation_to_position_ = position;
  }

  Actor* ActorExtUserOperation::GetActorByPosition(cocos2d::CCPoint touch_position, bool is_check_manual_control)
  {
    //currently touch must start within grid
    if (!IsPositionInGrid(touch_position)) return NULL;

    cocos2d::CCPoint touch_grid_position = GetGridFromPosition(touch_position);
    std::list<Actor*>* actor_list = actor_ext_env_->GetActorExtGrid()->GetActorListAtPosition(touch_position);
    std::list<Actor*>* actor_list_extend = actor_ext_env_->GetActorExtGrid()->GetActorListAtGrid(touch_grid_position);

    actor_list->splice(actor_list->end(), *actor_list_extend);

    float touch_distance_min = 9999999;
    Actor* touched_actor = NULL;

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* in_grid_actor = *iterator;
      if (in_grid_actor && in_grid_actor->GetIsActorAlive()
        && (is_check_manual_control == false || in_grid_actor->GetActorData()->GetActorStatusBool(kActorStatusControlIsManual))
        && in_grid_actor->GetActorData()->GetActorStatusBool(kActorStatusIsDisableUserOperation) == false)  //accept manual control, use to mute ally switch
      {
        float in_grid_distance = touch_position.getDistance(in_grid_actor->GetActorData()->GetActorPosition(kActorPositionAnimation));
        if (touch_distance_min > in_grid_distance)
        {
          touch_distance_min = in_grid_distance;
          touched_actor = in_grid_actor;
        }
      }

      ++iterator;
    }

    delete actor_list_extend;
    delete actor_list;

    return touched_actor;
  }
} // namespace actor