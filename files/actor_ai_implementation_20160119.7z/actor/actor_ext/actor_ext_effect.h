#ifndef ACTOR_EXT_SKILL_EFFECT_H
#define ACTOR_EXT_SKILL_EFFECT_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/typedef/actor_link_data_typedef.h"

#include "engine/base/basictypes.h"


namespace actor {
  class Actor;
  class ActorExtEnv;

  class ActorEffect;
  class ActorEffectTimeline;


  // hold all skill and effect instance
  class ActorExtEffect
  {
  public:
    ActorExtEffect(ActorExtEnv* actor_ext_env);
    ~ActorExtEffect();

    void Clear(); //clear all skill and effect

    void Update(float delta_time);

    ActorEffectTimeline* CreateEffectTimeline(int effect_timeline_key, int effect_timeline_id, const ActorSkillLinkData& skill_link_data);
    void RemoveEffectTimeline(int effect_timeline_key);

    ActorEffect* CreateEffect(ActorEffectLinkData effect_link_data);
    void RemoveEffect(int effect_key);

    ActorExtEnv* GetActorExtEnv() { return actor_ext_env_; }

  private:
    std::map<int, ActorEffectTimeline*> effect_timeline_map_;

    std::map<int, ActorEffect*> effect_map_;

    ActorExtEnv* actor_ext_env_;
  };

} // namespace actor


#endif // ACTOR_EXT_SKILL_EFFECT_H