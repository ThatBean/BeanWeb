#include "ext_effect_timeline.h"

#include "ext_effect.h"

#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/effect_timeline_data_table.h"
#include "game/data_table/effect_config_data_table.h"

#include "game/battle/battle_controller.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/battle_constants.h"


#include "engine/animation/projectile_animation.h"

#include "engine/geometry/geometry_const.h"
#include "engine/base/game_math.h"
#include "engine/base/random_helper.h"

#include "engine/sound/sound_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

#include <algorithm>

/*
  Actor Effect
    Effect is Animation + Movement + Trigger + Data, or what a Skill will create.
    All component is optional, thus a Animation only or Data only Effect can be created

    Life Span:
      Init: 
        need: effect_id 
        optional: source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update: 
        play animation, check trigger

      OnTrigger: 
        (may or may not), triggered, apply carried Data to one or more Actor, may result in a Buff

      Clear: 
        self removal, when hit, time out, or forced to stop(from skill maybe)
*/



namespace actor {


  //limit to [-PI, +PI]
  inline float get_min_rotation(float radian)
  {
    int tquot = std::floor( (radian + PI) / (2 * PI) );
    return radian - tquot * (2 * PI);
  }


  int __decide_homing_actor_id(const std::list<std::string>& movement_data, Actor* actor, const cocos2d::CCPoint& origin_position);

  void __effect_movement_init(
    ActorEffectTimelineUpdateData& effect_timeline_update_data, 
    int movement_type, 
    Actor* actor, 
    cocos2d::CCPoint& origin_position, 
    cocos2d::CCPoint* overload_speed_vector = NULL);

  void __effect_movement_update(
    ActorEffectTimelineUpdateData& effect_timeline_update_data, 
    int movement_type, 
    Actor* actor, 
    float delta_time);





  //ActorEffectTimeline
  ActorEffectTimeline::ActorEffectTimeline(ActorExtEffect* actor_ext_effect)
    : actor_ext_effect_(actor_ext_effect)
    , effect_timeline_key_(ACTOR_INVALID_ID)
    , effect_timeline_id_(ACTOR_INVALID_ID)
    , time_(0.0f)
  {

  }

  ActorEffectTimeline::~ActorEffectTimeline()
  {
    Clear();
  }

  void ActorEffectTimeline::Clear()
  {
    std::list<ActorEffectTimelineUpdateData>::iterator iterator = item_update_data_list_.begin();
    while (iterator != item_update_data_list_.end())
    {
      ActorEffectTimelineUpdateData &effect_timeline_update_data = *iterator;
      
      DeleteItem(effect_timeline_update_data);

      iterator ++;
    }
    item_update_data_list_.clear();

    effect_timeline_key_ = ACTOR_INVALID_ID;
    effect_timeline_id_ = ACTOR_INVALID_ID;
    time_ = 0.0f;
  }

  void ActorEffectTimeline::Init(int effect_timeline_key, int effect_timeline_id, const ActorSkillLinkData& skill_link_data)
  {
    EffectTimelineData* effect_timeline_data = DataManager::GetInstance().GetEffectTimelineDataTable()->GetEffectTimeline(effect_timeline_id);

    //check valid
    if (!effect_timeline_data)
    {
      CCLog("[ActorEffectTimeline][Init] missing effect timeline id: %d", effect_timeline_id);
      assert(false);
      return;
    }
    //check valid

    Clear();

    effect_timeline_key_ = effect_timeline_key;
    effect_timeline_id_ = effect_timeline_id;
    skill_link_data_ = skill_link_data;

    //loop effect timeline item and save link
    std::list<EffectTimelineItemData> &effect_timeline_item_data_list = effect_timeline_data->GetItemList();
    
    for (std::list<EffectTimelineItemData>::iterator iterator = effect_timeline_item_data_list.begin(); iterator != effect_timeline_item_data_list.end(); iterator ++)
    {
      EffectTimelineItemData &effect_timeline_item_data = *iterator;

      ActorEffectTimelineUpdateData effect_timeline_update_data;
      effect_timeline_update_data.effect_timeline_item_data = &effect_timeline_item_data;

      item_update_data_list_.push_back(effect_timeline_update_data);
    }
  }
  
  bool ActorEffectTimeline::Update(float delta_time)
  {
    time_ += delta_time;

    //loop effect and check time
    std::list<ActorEffectTimelineUpdateData>::iterator iterator = item_update_data_list_.begin();
    while (iterator != item_update_data_list_.end())
    {
      ActorEffectTimelineUpdateData &effect_timeline_update_data = *iterator;

      if (effect_timeline_update_data.is_deletable)
      {
        DeleteItem(effect_timeline_update_data);
        iterator = item_update_data_list_.erase(iterator);
      }
      else 
      {
        if (effect_timeline_update_data.is_updatable)
        {
          if (time_ >= effect_timeline_update_data.effect_timeline_item_data->GetDelay() + effect_timeline_update_data.effect_timeline_item_data->GetDuration())
          {
            effect_timeline_update_data.is_deletable = true;  //time out
          }
          else
          {
            UpdateItem(effect_timeline_update_data, delta_time);
          }
        }
        else if (time_ >= effect_timeline_update_data.effect_timeline_item_data->GetDelay())
        {
          CreateItem(effect_timeline_update_data);
        }
        else
        {
          //wait the delay
        }

        iterator ++;
      }
    }

    //is_keep
    return item_update_data_list_.empty() == false;
  }




  void ActorEffectTimeline::CreateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;
    EffectTimelineAnimationData &effect_animation_data = effect_timeline_item_data->GetEffectAnimationData();

    //collect data
    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(skill_link_data_.actor_id);

    //NOTE: all animation currently made consider LEFT(x-) as default direction, so in this x+ system, it's already 180deg rotated
    bool is_animation_filp_x = (effect_timeline_item_data->GetDirectionReference() == kActorEffectTimelineDirectionReferenceActorFront
      && actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight);

    //create effect node
    switch (effect_animation_data.animation_type)
    {
    case kActorAnimationEffectId:
      {
        ActorEffectLinkData actor_effect_link_data;
        actor_effect_link_data.effect_key = ACTOR_INVALID_ID; // auto decide
        actor_effect_link_data.effect_id = effect_animation_data.id;

        actor_effect_link_data.effect_timeline_id = effect_timeline_id_;
        actor_effect_link_data.effect_timeline_item_index = effect_timeline_update_data.effect_timeline_item_data->GetId();

        actor_effect_link_data.skill_link_data = skill_link_data_;
        
        //create effect
        effect_timeline_update_data.actor_effect = actor_ext_effect_->CreateEffect(actor_effect_link_data);

        effect_timeline_update_data.effect_node = effect_timeline_update_data.actor_effect->GetAnimation()->GetActorNode();

        effect_timeline_update_data.effect_node->setRotation(effect_timeline_item_data->GetDirection());
        if (is_animation_filp_x) effect_timeline_update_data.effect_node->setRotationY(180);
      }
      break;
    case kActorAnimationArmatureName:
      {
        std::string armature_name = effect_animation_data.name;
        std::string movement_name = "bsj";

        CCArmature* armature_animation = CCArmature::create();

        if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
        {
          std::string skeleton_config = taomee::kDefaultSkeletonFilePath+armature_name+".xml";
          std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+armature_name+".plist";
          std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+armature_name+".pvr.ccz";
          CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
        }
        armature_animation->init(armature_name.c_str());
        armature_animation->getAnimation()->play(movement_name.c_str(), 0, -1, 0);

        armature_animation->setRotation(effect_timeline_item_data->GetDirection());
        if (is_animation_filp_x) armature_animation->setRotationY(180);

        effect_timeline_update_data.animation_armature = armature_animation;
        effect_timeline_update_data.effect_node = armature_animation;
      }
      break;
    case kActorAnimationProjectileName:
      {
        std::string projectile_name = effect_animation_data.name;

        taomee::ProjectileAnimation* projectile_animation = new taomee::ProjectileAnimation();
        projectile_animation->initWithName(projectile_name.c_str());
        projectile_animation->setPositionType(kCCPositionTypeRelative);
        //projectile_animation->release();

        projectile_animation->setFlipX(is_animation_filp_x);
        projectile_animation->setRotation(effect_timeline_item_data->GetDirection());

        effect_timeline_update_data.animation_projectile = projectile_animation;
        effect_timeline_update_data.effect_node = projectile_animation;
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }


    if (effect_timeline_update_data.effect_node)
    {
      InitMovement(effect_timeline_update_data);

      //add to view
      switch (effect_animation_data.layer_type)
      {
      case kActorAnimationLayerTop:
        taomee::battle::BattleController::GetInstance().AddNodeByLayerType(effect_timeline_update_data.effect_node, taomee::battle::kBattleLayerTop);
        break;
      case kActorAnimationLayerActor:
        taomee::battle::BattleController::GetInstance().AddNodeByLayerType(effect_timeline_update_data.effect_node, taomee::battle::kBattleLayerMiddle);
        break;
      case kActorAnimationLayerBottom:
        taomee::battle::BattleController::GetInstance().AddNodeByLayerType(effect_timeline_update_data.effect_node, taomee::battle::kBattleLayerBottom);
        break;
      default:
        effect_timeline_update_data.is_deletable = true;
        assert(false);
        break;
      }
    }

    
    if (effect_timeline_update_data.effect_timeline_item_data->GetSoundEffectId() > 0)
    {
      //sound effect
      SoundManager::GetInstance().PlayEffect(effect_timeline_update_data.effect_timeline_item_data->GetSoundEffectId(), false);
    }

    effect_timeline_update_data.is_updatable = true;
  }

  void ActorEffectTimeline::UpdateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;
    EffectTimelineAnimationData &effect_animation_data = effect_timeline_item_data->GetEffectAnimationData();

    UpdateMovement(effect_timeline_update_data, delta_time);


    //create effect node
    switch (effect_animation_data.animation_type)
    {
    case kActorAnimationEffectId:
      {
        if (effect_timeline_update_data.actor_effect->GetScriptObjectIsActive() == false)
        {
          effect_timeline_update_data.is_deletable = true;
        }
      }
      break;
    case kActorAnimationArmatureName:
    case kActorAnimationProjectileName:
      {
        //pass
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }
  }

  void ActorEffectTimeline::DeleteItem(ActorEffectTimelineUpdateData& effect_timeline_update_data)
  {
    if (effect_timeline_update_data.animation_armature)
    {
      effect_timeline_update_data.animation_armature->removeFromParentAndCleanup(true);
    }

    if (effect_timeline_update_data.animation_projectile)
    {
      effect_timeline_update_data.animation_projectile->release();
      effect_timeline_update_data.animation_projectile->removeFromParentAndCleanup(true);
    }

    if (effect_timeline_update_data.actor_effect)
    {
      actor_ext_effect_->RemoveEffect(effect_timeline_update_data.actor_effect->GetEffectLinkData().effect_key);
    }

    effect_timeline_update_data.animation_armature = NULL;
    effect_timeline_update_data.animation_projectile = NULL;
    effect_timeline_update_data.actor_effect = NULL;
    effect_timeline_update_data.effect_node = NULL;
    effect_timeline_update_data.effect_timeline_item_data = NULL;
  }





  void ActorEffectTimeline::InitMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;

    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(skill_link_data_.actor_id);

    bool is_actor_facing_right = actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight;
    bool is_filp_x = (effect_timeline_item_data->GetDirectionReference() == kActorEffectTimelineDirectionReferenceActorFront
      && actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionLeft);


    //position
    cocos2d::CCPoint origin_position;
    switch (effect_timeline_item_data->GetMovementOriginType())
    {
    case kActorMovementOriginSourceActorLocation:
      if (actor)
      {
        origin_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      }
      else
      {
        effect_timeline_update_data.is_deletable = true;
        return;
      }
      break;
    case kActorMovementOriginSourceActorAttackAnchor:
      if (actor)
      {
        origin_position = actor->GetAnimation()->GetActorRangeAttackAnchor();
      }
      else
      {
        effect_timeline_update_data.is_deletable = true;
        return;
      }
      break;
    case kActorMovementOriginScreenCenter:
      origin_position = ccp(taomee::battle::BATTLE_DESIGN_SIZE.width * 0.5, taomee::battle::BATTLE_DESIGN_SIZE.height * 0.5);
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }



    origin_position.x += (is_filp_x ? -1 : 1) * effect_timeline_item_data->GetPositionX();
    origin_position.y += effect_timeline_item_data->GetPositionY();

    std::map<eEffectTimelineMovementDataType, std::list<std::string> >*	movement_data = effect_timeline_item_data->GetMovementData();
    if (movement_data && movement_data->find(kEffectTimelineMovementDataPositionRandom) != movement_data->end())
    {
      std::list<std::string>::iterator iterator = movement_data->at(kEffectTimelineMovementDataPositionRandom).begin();
      if ( iterator != movement_data->at(kEffectTimelineMovementDataPositionRandom).end())
      {
        float random_delta_x = String2Float(*iterator);
        iterator ++;
        float random_delta_y = String2Float(*iterator);
        iterator ++;

        if (random_delta_x > 0) origin_position.x += (random_lower_upper(0, random_delta_x) - random_delta_x * 0.5);
        if (random_delta_y > 0) origin_position.y += (random_lower_upper(0, random_delta_y) - random_delta_y * 0.5);
      }
    }

    effect_timeline_update_data.effect_node->setPosition(origin_position);


    //movement_init
    __effect_movement_init(
      effect_timeline_update_data, 
      effect_timeline_item_data->GetMovementType(), 
      actor, 
      origin_position);
  }



  void ActorEffectTimeline::UpdateMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;

    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(skill_link_data_.actor_id);
    

    __effect_movement_update(
      effect_timeline_update_data, 
      effect_timeline_item_data->GetMovementType(), 
      actor,
      delta_time);


    //check out of screen
    float size_scale = 1.5f; 
    CCRect screen_box = CCRect(
      taomee::battle::BATTLE_DESIGN_SIZE.width * 0.5f * (1.0f - size_scale), 
      taomee::battle::BATTLE_DESIGN_SIZE.height * 0.5f * (1.0f - size_scale), 
      taomee::battle::BATTLE_DESIGN_SIZE.width * size_scale, 
      taomee::battle::BATTLE_DESIGN_SIZE.height * size_scale);
    if (screen_box.containsPoint(effect_timeline_update_data.effect_node->getPosition()) == false)
    {
      effect_timeline_update_data.is_deletable = true;
    }
  }

  //ActorEffectTimeline











  




  int __decide_homing_actor_id(const std::list<std::string>& movement_data, Actor* actor, const cocos2d::CCPoint& origin_position)
  {
    if (movement_data.empty() || !actor)
      return ACTOR_INVALID_ID;

    std::list<std::string>::const_iterator iterator = movement_data.begin();

    bool is_ally = (*iterator) == "ally";
    iterator ++;
    int index_in_near_first_list = String2Int(*iterator);
    iterator ++;

    bool is_user_support = actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport;
    eActorFactionType target_faction_type = (is_user_support == is_ally) 
      ? kActorFactionUserSupport
      : kActorFactionUserOppose;

    Actor* target_actor = actor->GetActorExtEnv()->GetActorExtGrid()->QuickGetActorByFactionAndPosition(target_faction_type, origin_position, index_in_near_first_list);

    return target_actor 
      ? target_actor->GetScriptObjectId()
      : ACTOR_INVALID_ID;
  }





  void __effect_movement_init(
    ActorEffectTimelineUpdateData& effect_timeline_update_data, 
    int movement_type, 
    Actor* actor, 
    cocos2d::CCPoint& origin_position, 
    cocos2d::CCPoint* overload_speed_vector/* = NULL*/)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;

    bool is_actor_facing_right = actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight;
    bool is_filp_x = (effect_timeline_item_data->GetDirectionReference() == kActorEffectTimelineDirectionReferenceActorFront
      && actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionLeft);

    switch (movement_type)
    {
    case kActorMovementNone:
      // nothing
      break;
    case kActorMovementTagActor:
      {
        //record delta position
        effect_timeline_update_data.movement_position_data = ccpSub(
          effect_timeline_update_data.effect_node->getPosition(), 
          actor ? actor->GetActorData()->GetActorPosition(kActorPositionAnimation) : CCPointZero);
      }
      break;
    case kActorMovementCycleActor:
      {
        std::map<eEffectTimelineMovementDataType, std::list<std::string> >*	movement_data = effect_timeline_item_data->GetMovementData();
        if (movement_data && movement_data->find(kEffectTimelineMovementDataCycle) != movement_data->end())
        {
          std::list<std::string>::const_iterator iterator = movement_data->at(kEffectTimelineMovementDataCycle).begin();

          effect_timeline_update_data.movement_cycle_time = String2Float(*iterator);
          iterator ++;
          effect_timeline_update_data.movement_cycle_radius = GetGridBoxAverageWidth() * String2Float(*iterator);
          iterator ++;

          effect_timeline_update_data.movement_position_data = ccp(is_actor_facing_right 
            ? effect_timeline_update_data.movement_cycle_radius 
            : -effect_timeline_update_data.movement_cycle_radius, 0);

          //reset origin position
          effect_timeline_update_data.effect_node->setPosition(origin_position + effect_timeline_update_data.movement_position_data);
        }
        else
        {
          assert(movement_data && movement_data->find(kEffectTimelineMovementDataCycle) != movement_data->end());
          effect_timeline_update_data.is_deletable = true;
        }
      }
      break;
    case kActorMovementHoming:
      {
        std::map<eEffectTimelineMovementDataType, std::list<std::string> >*	movement_data = effect_timeline_item_data->GetMovementData();
        if (movement_data && movement_data->find(kEffectTimelineMovementDataHoming) != movement_data->end())
        {
          //get target actor id
          effect_timeline_update_data.movement_homing_target_actor_id = __decide_homing_actor_id(
            movement_data->at(kEffectTimelineMovementDataHoming), 
            actor, 
            origin_position);
        }
        else
        {
          assert(movement_data && movement_data->find(kEffectTimelineMovementDataHoming) != movement_data->end());
          effect_timeline_update_data.is_deletable = true;
        }
      }
      // break;//need line logic for init speed vector
    case kActorMovementLine:
      {
        if (overload_speed_vector)
        {
          effect_timeline_update_data.movement_position_data = *overload_speed_vector;
        }
        else
        {
          //calc speed vector
          //normally: from x+ (0deg), ccw
          //filp_x: from x-(180feg), cw
          float direction_degree = effect_timeline_item_data->GetDirection() * (is_filp_x ? -1 : 1) + (is_filp_x ? 180 : 0);
          float direction_radian = direction_degree * PI / 180.0f;

          effect_timeline_update_data.movement_position_data = ccpForAngle(direction_radian) 
            * (GetGridBoxAverageWidth() * effect_timeline_item_data->GetMovementSpeed());
        }
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }
  }




  void __effect_movement_update(
    ActorEffectTimelineUpdateData& effect_timeline_update_data, 
    int movement_type, 
    Actor* actor, 
    float delta_time)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;

    switch (movement_type)
    {
    case kActorMovementNone:
      // nothing
      break;
    case kActorMovementTagActor:
      effect_timeline_update_data.effect_node->setPosition(
        ccpAdd(
          actor ? actor->GetActorData()->GetActorPosition(kActorPositionAnimation) : CCPointZero, 
          effect_timeline_update_data.movement_position_data));
      break;
    case kActorMovementCycleActor:
      if (effect_timeline_update_data.movement_cycle_time >= 0)
      {
        //cycling
        effect_timeline_update_data.movement_cycle_time -= delta_time;

        float cycle_rotation_radian = effect_timeline_update_data.movement_position_data.getAngle();
        cocos2d::CCPoint actor_center_position = actor ? actor->GetAnimation()->GetActorCenterAnchor() : CCPointZero;

        cycle_rotation_radian += effect_timeline_item_data->GetMovementSpeed() / PI * delta_time;

        effect_timeline_update_data.movement_position_data = ccpForAngle(cycle_rotation_radian)
          * effect_timeline_update_data.movement_cycle_radius;

        effect_timeline_update_data.effect_node->setPosition(ccpAdd(actor_center_position, effect_timeline_update_data.movement_position_data));

        if (effect_timeline_update_data.movement_cycle_time < 0)
        {
          cocos2d::CCPoint overload_speed_vector = ccpForAngle(cycle_rotation_radian + 0.5 * PI) 
            * GetGridBoxAverageWidth() 
            * effect_timeline_item_data->GetMovementSpeed();

          //init for switching to homing
          cocos2d::CCPoint& origin_point = actor_center_position;
          __effect_movement_init(
            effect_timeline_update_data, 
            kActorMovementHoming, 
            actor, 
            origin_point, 
            &overload_speed_vector);
        }
      }
      else
      {
        //homing
        __effect_movement_update(
          effect_timeline_update_data, 
          kActorMovementHoming, 
          actor, 
          delta_time);
      }
      break;
    case kActorMovementLine:
      effect_timeline_update_data.effect_node->setPosition(
        ccpAdd(
          effect_timeline_update_data.effect_node->getPosition(), 
          effect_timeline_update_data.movement_position_data * delta_time));
      break;
    case kActorMovementHoming:
      {
        Actor* target_actor = actor->GetActorExtEnv()->GetActorById(effect_timeline_update_data.movement_homing_target_actor_id);
        if (!target_actor)
        {
          effect_timeline_update_data.is_deletable = true;
        }
        else
        {
          cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
          cocos2d::CCPoint effect_node_position = effect_timeline_update_data.effect_node->getPosition();

          cocos2d::CCPoint movement_vector = ccpSub(target_position, effect_node_position);

          float movement_speed = effect_timeline_update_data.movement_position_data.getLength();
          float target_distance = movement_vector.getLength();

          if (target_distance <= movement_speed * delta_time)
          {
            effect_timeline_update_data.effect_node->setPosition(target_position);  //just arrive
          }
          else
          {
            //rotate and move
            float movement_direction_radian = effect_timeline_update_data.movement_position_data.getAngle();
            float target_direction_radian = movement_vector.getAngle();

            float movement_speed_delta = MIN(target_distance, movement_speed * delta_time);
            float movement_rotation_radian = get_min_rotation(target_direction_radian - movement_direction_radian);

            movement_rotation_radian = (movement_rotation_radian >= 0 ? 1 : -1) 
              * MIN(std::abs(movement_rotation_radian), 0.2 * pow(movement_speed, 0.9f) * (PI / 180.0f) * delta_time);

            cocos2d::CCPoint normalized_vector = ccpForAngle(movement_direction_radian + movement_rotation_radian);

            effect_timeline_update_data.effect_node->setPosition(
              ccpAdd(
                effect_timeline_update_data.effect_node->getPosition(), 
                normalized_vector * movement_speed_delta));

            //true == actor facing left, and we need to change animation for this
            //NOTE: all animation currently made consider LEFT(x-) as default direction, so in this x+ system, it's already 180deg rotated
            effect_timeline_update_data.effect_node->setRotation(180 - R2A(movement_direction_radian + movement_rotation_radian));

            effect_timeline_update_data.movement_position_data = normalized_vector * movement_speed; //record new
          }
        }
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }
  }



} // namespace actor