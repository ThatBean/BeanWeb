#include "actor_ext_effect.h"

#include "game/actor/actor.h"

#include "game/actor/actor_ext/ext_effect/ext_effect.h"
#include "game/actor/actor_ext/ext_effect/ext_effect_timeline.h"

#include "game/data_table/effect_config_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

/*
  Actor Effect
    Effect is Animation + Movement + Trigger + Data, or what a Skill will create.
    All component is optional, thus a Animation only or Data only Effect can be created

    Life Span:
      Init: 
        need: effect_id 
        optional: source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update: 
        play animation, check trigger

      OnTrigger: 
        (may or may not), triggered, apply carried Data to one or more Actor, may result in a Buff

      Clear: 
        self removal, when hit, time out, or forced to stop(from skill maybe)
*/



namespace actor {

  static std::map<int, bool> effect_key_map;
  int RequestEffectKey(int start_from)
  {
    int possible_valid_id = start_from;
    if (start_from == ACTOR_INVALID_ID) possible_valid_id = effect_key_map.size() > 0 ? effect_key_map.rbegin()->first + 1 : 0; //guess best id
    while (effect_key_map.find(possible_valid_id) != effect_key_map.end()) possible_valid_id++; //check valid
    effect_key_map[possible_valid_id] = true;
    return possible_valid_id;
  }
  void ReturnEffectKey(int effect_key)
  {
    effect_key_map.erase(effect_key);
  }


  //ActorExtSkillEffect
  ActorExtEffect::ActorExtEffect(ActorExtEnv* actor_ext_env)
    :actor_ext_env_(actor_ext_env)
  {
    //
  }

  ActorExtEffect::~ActorExtEffect()
  {
    Clear();
  }

  void ActorExtEffect::Clear()
  {
    //remove all effect timeline
    std::map<int, ActorEffectTimeline*>::iterator iterator_effect_timeline = effect_timeline_map_.begin();
    while (iterator_effect_timeline != effect_timeline_map_.end())
    {
      int effect_timeline_key = iterator_effect_timeline->first;

      iterator_effect_timeline ++;

      RemoveEffectTimeline(effect_timeline_key);
    }
    effect_timeline_map_.clear();


    //remove all effect
    std::map<int, ActorEffect*>::iterator iterator_effect = effect_map_.begin();
    while (iterator_effect != effect_map_.end())
    {
      int effect_key = iterator_effect->first;

      iterator_effect ++;

      RemoveEffect(effect_key);
    }
    effect_map_.clear();
  }


  void ActorExtEffect::Update(float delta_time)
  {
    //update all effect timeline
    std::map<int, ActorEffectTimeline*>::iterator iterator_effect_timeline = effect_timeline_map_.begin();
    while (iterator_effect_timeline != effect_timeline_map_.end())
    {
      ActorEffectTimeline* actor_effect_timeline = iterator_effect_timeline->second;

      iterator_effect_timeline ++;

      bool is_keep = actor_effect_timeline->Update(delta_time);

      if (!is_keep)
      {
        RemoveEffectTimeline(actor_effect_timeline->GetEffectTimelineKey());
      }
    }


    //update all effect
    std::map<int, ActorEffect*>::iterator iterator_effect = effect_map_.begin();
    while (iterator_effect != effect_map_.end())
    {
      ActorEffect* actor_effect = iterator_effect->second;

      actor_effect->Update(delta_time);

      iterator_effect ++;
    }
  }



  ActorEffectTimeline* ActorExtEffect::CreateEffectTimeline(int effect_timeline_key, int effect_timeline_id, const ActorSkillLinkData& skill_link_data)
  {
    effect_timeline_key = RequestEffectKey(effect_timeline_key);
    ActorEffectTimeline* actor_effect_timeline = new ActorEffectTimeline(this);
    actor_effect_timeline->Init(effect_timeline_key, effect_timeline_id, skill_link_data);
    effect_timeline_map_[effect_timeline_key] = actor_effect_timeline;
    return actor_effect_timeline;
  }


  void ActorExtEffect::RemoveEffectTimeline(int effect_timeline_key)
  {
    if (effect_timeline_map_.find(effect_timeline_key) != effect_timeline_map_.end())
    {
      ActorEffectTimeline* actor_effect_timeline = effect_timeline_map_[effect_timeline_key];
      actor_effect_timeline->Clear();
      delete actor_effect_timeline;
      effect_timeline_map_.erase(effect_timeline_key);
      ReturnEffectKey(effect_timeline_key);
    }
  }



  ActorEffect* ActorExtEffect::CreateEffect(ActorEffectLinkData effect_link_data)
  {
//     effect_link_data.effect_key = RequestEffectKey(effect_link_data.effect_key);
//     ActorEffect* actor_effect = new ActorEffect(this);
//     actor_effect->Init(effect_link_data);
//     effect_map_[effect_link_data.effect_key] = actor_effect;
//     return actor_effect;

    effect_link_data.effect_key = actor_ext_env_->GetValidId(1000000);  //set an id gap
    ActorEffect* actor_effect = new ActorEffect(this);
    actor_effect->LinkScript(effect_link_data.effect_key, actor_ext_env_);
    actor_effect->Init(effect_link_data);
    effect_map_[effect_link_data.effect_key] = actor_effect;
    return actor_effect;
  }


  void ActorExtEffect::RemoveEffect(int effect_key)
  {
    if (effect_map_.find(effect_key) != effect_map_.end())
    {
//       ActorEffect* actor_effect = effect_map_[effect_key];
//       actor_effect->Clear();
//       delete actor_effect;
//       effect_map_.erase(effect_key);
//       ReturnEffectKey(effect_key);

      ActorEffect* actor_effect = effect_map_[effect_key];
      actor_effect->Clear();
      actor_effect->UnLinkScript();
      delete actor_effect;
      effect_map_.erase(effect_key);
    }
  }

} // namespace actor