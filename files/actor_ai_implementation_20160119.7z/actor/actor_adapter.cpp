#include "actor_adapter.h"

#include "actor.h"
#include "actor_script_exporter.h"
#include "game/actor/control/actor_control.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/motion/actor_motion_state_machine.h"
#include "game/actor/trigger/actor_trigger_predefined.h"
#include "game/actor/animation/actor_animation_skeleton_animation.h"

#include "game/battle/battle_controller.h"
#include "game/battle/battle_constants.h"
#include "game/battle/data/battle_data_center.h"
#include "game/battle/level/levelbase.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "game/battle/view/battle_view.h"
#include "game/battle/view/aim_mark.h"
#include "game/battle/view/battle_damage_label.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/character_data_table.h"
#include "game/data_table/actor_routine_config_data_table.h"

#include "engine/script/lua_data_tunnel.h"

#include "engine/ui_factory/ui_factory.h"
#include "engine/base/random_helper.h"
#include "engine/base/utils_string.h"

#include "game/actor/skill/actor_skill_data_extractor.h"

#define SCRIPT_OBJECT_LUA "script/actor/script_object.lua"

namespace actor
{
  //Search the string for space(the ' ', '\n', '\r', '\t'), and remove it, NOTE: will change source string
  std::string& ActorStringRemoveSpace(std::string& source_string)
  {
    std::string::iterator iterator = source_string.begin();
    while (iterator != source_string.end())
    {
      switch (*iterator)
      {
      case ' ':
      case '\n':
      case '\r':
      case '\t':
        iterator = source_string.erase(iterator);
        break;
      default:
        iterator ++;
        break;
      }
    }

    return source_string;
  }




  //Split the string at characters that matches any of the characters specified in delimiter_string.
  //delimiter can be ",|. " for multi-match split
  std::list<std::string>* ActorStringSplit(const std::string& source_string, const std::string& delimiter)
  {
    std::list<std::string>* result_list = new std::list<std::string>;
    std::string::size_type remain_string_index = 0, delimiter_index = std::string::npos, substr_count = 0;

    do {
      delimiter_index = source_string.find_first_of(delimiter, remain_string_index);
      substr_count = (delimiter_index == std::string::npos ? std::string::npos : delimiter_index - remain_string_index);
      result_list->push_back(source_string.substr(remain_string_index, substr_count));
      remain_string_index = delimiter_index + 1;  //skip delimiter
    } while (delimiter_index != std::string::npos);

    return result_list;
  }  















  //Parse
  //Parse
  eActorAttributeType ParseActorAttributeType(const std::string& source_string)
  {
    std::string attribute_type_string = source_string;

    std::string::size_type found_pos = attribute_type_string.find_first_of("kActorAttribute");

    if (found_pos != std::string::npos)
    {
      attribute_type_string = attribute_type_string.replace(found_pos, strlen("kActorAttribute"), "");
    }

    if (attribute_type_string.empty()) return kActorAttribute;
    else if (attribute_type_string == "TimeActive") return kActorAttributeTimeActive;
    else if (attribute_type_string == "HealthMax") return kActorAttributeHealthMax;
    else if (attribute_type_string == "HealthCurrent") return kActorAttributeHealthCurrent;
    else if (attribute_type_string == "HealthRecover") return kActorAttributeHealthRecover;
    else if (attribute_type_string == "EnergyMax") return kActorAttributeEnergyMax;
    else if (attribute_type_string == "EnergyCurrent") return kActorAttributeEnergyCurrent;
    else if (attribute_type_string == "EnergyRecover") return kActorAttributeEnergyRecover;
    else if (attribute_type_string == "FactorCritical") return kActorAttributeFactorCritical;
    else if (attribute_type_string == "FactorCriticalResist") return kActorAttributeFactorCriticalResist;
    else if (attribute_type_string == "FactorCriticalExtra") return kActorAttributeFactorCriticalExtra;
    else if (attribute_type_string == "FactorHit") return kActorAttributeFactorHit;
    else if (attribute_type_string == "FactorDodge") return kActorAttributeFactorDodge;
    else if (attribute_type_string == "FactorDodgeExtra") return kActorAttributeFactorDodgeExtra;
    else if (attribute_type_string == "FactorDamageAdjust") return kActorAttributeFactorDamageAdjust;
    else if (attribute_type_string == "FactorDamageAdjustResist") return kActorAttributeFactorDamageAdjustResist;
    else if (attribute_type_string == "FactorDamageAdjustExtra") return kActorAttributeFactorDamageAdjustExtra;
    else if (attribute_type_string == "FactorSkillDamage") return kActorAttributeFactorSkillDamage;
    else if (attribute_type_string == "FactorSkillDamageResist") return kActorAttributeFactorSkillDamageResist;
    else if (attribute_type_string == "SpeedAttack") return kActorAttributeSpeedAttack;
    else if (attribute_type_string == "SpeedMove") return kActorAttributeSpeedMove;
    else if (attribute_type_string == "AttackPhysical") return kActorAttributeAttackPhysical;
    else if (attribute_type_string == "AttackMagical") return kActorAttributeAttackMagical;
    else if (attribute_type_string == "AttackCritical") return kActorAttributeAttackCritical;
    else if (attribute_type_string == "DefensePhysical") return kActorAttributeDefensePhysical;
    else if (attribute_type_string == "DefenseMagical") return kActorAttributeDefenseMagical;
    else if (attribute_type_string == "DefenseCritical") return kActorAttributeDefenseCritical;
    else if (attribute_type_string == "TriggerSizeScaleAttack") return kActorAttributeTriggerSizeScaleAttack;
    else if (attribute_type_string == "TriggerSizeScaleGuard") return kActorAttributeTriggerSizeScaleGuard;
    else if (attribute_type_string == "AttackAreaRadius") return kActorAttributeAttackAreaRadius;
    else if (attribute_type_string == "AttackAreaWidth") return kActorAttributeAttackAreaWidth;
    else if (attribute_type_string == "AttackAreaHeight") return kActorAttributeAttackAreaHeight;
    else if (attribute_type_string == "GuardAreaRadius ") return kActorAttributeGuardAreaRadius ;
    else if (attribute_type_string == "GuardAreaWidth ") return kActorAttributeGuardAreaWidth ;
    else if (attribute_type_string == "GuardAreaHeight ") return kActorAttributeGuardAreaHeight ;
    else if (attribute_type_string == "DamageAddition  ") return kActorAttributeDamageAddition  ;
    else if (attribute_type_string == "DamageAdditionPhysical") return kActorAttributeDamageAdditionPhysical;
    else if (attribute_type_string == "DamageAdditionMagical") return kActorAttributeDamageAdditionMagical;
    else if (attribute_type_string == "DamageAdditionCritical") return kActorAttributeDamageAdditionCritical;
    else if (attribute_type_string == "DamageAdditionHealth") return kActorAttributeDamageAdditionHealth;
    else if (attribute_type_string == "DamageAdditionEnergy") return kActorAttributeDamageAdditionEnergy;
    else if (attribute_type_string == "DamageReduction ") return kActorAttributeDamageReduction ;
    else if (attribute_type_string == "DamageReductionPhysical") return kActorAttributeDamageReductionPhysical;
    else if (attribute_type_string == "DamageReductionMagical") return kActorAttributeDamageReductionMagical;
    else if (attribute_type_string == "DamageReductionCritical") return kActorAttributeDamageReductionCritical;
    else if (attribute_type_string == "DamageReductionHealth") return kActorAttributeDamageReductionHealth;
    else if (attribute_type_string == "DamageReductionEnergy") return kActorAttributeDamageReductionEnergy;
    else if (attribute_type_string == "AttackCount") return kActorAttributeAttackCount;
    else if (attribute_type_string == "AttackNormalCount") return kActorAttributeAttackNormalCount;
    else if (attribute_type_string == "AttackPowerCount") return kActorAttributeAttackPowerCount;
    else if (attribute_type_string == "AttackSpecialCount") return kActorAttributeAttackSpecialCount;
    else if (attribute_type_string == "AnimationScale") return kActorAttributeAnimationScale;
    else
    {
      CCLog("[ParseActorAttributeType] error source_string <%s>!", attribute_type_string.c_str());
      assert(false);
      return kActorAttribute;
    }
  }
  eActorStatusType ParseActorStatusType(const std::string& source_string)
  {
    if (source_string.empty()) return kActorStatus;
    else if (source_string == "ActorId") return kActorStatusActorId;
    else if (source_string == "ActorModel") return kActorStatusActorModel;
    else if (source_string == "AnimationModel") return kActorStatusAnimationModel;
    else if (source_string == "CardId") return kActorStatusCardId;
    else if (source_string == "EffectConfigId") return kActorStatusEffectConfigId;
    else if (source_string == "Level") return kActorStatusLevel;
    else if (source_string == "Appearance") return kActorStatusAppearance;
    else if (source_string == "Career") return kActorStatusCareer;
    else if (source_string == "Faction") return kActorStatusFaction;
    else if (source_string == "HomeDirection") return kActorStatusHomeDirection;
    else if (source_string == "GuardAreaType") return kActorStatusGuardAreaType;
    else if (source_string == "AttackAreaType") return kActorStatusAttackAreaType;
    else if (source_string == "LogicState") return kActorStatusLogicState;
    else if (source_string == "MotionState") return kActorStatusMotionState;
    else if (source_string == "BornType") return kActorStatusBornType;
    else if (source_string == "DeadType") return kActorStatusDeadType;
    else if (source_string == "IsDisableUserOperation") return kActorStatusIsDisableUserOperation;
    else if (source_string == "IsIncontrollable") return kActorStatusIsIncontrollable;
    else if (source_string == "IsMuteMove") return kActorStatusIsMuteMove;
    else if (source_string == "IsMuteAttack") return kActorStatusIsMuteAttack;
    else if (source_string == "IsMuteAttackNormal") return kActorStatusIsMuteAttackNormal;
    else if (source_string == "IsMuteAttackPower") return kActorStatusIsMuteAttackPower;
    else if (source_string == "IsMuteAttackSpecial") return kActorStatusIsMuteAttackSpecial;
    else if (source_string == "IsMuteGuard") return kActorStatusIsMuteGuard;
    else if (source_string == "AcceptDamage") return kActorStatusAcceptDamage;
    else if (source_string == "AcceptDamagePhysical") return kActorStatusAcceptDamagePhysical;
    else if (source_string == "AcceptDamageMagical") return kActorStatusAcceptDamageMagical;
    else if (source_string == "AcceptDamageCritical") return kActorStatusAcceptDamageCritical;
    else if (source_string == "AcceptDamageIce") return kActorStatusAcceptDamageIce;
    else if (source_string == "AcceptDamageFire") return kActorStatusAcceptDamageFire;
    else if (source_string == "AcceptDamageWind") return kActorStatusAcceptDamageWind;
    else if (source_string == "MotionIsBusy") return kActorStatusMotionIsBusy;
    else if (source_string == "ControlIsAuto") return kActorStatusControlIsAuto;
    else if (source_string == "ControlIsManual") return kActorStatusControlIsManual;
    else if (source_string == "ControlIsCounterAttack") return kActorStatusControlIsCounterAttack;
    else if (source_string == "ControlAutoGuardType") return kActorStatusControlAutoGuardType;
    else if (source_string == "ControlAutoReleaseSpecialSkillType") return kActorStatusControlAutoReleaseSpecialSkillType;
    else if (source_string == "ControlAutoReleaseSpecialSkillCount") return kActorStatusControlAutoReleaseSpecialSkillCount;
    else if (source_string == "ControlAutoReleaseSpecialSkillProbability") return kActorStatusControlAutoReleaseSpecialSkillProbability;
    else if (source_string == "BuffShaderType") return kActorStatusBuffShaderType;
    else if (source_string == "BuffIsPauseAnimation") return kActorStatusBuffIsPauseAnimation;
    else if (source_string == "BuffIsChangeColor") return kActorStatusBuffIsChangeColor;
    else if (source_string == "BuffIsIncontrollable") return kActorStatusBuffIsIncontrollable;
    else if (source_string == "BuffIsMuteMove") return kActorStatusBuffIsMuteMove;
    else if (source_string == "BuffIsMuteAttack") return kActorStatusBuffIsMuteAttack;
    else if (source_string == "BuffIsMuteAttackNormal") return kActorStatusBuffIsMuteAttackNormal;
    else if (source_string == "BuffIsMuteAttackPower") return kActorStatusBuffIsMuteAttackPower;
    else if (source_string == "BuffIsMuteAttackSpecial") return kActorStatusBuffIsMuteAttackSpecial;
    else if (source_string == "BuffIsMuteGuard") return kActorStatusBuffIsMuteGuard;
    else if (source_string == "SkillCurrentSkillId") return kActorStatusSkillCurrentSkillId;
    else if (source_string == "SkillIsBusy") return kActorStatusSkillIsBusy;
    else if (source_string == "SkillIsPaused") return kActorStatusSkillIsPaused;
    else if (source_string == "SkillAttackType") return kActorStatusSkillAttackType;
    else if (source_string == "SkillGuardType") return kActorStatusSkillGuardType;
    else if (source_string == "SkillAutoType") return kActorStatusSkillAutoType;
    else if (source_string == "AnimationIsPaused") return kActorStatusAnimationIsPaused;
    else if (source_string == "AnimationIsFocused") return kActorStatusAnimationIsFocused;
    else if (source_string == "AnimationDirection") return kActorStatusAnimationDirection;
    else if (source_string == "AnimationIsHealthChanged") return kActorStatusAnimationIsHealthChanged;
    else if (source_string == "SpecifiedIsLimitGridX") return kActorStatusSpecifiedIsLimitGridX;
    else
    {
      CCLog("[ParseActorStatusType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorStatus;
    }
  }




  eActorAnimationType ParseAnimationType(const std::string& source_string)
  {
    if (source_string.empty()) return kActorAnimationNone;
    else if (source_string == "effect") return kActorAnimationEffectId;
    else if (source_string == "armature") return kActorAnimationArmatureName;
    else if (source_string == "projectile") return kActorAnimationProjectileName;
    else
    {
      CCLog("[ParseEffectTimelineAnimationType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorAnimation;
    }
  }
  eActorAnimationLayerType ParseAnimationLayerType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "top_layer") return kActorAnimationLayerTop;
    else if (source_string == "actor_layer") return kActorAnimationLayerActor;
    else if (source_string == "bottom_layer") return kActorAnimationLayerBottom;
    else
    {
      CCLog("[ParseEffectTimelineAnimationLayerType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorAnimationLayer;
    }
  }
  eActorAnimationDisplayType ParseAnimationDisplayType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "above_actor") return kActorAnimationDisplayAboveActor;
    else if (source_string == "on_actor") return kActorAnimationDisplayOnActor;
    else if (source_string == "below_actor") return kActorAnimationDisplayBelowActor;
    else
    {
      CCLog("[ParseBuffStatusAnimationDisplayType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorAnimationDisplay;
    }
  }




  eActorMovementOriginType ParseMovementOriginType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "source_actor_location") return kActorMovementOriginSourceActorLocation;
    else if (source_string == "source_actor_attack_anchor") return kActorMovementOriginSourceActorAttackAnchor;
    else if (source_string == "screen_center") return kActorMovementOriginScreenCenter;
    else
    {
      CCLog("[ParseMovementOriginType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorMovementOrigin;
    }
  }
  eActorMovementType ParseMovementType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "none") return kActorMovementNone;
    else if (source_string == "tag_actor") return kActorMovementTagActor;
    else if (source_string == "cycle_actor") return kActorMovementCycleActor;
    else if (source_string == "line") return kActorMovementLine;
    else if (source_string == "homing") return kActorMovementHoming;
    else
    {
      CCLog("[ParseMovementType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorMovement;
    }
  }




  std::list<EmitIdData> ParseEmitIdDataList(const std::string& source_string)
  {
    std::list<EmitIdData> emit_id_data_list;

    if (source_string.empty())
    {
      return emit_id_data_list;
    }

    //parse string
    std::list<std::string>* data_string_list = ActorStringSplit(source_string, std::string(","));
    for (std::list<std::string>::iterator iterator = data_string_list->begin(); iterator != data_string_list->end(); iterator ++)
    {
      std::string &data_string = *iterator;
      std::list<std::string>* data_item_string_list = ActorStringSplit(data_string, std::string("|"));
      std::list<std::string>::iterator iterator_data_item = data_item_string_list->begin();

      if (data_item_string_list->size() != 2 && data_item_string_list->size() != 3)
      {
        CCLog("[ParseEmitIdDataList] error data item count <%d>! source_string: %s", data_item_string_list->size(), source_string.c_str());
        assert(false);
        delete data_item_string_list;
        continue;
      }

      EmitIdData emit_id_data;

      emit_id_data.id = atoi(iterator_data_item->c_str());
      iterator_data_item ++;

      if (*iterator_data_item == "effect_timeline")
      {
        emit_id_data.type = kActorEmitEffectTimeline;
      }
      else if (*iterator_data_item == "buff")
      {
        emit_id_data.type = kActorEmitBuff;
      }
      else
      {
        CCLog("[ParseEmitIdDataList] error type string <%s>! source_string: %s", iterator_data_item->c_str(), source_string.c_str());
        assert(false);
        emit_id_data.type = kActorEmit;
      }
      iterator_data_item ++;

      if (data_item_string_list->size() > 2)
      {
        emit_id_data.fail_chance = String2Float(*iterator_data_item);
      }
      else
      {
        emit_id_data.fail_chance = 0.0f;
      }

      emit_id_data_list.push_back(emit_id_data);

      delete data_item_string_list;
    }
    delete data_string_list;

    return emit_id_data_list;
  }




  ActorBuffStatusBitSet ParseBuffStatusBitSet(const std::string& source_string)
  {
    ActorBuffStatusBitSet result_status_bit_set;

    if (source_string == "all_effect") 
    {
      result_status_bit_set.set();  //set all
    }

    else if (source_string == "mute_attack_all") 
    {
      result_status_bit_set.set(kActorBuffStatusMuteAttackNormal);
      result_status_bit_set.set(kActorBuffStatusMuteAttackPower);
      result_status_bit_set.set(kActorBuffStatusMuteAttackSpecial);
    }

    else if (source_string == "mute_receive_damage_all") 
    {
      result_status_bit_set.set(kActorBuffStatusMuteReceiveDamagePhysical);
      result_status_bit_set.set(kActorBuffStatusMuteReceiveDamageMagical);
    }

    else if (source_string == "element_fire") result_status_bit_set.set(kActorBuffStatusElementFire);
    else if (source_string == "element_water") result_status_bit_set.set(kActorBuffStatusElementWater);
    else if (source_string == "element_wind") result_status_bit_set.set(kActorBuffStatusElementWind);
    else if (source_string == "element_light") result_status_bit_set.set(kActorBuffStatusElementLight);
    else if (source_string == "element_dark") result_status_bit_set.set(kActorBuffStatusElementDark);

    else if (source_string == "mute_attack_normal") result_status_bit_set.set(kActorBuffStatusMuteAttackNormal);
    else if (source_string == "mute_attack_power") result_status_bit_set.set(kActorBuffStatusMuteAttackPower);
    else if (source_string == "mute_attack_special") result_status_bit_set.set(kActorBuffStatusMuteAttackSpecial);

    else if (source_string == "mute_receive_damage_physical") result_status_bit_set.set(kActorBuffStatusMuteReceiveDamagePhysical);
    else if (source_string == "mute_receive_damage_magical") result_status_bit_set.set(kActorBuffStatusMuteReceiveDamageMagical);

    else if (source_string == "auto_move") result_status_bit_set.set(kActorBuffStatusAutoMove);
    else if (source_string == "mute_move") result_status_bit_set.set(kActorBuffStatusMuteMove);

    else if (source_string == "status_stiff") result_status_bit_set.set(kActorBuffStatusStiff);

    else if (source_string == "status_blind") result_status_bit_set.set(kActorBuffStatusBlind);
    else if (source_string == "status_fear") result_status_bit_set.set(kActorBuffStatusFear);
    else if (source_string == "status_freeze") result_status_bit_set.set(kActorBuffStatusFreeze);
    else if (source_string == "status_invisible") result_status_bit_set.set(kActorBuffStatusInvisible);
    else if (source_string == "status_petrify") result_status_bit_set.set(kActorBuffStatusPetrify);
    else if (source_string == "status_silence") result_status_bit_set.set(kActorBuffStatusSlience);
    else if (source_string == "status_stun") result_status_bit_set.set(kActorBuffStatusStun);
    else if (source_string == "status_charmed") result_status_bit_set.set(kActorBuffStatusCharmed);
    else if (source_string == "status_intertwine") result_status_bit_set.set(kActorBuffStatusInterwine);

    else
    {
      CCLog("[ParseBuffStatusBitSet] error source_string <%s>!", source_string.c_str());
      //assert(false);
    }

    return result_status_bit_set;
  }










  void InitRoutineConfigData(Actor* actor, int routine_config_id/* = ACTOR_INVALID_ID*/)
  {
    actor::ActorData* actor_data = actor->GetActorData();

    int card_id = actor_data->GetActorStatus(kActorStatusCardId);
    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    assert(card_data);

    //apply actor routine config data to lua
    if (routine_config_id <= 0)
    {
      routine_config_id = (actor_data->GetActorStatus(kActorStatusFaction) == kActorFactionUserOppose) 
        ? card_data->GetAIMoveType() 
        : 1;
    }

    ActorRoutineConfigData* actor_routine_config_data = DataManager::GetInstance().GetActorRoutineConfigDataTable()->GetActorRoutineConfig(routine_config_id);

    if (!actor_routine_config_data)
    {
      actor_data->GetLog()->AddErrorLogF("[InitRoutineConfigData] invalid routine_config_id: %d!", routine_config_id);
      assert(actor_routine_config_data);
      return;
    }


    //create lua routine_data_table
    lua_tinker::table routine_data_table = lua_tinker::table(lua_data_tunnel::GetLuaState());

    routine_data_table.set("is_mute_move", actor_routine_config_data->GetIsMuteMove());
    routine_data_table.set("is_mute_attack", actor_routine_config_data->GetIsMuteAttack());
    routine_data_table.set("is_mute_guard", actor_routine_config_data->GetIsMuteGuard());
    routine_data_table.set("is_mute_auto", actor_routine_config_data->GetIsMuteAuto());
    routine_data_table.set("is_mute_counter_attack", actor_routine_config_data->GetIsMuteCounterAttack());
    routine_data_table.set("is_direction_relative", actor_routine_config_data->GetIsTargetGridDirectionRelative());

    lua_tinker::table routine_data_target_grid_list_table = lua_tinker::table(lua_data_tunnel::GetLuaState());

    {
      int lua_table_index = 1;
      std::list<ActorTargetGridData>& target_grid_data_list = actor_routine_config_data->GetTargetGridData();
      if (target_grid_data_list.empty() == false)
      {
        for (std::list<ActorTargetGridData>::iterator iterator = target_grid_data_list.begin(); iterator != target_grid_data_list.end(); iterator ++)
        {
          ActorTargetGridData& target_grid_data = *iterator;

          lua_tinker::table routine_data_target_grid_table = lua_tinker::table(lua_data_tunnel::GetLuaState());
          if (target_grid_data.is_actor_grid_x == false) routine_data_target_grid_table.set("grid_x", target_grid_data.grid_x);
          if (target_grid_data.is_actor_grid_y == false) routine_data_target_grid_table.set("grid_y", target_grid_data.grid_y);
          if (target_grid_data.extra_data.empty() == false) routine_data_target_grid_table.set("extra_data", target_grid_data.extra_data.c_str());

          routine_data_target_grid_list_table.set(lua_table_index ++, routine_data_target_grid_table);
        }
      }
      //auto add target grid "base_line"
      if (actor_routine_config_data->GetIsTargetBaseLine())
      {
        lua_tinker::table routine_data_target_grid_table = lua_tinker::table(lua_data_tunnel::GetLuaState());
        routine_data_target_grid_table.set("grid_x", 7);
        routine_data_target_grid_table.set("extra_data", "base_line");

        routine_data_target_grid_list_table.set(lua_table_index ++, routine_data_target_grid_table);
      }
      //auto add target grid "born"
      if (actor_data->CheckActorPosition(kActorPositionTargetGridBorn) && actor_data->GetActorPosition(kActorPositionTargetGridBorn).equals(CCPointZero) == false)
      {
        lua_tinker::table routine_data_target_grid_table = lua_tinker::table(lua_data_tunnel::GetLuaState());
        bool is_actor_home_left = actor_data->GetActorStatus(kActorStatusHomeDirection) == kActorAnimationDirectionLeft;
        routine_data_target_grid_table.set("grid_x", is_actor_home_left
          ? actor_data->GetActorPosition(kActorPositionTargetGridBorn).x
          : 6 - actor_data->GetActorPosition(kActorPositionTargetGridBorn).x + 1);
        routine_data_target_grid_table.set("extra_data", "born");

        routine_data_target_grid_list_table.set(lua_table_index ++, routine_data_target_grid_table);
      }
    }

    routine_data_table.set("target_grid_list", routine_data_target_grid_list_table);


    //send to lua
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", actor->GetScriptObjectId(), 
      "InitRoutineControlFromRoutineConfig", 
      actor_routine_config_data->GetRoutineScript().c_str(),
      routine_data_table);
  }






  //Element 
  // 0 for nothing, 1+ for advantage, -1- for disadvantage
  const int element_type_count = 5;
  const int status_element_bit_index_list[element_type_count] = {
    kActorBuffStatusElementFire,
    kActorBuffStatusElementWater,
    kActorBuffStatusElementWind,
    kActorBuffStatusElementLight,
    kActorBuffStatusElementDark
  };
  const int element_correction_map_positive[element_type_count][element_type_count] = {
    //1st \ 2nd   Fire    Water   Wind    Light   Dark
    /*Fire  */   {0,      0,      1,      0,      0},
    /*Water */   {1,      0,      0,      0,      0},
    /*Wind  */   {0,      1,      0,      0,      0},
    /*Light */   {0,      0,      0,      0,      1},
    /*Dark  */   {0,      0,      0,      1,      0}
  };
  const int element_correction_map_negative[element_type_count][element_type_count] = {
    //1st \ 2nd   Fire    Water   Wind    Light   Dark
    /*Fire  */   {0,      -1,     0,      0,      0},
    /*Water */   {0,      0,      -1,     0,      0},
    /*Wind  */   {-1,     0,      0,      0,      0},
    /*Light */   {0,      0,      0,      0,      0},
    /*Dark  */   {0,      0,      0,      0,      0}
  };

  void quick_set_element_list(int element_list[element_type_count], const ActorBuffStatusBitSet& status_bit_set)
  {
    for (int i = 0; i < element_type_count; i ++)
      element_list[i] = status_bit_set.test(status_element_bit_index_list[i]) ? 1 : 0;
  }

  int quick_sum_element_correction(const int element_correction_map[element_type_count][element_type_count], const ActorBuffStatusBitSet& source, const ActorBuffStatusBitSet& target)
  {
    static int source_element_list[element_type_count];
    static int target_element_list[element_type_count];

    quick_set_element_list(source_element_list, source);
    quick_set_element_list(target_element_list, target);

    int result_correction = 0;

    for (int i = 0; i < element_type_count; i ++)
      if (source_element_list[i])
        for (int j = 0; j < element_type_count; j ++)
          if (target_element_list[j])
            result_correction += element_correction_map[i][j];

    return result_correction;
  }


  int GetElementCorrectionPositive(const ActorBuffStatusBitSet& source, const ActorBuffStatusBitSet& target)
  {
    return quick_sum_element_correction(element_correction_map_positive, source, target);
  }
  int GetElementCorrectionNegative(const ActorBuffStatusBitSet& source, const ActorBuffStatusBitSet& target)
  {
    return quick_sum_element_correction(element_correction_map_negative, source, target);
  }







  //MISC
  // TODO: Remove if possible
  ActorExtEnv* GetActorExtEnvAdapter()
  {
    return taomee::battle::BattleController::GetInstance().GetActorExtEnv();
  }

  void AlertEnemyPassRightBorder(int actor_id)
  {
    battle::BattleController::GetInstance().GetLevelEntity()->notifyMonsterMoveToRightBorder(actor_id);
  }

  void AutoReleaseSpecialSkill(int actor_id)
  {
    taomee::battle::BattleController::GetInstance().TriggerSpecialSkillRelease(actor_id);
  }

  void ShowDamageLabel(DamagePackage* damage_package, int actor_id, float damage_value)
  {
    Actor* target_actor = GetActorExtEnvAdapter()->GetActorById(actor_id);

    if (!target_actor || !target_actor->GetIsActorAlive())
      return;

//     eActorSkillType skill_type = eActorSkillType(damage_package->GetStatus(kActorDamageStatusSourceSkillType));
//     bool is_normal_attack = (skill_type == kActorSkillNormal);

    //ActorFactionType
    eActorFactionType target_actor_faction = eActorFactionType(target_actor->GetActorData()->GetActorStatus(kActorStatusFaction));

    //DamageType
    taomee::battle::eDamageType damage_type;
    if (damage_package->GetStatusBool(kActorDamageStatusIsMissed))
      damage_type = taomee::battle::eDamageTypeMiss;
    else if (damage_package->GetStatusBool(kActorDamageStatusIsCritical))
      damage_type = taomee::battle::eDamageTypeCritical;
    else if (damage_package->GetStatusBool(kActorDamageStatusIsHeal))
      damage_type = taomee::battle::eDamageTypeHeal;
    else
      damage_type = taomee::battle::eDamageTypeNormal;
      //damage_type = taomee::battle::eDamageTypeStatus; //not yet

    //DamageElementType
    taomee::battle::eDamageElementType damage_element_type = taomee::battle::eDamageElementTypeNormal;
    ActorBuffStatusBitSet damage_status_bit_set = damage_package->GetStatusBitSet();
    if (damage_status_bit_set.test(kActorBuffStatusElementFire))
      damage_element_type = taomee::battle::eDamageElementTypeFire;
    if (damage_status_bit_set.test(kActorBuffStatusElementWater))
      damage_element_type = taomee::battle::eDamageElementTypeWater;
    if (damage_status_bit_set.test(kActorBuffStatusElementWind))
      damage_element_type = taomee::battle::eDamageElementTypeWind;
    if (damage_status_bit_set.test(kActorBuffStatusElementLight))
      damage_element_type = taomee::battle::eDamageElementTypeLight;
    if (damage_status_bit_set.test(kActorBuffStatusElementDark))
      damage_element_type = taomee::battle::eDamageElementTypeDark;

    //ElementCorrection
    ActorBuffStatusBitSet target_status_bit_set = target_actor->GetActorData()->GetBuffData()->GetBuffStatusBitFlag();
    int element_correction = GetElementCorrectionPositive(damage_status_bit_set, target_status_bit_set)
      + GetElementCorrectionNegative(damage_status_bit_set, target_status_bit_set);

    //Position
    cocos2d::CCPoint label_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
    label_position.y += target_actor->GetAnimation()->GetActorVisualHeight();


    //Create Label
    taomee::battle::DamageLabel::create()->ShowDamageLabelOnBattleLayer(
      target_actor_faction, //target_actor_faction
      damage_type,  //damage_type
      damage_element_type,  //damage_element_type
      element_correction,  //element_correction
      damage_value, //damage_value
      label_position);  //label_position
  }

}