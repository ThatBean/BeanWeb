#include "actor_logic_state_born.h"

#include "game/actor/actor.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateBorn::STATE_TYPE = kActorLogicStateBorn;

  LogicStateBorn* LogicStateBorn::Instance()
  {
    static LogicStateBorn instance;
    return &instance;
  }


  void LogicStateBorn::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateBorn][OnEnter]");

    switch (actor->GetActorData()->GetActorStatus(kActorStatusBornType))
    {
    case kActorBornFadeIn:
    case kActorBornDropIn:
    case kActorBornBounceIn:
    case kActorBornExplode:
    case kActorBornBeam:
      actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateBorn));
      break;
    case kActorBornDefault:
      //Skip Born Motion
      actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateBorn));
      break;
    default:
      assert(false);
      break;
    }
  }

  void LogicStateBorn::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeBorn);  //Exit Born State

    //apply skill born with (should all be buff, and no animation)
    actor->GetActorData()->GetSkillData()->CommitSkill(actor->GetActorData()->GetSkillData()->GetSkillIdByType(actor::kActorSkillBornWith, 0), actor->GetScriptObjectId());
    actor->GetActorData()->GetSkillData()->CommitSkill(actor->GetActorData()->GetSkillData()->GetSkillIdByType(actor::kActorSkillBornWith, 1), actor->GetScriptObjectId());

    //RoutineConfig
    InitRoutineConfigData(actor, ACTOR_INVALID_ID);

    actor->GetActorData()->GetLog()->AddLog("[LogicStateBorn][OnExit]");
  }

  void LogicStateBorn::Update(Actor* actor, float delta_time)
  {
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeBorn);  //Release Control Lock
      
    }
  }

} // namespace actor