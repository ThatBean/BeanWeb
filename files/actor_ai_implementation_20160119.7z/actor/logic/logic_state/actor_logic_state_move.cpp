#include "actor_logic_state_move.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateMove::STATE_TYPE = kActorLogicStateMove;

  LogicStateMove* LogicStateMove::Instance()
  {
    static LogicStateMove instance;
    return &instance;
  }


  void LogicStateMove::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateMove][OnEnter]");

    //position correction(always move to the center of tile)
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    
    if (control_data->CheckOperationData(kActorControlOperationPositionMove))
    {
      ActorSpecifiedData* specified_Data = actor->GetActorData()->GetSpecifiedData();

      if (specified_Data->IsPositionValid(control_data->GetPositionOperationData(kActorControlOperationPositionMove))) //check position
      {
        ActorControlOperationData* operation_data = control_data->GetOperationData(kActorControlOperationPositionMove);
        operation_data->data_position = specified_Data->PositionCorrection(operation_data->data_position);  //adjust
      }
      else
      {
        actor->GetActorData()->GetLog()->AddErrorLogF("[Error][LogicStateMove][OnEnter] Position not Valid: (%f, %f)", control_data->GetPositionOperationData(kActorControlOperationPositionMove).x, control_data->GetPositionOperationData(kActorControlOperationPositionMove).y);
        control_data->RemoveOperationData(kActorControlOperationPositionMove);
      }
    }

    if (control_data->CheckOperationData(kActorControlOperationIdTargetMove))
    {
      if (!actor->GetActorExtEnv()->GetActorById(control_data->GetIdOperationData(kActorControlOperationIdTargetMove))) //check position
      {
        actor->GetActorData()->GetLog()->AddErrorLogF("[Error][LogicStateMove][OnEnter] Target Id not Valid: %d", control_data->GetIdOperationData(kActorControlOperationIdTargetMove));
        control_data->RemoveOperationData(kActorControlOperationIdTargetMove);
      }
    }

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateMove));
  }

  void LogicStateMove::OnExit(Actor* actor)
  {
    //clear control data
    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetMove);
    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationPositionMove);

    actor->GetActorData()->GetLog()->AddLog("[LogicStateMove][OnExit]");
  }

  void LogicStateMove::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[LogicStateMove][Update]");
    //Position
    //Target
    
    //Finished State Logic?
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetMove);
      actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationPositionMove);
      //back to idle
      //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
    }

    //check trigger
    if (/*actor->GetActorData()->GetControlData()->IsSetOperation() == false 
        && */actor->GetActorData()->GetControlData()->GetCountdown() == 0
        && IsPositionInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation))) //logic only run when actor entered grid
    {
      //reset CD
      actor->GetActorData()->GetControlData()->SetCountdown(ACTOR_CONTROL_COUNTDOWN_MOVE_CHECK);

      //check attack
      if (actor->GetActorData()->GetSkillData()->CheckAttackTrigger())
      {
        //goto Attack, commit attack
        //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
        return;
      }
    }
  }

} // namespace actor