#include "actor_logic_state_dead.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateDead::STATE_TYPE = kActorLogicStateDead;

  LogicStateDead* LogicStateDead::Instance()
  {
    static LogicStateDead instance;
    return &instance;
  }


  void LogicStateDead::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateDead][OnEnter]");
    

    switch (actor->GetActorData()->GetActorStatus(kActorStatusDeadType))
    {
    case kActorDeadFadeOut:
    case kActorDeadDropOut:
    case kActorDeadBounceOut:
    case kActorDeadExplode:
    case kActorDeadBeam:
      actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateDead));
      break;
    case kActorDeadDefault:
      //Skip Dead Motion
      actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateDead));
      break;
    default:
      assert(false);
      break;
    }
  }

  void LogicStateDead::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeDead);  //Exit Dead State

    //should not exit???

    actor->GetActorData()->GetLog()->AddLog("[LogicStateDead][OnExit]");
  }

  void LogicStateDead::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[LogicStateDead][Update]");
    
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      //Remain Dead Lock
      //actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeDead);  //Release Control Lock

      //Dead logic
      actor->GetMotionStateMachine()->ChangeState(NULL);
      actor->SetScriptObjectIsActive(false);  //wait for update to be picked out and removed, currently in BattleActorDataCenter
    }
  }
} // namespace actor