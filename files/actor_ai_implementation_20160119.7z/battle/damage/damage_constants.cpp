//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  damage_constants.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-11-14
//          Time:  6:50
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-11-14       1         create
//////////////////////////////////////////////////////////////

#include "game/battle/damage/damage_constants.h"

#include <assert.h>

namespace taomee {
namespace battle {
 
uint_32 GetFiveElementsStatusOverlayedResult(uint_32 attackStatus, uint_32 targetStatus)
{
	uint_32 targetImmuneStatus = 0;
	if ( targetStatus & kDamageInvincible )
	{
		targetImmuneStatus = targetImmuneStatus | kDamageInvincible;
	}
	if ( targetStatus & kDamageStatusImmune )
	{
		targetImmuneStatus = targetImmuneStatus | kDamageStatusImmune;
	}

  uint_32 damageType = 0;
  if (attackStatus & kDamageFireProperty)
  {
    damageType = kAttackResultFireDamage;
  }
  else if (attackStatus & kDamageIceProperty)
  {
    damageType = kAttackResultIceDamage;
  }
  else if ( attackStatus & kDamageWindProperty )
  {
	  damageType = kAttackResultWindDamage;
  }

  // value type : reinforce / weaken
  attackStatus = attackStatus & kFiveElementsBitFlag;
  if (attackStatus & targetStatus)
  {
    damageType = damageType | kAttackResultReinforceDamage;
  }
  else if (attackStatus & targetImmuneStatus)
  {
    damageType = damageType | kAttackResultWeakenDamage;
  }
  else
  {
    damageType = damageType | kAttackResultNormalDamage;
  }
  return damageType;
}
  
eAttackResult GetOtherStatusExceptFiveElementsOverlayedResult(uint_32 attackStatus,
                                                              uint_32 targetStatus)
{
  attackStatus = attackStatus & kOtherStatusExceptFiveElementsBitFlag;
  targetStatus = targetStatus & kOtherStatusExceptFiveElementsBitFlag;
  if (attackStatus & targetStatus)
  {
    return kAttackResultReinforceDamage;
  }
  else
  {
    return kAttackResultNormalDamage;
  }
}
//   
// bool IsDamageFromRangeAttacker(uint_32 skillid)
// {
//   return (skillid==2 || skillid==4);
// }
//   
// bool IsStatusAKindOfStunType(eDamageStatus type)
// {
//   return (type&kDamageStunned) || (type&kDamageFreeze);
// }
//   
// bool IsStatusAKindOfSkillForbiddenType(eDamageStatus type)
// {
//   return (type&kDamageBlinded);
// }
  
} // namespace battle
} // namespace taomee