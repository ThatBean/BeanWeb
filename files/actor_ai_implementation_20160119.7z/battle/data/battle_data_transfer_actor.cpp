#include "battle_data_transfer_actor.h"

#include "battle_data_center.h"

#include "game/actor/actor.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/trigger/actor_trigger_predefined.h"

#include "game/battle/battle_controller.h"
#include "game/battle/battle_constants.h"

#include "game/user_data/character_info.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/character_data_table.h"
#include "game/data_table/skill_data_table.h"
#include "game/data_table/skill_config_data_table.h"

#include "game/shader/shader_manager.h"
#include "engine/script/lua_tinker_manager.h"

#include "engine/base/utils_string.h"


using namespace cocos2d;
using namespace cocos2d::extension;
using namespace actor;

#define SCRIPT_OBJECT_LUA "script/actor/script_object.lua"

namespace battle_data {

  //private data setting method
  //these method only focus on setting the basic init data

  //attribute data
  void _apply_attribute_data_from_card_table(
    BattleActorData* battle_actor_data, 
    int card_id, 
    int card_level = 1, 
    int card_evolve = 0, 
    int card_star = 0);

  void _apply_attribute_data_from_card_seq_id(
    BattleActorData* battle_actor_data, 
    int card_seq_id);

  void _apply_attribute_data_from_lua_attribute_table(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_attribute_table, 
    int card_id, 
    int card_level = 1, 
    int card_evolve = 0, 
    int card_star = 0);

  void _apply_attribute_data_from_overload_battle_actor_data(
    BattleActorData* battle_actor_data, 
    BattleActorData* overload_battle_actor_data);




  //skill data
  void _apply_skill_data_from_skill_table(
    BattleActorData* battle_actor_data, 
    int card_id);

  void _apply_skill_data_from_card_seq_id(
    BattleActorData* battle_actor_data, 
    int card_seq_id);

  void _apply_skill_data_from_lua_skill_table(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_skill_table, 
    int card_id);

  void _apply_skill_data_from_overload_battle_actor_data(
    BattleActorData* battle_actor_data, 
    BattleActorData* overload_battle_actor_data);

  //verify
  void _verify_actor_data(BattleActorData* battle_actor_data);




  //==========================================================================================================
  //==========================================================================================================

  const eBattleAttributeType __battle_data_attribute_required_array[] = {
    kBattleAttributeActorInitHealthMax,
    //kBattleAttributeActorInitHealthCurrent, //optional, currently health, default full

    kBattleAttributeActorInitEnergyMax, //all is set to 1000
    //kBattleAttributeActorInitEnergyCurrent, //optional, currently energy, default empty

    kBattleAttributeActorInitAttackPhysical,
    kBattleAttributeActorInitAttackMagical,
    kBattleAttributeActorInitAttackCritical,

    kBattleAttributeActorInitFactorHit,
    kBattleAttributeActorInitFactorDodge,
    kBattleAttributeActorInitFactorCritical,

    kBattleAttributeActorInitDefensePhysical,
    kBattleAttributeActorInitDefenseMagical

    //kBattleAttributeActorInitDamageAddition,

    //kBattleAttributeActorInitDamageReduction,
    //kBattleAttributeActorInitDamageReductionPhysical,
    //kBattleAttributeActorInitDamageReductionMagical,

    //kBattleAttributeActorInitWaveHealthRecover,
    //kBattleAttributeActorInitWaveEnergyRecover,
  };
  const int __battle_data_attribute_required_array_size = CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_attribute_required_array);


  const eBattleStatusType __battle_data_status_required_array[] = {
    kBattleStatusActorInitCardId,
    //kBattleStatusActorInitCardSeqId,

    kBattleStatusActorInitLevel,
    //kBattleStatusActorInitEvolve,
    //kBattleStatusActorInitStar,

    kBattleStatusActorInitFaction,
    kBattleStatusActorInitHomeDirection
  };
  const int __battle_data_status_required_array_size = CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_status_required_array);


  const int __battle_data_attribute_convert_array_source[] = {
    kCharacterAttrTypeHealthMax,
    //kCharacterAttrTypeHealthCurrent,
    //kCharacterAttrTypeHealthRecover,

    //kCharacterAttrTypeEnergyMax,
    //kCharacterAttrTypeEngeryCurrent,
    //kCharacterAttrTypeEngeryRecover,

    kCharacterAttrTypeCrit,
    kCharacterAttrTypeCritResist,
    kCharacterAttrTypeCritPrefectRate,

    kCharacterAttrTypeHit,

    kCharacterAttrTypeDodge,
    kCharacterAttrTypeDodgePerfertRate,

    kCharacterAttrTypeArmor,
    kCharacterAttrTypeArmorRend,
    kCharacterAttrTypeArmorRendExtendRate,

    kCharacterAttrTypeSkillDamageRate,
    kCharacterAttrTypeSkillResist,

    kCharacterAttrTypeSpeedAttack,
    kCharacterAttrTypeSpeedMove,

    kCharacterAttrTypeAttackPhysical,
    kCharacterAttrTypeAttackMagic,
    kCharacterAttrTypeCritExtendDamage,

    kCharacterAttrTypeDefensePhysical,
    kCharacterAttrTypeDefenseMagic,

    kCharacterAttrTypeDamageExtendAdd,
    kCharacterAttrTypeDamageExtendReduce,
  };
  const eBattleAttributeType __battle_data_attribute_convert_array_battle_actor_init[] = {
    kBattleAttributeActorInitHealthMax,
    //kBattleAttributeActorInitHealthCurrent,
    //kBattleAttributeActorInitHealthRecover,

    //kBattleAttributeActorInitEnergyMax,
    //kBattleAttributeActorInitEnergyCurrent,
    //kBattleAttributeActorInitEnergyRecover,

    kBattleAttributeActorInitFactorCritical,
    kBattleAttributeActorInitFactorCriticalResist,
    kBattleAttributeActorInitFactorCriticalExtra,

    kBattleAttributeActorInitFactorHit,

    kBattleAttributeActorInitFactorDodge,
    kBattleAttributeActorInitFactorDodgeExtra,

    kBattleAttributeActorInitFactorDamageAdjust,
    kBattleAttributeActorInitFactorDamageAdjustResist,
    kBattleAttributeActorInitFactorDamageAdjustExtra,

    kBattleAttributeActorInitFactorSkillDamage,
    kBattleAttributeActorInitFactorSkillDamageResist,

    kBattleAttributeActorInitSpeedAttack,
    kBattleAttributeActorInitSpeedMove,

    kBattleAttributeActorInitAttackPhysical,
    kBattleAttributeActorInitAttackMagical,
    kBattleAttributeActorInitAttackCritical,

    kBattleAttributeActorInitDefensePhysical,
    kBattleAttributeActorInitDefenseMagical,

    kBattleAttributeActorInitDamageAddition,
    kBattleAttributeActorInitDamageReduction,
  };
  const eActorAttributeType __battle_data_attribute_convert_array_actor[] = {
    kActorAttributeHealthMax,
    //kActorAttributeHealthCurrent,
    //kActorAttributeHealthRecover,

    //kActorAttributeEnergyMax,
    //kActorAttributeEnergyCurrent,
    //kActorAttributeEnergyRecover,

    kActorAttributeFactorCritical,
    kActorAttributeFactorCriticalResist,
    kActorAttributeFactorCriticalExtra,

    kActorAttributeFactorHit,

    kActorAttributeFactorDodge,
    kActorAttributeFactorDodgeExtra,

    kActorAttributeFactorDamageAdjust,
    kActorAttributeFactorDamageAdjustResist,
    kActorAttributeFactorDamageAdjustExtra,

    kActorAttributeFactorSkillDamage,
    kActorAttributeFactorSkillDamageResist,

    kActorAttributeSpeedAttack,
    kActorAttributeSpeedMove,

    kActorAttributeAttackPhysical,
    kActorAttributeAttackMagical,
    kActorAttributeAttackCritical,

    kActorAttributeDefensePhysical,
    kActorAttributeDefenseMagical,

    kActorAttributeDamageAddition,
    kActorAttributeDamageReduction,
  };
  const int __battle_data_attribute_convert_array_size = CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_attribute_convert_array_source);





  const eBattleStatusType __battle_data_status_convert_array_battle_actor_init[] = {
    kBattleStatusActorInitCardId,
    kBattleStatusActorInitCardSeqId,

    kBattleStatusActorInitLevel,
    kBattleStatusActorInitEvolve,
    kBattleStatusActorInitStar,

    kBattleStatusActorInitFaction,
    kBattleStatusActorInitHomeDirection
  };
  const eActorStatusType __battle_data_status_convert_array_actor[] = {
    kActorStatusCardId,
    kActorStatus, //kActorStatusCardSeqId,

    kActorStatusLevel,
    kActorStatus, //kActorStatusEvolve,
    kActorStatus, //kActorStatusStar,

    kActorStatusFaction,
    kActorStatusHomeDirection
  };
  const int __battle_data_status_convert_array_size = CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_status_convert_array_battle_actor_init);




  const int __battle_data_skill_array_index[] = {
    kSkillNormal,
    kSkillPower1,
    kSkillPower2,
    kSkillSpecial,
    kSkillPassive1,
    kSkillPassive2
  };
  const eActorSkillType __battle_data_skill_array_type[] = {
    kActorSkillNormal,
    kActorSkillPower,
    kActorSkillPower,
    kActorSkillSpecial,
    kActorSkillBornWith,
    kActorSkillBornWith
  };
  const int __battle_data_skill_array_level_default[] = {
    1,
    0,
    0,
    1,
    0,
    0
  };
  const int __battle_data_skill_array_level_enemy[] = {
    1,
    1,
    1,
    1,
    1,
    1
  };
  const int __battle_data_skill_array_size = CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_skill_array_index);


#ifdef WIN32
  class KeyArrayCheck {
  public:
    KeyArrayCheck()
    {
      //these array are supposed to be the same length
      assert(__battle_data_attribute_convert_array_size == CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_attribute_convert_array_battle_actor_init));
      assert(__battle_data_attribute_convert_array_size == CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_attribute_convert_array_actor));

      assert(__battle_data_status_convert_array_size == CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_status_convert_array_actor));
      
      assert(__battle_data_skill_array_size == CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_skill_array_type));
      assert(__battle_data_skill_array_size == CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_skill_array_level_default));
      assert(__battle_data_skill_array_size == CALC_ARRAY_LEN_BY_SIZE_OF(__battle_data_skill_array_level_enemy));
    }
  };

  const KeyArrayCheck key_array_check_instance;
#endif //WIN32




  //attribute data
  void _apply_attribute_data_from_card_table(
    BattleActorData* battle_actor_data, 
    int card_id, 
    int card_level/* = 1*/, 
    int card_evolve/* = 0*/, 
    int card_star/* = 0*/)
  {
    battle_actor_data->status_map[kBattleStatusActorInitCardId] = card_id;
    battle_actor_data->status_map[kBattleStatusActorInitLevel] = card_level;
    battle_actor_data->status_map[kBattleStatusActorInitEvolve] = card_evolve;
    battle_actor_data->status_map[kBattleStatusActorInitStar] = card_star;


    // from card data table only
    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    assert(card_data);

    BornCalculator* value_calculator = DataManager::GetInstance().calculator();
    for (int convert_index = 0; convert_index < __battle_data_attribute_convert_array_size; convert_index++)
    {
      int source_key = __battle_data_attribute_convert_array_source[convert_index];
      eBattleAttributeType target_key = __battle_data_attribute_convert_array_battle_actor_init[convert_index];

      //from mixed data table
      float convert_value = value_calculator->PropertyCalculatorForActorByCardId(
        card_id, 
        source_key, 
        card_level, 
        card_star, 
        card_evolve);
      
      battle_actor_data->attribute_map[target_key] = convert_value;
    }


    //attack type
    if (card_data->GetAttackType() == kAttackTypePhysical)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitAttackMagical] = 0;
    }
    else if (card_data->GetAttackType() == kAttackTypeMagical)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitAttackPhysical] = 0;
    }
    else
    {
      CCLog("[_apply_attribute_data_from_card_table] error AttackType: %d", card_data->GetAttackType());
      assert(false);
    }


    //energy type(mana anger)
    if (card_data->GetSkillConsumeType() == kSkillConsumeTypeAnger)
    {
      //anger
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = BATTLE_ACTOR_ENEMGY_MAX
        + value_calculator->PropertyCalculatorForActorByCardId(card_id,kCharacterAttrTypeAngerMax,card_level,card_star,card_evolve);
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] * 0.5;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = value_calculator->PropertyCalculatorForActorByCardId(card_id,kCharacterAttrTypeAngerRecover,card_level,card_star,card_evolve);
    }
    else if (card_data->GetSkillConsumeType() == kSkillConsumeTypeMana)
    {
      //mana
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = BATTLE_ACTOR_ENEMGY_MAX
        + value_calculator->PropertyCalculatorForActorByCardId(card_id,kCharacterAttrTypeManaMax,card_level,card_star,card_evolve);
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax];
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = value_calculator->PropertyCalculatorForActorByCardId(card_id,kCharacterAttrTypeManaRecover,card_level,card_star,card_evolve);
    }
    else if (card_data->GetSkillConsumeType() == kSkillConsumeTypeNothing)
    {
      //nothing
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = 0;
    }
    else
    {
      CCLog("[_apply_attribute_data_from_card_table] error SkillConsumeType: %d", card_data->GetSkillConsumeType());
      assert(false);
      //set to nothing
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = 0;
    }
    

    //additional set default
    battle_actor_data->attribute_map[kBattleAttributeActorInitHealthCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitHealthMax];
    battle_actor_data->attribute_map[kBattleAttributeActorInitHealthRecover] = 0;    
  }


  void _apply_attribute_data_from_card_seq_id(
    BattleActorData* battle_actor_data, 
    int card_seq_id)
  {
    taomee::data::CharacterInfo* card_seq_info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(card_seq_id);
    assert(card_seq_info);

    int card_id = card_seq_info->card_id();

    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    assert(card_data);

    //record
    battle_actor_data->status_map[kBattleStatusActorInitCardSeqId] = card_seq_id;
    battle_actor_data->status_map[kBattleStatusActorInitCardId] = card_id;
    battle_actor_data->status_map[kBattleStatusActorInitLevel] = card_seq_info->level();
    battle_actor_data->status_map[kBattleStatusActorInitEvolve] = card_seq_info->getEvolveStep();
    battle_actor_data->status_map[kBattleStatusActorInitStar] = card_seq_info->up_star();

    for (int convert_index = 0; convert_index < __battle_data_attribute_convert_array_size; convert_index++)
    {
      int source_key = __battle_data_attribute_convert_array_source[convert_index];
      eBattleAttributeType target_key = __battle_data_attribute_convert_array_battle_actor_init[convert_index];

      float convert_value = card_seq_info->GetAttributeByType(source_key);

      battle_actor_data->attribute_map[target_key] = convert_value; //just flush
    }
    


    //attack type
    if (card_data->GetAttackType() == kAttackTypePhysical)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitAttackMagical] = 0;
    }
    else if (card_data->GetAttackType() == kAttackTypeMagical)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitAttackPhysical] = 0;
    }
    else
    {
      CCLog("[_apply_attribute_data_from_card_seq_id] error AttackType: %d", card_data->GetAttackType());
      assert(false);
    }


    //energy type(mana anger)
    if (card_data->GetSkillConsumeType() == kSkillConsumeTypeAnger)
    {
      //anger
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = BATTLE_ACTOR_ENEMGY_MAX
        + card_seq_info->GetAttributeByType(kCharacterAttrTypeAngerMax);
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] * 0.5;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = card_seq_info->GetAttributeByType(kCharacterAttrTypeAngerRecover);
    }
    else if (card_data->GetSkillConsumeType() == kSkillConsumeTypeMana)
    {
      //mana
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = BATTLE_ACTOR_ENEMGY_MAX
        + card_seq_info->GetAttributeByType(kCharacterAttrTypeManaMax);
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax];
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = card_seq_info->GetAttributeByType(kCharacterAttrTypeManaRecover);
    }
    else if (card_data->GetSkillConsumeType() == kSkillConsumeTypeNothing)
    {
      //nothing
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = 0;
    }
    else
    {
      CCLog("[_apply_attribute_data_from_card_seq_id] error SkillConsumeType: %d", card_data->GetSkillConsumeType());
      assert(false);
      //set to nothing
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = 0;
    }


    //additional set default
    battle_actor_data->attribute_map[kBattleAttributeActorInitHealthCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitHealthMax];
    battle_actor_data->attribute_map[kBattleAttributeActorInitHealthRecover] = 0;
  }


  void _apply_attribute_data_from_lua_attribute_table(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_attribute_table, 
    int card_id, 
    int card_level/* = 1*/, 
    int card_evolve/* = 0*/, 
    int card_star/* = 0*/)
  {
    battle_actor_data->status_map[kBattleStatusActorInitCardId] = card_id;
    battle_actor_data->status_map[kBattleStatusActorInitLevel] = card_level;
    battle_actor_data->status_map[kBattleStatusActorInitEvolve] = card_evolve;
    battle_actor_data->status_map[kBattleStatusActorInitStar] = card_star;

    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    assert(card_data);

    for (int convert_index = 0; convert_index < __battle_data_attribute_convert_array_size; convert_index++)
    {
      int source_key = __battle_data_attribute_convert_array_source[convert_index];
      eBattleAttributeType target_key = __battle_data_attribute_convert_array_battle_actor_init[convert_index];

      float convert_value = lua_attribute_table.get<float>(int(source_key + 1));  //lua table starts from 1

      battle_actor_data->attribute_map[target_key] = convert_value; //just flush
    }

    //attack type
    if (card_data->GetAttackType() == kAttackTypePhysical)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitAttackMagical] = 0;
    }
    else if (card_data->GetAttackType() == kAttackTypeMagical)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitAttackPhysical] = 0;
    }
    else
    {
      CCLog("[_apply_attribute_data_from_lua_attribute_table] error AttackType: %d", card_data->GetAttackType());
      assert(false);
    }


    //energy type(mana anger)
    if (card_data->GetSkillConsumeType() == kSkillConsumeTypeAnger)
    {
      //anger
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = BATTLE_ACTOR_ENEMGY_MAX
        + lua_attribute_table.get<float>(int(kCharacterAttrTypeAngerMax + 1));
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] * 0.5;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = lua_attribute_table.get<float>(int(kCharacterAttrTypeAngerRecover + 1));
    }
    else if (card_data->GetSkillConsumeType() == kSkillConsumeTypeMana)
    {
      //mana
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = BATTLE_ACTOR_ENEMGY_MAX
        + lua_attribute_table.get<float>(int(kCharacterAttrTypeManaMax + 1));
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax];
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = lua_attribute_table.get<float>(int(kCharacterAttrTypeManaRecover + 1));
    }
    else if (card_data->GetSkillConsumeType() == kSkillConsumeTypeNothing)
    {
      //nothing
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = 0;
    }
    else
    {
      CCLog("[_apply_attribute_data_from_lua_attribute_table] error SkillConsumeType: %d", card_data->GetSkillConsumeType());
      assert(false);
      //set to nothing
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = 1;
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover] = 0;
    }


    //additional set default
    battle_actor_data->attribute_map[kBattleAttributeActorInitHealthCurrent] = battle_actor_data->attribute_map[kBattleAttributeActorInitHealthMax];
    battle_actor_data->attribute_map[kBattleAttributeActorInitHealthRecover] = 0;


    //additional additional set default
    if (lua_attribute_table.get<float>(int(kCharacterAttrTypeHealthCurrent + 1)) > 0)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitHealthCurrent] = lua_attribute_table.get<float>(int(kCharacterAttrTypeHealthCurrent + 1));
    }
    if (lua_attribute_table.get<float>(int(kCharacterAttrTypeEnergyCurrent + 1)) > 0)
    {
      battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent] = lua_attribute_table.get<float>(int(kCharacterAttrTypeEnergyCurrent + 1));
    }
  }


  void _apply_attribute_data_from_overload_battle_actor_data(
    BattleActorData* battle_actor_data, 
    BattleActorData* overload_battle_actor_data)
  {
    std::map<eBattleAttributeType, float>::iterator iterator = overload_battle_actor_data->attribute_map.begin();

    while (iterator != overload_battle_actor_data->attribute_map.end())
    {
      eBattleAttributeType overload_key = iterator->first;
      float overload_value = iterator->second;

      battle_actor_data->attribute_map[overload_key] = overload_value;  //just set

      iterator ++;
    }
  }



  //skill data
  void _apply_skill_data_from_skill_table(
    BattleActorData* battle_actor_data, 
    int card_id)
  {
    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    assert(card_data);

    bool is_enemy;
    switch (card_data->GetEnemyGrade())
    {
    case kEnemyGradeLowBoss:
    case kEnemyGradeHighBoss:
    case kEnemyGradeWorldBoss:
      is_enemy = true;
      break;
    case kEnemyGradeSelf:
    case kEnemyGradeNormal:
    default:
      is_enemy = false;
      break;
    }

    //skill
    for (int skill_index = 0; skill_index < __battle_data_skill_array_size; skill_index++)
    {
      int skill_id = card_data->GetSkillId(__battle_data_skill_array_index[skill_index]);
      if (skill_id > 0)
      {
        eActorSkillType skill_type = __battle_data_skill_array_type[skill_index];
        int skill_level = is_enemy ? __battle_data_skill_array_level_default[skill_index] : __battle_data_skill_array_level_enemy[skill_index];

        ActorSkillInfo& skill_info = battle_actor_data->skill_info_map[skill_index];
        
        skill_info.skill_id = skill_id;
        skill_info.skill_type = skill_type;
        skill_info.skill_level = skill_level;

        SkillConfigData* skill_config_data = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_id);

        skill_info.skill_damage_scale = skill_config_data->GetDamageScaleBase() + skill_config_data->GetLevelAddDamageScale() * (skill_level - 1);
        skill_info.skill_energy_cost = skill_config_data->GetCostValue();
        skill_info.skill_energy_recover = skill_config_data->GetRecoverValue();
        skill_info.skill_cooldown = skill_config_data->GetCooldown();
        skill_info.skill_cooldown_current = skill_config_data->GetCooldownInit();
      }
    }
  }


  void _apply_skill_data_from_card_seq_id(
    BattleActorData* battle_actor_data, 
    int card_seq_id)
  {
    taomee::data::CharacterInfo* card_seq_info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(card_seq_id);
    assert(card_seq_info);

    _apply_skill_data_from_skill_table(battle_actor_data, card_seq_info->card_id());

    //flush skill level
    std::map<int, actor::ActorSkillInfo>::iterator iterator = battle_actor_data->skill_info_map.begin();
    while (iterator != battle_actor_data->skill_info_map.end())
    {
      int skill_index = iterator->first;
      ActorSkillInfo& skill_info = iterator->second;

      iterator ++;

      SkillConfigData* skill_config_data = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_info.skill_id);
      taomee::data::CharacterSkillInfo* card_skill_info = card_seq_info->GetSkillInfoBySkillID(skill_info.skill_id);

      if (skill_config_data && card_skill_info && card_skill_info->GetSkillLevel() > 0)
      {
        skill_info.skill_level = card_skill_info->GetSkillLevel();
        skill_info.skill_damage_scale = skill_config_data->GetDamageScaleBase() + skill_config_data->GetLevelAddDamageScale() * (card_skill_info->GetSkillLevel() - 1);
      }
      else
      {
        battle_actor_data->skill_info_map.erase(skill_index);
      }
    }
  }


  void _apply_skill_data_from_lua_skill_table(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_skill_table, 
    int card_id)
  {
    _apply_skill_data_from_skill_table(battle_actor_data, card_id);

    std::map<int, int> skill_id_level_map;

    int lua_skill_index = 1;
    while (true)
    {
      lua_tinker::table skill_data = lua_skill_table.get<lua_tinker::table>(lua_skill_index);

      int skill_id = skill_data.get<int>("skill_id");
      int skill_level = skill_data.get<int>("skill_level");

      if (skill_id > 0 && skill_level > 0)
      {
        skill_id_level_map[skill_id] = skill_level;
      }
      else
      {
        break;  //no more data
      }

      lua_skill_index ++;
    }


    //flush skill level
    std::map<int, actor::ActorSkillInfo>::iterator iterator = battle_actor_data->skill_info_map.begin();
    while (iterator != battle_actor_data->skill_info_map.end())
    {
      int skill_index = iterator->first;
      ActorSkillInfo& skill_info = iterator->second;

      iterator ++;

      SkillConfigData* skill_config_data = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_info.skill_id);

      if (skill_config_data && skill_id_level_map.find(skill_info.skill_id) != skill_id_level_map.end())
      {
        skill_info.skill_level = skill_id_level_map[skill_info.skill_id];
        skill_info.skill_damage_scale = skill_config_data->GetDamageScaleBase() + skill_config_data->GetLevelAddDamageScale() * (skill_info.skill_level - 1);
      }
      else
      {
        battle_actor_data->skill_info_map.erase(skill_index);
      }
    }
  }



  void _apply_skill_data_from_overload_battle_actor_data(
    BattleActorData* battle_actor_data, 
    BattleActorData* overload_battle_actor_data)
  {
    std::map<int, actor::ActorSkillInfo>::iterator iterator = overload_battle_actor_data->skill_info_map.begin();
    while (iterator != battle_actor_data->skill_info_map.end())
    {
      int skill_index = iterator->first;

      battle_actor_data->skill_info_map[skill_index] = iterator->second;

      iterator++;
    }
  }


  void _verify_actor_data(BattleActorData* battle_actor_data)
  {
    //verify required attribute
    for (int attribute_index = 0; attribute_index < __battle_data_attribute_required_array_size; attribute_index++)
    {
      assert(battle_actor_data->attribute_map.find(__battle_data_attribute_required_array[attribute_index]) 
        != battle_actor_data->attribute_map.end());
    }

    //verify required status
    for (int status_index = 0; status_index < __battle_data_status_required_array_size; status_index++)
    {
      assert(battle_actor_data->status_map.find(__battle_data_status_required_array[status_index]) 
        != battle_actor_data->status_map.end());
    }

    //verify required position
    bool is_set_required_position = false
      || battle_actor_data->position_map.find(kBattlePositionActorInit) != battle_actor_data->position_map.end()
      || battle_actor_data->position_map.find(kBattlePositionActorInitPlacingGrid) != battle_actor_data->position_map.end();

    assert(is_set_required_position);

    //check skill
    //CCLog("[_verify_actor_data] get init skill data size: %d", battle_actor_data->skill_info_map.size());
  }

  //==========================================================================================================
  //==========================================================================================================






  void FillActorAttributeDataFromCardIdLevelEvolveStar(
    BattleActorData* battle_actor_data, 
    int card_id, 
    int card_level/* = 1*/, 
    int card_evolve/* = 0*/, 
    int card_star/* = 0*/)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsSetDynamicAttributeData) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsSetDynamicAttributeData] = 1;

    _apply_attribute_data_from_card_table(
      battle_actor_data, 
      card_id, 
      card_level, 
      card_evolve, 
      card_star);
  }


  void FillActorAttributeDataFromCardSeqId(
    BattleActorData* battle_actor_data, 
    int card_seq_id)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsSetDynamicAttributeData) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsSetDynamicAttributeData] = 1;
    
    _apply_attribute_data_from_card_seq_id(
      battle_actor_data, 
      card_seq_id);
  }


  void FillActorAttributeDataFromLuaAttributeTable(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_attribute_table, 
    int card_id, 
    int card_level/* = 1*/, 
    int card_evolve/* = 0*/, 
    int card_star/* = 0*/)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsSetDynamicAttributeData) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsSetDynamicAttributeData] = 1;

    _apply_attribute_data_from_lua_attribute_table(
      battle_actor_data,
      lua_attribute_table, 
      card_id,
      card_level,
      card_evolve,
      card_star);
  }



  void FillActorSkillDataFromSkillLevel(
    BattleActorData* battle_actor_data, 
    int card_id,
    int skill_level/* = 1*/)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsSetDynamicSkillData) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsSetDynamicSkillData] = 1;

    _apply_skill_data_from_skill_table(
      battle_actor_data, 
      card_id);
  }
  
  
  void FillActorSkillDataFromCardSeqId(
    BattleActorData* battle_actor_data, 
    int card_seq_id)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsSetDynamicSkillData) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsSetDynamicSkillData] = 1;

    _apply_skill_data_from_card_seq_id(
      battle_actor_data, 
      card_seq_id);
  }



  void FillActorSkillDataFromLuaSkillTable(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_skill_table, 
    int card_id)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsSetDynamicSkillData) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsSetDynamicSkillData] = 1;

    _apply_skill_data_from_lua_skill_table(
      battle_actor_data, 
      lua_skill_table,
      card_id);
  }

  bool VerifyBattleActorData(BattleActorData* battle_actor_data)
  {
    assert(battle_actor_data->status_map.find(kBattleStatusActorInitMarkIsVarified) == battle_actor_data->status_map.end());
    battle_actor_data->status_map[kBattleStatusActorInitMarkIsVarified] = 1;

    _verify_actor_data(battle_actor_data);

    // TODO: move. mark boss
    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(battle_actor_data->status_map[kBattleStatusActorInitCardId]);
    switch (card_data->GetEnemyGrade())
    {
    case kEnemyGradeLowBoss:
    case kEnemyGradeHighBoss:
    case kEnemyGradeWorldBoss:
      battle_actor_data->status_map[kBattleStatusActorInitMarkIsWaveBoss] = 1;
      break;
    case kEnemyGradeSelf:
    case kEnemyGradeNormal:
    default:
      break;
    }

    return true;
  }







  //data transfer
  void ApplyActorAttribute(BattleActorData* battle_actor_data, actor::Actor* actor);
  void ApplyActorStatus(BattleActorData* battle_actor_data, actor::Actor* actor);
  void ApplyActorPosition(BattleActorData* battle_actor_data, actor::Actor* actor);
  void ApplyActorSkill(BattleActorData* battle_actor_data, actor::Actor* actor);
  void ApplyAdditionalActorDataFromCardData(actor::Actor* actor, int card_id);
  void ApplyAdditionalActorDataFromBattleData(actor::Actor* actor);

  bool ApplyBattleActorDataToActor(BattleActorData* battle_actor_data, actor::Actor* actor)
  {
    ApplyActorAttribute(battle_actor_data, actor);
    ApplyActorStatus(battle_actor_data, actor);
    ApplyActorPosition(battle_actor_data, actor);
    ApplyActorSkill(battle_actor_data, actor);
    ApplyAdditionalActorDataFromCardData(actor, battle_actor_data->status_map[battle_data::kBattleStatusActorInitCardId]);
    ApplyAdditionalActorDataFromBattleData(actor);

    // TODO: change to cpp-packed-lua-table
    //push data to lua_battle_data
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_id", actor->GetScriptObjectId());
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_model", actor->GetActorData()->GetActorStatus(kActorStatusActorModel));
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "card_id", actor->GetActorData()->GetActorStatus(kActorStatusCardId));
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "card_seq_id", battle_actor_data->status_map[kBattleStatusActorInitCardSeqId]);
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_level", actor->GetActorData()->GetActorStatus(kActorStatusLevel));
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_evolve", battle_actor_data->status_map[kBattleStatusActorInitEvolve]);
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_star", battle_actor_data->status_map[kBattleStatusActorInitStar]);
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_career", actor->GetActorData()->GetActorStatus(kActorStatusCareer));
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_faction", actor->GetActorData()->GetActorStatus(kActorStatusFaction));
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "SetLuaBattleActorData", actor->GetScriptObjectId(), "actor_appearance", actor->GetActorData()->GetActorStatus(kActorStatusAppearance));

    return true;
  }


  const eActorAttributeType __actor_data_set_limit_array[] = {
    kActorAttributeFactorCritical,
    kActorAttributeFactorHit,
    kActorAttributeFactorDodge,

    kActorAttributeSpeedAttack,
    kActorAttributeSpeedMove,

    kActorAttributeAttackPhysical,
    kActorAttributeAttackMagical,
    kActorAttributeAttackCritical,

    kActorAttributeDefensePhysical,
    kActorAttributeDefenseMagical,
    kActorAttributeDefenseCritical,

    kActorAttributeDamageAddition,
    kActorAttributeDamageAdditionPhysical,
    kActorAttributeDamageAdditionMagical,
    kActorAttributeDamageAdditionCritical,
    kActorAttributeDamageAdditionHealth,
    kActorAttributeDamageAdditionEnergy,

    kActorAttributeDamageReduction,
    kActorAttributeDamageReductionPhysical,
    kActorAttributeDamageReductionMagical,
    kActorAttributeDamageReductionCritical,
    kActorAttributeDamageReductionHealth,
    kActorAttributeDamageReductionEnergy
  };
  const int __actor_data_set_limit_array_size = CALC_ARRAY_LEN_BY_SIZE_OF(__actor_data_set_limit_array);

  void ApplyActorAttribute(BattleActorData* battle_actor_data, actor::Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();

    //init
    actor_data->InitActorAttribute(kActorAttributeTimeActive, 0);

    actor_data->InitActorAttribute(kActorAttributeKillCount, 0);
    
    actor_data->InitActorAttribute(kActorAttributeAttackCount, 0);
    actor_data->InitActorAttribute(kActorAttributeAttackNormalCount, 0);
    actor_data->InitActorAttribute(kActorAttributeAttackPowerCount, 0);
    actor_data->InitActorAttribute(kActorAttributeAttackSpecialCount, 0);

    //init and set limit
    for (int init_set_index = 0; init_set_index < __actor_data_set_limit_array_size; init_set_index++)
    {
      eActorAttributeType actor_attribute_key = __actor_data_set_limit_array[init_set_index];
      
      actor_data->InitActorAttribute(actor_attribute_key, 0);
      actor_data->GetActorAttributeData(actor_attribute_key)->SetLimit(0);
    }

    //attribute
    for (int convert_index = 0; convert_index < __battle_data_attribute_convert_array_size; convert_index++)
    {
      eBattleAttributeType battle_attribute_key = __battle_data_attribute_convert_array_battle_actor_init[convert_index];
      eActorAttributeType actor_attribute_key = __battle_data_attribute_convert_array_actor[convert_index];

      if (battle_actor_data->attribute_map.find(battle_attribute_key) != battle_actor_data->attribute_map.end())
        actor_data->InitActorAttribute(actor_attribute_key, battle_actor_data->attribute_map[battle_attribute_key]);
    }

    //special attribute
    actor_data->InitActorAttribute(actor::kActorAttributeHealthRecover, 0, battle_actor_data->attribute_map[kBattleAttributeActorInitHealthRecover]);
    actor_data->InitActorAttribute(actor::kActorAttributeHealthCurrent, 0, battle_actor_data->attribute_map[kBattleAttributeActorInitHealthCurrent]);
    actor_data->InitActorAttribute(actor::kActorAttributeEnergyMax, battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyMax]);    
    actor_data->InitActorAttribute(actor::kActorAttributeEnergyCurrent, 0, battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyCurrent]);
    actor_data->InitActorAttribute(actor::kActorAttributeEnergyRecover,0, battle_actor_data->attribute_map[kBattleAttributeActorInitEnergyRecover]);
  }



  void ApplyActorStatus(BattleActorData* battle_actor_data, actor::Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();

    //preset default
    actor_data->InitActorStatusBool(kActorStatusIsIncontrollable, false);
    actor_data->InitActorStatusBool(kActorStatusIsMuteMove, false);
    actor_data->InitActorStatusBool(kActorStatusIsMuteAttack, false);
    actor_data->InitActorStatusBool(kActorStatusIsMuteAttackNormal, false);
    actor_data->InitActorStatusBool(kActorStatusIsMuteAttackPower, false);
    actor_data->InitActorStatusBool(kActorStatusIsMuteAttackSpecial, false);
    actor_data->InitActorStatusBool(kActorStatusIsMuteGuard, false);

    actor_data->InitActorStatus(kActorStatusBornType, kActorBornDefault);
    actor_data->InitActorStatus(kActorStatusDeadType, kActorDeadDefault);

    actor_data->InitActorStatusBool(kActorStatusAcceptDamage, true);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamagePhysical, true);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageMagical, true);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageCritical, true);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageIce, true);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageFire, true);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageWind, true);

    actor_data->InitActorStatusBool(kActorStatusControlIsCounterAttack, false);

    actor_data->InitActorStatusBool(kActorStatusSkillIsPaused, false);
    actor_data->InitActorStatusBool(kActorStatusAnimationIsPaused, false);
    actor_data->InitActorStatusBool(kActorStatusAnimationIsFocused, false);
    actor_data->InitActorStatusBool(kActorStatusAnimationIsHealthChanged, false);

    actor_data->InitActorStatus(kActorStatusLogicState, ACTOR_INVALID_ID);
    actor_data->InitActorStatus(kActorStatusMotionState, ACTOR_INVALID_ID);

    actor_data->InitActorStatus(kActorStatusControlAutoGuardType, kActorControlAutoGuardInvalid);

    actor_data->InitActorStatusBool(kActorStatusMotionIsBusy, false);
    actor_data->InitActorStatusBool(kActorStatusSkillIsBusy, false);

    actor_data->InitActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);

    actor_data->InitActorStatus(kActorStatusBuffShaderType, shader::kShaderDefault);
    actor_data->InitActorStatusBool(kActorStatusBuffIsPauseAnimation, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsChangeColor, false);

    actor_data->InitActorStatusBool(kActorStatusBuffIsIncontrollable, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsMuteMove, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsMuteAttack, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsMuteAttackNormal, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsMuteAttackPower, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsMuteAttackSpecial, false);
    actor_data->InitActorStatusBool(kActorStatusBuffIsMuteGuard, false);

    //status
    for (int convert_index = 0; convert_index < __battle_data_status_convert_array_size; convert_index++)
    {
      eBattleStatusType battle_status_key = __battle_data_status_convert_array_battle_actor_init[convert_index];
      eActorStatusType actor_status_key = __battle_data_status_convert_array_actor[convert_index];

      if (battle_actor_data->status_map.find(battle_status_key) != battle_actor_data->status_map.end())
        actor_data->InitActorStatus(actor_status_key, battle_actor_data->status_map[battle_status_key]);
    }

    //opposite init placing direction from Home direction
    actor_data->InitActorStatus(kActorStatusAnimationDirection, 
      actor_data->GetActorStatus(kActorStatusHomeDirection) == kActorAnimationDirectionRight 
        ? kActorAnimationDirectionLeft 
        : kActorAnimationDirectionRight);
  }



  void ApplyActorPosition(BattleActorData* battle_actor_data, actor::Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();

    //preset default
    actor_data->InitActorPosition(kActorPositionMotionMoveTarget, ccp(0, 0));
    actor_data->InitActorPosition(kActorPositionMotionMoveSpeedUnit, ccp(0, 0));

    //position
    actor_data->InitActorPosition(kActorPositionAnimation, battle_actor_data->position_map[kBattlePositionActorInit]);
    actor_data->InitActorPosition(kActorPositionTargetGridBorn, battle_actor_data->position_map[kBattlePositionActorInitTargetGridBorn]);
  }


  void ApplyActorSkill(BattleActorData* battle_actor_data, actor::Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();

    //skill
    std::map<int, actor::ActorSkillInfo>::iterator iterator = battle_actor_data->skill_info_map.begin();
    while (iterator != battle_actor_data->skill_info_map.end())
    {
      actor::ActorSkillInfo* skill_info = &(iterator->second);

      if (skill_info->skill_level > 0)
        actor_data->GetSkillData()->AddSkillInfo(*skill_info);

      iterator ++;
    }
  }


  void ApplyAdditionalActorDataFromCardData(actor::Actor* actor, int card_id)
  {
    actor::ActorData* actor_data = actor->GetActorData();

    CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
    assert(card_data);

    actor->SetScriptObjectName(card_data->GetName()); //the actor name used for log and animation resource

    actor_data->InitActorAttribute(kActorAttributeSpeedMove, actor_data->GetActorAttribute(kActorAttributeSpeedMove) * GetGridBoxAverageWidth());

    //scale
    actor_data->InitActorAttribute(kActorAttributeAnimationScale, card_data->GetSkeletonScale());
    actor_data->InitActorAttribute(kActorAttributeTriggerSizeScaleAttack, 1.0f);  // TODO: current not changeable
    actor_data->InitActorAttribute(kActorAttributeTriggerSizeScaleGuard, 1.0f * card_data->GetPatrolScale());

    //for enemy pawn?
    actor_data->InitActorStatus(kActorStatusControlAutoReleaseSpecialSkillCount, card_data->GetSkillRate());

    //appearance
    switch (card_data->GetEnemyGrade())
    {
    case kEnemyGradeSelf:
      actor_data->InitActorStatus(kActorStatusAppearance, kActorAppearanceCharacter);
      break;
    case kEnemyGradeNormal:
      actor_data->InitActorStatus(kActorStatusAppearance, kActorAppearanceEnemyPawn);
      break;
    case kEnemyGradeLowBoss:
    case kEnemyGradeHighBoss:
    case kEnemyGradeWorldBoss:
      actor_data->InitActorStatus(kActorStatusAppearance, kActorAppearanceEnemyBoss);
      break;
    default:
      assert(false);
      break;
    }


    //init element
    ActorBuffStatusBitSet status_bit_set;
    switch (card_data->GetElementFlag())
    {
    case kCardElementFire:
      status_bit_set.set(kActorBuffStatusElementFire);
      break;
    case kCardElementWater:
      status_bit_set.set(kActorBuffStatusElementWater);
      break;
    case kCardElementWind:
      status_bit_set.set(kActorBuffStatusElementWind);
      break;
    case kCardElementLight:
      status_bit_set.set(kActorBuffStatusElementLight);
      break;
    case kCardElementDark:
      status_bit_set.set(kActorBuffStatusElementDark);
      break;
    default:
      break;
    }
    actor_data->GetBuffData()->AddBuffStatusBitSet(status_bit_set, kActorBuffStatusStateAdd);


    //career
    switch (taomee::army::eCareerType(card_data->GetJobType()))
    {
    case taomee::army::kCareerTypeWarrior:
      actor_data->InitActorStatus(kActorStatusCareer, kActorCareerWarrior);
      break;
    case taomee::army::kCareerTypeArcher:
      actor_data->InitActorStatus(kActorStatusCareer, kActorCareerArcher);
      break;
    case taomee::army::kCareerTypeWizard:
      actor_data->InitActorStatus(kActorStatusCareer, kActorCareerWizard);
      break;
    case taomee::army::kCareerTypeMonk:
      actor_data->InitActorStatus(kActorStatusCareer, kActorCareerPriest);
      break;
    case taomee::army::kCareerTypeKnight:
      actor_data->InitActorStatus(kActorStatusCareer, kActorCareerKnight);
      break;
    default:
      actor_data->InitActorStatus(kActorStatusCareer, kActorCareer);
      break;
    }

    
    //attack type
    switch (taomee::army::eAttackType(card_data->GetAILogicType()))
    {
    case taomee::army::kAttackTypeAttack:
      actor_data->InitActorStatus(kActorStatusSkillAttackType, kActorAttackMelee);
      actor_data->InitActorStatus(kActorStatusSkillGuardType, kActorGuardMelee);
      actor_data->InitActorStatus(kActorStatusSkillAutoType, kActorAutoNearFirst);
      break;
    case taomee::army::kAttackTypeShot:
      actor_data->InitActorStatus(kActorStatusSkillAttackType, kActorAttackRanged);
      actor_data->InitActorStatus(kActorStatusSkillGuardType, kActorGuardRanged);
      actor_data->InitActorStatus(kActorStatusSkillAutoType, kActorAutoSameRowFirst);
      break;
    case taomee::army::kAttackTypeHeal:
      actor_data->InitActorStatus(kActorStatusSkillAttackType, kActorAttackHeal);
      actor_data->InitActorStatus(kActorStatusSkillGuardType, kActorGuardRanged);
      actor_data->InitActorStatus(kActorStatusSkillAutoType, kActorAutoSameRowFirst);
      break;
    default:
      actor_data->InitActorStatus(kActorStatusSkillAttackType, kActorAttack);  //not attack
      actor_data->InitActorStatus(kActorStatusSkillGuardType, kActorGuard);
      actor_data->InitActorStatus(kActorStatusSkillAutoType, kActorAuto);
      break;
    }


    //set attack cycle
    std::string attack_cycle = card_data->GetAttackCycle();
    if (attack_cycle == "")
    {
      actor_data->GetLog()->AddErrorLogF("[ApplyAdditionalActorDataFromCardData] empty skill cycle! default [0|0|0|1] used");
      assert(false);
      attack_cycle = "0|0|0|1";
    }
    actor_data->GetSkillData()->SetSkillCycleList(attack_cycle);
  }


  void ApplyAdditionalActorDataFromBattleData(actor::Actor* actor)
  {
    actor::ActorData* actor_data = actor->GetActorData();

    battle_data::BattleDataCenter* battle_data_center = taomee::battle::BattleController::GetInstance().GetBattleDataCenter();
    taomee::battle::eBattleType battle_type = taomee::battle::eBattleType(battle_data_center->GetBattleStatus(kBattleStatusBattleType));
    taomee::battle::eBattleSceneType scene_type = taomee::battle::eBattleSceneType(battle_data_center->GetBattleStatus(kBattleStatusSceneType));

    bool is_battle_user_manual = (battle_type == taomee::battle::kBattleType_PVE_Manual 
      || battle_type == taomee::battle::kBattleType_PVP_Manual
      || battle_type == taomee::battle::kBattleType_Sandbox);
    bool is_battle_pvp = (battle_type == taomee::battle::kBattleType_PVP_Auto 
      || battle_type == taomee::battle::kBattleType_PVP_Manual);
    bool is_actor_user_support = actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport;
    bool is_actor_controllable = is_actor_user_support && is_battle_user_manual;
    
    //control
    actor_data->InitActorStatusBool(kActorStatusControlIsManual, is_actor_controllable);
    actor_data->InitActorStatusBool(kActorStatusControlIsAuto, !is_actor_controllable);

    actor_data->InitActorStatusBool(kActorStatusSpecifiedIsLimitGridX, is_actor_controllable);
    

    //auto guard (has more logic in ActorControl), PVP type, attack front first, but not for UserSupport
    if (is_battle_pvp && !is_actor_controllable)
    {
      actor_data->InitActorStatusBool(kActorStatusBuffIsMuteGuard, true); //disable guard trigger check, may cause unwanted row switch
      actor_data->InitActorStatus(kActorStatusControlAutoGuardType, kActorControlAutoGuardPreferY);
    }
    else
    {
      actor_data->InitActorStatus(kActorStatusControlAutoGuardType, kActorControlAutoGuardDefault);
    }


    //init control auto release skill type
    if (is_actor_user_support)
    {
      actor_data->InitActorStatus(kActorStatusControlAutoReleaseSpecialSkillType, is_battle_pvp 
        ? kActorControlAutoReleaseSkillNoPause
        : kActorControlAutoReleaseSkillWithPause);
    }
    else
    {
      if (actor_data->GetSkillData()->GetSkillIdByType(kActorSkillSpecial) > 0
        && actor_data->GetActorStatus(kActorStatusControlAutoReleaseSpecialSkillCount) > 0)
      {
        //has preset kActorStatusControlAutoReleaseSpecialSkillCount
        actor_data->InitActorStatus(kActorStatusControlAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillByAttackCount);
      }
      else
      {
        actor_data->InitActorStatus(kActorStatusControlAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillInvalid);
      }
    }
  }



  bool FollowUpActorInitAfterAnimationInit(actor::Actor* actor)
  {
    actor::ActorData* actor_data = actor->GetActorData();


    //attack trigger(actor animation needed for actor box)
    float actor_attack_trigger_size_multiplier = actor_data->GetActorAttribute(kActorAttributeTriggerSizeScaleAttack);
    switch (actor_data->GetActorStatus(kActorStatusSkillAttackType))
    {
    case kActorAttackMelee:
      actor_data->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerCircle, actor, actor_attack_trigger_size_multiplier));
      break;
    case kActorAttackHeal:
      actor_data->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerHeal, actor, actor_attack_trigger_size_multiplier));
      break;
    case kActorAttackRanged:
      actor_data->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerRect, actor, actor_attack_trigger_size_multiplier));
      break;
    default:
      actor_data->GetSkillData()->SetAttackTrigger(NULL);
      break;
    }

    //guard trigger(actor animation needed for actor box)
    float actor_guard_trigger_size_multiplier = actor_data->GetActorAttribute(kActorAttributeTriggerSizeScaleGuard);
    switch (actor_data->GetActorStatus(kActorStatusSkillGuardType))
    {
    case kActorGuardMelee:
      actor_data->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerCircle, actor, actor_guard_trigger_size_multiplier));
      break;
    case kActorGuardRanged:
      actor_data->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerRect, actor, actor_guard_trigger_size_multiplier));
      break;
    default:
      actor_data->GetSkillData()->SetGuardTrigger(NULL);
      break;
    }

    //auto guard trigger
    switch (actor_data->GetActorStatus(kActorStatusSkillAutoType))
    {
    case kActorAutoNearFirst:
      actor_data->GetSkillData()->SetAutoTrigger(GetPredefinedAutoTrigger(kActorPredefinedAutoTriggerNearFirst, actor));
      break;
    case kActorAutoSameRowFirst:
      actor_data->GetSkillData()->SetAutoTrigger(GetPredefinedAutoTrigger(kActorPredefinedAutoTriggerSameRowFirst, actor));
      break;
    default:
      actor_data->GetSkillData()->SetAutoTrigger(NULL);
      break;
    }


    //monster not auto guard by default
    if (actor_data->GetActorStatus(kActorStatusAppearance) != kActorAppearanceCharacter
      && actor_data->GetSkillData()->GetAutoTrigger())
    {
      //auto guard will be called directly by UpdateSpecialGuard in actor routine control
      actor_data->GetSkillData()->GetAutoTrigger()->SetIsPause(true);
    }


    //switch to initial logic state: Born
    actor_data->GetControlData()->AddIdOperation(kActorControlOperationTypeBorn, kActorControlPriorityBorn, actor_data->GetActorStatus(kActorStatusBornType));  //mute other operation with higher priority
    actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateBorn));


    return true;
  }





} // namespace battle_data