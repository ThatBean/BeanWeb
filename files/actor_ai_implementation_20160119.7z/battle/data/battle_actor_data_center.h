#ifndef BATTLE_ACTOR_DATA_CENTER
#define BATTLE_ACTOR_DATA_CENTER

#include "battle_data_typedef.h"

#include "battle_data_transfer_actor.h"

#include "game/actor/typedef/actor_data_typedef.h"

#include "game/actor/template_class/actor_data_class.h"
#include "game/actor/template_class/actor_data_map_class.h"
#include "game/actor/template_class/data_log.h"

#include "engine/base/cocos2d_wrapper.h"


/*
    Actor Data Generate Route
      [Card Attribute Data]
        CardId + Level ---> <Card Table Data> ---> Base Data
          + CardSeqId/PvpData ---> Star/Evolve Attribute Add-on
          + CardSeqId/PvpData ---> Rune Attribute Add-on
          + CardSeqId/PvpData ---> Passive Skill Attribute Add-on
          + OverloadData ---> Overload Attribute Add-on

      [Skill Data]
        CardId + SkillLevelList ---> <Card Table Data> ---> <Skill Table Data> ---> Base Skill Data
          + CardSeqId/PvpData ---> Skill Level overload
          + OverloadData ---> Skill Level overload

    Generated data should be enough for battle(no original-data access needed)
*/

namespace taomee {
  namespace army {
    class MoveObject;
  }
}

namespace actor {	
  class Actor;
}

namespace battle_data {
  class BattleDataCenter;
  class BattleDataSignalData;
  
  class BattleActorDataCenter
  {
  public:
    BattleActorDataCenter(BattleDataCenter* battle_data_center);
    ~BattleActorDataCenter();

    void ResetData(); //reset all data
    void RemoveAllBattleActor();  //Actor only, not remove BattleActorData
    void RemoveAllBattleActorData();  //BattleActorData and Actor, will call RemoveAllBattleActor

    void Init();

    void Update(float delta_time);  //auto pop actor by time to pending_battle_actor_data_map_, then create actor in pending_battle_actor_data_map_
    
    void DispenseWaveRecover(); //add Health & Energy for all Living Actor by BattleActorData
    
    void ResetBattleActorForBattleResult(); //for battle result

    actor::DataLog* GetLog();

  public: //Both Cpp and Lua
    //actor data related
    int AddBattleActorData(BattleActorData* battle_actor_data); //actor_id starts from 0, set in battle_actor_data for force setting, return auto id if needed
    void RemoveBattleActorData(int actor_id); //notice: will also remove Actor, if there is one
    bool CheckBattleActorData(int actor_id);
    BattleActorData* GetBattleActorData(int actor_id);
    std::map<int, BattleActorData*>& GetBattleActorDataMap();

    int GetBattleActorDataCount();
    std::list<int> GetBattleActorDataIdList();
    void FlushPendingBattleActor();

    //spawn wave & time related
    void SetActorWave(int actor_id, float spawn_delay_time = -1, int wave_id = -1); //wave_id in battle starts from 1, wave_id = 0 for instant create, for force setting wave_id > current wave_size, will create wave if wave not exist (wave >= 0)
    void SetWaveSize(int wave_size);
    int AddNewWave();  //= SetWaveSize(wave_size + 1);
    void VerifyWaveData();
    std::list<BattleActorData*>* GetBattleActorDataListByWaveOrder();  //need delete after use

    //wave switch
    void WaveSwitch();  //switch to next wave


  protected:
    void UpdateWave(float delta_time);
    void CreateBattleActorFromBattleActorData(BattleActorData* battle_actor_data); //create an actor from BattleActorData and add to battle, currently messy, will use battle hub and create MoveObject
    void RemoveBattleActor(actor::Actor* actor);
    
    void ConnectDataSignal(); //link OnDataOperation to selected signal
    void OnDataOperation(int operation_type, int battle_data_type, BattleDataSignalData* signal_data); //callback for data operation signal

  private:
    void PushWaveActorToPendingBattleActorMap(int wave_id, float wave_time); //push all actor before wave_time in wave with wave_id to pending_battle_actor_data_map_, wave_time < 0 for a flush(push all)
    void RefreshCurrentWaveLeftActorCount();

  private:
    BattleDataCenter* battle_data_center_;

    std::map<int, std::map<int, int > > wave_map_;  //wave_map_[wave_number][spawn_delay_sec * 1000] = actor_id, wave_number = 0 for instant create actor

    std::map<int, BattleActorData*> battle_actor_data_map_;

    std::map<int, BattleActorData*> pending_battle_actor_data_map_;  //actor_id + BattleActorData
  };

} // namespace battle_data




#endif
