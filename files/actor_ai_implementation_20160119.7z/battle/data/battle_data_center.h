#ifndef BATTLE_DATA_CENTER
#define BATTLE_DATA_CENTER

#include "battle_data_typedef.h"

#include "battle_actor_data_center.h"
#include "battle_data_transfer_actor.h"

#include "game/actor/typedef/actor_data_typedef.h"

#include "game/actor/template_class/actor_data_class.h"
#include "game/actor/template_class/actor_data_map_class.h"
#include "game/actor/template_class/data_log.h"

#include "engine/base/cocos2d_wrapper.h"

// Battle Data Flow:
//     
//     [CITY]:
//     UI - gather battle init data
// to battle ----------------------------------------------------------------------------------------
//         [CITY] -> [BATTLE]
//         LuaBattleController - battle type, scene type, checkpoint id, pvp target user id...
//             BattleController - Clear Data
//             BattleDataCenter - Clear Data
//             LuaBattleData - Clear Data
//             LuaBattleData - pvp target user id
//             BattleDataCenter - battle type, scene type, checkpoint id, actor data
// init battle data ---------------------------------------------------------------------------------
//                 [Message: Start]
//                 LuaBattleMessage - Clear Data
//                 LuaBattleMessage - drop item, actor data
// battle start -------------------------------------------------------------------------------------
//                     [BATTLE]:
//                     BattleController - Control Data: battle pause, touch
//                         BattleDataCenter - Battle Data: battle type, scene type, checkpoint id
//                         ActorExtEnv - Actor Data: actor id, hp, en, pos...
//                         LevelBase - Level Logic: win condition, time limit check
// battle end ---------------------------------------------------------------------------------------
//                             [Message: Win/Lost/Exit]
//                             LuaBattleMessage - Clear Data
//                             LuaBattleMessage - gain item
// display battle result ----------------------------------------------------------------------------
//                                 [RESULT UI]
//                                 ActorExtEnv - Clear Data
// clear remain data --------------------------------------------------------------------------------
//                                     [BATTLE] -> [CITY]
//                                     BattleController - Clear Data
//                                     BattleDataCenter - Clear Data
//                                     LevelBase - Clear Data
// to city ------------------------------------------------------------------------------------------
//                                         [CITY]
//                                         LuaBattleData - still valid until next battle
//                                         LuaBattleMessage - still valid until next battle

namespace actor {	
  class Actor;
}

namespace taomee {
  namespace battle {
    class BattleController;
  }
}

namespace battle_data {

  class BattleActorDataCenter;

  class BattleDataCenter;
  class BattleDataSignalData;

  typedef actor::ActorTemplateAttributeData<BattleDataSignalData> BattleAttributeData;
  typedef actor::ActorTemplateStatusData<BattleDataSignalData> BattleStatusData;
  typedef actor::ActorTemplatePositionData<BattleDataSignalData> BattlePositionData;

  typedef actor::ActorTemplateAttributeDataMap<BattleDataSignalData, eBattleAttributeType> BattleAttributeMap;
  typedef actor::ActorTemplateStatusDataMap<BattleDataSignalData, eBattleStatusType> BattleStatusMap;
  typedef actor::ActorTemplatePositionDataMap<BattleDataSignalData, eBattlePositionType> BattlePositionMap;

  class BattleDataSignalData 
  {
  public:
    BattleDataSignalData() 
      : key(-1)
      , type(-1)
      , battle_data_center(NULL)
      , battle_controller(NULL)
    {}
    ~BattleDataSignalData() {}

    int key;  //for specific, non-default
    int type; //for signal type
    BattleDataCenter* battle_data_center;  //self reference
    taomee::battle::BattleController* battle_controller;  //self reference
  };



  class BattleActorData {
  public:
    BattleActorData()
      : actor_id(-1)
    {

    }

    ~BattleActorData()
    {
      //Debug Use
    }

    int actor_id; //-1 for auto decide ()

    std::map<eBattleStatusType, int> status_map;                //eBattleStatusType
    std::map<eBattleAttributeType, float> attribute_map;           //eBattleAttributeType
    std::map<eBattlePositionType, cocos2d::CCPoint> position_map; //eBattlePositionType

    std::map<int, actor::ActorSkillInfo> skill_info_map;

    //Lua only
    static BattleActorData* Create() { return new BattleActorData(); }

    void SetActorID(int value) { actor_id = value; }
    int GetActorID() { return actor_id; }

    void SetStatus(eBattleStatusType key, int value) { status_map[key] = value; }
    void SetAttribute(eBattleAttributeType key, float value) { attribute_map[key] = value; }
    void SetPosition(eBattlePositionType key, cocos2d::CCPoint value) { position_map[key] = value; }

    bool CheckStatus(eBattleStatusType key) { return status_map.find(key) != status_map.end(); }
    bool CheckAttribute(eBattleAttributeType key) { return attribute_map.find(key) != attribute_map.end(); }
    bool CheckPosition(eBattlePositionType key) { return position_map.find(key) != position_map.end(); }

    int GetStatus(eBattleStatusType key) { return status_map[key]; }
    float GetAttribute(eBattleAttributeType key) { return attribute_map[key]; }
    cocos2d::CCPoint GetPosition(eBattlePositionType key) { return position_map[key]; }

    void SetSkill(int skill_index, int skill_id, int skill_level, int skill_type)
    {
      skill_info_map[skill_index].skill_id = skill_id;
      skill_info_map[skill_index].skill_level = skill_level;
      skill_info_map[skill_index].skill_type = actor::eActorSkillType(skill_type);
    }
    bool CheckSkill(int skill_index) { return skill_info_map.find(skill_index) != skill_info_map.end(); }
    int GetSkillId(int skill_index) { return skill_info_map[skill_index].skill_id; }
    int GetSkillLevel(int skill_index) { return skill_info_map[skill_index].skill_level; }
    int GetSkillType(int skill_index) { return skill_info_map[skill_index].skill_type; }
  };


  class BattleDataCenter
  {
  public:
    BattleDataCenter(taomee::battle::BattleController* battle_controller);
    ~BattleDataCenter();

    void Init(int battle_type, int scene_type, int level_id);
    void ResetData(); //reset all data
    void Update(float delta_time);  //


    //access data map
    BattleAttributeMap*  GetAttributeMap() { return &attribute_map_; }
    BattleStatusMap*     GetStatusMap() { return &status_map_; }
    BattlePositionMap*   GetPositionMap() { return &position_map_; }

    BattleAttributeData* GetBattleAttributeData(eBattleAttributeType data_key) { return attribute_map_.GetData(data_key); }
    BattleStatusData* GetBattleStatusData(eBattleStatusType data_key) { return status_map_.GetData(data_key); }
    BattlePositionData* GetBattlePositionData(eBattlePositionType data_key) { return position_map_.GetData(data_key); }

    //debug use log record
    actor::DataLog* GetLog() { return data_log_; }

  public: //Both Cpp and Lua
    taomee::battle::BattleController* GetBattleController() { return battle_controller_; }
    BattleActorDataCenter* GetBattleActorDataCenter() { return battle_actor_data_center_; }


    //// Data with predefined enum keys
    bool CheckBattleAttribute(eBattleAttributeType data_key) { return attribute_map_.Check(data_key); }

    void  InitBattleAttribute(eBattleAttributeType data_key, float base = 0, float add = 0, float multiplier = 1, float extra = 0) 
    { 
      BattleAttributeData* data = attribute_map_.GetData(data_key);
      data->SetDefault(data_key, &default_attribute_signal_data_);
      data->Init(base, add, multiplier, extra);
    }
    void  SetBattleAttribute(eBattleAttributeType data_key, float add = 0, float multiplier = 1, float extra = 0) { attribute_map_.Set(data_key, add, multiplier, extra); }
    void  AddBattleAttribute(eBattleAttributeType data_key, float add = 0, float multiplier = 0, float extra = 0) { attribute_map_.Add(data_key, add, multiplier, extra); }
    float GetBattleAttribute(eBattleAttributeType data_key) { return attribute_map_.Get(data_key); }


    //direct access to BattleStatusData
    bool CheckBattleStatus(eBattleStatusType data_key) { return status_map_.Check(data_key); }

    void  InitBattleStatus(eBattleStatusType data_key, int status) 
    { 
      BattleStatusData* data = status_map_.GetData(data_key);
      data->SetDefault(data_key, &default_status_signal_data_);
      data->Init(status);
    }
    void  SetBattleStatus(eBattleStatusType data_key, int status) { status_map_.Set(data_key, status); }
    int   GetBattleStatus(eBattleStatusType data_key) { return status_map_.Get(data_key); }

    void  InitBattleStatusBool(eBattleStatusType data_key, bool bool_status) 
    { 
      BattleStatusData* data = status_map_.GetData(data_key);
      data->SetDefault(data_key, &default_status_signal_data_);
      data->InitBool(bool_status);
    }
    void  SetBattleStatusBool(eBattleStatusType data_key, bool bool_status) { status_map_.SetBool(data_key, bool_status); }
    bool  GetBattleStatusBool(eBattleStatusType data_key) { return status_map_.GetBool(data_key); }


    //direct access to BattlePositionData
    bool CheckBattlePosition(eBattlePositionType data_key) { return position_map_.Check(data_key); }

    void  InitBattlePosition(eBattlePositionType data_key, cocos2d::CCPoint position) 
    { 
      BattlePositionData* data = position_map_.GetData(data_key);
      data->SetDefault(data_key, &default_position_signal_data_);
      data->Init(position);
    }
    void  SetBattlePosition(eBattlePositionType data_key, cocos2d::CCPoint position) { position_map_.Set(data_key, position); }
    cocos2d::CCPoint&   GetBattlePosition(eBattlePositionType data_key) { return position_map_.Get(data_key); }

  protected:
    void ConnectDataSignal(); //link OnDataOperation to selected signal
    void OnDataOperation(int operation_type, int battle_data_type, BattleDataSignalData* signal_data); //callback for data operation signal


  private:
    taomee::battle::BattleController* battle_controller_;

    BattleActorDataCenter* battle_actor_data_center_;

    actor::DataLog* data_log_; //debug use

    //key reserved, limited to declared type enum only
    BattleAttributeMap  attribute_map_;
    BattleStatusMap     status_map_;
    BattlePositionMap   position_map_;

    BattleDataSignalData   default_attribute_signal_data_;
    BattleDataSignalData   default_status_signal_data_;
    BattleDataSignalData   default_position_signal_data_;
  };

} // namespace battle_data




#endif
