#include "battle_actor_data_center.h"
#include "battle_data_center.h"

#include "game/battle/battle_controller.h"
#include "game/battle/level/levelbase.h"
#include "game/battle/view/battle_view.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext_env.h"
#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/typedef/actor_animation_data_typedef.h"
#include "game/actor/animation/actor_animation_overhead_layer.h"

#include "game/data_table/data_constant.h"
#include "game/data_table/character_data_table.h"
#include "game/data_table/role_data_table.h"
#include "game/user_data/character_info.h"

#include "engine/animation/skeleton_animation.h"

#include "engine/script/lua_data_tunnel.h"



using namespace cocos2d;
using namespace cocos2d::extension;

using namespace actor;

namespace battle_data {

  BattleActorDataCenter::BattleActorDataCenter(BattleDataCenter* battle_data_center)
  {
    battle_data_center_ = battle_data_center;
  }

  BattleActorDataCenter::~BattleActorDataCenter()
  {
    ResetData();
  }

  void BattleActorDataCenter::Init()
  {
    ResetData();

    ConnectDataSignal();
  }

  void BattleActorDataCenter::ResetData()
  {
    RemoveAllBattleActor();
    RemoveAllBattleActorData();

    wave_map_.clear();

    assert(battle_actor_data_map_.empty());
    battle_actor_data_map_.clear();

    //keep more log
    //GetLog()->Clear();

    GetLog()->AddLog("[BattleActorDataCenter][ResetData]");
    GetLog()->ResetStartTime();
  }



  void BattleActorDataCenter::Update(float delta_time)
  {
    UpdateWave(delta_time);

    //create actor in pending_battle_actor_data_map_, and clean up pending_battle_actor_data_map_
    std::map<int, BattleActorData*>::iterator iterator_pending_battle_actor_data_map_ = pending_battle_actor_data_map_.begin();
    while (iterator_pending_battle_actor_data_map_ != pending_battle_actor_data_map_.end())
    {
      int actor_id = iterator_pending_battle_actor_data_map_->first;
      BattleActorData* battle_actor_data = iterator_pending_battle_actor_data_map_->second;

      assert(actor_id == battle_actor_data->actor_id);

      CreateBattleActorFromBattleActorData(battle_actor_data);//create and put into battle field

      iterator_pending_battle_actor_data_map_ ++;
    }
    pending_battle_actor_data_map_.clear();


    //update and picking non-active actor and ready to deletion
    std::list<actor::Actor*> pending_remove_actor_map_;

    std::map<int, actor::Actor*>* actor_map = battle_data_center_->GetBattleController()->GetActorExtEnv()->GetActorMap();
    std::map<int, actor::Actor*>::iterator iterator_actor_map = actor_map->begin();
    while (iterator_actor_map != actor_map->end())
    {
      int actor_id = iterator_actor_map->first;
      Actor* actor = iterator_actor_map->second;

      if (!actor->GetScriptObjectIsActive())
      {
        pending_remove_actor_map_.push_back(actor);
      }

      iterator_actor_map ++;
    }


    //loop and delete actors
    std::list<actor::Actor*>::iterator iterator_pending_remove_actor_map_ = pending_remove_actor_map_.begin();
    while (iterator_pending_remove_actor_map_ != pending_remove_actor_map_.end())
    {
      Actor* actor = *iterator_pending_remove_actor_map_;

      RemoveBattleActor(actor);

      iterator_pending_remove_actor_map_ ++;
    }
    pending_remove_actor_map_.clear();
  }


  void BattleActorDataCenter::DispenseWaveRecover()
  {
    std::list<Actor*>* actor_list = battle_data_center_->GetBattleController()->GetActorExtEnv()->GetActorList();
    std::list<Actor*>::iterator iterator_actor_list = actor_list->begin();
    while (iterator_actor_list != actor_list->end())
    {
      Actor* actor = *iterator_actor_list;
      BattleActorData* battle_actor_data = GetBattleActorData(actor->GetScriptObjectId());

      assert(battle_actor_data);  //just checking

      actor->GetActorData()->AddActorAttribute(actor::kActorAttributeHealthCurrent, battle_actor_data->attribute_map[kBattleAttributeActorInitWaveHealthRecover]);
      actor->GetActorData()->AddActorAttribute(actor::kActorAttributeEnergyCurrent, battle_actor_data->attribute_map[kBattleAttributeActorInitWaveEnergyRecover]);

      iterator_actor_list ++;
    }
    delete actor_list;
  }



  void BattleActorDataCenter::RemoveAllBattleActor()
  {
    //pick all actor and ready to deletion
    std::list<actor::Actor*> pending_remove_actor_map_;
    std::map<int, actor::Actor*>* actor_map = battle_data_center_->GetBattleController()->GetActorExtEnv()->GetActorMap();
    for (std::map<int, actor::Actor*>::iterator iterator = actor_map->begin(); iterator != actor_map->end(); iterator ++)
    {
      int actor_id = iterator->first;
      Actor* actor = iterator->second;

      pending_remove_actor_map_.push_back(actor);
    }


    //loop and delete actors
    for (std::list<actor::Actor*>::iterator iterator = pending_remove_actor_map_.begin(); iterator != pending_remove_actor_map_.end(); iterator ++)
    {
      Actor* actor = *iterator;

      RemoveBattleActor(actor);
    }
    pending_remove_actor_map_.clear();
  }


  void BattleActorDataCenter::RemoveAllBattleActorData()
  {
    while(battle_actor_data_map_.size() > 0)
    {
      int actor_id = battle_actor_data_map_.begin()->first;
      RemoveBattleActorData(actor_id);
    }
  }


  int BattleActorDataCenter::AddBattleActorData(BattleActorData* battle_actor_data)
  {
    CCLog("[BattleActorDataCenter][AddBattleActorData] battle_actor_data: %p, actor_id: %d", battle_actor_data, battle_actor_data->actor_id);

    if (!battle_actor_data)
    {
      return ACTOR_INVALID_ID;
    }

    if (!VerifyBattleActorData(battle_actor_data))
    {
      delete battle_actor_data;
      return ACTOR_INVALID_ID;
    }

    //decide actor_id
    int actor_id = battle_actor_data->actor_id;

    if (actor_id == BATTLE_INVALID_ID) 
    {
      //seems to be a nice start
      actor_id = battle_actor_data_map_.size();

      //loop for valid id
      while(battle_actor_data_map_.find(actor_id) != battle_actor_data_map_.end())
      {
        actor_id ++;
      }

    }

    assert(battle_actor_data_map_.find(actor_id) == battle_actor_data_map_.end());

    GetLog()->AddLogF("[BattleActorDataCenter][AddBattleActorData] actor_id: %d", actor_id);

    battle_actor_data_map_[actor_id] = battle_actor_data;

    //flush id
    battle_actor_data->actor_id = actor_id;

    return actor_id;
  }

  void BattleActorDataCenter::RemoveBattleActorData(int actor_id)
  {
    if (!CheckBattleActorData(actor_id))
    {
      return;
    }

    //remove Actor first
    actor::Actor* actor = battle::BattleController::GetInstance().GetActorExtEnv()->GetActorById(actor_id);
    if (actor)
    {
      RemoveBattleActor(actor);
    }

    //then BattleActorData
    BattleActorData* battle_actor_data = battle_actor_data_map_[actor_id];
    delete battle_actor_data;
    battle_actor_data_map_.erase(actor_id);
  }


  bool BattleActorDataCenter::CheckBattleActorData(int actor_id)
  {
    return (battle_actor_data_map_.find(actor_id) != battle_actor_data_map_.end());
  }


  BattleActorData* BattleActorDataCenter::GetBattleActorData(int actor_id)
  {
    if (CheckBattleActorData(actor_id))
      return battle_actor_data_map_[actor_id];
    else
      return NULL;
  }

  std::map<int, BattleActorData*>& BattleActorDataCenter::GetBattleActorDataMap()
  {
    return battle_actor_data_map_;
  }

  int BattleActorDataCenter::GetBattleActorDataCount()
  {
    return battle_actor_data_map_.size();
  }


  std::list<int> BattleActorDataCenter::GetBattleActorDataIdList()
  {
    std::list<int> actor_id_list;

    std::map<int, BattleActorData*>::iterator iterator = battle_actor_data_map_.begin();
    while (iterator != battle_actor_data_map_.end())
    {
      int actor_id = iterator->first;

      actor_id_list.push_back(actor_id);

      iterator ++;
    }

    return actor_id_list;
  }



  void BattleActorDataCenter::FlushPendingBattleActor()
  {
    Update(0.0f); //just empty updates
  }


  void BattleActorDataCenter::SetActorWave(int actor_id, float spawn_delay_sec/* = -1*/, int wave_id/* = -1*/)
  {
    if (CheckBattleActorData(actor_id) == false)
    {
      //should first add data, then set wave!
      assert(false);
      return;
    }

    //auto to current wave (starts from 1)
    if (wave_id <= -1) 
      wave_id = MAX(battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize), 1);

    //auto expand wave
    if (wave_id >= battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize))
      SetWaveSize(wave_id);

    int spawn_delay_id = spawn_delay_sec * 1000;

    if (spawn_delay_sec == BATTLE_INVALID_ID) 
    {
      if (wave_map_[wave_id].empty())
        spawn_delay_id = 0;
      else
        spawn_delay_id = wave_map_[wave_id].rbegin()->first + 1;
    }

    //prevent spawn_delay_id as id overlap by delay 1 more msec
    while (wave_map_[wave_id].find(spawn_delay_id) != wave_map_[wave_id].end())
    {
      spawn_delay_id ++;
    }

    wave_map_[wave_id][spawn_delay_id] = actor_id;

    GetLog()->AddLogF("[BattleActorDataCenter][SetActorWave] actor_id: %d, spawn_delay_id : %d, wave_id: %d", actor_id, spawn_delay_id, wave_id);


    //static
    BattleActorData* battle_actor_data = battle_actor_data_map_[actor_id];

    battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountTotal, 1);
    //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountAlive, 1);
    battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountLeft, 1);
    //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountDead, 1);

    if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserSupport)
    {
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportTotal, 1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportAlive, 1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportLeft, 1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportDead, 1);
    }

    if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserOppose)
    {
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeTotal, 1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeAlive, 1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeLeft, 1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeDead, 1);
    }
  }


  int BattleActorDataCenter::AddNewWave()  //return new wave counts
  {
    int wave_size = battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize) + 1;
    SetWaveSize(wave_size);
    return wave_size;
  }


  void BattleActorDataCenter::SetWaveSize(int wave_size)  //return new wave counts
  {
    assert(wave_size >= battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize));

    while (wave_map_.size() < wave_size)
    {
      //expand
      wave_map_[wave_map_.size()];
    }

    battle_data_center_->SetBattleAttribute(kBattleAttributeWaveSize, wave_size);
    GetLog()->AddLogF("[BattleActorDataCenter][SetWaveSize] wave_size: %d", wave_size);
  }


  void BattleActorDataCenter::VerifyWaveData()
  {
    //count
    int actor_count_total = 0;
    int actor_count_user_support = 0;
    int actor_count_user_oppose = 0;

    std::map<int, std::map<int, int > > sort_wave_map = wave_map_;

    int sort_wave_id = (!sort_wave_map.empty() && sort_wave_map.begin()->first == 0)
      ? 0   //has immediate wave
      : 1;  //no immediate wave, or no wave at all

    wave_map_.clear();

    std::map<int, std::map<int, int > >::iterator iterator = sort_wave_map.begin();
    while (iterator != sort_wave_map.end())
    {
      std::map<int, int >* wave_actor_map = &(iterator->second);

      if (wave_actor_map->size() > 0)
      {
        //reorder map
        wave_map_[sort_wave_id] = iterator->second;
        sort_wave_id ++;

        //loop wave and count actor
        std::map<int, int >::iterator actor_iterator = wave_actor_map->begin();
        while (actor_iterator != wave_actor_map->end())
        {
          int actor_id = actor_iterator->second;

          assert(battle_actor_data_map_.find(actor_id) != battle_actor_data_map_.end());  //check data ready

          actor_count_total++;

          if (battle_actor_data_map_[actor_id]->status_map[kBattleStatusActorInitFaction] == kActorFactionUserSupport)
            actor_count_user_support++;
          
          if (battle_actor_data_map_[actor_id]->status_map[kBattleStatusActorInitFaction] == kActorFactionUserOppose)
            actor_count_user_oppose++;

          actor_iterator++;
        }
      }
      else
      {
        assert(false);  //check empty wave
      }

      iterator ++;
    }

    assert(battle_data_center_->GetBattleAttribute(kBattleAttributeActorCountTotal) == actor_count_total);
    assert(battle_data_center_->GetBattleAttribute(kBattleAttributeActorCountUserSupportTotal) == actor_count_user_support);
    assert(battle_data_center_->GetBattleAttribute(kBattleAttributeActorCountUserOpposeTotal) == actor_count_user_oppose);

    int sort_wave_size = sort_wave_id - 1;
    assert(battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize) == sort_wave_size);
    battle_data_center_->SetBattleAttribute(kBattleAttributeWaveSize, sort_wave_size);
  }


  std::list<BattleActorData*>* BattleActorDataCenter::GetBattleActorDataListByWaveOrder()  //need delete after use
  {
    std::list<BattleActorData*>* battle_actor_data_list = new std::list<BattleActorData*>;

    for (std::map<int, std::map<int, int > >::iterator iterator = wave_map_.begin(); iterator != wave_map_.end(); iterator ++)
    {
      std::map<int, int >& wave_actor_map = iterator->second;

      for (std::map<int, int >::iterator iterator_actor = wave_actor_map.begin(); iterator_actor != wave_actor_map.end(); iterator_actor ++)
      {
        int actor_id = iterator_actor->second;

        battle_actor_data_list->push_back(battle_actor_data_map_[actor_id]);
      }
    }

    return battle_actor_data_list;
  }

  void BattleActorDataCenter::WaveSwitch()
  {
    //before switch wave data(last wave)
    int wave_id = battle_data_center_->GetBattleAttribute(kBattleAttributeWaveCurrent); //starts from 0(the instant wave)
    float wave_time = battle_data_center_->GetBattleAttribute(kBattleAttributeWaveCurrentTime);
    
    CCLog("[BattleActorDataCenter][WaveSwitch] wave_id: %d, wave_time: %f", wave_id, wave_time);

    //reset data
    wave_id += 1;
    wave_time = 0.0f;

    //get actor count
    int current_wave_actor_count = wave_map_[wave_id].size();

    //get wave boss count
    int wave_boss_actor_count = 0;
    std::map<int, int>::iterator iterator = wave_map_[wave_id].begin();
    while (iterator != wave_map_[wave_id].end())
    {
      int actor_id = iterator->second;
      BattleActorData* battle_actor_data = battle_actor_data_map_[actor_id];
      if (battle_actor_data->status_map[kBattleStatusActorInitMarkIsWaveBoss])
      {
        wave_boss_actor_count ++;
      }

      iterator ++;
    }


    //  [LEGACY_CHECKPOINT_SCRIPT] 
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
      "CallActiveBattleDataScriptFunc", 
      "Battle_Wave", 
      wave_id, 
      battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize));

    battle::BattleController::GetInstance().GetBattleUIController()->notifyNewWaveComing(wave_id, battle_data_center_->GetBattleAttribute(kBattleAttributeWaveSize), wave_boss_actor_count > 0);



    DispenseWaveRecover();

    //after switch wave data
    battle_data_center_->SetBattleAttribute(kBattleAttributeWaveCurrent, wave_id);
    battle_data_center_->SetBattleAttribute(kBattleAttributeWaveCurrentTime, wave_time);

    RefreshCurrentWaveLeftActorCount();
  }


  void BattleActorDataCenter::RefreshCurrentWaveLeftActorCount()
  {
    int wave_id = battle_data_center_->GetBattleAttribute(kBattleAttributeWaveCurrent); //starts from 0(the instant wave)

    if (wave_map_.find(wave_id) == wave_map_.end())
    {
      battle_data_center_->SetBattleAttribute(kBattleAttributeWaveCurrentActorLeft, 0);
    }
    else
    {
      battle_data_center_->SetBattleAttribute(kBattleAttributeWaveCurrentActorLeft, wave_map_[wave_id].size());
    }
  }


  void BattleActorDataCenter::ResetBattleActorForBattleResult()
  {
    //remove all ally and enemy
    RemoveAllBattleActor();

    //reset data
    LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_add_xp.lua", "InitLuaBattleAddXp");

    //create all ally
    {
      int team_type = DataManager::GetInstance().user_info()->default_team_index();

      CCLog("[TransferUserTeamWinData] team_type: %d", team_type);

      //get team character info by team index
      uint_32 team_card_seq_id_list[data::kMaxCharacterCountInOneTeam] = { data::kUnexistCharacterId };
      DataManager::GetInstance().user_info()->teams_ids(team_type, team_card_seq_id_list);


      for (std::map<int, BattleActorData*>::iterator iterator = battle_actor_data_map_.begin(); iterator != battle_actor_data_map_.end(); iterator ++)
      {
        int actor_id = iterator->first;
        BattleActorData* battle_actor_data = iterator->second;

        if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserSupport
          && (actor_id >= 0 && actor_id < data::kMaxCharacterCountInOneTeam))
        {
          int card_seq_id = team_card_seq_id_list[actor_id];

          if (card_seq_id <= 0)
          {
            assert(card_seq_id > 0);
            continue;
          }
          

          //check if dead, then recreate(always dead)
          if (!battle_data_center_->GetBattleController()->GetActorExtEnv()->GetActorById(actor_id))
          {
            battle_actor_data->status_map[battle_data::kBattleStatusActorInitMarkIsSimpleInit] = 1;

            SetActorWave(actor_id, -1, 0);//re-push
            FlushPendingBattleActor();//flush and create actual actor
          }


          Actor* actor = battle_data_center_->GetBattleController()->GetActorExtEnv()->GetActorById(actor_id);


          // data reset
          actor->SetScriptObjectIsActive(true);
          actor->GetActorData()->SetActorAttribute(kActorAttributeHealthCurrent, actor->GetActorData()->GetActorAttribute(kActorAttributeHealthMax));


          // set position && animation
          cocos2d::CCPoint placing_grid_position = ccp(actor_id % 5 + 1, actor_id / 5 + 1);
          cocos2d::CCPoint placing_position = actor::GetPositionFromGrid(placing_grid_position);
          placing_position = ccpAdd(placing_position, ccp(actor::GetGridBoxAverageWidth() * 0.5f, 0));

          actor->GetActorData()->SetActorPosition(actor::kActorPositionAnimation, placing_position);
          actor->GetAnimation()->GetActorNode()->setPosition(placing_position);
          actor->GetAnimation()->GetActorNode()->setScale(0.8f);
          actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);


          // exp calculation
          data::CharacterInfo* character_info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(card_seq_id);
          if(!character_info)
          {
            assert(character_info);
            continue;
          }

          cocos2d::CCPoint position_exp_bar = ccp(0, actor->GetAnimation()->GetActorVisualHeight());
          cocos2d::CCPoint position_actor = placing_position;
          bool is_user_exp = DataManager::GetInstance().GetRoleDataTable()->IsRoleCard(character_info->getID());
          UILayer* ui_layer_overhead_layer = actor->GetAnimation()->GetAnimationOverheadLayer()->GetOverheadLayer();
          int exp_add = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", 
            "GetLuaBattleMessageData", 
            battle_data_center_->GetBattleStatus(battle_data::kBattleStatusBattleType),
            battle_data_center_->GetBattleStatus(battle_data::kBattleStatusSceneType),
            is_user_exp ? "reward_user_exp" : "reward_card_exp");


          //convert to lua table
          lua_tinker::table actor_exp_data_table = lua_tinker::table(lua_data_tunnel::GetLuaState());
          actor_exp_data_table.set("actor_id", actor_id);
          actor_exp_data_table.set("card_id", character_info->card_id());
          actor_exp_data_table.set("card_seq_id", card_seq_id);
          actor_exp_data_table.set("exp_add", exp_add);
          actor_exp_data_table.set("is_user_exp", is_user_exp);
          actor_exp_data_table.set("position_exp_bar", position_exp_bar);
          actor_exp_data_table.set("position_actor", position_actor);
          actor_exp_data_table.set("ui_layer_overhead_layer", ui_layer_overhead_layer);

          //calculate unit xp for preview
          LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_add_xp.lua", "AddLuaBattleAddXpData", actor_id, actor_exp_data_table);

          //add xp now...
          if (!is_user_exp) 
            character_info->AddXp(exp_add);
        }
      }
    }
  }






  actor::DataLog* BattleActorDataCenter::GetLog() 
  { 
    return battle_data_center_->GetLog(); 
  }


  void BattleActorDataCenter::UpdateWave(float delta_time)
  {
    int wave_id = battle_data_center_->GetBattleAttribute(kBattleAttributeWaveCurrent); //starts from 0(the instant wave)
    float wave_time = battle_data_center_->GetBattleAttribute(kBattleAttributeWaveCurrentTime);
    
    //CCLog("[BattleActorDataCenter][UpdateWave] wave_id: %d, wave_time: %f", wave_id, wave_time);

    //add wave time
    wave_time += delta_time;  

    //push actor data if time is right
    std::map<int, std::map<int, int > >::iterator iterator_wave_map = wave_map_.begin();
    while (iterator_wave_map != wave_map_.end())
    {
      int processing_wave_id = iterator_wave_map->first;

      //first step
      iterator_wave_map ++;

      //then process
      if (wave_id == 0 && processing_wave_id == 0)
      {
        PushWaveActorToPendingBattleActorMap(processing_wave_id, -1);  //flush other wave, special for immediate wave(wave_id = 0)
      }
      else 
      {
        if (wave_id > processing_wave_id)
        {
          PushWaveActorToPendingBattleActorMap(processing_wave_id, -1);  //flush all actor, immediate and previous wave
        }
        if (wave_id == processing_wave_id)
        {
          PushWaveActorToPendingBattleActorMap(processing_wave_id, wave_time); //check wave time, current wave
        }
        if (wave_id < processing_wave_id)
        {
          //not yet, following wave
        }
      }
    }

    //set back wave data
    battle_data_center_->SetBattleAttribute(kBattleAttributeWaveCurrentTime, wave_time);

    RefreshCurrentWaveLeftActorCount();
  }

  void BattleActorDataCenter::PushWaveActorToPendingBattleActorMap(int wave_id, float wave_time)
  {
    // CCLog("[BattleActorDataCenter][PushWaveActorToPendingBattleActorMap] wave_id: %d, wave_time: %f", wave_id, wave_time);

    //check exist
    if (wave_map_.find(wave_id) == wave_map_.end())
    {
      CCLog("[BattleActorDataCenter][PushWaveActorToPendingBattleActorMap] empty");
      return;
    }

    //pick actor and push to pending_battle_actor_data_map_, and remove from wave_map_[wave_id]
    std::map<int, int>::iterator iterator_wave_map_time = wave_map_[wave_id].begin();

    while (iterator_wave_map_time != wave_map_[wave_id].end()/* && pending_battle_actor_data_map_.empty()*/) //limit to 1 per update
    {
      int actor_wave_time_raw = iterator_wave_map_time->first;
      float actor_wave_time = actor_wave_time_raw * 0.001;  //convert to seconds
      int actor_id = iterator_wave_map_time->second;

      //first push forward
      iterator_wave_map_time ++;

      if (wave_time < 0 || actor_wave_time <= wave_time)
      {
        if (battle_actor_data_map_.find(actor_id) != battle_actor_data_map_.end())
        {
          BattleActorData* battle_actor_data = battle_actor_data_map_[actor_id];

          assert(pending_battle_actor_data_map_.find(actor_id) == pending_battle_actor_data_map_.end());  //check strange actor_id overlap

          //push to pending map
          pending_battle_actor_data_map_[actor_id] = battle_actor_data;

          //remove from map
          wave_map_[wave_id].erase(actor_wave_time_raw);
        }
      }
    }

    //check empty
    if (wave_map_[wave_id].empty())
    {
      wave_map_.erase(wave_id);
    }
  }



  void BattleActorDataCenter::CreateBattleActorFromBattleActorData(BattleActorData* battle_actor_data)
  {
    int actor_id = battle_actor_data->actor_id;
    int actor_level = battle_actor_data->status_map[kBattleStatusActorInitLevel];
    int actor_card_id = battle_actor_data->status_map[kBattleStatusActorInitCardId];
    int actor_faction = battle_actor_data->status_map[kBattleStatusActorInitFaction];


    //init place position conversion
    if (battle_actor_data->position_map.find(kBattlePositionActorInitPlacingGrid) != battle_actor_data->position_map.end())
    {
      cocos2d::CCPoint placing_grid_position = battle_actor_data->position_map[kBattlePositionActorInitPlacingGrid];
      assert(placing_grid_position.y >= 1 && placing_grid_position.y <= 3);

      if (placing_grid_position.x >= 1 && placing_grid_position.x <= 6)
        battle_actor_data->position_map[kBattlePositionActorInit] = GetPositionFromGrid(placing_grid_position);
      else
      {
        if (battle_actor_data->status_map[kBattleStatusActorInitHomeDirection] == actor::kActorAnimationDirectionLeft)
          battle_actor_data->position_map[kBattlePositionActorInit] = ccp(-100, GetPositionFromGrid(ccp(1, placing_grid_position.y)).y);
        else
          battle_actor_data->position_map[kBattlePositionActorInit] = ccp(1000, GetPositionFromGrid(ccp(1, placing_grid_position.y)).y);
      }
    }

    assert(battle_actor_data->position_map.find(kBattlePositionActorInit) != battle_actor_data->position_map.end());


    actor::Actor* actor = battle::BattleController::GetInstance().GetActorExtEnv()->CreateActor(actor_id);
    actor->Init(actor::kActorModelActor);

    //data flush

    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    ApplyBattleActorDataToActor(battle_actor_data, actor);
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL
    // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL // DANGER EXPERIMENTAL

    //check init type, TODO: merge logic
    bool is_simple_init = battle_actor_data->status_map[battle_data::kBattleStatusActorInitMarkIsSimpleInit] == 1;

    // init animation
    actor->GetAnimation()->Init(is_simple_init ? kActorAnimationModelActorLite : kActorAnimationModelActor);
    actor->GetAnimation()->GetActorNode()->setPosition(battle_actor_data->position_map[kBattlePositionActorInit]);

    //add to scene
    taomee::battle::BattleController::GetInstance().AddNodeByLayerType(actor->GetAnimation()->GetActorNode(), battle::kBattleLayerMiddle);

    //flush settings
    actor->GetAnimation()->Update(0.0f);

    //set active
    actor->SetScriptObjectIsActive(true);

    // create all passive abilities
    if (!is_simple_init)
    {

      FollowUpActorInitAfterAnimationInit(actor);

      // TODO: move to enemy specific logic

      //get boss mark
      if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceEnemyBoss)
      {
        // add boss Health display
        LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/battleOverlayUI/BattleOverlayUI.lua", 
          "CallFuncBattleOverlayUI", 
          "AddSubDisplay",
          "", 
          "WIDGET_BOSS_HEALTH", 
          actor_id);


        //warning display
        LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/battleOverlayUI/BattleOverlayUI.lua", 
          "CallFuncBattleOverlayUI", 
          "NotifySubDisplay",
          "NOTIFIER_WARNING", 
          "boss_warning");


        //Add Boss Effect
        taomee::SkeletonAnimation* boss_effect = new taomee::SkeletonAnimation();
        boss_effect->Init("boss_bjtx", "boss_bjtx");
        boss_effect->Play("bsj");
        actor->GetAnimation()->GetActorNode()->addChild(boss_effect, -1);


        //attach boss script(skill overload)
        LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle_level/boss_skill_overload_config.lua", 
          "AttachBossSkillOverload", 
          actor_id);


        battle_data_center_->GetLog()->AddErrorLogF("[BattleActorDataCenter][CreateBattleActor] get boss actor! actor_id: %d, card_id: %d", actor_id, actor_card_id);
      }

      // draw arrows for only monster
      if (actor->GetActorData()->GetActorStatus(actor::kActorStatusFaction) == actor::kActorFactionUserOppose
        && actor->GetActorData()->GetActorStatus(actor::kActorStatusAppearance) == actor::kActorAppearanceEnemyPawn
        && battle_actor_data->position_map.find(kBattlePositionActorInitPlacingGrid) != battle_actor_data->position_map.end())
      {
        taomee::battle::BattleController::GetInstance().GetBattleView()->CreateEnemyIndicatorArrow(battle_actor_data->position_map[kBattlePositionActorInitPlacingGrid].y);
      }



      //static
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountTotal, 1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountAlive, 1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountLeft, -1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountDead, 1);

      if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserSupport)
      {
        //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportTotal, 1);
        battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportAlive, 1);
        battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportLeft, -1);
        //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportDead, 1);
      }


      if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserOppose)
      {
        //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeTotal, 1);
        battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeAlive, 1);
        battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeLeft, -1);
        //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeDead, 1);
      }


      //send actor event
      ActorEventData event_data(actor);
      actor->GetActorExtEnv()->GetSignalHub()->Emit(kActorEventActorBorn, actor_id, &event_data);
    }
  }

  void BattleActorDataCenter::RemoveBattleActor(actor::Actor* actor)
  {
    if (!actor)
    {
      return;
    }

    int actor_id = actor->GetScriptObjectId();

    if (CheckBattleActorData(actor_id) == false)
    {
      //ghost actor??
      assert(false);
      return;
    }

    //static
    BattleActorData* battle_actor_data = battle_actor_data_map_[actor_id];

    //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountTotal, 1);
    battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountAlive, -1);
    //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountLeft, -1);
    battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountDead, 1);

    if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserSupport)
    {
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportTotal, 1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportAlive, -1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportLeft, -1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserSupportDead, 1);
    }

    if (battle_actor_data->status_map[kBattleStatusActorInitFaction] == kActorFactionUserOppose)
    {
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeTotal, 1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeAlive, -1);
      //battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeLeft, -1);
      battle_data_center_->AddBattleAttribute(kBattleAttributeActorCountUserOpposeDead, 1);
    }


    //send actor event
    ActorEventData event_data(actor);
    actor->GetActorExtEnv()->GetSignalHub()->Emit(kActorEventActorDead, actor_id, &event_data);


    // this is NOT SAFE LOGIC, TODO: MOVE and add event/data flow


    // [LEGACY_CHECKPOINT_SCRIPT]  TODO: move or remove
    if (actor->GetActorData()->GetActorStatus(actor::kActorStatusFaction) == actor::kActorFactionUserOppose)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
        "CallActiveBattleDataScriptFunc", 
        "Battle_Monster_Dead", 
        actor_id);
    }


    // NOTICE the corresponding BattleActorData is not deleted
    // NOTICE the corresponding BattleActorData is not deleted
    // NOTICE the corresponding BattleActorData is not deleted

    actor->GetActorExtEnv()->RemoveActor(actor->GetScriptObjectId());
  }


  void BattleActorDataCenter::ConnectDataSignal()
  {
    //add data signal
    battle_data_center_->GetBattleStatusData(kBattleStatusState)->Connect<BattleActorDataCenter>(this, &BattleActorDataCenter::OnDataOperation);

    battle_data_center_->GetBattleStatusData(kBattleStatusIsPaused)->Connect<BattleActorDataCenter>(this, &BattleActorDataCenter::OnDataOperation);
  }


  void BattleActorDataCenter::OnDataOperation(int operation_type, int battle_data_type, BattleDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    BattleDataCenter* battle_data_center = signal_data->battle_data_center;
    taomee::battle::BattleController* battle_controller = signal_data->battle_controller;

    switch (battle_data_type)
    {
    case kBattleStatusState:
      switch (operation_type)
      {
      case kActorDataOperationReset:
      case kActorDataOperationSet:
        {
          int battle_status_state = battle_data_center->GetBattleStatus(kBattleStatusState);

          CCLog("[BattleActorDataCenter][OnDataOperation] get kBattleStatusState: %d", battle_status_state);

          switch (battle_status_state)
          {
          case battle_data::kBattleStateMarkBattleStart:
            // [LEGACY_CHECKPOINT_SCRIPT]  TODO: may cause extra actor creation
            LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
              "CallActiveBattleDataScriptFunc", 
              "Battle_Start");

            break;
          }

        }
        break;
      }
      break;

    case kBattleStatusIsPaused:
      switch (operation_type)
      {
      case kActorDataOperationReset:
      case kActorDataOperationSet:
        {
          bool battle_status_is_paused = battle_data_center->GetBattleStatusBool(kBattleStatusIsPaused);

          CCLog("[BattleActorDataCenter][OnDataOperation] get battle_status_is_paused: %s", battle_status_is_paused ? "true" : "false");

          battle_controller->GetActorExtEnv()->SetIsPause(battle_status_is_paused);
        }
        break;
      }
      break;
    }
  }



} // namespace battle_data