#ifndef BATTLE_DATA_TRANSFER_ACTOR
#define BATTLE_DATA_TRANSFER_ACTOR

#include "battle_data_typedef.h"
#include "game/actor/typedef/actor_data_typedef.h"

#include "engine/script/lua_tinker.h"

namespace actor {	
  class Actor;
}

namespace battle_data {

  class BattleDataCenter;
  class BattleActorData;

  // quick data fill method
  void InitActorAttributeDataFromCardId(
    BattleActorData* battle_actor_data, 
    int card_id,
    int actor_faction);

  void FillActorAttributeDataFromCardIdLevelEvolveStar(
    BattleActorData* battle_actor_data, 
    int card_id, 
    int card_level = 1, 
    int card_evolve = 0, 
    int card_star = 0);
  
  void FillActorAttributeDataFromCardSeqId(
    BattleActorData* battle_actor_data, 
    int card_seq_id);

  void FillActorAttributeDataFromLuaAttributeTable(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_attribute_table, 
    int card_id, 
    int card_level = 1, 
    int card_evolve = 0, 
    int card_star = 0);



  void FillActorSkillDataFromSkillLevel(
    BattleActorData* battle_actor_data, 
    int card_id,
    int skill_level = 1);
  
  void FillActorSkillDataFromCardSeqId(
    BattleActorData* battle_actor_data, 
    int card_seq_id);

  void FillActorSkillDataFromLuaSkillTable(
    BattleActorData* battle_actor_data, 
    lua_tinker::table lua_skill_table, 
    int card_id);



  bool VerifyBattleActorData(BattleActorData* battle_actor_data);

  //data transfer
  bool ApplyBattleActorDataToActor(BattleActorData* battle_actor_data, actor::Actor* actor);
  bool FollowUpActorInitAfterAnimationInit(actor::Actor* actor);
} // namespace battle_data

#endif