//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_state.cpp
//        Author: leohou
//       Version:
//          Date: Oct 20, 2013
//          Time: 10:18:30 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     10:18:30 PM
//
//////////////////////////////////////////////////////////////

#include "game/battle/battle_state.h"

#include "game/battle/battle_constants.h"
#include "game/battle/battle_controller.h"
#include "game/battle/battle_resource_loader.h"
#include "game/battle/data/battle_data_center.h"
#include "game/battle/view/battle_view.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "game/game_manager/game_manager.h"

#include "engine/sound/sound_manager.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/state_machine/state_machine.h"
#include "engine/base/utils_string.h"





/*
  Battle State in battle process order:
  
  BattleController::Start

    BattleStateMessage: battle message sending + store server data (both begin and end)
      BattleStatePreload: battle class, actor data preload
        BattleStateDrama: check and show drama (both begin and end)

          BattleStateBattleStart: change ui, will switch wave 0 -> 1(flush wave id 0)
            
            [Mix] BattleStatePause <--> BattleStateBattle <--> BattleStateBattleSwitchWave: change of wave, may preload wave actor
            BattleStateBattle: will update battle class and count active time
            BattleStatePause: pause and show pause menu
            BattleStateSwitchWave: change of wave, may preload wave actor, for wave switch 1 -> 2, 2 -> 3 ... n -> wait for BattleResultWin

              BattleStateBattleEnd: clear up class, data
                
                BattleStateMessage: [end] skip-able by level config
                  BattleStateResult: skip-able by level config, level up animation, battle result UI
                    BattleStateDrama: [end] only win

                      BattleController::End
*/






namespace taomee {
  namespace battle {

    // state message
    BattleStateMessage* BattleStateMessage::Instance()
    {
      static BattleStateMessage battle_state_message;
      return &battle_state_message;
    }

    BattleStateMessage::BattleStateMessage() {}
    BattleStateMessage::~BattleStateMessage() {}

    void BattleStateMessage::Enter(BattleController* battle_controller)
    {
      bool is_battle_start = battle_controller->GetBattleStatus(battle_data::kBattleStatusState) <= battle_data::kBattleStateMarkBattleStart;


      //check level config skip
      if (is_battle_start == false 
        && battle_controller->GetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd))
      {
        battle_controller->SwitchBattleStateResult();
        return;
      }

      // ALL to Lua HttpRequest
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_message.lua", 
        "SendLuaBattleMessage", 
        battle_controller->GetBattleStatus(battle_data::kBattleStatusBattleType), 
        battle_controller->GetBattleStatus(battle_data::kBattleStatusSceneType), 
        is_battle_start ? "begin" : "end");


      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, is_battle_start 
        ? battle_data::kBattleStateMessageStart
        : battle_data::kBattleStateMessageEnd);
    }

    void BattleStateMessage::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      bool is_battle_start = battle_controller->GetBattleStatus(battle_data::kBattleStatusState) <= battle_data::kBattleStateMarkBattleStart;

      int message_state = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", 
        "GetLuaBattleMessageState");

      switch (message_state)
      {
      case battle_data::kBattleMessageStateComplete:
        if (is_battle_start) battle_controller->SwitchBattleStatePreload();
        else battle_controller->SwitchBattleStateResult();
        break;
      case battle_data::kBattleMessageStateWait:
        // do nothing
        break;
      case battle_data::kBattleMessageStateForceEnd:
        battle_controller->End();
        break;
      case battle_data::kBattleMessageStateError:
      default:
        assert(false);
        battle_controller->End();
        break;
      }
    }

    void BattleStateMessage::Exit(BattleController* battle_controller)
    {
      // do nothing
    }








    // state prepare
    BattleStatePreload* BattleStatePreload::Instance()
    {
      static BattleStatePreload battle_state_preload;
      return &battle_state_preload;
    }

    BattleStatePreload::BattleStatePreload() 
      : battle_resource_loader_(NULL)
      , is_preload_actor_(false)
      , is_preload_battle_class_(false)
    {}
    BattleStatePreload::~BattleStatePreload() {
      if (battle_resource_loader_)
      {
        delete battle_resource_loader_;
        battle_resource_loader_ = NULL;
      }
    }

    void BattleStatePreload::Enter(BattleController* battle_controller)
    {
      is_preload_actor_ = false;
      is_preload_battle_class_ = false;
      
      if (battle_resource_loader_)
      {
        assert(!battle_resource_loader_);
        delete battle_resource_loader_;
        battle_resource_loader_ = NULL;
      }

      battle_resource_loader_ = new BattleResourceLoader;
      

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateMarkDataReady);

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStatePreLoad);
    }

    void BattleStatePreload::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      //CCLog("<%.3fs>[BattleStatePreload][UpdateEachFrame]", double(clock()) / CLOCKS_PER_SEC);

      if (!is_preload_battle_class_)
      {
        is_preload_battle_class_ = battle_controller->BattleClassPreload();
      }
      else if (!is_preload_actor_)
      {
        if (preload_id_list_.empty())
        {
          //fetch actor id
          preload_id_list_ = battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorDataIdList();
        }

        //preload actor
        float time_use_max = 1.0f / 60.0f * CLOCKS_PER_SEC;  //limit max tine for one update
        float time_started = clock();
        while ((clock() - time_started) < time_use_max && !preload_id_list_.empty())
        {
          int actor_id = *(preload_id_list_.begin());

          battle_resource_loader_->PreloadBattleActorData(actor_id);

          preload_id_list_.pop_front();
        }

        is_preload_actor_ = preload_id_list_.empty();
      }
      else 
      {
        // note: drama seems to be mission only
        battle_controller->SwitchBattleStateDrama();// Battle Start Drama
      }
    }

    void BattleStatePreload::Exit(BattleController* battle_controller)
    {
      preload_id_list_.clear();

      if (battle_resource_loader_)
      {
        delete battle_resource_loader_;
        battle_resource_loader_ = NULL;
      }
    }






    // state drama
    BattleStateDrama* BattleStateDrama::Instance()
    {
      static BattleStateDrama battle_state_drama;
      return &battle_state_drama;
    }

    BattleStateDrama::BattleStateDrama() {}
    BattleStateDrama::~BattleStateDrama() {}

    void BattleStateDrama::Enter(BattleController* battle_controller)
    {
      bool is_battle_start = battle_controller->GetBattleStatus(battle_data::kBattleStatusState) <= battle_data::kBattleStateMarkBattleStart;

      //check if drama exist
      int battle_drama_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/nasty_drama_id_finder.lua", 
        "NastyFindDramaId", 
        is_battle_start ? "battle_start" : "battle_end", 
        battle_controller->GetBattleStatus(battle_data::kBattleStatusLevelId));

      //battle lost will skip end drama
      if (is_battle_start == false && battle_controller->GetBattleStatusBool(battle_data::kBattleStatusResultIsWin) == false)
      {
        battle_drama_id = -1;
      }

      //always call drama UI
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/nasty_drama_id_finder.lua", 
        "PackLuaCallbackAndOpenDramaUI", 
        battle_drama_id,
        is_battle_start ? "battle_start" : "battle_end");


      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, is_battle_start 
        ? battle_data::kBattleStateDramaStart 
        : battle_data::kBattleStateDramaEnd);
    }

    void BattleStateDrama::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      bool is_drama_finished = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/nasty_drama_id_finder.lua", 
        "CheckLuaCallbackFinished");

      if (is_drama_finished)
      {
        switch (battle_controller->GetBattleStatus(battle_data::kBattleStatusState))
        {
        case battle_data::kBattleStateDramaStart:
          battle_controller->SwitchBattleStateBattleStart();
          break;
        case battle_data::kBattleStateDramaEnd:
          battle_controller->End();
          break;
        }
      }
    }

    void BattleStateDrama::Exit(BattleController* battle_controller)
    {
      // do nothing
    }






    // state battle start
    BattleStateBattleStart* BattleStateBattleStart::Instance()
    {
      static BattleStateBattleStart battle_state_battle_start;
      return &battle_state_battle_start;
    }

    BattleStateBattleStart::BattleStateBattleStart() {}
    BattleStateBattleStart::~BattleStateBattleStart() {}

    void BattleStateBattleStart::Enter(BattleController* battle_controller)
    {
      battle_controller->SetBattleStatusBool(battle_data::kBattleStatusIsTouchEnabled, true);

      //safe reset
      cocos2d::CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.0f);

      // verify data
      battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->VerifyWaveData();

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateMarkBattleStart);
    }

    void BattleStateBattleStart::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      // show menu_layer_ enter animation
      battle_controller->GetBattleUIController()->CreateBattleOverlayUI(); 

      //skip first wave switch by call logic directly here
      battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->WaveSwitch();//wave 0 to wave 1

      //flush actor
      battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->FlushPendingBattleActor();
      
      //to battle
      battle_controller->SwitchBattleStateBattle();
    }

    void BattleStateBattleStart::Exit(BattleController* battle_controller)
    {
      // remove loading layer
      battle_controller->GetBattleUIController()->RemoveBattleLoading();
    }








    // state battle
    BattleStateBattle* BattleStateBattle::Instance()
    {
      static BattleStateBattle battle_state_battle;
      return &battle_state_battle;
    }

    BattleStateBattle::BattleStateBattle() {}
    BattleStateBattle::~BattleStateBattle() {}

    void BattleStateBattle::Enter(BattleController* battle_controller)
    {
      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateBattle);
    }

    void BattleStateBattle::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      battle_controller->BattleUpdate(delta);

      //check is time to switch wave
      if (battle_controller->GetBattleAttribute(battle_data::kBattleAttributeWaveCurrentActorLeft) == 0
        && battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeAlive) == 0)
      {
        bool is_wave_left = battle_controller->GetBattleAttribute(battle_data::kBattleAttributeWaveCurrent)
          < battle_controller->GetBattleAttribute(battle_data::kBattleAttributeWaveSize);
        
        if (is_wave_left)
        {
          battle_controller->SwitchBattleStateSwitchWave();
        }
        else
        {
          //no more enemy, win?
          //wait level check //battle_controller->GetLevelEntity()->SetBattleEndState(kBattleEndResultWin);
        }
      }
    }

    void BattleStateBattle::Exit(BattleController* battle_controller)
    {
      // do nothing
    }






    // state pause
    BattleStatePause* BattleStatePause::Instance()
    {
      static BattleStatePause battle_state_pause;
      return &battle_state_pause;
    }

    BattleStatePause::BattleStatePause() {}
    BattleStatePause::~BattleStatePause() {}

    void BattleStatePause::Enter(BattleController* battle_controller)
    {
      battle_controller->GetBattleView()->PauseBattleLayer();

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateBattlePaused);
    }

    void BattleStatePause::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      // do nothing
    }

    void BattleStatePause::Exit(BattleController* battle_controller)
    {
      battle_controller->GetBattleView()->ResumeBattleLayer();
    }





    // state switch wave
    BattleStateSwitchWave* BattleStateSwitchWave::Instance()
    {
      static BattleStateSwitchWave battle_state_switch_wave;
      return &battle_state_switch_wave;
    }

    BattleStateSwitchWave::BattleStateSwitchWave() {}
    BattleStateSwitchWave::~BattleStateSwitchWave() {}

    void BattleStateSwitchWave::Enter(BattleController* battle_controller)
    {
      battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->WaveSwitch(); //wave data is changed

      //check level config skip
      if (battle_controller->GetBattleAttribute(battle_data::kBattleAttributeTimeSwitchWaveLimit) == 0
        || battle_controller->GetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipSwitchWaveUI))
      {
        battle_controller->SwitchBattleStateBattle();
        return;
      }

      //reset switch wave time
      battle_controller->GetBattleDataCenter()->GetBattleAttributeData(battle_data::kBattleAttributeTimeSwitchWave)->Reset();

      battle_controller->GetBattleUIController()->SetIsHideBattleOverlayUI(true);

      battle_controller->GetBattleUIController()->CreateBattleSwitchWaveUI();

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateBattleSwitchWave);
    }

    void BattleStateSwitchWave::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      if (battle_controller->GetBattleUIController()->CheckIsFinishedBattleSwitchWaveUI())
      {
        //back to battle
        battle_controller->SwitchBattleStateBattle(); 
      }
      else
      {
        //different update from battle state battle
        battle_controller->SwitchWaveUpdate(delta);
      }
    }

    void BattleStateSwitchWave::Exit(BattleController* battle_controller)
    {
      battle_controller->GetBattleUIController()->SetIsHideBattleOverlayUI(false);

      battle_controller->GetBattleUIController()->RemoveBattleSwitchWaveUI();
    }




    // state battle end
    BattleStateBattleEnd* BattleStateBattleEnd::Instance()
    {
      static BattleStateBattleEnd battle_state_battle_end;
      return &battle_state_battle_end;
    }

    BattleStateBattleEnd::BattleStateBattleEnd() {}
    BattleStateBattleEnd::~BattleStateBattleEnd() {}

    void BattleStateBattleEnd::Enter(BattleController* battle_controller)
    {
      battle_controller->SetBattleStatusBool(battle_data::kBattleStatusIsTouchEnabled, false);

      //safe reset
      cocos2d::CCDirector::sharedDirector()->getScheduler()->setTimeScale(1.0f);

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateMarkBattleEnd);
    }

    void BattleStateBattleEnd::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      battle_controller->GetBattleUIController()->RemoveBattleOverlayUI(); 
      battle_controller->GetBattleUIController()->RemoveSkillMask(); 
      battle_controller->GetBattleUIController()->RemoveBattleSwitchWaveUI();
      battle_controller->GetBattleUIController()->RemoveBattleLoading();

      battle_controller->BattleClassClear();

      taomee::GameManager::GetInstance().BattleStateEnd();

      battle_controller->SwitchBattleStateMessage();
    }

    void BattleStateBattleEnd::Exit(BattleController* battle_controller)
    {
      // do nothing
    }









    // state result
    BattleStateResult* BattleStateResult::Instance()
    {
      static BattleStateResult battle_state_result;
      return &battle_state_result;
    }

    BattleStateResult::BattleStateResult() {}
    BattleStateResult::~BattleStateResult() {}

    void BattleStateResult::Enter(BattleController* battle_controller)
    {
      //check level config skip
      if (battle_controller->GetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult))
      {
        battle_controller->SwitchBattleStateDrama();
        return;
      }

      battle_controller->BattleResult();

      // create result UI
      battle_controller->GetBattleUIController()->CreateBattleResultUI();

      // BATTLE STATE CHANGE
      battle_controller->SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateResult);
    }

    void BattleStateResult::UpdateEachFrame(BattleController* battle_controller, float delta)
    {
      if (battle_controller->GetBattleUIController()->CheckIsFinishedBattleResultUI())
      {
        battle_controller->SwitchBattleStateDrama();// Battle End Drama. 
      }
    }
    void BattleStateResult::Exit(BattleController* battle_controller)
    {
      // do nothing
    }


  } /* namespace battle */
} /* namespace taomee */
