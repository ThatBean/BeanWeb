//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_resouce_loader.cpp
//        Author: coldouyang
//          Date: 2014/10/23 15:21
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/23      add
//////////////////////////////////////////////////////////////

#include "game/battle/battle_resource_loader.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"
#include "game/battle/data/battle_data_typedef.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/projectiles_data_table.h"
#include "game/data_table/character_data_table.h"
#include "game/data_table/card_addon_armature_data_table.h"
#include "game/data_table/skill_config_data_table.h"
#include "game/data_table/effect_timeline_data_table.h"
#include "game/data_table/effect_config_data_table.h"
#include "game/data_table/buff_config_data_table.h"
#include "game/data_table/buff_status_animation_data_table.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/animation/projectile_animation_cache_manager.h"
#include "engine/animation/animation_constant.h"
#include "engine/particle/particle_manager.h"
#include "engine/asprite/AspriteManager.h"
#include "engine/base/utils_string.h"




void debug_print_loaded_id_set(std::set<int>& loaded_id_set, const std::string& prefix_text)
{
  char buffer_data[256];
  std::string text_string;

  for (std::set<int>::iterator iterator = loaded_id_set.begin(); iterator != loaded_id_set.end(); iterator ++)
  {
    int loaded_id = *iterator;
    sprintf(buffer_data, "%d", loaded_id);
    text_string += buffer_data;
    text_string += "\t";
  }

  CCLog("%s\n%s\ntotal: %d", prefix_text.c_str(), text_string.c_str(), loaded_id_set.size());
}


void load_projectiles_data(const std::string& res_name)
{
  if (res_name.empty())
    return;

  ProjectilesData* projectile_data = DataManager::GetInstance().GetProjectilesDataTable()->GetProjectiles(res_name);

  if (!projectile_data)
    return;

  std::string folder = "textures/projectile/";
  const std::string& projectile_name = projectile_data->GetExportName();
  const std::string& particle_name = projectile_data->GetParticleEmitter();
  if ((folder.size() == 0 || projectile_name.size() == 0) && particle_name.size() == 0)
    return;

  if (folder.size() != 0 && projectile_name.size() != 0) 
  {
    string plist_file = folder + projectile_name + ".plist";
    string pvr_ccz_file = folder + projectile_name + ".pvr.ccz";
    string animation_plist_file = folder + projectile_name + "_animation.plist";

    // load animation texture and config 
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(
      plist_file.c_str(),
      pvr_ccz_file.c_str());

    CCAnimationCache::sharedAnimationCache()->addAnimationsWithFile(animation_plist_file.c_str());

    ProjectileAnimationCacheManager::GetInstance().AddCacheProjectileAnimationInfo(
      plist_file.c_str(), 
      pvr_ccz_file.c_str(), 
      projectile_name.c_str());
  }

  if (particle_name.size() != 0)
  {
    taomee::ParticleManager::GetInstance().Load(particle_name);
  }
}


void load_armature_data(const std::string& res_name)
{
  if (res_name.empty())
    return;

  if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(res_name.c_str()) == NULL)
  {
    std::string skeleton_texture = kDefaultSkeletonFilePath + res_name + ".pvr.ccz";
    std::string skeleton_plist = kDefaultSkeletonFilePath + res_name + ".plist";
    std::string skeleton_config = kDefaultSkeletonFilePath + res_name + ".xml";

    CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(
      skeleton_texture.c_str(), 
      skeleton_plist.c_str(), 
      skeleton_config.c_str());

    CCTextureCache::sharedTextureCache()->addImage(
      skeleton_texture.c_str());
  }
}







void BattleResourceLoader::quick_switch_animation(int animation_type, std::string& animation_name, int animation_id/* = -1*/)
{
  switch (animation_type)
  {
  case actor::kActorAnimationEffectId:
    add_resource_from_effect_config(animation_id);
    break;
  case actor::kActorAnimationArmatureName:
    load_armature_data(animation_name);
    break;
  case actor::kActorAnimationProjectileName:
    load_projectiles_data(animation_name);
    break;
  case actor::kActorAnimationNone:
    break;
  default:
    assert(false);
    break;
  }
}


void BattleResourceLoader::quick_switch_emit_id_data_list(std::list<actor::EmitIdData>& emit_id_data_list)
{
  for (std::list<actor::EmitIdData>::iterator iterator = emit_id_data_list.begin(); iterator != emit_id_data_list.end(); iterator ++)
  {
    actor::EmitIdData& emit_id_data = *iterator;

    switch (emit_id_data.type)
    {
    case actor::kActorEmitEffectTimeline:
      add_resource_from_effect_timeline(emit_id_data.id);
      break;
    case actor::kActorEmitBuff:
      add_resource_from_buff_config(emit_id_data.id);
      break;
    default:
      assert(false);
      break;
    }
  }
}





void BattleResourceLoader::add_resource_from_effect_config(int effect_config_id)
{
  if (effect_config_id <= 0) 
    return;

  if (loaded_effect_config_id_set_.find(effect_config_id) != loaded_effect_config_id_set_.end())
  {
    return;
  }
  else
  {
    loaded_effect_config_id_set_.insert(effect_config_id);
  }

  EffectConfigData* effect_config_data = DataManager::GetInstance().GetEffectConfigDataTable()->GetEffectConfig(effect_config_id);

  if (!effect_config_data) 
  {
    CCLog("[BattleResourceLoader][add_resource_from_effect] invalid effect_id: %d", effect_config_id);
    assert(false);
    return;
  }

  quick_switch_emit_id_data_list(effect_config_data->GetEmitData());

  quick_switch_animation(effect_config_data->GetAnimationType(), effect_config_data->GetAnimationName());
}


void BattleResourceLoader::add_resource_from_effect_timeline(int effect_timeline_id)
{
  if (effect_timeline_id <= 0) 
    return;

  if (loaded_effect_timeline_id_set_.find(effect_timeline_id) != loaded_effect_timeline_id_set_.end())
  {
    return;
  }
  else
  {
    loaded_effect_timeline_id_set_.insert(effect_timeline_id);
  }

  EffectTimelineData* effect_timeline_data = DataManager::GetInstance().GetEffectTimelineDataTable()->GetEffectTimeline(effect_timeline_id);

  if (!effect_timeline_data) 
  {
    CCLog("[BattleResourceLoader][add_resource_from_effect_timeline] invalid effect_timeline_id: %d", effect_timeline_id);
    assert(false);
    return;
  }

  std::list<EffectTimelineItemData>& effect_timeline_item_list = effect_timeline_data->GetItemList();
  for (std::list<EffectTimelineItemData>::iterator iterator = effect_timeline_item_list.begin(); iterator != effect_timeline_item_list.end(); iterator ++)
  {
    actor::EffectTimelineAnimationData& effect_timeline_animation_data = iterator->GetEffectAnimationData();

    quick_switch_animation(effect_timeline_animation_data.animation_type, effect_timeline_animation_data.name, effect_timeline_animation_data.id);
  }
}



void BattleResourceLoader::add_resource_from_buff_config(int buff_config_id)
{
  if (buff_config_id <= 0) 
    return;

  if (loaded_buff_config_id_set_.find(buff_config_id) != loaded_buff_config_id_set_.end())
  {
    return;
  }
  else
  {
    loaded_buff_config_id_set_.insert(buff_config_id);
  }

  BuffConfigData* buff_config_data = DataManager::GetInstance().GetBuffConfigDataTable()->GetBuffConfig(buff_config_id);

  if (!buff_config_data) 
  {
    CCLog("[BattleResourceLoader][add_resource_from_buff] invalid buff_config_data: %p", buff_config_data);
    assert(false);
    return;
  }

  int buff_status_animation_id = buff_config_data->GetStatusAnimationId();

  if (buff_status_animation_id <= 0) 
    return;

  BuffStatusAnimationData* buff_status_animation_data = DataManager::GetInstance().GetBuffStatusAnimationDataTable()->GetBuffStatusAnimation(buff_status_animation_id);

  if (!buff_status_animation_data) 
  {
    CCLog("[BattleResourceLoader][add_resource_from_buff] invalid buff_status_animation_data: %p", buff_status_animation_data);
    assert(false);
    return;
  }

  quick_switch_animation(buff_status_animation_data->GetEffectTypeStart(), buff_status_animation_data->GetEffectNameStart());
  quick_switch_animation(buff_status_animation_data->GetEffectTypeLoop(), buff_status_animation_data->GetEffectNameLoop());
  quick_switch_animation(buff_status_animation_data->GetEffectTypeEnd(), buff_status_animation_data->GetEffectNameEnd());
}





void BattleResourceLoader::add_resource_from_skill_config(int skill_config_id)
{
	if (skill_config_id <= 0)
		return;

  if (loaded_skill_config_id_set_.find(skill_config_id) != loaded_skill_config_id_set_.end())
  {
    return;
  }
  else
  {
    loaded_skill_config_id_set_.insert(skill_config_id);
  }

  SkillConfigData* skill_config = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_config_id);
  
  if (!skill_config) 
  {
    CCLog("[BattleResourceLoader][loadSkillResource] invalid skill_id: %d", skill_config_id);
    return;
  }

  //CCLog("<%.3fs>[BattleResourceLoader][loadSkillResource] skill_id: %d", double(clock()) / CLOCKS_PER_SEC, skill_id);

  quick_switch_emit_id_data_list(skill_config->GetEmitDataStart());
  quick_switch_emit_id_data_list(skill_config->GetEmitDataEnd());
  quick_switch_emit_id_data_list(skill_config->GetEmitDataHit1());
  quick_switch_emit_id_data_list(skill_config->GetEmitDataHit2());
  quick_switch_emit_id_data_list(skill_config->GetEmitDataHit3());
}







BattleResourceLoader::BattleResourceLoader()
{

}

BattleResourceLoader::~BattleResourceLoader()
{
  //debug print loaded id:
  debug_print_loaded_id_set(loaded_actor_id_set_, "[Loaded Actor ID]");
  debug_print_loaded_id_set(loaded_card_id_set_, "[Loaded Card ID]");
  debug_print_loaded_id_set(loaded_skill_config_id_set_, "[Loaded Skill Config]");
  debug_print_loaded_id_set(loaded_effect_timeline_id_set_, "[Loaded Effect Timeline]");
  debug_print_loaded_id_set(loaded_effect_config_id_set_, "[Loaded Effect Config]");
  debug_print_loaded_id_set(loaded_buff_config_id_set_, "[Loaded Buff Config]");
}






void BattleResourceLoader::PreloadBattleActorData(int actor_id)
{
  if (actor_id < 0)
  {
    assert(false);
    return;
  }

  if (loaded_actor_id_set_.find(actor_id) != loaded_actor_id_set_.end())
  {
    assert(false);
    return;
  }
  else
  {
    loaded_actor_id_set_.insert(actor_id);
  }

  battle_data::BattleActorData* battle_actor_data = taomee::battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(actor_id);
  
  int card_id = battle_actor_data->status_map[battle_data::kBattleStatusActorInitCardId];

  if (card_id < 0)
  {
    assert(false);
    return;
  }

  if (loaded_card_id_set_.find(card_id) != loaded_card_id_set_.end())
  {
    return;
  }
  else
  {
    loaded_card_id_set_.insert(card_id);
  }


  CCLog("<%.3fs>[BattleResourceLoader][PreloadBattleActorData] actor_id: %d, card_id: %d", double(clock()) / CLOCKS_PER_SEC, actor_id, card_id);

  CharacterData* character_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);

  //preload armature animation
  //load_armature_data(character_data->GetName());

  //preload by create a SkeletonAnimation
  taomee::SkeletonAnimation* skeleton_animation_node = new taomee::SkeletonAnimation();
  skeleton_animation_node->Init(character_data->GetName().c_str(), character_data->GetName().c_str());
  skeleton_animation_node->removeFromParentAndCleanup(true);

  //preload user support actor icon
  if (battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] == actor::kActorFactionUserSupport)
  {
    CCSprite* actor_icon = AspriteManager::GetInstance().GetOneFrame(character_data->getFullIconPath(), 1);
    actor_icon->removeFromParentAndCleanup(true);
  }


  //skill
  std::map<int, actor::ActorSkillInfo>::iterator iterator = battle_actor_data->skill_info_map.begin();
  while (iterator != battle_actor_data->skill_info_map.end())
  {
    actor::ActorSkillInfo* skill_info = &(iterator->second);

    //     if (skill_info->skill_level > 0)
    //     {
    int skill_id = skill_info->skill_id;
    add_resource_from_skill_config(skill_id);
    //     }

    iterator ++;
  }


  //card skill addon armature
  list<CardAddonArmatureData*>* card_addon_armature_list = DataManager::GetInstance().GetCardAddonArmatureDataTable()->GetCardAddonArmatureListForCardId(card_id);
  if (card_addon_armature_list)
  {
    for (list<CardAddonArmatureData*>::iterator iterator = card_addon_armature_list->begin(); iterator != card_addon_armature_list->end(); iterator ++)
    {
      CardAddonArmatureData* card_addon_armature = *iterator;

      load_armature_data(card_addon_armature->GetCardAddonArmatureName());
    }
    delete card_addon_armature_list;
  }
}