#include "level_tongtianta.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {

    void LevelLongMarch::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamBabelIndex);

      TransferLuaLongMarchUserTeamInitData();
      TransferLuaMercenaryInitData();

      //TransferLuaTeamInitData("user_support", army::kCharaterObject_StartId, actor::kActorFactionUserSupport);
      TransferLuaTeamInitData("user_oppose", army::kActorIdUserOpposeStart, actor::kActorFactionUserOppose);
    }


    void LevelLongMarch::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      //User Quit Skip All Result logic
      if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
      {
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
        return;
      }

      if ( m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusResultIsWin) )
      {
        m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->DispenseWaveRecover();
      }
    }

  }//namespace battle
}//namespace taomee