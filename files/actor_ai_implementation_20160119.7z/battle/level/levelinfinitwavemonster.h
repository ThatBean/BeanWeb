// /*
// 
// 
// #ifndef Battle_Level_InfiniteWaveMonster_H
// #define Battle_Level_InfiniteWaveMonster_H
// 
// #include "game/battle/battle_constants.h"
// #include "game/battle/level/level_mission.h"
// 
// namespace taomee {
// 
// namespace battle {
// 
// class LevelInfiniteWaveMonster : public LevelMission
// {
// public:
// 	LevelInfiniteWaveMonster();
//   virtual ~LevelInfiniteWaveMonster();
// protected:
//   virtual void onInitialize();
// public:
// 
// 	virtual void notifyBattleStart();
// 
// 	virtual void notifyMoveObjBorn(uint_32 move_obj_id);
// 	virtual void notifyMonsterMoveToRightBorder(uint_32 monster_id);
// 	virtual void notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave);
// 	virtual void notifyPlayerDead(uint_32 player_id, bool last_one);
// 
// private:
// 	void onAwardEnd();
// public:
//   virtual void createUnit();
// 
// 	virtual void Update(float delta);
// 
// protected:
// 
// 	uint_32 m_protecter_id;
// 
// 	bool m_is_waitting_award;
// 
// 
// };
// 
// }//namespace battle
// }//namespace taomee
// 
// #endif*/