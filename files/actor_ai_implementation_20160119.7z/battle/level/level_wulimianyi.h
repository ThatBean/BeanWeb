#ifndef Battle_Level_Daily_H
#define Battle_Level_Daily_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {
  namespace battle {

    class LevelDaily : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();
      virtual void CustomBattleResult();

    };

  }//namespace battle
}//namespace taomee

#endif