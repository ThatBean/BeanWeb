#ifndef BATTLE_LEVEL_CITY_PK_H
#define BATTLE_LEVEL_CITY_PK_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelbase.h"

namespace taomee {

  namespace battle {

    class LevelCityPk : public LevelBase
    {
    public:
      virtual void Initialize();
      virtual void CreateBattleActorData();
    };

  }//namespace battle
}//namespace taomee

#endif