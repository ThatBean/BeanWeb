#include "level_jingyanyaoshui.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"

#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {

    void LevelLimitTimeKO::notifyMonsterMoveToRightBorder(uint_32 monster_id)
    {
      actor::Actor* actor = m_battle_controller->GetActorExtEnv()->GetActorById(monster_id);
      if (actor
        && actor->GetActorData()->GetActorStatus(actor::kActorStatusFaction) == actor::kActorFactionUserOppose)
      {
        actor->GetActorData()->SetActorAttribute(actor::kActorAttributeHealthCurrent, 0);
      }
    }

    void LevelLimitTimeKO::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      //User Quit Skip All Result logic
      if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
      {
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
        return;
      }

      //this battle always result in win
      m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, true);

      //data transfer logic
      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
        "SetLuaBattleData", 
        "LevelLimitTimeKoDeadMonsterCount", 
        m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeDead));

      //  [LEGACY_CHECKPOINT_SCRIPT] 
      int grade = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
        "CallActiveBattleDataScriptFunc", 
        "GetBattleGrade",
        m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeDead));

      BattleController::GetInstance().SetBattleStatus(battle_data::kBattleStatusFinishedUnexplainableGrade, grade);
    }


    void LevelLimitTimeKO::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamExploreExp);
      TransferUserTeamInitData(data::kTeamExploreExp);

      TransferLuaMercenaryInitData();
    }

  }//namespace battle
}//namespace taomee