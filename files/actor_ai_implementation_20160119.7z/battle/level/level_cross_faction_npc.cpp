#include "level_cross_faction_npc.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"
#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {
    void LevelCrossFactionBattleNPC::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kCrossFactionBattleTeam);
      TransferUserTeamInitData(data::kCrossFactionBattleTeam);

      //TransferLuaTeamInitData("user_support", army::kCharaterObject_StartId, actor::kActorFactionUserSupport);

      //get level boss id
      m_world_boss_id = actor::ACTOR_INVALID_ID;
      std::list<int> battle_actor_data_id_list = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorDataIdList();
      std::list<int>::iterator iterator = battle_actor_data_id_list.begin();
      while (iterator != battle_actor_data_id_list.end())
      {
        int actor_id = *iterator;
        battle_data::BattleActorData* battle_actor_data = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(actor_id);
        if (battle_actor_data->status_map[battle_data::kBattleStatusActorInitMarkIsWaveBoss])
        {
          assert(m_world_boss_id == actor::ACTOR_INVALID_ID);//check multi BOSS

          m_world_boss_id = actor_id;//found the BOSS!!
        }

        iterator ++;
      }

      assert(m_world_boss_id != actor::ACTOR_INVALID_ID);//check have BOSS

      //set different health
      int current_boss_hp = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "GetLuaBattleData", "FactionRaidBossHp");
      battle_data::BattleActorData* battle_actor_data = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(m_world_boss_id);
      battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthCurrent] = current_boss_hp;
      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
        "SetLuaBattleData", 
        "FactionRaidBossHpStart", 
        current_boss_hp);
    }

    void LevelCrossFactionBattleNPC::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
      {
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
        return;
      }

      //this battle always result in win
      m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, true);


      //data transfer logic
      if (m_world_boss_id != actor::ACTOR_INVALID_ID)
      {
        actor::Actor* actor = m_battle_controller->GetActorExtEnv()->GetActorById(m_world_boss_id);
        battle_data::BattleActorData* battle_actor_data = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(m_world_boss_id);

        int damage_taken = battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthCurrent] //better for preset health boss //actor->GetActorData()->GetActorAttribute(actor::kActorAttributeHealthMax)
        - (actor ? actor->GetActorData()->GetActorAttribute(actor::kActorAttributeHealthCurrent) : 0.0f);

        LuaTinkerManager::GetInstance().CallLuaFunc<int>(
          "script/battle/lua_battle_data.lua", 
          "SetLuaBattleData", 
          "FactionRaidBossDamage",
          damage_taken);
      }
    }
  }//namespace battle
}//namespace taomee