#include "levelbase.h"

#include "game/battle/battle_controller.h"
#include "game/battle/battle_state.h"
#include "game/battle/data/battle_data_center.h"

#include "game/actor/actor.h"

#include "game/data_table/data_constant.h"
#include "game/data_table/character_data_table.h"
#include "game/user_data/character_info.h"


#include "engine/base/utils_string.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/script/lua_tinker.h"

#include "game/battle/level/level_pvp.h"
#include "game/battle/level/level_sandbox.h"
#include "game/battle/level/level_first_battle.h"
#include "game/battle/level/level_mission.h"
#include "game/battle/level/level_tongtianta.h"
#include "game/battle/level/level_wulimianyi.h"
#include "game/battle/level/level_mofamianyi.h"
#include "game/battle/level/level_jy.h"
#include "game/battle/level/level_jinbi.h"
#include "game/battle/level/level_jingyanyaoshui.h"
#include "game/battle/level/level_guard_npc.h"
#include "game/battle/level/level_city_pk.h"
#include "game/battle/level/level_faction_boss.h"
#include "game/battle/level/level_faction_pk.h"
#include "game/battle/level/level_wuxianboguai.h"
#include "game/battle/level/level_cross_faction_pk.h"
#include "game/battle/level/level_cross_faction_npc.h"


namespace taomee {
  namespace battle {

    LevelBase* LevelBase::CreateLevel(eBattleType battle_type, eBattleSceneType battle_scene_type)
    {
      LevelBase* pLevel = NULL;
      switch(battle_scene_type)
      {
      case kBattleSceneType_First_Battle:
        pLevel = new LevelFirstBattle();
        break;
      case kBattleSceneType_Mission:
        pLevel = new LevelMission();
        break;
      case kBattleSceneType_Daily_WuLiMianYi:
        pLevel = new LevelDaily();
        break;
      case kBattleSceneType_Daily_MoFaMianYi:
        pLevel = new LevelMoFaDaily();
        break;
      case kBattleSceneType_Daily_JingYanYaoShui:
        pLevel = new LevelLimitTimeKO();
        break;
      case kBattleSceneType_Daily_JinBi:
        pLevel = new LevelBreak();
        break;
      case kBattleSceneType_FactionBoss:
        pLevel = new LevelFaction();
        break;
      case kBattleSceneType_JY:
        pLevel = new LevelElite();
        break;
      case kBattleSceneType_ArenaPK:
        pLevel = new LevelPvp();
        break;
      case kBattleSceneType_CityPK:
        pLevel = new LevelCityPk();
        break;
      case kBattleSceneType_FactionBattlePK:
        pLevel = new LevelFactionBattle();
        break;
      case kBattleSceneType_TongTianTa:
        pLevel = new LevelLongMarch();
        break;
      case kBattleSceneType_Daily_WuXianBoGuai:
        pLevel = new LevelWuXianBoGuai();
        break;
  	  case kBattleSceneType_CrossFactionBattle:
    		pLevel = new LevelCrossFactionBattle();    
    		break;
      case kBattleSceneType_CrossFactionBattleNPC:
        pLevel = new LevelCrossFactionBattleNPC();    
        break;
      default:
        pLevel = new LevelSandbox();
        break;
      }
      CCAssert( pLevel != NULL, "pLevel != NULL");
      return pLevel;
    }



    LevelBase::LevelBase()
      : m_battle_controller(NULL)
      , m_battle_over(false)
    {
      m_battle_controller = &(BattleController::GetInstance());
    }

    LevelBase::~LevelBase()
    {

    }

    void LevelBase::Initialize()
    {
      //default level config
      m_battle_controller->InitBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, false);
      m_battle_controller->InitBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, false);
      m_battle_controller->InitBattleStatusBool(battle_data::kBattleStatusLevelConfigIsHideToolButton, false);
    }


    void LevelBase::SetBattleEndState(eBattleEndResultType battle_end_result)
    {
      //set is finished in time
      float time_battle_active_limit = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActiveLimit);
      float time_battle_active = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActive);

      bool is_finish_in_time = (time_battle_active_limit > 0) && (time_battle_active <= time_battle_active_limit);
      m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusFinishedInLimitedTime, is_finish_in_time);


      //set is all ally alive(no ally dead)
      int actor_count_user_support_dead = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserSupportDead);

      bool is_all_ally_alive = actor_count_user_support_dead <= 0;
      m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusFinishedAllAllyAlive, is_all_ally_alive);

      int result_star_status = 0;
      if (actor_count_user_support_dead >= 3) result_star_status = 0;
      else if (actor_count_user_support_dead == 2) result_star_status = 1;
      else if (actor_count_user_support_dead == 1) result_star_status = 2;
      else result_star_status = 3;
      m_battle_controller->SetBattleStatus(battle_data::kBattleStatusResultStar, result_star_status);

      //set result
      switch (battle_end_result)
      {
      case kBattleEndResultWin:
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, true);
        break;
      case kBattleEndResultFailed:
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        break;
      case kBattleEndResultUserQuit:
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit, true);
        break;
      default:
        assert(false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        break;
      }



      m_battle_over = true;
    }


    void LevelBase::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kDefaultTeamIndex);
    }

    void LevelBase::notifyMonsterMoveToRightBorder(uint_32 monster_id)
    {
      SetBattleEndState(kBattleEndResultFailed);
    }


    void LevelBase::CheckBattleOver()
    {
      //check alive count
      bool is_exist_alive_actor_user_support = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserSupportAlive) > 0;
      bool is_exist_alive_actor_user_oppose = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeAlive) > 0;
      bool is_exist_left_actor_user_support = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserSupportLeft) > 0;
      bool is_exist_left_actor_user_oppose = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeLeft) > 0;


      bool is_exist_more_wave = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeWaveCurrent)
        < m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeWaveSize);


      if (!is_exist_more_wave
        && !is_exist_alive_actor_user_oppose 
        && !is_exist_left_actor_user_oppose
        && is_exist_alive_actor_user_support)
      {
        //seems win (we live you die)
        SetBattleEndState(kBattleEndResultWin);
      }


      if (!is_exist_alive_actor_user_support 
        && !is_exist_left_actor_user_support)
      {
        //seems lost (no more user supporters)
        SetBattleEndState(kBattleEndResultFailed);
      }


      //check battle over
      if (m_battle_over)
      {
        //first adjust battle result
        CustomBattleResult();

        //will end battle
        m_battle_controller->SwitchBattleStateBattleEnd();
      }
    }

    void LevelBase::CustomBattleResult()
    {
      // if the SetBattleEndState suits the level, don't bother this method

      // you can set always win as:
      // m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, true);
    }


    void LevelBase::BattleUpdate(float delta)
    {
      //update for battle

      if ((m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActiveLimit) > 0)
        && (m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActive) 
          >= m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActiveLimit)))
      {
        SetBattleEndState(kBattleEndResultFailed);
      }

      CheckBattleOver();
    }


    void LevelBase::SwitchWaveUpdate(float delta)
    {
      //update for switch wave

      CheckBattleOver();
    }





























    static bool _actor_born_grid_status[3][6] = {}; //is_taken = grid_status[y][x]
    void _reset_actor_born_grid_status()
    {
      //array of taken grids
      int x, y;
      for (int i = 0; i < 3 * 6; i ++)
      {
        x = 1 + i % 6;
        y = 1 + i / 6;
        _actor_born_grid_status[y - 1][x - 1] = false;
      }
    }


    cocos2d::CCPoint _auto_decide_actor_born_grid(battle_data::BattleActorData* battle_actor_data)
    {
      int card_id = battle_actor_data->status_map[battle_data::kBattleStatusActorInitCardId];
      bool is_home_direction_right = battle_actor_data->status_map[battle_data::kBattleStatusActorInitHomeDirection] == actor::kActorAnimationDirectionRight;
      taomee::army::eCareerType card_career = taomee::army::eCareerType(DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id)->GetJobType());

      int preferred_grid_x = -1;
      switch (card_career)
      {
      case taomee::army::kCareerTypeKnight:
      case taomee::army::kCareerTypeWarrior:
        preferred_grid_x = is_home_direction_right ? 4 : 3; //front line
        break;
      case taomee::army::kCareerTypeMonk:
        preferred_grid_x = is_home_direction_right ? 5 : 2; //middle line
        break;
      case taomee::army::kCareerTypeArcher:
      case taomee::army::kCareerTypeWizard:
        preferred_grid_x = is_home_direction_right ? 6 : 1; //back line
        break;
      default:
        preferred_grid_x = is_home_direction_right ? 6 : 1; //back line
        break;
      }

      //search valid grid
      int valid_grid_x = -999;
      int valid_grid_y = 1;

      int x, y;
      for (int i = 0; i < 3 * 6; i ++)
      {
        x = 1 + i % 6;
        y = 1 + i / 6;

        if (
          (is_home_direction_right ? (x >= 4) : (x <= 3)) //grid direction valid
          && _actor_born_grid_status[y - 1][x - 1] == false //grid valid
          && (abs(valid_grid_x - preferred_grid_x) > abs(x - preferred_grid_x)))  //grid is closer to preferred
        {
          valid_grid_x = x; 
          valid_grid_y = y;
        }
      }

      assert(valid_grid_x != -999); //should have enough space

      //mark taken grid
      _actor_born_grid_status[valid_grid_y - 1][valid_grid_x - 1] = true;

      return ccp(valid_grid_x, valid_grid_y);
    }





    void TransferUserTeamInitData(int team_type)
    {
      DataManager::GetInstance().user_info()->set_default_team_index(team_type);

      //CCLog("[TransferUserTeamInitData] team_type: %d, is_have_preset_team : %d", team_type, is_have_preset_team);
      CCLog("[TransferUserTeamInitData] team_type: %d", team_type);

      //array of taken grids
      _reset_actor_born_grid_status();

      //get team character info by team index
      uint_32 team_card_seq_id_list[data::kMaxCharacterCountInOneTeam] = { data::kUnexistCharacterId };
      DataManager::GetInstance().user_info()->teams_ids(team_type, team_card_seq_id_list);

      //create team character
      for (int actor_id = 0; actor_id < data::kMaxCharacterCountInOneTeam; actor_id++)
      {
        int card_seq_id = team_card_seq_id_list[actor_id];

        CCLog("[TransferUserTeamInitData] get team actor id: %d, seq id: %d", actor_id, card_seq_id);

        if (card_seq_id > 0)
        {
          //BattleActorData
          battle_data::BattleActorData* battle_actor_data = new battle_data::BattleActorData;
          battle_actor_data->actor_id = actor_id;

          battle_data::FillActorAttributeDataFromCardSeqId(
            battle_actor_data, 
            card_seq_id);

          battle_data::FillActorSkillDataFromCardSeqId(
            battle_actor_data, 
            card_seq_id);

          //additional status
          battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] = actor::kActorFactionUserSupport;
          battle_actor_data->status_map[battle_data::kBattleStatusActorInitHomeDirection] = actor::kActorAnimationDirectionRight;

          cocos2d::CCPoint born_grid_position = _auto_decide_actor_born_grid(battle_actor_data);

          battle_actor_data->position_map[battle_data::kBattlePositionActorInitPlacingGrid] = ccpAdd(born_grid_position, ccp(1, 0));
          battle_actor_data->position_map[battle_data::kBattlePositionActorInitTargetGridBorn] = born_grid_position;

          int result_actor_id = battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->AddBattleActorData(battle_actor_data);
          assert(actor_id == result_actor_id); //this will be remove in Android/iOS

          battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->SetActorWave(actor_id, -1, 0);
        }
      }
    }




    void TransferLuaTeamInitData(const char* team_key, int start_id, int team_faction)
    {
      eBattleType battle_type = eBattleType(taomee::battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusBattleType));
      eBattleSceneType scene_type = eBattleSceneType(taomee::battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusSceneType));

      CCLog("[TransferUserTeamWinData] battle_type: %d, scene_type: %d, team_key: %s, start_id: %d, team_faction: %d", battle_type, scene_type, team_key, start_id, team_faction);

      _reset_actor_born_grid_status();

      int team_size = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", 
        "GetLuaBattleMessageData", battle_type, scene_type,
        "team_size", team_key);

      for (int i = 0;  i < team_size; ++i)
      {
        int actor_id = start_id + i;

        int card_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_id", team_key, i);
        int card_seq_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_seq_id", team_key, i);
        int card_level = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_level", team_key, i);
        int card_evolve = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_evolve", team_key, i);
        int card_star = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_star", team_key, i);

        lua_tinker::table lua_attribute_table = LuaTinkerManager::GetInstance().GetLuaTable("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "attribute_table", team_key, i);
        lua_tinker::table lua_skill_table = LuaTinkerManager::GetInstance().GetLuaTable("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "skill_table", team_key, i);

        //find card info if self team
        if (team_faction == actor::kActorFactionUserSupport)
        {
          //may fail, add check
          do
          {
            CCArray* card_list = DataManager::GetInstance().user_info()->QueryCharacterListByCardId(card_id);
            if (card_list->count() == 0) { /*assert(false); */break; }
            int user_card_seq_id = dynamic_cast<CCInteger*>(card_list->objectAtIndex(0))->getValue();
            data::CharacterInfo* character_info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(user_card_seq_id);
            if (!character_info) { /*assert(false); */break; }
            CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
            if (!card_data) { /*assert(false); */break; }
            CCLog("[TransferUserTeamWinData] pull additional user team data for actor icon by card id, card_id: %d, card_seq_id: %d, card_count: %d", card_id, card_seq_id, card_list->count());

            card_seq_id = user_card_seq_id;
            card_level = character_info->level();
            card_evolve = character_info->getEvolveStep();
            card_star = character_info->up_star();
          } while(0);
        }

        //BattleActorData
        battle_data::BattleActorData* battle_actor_data = new battle_data::BattleActorData;
        battle_actor_data->actor_id = actor_id;


        battle_data::FillActorAttributeDataFromLuaAttributeTable(
          battle_actor_data, 
          lua_attribute_table, 
          card_id,
          card_level,
          card_evolve,
          card_star);

        battle_data::FillActorSkillDataFromLuaSkillTable(
          battle_actor_data, 
          lua_skill_table,
          card_id);


        //additional status
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitCardSeqId] = card_seq_id;
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] = team_faction;
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitHomeDirection] = (team_faction == actor::kActorFactionUserSupport)
          ? actor::kActorAnimationDirectionRight
          : actor::kActorAnimationDirectionLeft;


        cocos2d::CCPoint born_grid_position = _auto_decide_actor_born_grid(battle_actor_data);

        battle_actor_data->position_map[battle_data::kBattlePositionActorInitPlacingGrid] = born_grid_position;
        battle_actor_data->position_map[battle_data::kBattlePositionActorInitTargetGridBorn] = born_grid_position;

        int result_actor_id = battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->AddBattleActorData(battle_actor_data);

        assert(actor_id == result_actor_id); //this will be remove in Android/iOS

        battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->SetActorWave(actor_id, -1, 0);
      }
    }




    void TransferLuaLongMarchUserTeamInitData()
    {
      eBattleType battle_type = eBattleType(taomee::battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusBattleType));
      eBattleSceneType scene_type = eBattleSceneType(taomee::battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusSceneType));

      const char* team_key = "long_march_user_support_data";

      CCLog("[TransferLuaLongMarchUserTeamInitData] battle_type: %d, scene_type: %d", battle_type, scene_type);

      _reset_actor_born_grid_status();

      for (int i = 0; i<data::kMaxCharacterCountInOneTeam; ++i)
      {
        int actor_id = army::kActorIdUserSupportStart + i;

        int card_seq_id = DataManager::GetInstance().user_info()->GetSequenceIdForTeamIdx(data::kTeamBabelIndex, i);
        if (card_seq_id <= 0)
          continue;

        taomee::data::CharacterInfo* card_seq_info = DataManager::GetInstance().user_info()->GetCharacterCardBySequenceId(card_seq_id);
        if (!card_seq_info)
          continue;
        
        lua_tinker::table long_march_card_init_data = LuaTinkerManager::GetInstance().GetLuaTable("script/battle/lua_battle_message.lua", 
          "GetLuaBattleMessageData", battle_type, scene_type, 
          "long_march_card_init_data", team_key, card_seq_id);

        if (long_march_card_init_data.get<bool>("is_dead"))
          continue;


        float current_health_percent = long_march_card_init_data.get<float>("health_percent");
        float current_energy = long_march_card_init_data.get<float>("energy_current");

        current_health_percent = (current_health_percent <= 0) ? 100 : current_health_percent;


        //BattleActorData
        battle_data::BattleActorData* battle_actor_data = new battle_data::BattleActorData;
        battle_actor_data->actor_id = actor_id;

        battle_data::FillActorAttributeDataFromCardSeqId(
          battle_actor_data, 
          card_seq_id);

        battle_data::FillActorSkillDataFromCardSeqId(
          battle_actor_data, 
          card_seq_id);


        //additional attribute
        battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthCurrent] = 0.01 * current_health_percent * battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthMax];
        battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitEnergyCurrent] = current_energy;


        //additional status
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] = actor::kActorFactionUserSupport;
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitHomeDirection] = actor::kActorAnimationDirectionRight;

        cocos2d::CCPoint born_grid_position = _auto_decide_actor_born_grid(battle_actor_data);

        battle_actor_data->position_map[battle_data::kBattlePositionActorInitPlacingGrid] = born_grid_position;
        battle_actor_data->position_map[battle_data::kBattlePositionActorInitTargetGridBorn] = born_grid_position;

        int result_actor_id = battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->AddBattleActorData(battle_actor_data);
        assert(actor_id == result_actor_id); //this will be remove in Android/iOS

        battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->SetActorWave(actor_id, -1, 0);
      }
    }



    void TransferLuaMercenaryInitData()
    {
      //actor id from team selection ui
      eBattleType battle_type = eBattleType(taomee::battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusBattleType));
      eBattleSceneType scene_type = eBattleSceneType(taomee::battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusSceneType));

      const char* team_key = "mercenary_data";

      int team_size = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", 
        "GetLuaBattleMessageData", battle_type, scene_type,
        "team_size", team_key);

      for (int mercenary_index = 0;  mercenary_index < team_size; mercenary_index ++)
      {
        int actor_id = 6 + mercenary_index;
        actor::eActorFactionType team_faction = actor::kActorFactionUserSupport;

        CCLog("[TransferLuaMercenaryInitData] battle_type: %d, scene_type: %d, actor_id: %d", battle_type, scene_type, actor_id);

        int card_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_id", team_key, mercenary_index);
        int card_seq_id = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_seq_id", team_key, mercenary_index);
        int card_level = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_level", team_key, mercenary_index);
        int card_evolve = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_evolve", team_key, mercenary_index);
        int card_star = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "card_star", team_key, mercenary_index);

        lua_tinker::table lua_attribute_table = LuaTinkerManager::GetInstance().GetLuaTable("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "attribute_table", team_key, mercenary_index);
        lua_tinker::table lua_skill_table = LuaTinkerManager::GetInstance().GetLuaTable("script/battle/lua_battle_message.lua", "GetLuaBattleMessageData", battle_type, scene_type, "skill_table", team_key, mercenary_index);

        //BattleActorData
        battle_data::BattleActorData* battle_actor_data = new battle_data::BattleActorData;
        battle_actor_data->actor_id = actor_id;


        battle_data::FillActorAttributeDataFromLuaAttributeTable(
          battle_actor_data, 
          lua_attribute_table, 
          card_id,
          card_level,
          card_evolve,
          card_star);

        battle_data::FillActorSkillDataFromLuaSkillTable(
          battle_actor_data, 
          lua_skill_table,
          card_id);


        //additional status
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitCardSeqId] = card_seq_id;
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] = team_faction;
        battle_actor_data->status_map[battle_data::kBattleStatusActorInitHomeDirection] = (team_faction == actor::kActorFactionUserSupport)
          ? actor::kActorAnimationDirectionRight
          : actor::kActorAnimationDirectionLeft;


        cocos2d::CCPoint born_grid_position = _auto_decide_actor_born_grid(battle_actor_data);

        battle_actor_data->position_map[battle_data::kBattlePositionActorInitPlacingGrid] = born_grid_position;
        battle_actor_data->position_map[battle_data::kBattlePositionActorInitTargetGridBorn] = born_grid_position;

        int result_actor_id = battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->AddBattleActorData(battle_actor_data);

        assert(actor_id == result_actor_id); //this will be remove in Android/iOS

        battle::BattleController::GetInstance().GetBattleDataCenter()->GetBattleActorDataCenter()->SetActorWave(actor_id, -1, 0);
      }
    }


  }//namespace battle
}//namespace taomee