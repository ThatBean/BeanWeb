#include "level_wulimianyi.h"

#include "game/battle/battle_controller.h"
#include "game/game_manager/data_manager.h"

namespace taomee {
  namespace battle {

    void LevelDaily::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamExploreWuli);
      TransferUserTeamInitData(data::kTeamExploreWuli);

      TransferLuaMercenaryInitData();
    }

    void LevelDaily::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      //User Quit Skip All Result logic
      if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
      {
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
        return;
      }

      //data transfer logic
      BattleController::GetInstance().SetBattleStatus(battle_data::kBattleStatusFinishedUnexplainableGrade, 1);
    }

  }//namespace battle
}//namespace taomee