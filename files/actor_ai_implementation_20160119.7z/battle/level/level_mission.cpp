#include "level_mission.h"

#include "game/battle/battle_controller.h"
#include "game/battle/battle_state.h"

#include "engine/base/state_machine/state_machine.h"

namespace taomee {
  namespace battle {

    void LevelMission::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamMainIndex);
      TransferUserTeamInitData(data::kTeamMainIndex);
    }

  }//namespace battle
}//namespace taomee