#ifndef Battle_Level_MoFaDaily_H
#define Battle_Level_MoFaDaily_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {
  namespace battle {

    class LevelMoFaDaily : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();
      virtual void CustomBattleResult();

    };

  }//namespace battle
}//namespace taomee

#endif