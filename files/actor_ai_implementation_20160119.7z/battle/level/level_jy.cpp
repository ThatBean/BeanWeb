#include "level_jy.h"

#include "game/battle/battle_controller.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {

    void LevelElite::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamMainIndex);
      TransferUserTeamInitData(data::kTeamMainIndex);
      TransferLuaMercenaryInitData();
    }

    void LevelElite::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      //User Quit Skip All Result logic
      if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
      {
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
        return;
      }
    }

  }//namespace battle
}//namespace taomee