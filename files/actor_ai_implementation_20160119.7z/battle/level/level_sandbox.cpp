#include "level_sandbox.h"

#include "game/battle/battle_controller.h"

#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {

    void LevelSandbox::Initialize()
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
        "LoadLuaBattleScript", 
        m_battle_controller->GetBattleStatus(battle_data::kBattleStatusBattleType),
        m_battle_controller->GetBattleStatus(battle_data::kBattleStatusSceneType),
        m_battle_controller->GetBattleStatus(battle_data::kBattleStatusLevelId));
    }


    void LevelSandbox::BattleUpdate(float delta)
    {
      //nothing.. just loop
    }

  }//namespace battle
}//namespace taomee