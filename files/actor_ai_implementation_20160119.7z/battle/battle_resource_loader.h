//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_resource_loader.h
//        Author: coldouyang
//          Date: 2014/10/23 15:21
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/23      add
//////////////////////////////////////////////////////////////

#ifndef BATTLE_RESOURCE_LOADER_H
#define BATTLE_RESOURCE_LOADER_H

#include "engine/base/basictypes.h"
#include "game/actor/typedef/actor_data_typedef.h"

#include <set>

class BattleResourceLoader
{
public:
  BattleResourceLoader();
  ~BattleResourceLoader();

  void PreloadBattleActorData(int actor_id);

protected:
  void add_resource_from_effect_config(int effect_config_id);
  void add_resource_from_effect_timeline(int effect_timeline_id);
  void add_resource_from_buff_config(int buff_config_id);
  void add_resource_from_skill_config(int skill_config_id);

  void quick_switch_emit_id_data_list(std::list<actor::EmitIdData>& emit_id_data_list);
  void quick_switch_animation(int animation_type, std::string& animation_name, int animation_id = -1);

private:
  std::set<int> loaded_actor_id_set_;
  std::set<int> loaded_card_id_set_;
  std::set<int> loaded_skill_config_id_set_;
  std::set<int> loaded_effect_timeline_id_set_;
  std::set<int> loaded_effect_config_id_set_;
  std::set<int> loaded_buff_config_id_set_;
};

#endif