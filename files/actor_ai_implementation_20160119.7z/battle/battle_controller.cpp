//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_controller.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/battle_controller.h"

#include "engine/base/load_helper.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/utils_string.h"
#include "engine/base/state_machine/state_machine.h"

#include "engine/script/lua_data_tunnel.h"

#include "engine/animation/skeleton_animation_cache_manager.h"
#include "engine/animation/skeleton_animation.h"
#include "engine/sound/sound_manager.h"
#include "engine/event_system/event_manager.h"
#include "game/event/event_battle/event_battle_obj.h"

#include "game/army/unit/unit_constants.h"

#include "game/battle/battle_state.h"
#include "game/battle/battle_constants.h"

#include "game/battle/view/battle_view.h"
#include "game/battle/view/battle_damage_label.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "game/mission/mission_contants.h"
#include "game/game_manager/game_manager.h"
#include "game/game_manager/data_manager.h"
#include "game/game_manager/data_sync_module.h"

#include "game/battle/level/levelbase.h"
#include "game/data_table/checkpointdaily_data_table.h"
#include "game/data_table/character_data_table.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext_env.h"
#include "game/actor/actor_ext/actor_ext_effect.h"
#include "game/actor/actor_ext/actor_ext_damage.h"
#include "game/actor/actor_script_exporter.h"
#include "game/actor/buff/actor_buff.h"
#include "game/actor/motion/actor_motion_state_machine.h"

#include "game/battle/data/battle_data_center.h"

#include "game/platform/SDKManager.h"
#include "game/platform/TDGameManager.h"

using namespace cocos2d;

// Main Battle Process: check battle state and SwitchBattleState_________


namespace taomee {
namespace battle {


BattleController& BattleController::GetInstance()
{
  static BattleController* X = NULL;
  if (!X)
  {
    X = new BattleController();
    SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&X, "BattleController");
  }
  return *X;
}



BattleController::BattleController()
  : battle_state_machine_(NULL)

  , root_scene_(NULL)
  , battle_view_(NULL)
  , battle_ui_controller_(NULL)

  , battle_data_center_(NULL)

  , level_entity_(NULL)

  , actor_ext_env_(NULL)
{
  battle_state_machine_ = new StateMachine<BattleController>(this);

  //actor
  actor_ext_env_ = new actor::ActorExtEnv();
  actor::ActorScriptExporter::SetIsAutoControl(false);  //for game reset

  battle_data_center_ = new battle_data::BattleDataCenter(this);
  battle_data_center_->ResetData();
}

BattleController::~BattleController()
{
  //data clean up
  battle_state_machine_->ChangeState(NullState<BattleController>::Instance());

  GetBattleDataCenter()->ResetData();
  actor_ext_env_->Clear();

  SAFE_DEL(level_entity_);

  //ui
  SAFE_DEL(battle_view_);
  SAFE_DEL(battle_ui_controller_);
  if (root_scene_) root_scene_->removeAllChildrenWithCleanup(true);
  CC_SAFE_RELEASE_NULL(root_scene_);

  CC_SAFE_DELETE(battle_state_machine_);

  SAFE_DEL(battle_data_center_);
  SAFE_DEL(actor_ext_env_);
}





StateMachine<BattleController>* BattleController::GetStateMachine()
{
  return battle_state_machine_;
}

void BattleController::UpdateEachFrame(float delta)
{
  battle_state_machine_->UpdateEachFrame(delta);
}

void BattleController::Prepare(LoadHelper* load_helper)
{
  // what for? check "game_state_scene_transition.h"
}





void BattleController::Start(eBattleType battle_type,eBattleSceneType scene_type,int level_id)
{
  CCLog("[BattleController][Start]");
  CCLog("-- BattleType: %d\n-- SceneType: %d\n-- LevelId: %d",
    battle_type, 
    scene_type, 
    level_id);

  //data init
  GetBattleDataCenter()->Init(battle_type, scene_type, level_id);


  //level
  level_entity_ = LevelBase::CreateLevel(battle_type, scene_type);
  level_entity_->Initialize();


  //battle scene, root node of all ui
  root_scene_ = CCScene::create();
  root_scene_->retain();

  if (CCDirector::sharedDirector()->getRunningScene() != NULL) 
    CCDirector::sharedDirector()->replaceScene(root_scene_);
  else 
    CCDirector::sharedDirector()->runWithScene(root_scene_);

  // TODO: not sure what this is
  taomee::GameManager::GetInstance().SetCurrentTemplateScene(NULL);


  // create battle view and switch scene
  battle_view_ = new BattleView(root_scene_); 


  // create battle ui controller
  battle_ui_controller_ = new ui::BattleUIController(this, root_scene_);
  battle_ui_controller_->CreateBattleLoading(); // create battle loading layer


  //etc
  SDKManager::getInstance()->setToolbarVisible(false);
  

  //actor
  actor_ext_env_->Clear();
  actor_ext_env_->SetIsPause(false);


  // send start message
  SwitchBattleStateMessage();
}




void BattleResultDataStatic(
  int battle_type, 
  int scene_type, 
  bool is_battle_win, 
  int battle_time, 
  int battle_level_id)
{
  std::string send_data = "";

  //=====================================================send to talking data
  if(battle_type == kBattleType_PVE_Manual)
  {
    if(is_battle_win == true)
    {
      send_data = Int2String(battle_level_id);
      TDGameManager::getInstance()->onCompleted(send_data);

      send_data = Int2String(battle_level_id);
      send_data += "&";
      send_data += Int2String(battle_time);
      TDGameManager::getInstance()->onSelfEvent("battleSucLeftTime", "checkPoint&leftTime", send_data);
    }
    else
    {
      send_data = Int2String(battle_level_id);
      TDGameManager::getInstance()->onFailed(send_data, "dead des");
    }
  }
  else if(scene_type == kBattleSceneType_ArenaPK)
  {
    if(is_battle_win == true) TDGameManager::getInstance()->onCompleted("arenaBattle");//don't change this string
    else TDGameManager::getInstance()->onFailed("arenaBattle", "arena dead");//don't change this string
  }
}


void BattleController::End()
{
  CCLog("[BattleController][End]");
  CCLog("-- BattleType: %d\n-- SceneType: %d\n-- LevelId: %d\n-- ResultIsWin: %d\n-- TimeBattleActive: %f",
    GetBattleStatus(battle_data::kBattleStatusBattleType), 
    GetBattleStatus(battle_data::kBattleStatusSceneType), 
    GetBattleStatus(battle_data::kBattleStatusLevelId), 
    GetBattleStatusBool(battle_data::kBattleStatusResultIsWin) ? 1 : 0, 
    GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActive));

  // BATTLE STATE CHANGE
  SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateMarkEnd);

  //data log
  BattleResultDataStatic(
    GetBattleStatus(battle_data::kBattleStatusBattleType), 
    GetBattleStatus(battle_data::kBattleStatusSceneType), 
    GetBattleStatusBool(battle_data::kBattleStatusResultIsWin), 
    GetBattleAttribute(battle_data::kBattleAttributeTimeBattleActive), 
    GetBattleStatus(battle_data::kBattleStatusLevelId)
    );

  //data clean up
  battle_state_machine_->ChangeState(NullState<BattleController>::Instance());

  actor::ActorScriptExporter::SetIsAutoControl(false);

  GetBattleDataCenter()->ResetData();
  actor_ext_env_->Clear();

  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle_level/level_item_drop.lua", 
    "CallLevelDropItemFunction", 
    "Clear");

  GameManager::GetInstance().OnBattleCompleted();

  //======================================================
  SAFE_DEL(level_entity_);

  SAFE_DEL(battle_view_);
  SAFE_DEL(battle_ui_controller_);
  root_scene_->removeAllChildrenWithCleanup(true);
  CC_SAFE_RELEASE_NULL(root_scene_);
}







void BattleController::SwitchBattleStateMessage()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateMessage]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateMessage::Instance());
}
void BattleController::SwitchBattleStateDrama()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateDrama]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateDrama::Instance());
}


void BattleController::SwitchBattleStatePreload()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStatePreload]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStatePreload::Instance());
}
void BattleController::SwitchBattleStateBattleStart()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateBattleStart]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateBattleStart::Instance());
}
void BattleController::SwitchBattleStateBattle()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateBattle]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateBattle::Instance());

  CCDirector::sharedDirector()->resume();
  battle_view_->SetTouchFliterEnable(true);//this is used to prevent Touch helper shield the Touch event before the ui receive it
}
void BattleController::SwitchBattleStatePause()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStatePause]", double(clock()) / CLOCKS_PER_SEC);
  assert(battle_state_machine_->CurrentState() == BattleStateBattle::Instance());
  battle_state_machine_->ChangeState(BattleStatePause::Instance());

  CCDirector::sharedDirector()->pause();
  battle_view_->SetTouchFliterEnable(false);//this is used to prevent Touch helper shield the Touch event before the ui receive it
}

void BattleController::SwitchBattleStateSwitchWave()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateSwitchWave]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateSwitchWave::Instance());
}
void BattleController::SwitchBattleStateBattleEnd()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateBattleEnd]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateBattleEnd::Instance());
}
void BattleController::SwitchBattleStateResult()
{
  CCLog("<%.3fs>[BattleController][SwitchBattleStateResult]", double(clock()) / CLOCKS_PER_SEC);
  battle_state_machine_->ChangeState(BattleStateResult::Instance());
}





void BattleController::SandboxWin(bool is_battle_win)
{
  if (battle_state_machine_->CurrentState() != BattleStateBattle::Instance())
    return;

  level_entity_->SetBattleEndState(kBattleEndResultWin);
}






bool BattleController::BattleClassPreload()
{
  CCLog("<%.3fs>[BattleController][LoadResource]", double(clock()) / CLOCKS_PER_SEC);
  // load common resource
  cocos2d::CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("textures/battle/battle_ex.plist");
  cocos2d::CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/ui_icon/ui_icon_ex.plist");


  CCLog("<%.3fs>[BattleController][CreateBattleActorData]", double(clock()) / CLOCKS_PER_SEC);
  //collect and push battle actor data

  bool is_new_level_layout = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_new_level_layout");
  if (is_new_level_layout 
    && GetBattleStatus(battle_data::kBattleStatusSceneType) == kBattleSceneType_Mission)
  {
    //parse enemy actor BattleActorData from DataTable
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle_level/level_actor_layout_parser.lua", 
      "ParseLevelActorLayout", 
      GetBattleStatus(battle_data::kBattleStatusBattleType), 
      GetBattleStatus(battle_data::kBattleStatusSceneType), 
      GetBattleStatus(battle_data::kBattleStatusLevelId));
  }
  else
  {
    // [LEGACY_CHECKPOINT_SCRIPT] from script; WARNING: this will call Battle_Init function in <checkpoint.lua>, and get battle actor data
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
      "CallActiveBattleDataScriptFunc", 
      "Battle_Init");
  }
  
  //from team/message data
  level_entity_->CreateBattleActorData();


  //check boss script(skill overload)
  std::map<int, battle_data::BattleActorData*>& battle_actor_data_map = GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorDataMap();
  for (std::map<int, battle_data::BattleActorData*>::iterator iterator = battle_actor_data_map.begin(); iterator != battle_actor_data_map.end(); iterator ++)
  {
    battle_data::BattleActorData* battle_actor_data = iterator->second;

    //enemy only
    if (battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] == actor::kActorFactionUserOppose
      && battle_actor_data->status_map[battle_data::kBattleStatusActorInitMarkIsWaveBoss] > 0)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle_level/boss_skill_overload_config.lua", 
        "CheckBossSkillOverload", 
        battle_actor_data);
    }
  }


  //pack drop item enemy_actor_id_list
  std::list<battle_data::BattleActorData*>* battle_actor_data_list = GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorDataListByWaveOrder();
  if (battle_actor_data_list->size() > 0)
  {
    lua_tinker::table enemy_actor_id_list = lua_tinker::table(lua_data_tunnel::GetLuaState());
    int enemy_actor_id_list_index = 1;

    for (std::list<battle_data::BattleActorData*>::iterator iterator = battle_actor_data_list->begin(); iterator != battle_actor_data_list->end(); iterator ++)
    {
      battle_data::BattleActorData* battle_actor_data = *iterator;

      //enemy only
      if (battle_actor_data->status_map[battle_data::kBattleStatusActorInitFaction] == actor::kActorFactionUserOppose)
      {
        bool is_enemy_boss = battle_actor_data->status_map[battle_data::kBattleStatusActorInitMarkIsWaveBoss] > 0;

        enemy_actor_id_list.set(enemy_actor_id_list_index ++, battle_actor_data->actor_id);
        if (is_enemy_boss)//boss count as 3
        {
          enemy_actor_id_list.set(enemy_actor_id_list_index ++, battle_actor_data->actor_id);
          enemy_actor_id_list.set(enemy_actor_id_list_index ++, battle_actor_data->actor_id);
        }
      }
    }

    //distribute drop item logic to enemy
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle_level/level_item_drop.lua", 
      "CallLevelDropItemFunction", 
      "AssignDropItemToActor", 
      enemy_actor_id_list);
  }
  delete battle_actor_data_list;


  CCLog("<%.3fs>[BattleController][CreateStage]", double(clock()) / CLOCKS_PER_SEC);
  battle_view_->CreateBattleView();


  CCLog("<%.3fs>[BattleController][CreateMusic]", double(clock()) / CLOCKS_PER_SEC);
  //preload??
  int boss_music_id = GetLuaMusic("kSIDBoss_bgm");
  int win_music_id = GetLuaMusic("kSIDWin_bgm");

  return true;
}


void BattleController::BattleClassClear()
{
  LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_add_xp.lua", "CloseLuaBattleAddXp");

  //clear ext effect / damage / user operation
  actor_ext_env_->GetActorExtEffect()->Clear();
  actor_ext_env_->GetActorExtDamage()->Clear();

  battle_ui_controller_->RemoveSkillMask();

}


void BattleController::BattleResult()
{
  // still messy, but merged
  LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/mission/main_mission_util.lua", 
    "NotifyCheckPointComplete",
    GetBattleStatus(battle_data::kBattleStatusBattleType), 
    GetBattleStatus(battle_data::kBattleStatusSceneType), 
    GetBattleStatusBool(battle_data::kBattleStatusResultIsWin), 
    GetBattleStatus(battle_data::kBattleStatusLevelId));

  if (GetBattleStatusBool(battle_data::kBattleStatusResultIsWin))
  {
    battle_data_center_->GetBattleActorDataCenter()->ResetBattleActorForBattleResult(); // create all characters & set default AI
  }
}








void BattleController::BattleUpdate(float delta_time)
{
  AddBattleAttribute(battle_data::kBattleAttributeTimeTotal, delta_time); //Debug Time
  delta_time = delta_time > 1 ? 1 : delta_time;  //for debug, limit time delta to max 1.0sec
  AddBattleAttribute(battle_data::kBattleAttributeTimeBattleTotal, delta_time);

  //no pause only
  if (GetBattleStatusBool(battle_data::kBattleStatusIsPaused) == false
    && GetBattleStatusBool(battle_data::kBattleStatusIsSkillMask) == false)
  {
    AddBattleAttribute(battle_data::kBattleAttributeTimeBattleActive, delta_time);

    battle_data_center_->Update(delta_time);  //update data, and POP new Actor if time is right

    level_entity_->BattleUpdate(delta_time);
  }

  // update actor
  actor_ext_env_->Update(delta_time);

  // battle view handler
  battle_view_->Update(delta_time);

  // update battle ui
  battle_ui_controller_->UpdateBattleUI(delta_time);
}


void BattleController::SwitchWaveUpdate(float delta_time)
{
  AddBattleAttribute(battle_data::kBattleAttributeTimeTotal, delta_time);
  delta_time = delta_time > 1 ? 1 : delta_time;  //for debug, limit time delta to max 1.0sec
  AddBattleAttribute(battle_data::kBattleAttributeTimeBattleTotal, delta_time);
  AddBattleAttribute(battle_data::kBattleAttributeTimeSwitchWave, delta_time);

  //level specific switch wave logic, maybe
  level_entity_->SwitchWaveUpdate(delta_time);

  actor_ext_env_->Update(delta_time);

  // battle view update
  battle_view_->Update(delta_time);

  // update battle ui
  battle_ui_controller_->UpdateBattleUI(delta_time);
}





void BattleController::ToggleBattleStatePause(bool is_pause)
{
  bool is_current_paused = battle_state_machine_->CurrentState() == BattleStatePause::Instance();
  if (is_current_paused == is_pause)
  {
    return;
  }

  if (is_pause) SwitchBattleStatePause();
  else SwitchBattleStateBattle();
}



void BattleController::AppEnterBackgroundDuringBattleState()
{
//   battle_touch_handler_->SetDisableTouch(true);
//   battle_touch_handler_->SetDisableTouch(false);
}


void BattleController::AddNodeByLayerType(cocos2d::CCNode *node, eBattleLayerType layer_type/* = kBattleLayerTop*/)
{
  battle_view_->AddNodeByLayerType(node, layer_type);
}


void BattleController::AddCCLayeToBattleSceneCenter(cocos2d::CCLayer *layer)
{
  layer->ignoreAnchorPointForPosition(false);
  layer->setAnchorPoint(ccp(0.5f, 0.5f));
  layer->setPosition(ccp(root_scene_->getContentSize().width * 0.5f,
                          root_scene_->getContentSize().height * 0.5f));
  root_scene_->addChild(layer, kBattleUIMax);
}


void BattleController::TriggerSpecialSkillRelease(int actor_id)
{
  actor::Actor* actor = GetActorExtEnv()->GetActorById(actor_id);
  if (!actor)
  {
    return;
  }


  int special_skill_id = actor->GetActorData()->GetSkillData()->GetSkillIdByType(actor::kActorSkillSpecial);
  if (special_skill_id <= 0  
    || actor->GetActorData()->GetSkillData()->IsSkillValid(special_skill_id) == false)
  {
    return;
  }

  // [LEGACY_CHECKPOINT_SCRIPT] 
  bool is_prevent_release = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", 
    "CallActiveBattleDataScriptFunc", 
    "Battle_Skill_Release", 
    actor_id);
  if (is_prevent_release)
  {
    return;
  }

  bool is_success = battle_ui_controller_->StartSkillMask(actor_id);
  if (is_success)
  {
    actor->GetActorData()->GetLog()->AddErrorLogF("[BattleUIController][SkillReleaseButtonSelected] set special_skill_id: %d", special_skill_id);

    actor->GetActorData()->GetControlData()->AddIdOperation(
      actor::kActorControlOperationIdSkillAttack, 
      actor::kActorControlPriorityAttackSpecialManual, 
      special_skill_id);

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(actor::kActorMotionStateAttack));
  }
}


// Lua API 2.0

//direct access to BattleAttributeData
bool BattleController::CheckBattleAttribute(int data_key)
{ return GetBattleDataCenter()->CheckBattleAttribute((battle_data::eBattleAttributeType)data_key); }
//normal access, with event
void BattleController::InitBattleAttribute(int data_key, float base/* = 0*/, float add/* = 0*/, float multiplier/* = 1*/, float extra/* = 0*/)
{ GetBattleDataCenter()->InitBattleAttribute((battle_data::eBattleAttributeType)data_key, base, add, multiplier, extra); }
void BattleController::SetBattleAttribute(int data_key, float add/* = 0*/, float multiplier/* = 1*/, float extra/* = 0*/)
{ GetBattleDataCenter()->SetBattleAttribute((battle_data::eBattleAttributeType)data_key, add, multiplier, extra); }
void BattleController::AddBattleAttribute(int data_key, float add/* = 0*/, float multiplier/* = 0*/, float extra/* = 0*/)
{ GetBattleDataCenter()->AddBattleAttribute((battle_data::eBattleAttributeType)data_key, add, multiplier, extra); }
float BattleController::GetBattleAttribute(int data_key)
{ return GetBattleDataCenter()->GetBattleAttribute((battle_data::eBattleAttributeType)data_key); }

//direct access to BattleStatusData
bool BattleController::CheckBattleStatus(int data_key)
{ return GetBattleDataCenter()->CheckBattleStatus((battle_data::eBattleStatusType)data_key); }
//normal access, with event
void BattleController::InitBattleStatus(int data_key, int status)
{ GetBattleDataCenter()->InitBattleStatus((battle_data::eBattleStatusType)data_key, status); }
void BattleController::SetBattleStatus(int data_key, int status)
{ GetBattleDataCenter()->SetBattleStatus((battle_data::eBattleStatusType)data_key, status); }
int BattleController::GetBattleStatus(int data_key)
{ return GetBattleDataCenter()->GetBattleStatus((battle_data::eBattleStatusType)data_key); }
//normal access, with event
void BattleController::InitBattleStatusBool(int data_key, bool bool_status)
{ GetBattleDataCenter()->InitBattleStatusBool((battle_data::eBattleStatusType)data_key, bool_status); }
void BattleController::SetBattleStatusBool(int data_key, bool bool_status)
{ GetBattleDataCenter()->SetBattleStatusBool((battle_data::eBattleStatusType)data_key, bool_status); }
bool BattleController::GetBattleStatusBool(int data_key)
{ return GetBattleDataCenter()->GetBattleStatusBool((battle_data::eBattleStatusType)data_key); }

//direct access to BattlePositionData
bool BattleController::CheckBattlePosition(int data_key)
{ return GetBattleDataCenter()->CheckBattlePosition((battle_data::eBattlePositionType)data_key); }
void BattleController::InitBattlePosition(int data_key, cocos2d::CCPoint position)
{ GetBattleDataCenter()->InitBattlePosition((battle_data::eBattlePositionType)data_key, position); }
void BattleController::SetBattlePosition(int data_key, cocos2d::CCPoint position)
{ GetBattleDataCenter()->SetBattlePosition((battle_data::eBattlePositionType)data_key, position); }
cocos2d::CCPoint& BattleController::GetBattlePosition(int data_key)
{ return GetBattleDataCenter()->GetBattlePosition((battle_data::eBattlePositionType)data_key); }


void BattleController::ClearTouchLimit()
{
  CCLog("[BattleController][ClearTouchLimit]");

  GetBattleDataCenter()->GetBattleStatusData(battle_data::kBattleStatusIsTouchLimited)->Reset();

  GetBattleDataCenter()->GetBattleStatusData(battle_data::kBattleStatusTouchLimitSourceId)->Reset();
  GetBattleDataCenter()->GetBattleStatusData(battle_data::kBattleStatusTouchLimitTargetId)->Reset();
  GetBattleDataCenter()->GetBattlePositionData(battle_data::kBattlePositionTouchLimitTargetGrid)->Reset();
}

bool BattleController::SetTouchLimitFromActorId(int actor_id_from)
{
  if (GetActorExtEnv()->GetActorById(actor_id_from) != NULL)
  {
    CCLog("[BattleController][SetTouchLimitFromActorId] actor_id_from: %d", actor_id_from);

    GetBattleDataCenter()->SetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited, true);
    GetBattleDataCenter()->SetBattleStatus(battle_data::kBattleStatusTouchLimitSourceId, actor_id_from);
    return true;
  }
  else
  {
    return false;
  }
}
bool BattleController::SetTouchLimitFromActorIdToActorId(int actor_id_from, int actor_id_to)
{
  if (GetActorExtEnv()->GetActorById(actor_id_from) != NULL 
    && GetActorExtEnv()->GetActorById(actor_id_to) != NULL)
  {
    CCLog("[BattleController][SetTouchLimitFromActorIdToActorId] actor_id_from: %d, actor_id_to: %d", actor_id_from, actor_id_to);

    GetBattleDataCenter()->SetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited, true);
    GetBattleDataCenter()->SetBattleStatus(battle_data::kBattleStatusTouchLimitSourceId, actor_id_from);
    GetBattleDataCenter()->SetBattleStatus(battle_data::kBattleStatusTouchLimitTargetId, actor_id_to);
    return true;
  }
  else
  {
    return false;
  }
}
bool BattleController::SetTouchLimitFromActorIdToGrid(int actor_id_from, cocos2d::CCPoint grid_position_to)
{
  if (GetActorExtEnv()->GetActorById(actor_id_from) != NULL)
  {
    CCLog("[BattleController][SetTouchLimitFromActorIdToGrid] actor_id_from: %d, grid_position: (%f,%f)", actor_id_from, grid_position_to.x, grid_position_to.y);

    GetBattleDataCenter()->SetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited, true);
    GetBattleDataCenter()->SetBattleStatus(battle_data::kBattleStatusTouchLimitSourceId, actor_id_from);
    GetBattleDataCenter()->SetBattlePosition(battle_data::kBattlePositionTouchLimitTargetGrid, grid_position_to);
    return true;
  }
  else
  {
    return false;
  }
}
} /* namespace battle */
} /* namespace taomee */
