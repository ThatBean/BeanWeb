
//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_layer.h
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_LAYER_H_
#define BATTLE_LAYER_H_

#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/battle_constants.h"

namespace taomee {
namespace battle {

class TouchHandler;

class BattleLayer : public cocos2d::CCLayer {
public:
  BattleLayer();
  virtual ~BattleLayer();

  CREATE_FUNC(BattleLayer);
  virtual bool init();

public:
  // touch
  virtual void ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
  virtual void ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
  virtual void ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);
  virtual void ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent);

  void SetTouchHandler(TouchHandler* touch_handler) { touch_handler_ = touch_handler; }

public:
  void AddNodeToLayer(cocos2d::CCNode* element, eBattleLayerType layer_type);
  cocos2d::CCLayer* GetLayer(eBattleLayerType layer_type);

private:
  TouchHandler* touch_handler_;
};

} /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_LAYER_H_ */
