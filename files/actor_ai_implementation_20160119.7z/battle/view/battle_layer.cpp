//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_layer.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////
#include "engine/base/basictypes.h"
#include "game/battle/view/battle_layer.h"

#include "game/battle/touch/touch_handler.h"

using namespace cocos2d;

namespace taomee {
  namespace battle {

    float GetBattleLayerScale()
    {
      CCSize window_size = CCDirector::sharedDirector()->getWinSize();
      float battle_scale = (std::min)(
          window_size.width / BATTLE_DESIGN_SIZE.width, 
          window_size.height / BATTLE_DESIGN_SIZE.height);
      return battle_scale;
    }




    BattleLayer::BattleLayer()
      : touch_handler_(NULL)
    {

    }

    BattleLayer::~BattleLayer()
    {
      touch_handler_ = NULL;
    }

    bool BattleLayer::init()
    {
      if (!CCLayer::init())
      {
        return false;
      }

      const CCSize battle_layer_size = BATTLE_DESIGN_SIZE;

      this->setContentSize(battle_layer_size);
      this->ignoreAnchorPointForPosition(false);
      this->setAnchorPoint(ccp(0.5f, 0.5f)); 
      this->setScale(GetBattleLayerScale() * 0.9f);

      //create layers
      for (int i = kBattleLayerBottom; i <= kBattleLayerTop; ++i) 
      {
        CCLayer* layer = CCLayer::create();
        layer->setContentSize(battle_layer_size);
        layer->setPosition(ccp(battle_layer_size.width * 0.5f, battle_layer_size.height * 0.5f));
        layer->setAnchorPoint(ccp(0.5f, 0.5f));
        layer->ignoreAnchorPointForPosition(false);
        this->addChild(layer, i, i);
      }

      // enable touch
      this->setTouchEnabled(true);

      return true;
    }

    void BattleLayer::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
    {
      if (touch_handler_ != NULL)
      {
        touch_handler_->OnTouchesBegan(pTouches, pEvent, this->GetLayer(kBattleLayerMiddle));
      }
    }

    void BattleLayer::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
    {
      if (touch_handler_ != NULL)
      {
        touch_handler_->OnTouchesMoved(pTouches, pEvent, this->GetLayer(kBattleLayerMiddle));
      }
    }

    void BattleLayer::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
    {
      if (touch_handler_ != NULL)
      {
        touch_handler_->OnTouchesEnded(pTouches, pEvent, this->GetLayer(kBattleLayerMiddle));
      }
    }

    void BattleLayer::ccTouchesCancelled(cocos2d::CCSet *pTouches, cocos2d::CCEvent *pEvent)
    {

    }

    cocos2d::CCLayer* BattleLayer::GetLayer(eBattleLayerType layer_type)
    {
      assert(layer_type >= kBattleLayerBottom && layer_type <= kBattleLayerTop);
      CCLayer* layer = dynamic_cast<CCLayer*>(this->getChildByTag(layer_type));
      return layer;
    }

    void BattleLayer::AddNodeToLayer(cocos2d::CCNode* element, eBattleLayerType layer_type)
    {
      assert(element != NULL);
      assert(layer_type >= kBattleLayerBottom && layer_type <= kBattleLayerTop);
      CCLayer* layer = this->GetLayer(layer_type);
      if (layer != NULL) 
      {
        layer->addChild(element);
      } 
      else 
      {
        assert(false);
      }
    }

  } /* namespace battle */
} /* namespace taomee */
