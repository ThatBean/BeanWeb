//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-29
//          Time:  9:56
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-29        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_damage_label_h
#define ChainChronicle_battle_damage_label_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
  namespace battle {

    enum eDamageType
    {
      eDamageTypeMiss = 1,
      eDamageTypeCritical,
      eDamageTypeHeal,
      eDamageTypeNormal,
      eDamageTypeStatus,
    };

    enum eDamageElementType
    {
      eDamageElementTypeNormal = 0,
      eDamageElementTypeFire,
      eDamageElementTypeWater,
      eDamageElementTypeWind,
      eDamageElementTypeLight,
      eDamageElementTypeDark,
    };

    class DamageLabel : public cocos2d::CCNode
    {
    public:
      static DamageLabel* create();
      ~DamageLabel();

    protected:
      DamageLabel();

    public:
      void ShowDamageLabelOnBattleLayer(
        int actor_faction,
        eDamageType damage_type, 
        eDamageElementType damage_element_type,
        int element_correction, 
        int damage_value, 
        cocos2d::CCPoint& show_postion);
    };

  } // namespace battle
} // namespace taomee

#endif // ChainChronicle_battle_damage_label_h
