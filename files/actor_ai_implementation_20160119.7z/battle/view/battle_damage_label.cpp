//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.cpp
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-29
//          Time:  9:56
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-29        1         create
//////////////////////////////////////////////////////////////

#include "game/battle/view/battle_damage_label.h"

#include "game/battle/view/battle_view.h"
#include "game/effect/CCShake.h"
#include "game/battle/battle_controller.h"
#include "game/data_table/damage_label_config_data_table.h"
#include "game/game_manager/data_manager.h"

using namespace cocos2d;

namespace taomee {
  namespace battle {

    namespace damage_label {

      //action config
      static const float __scale = 0.5f;
      static const float __duration_enter = 0.1f;
      static const float __duration_delay = 0.3f;
      static const float __duration_exit = 0.2f;
      static const float __distance_exit_y = 100.0f;

      static int __z_order = 1 << 30;

      void __run_label_action(CCNode* node)
      {
        node->setZOrder(__z_order --);

        node->runAction(
          CCSequence::create(

            CCEaseIn::create(CCScaleTo::create(__duration_enter, __scale), 1.4), 

            CCDelayTime::create(__duration_delay), 

            CCSpawn::create(
              CCMoveBy::create(__duration_exit, CCPoint(0, __distance_exit_y)), 
              CCFadeOut::create(__duration_exit), 
              NULL),

            CCRemoveSelf::create(),

            NULL
          )
        );
      }

    }

    DamageLabel::DamageLabel()
    {}

    DamageLabel::~DamageLabel()
    {}

    DamageLabel* DamageLabel::create()
    {
      DamageLabel* pRet = new DamageLabel();
      if (pRet)
      {
        pRet->autorelease();
        return pRet;
      }
      CC_SAFE_DELETE(pRet);
      return NULL;
    }

    void DamageLabel::ShowDamageLabelOnBattleLayer(
      int actor_faction,
      eDamageType damage_type, 
      eDamageElementType damage_element_type,
      int element_correction, 
      int damage_value,
      CCPoint& show_postion)
    {
      if (element_correction > 0)
        element_correction = 1;
      else if (element_correction < 0)
        element_correction = 2;

      int damage_label_config_id = 0;
      int char_width = 41;
      int char_height = 43;

      if ( damage_type == eDamageTypeNormal )
      {
        damage_label_config_id = 
          actor_faction 
          + damage_type * 10 
          + damage_element_type * 100 
          + element_correction * 1000;
      }
      else
      {
        damage_label_config_id = actor_faction + damage_type*10;
        if (damage_type == eDamageTypeCritical)
        {
          char_width = 43;
          char_height = 54;
        }
      }
      DamageLabelConfigData* damage_label_config_data = DataManager::GetInstance().GetDamageLabelConfigDataTable()->GetDamageLabelConfig(damage_label_config_id);

      if ( false == damage_label_config_data->GetStatusImagePath().empty())
      {
        CCSprite* sprite_bg = CCSprite::createWithSpriteFrameName(damage_label_config_data->GetStatusImagePath().c_str());
        sprite_bg->setScale(1.2);
        this->addChild(sprite_bg);
      }
      if ( damage_value != 0 )
      {
        std::ostringstream string_stream;
        string_stream << (damage_value >= 0 ? "-" : "+") << abs(damage_value) << std::endl;


        CCLabelAtlas* label_damage = CCLabelAtlas::create(
          string_stream.str().c_str(), 
          damage_label_config_data->GetAltasImagePath().c_str(), 
          char_width, 
          char_height, 
          '+');
        label_damage->setAnchorPoint(ccp(0.5f, 0.5f));
        this->addChild(label_damage);
      }

      show_postion.y = MAX(MIN(show_postion.y, taomee::battle::BATTLE_DESIGN_SIZE.height * 0.8f), taomee::battle::BATTLE_DESIGN_SIZE.height * 0.2f);


      taomee::battle::BattleController::GetInstance().GetBattleView()->AddNodeByLayerType(this, kBattleLayerTop);
      this->setPosition(show_postion);
      this->setScale(0.9f);
      damage_label::__run_label_action(this);
    }

  } // namespace battle
} // namespace taomee