#ifndef TASK_CUSTOM_DATA_H
#define TASK_CUSTOM_DATA_H

#include "task_data_typedef.h"
#include "task_data.h"
#include "task_custom_method.h"

namespace task {
  
  class SubTaskItemData
  {
  public:
    SubTaskItemData();

  public:
	  int	id;
    eTaskType type;
	  eTaskSubType sub_type;

    int unlock_user_level;
	  int unlock_time_start;
	  int unlock_time_end;
    int unlock_mission;
    std::set<int> unlock_day_in_week_set;

	  int requirement_level_id;
    int requirement_data_count;

    int last_finish_timestamp;

    string  name;
    string  desc;
    string  icon;

    std::list< std::pair<int, int> > reward_data_list;

    int requirement_link_func_id; //function id related to unlock this task
  };

  //============================================================================================

  TaskData* PackTaskData(eTaskType task_type, vector<SubTaskItemData*>& item_data_list);
  
  eTaskSubType ParseTaskSubType(eTaskType task_type, int sub_type_value);
  eTaskSubType ParseTaskSubTypeFromItemId(eTaskType task_type, int sub_type_item_id);

  //============================================================================================

  class SubTaskDataWithItem : public SubTaskData
  {
  public:
    SubTaskDataWithItem(eTaskType type_init, eTaskSubType sub_type_init);

    virtual bool CheckValid();
    virtual bool CheckUnlock();
    virtual bool CheckComplete();

    virtual void Update(int update_value);

    virtual bool FinishItem();  //is more Item

    virtual void Init(lua_tinker::table& init_data_table);

    virtual lua_tinker::table GetLuaDisplayData(); //lua display data

    SubTaskItemData* GetCurrentSubTaskItemData();

  public:
    std::map<int, SubTaskItemData*> item_data_map_;

    SubTaskCustomFunction function_init_;
    SubTaskCustomFunction function_update_;
    SubTaskCustomFunction function_finish_;
  };

} // namespace task


#endif // TASK_CUSTOM_DATA_H