#include "task_custom_data.h"

#include "game/data_table/daily_work_table.h"
#include "game/data_table/challenge_data_table.h"
#include "game/data_table/eventwork_data_table.h"

#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"

#include "engine/base/game_time.h"

namespace task {
  //SubTaskItemData
  SubTaskItemData::SubTaskItemData()
    : id(-1)
    , type(kTask)
    , sub_type(kTaskSub)

    , unlock_user_level(-1)
    , unlock_time_start(-1)
    , unlock_time_end(-1)
    , unlock_mission(-1)
    //, unlock_day_in_week_set

    , requirement_level_id(-1)
    , requirement_data_count(-1)

    , last_finish_timestamp(0)

    //, name
    //, desc
    //, icon

    //, reward_data_list

    , requirement_link_func_id(-1)
  {}
  //SubTaskItemData


  TaskData* PackTaskData(eTaskType task_type, vector<SubTaskItemData*>& item_data_list)
  {
    TaskData* task_data = new TaskData(task_type);

    //push SubTaskItemData to corresponding SubTaskDataWithItem
    for (vector<SubTaskItemData*>::iterator iterator = item_data_list.begin(); iterator != item_data_list.end(); iterator ++)
    {
      SubTaskItemData* sub_task_item_data = *iterator;
      eTaskSubType sub_task_type = eTaskSubType(sub_task_item_data->sub_type);

      if (task_data->sub_task_map.find(sub_task_type) == task_data->sub_task_map.end())
      {
        task_data->sub_task_map[sub_task_type] = new SubTaskDataWithItem(task_type, sub_task_type);
      }

      SubTaskDataWithItem* sub_task_data = dynamic_cast<SubTaskDataWithItem*>(task_data->sub_task_map[sub_task_type]);
      sub_task_data->item_data_map_[sub_task_item_data->id] = sub_task_item_data;
    }

    //call init
    lua_tinker::table init_data_table = lua_tinker::table(lua_data_tunnel::GetLuaState());
    init_data_table.set(1, 0);

    for (std::map<eTaskSubType, SubTaskData*>::iterator iterator = task_data->sub_task_map.begin(); iterator != task_data->sub_task_map.end(); iterator ++)
    {
      SubTaskData* sub_task_data = iterator->second;

      sub_task_data->Init(init_data_table);
    }


    return task_data;
  }




  eTaskSubType ParseTaskSubType(eTaskType task_type, int sub_type_value)
  {
    static std::map<int, eTaskSubType> convert_map_daily;
    if (convert_map_daily.empty())
    {
      convert_map_daily[1] = kTaskSubDailyBattleMain; //1.�ɹ������Ѷȵ����߹ؿ�
      convert_map_daily[13] = kTaskSubDailyBattleMainHard; //13.�ɹ����ѹؿ�����
      convert_map_daily[3] = kTaskSubDailyBattleArena; //3.�μӾ�����
      convert_map_daily[11] = kTaskSubDailyBattleExploreJam; //11.�ճ�����ͨ�أ�����̽���г�ͨ����������ݣ�
      convert_map_daily[14] = kTaskSubDailyBattleLongMarch; //14.���һ��ͨ����
      convert_map_daily[17] = kTaskSubDailyBattleGuild; //17.ÿ�վ��Źؿ�

      convert_map_daily[4] = kTaskSubDailyPurchaseTavern; //4.��ļ
      convert_map_daily[9] = kTaskSubDailyPurchaseGold; //9.������
      convert_map_daily[16] = kTaskSubDailyPurchaseWorshipPremium; //16.ÿ�ո߼�Ĥ��

      convert_map_daily[12] = kTaskSubDailyLevelUpCardSkill; //12.��ɫ��������

      convert_map_daily[8] = kTaskSubDailyCollectTimedApReward; //8.��ȡ����
      convert_map_daily[15] = kTaskSubDailyCollectRenewalTicketMonthly; //15.��ȡ�����¿�
      convert_map_daily[18] = kTaskSubDailyCollectRenewalTicketDaily; //18.��ȡ�տ�
    }


    static std::map<int, eTaskSubType> convert_map_challenge;
    if (convert_map_challenge.empty())
    {
      convert_map_challenge[100] = kTaskSubChallengeUserLevel; //100.��ҵȼ�
      convert_map_challenge[105] = kTaskSubChallengeUserCardStarCount; //105.���ǿ�������

      convert_map_challenge[102] = kTaskSubChallengeBattleMainEasy; //102.�򵥹ؿ�����
      convert_map_challenge[101] = kTaskSubChallengeBattleMainNormal; //101.��ͨ�ؿ�����
      convert_map_challenge[104] = kTaskSubChallengeBattleMainHard; //104.���ѹؿ�����
      convert_map_challenge[113] = kTaskSubChallengeBattleArena; //113.������ʤ������
      convert_map_challenge[115] = kTaskSubChallengeBattleLongMarch; //115.ͨ����ͨ�ؽ���

      convert_map_challenge[106] = kTaskSubChallengeCountCard; //106.��������
      convert_map_challenge[107] = kTaskSubChallengeCountCardStar3; //107.3�ǿ�������
      convert_map_challenge[108] = kTaskSubChallengeCountCardStar4; //108.4�ǿ�������
      convert_map_challenge[109] = kTaskSubChallengeCountCardStar5; //109.5�ǿ�������
      convert_map_challenge[110] = kTaskSubChallengeCountCardEvolve3; //110.��ɫ���׿�������3��
      convert_map_challenge[111] = kTaskSubChallengeCountCardEvolve6; //111.��ɫ���׿�������6��
      convert_map_challenge[112] = kTaskSubChallengeCountCardEvolve10; //112.��ɫ+4��������10��

      convert_map_challenge[116] = kTaskSubChallengePowerTeam; //116.����ս�����ﵽ��ֵ
      convert_map_challenge[117] = kTaskSubChallengeJoinGuild; //117.�������
    }


    static std::map<int, eTaskSubType> convert_map_event;
    if (convert_map_event.empty())
    {
      convert_map_event[1] = kTaskSubEventBattleMain; //1.�ɹ������Ѷȵ����߹ؿ�
      convert_map_event[2] = kTaskSubEventBattleArena; //2.�μӾ�����
      convert_map_event[8] = kTaskSubEventBattleMainHard; //8.�ɹ����ѹؿ�����
      convert_map_event[6] = kTaskSubEventBattleExploreJam; //6.�ճ�����ͨ�أ�����̽���г�ͨ����������ݣ�
      convert_map_event[9] = kTaskSubEventBattleLongMatch; //9.���һ��ͨ����
      convert_map_event[10] = kTaskSubEventBattleGuildBoss; //10.���Ÿ���

      convert_map_event[3] = kTaskSubEventPurchaseTavern; //3.��ļ
      convert_map_event[5] = kTaskSubEventPurchaseGold; //5.������
      convert_map_event[11] = kTaskSubEventPurchaseGem; //11.��ֵ
      convert_map_event[12] = kTaskSubEventConsumeGem; //12.������ʯ

      convert_map_event[4] = kTaskSubEventEquipEnchant; //4.װ����ħ
      convert_map_event[7] = kTaskSubEventLevelUpCardSkill; //7.��ɫ��������
      convert_map_event[13] = kTaskSubEventLogin; //13.�ۼƵ�¼����
    }


    switch (task_type)
    {
    case kTaskDaily:
      if (convert_map_daily.find(sub_type_value) == convert_map_daily.end())
      {
        CCLog("[ParseTaskSubType][kTaskDaily] missing value! task_type: %d, sub_type_value: %d", task_type, sub_type_value);
        //assert(false);
      }
      return convert_map_daily[sub_type_value];
    case kTaskChallenge:
      if (convert_map_challenge.find(sub_type_value) == convert_map_challenge.end())
      {
        CCLog("[ParseTaskSubType][kTaskChallenge] missing value! task_type: %d, sub_type_value: %d", task_type, sub_type_value);
        //assert(false);
      }
      return convert_map_challenge[sub_type_value];
    case kTaskEvent:
      if (convert_map_event.find(sub_type_value) == convert_map_event.end())
      {
        CCLog("[ParseTaskSubType][kTaskEvent] missing value! task_type: %d, sub_type_value: %d", task_type, sub_type_value);
        //assert(false);
      }
      return convert_map_event[sub_type_value];
    default:
      CCLog("[ParseTaskSubType] error task_type: %d, sub_type_value: %d", task_type, sub_type_value);
      assert(false);
      return kTaskSub;
    }
  }

  eTaskSubType ParseTaskSubTypeFromItemId(eTaskType task_type, int sub_type_item_id)
  {
    vector<task::SubTaskItemData*>* item_data_list = NULL;

    switch (task_type)
    {
    case kTaskDaily:
      item_data_list = &(DataManager::GetInstance().GetDailyWorkTable()->GetSubTaskItemDataList());
      break;
    case kTaskChallenge:
      item_data_list = &(DataManager::GetInstance().GetChallengeDataTable()->GetSubTaskItemDataList());
      break;
    case kTaskEvent:
      item_data_list = &(DataManager::GetInstance().GetEventworkDataTable()->GetSubTaskItemDataList());
      break;
    default:
      item_data_list = NULL;
      break;
    }

    if (item_data_list)
    {
      for (vector<task::SubTaskItemData*>::iterator iterator = item_data_list->begin(); iterator != item_data_list->end(); iterator ++)
      {
        SubTaskItemData* item_data = *iterator;

        if (sub_type_item_id == item_data->id)
        {
          return item_data->sub_type;
        }
      }
    }

    CCLog("[ParseTaskSubTypeFromItemId] missing id! task_type: %d, sub_type_item_id: %d", task_type, sub_type_item_id);
    assert(false);
    return kTaskSub;
  }






  //SubTaskDataWithItem
  SubTaskDataWithItem::SubTaskDataWithItem(eTaskType type_init, eTaskSubType sub_type_init)
    : SubTaskData(type_init, sub_type_init)
    , function_init_(NULL)
    , function_update_(NULL)
    , function_finish_(NULL)
  {
    function_init_ = GetSubTaskCustomInitFunction(type_init, sub_type_init);
    function_update_ = GetSubTaskCustomUpdateFunction(type_init, sub_type_init);
    function_finish_ = GetSubTaskCustomFinishFunction(type_init, sub_type_init);
  }

  bool SubTaskDataWithItem::CheckValid()
  {
    return !item_data_map_.empty();
  }

  bool SubTaskDataWithItem::CheckUnlock()
  {
    if (item_data_map_.empty() || is_finished)
      return false;

    SubTaskItemData* item_data = item_data_map_.begin()->second;

    bool is_unlock = CheckValid();

    data::UserInfo* user_info = DataManager::GetInstance().user_info();

    if (item_data->unlock_user_level > 0) is_unlock &= (user_info->rank() >= item_data->unlock_user_level);
    if (item_data->unlock_mission > 0) is_unlock &= (user_info->QueryMissionComplete(item_data->unlock_mission));

    uint_32 timestamp = taomee::GetTimestampServerWithServerTimeZone();
    int hour_in_day = GetTimeDataFromTimestamp(timestamp, taomee::kTimeDataTypeHour);
    int day_in_week = GetTimeDataFromTimestamp(timestamp, taomee::kTimeDataTypeDayOfWeek);

    //if (item_data->unlock_time_start >= 0) is_unlock &= (hour_in_day >= item_data->unlock_time_start);
    if (item_data->unlock_time_end >= 0) is_unlock &= (hour_in_day < item_data->unlock_time_end);

    if (item_data->unlock_day_in_week_set.empty() == false) is_unlock &= (item_data->unlock_day_in_week_set.find(day_in_week) != item_data->unlock_day_in_week_set.end());

    return is_unlock;
  }

  bool SubTaskDataWithItem::CheckComplete()
  {
    if (item_data_map_.empty() || is_finished)
      return false;

    SubTaskItemData* item_data = item_data_map_.begin()->second;

    bool is_complete = CheckUnlock();

    data::UserInfo* user_info = DataManager::GetInstance().user_info();

    uint_32 timestamp = taomee::GetTimestampServerWithServerTimeZone();
    int hour_in_day = GetTimeDataFromTimestamp(timestamp, taomee::kTimeDataTypeHour);

    if (item_data->unlock_time_start >= 0) is_complete &= (hour_in_day >= item_data->unlock_time_start);
    //if (item_data->unlock_time_end >= 0) is_complete &= (hour_in_day < item_data->unlock_time_end);

    if (item_data->requirement_data_count > 0) is_complete &= (data_count_current >= item_data->requirement_data_count);
    if (item_data->requirement_level_id > 0) is_complete &= (user_info->QueryCheckPointPassSucess(item_data->requirement_level_id));  //strange logic

    return is_complete;
  }


  void SubTaskDataWithItem::Update(int update_value)
  {
    if (function_update_)
    {
      function_update_(this, update_value);
    }
  }

  bool SubTaskDataWithItem::FinishItem()
  {
    if (is_finished)
      return true;

    if (item_data_map_.empty())
    {
      assert(false);
      return false;
    }

    assert(CheckComplete());

    data_count_current = 0;

    SubTaskItemData* item_data = item_data_map_.begin()->second;

    item_data->last_finish_timestamp = taomee::GetTimestampServer();

    if (function_finish_)
    {
      function_finish_(this, 0);
    }

    if (item_data_map_.size() == 1)
    {
      is_finished = true;
    }
    else
    {
      item_data_map_.erase(item_data_map_.begin());

      if (function_init_)
      {
        function_init_(this, 0);
      }
    }

    return (item_data_map_.size() > 0);
  }

  void SubTaskDataWithItem::Init(lua_tinker::table& init_data_table)
  {
    //     init_data_table = {
    //       task_sub_init_value,
    //       {
    //         {
    //           task_sub_item_id,
    //           task_sub_item_is_finished,
    //           task_sub_item_last_finished_timestamp,
    //         },
    //       },
    //     },

    data_count_current = init_data_table.get<int>(1);
    lua_tinker::table item_data_list_table = init_data_table.get<lua_tinker::table>(2);
    for (int index = 1, table_length = item_data_list_table.length(); index <= table_length; index ++)
    {
      lua_tinker::table item_data_table = item_data_list_table.get<lua_tinker::table>(index);

      int task_sub_item_id = item_data_table.get<int>(1);
      bool task_sub_item_is_finished = item_data_table.get<bool>(2);
      int task_sub_item_last_finished_timestamp = item_data_table.get<int>(3);

      for (std::map<int, SubTaskItemData*>::iterator iterator = item_data_map_.begin(); iterator != item_data_map_.end(); iterator ++)
      {
        SubTaskItemData* item_data = iterator->second;

        if (item_data->id == task_sub_item_id)
        {
          item_data->last_finish_timestamp = task_sub_item_last_finished_timestamp;

          if (task_sub_item_is_finished)
            item_data_map_.erase(iterator);

          break;
        }
      }
    }

    if (function_init_)
    {
      function_init_(this, 0);
    }
  }

  lua_tinker::table SubTaskDataWithItem::GetLuaDisplayData()
  {
    lua_tinker::table lua_display_data = SubTaskData::GetLuaDisplayData();

    if (item_data_map_.empty() == false)
    {
      SubTaskItemData* item_data = item_data_map_.begin()->second;

      lua_display_data.set("sub_task_item_id", item_data->id);
      
      lua_display_data.set("text_title", item_data->name.c_str());
      lua_display_data.set("text_description", item_data->desc.c_str());
      lua_display_data.set("image_src_icon", item_data->icon.c_str());

      lua_display_data.set("last_finish_timestamp", item_data->last_finish_timestamp);
      lua_display_data.set("requirement_checkpoint", item_data->requirement_level_id);
      lua_display_data.set("requirement_data_count", item_data->requirement_data_count);
      lua_display_data.set("requirement_link_func_id", item_data->requirement_link_func_id);

      lua_display_data.set("reward_item_list", lua_data_tunnel::ParseIntIntListToLuaTable(item_data->reward_data_list));
    }

    return lua_display_data;
  }

  SubTaskItemData* SubTaskDataWithItem::GetCurrentSubTaskItemData()
  {
    if (item_data_map_.empty())
      return NULL;
    else
      return item_data_map_.begin()->second;
  }
  //SubTaskDataWithItem

} // namespace task