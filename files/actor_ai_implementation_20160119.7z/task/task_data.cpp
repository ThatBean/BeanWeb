#include "task_data.h"

namespace task {

  //SubTaskData
  SubTaskData::SubTaskData(eTaskType type_init, eTaskSubType sub_type_init)
    : type(type_init)
    , sub_type(sub_type_init)
    , is_finished(false)
    , data_count_current(0)
  {}

  bool SubTaskData::CheckValid() 
  { 
    return true; 
  } //is any item at all
  
  bool SubTaskData::CheckUnlock() 
  { 
    return !is_finished; 
  }  //is any item waiting to complete
  bool SubTaskData::CheckComplete() 
  { 
    return !is_finished; 
  } //is any item waiting to finish

  void SubTaskData::Update(int update_value) 
  { 
    data_count_current = update_value; 
  }

  bool SubTaskData::FinishItem() 
  { 
    is_finished = true; 
    return false;   //return is more item
  }

  void SubTaskData::Init(lua_tinker::table& init_data_table) 
  { 
    data_count_current = init_data_table.get<int>(1); 
  }

  lua_tinker::table SubTaskData::GetLuaDisplayData() 
  { 
    lua_tinker::table lua_display_data(lua_data_tunnel::GetLuaState());

    lua_display_data.set("task_type", type);
    lua_display_data.set("sub_task_type", sub_type);

    lua_display_data.set("is_unlock", CheckUnlock());
    lua_display_data.set("is_complete", CheckComplete());
    lua_display_data.set("is_finished", is_finished);

    lua_display_data.set("data_count_current", data_count_current);
    
    return lua_display_data;
  }
  //SubTaskData



  //TaskData
  TaskData::~TaskData()
  {
    for (std::map<eTaskSubType, SubTaskData*>::iterator iterator = sub_task_map.begin(); iterator != sub_task_map.end(); iterator ++)
    {
      SubTaskData* sub_task = iterator->second;

      delete sub_task;
    }
  }

  bool  TaskData::CheckValid()
  {
    bool is_valid = false;

    for (std::map<eTaskSubType, SubTaskData*>::iterator iterator = sub_task_map.begin(); iterator != sub_task_map.end(); iterator ++)
    {
      SubTaskData* sub_task = iterator->second;

      is_valid |= sub_task->CheckValid();
    }

    return is_valid;
  }

  bool  TaskData::CheckNotify()
  {
    bool is_notify = false;

    for (std::map<eTaskSubType, SubTaskData*>::iterator iterator = sub_task_map.begin(); iterator != sub_task_map.end(); iterator ++)
    {
      SubTaskData* sub_task = iterator->second;

      is_notify |= sub_task->CheckComplete();
    }

    return is_notify;
  }


  void  TaskData::UpdateSubTask(eTaskSubType sub_type, int update_value)
  {
    if (sub_task_map.find(sub_type) != sub_task_map.end())
    {
      sub_task_map[sub_type]->Update(update_value);
    }
  }

  bool  TaskData::FinishSubTask(eTaskSubType sub_type)
  {
    if (sub_task_map.find(sub_type) != sub_task_map.end())
    {
      return sub_task_map[sub_type]->FinishItem();
    }

    return false;
  }

  void  TaskData::InitSubTask(eTaskSubType sub_type, lua_tinker::table& init_data_table)
  {
    if (sub_task_map.find(sub_type) != sub_task_map.end())
    {
      sub_task_map[sub_type]->Init(init_data_table);
    }
  }
  //TaskData

} // namespace task