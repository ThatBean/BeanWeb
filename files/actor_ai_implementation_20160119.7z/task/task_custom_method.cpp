#include "task_custom_method.h"

#include "task_data_typedef.h"
#include "task_data.h"
#include "task_custom_data.h"

#include "game/game_manager/data_manager.h"
#include "game/user_data/user_info.h"
#include "game/user_data/character_info.h"

#include "engine/base/game_time.h"

namespace task {

  void custom_function_decoy(SubTaskData* sub_task_data, int data_value)
  {
    //do nothing
  }

  void init_timed_ap_reward(SubTaskData* sub_task_data, int data_value)
  {
    SubTaskDataWithItem* sub_task_data_with_item = dynamic_cast<SubTaskDataWithItem*>(sub_task_data);

    if (!sub_task_data_with_item)
    {
      assert(false);
      return;
    }

    uint_32 timestamp = taomee::GetTimestampServerWithServerTimeZone();
    int hour_in_day = GetTimeDataFromTimestamp(timestamp, taomee::kTimeDataTypeHour);

    std::map<int, SubTaskItemData*>& item_data_map = sub_task_data_with_item->item_data_map_;
    while(item_data_map.empty() == false)
    {
      SubTaskItemData* item_data = item_data_map.begin()->second;

      bool is_unlock = true;

      //if (item_data->unlock_time_start >= 0) is_unlock &= (hour_in_day >= item_data->unlock_time_start);
      if (item_data->unlock_time_end >= 0) is_unlock &= (hour_in_day < item_data->unlock_time_end);

      if (is_unlock)
      {
        //valid timed ap item
        break;
      }
      else
      {
        //drop invalid time item
        item_data_map.erase(item_data_map.begin());
      }
    }

    SubTaskItemData* item_data = sub_task_data_with_item->GetCurrentSubTaskItemData();
    if (item_data)
      sub_task_data->data_count_current = item_data->requirement_data_count;
  }


  void init_renewel_ticket_monthly(SubTaskData* sub_task_data, int data_value)
  {
    SubTaskDataWithItem* sub_task_data_with_item = dynamic_cast<SubTaskDataWithItem*>(sub_task_data);

    if (!sub_task_data_with_item)
    {
      assert(false);
      return;
    }

    SubTaskItemData* item_data = sub_task_data_with_item->GetCurrentSubTaskItemData();

    item_data->unlock_time_end = int((
        (30 * 24 * 60 * 60) //30 days in seconds
        - DataManager::GetInstance().user_info()->getMonthCardStampPassTime()
      ) / 60 / 60); //in hour
  }




  


  void update_count_by_sum(SubTaskData* sub_task_data, int data_value)
  {
    sub_task_data->data_count_current += data_value;
  }

  void update_count_by_max(SubTaskData* sub_task_data, int data_value)
  {
    data_value = MAX(data_value, 0);
    sub_task_data->data_count_current = MAX(sub_task_data->data_count_current, data_value);
  }

  void update_count_by_daily_login(SubTaskData* sub_task_data, int data_value)
  {
    SubTaskDataWithItem* sub_task_data_with_item = dynamic_cast<SubTaskDataWithItem*>(sub_task_data);

    if (!sub_task_data_with_item)
    {
      assert(false);
      return;
    }

    SubTaskItemData* item_data = sub_task_data_with_item->GetCurrentSubTaskItemData();
    int day_last_finish = taomee::GetTimeDataFromTimestamp(item_data->last_finish_timestamp, kTimeDataTypeDay);

    int timestamp_server = taomee::GetTimestampServer();
    int day_current = taomee::GetTimeDataFromTimestamp(timestamp_server, kTimeDataTypeDay);

    if (day_last_finish != day_current)
    {
      sub_task_data->data_count_current ++;
      item_data->last_finish_timestamp = timestamp_server;
    }
  }



  static int quick_user_data_array[kTaskQuickUserDataMax];

  void __update_count_user_data()
  {
    data::UserInfo* user_info = DataManager::GetInstance().user_info();

    user_info->QueryTaskStatus(quick_user_data_array);
  }

  void update_count_from_user_data(SubTaskData* sub_task_data, int data_value)
  {
    switch (sub_task_data->sub_type)
    {
    case kTaskSubChallengeUserLevel:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataUserLevel];
      break;
    case kTaskSubChallengeUserCardStarCount:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataUserCardStar];
      break;
    case kTaskSubChallengeCountCard:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCount];
      break;
    case kTaskSubChallengeCountCardStar3:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCountStar3];
      break;
    case kTaskSubChallengeCountCardStar4:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCountStar4];
      break;
    case kTaskSubChallengeCountCardStar5:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCountStar5];
      break;
    case kTaskSubChallengeCountCardEvolve3:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCountEvolve3];
      break;
    case kTaskSubChallengeCountCardEvolve6:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCountEvolve6];
      break;
    case kTaskSubChallengeCountCardEvolve10:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataCardCountEvolve10];
      break;
    case kTaskSubChallengePowerTeam:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataPowerTeam];
      break;
    case kTaskSubEventPurchaseGem:
      sub_task_data->data_count_current = quick_user_data_array[kTaskQuickUserDataPurchasedGem];
      break;
    default:
      assert(false);
      break;
    }
  }
  

  void collect_renewal_ticket_daily(SubTaskData* sub_task_data, int data_value)
  {
    data::UserInfo* user_info = DataManager::GetInstance().user_info();

    user_info->AddLocalItemToUserBag(taomee::data::kItemTypeDailyRedeemTicket, -1); //reduce local item count
  }




  SubTaskCustomFunction GetSubTaskCustomInitFunction(eTaskType type, eTaskSubType sub_type)
  {
    static std::map<eTaskSubType, SubTaskCustomFunction> function_init_map;

    if (function_init_map.empty())
    {
      function_init_map[kTaskSubDailyCollectTimedApReward] = &init_timed_ap_reward;

      function_init_map[kTaskSubDailyCollectRenewalTicketMonthly] = &init_renewel_ticket_monthly;


      function_init_map[kTaskSubChallengeUserLevel] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeUserCardStarCount] = &update_count_from_user_data;
      
      function_init_map[kTaskSubChallengeCountCard] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeCountCardStar3] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeCountCardStar4] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeCountCardStar5] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeCountCardEvolve3] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeCountCardEvolve6] = &update_count_from_user_data;
      function_init_map[kTaskSubChallengeCountCardEvolve10] = &update_count_from_user_data;

      function_init_map[kTaskSubChallengePowerTeam] = &update_count_from_user_data;


      function_init_map[kTaskSubEventPurchaseGem] = &update_count_from_user_data;
    }

    if (function_init_map.find(sub_type) != function_init_map.end())
      return function_init_map[sub_type];
    else
      return NULL;
  }




  SubTaskCustomFunction GetSubTaskCustomUpdateFunction(eTaskType type, eTaskSubType sub_type)
  {
    static std::map<eTaskSubType, SubTaskCustomFunction> function_update_map;

    if (function_update_map.empty())
    {
      function_update_map[kTaskSub] = &custom_function_decoy;


      function_update_map[kTaskSubDailyBattleMain] = &update_count_by_sum;
      function_update_map[kTaskSubDailyBattleMainHard] = &update_count_by_sum;
      function_update_map[kTaskSubDailyBattleArena] = &update_count_by_sum;
      function_update_map[kTaskSubDailyBattleExploreJam] = &update_count_by_sum;
      function_update_map[kTaskSubDailyBattleLongMarch] = &update_count_by_sum;
      function_update_map[kTaskSubDailyBattleGuild] = &update_count_by_sum;

      function_update_map[kTaskSubDailyPurchaseTavern] = &update_count_by_sum;
      function_update_map[kTaskSubDailyPurchaseGold] = &update_count_by_sum;
      function_update_map[kTaskSubDailyPurchaseWorshipPremium] = &update_count_by_sum;

      function_update_map[kTaskSubDailyLevelUpCardSkill] = &update_count_by_sum;

      function_update_map[kTaskSubDailyCollectTimedApReward] = &custom_function_decoy;
      function_update_map[kTaskSubDailyCollectRenewalTicketMonthly] = &update_count_by_sum;
      function_update_map[kTaskSubDailyCollectRenewalTicketDaily] = &update_count_by_sum;


      function_update_map[kTaskSubChallengeUserLevel] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeUserCardStarCount] = &update_count_from_user_data;


      function_update_map[kTaskSubChallengeCountCard] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeCountCardStar3] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeCountCardStar4] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeCountCardStar5] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeCountCardEvolve3] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeCountCardEvolve6] = &update_count_from_user_data;
      function_update_map[kTaskSubChallengeCountCardEvolve10] = &update_count_from_user_data;

      function_update_map[kTaskSubChallengePowerTeam] = &update_count_from_user_data;
      
      function_update_map[kTaskSubChallengeBattleMainEasy] = &custom_function_decoy;
      function_update_map[kTaskSubChallengeBattleMainNormal] = &custom_function_decoy;
      function_update_map[kTaskSubChallengeBattleMainHard] = &custom_function_decoy;
      function_update_map[kTaskSubChallengeBattleArena] = &update_count_by_sum;
      function_update_map[kTaskSubChallengeBattleLongMarch] = &update_count_by_max;

      function_update_map[kTaskSubChallengeJoinGuild] = &update_count_by_sum;


      function_update_map[kTaskSubEventBattleMain] = &update_count_by_sum;
      function_update_map[kTaskSubEventBattleArena] = &update_count_by_sum;
      function_update_map[kTaskSubEventBattleMainHard] = &update_count_by_sum;
      function_update_map[kTaskSubEventBattleExploreJam] = &update_count_by_sum;
      function_update_map[kTaskSubEventBattleLongMatch] = &update_count_by_sum;
      function_update_map[kTaskSubEventBattleGuildBoss] = &update_count_by_sum;

      function_update_map[kTaskSubEventPurchaseTavern] = &update_count_by_sum;
      function_update_map[kTaskSubEventPurchaseGold] = &update_count_by_sum;
      function_update_map[kTaskSubEventPurchaseGem] = &update_count_from_user_data;
      
      function_update_map[kTaskSubEventConsumeGem] = &update_count_by_sum;

      function_update_map[kTaskSubEventEquipEnchant] = &update_count_by_sum;
      function_update_map[kTaskSubEventLevelUpCardSkill] = &update_count_by_sum;
      function_update_map[kTaskSubEventLogin] = &update_count_by_daily_login;
    }

    assert(function_update_map.find(sub_type) != function_update_map.end());

    return function_update_map[sub_type];
  }


  SubTaskCustomFunction GetSubTaskCustomFinishFunction(eTaskType type, eTaskSubType sub_type)
  {
    static std::map<eTaskSubType, SubTaskCustomFunction> function_finish_map;

    if (function_finish_map.empty())
    {
      function_finish_map[kTaskSubDailyCollectRenewalTicketDaily] = &collect_renewal_ticket_daily;
    }

    if (function_finish_map.find(sub_type) != function_finish_map.end())
      return function_finish_map[sub_type];
    else
      return NULL;
  }


  void UpdateQuickTaskDataCount()
  {
    __update_count_user_data();
  }
} // namespace task