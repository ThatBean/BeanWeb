#include "actor_ext_env.h"

#include "actor.h"
#include "actor_ext_user_operation.h"

//#include "game/battle/tiled_map/coordinate_helper.h"

namespace actor {
    ActorExtEnv::ActorExtEnv()
      :actor_next_valid_id_(1)
    {
      actor_map_.clear();
      actor_id_list_.clear();
      actor_ext_user_operation_ = new ActorExtUserOperation(this);
    }

    ActorExtEnv::~ActorExtEnv()
    {
      Clear();
    }

    void ActorExtEnv::Clear()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        
        //delete actor;

        ++iterator;
      }

      actor_map_.clear();
      actor_id_list_.clear();
    }


    void ActorExtEnv::Update(float delta_time)
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        if (actor->GetIsActorActive() == true)
          actor->Update(delta_time);

        ++iterator;
      }
    }

    int ActorExtEnv::AddActor(Actor* actor) //will return actor_id
    {
      int actor_id = actor_next_valid_id_;
      
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      
      AddActor(actor_id, actor);
      return actor_id;
    }

    void ActorExtEnv::AddActor(int actor_id, Actor* actor) //alternative, predefined actor_id
    {
      assert(actor_map_.find(actor_id) == actor_map_.end());

      if (actor->GetActorId() > 0)
      {
        RemoveActor(actor->GetActorId());
      }

      actor->SetActorId(actor_id);
      actor_map_[actor_id] = actor;
      actor_id_list_.push_back(actor_id);
      
      actor_next_valid_id_ = (actor_id > actor_next_valid_id_ ? actor_id : actor_next_valid_id_) + 1;
    }

    Actor* ActorExtEnv::RemoveActor(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        Actor* actor = actor_map_.at(actor_id);
        actor_map_.erase(actor_id);
        std::list<int>::iterator iterator = actor_id_list_.begin();
        while (iterator != actor_id_list_.end())
        {
          if (*iterator == actor_id)
          {
            actor_id_list_.erase(iterator);
            break;
          }
          ++iterator;
        }
        actor->SetActorExtEnv(NULL);
        return actor;
      }
      else
      {
        assert(false);
        return NULL;
      }
    }

    Actor* ActorExtEnv::GetActorById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
        return actor_map_.at(actor_id);
      else
        return NULL;
    }

    int ActorExtEnv::GetActorCount()
    {
      return actor_id_list_.size();
    }

    std::list<Actor*>* ActorExtEnv::GetActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetIsActorActive() == true)
          actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }

    std::list<Actor*>* ActorExtEnv::GetAllActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }






    //should move ? should move
    //position/animation related
    Actor* ActorExtEnv::GetActorByPosition(cocos2d::CCPoint actor_position)
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        if (actor->GetActorData()->GetMotionData()->IsPointInAnimation(actor_position))
          return actor;

        ++iterator;
      }

      return NULL;
    }


    bool ActorExtEnv::IsPositionValid(cocos2d::CCPoint position)
    {
      int_8 target_tile_idx = taomee::battle::GetTileIndexByCurrentPointPosition(position);
      if (target_tile_idx <= taomee::battle::kUnexistTileIndex 
        || target_tile_idx >= taomee::battle::kBorderRightFailedTileIndex)
        target_tile_idx = taomee::battle::kUnexistTileIndex;
      return target_tile_idx != taomee::battle::kUnexistTileIndex;
    }

    cocos2d::CCPoint ActorExtEnv::PositionCorrection(cocos2d::CCPoint position)
    {
      int_8 target_tile_idx = taomee::battle::GetTileIndexByCurrentPointPosition(position);
      assert(target_tile_idx != taomee::battle::kUnexistTileIndex);
      return taomee::battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);
    }


    //position/animation related
    //should move ? should move

} // namespace actor