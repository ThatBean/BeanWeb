#ifndef ACTOR_ACTOR_H
#define ACTOR_ACTOR_H


#include "actor_ext_env.h"

#include "data/actor_data.h"

#include "control/actor_control.h"
#include "trigger/actor_trigger.h"
#include "logic/actor_logic_state_machine.h"
#include "motion/actor_motion_state_machine.h"

namespace actor {

  //class ActorExtEnv;  //ActorExternalEnvironment, the map / battlefield where actors live in (Actor Pool)
  //class ActorData;


  class Actor
  {
  public:
    Actor();
    ~Actor();

    void    Init();
    void    Update(float delta_time);

    ActorControl* GetControl() { return actor_control_; }

    LogicStateMachine*   GetLogicStateMachine() { return logic_state_machine_; }
    MotionStateMachine*  GetMotionStateMachine() { return motion_state_machine_; }

  public:
    //The link upwards to actor pool
    void             SetActorExtEnv(ActorExtEnv* actor_ext_env) { actor_ext_env_ = actor_ext_env; }
    ActorExtEnv*     GetActorExtEnv() { return actor_ext_env_; }
    
    void             SetActorId(int actor_id) { actor_id_ = actor_id; }
    int              GetActorId() { return actor_id_; }

    void             SetIsActorActive(bool is_actor_active) { is_actor_active_ = is_actor_active; }
    bool             GetIsActorActive() { return is_actor_active_; }

    ActorData*       GetActorData() { return actor_data_; }


  private:
    int                   actor_id_;  //where this actor is stored in ExtEnv
    bool                  is_actor_active_;
    ActorExtEnv*          actor_ext_env_;
    
    ActorData*            actor_data_;  //collection of all actor-data-class, provide both data&functions

    //Notice:
    // below class will be & should be updated in Actor Update() by order
    ActorControl*         actor_control_; //Manual or Auto, may change Logic State
    //ActorBuff*            actor_buff_; //Manage actor-side buff data&logic
    //ActorSkill*           actor_skill_; //Manage actor-side skill data&logic
    LogicStateMachine*    logic_state_machine_; //Manage Both Logic-State&Motion-State 
    MotionStateMachine*   motion_state_machine_;  //Manage Position and Animation

  };



} // namespace actor


#endif // actor/actor.h
