#include "actor_trigger_module.h"

// kActorTriggerModuleFaction,
// kActorTriggerModuleGeometry,
// kActorTriggerModuleStatus,
// kActorTriggerModuleScript,  //lua
// kActorTriggerModuleActive,  //will cause target status change, maybe a bad idea
// kActorTriggerModuleSort,  //


#include "trigger_module/actor_trigger_module_faction.h"
#include "trigger_module/actor_trigger_module_geometry.h"
//#include "trigger_module/actor_trigger_module_status.h"
//#include "trigger_module/actor_trigger_module_script.h"
//#include "trigger_module/actor_trigger_module_active.h"
#include "trigger_module/actor_trigger_module_sort.h"


namespace actor 
{

  ActorTriggerModule* GetActorTriggerModule(eActorTriggerModule module_type)
  {
    switch(module_type)
    {
    case kActorTriggerModuleFaction:
      return ActorTriggerModuleFaction::Instance();
      break;
    case kActorTriggerModuleGeometry:
      return ActorTriggerModuleGeometry::Instance();
      break;
      //     case kActorTriggerModuleStatus:
      //       return ActorTriggerModuleStatus::Instance();
      //       break;
      //     case kActorTriggerModuleScript:
      //       return ActorTriggerModuleScript::Instance();
      //       break;
    case kActorTriggerModuleSort:
      return ActorTriggerModuleSort::Instance();
      break;
    default:
      return 0;
      break;
    }
  }

  ActorTriggerModuleData* GetActorTriggerModuleData(eActorTriggerModule module_type, uint_32 trigger_flag/* = 0*/)
  {
    ActorTriggerModuleData* module_data = NULL;
    
    switch(module_type)
    {
    case kActorTriggerModuleFaction:
      module_data = new ActorTriggerModuleDataFaction;
      break;
    case kActorTriggerModuleGeometry:
      module_data = new ActorTriggerModuleDataGeometry;
      break;
      //     case kActorTriggerModuleStatus:
      //       module_data = new ActorTriggerModuleDataStatus;
      //       break;
      //     case kActorTriggerModuleScript:
      //       module_data = new ActorTriggerModuleDataScript;
      //       break;
    case kActorTriggerModuleSort:
      module_data = new ActorTriggerModuleDataSort;
      break;
    default:
      module_data = NULL;
      break;
    }

    if (module_data)
      module_data->SetTriggerFlag(trigger_flag);
    else
      assert(false);

    return module_data;
  }

}  // namespace actor