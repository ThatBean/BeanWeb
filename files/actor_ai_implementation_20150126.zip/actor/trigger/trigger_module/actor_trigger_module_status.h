#ifndef ACTOR_TRIGGER_MODULE_STATUS_H
#define ACTOR_TRIGGER_MODULE_STATUS_H


#include "game/actor/trigger/actor_trigger_module.h"


namespace actor 
{
  enum eActorTriggerStatusFlag
  {
    kActorTriggerStatusFlagWeak  = 1 << 0,
    kActorTriggerStatusFlagDead  = 1 << 1,
    kActorTriggerStatusFlagIdle  = 1 << 2,
    kActorTriggerStatusFlag = 0
  };


  class ActorTriggerModuleDataStatus: public ActorTriggerModuleData
  {
  public:
    static const uint_32 TARGET_MODULE_TYPE;
//     void  SetDistanceMin(float distance_min) { distance_min_ = distance_min; }
//     float   GetDistanceMin() { return distance_min_; }
// 
//     void  SetDistanceMax(float distance_max) { distance_max_ = distance_max; }
//     float   GetDistanceMax() { return distance_max_; }

  private:
//     float   distance_min_;
//     float   distance_max_;
//     bool   is_direction_relative_;
//     //cocos2d::CCPoint location_;
  };

  class ActorTriggerModuleStatus: public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleStatus() {}

  public:
    static ActorTriggerModuleStatus* Instance();
    ~ActorTriggerModuleStatus() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

//     void     UpdateDistance(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list);
//     void     UpdateDirection(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list);
//     void     UpdateLocation(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list);

  private:
    static const eActorTriggerModule trigger_module_type_;

  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_STATUS_H