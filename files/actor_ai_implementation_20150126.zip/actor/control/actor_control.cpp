#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"


namespace actor {

  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor),
    actor_control_type_(kActorControl)
  {

  }

  ActorControl::~ActorControl()
  {

  }

  void ActorControl::Update()
  {
    if (!actor_control_type_)
    {
      assert(false);
      return;
    }

    if (actor_control_type_ & kActorControlManual) UpdateManual();
    if (actor_control_type_ & kActorControlAuto) UpdateAuto();
    
    result_logic_state_type_ = DecideLogicState();
    if (ControlLogicStateChange(result_logic_state_type_))
      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type_));
  }

  void ActorControl::UpdateManual()
  {
    ActorControlDataBase* user_control_data = actor_->GetActorData()->GetUserControlData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    if (user_control_data->IsSet())
    {
      if (user_control_data->IsSetPosition())
      {
        cocos2d::CCPoint set_position = user_control_data->GetPosition();

        if (actor_->GetActorExtEnv()->IsPositionValid(set_position)) //check position
          control_data->SetPosition(actor_->GetActorExtEnv()->PositionCorrection(set_position), kActorControlPriorityMoveManual);
      }

      if (user_control_data->IsSetTarget())
      {
        int set_target = user_control_data->GetTarget();

        //check target
        control_data->SetTarget(set_target, kActorControlPriorityMoveManual);
      }

      if (user_control_data->IsSetSkill())
      {
        int set_skill = user_control_data->GetSkill();

        //check skill
        control_data->SetSkill(set_skill, kActorControlPriorityAttackNormalManual);
      }

      if (user_control_data->IsSetIncontrollable())
      {
        eActorControlIncontrollableType set_incontrollable = user_control_data->GetIncontrollable();

        //check incontrollable
        control_data->SetIncontrollable(set_incontrollable, kActorControlPriorityIncontrollable);
      }
      
      user_control_data->Reset(); //clear user data
    }
  }

  void ActorControl::UpdateAuto()
  {
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() != kActorLogicStateIdle)
      return;

    //TODO
  }

  eActorLogicState ActorControl::DecideLogicState()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    switch (control_data->GetMaximumControlPriority())
    {
    case kActorControlPriorityMoveAuto:
    case kActorControlPriorityMoveManual:
      if (control_data->IsSetTarget()) control_data->ResetPosition();
      if (control_data->IsSetPosition()) control_data->ResetTarget(); //no use
      return kActorLogicStateMove;
      break;
    case kActorControlPriorityAttackNormalAuto:
    case kActorControlPriorityAttackNormalManual:
      control_data->ResetPosition();
      control_data->ResetTarget();
      return kActorLogicStateAttack;
      break;
    case kActorControlPriorityIncontrollable:
      control_data->ResetPosition();
      control_data->ResetTarget();
      control_data->ResetSkill();
      return kActorLogicStateIncontrollable;
      break;
    case kActorControlPriorityMin:
      return kActorLogicState;  //nothing set
      break;
    case kActorControlPriorityMax:
    default:
      assert(false);  //error priority
      break;
    }

    return kActorLogicState;
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState new_logic_state)
  {
    if (new_logic_state == kActorLogicState)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == kActorLogicStateDead)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == new_logic_state)
      return false;

    ActorLogicData* logic_data = actor_->GetActorData()->GetLogicData();

    switch(new_logic_state)
    {
    case kActorLogicStateMove:
      if (logic_data->GetIsMuteMove())
        return false;
      break;
    case kActorLogicStateAttack:
      if (logic_data->GetIsMuteAttack())
        return false;
      break;
    case kActorLogicStateIncontrollable:
      //if (logic_data->GetIsMuteAttack())
        //return false;
      break;
    default:
      break;
    }

    return true;
  }
} // namespace actor