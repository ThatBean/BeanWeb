#include "actor_motion_state_idle.h"

#include "game/actor/actor.h"

#include "game/actor/motion/actor_motion_animation_operation.h"

namespace actor {

  const int MotionStateIdle::STATE_TYPE = kActorMotionStateIdle;

  MotionStateIdle* MotionStateIdle::Instance()
  {
    static MotionStateIdle instance;
    return &instance;
  }


  void MotionStateIdle::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(false);
    CheckWeakStatus(actor);
    ChangeAnimation(actor, taomee::army::kUnitAnimationIdle);
    ResetAnimationDirection(actor);
  }

  void MotionStateIdle::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);

  }

  void MotionStateIdle::Update(Actor* actor, float delta_time)
  {
    CheckWeakStatus(actor);
  }

  void MotionStateIdle::CheckWeakStatus(Actor* actor)
  {
    if (actor->GetActorData()->GetBasicData()->GetIsWeakStatus() != actor->GetActorData()->GetMotionData()->GetIsWeakStatusAnimation())
    {
      if (actor->GetActorData()->GetBasicData()->GetIsWeakStatus())
      {
        ChangeAnimation(actor, taomee::army::kUnitAnimationWeak);
        actor->GetActorData()->GetMotionData()->SetIsWeakStatusAnimation(true);
      }
      else
      {
        ChangeAnimation(actor, taomee::army::kUnitAnimationIdle);
        actor->GetActorData()->GetMotionData()->SetIsWeakStatusAnimation(false);
      }
    }
  }

} // namespace actor