#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {
  ActorSkillData::ActorSkillData()
    : actor_skill_id_melee_(ACTOR_SKILL_ID_INVALID),
      actor_skill_id_ranged_(ACTOR_SKILL_ID_INVALID),
      actor_skill_id_heal_(ACTOR_SKILL_ID_INVALID),
      actor_skill_id_power_(ACTOR_SKILL_ID_INVALID),
      actor_skill_id_special_(ACTOR_SKILL_ID_INVALID),
      guard_type_(kActorGuard),
      guard_trigger_(NULL),
      attack_trigger_melee_(NULL),
      attack_trigger_heal_(NULL),
      attack_trigger_ranged_(NULL),
      attack_trigger_power_(NULL),
      attack_trigger_special_(NULL)
  {

  }

  ActorSkillData::~ActorSkillData()
  {
    if (guard_trigger_) delete guard_trigger_;

    if (attack_trigger_melee_) delete attack_trigger_melee_;
    if (attack_trigger_heal_) delete attack_trigger_heal_;
    if (attack_trigger_ranged_) delete attack_trigger_ranged_;

    if (attack_trigger_power_) delete attack_trigger_power_;
    if (attack_trigger_special_) delete attack_trigger_special_;
  }


  void ActorSkillData::SetSkillIdByType(eActorAttackType attack_type, int skill_id)
  {
    switch (attack_type)
    {
    case kActorAttackMelee:
      actor_skill_id_melee_ = skill_id;
      break;
    case kActorAttackRanged:
      actor_skill_id_ranged_ = skill_id;
      break;
    case kActorAttackHeal:
      actor_skill_id_heal_ = skill_id;
      break;
    case kActorAttackPower:
      actor_skill_id_power_ = skill_id;
      break;
    case kActorAttackSpecial:
      actor_skill_id_special_ = skill_id;
      break;
    case kActorAttack:
    default:
      assert(false);
      break;
    }
  }


  int ActorSkillData::GetSkillIdByType(eActorAttackType attack_type)
  {
    switch (attack_type)
    {
    case kActorAttackMelee:
      return actor_skill_id_melee_;
      break;
    case kActorAttackRanged:
      return actor_skill_id_ranged_;
      break;
    case kActorAttackHeal:
      return actor_skill_id_heal_;
      break;
    case kActorAttackPower:
      return actor_skill_id_power_;
      break;
    case kActorAttackSpecial:
      return actor_skill_id_special_;
      break;
    case kActorAttack:
    default:
      return ACTOR_SKILL_ID_INVALID;
      break;
    }
  }

  eActorAttackType ActorSkillData::GetSkillTypeById(int skill_id)
  {
    if (skill_id == ACTOR_SKILL_ID_INVALID) return kActorAttack;

    if (skill_id == actor_skill_id_melee_) return kActorAttackMelee;
    if (skill_id == actor_skill_id_ranged_) return kActorAttackRanged;
    if (skill_id == actor_skill_id_heal_) return kActorAttackHeal;

    if (skill_id == actor_skill_id_power_) return kActorAttackPower;
    if (skill_id == actor_skill_id_special_) return kActorAttackSpecial;

    return kActorAttack;
  }


  void ActorSkillData::UpdateNormalAttackTrigger()
  {
    if (attack_trigger_melee_) attack_trigger_melee_->Update();
    if (attack_trigger_ranged_) attack_trigger_ranged_->Update();
    if (attack_trigger_heal_) attack_trigger_heal_->Update();
  }

  bool ActorSkillData::GetNormalAttackIsTriggered()
  {
    bool is_triggered = false;
    if(attack_trigger_melee_) is_triggered |= attack_trigger_melee_->GetIsTriggered();
    if(attack_trigger_ranged_) is_triggered |= attack_trigger_ranged_->GetIsTriggered();
    if(attack_trigger_heal_) is_triggered |= attack_trigger_heal_->GetIsTriggered();
    return is_triggered;
  }

  eActorAttackType ActorSkillData::GetNormalAttackTriggeredType()
  {
    if (attack_trigger_melee_)
    {
      if (attack_trigger_melee_->GetIsTriggered())
        return kActorAttackMelee;
    }

    if (attack_trigger_ranged_)
    {
      if (attack_trigger_ranged_->GetIsTriggered())
        return kActorAttackRanged;
    }

    if (attack_trigger_heal_)
    {
      if (attack_trigger_heal_->GetIsTriggered())
        return kActorAttackHeal;
    }

    return kActorAttack;
  }

   ActorTrigger* ActorSkillData::GetTriggeredAttackTrigger()
   {
     if (attack_trigger_special_)
     {
       if (attack_trigger_special_->GetIsTriggered())
         return attack_trigger_special_;
     }

     if (attack_trigger_power_)
     {
       if (attack_trigger_power_->GetIsTriggered())
         return attack_trigger_power_;
     }

     if (attack_trigger_melee_)
     {
       if (attack_trigger_melee_->GetIsTriggered())
         return attack_trigger_melee_;
     }

     if (attack_trigger_ranged_)
     {
       if (attack_trigger_ranged_->GetIsTriggered())
         return attack_trigger_ranged_;
     }

     if (attack_trigger_heal_)
     {
       if (attack_trigger_heal_->GetIsTriggered())
         return attack_trigger_heal_;
     }

     return NULL;
   }



   void ActorSkillData::CommitSkill(int skill_id)
   {
     actor_adapter_->getSkillControl()->playSkillByID(skill_id, kSkillSkill);
   }

   bool ActorSkillData::GetIsSkillFinished() 
   { 
     is_skill_finished_ = (actor_adapter_->getSkillControl()->getSkillMotionState() == taomee::ai::kMotionResultCompelted)
       || (actor_adapter_->getSkillControl()->getSkillMotionState() == taomee::ai::kMotionResultInvalid);
     return is_skill_finished_; 
   }

  //ActorSkillData

} // namespace actor