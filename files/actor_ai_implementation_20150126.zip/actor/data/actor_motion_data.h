#ifndef ACTOR_MOTION_DATA_H
#define ACTOR_MOTION_DATA_H

#include "game/actor/actor_adapter.h"

#include "cocos2d.h"

namespace actor {

  class Actor;

  enum eActorAnimationDirection
  {
    kActorAnimationDirectionLeft,
    kActorAnimationDirectionRight,
    kActorAnimationDirection
  };

  class ActorMotionData
  {
  public:
    ActorMotionData();
    ~ActorMotionData();

    void        SetIsMotionAnimationEnded(bool is_motion_animation_finished) { is_motion_animation_finished_ = is_motion_animation_finished; }
    bool        GetIsMotionAnimationEnded() { return is_motion_animation_finished_; }

    void        SetIsWeakStatusAnimation(bool is_weak_status_animation) { is_weak_status_animation_ = is_weak_status_animation; }
    bool        GetIsWeakStatusAnimation() { return is_weak_status_animation_; }

    void        ResetIsCachedPosition() { is_cached_position_ = false; }
    bool        GetIsCachedPosition() { return is_cached_position_; }

    void              SetCachedTargetPosition(cocos2d::CCPoint target_position) { cached_target_position_ = target_position; } //no need to delete last target position, it's stored in control data
    cocos2d::CCPoint  GetCachedTargetPosition() { return cached_target_position_; }

    void              SetCachedMoveSpeedVector(cocos2d::CCPoint move_speed_vector) { cached_move_speed_vector_ = move_speed_vector; }
    cocos2d::CCPoint  GetCachedMoveSpeedVector() { return cached_move_speed_vector_; }

    //currently in adapter
    void                 SetPosition(cocos2d::CCPoint position);
    cocos2d::CCPoint     GetPosition();

    bool        IsPointInAnimation(cocos2d::CCPoint position);

    void        SetMoveSpeedBase(float move_speed_base);
    float       GetMoveSpeedBase();

    taomee::SkeletonAnimation* GetAnimationNode();
    taomee::effect::SkeletonAnimationManager* GetAnimationManager();

    void        ResetAnimationDirection();  //set to default direction
    void        SetAnimationDirection(eActorAnimationDirection direction);
    eActorAnimationDirection GetAnimationDirection() { return animation_direction_; }
    void        SetDefaultAnimationDirection(eActorAnimationDirection direction) { animation_direction_default_ = direction; }
    eActorAnimationDirection GetDefaultAnimationDirection() { return animation_direction_default_; }

    void        DeadAnimation();  //play dead animaiton, hard to reset

    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }

  private:
    bool    is_motion_animation_finished_;
    
    bool    is_weak_status_animation_;

    //float                move_speed_base_;

    bool  is_cached_position_;
    cocos2d::CCPoint     cached_target_position_;  //current 
    cocos2d::CCPoint     cached_move_speed_vector_;  //current 

    eActorAnimationDirection  animation_direction_; //only used privately
    eActorAnimationDirection  animation_direction_default_; // can be set

    //below data is used to customize certain motion
    //Will auto apply to animation, in certain motion state

    bool is_set_animation_;
    bool is_set_move_;

    bool is_animation_overload_;  //playing another animation
    bool is_animation_lock_;  //animation stopped
    bool is_direction_lock_;  //no direction change
    bool is_move_lock_; //no position change


    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*        actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_MOTION_DATA_H