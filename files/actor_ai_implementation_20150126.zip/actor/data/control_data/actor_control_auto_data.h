#ifndef ACTOR_CONTROL_AUTO_DATA_H
#define ACTOR_CONTROL_AUTO_DATA_H

#include "game/actor/actor_adapter.h"
#include "game/actor/logic/actor_logic_state.h"

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;


  //-- near attacker ai stay time
  const int TIME_ENEMY_STAY_MELEE = 5;

  //-- range attacker ai stay time
  const int TIME_ENEMY_STAY_RANGED = 15;

  //-- assassin attacker ai search row time
  const int TIME_ENEMY_SEARCH_TARGET = 3;




  /*
    About Actor Control Auto:
  
    Auto control of an actor will be achieved by a system in Lua "routine"

    During Actor Exist Time:
    --  Routine Part: Package of routines
    --  --  Routine: Sets of checks and operations for actor logic data & state
  */


  class ActorControlAutoData  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorControlAutoData();
    ~ActorControlAutoData();

    void Clear();
    void Init(Actor* actor, std::string& routine_name);
    eActorLogicState Update(float delta_time);

  private:
    int lua_auto_data_id_;
    
    int current_routine_part_id_;
    int current_routine_id_;

    //state data, may be used in current state
    uint_32          routine_part_start_timestamp_;
    uint_32          routine_start_timestamp_;
  };

} // namespace actor


#endif // ACTOR_CONTROL_AUTO_DATA_H