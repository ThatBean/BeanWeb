#include "actor_control_auto_data.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  ActorControlAutoData::ActorControlAutoData()
    :lua_auto_data_id_(0)
  {

  }
  ActorControlAutoData::~ActorControlAutoData()
  {
    Clear();
  }

  void ActorControlAutoData::Clear()
  {
    if (lua_auto_data_id_ > 0)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(
        "script/actor/lua_actor_routine.lua", 
        "ClearRoutine",
        lua_auto_data_id_);
      lua_auto_data_id_ = 0;
    }
  }

  void ActorControlAutoData::Init(Actor* actor, std::string& routine_name)
  {
    Clear();

    lua_auto_data_id_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "InitRoutine",
      actor->GetActorId(),
      routine_name.c_str());
  }

  eActorLogicState ActorControlAutoData::Update(float delta_time)
  {
     int result_state = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "UpdateRoutine",
      lua_auto_data_id_,
      delta_time);
    return eActorLogicState(result_state);
  }

} // namespace actor