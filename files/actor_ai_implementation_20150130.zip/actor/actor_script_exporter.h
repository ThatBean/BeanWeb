#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorControlDataBase;


  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

    //export to lua for data
    float GetActorHealthPercent();
    cocos2d::CCPoint GetActorPosition();
    cocos2d::CCPoint GridToPosition(int grid_x, int grid_y);
    void ActorAutoGuard();
    ActorControlDataBase* GetActorRoutineControlData();
    //export to lua for data

  private:
    Actor* actor_;  //keep actor pointer
  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H