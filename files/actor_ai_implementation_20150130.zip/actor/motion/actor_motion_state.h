#ifndef ACTOR_MOTION_STATE_H
#define ACTOR_MOTION_STATE_H

#include "game/actor/template_class/state.h"

namespace actor {

  class Actor;

  enum eActorMotionState
  {
    kActorMotionStateIdle,
    kActorMotionStateMove,
    kActorMotionStateAttack,
    kActorMotionStateIncontrollable,
    kActorMotionStateBorn,
    kActorMotionStateDead,
    kActorMotionState
  };


  class MotionState : public State<Actor>
  {
  public:
    virtual ~MotionState() {}

    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }
  };

  MotionState* GetActorMotionState(eActorMotionState state_type);
} // namespace actor


#endif // ACTOR_MOTION_STATE_H
