#ifndef ACTOR_MOTION_STATE_MOVE_H
#define ACTOR_MOTION_STATE_MOVE_H

#include "game/actor/motion/actor_motion_state.h"
#include "cocos2d.h"

namespace actor {

  class MotionStateMove : public MotionState
  {
  public:
    virtual ~MotionStateMove() {}
    static MotionStateMove* Instance();
    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);

    void UpdateMoveToPosition(Actor* actor, float delta_time, cocos2d::CCPoint target_position); //both Target&Position will use this

    void CheckWeakStatus(Actor* actor);

  private:
    MotionStateMove() {}
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_MOVE_H
