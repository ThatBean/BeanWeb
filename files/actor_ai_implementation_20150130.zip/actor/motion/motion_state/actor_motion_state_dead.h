#ifndef ACTOR_MOTION_STATE_DEAD_H
#define ACTOR_MOTION_STATE_DEAD_H

#include "game/actor/motion/actor_motion_state.h"


namespace actor {

  class MotionStateDead : public MotionState
  {
  public:
    virtual ~MotionStateDead() {}
    static MotionStateDead* Instance();
    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);
    
    void CheckWeakStatus(Actor* actor);
  private:
    MotionStateDead() {}
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_DEAD_H
