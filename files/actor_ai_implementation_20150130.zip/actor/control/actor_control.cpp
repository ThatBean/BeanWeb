#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

namespace actor {


  //#####################################################################


  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor),
    actor_control_type_(kActorControl),
    actor_control_routine_(NULL)
  {

  }

  ActorControl::~ActorControl()
  {
    if (actor_control_routine_)
    {
      actor_control_routine_->Clear();
      delete actor_control_routine_;
    }
  }

  void ActorControl::Update(float delta_time)
  {
    if (!actor_control_type_)
    {
      assert(false);
      return;
    }

    if (actor_control_routine_)
      actor_control_routine_->Update(delta_time);

    if (actor_control_type_ & kActorControlManual) UpdateManual();
    if (actor_control_type_ & kActorControlAuto) UpdateAuto();
    
    result_logic_state_type_ = DecideLogicState();
    if (ControlLogicStateChange(result_logic_state_type_))
      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type_));
  }

  void ActorControl::UpdateManual()
  {
    ActorControlDataBase* user_control_data = actor_->GetActorData()->GetUserControlData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
    
    ApplyControlData(user_control_data, control_data);
  }

  void ActorControl::UpdateAuto()
  {
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() != kActorLogicStateIdle)
      return;

    //check and apply routine control
    if (actor_control_routine_)
    {
      ActorControlDataBase* routine_control_data = actor_control_routine_->GetRoutineControlData();
      ActorControlData* control_data = actor_->GetActorData()->GetControlData();

      ApplyControlData(routine_control_data, control_data);
    }
  }


  void ActorControl::ApplyControlData(ActorControlDataBase* from_control_data, ActorControlDataBase* to_control_data)
  {
    if (!from_control_data || !to_control_data)
    {
      assert(false);
      return;
    }

    if (from_control_data->IsSet())
    {
      if (from_control_data->IsSetPosition())
      {
        cocos2d::CCPoint set_position = from_control_data->GetPosition();
        eActorControlPriority control_priority = from_control_data->GetPositionPriority();

        //check position
        to_control_data->SetPosition(set_position, control_priority);
        //check position
      }

      if (from_control_data->IsSetTarget())
      {
        int set_target = from_control_data->GetTarget();
        eActorControlPriority control_priority = from_control_data->GetTargetPriority();

        //check target
        to_control_data->SetTarget(set_target, control_priority);
        //check target
      }

      if (from_control_data->IsSetSkill())
      {
        int set_skill = from_control_data->GetSkill();
        eActorControlPriority control_priority = from_control_data->GetSkillPriority();

        //check skill
        to_control_data->SetSkill(set_skill, control_priority);

        if (control_priority == kActorControlPriorityAttackSpecialManual)
        {
          //flush actor logic state, re-enter to overload current skill
          actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
        }
        //check skill
      }

      if (from_control_data->IsSetIncontrollable())
      {
        eActorControlIncontrollableType set_incontrollable = from_control_data->GetIncontrollable();
        eActorControlPriority control_priority = from_control_data->GetIncontrollablePriority();

        //check incontrollable
        to_control_data->SetIncontrollable(set_incontrollable, control_priority);
        //check incontrollable
      }

      from_control_data->Reset(); //clear user data
    }
  }




  eActorLogicState ActorControl::DecideLogicState()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    switch (control_data->GetMaximumControlPriority())
    {
    case kActorControlPriorityMoveAuto:
    case kActorControlPriorityMoveManual:
      if (control_data->IsSetTarget()) control_data->ResetPosition();
      if (control_data->IsSetPosition()) control_data->ResetTarget(); //no use
      return kActorLogicStateMove;
      break;
    case kActorControlPriorityAttackNormalAuto:
    case kActorControlPriorityAttackNormalManual:
    case kActorControlPriorityAttackSpecialManual:
      control_data->ResetPosition();
      control_data->ResetTarget();
      return kActorLogicStateAttack;
      break;
    case kActorControlPriorityIncontrollable:
      control_data->ResetPosition();
      control_data->ResetTarget();
      control_data->ResetSkill();
      return kActorLogicStateIncontrollable;
      break;
    case kActorControlPriorityMin:
      return kActorLogicState;  //nothing set
      break;
    case kActorControlPriorityMax:
    default:
      assert(false);  //error priority
      break;
    }

    return kActorLogicState;
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState new_logic_state)
  {
    if (new_logic_state == kActorLogicState)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == kActorLogicStateDead)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == new_logic_state)
      return false;

    ActorLogicData* logic_data = actor_->GetActorData()->GetLogicData();

    switch(new_logic_state)
    {
    case kActorLogicStateMove:
      if (logic_data->GetIsMuteMove())
        return false;
      break;
    case kActorLogicStateAttack:
      if (logic_data->GetIsMuteAttack())
        return false;
      break;
    case kActorLogicStateIncontrollable:
      //if (logic_data->GetIsMuteAttack())
        //return false;
      break;
    default:
      break;
    }

    return true;
  }


  void ActorControl::SetActorControlRoutine(ActorControlRoutine* actor_control_routine)
  {
    if (actor_control_routine_) 
    {
      actor_control_routine_->Clear();
      delete actor_control_routine_;
    }
    actor_control_routine_ = actor_control_routine;
  }
  ActorControlRoutine* ActorControl::GetActorControlRoutine()
  {
    return actor_control_routine_;
  }
} // namespace actor