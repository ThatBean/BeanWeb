#include "actor_control_routine.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  ActorControlRoutine::ActorControlRoutine(Actor* actor)
    :lua_auto_data_id_(0),
    actor_(NULL),
    routine_control_data_(NULL)
  {
    routine_control_data_ = new ActorControlDataBase;
    Init(actor);
  }

  ActorControlRoutine::~ActorControlRoutine()
  {
    Clear();

    if (routine_control_data_)
    {
      delete routine_control_data_;
      routine_control_data_ = NULL;
    }
  }

  void ActorControlRoutine::Init(Actor* actor)
  {
    //printf("[ActorControlAutoData][Init] name %s", routine_name.c_str());

    Clear();

    lua_auto_data_id_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "InitRoutine", actor->GetActorScriptExporter());

    assert(lua_auto_data_id_ > 0);
    
    actor_ = actor;
  }

  void ActorControlRoutine::Clear()
  {
    //printf("[ActorControlAutoData][Clear] id %d", lua_auto_data_id_);

    if (lua_auto_data_id_ > 0)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(
        "script/actor/lua_actor_routine.lua", 
        "ClearRoutine",
        lua_auto_data_id_);
      lua_auto_data_id_ = 0;
    }
    actor_ = NULL;
    if (routine_control_data_)
      routine_control_data_->Reset();
  }

  void ActorControlRoutine::AddRoutineData(std::string& key_string, int value_int)
  {
    if (lua_auto_data_id_ <= 0) return;
    //to lua logic
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "AddRoutineData", lua_auto_data_id_, key_string.c_str(), value_int);
  }
  void ActorControlRoutine::AddRoutineData(std::string& key_string, float value_float)
  {
    if (lua_auto_data_id_ <= 0) return;
    //to lua logic
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "AddRoutineData", lua_auto_data_id_, key_string.c_str(), value_float);
  }
  void ActorControlRoutine::AddRoutineData(std::string& key_string, std::string& value_string)
  {
    if (lua_auto_data_id_ <= 0) return;
    //to lua logic
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "AddRoutineData", lua_auto_data_id_, key_string.c_str(), value_string.c_str());
  }

  void ActorControlRoutine::LoadRoutine()
  {
    //printf("[ActorControlAutoData][LoadRoutine] id %d", lua_auto_data_id_);

    if (lua_auto_data_id_ <= 0) return;

    //to lua logic
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "LoadRoutine", lua_auto_data_id_);
  }

  void ActorControlRoutine::Update(float delta_time)
  {
    //printf("[ActorControlAutoData][Update] id %d", lua_auto_data_id_);

    if (actor_->GetIsActorActive() == false || actor_->GetActorData()->GetBasicData()->GetIsDeadStatus())
      return;

    if (lua_auto_data_id_ <= 0) return;

    //to lua logic
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(
      "script/actor/lua_actor_routine.lua", 
      "UpdateRoutine", lua_auto_data_id_, delta_time);
  }

} // namespace actor