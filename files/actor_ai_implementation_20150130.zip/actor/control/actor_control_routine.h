#ifndef ACTOR_CONTROL_ROUTINE_H
#define ACTOR_CONTROL_ROUTINE_H

#include "game/actor/actor_adapter.h"
#include "game/actor/logic/actor_logic_state.h"

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorControlDataBase;

  /*
    About Actor Control Routine:
  
    Auto control of an actor will be achieved by a system in Lua "routine"

    During Actor Alive Time:
    --  Routine Part: Package of routines
    --  --  Routine: Sets of checks and operations for actor logic data & state
  */


  class ActorControlRoutine  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorControlRoutine(Actor* actor);
    ~ActorControlRoutine();

    void Init(Actor* actor);
    void Clear();

    void AddRoutineData(std::string& key_string, int value_int);
    void AddRoutineData(std::string& key_string, float value_float);
    void AddRoutineData(std::string& key_string, std::string& value_string);

    void LoadRoutine();
    void Update(float delta_time);  //update will run routine logic in lua, result in a "eActorLogicState", and the change in auto data

    //for lua to set, control to read
    ActorControlDataBase* GetRoutineControlData() { return routine_control_data_; }
    
  private:
    int lua_auto_data_id_;  //keep lua data id
    Actor* actor_;  //keep actor pointer

    ActorControlDataBase* routine_control_data_;
  };

} // namespace actor


#endif // ACTOR_CONTROL_ROUTINE_H