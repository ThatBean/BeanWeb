#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H


#include "game/army/unit/move_object.h"
// 
// namespace taomee {
//   namespace army {
//     class MoveObject;
//   }
// }

namespace actor {
  typedef taomee::army::MoveObject ActorAdapter;

  //deprecated
  bool IsPositionValid(cocos2d::CCPoint position);
  cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position);
  //deprecated
  
  cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
  cocos2d::CCPoint GetPositionFromGrid(cocos2d::CCPoint grid_position);

  bool IsPositionInGrid(cocos2d::CCPoint position);
  cocos2d::CCPoint SnapToGrid(cocos2d::CCPoint position);


  void ResetSkillAdapter(ActorAdapter* actor_adapter);
  void AddSkillTargetAdapter(ActorAdapter* actor_adapter, int target_id);
  void CommitSkillAdapter(ActorAdapter* actor_adapter, int skill_id, int attack_type);
  
  bool GetIsSkillFinishedAdapter(ActorAdapter* actor_adapter);

  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter);

  void NastyActorInitAdapter(ActorAdapter* actor_adapter, Actor* actor);
  void NastyActorInitRoutineDataAdapter(ActorAdapter* actor_adapter, Actor* actor);

} // namespace actor


#endif // ACTOR_ADAPTER_H
