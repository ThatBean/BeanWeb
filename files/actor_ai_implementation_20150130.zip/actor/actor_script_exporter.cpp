#include "actor_script_exporter.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  ActorScriptExporter::ActorScriptExporter(Actor* actor)
    :actor_(actor)
  {

  }

  ActorScriptExporter::~ActorScriptExporter()
  {

  }

  //export to lua

  float ActorScriptExporter::GetActorHealthPercent()
  {
    assert(actor_);
    return actor_->GetActorData()->GetBasicData()->GetCurrentHealth() * 1.0f / actor_->GetActorData()->GetBasicData()->GetTotalHealth();
  }

  cocos2d::CCPoint ActorScriptExporter::GetActorPosition()
  {
    assert(actor_);
    return actor_->GetActorData()->GetMotionData()->GetPosition();
  }


  cocos2d::CCPoint ActorScriptExporter::GridToPosition(int grid_x, int grid_y)
  {
    assert(actor_);
    return GetPositionFromGrid(grid_x, grid_y);
  }

  void ActorScriptExporter::ActorAutoGuard()
  {
    ///////////////TODO
  }


  ActorControlDataBase* ActorScriptExporter::GetActorRoutineControlData()
  {
    assert(actor_);
    return actor_->GetControl()->GetActorControlRoutine()->GetRoutineControlData();
  }
} // namespace actor