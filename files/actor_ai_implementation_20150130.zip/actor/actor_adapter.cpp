#include "actor_adapter.h"

#include "actor.h"
#include "game/actor/trigger/actor_trigger_predefined.h"

#include "game/army/unit/monster.h"
#include "game/army/unit/character.h"

#include "game/battle/battle_controller.h"
#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/ago_skill/control/ASkillControl.h"

namespace actor
{

  //     <The Battle field>		  // grid_x  1   2   3      4   5   6   | grid_y
  //         ---------------------------|
  //         0   1   2      3   4   5   |      1
  //         6   7   8      9   10  11  |      2
  //         12  13  14     15  16  17  |      3
  //         tile index                 |
  const int grid_to_tile_index_list[18] = {
    0,  1,  2,      3,  4,  5,
    6,  7,  8,      9,  10, 11,
    12, 13, 14,     15, 16, 17
  };



  bool IsPositionValid(cocos2d::CCPoint position)
  {
    int_8 target_tile_idx = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    if (target_tile_idx <= taomee::battle::kUnexistTileIndex 
      || target_tile_idx >= taomee::battle::kBorderRightFailedTileIndex)
      target_tile_idx = taomee::battle::kUnexistTileIndex;
    return target_tile_idx != taomee::battle::kUnexistTileIndex;
  }

  cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position)
  {
    int_8 target_tile_idx = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    assert(target_tile_idx != taomee::battle::kUnexistTileIndex);
    return taomee::battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);
  }

  cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y)
  {
    int index = (grid_x - 1) + (grid_y - 1) * 6;
    assert(0 <= index && 17 >= index);
    int_8 target_tile_idx = grid_to_tile_index_list[index];
    assert(target_tile_idx != taomee::battle::kUnexistTileIndex);
    return taomee::battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);
  }

  cocos2d::CCPoint GetPositionFromGrid(cocos2d::CCPoint grid_position)
  {
    return GetPositionFromGrid(grid_position.x, grid_position.y);
  }

  bool IsPositionInGrid(cocos2d::CCPoint position)
  {
    int_8 target_tile_idx = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    if (target_tile_idx <= taomee::battle::kUnexistTileIndex 
      || target_tile_idx >= taomee::battle::kBorderRightFailedTileIndex)
      target_tile_idx = taomee::battle::kUnexistTileIndex;
    return target_tile_idx != taomee::battle::kUnexistTileIndex;
  }

  cocos2d::CCPoint SnapToGrid(cocos2d::CCPoint position)
  {
    int_8 target_tile_idx = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    assert(target_tile_idx != taomee::battle::kUnexistTileIndex);
    return taomee::battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);
  }

  //used only in this file
  //don't want tile index in actor system, used only:
  //  PositionCorrection (Primary)
  //  position (Secondary)
  //  grid x/y (Remedy, should be enough)
  //below only used for tile_index to grid_x/y
  const int tile_index_to_grid_x_list[18] = {
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6
  };
  const int tile_index_to_grid_y_list[18] = {
    1,  1,  1,      1,  1,  1,
    2,  2,  2,      2,  2,  2,
    3,  3,  3,      3,  3,  3
  };

  int GetGridXFromTileIndex(int tile_index)
  {
    return tile_index_to_grid_x_list[tile_index];
  }
  int GetGridYFromTileIndex(int tile_index)
  {
    return tile_index_to_grid_y_list[tile_index];
  }

  //used only in this file


  void ResetSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->removeAllActorSkill();
  }

  void AddSkillTargetAdapter(ActorAdapter* actor_adapter, int target_id)
  {
    actor_adapter->target_selection()->set_target_id(target_id);
  }

  void CommitSkillAdapter(ActorAdapter* actor_adapter, int skill_id, int attack_type)
  {
    int skill_release_type = -1;

    switch (eActorAttackType(attack_type))
    {
    case kActorAttackMelee:
      skill_release_type = kSkillNormalHitNear;
      break;
    case kActorAttackRanged:
    case kActorAttackHeal:
      skill_release_type = kSkillNormalHitFar;
      break;
    case kActorAttackPower:
    case kActorAttackSpecial:
      skill_release_type = kSkillSkill;
      break;
    }

    //actor_adapter_->set_selected_skill_id(skill_id);
    actor_adapter->getSkillControl()->playSkillByID(skill_id, skill_release_type);
  }

  bool GetIsSkillFinishedAdapter(ActorAdapter* actor_adapter)
  {
    return (actor_adapter->getSkillControl()->getSkillMotionState() == taomee::ai::kMotionResultCompelted)
      || (actor_adapter->getSkillControl()->getSkillMotionState() == taomee::ai::kMotionResultInvalid);
  }

  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->set_is_active(false);
    actor_adapter->set_ai_state(taomee::ai::KAIStateDead);
    taomee::ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(actor_adapter, taomee::ai::kMotionStateDead);
    actor_adapter->set_current_animation_state(taomee::ai::kMotionResultCompelted);
    //later will be checked in troops hub Update
//     if(!unit->is_active() && unit->motion_state() == ai::kMotionStateDead &&
//       unit->current_animation_state() == ai::kMotionResultCompelted)
  }

  void NastyActorInitAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    Actor* actor_ = actor;
    CharacterData* character_card_data_ = actor_adapter->character_card_data();
    //set data
    if (character_card_data_->GetIsEnemy())
    {
      if (character_card_data_->GetMonsterLevel() > 0)
        actor_->GetActorData()->GetBasicData()->SetActorType(kActorEnemyBoss);
      else
        actor_->GetActorData()->GetBasicData()->SetActorType(kActorEnemyPawn);
    }
    else
      actor_->GetActorData()->GetBasicData()->SetActorType(kActorCharacter);


    actor_->GetActorData()->GetBasicData()->SetFactionType(character_card_data_->GetIsEnemy() ? kActorFactionUserOppose : kActorFactionUserSupport);

    switch (taomee::army::eCareerType(character_card_data_->GetJobType()))
    {
    case taomee::army::kCareerTypeWarrior:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerWarrior);
      break;
    case taomee::army::kCareerTypeArcher:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerArcher);
      break;
    case taomee::army::kCareerTypeWizard:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerWizard);
      break;
    case taomee::army::kCareerTypeMonk:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerPriest);
      break;
    case taomee::army::kCareerTypeKnight:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerKnight);
      break;
    default:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareer);
      break;
    }

    switch (taomee::army::eCareerType(character_card_data_->GetJobType()))
    {
    case taomee::army::kCareerTypeKnight:
    case taomee::army::kCareerTypeWarrior:
      actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackMelee, character_card_data_->GetSkillId(kSkillNormalHitNear));

      actor_->GetActorData()->GetSkillData()->SetGuardType(kActorGuardMelee);
      actor_->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerMelee, actor_));

      actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttackMelee);
      actor_->GetActorData()->GetSkillData()->SetAttackTriggerMelee(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerMelee, actor_));
      break;
    case taomee::army::kCareerTypeMonk:
    case taomee::army::kCareerTypeWizard:
    case taomee::army::kCareerTypeArcher:
      actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackRanged, character_card_data_->GetSkillId(kSkillNormalHitFar));

      actor_->GetActorData()->GetSkillData()->SetGuardType(kActorGuardRanged);
      actor_->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerRanged, actor_));

      actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttackRanged);
      actor_->GetActorData()->GetSkillData()->SetAttackTriggerRanged(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerRanged, actor_));
      break;
    default:
      actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttack);
      break;
    }

    actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackPower, character_card_data_->GetSkillId(kSkillSkill_Little));
    actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackSpecial, character_card_data_->GetSkillId(kSkillSkill));

    ///////////character_card_data_->GetAttackRange();
    //////character_card_data_->GetBodyRange();

    //actor_->GetActorData()->GetControlData();
    //actor_->GetActorData()->GetBuffData();
    //actor_->GetActorData()->GetLogicData()->SetGuardTrigger(NULL);
    //actor_->GetActorData()->GetMotionData();

    //initial logic state
    actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateBorn));
    actor_->GetActorData()->GetMotionData()->SetDefaultAnimationDirection(character_card_data_->GetIsEnemy() ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);

    //control
    actor_->GetControl()->SetControlType(character_card_data_->GetIsEnemy() ? kActorControlAuto : kActorControlSemiAuto);

    //Activate
    actor_->SetIsActorActive(true);
  }



  void NastyActorInitRoutineDataAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    Actor* actor_ = actor;
    CharacterData* character_card_data_ = actor_adapter->character_card_data();

    ActorControlRoutine* actor_control_routine = new ActorControlRoutine(actor_);
    actor_->GetControl()->SetActorControlRoutine(actor_control_routine);

    actor_control_routine->AddRoutineData(std::string("actor_type"), actor->GetActorData()->GetBasicData()->GetActorType());
    actor_control_routine->AddRoutineData(std::string("fraction_type"), actor->GetActorData()->GetBasicData()->GetFactionType());

    if (character_card_data_->GetIsEnemy())
    {
      actor_control_routine->AddRoutineData(std::string("ROUTINE_NAME"), std::string("routine_config_enemy_pawn"));

      taomee::army::Monster* actor_adapter_monster = dynamic_cast<taomee::army::Monster*>(actor_adapter);
      if (actor_adapter_monster)
      {
        int born_grid_x = actor_adapter->stage_stay_column() + 1;
        int born_grid_y = -1;
        actor_control_routine->AddRoutineData(std::string("born_grid_x"), born_grid_x);
        actor_control_routine->AddRoutineData(std::string("born_grid_y"), born_grid_y);
      }
    }
    else
    {
      actor_control_routine->AddRoutineData(std::string("ROUTINE_NAME"), std::string("routine_config_character"));

      taomee::army::Character* actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);
      if (actor_adapter_character)
      {
        int born_tile_index = actor_adapter_character->garrison_tile_index();

        int born_grid_x = GetGridXFromTileIndex(born_tile_index);
        int born_grid_y = GetGridYFromTileIndex(born_tile_index);
        actor_control_routine->AddRoutineData(std::string("born_grid_x"), born_grid_x);
        actor_control_routine->AddRoutineData(std::string("born_grid_y"), born_grid_y);
      }
    }

    //activate
    actor_control_routine->LoadRoutine();

    //first reset direction
    actor_->GetActorData()->GetMotionData()->ResetAnimationDirection();
  }
}