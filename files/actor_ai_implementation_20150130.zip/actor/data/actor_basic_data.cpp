#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  void ActorBasicData::Update(float delta_time)
  { 
    UpdateActiveTime(delta_time);
  }

  bool ActorBasicData::GetIsWeakStatus()
  { 
    return GetCurrentHealth() < GetTotalHealth() * 0.01f * WEAK_RATE;
  }

  bool ActorBasicData::GetIsDeadStatus()
  {
    return GetCurrentHealth() <= 0;
  }

  //ActorBasicData
  void ActorBasicData::SetCurrentHealth(int current_health)
  {
    actor_adapter_->set_currnet_health_point(current_health);
  }
  int ActorBasicData::GetCurrentHealth()
  {
    return actor_adapter_->currnet_health_point();
  }

  void ActorBasicData::SetTotalHealth(int max_health)
  {
    actor_adapter_->set_base_total_health_point(max_health);
  }
  int ActorBasicData::GetTotalHealth()
  {
    return actor_adapter_->total_health_point();
  }

  void ActorBasicData::ActorDeadCleanUp()
  {
    NastyActorDeadCleanUpAdapter(actor_adapter_);
  }

  //ActorBasicData

} // namespace actor