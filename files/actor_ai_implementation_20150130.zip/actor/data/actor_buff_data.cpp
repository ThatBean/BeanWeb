#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {
  ActorBuffData::ActorBuffData()
    : is_buff_finished_(true),
    is_incontrollable_finished_(true)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }


} // namespace actor