#ifndef ACTOR_SKILL_DATA_H
#define ACTOR_SKILL_DATA_H

#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;
  class ActorTrigger;


  const int ACTOR_SKILL_ID_INVALID = -1;

  enum eActorGuardType
  {
    kActorGuardMelee, //Circle
    kActorGuardRanged, //Rectangle front & same row
    //kActorGuard,
    kActorGuard
  };

  enum eActorAttackType
  {
    kActorAttackMelee = 1 << 0,
    kActorAttackRanged = 1 << 1,
    kActorAttackHeal = 1 << 2,
    kActorAttackPower = 1 << 3,
    kActorAttackSpecial = 1 << 4,
    kActorAttack
  };

  class ActorSkillData
  {
  public:
    ActorSkillData();
    ~ActorSkillData();

    int GetActorNormalAttackCount() { return actor_normal_attack_count_; }
    int GetActorPowerAttackCount() { return actor_power_attack_count_; }
    int GetActorSpecialAttackCount() { return actor_special_attack_count_; }

    void                 SetAttackType(eActorAttackType set_type) { actor_attack_type_ = set_type; }
    eActorAttackType     GetAttackType() { return actor_attack_type_; }

    void  SetSkillIdByType(eActorAttackType attack_type, int skill_id);
    int   GetSkillIdByType(eActorAttackType attack_type);
    eActorAttackType   GetSkillTypeById(int skill_id);



    void SetGuardType(eActorGuardType guard_type) { guard_type_ = guard_type_; }
    eActorGuardType GetGuardType() { return guard_type_; }

    void SetGuardTrigger(ActorTrigger* trigger) { guard_trigger_ = trigger; }
    ActorTrigger* GetGuardTrigger() { return guard_trigger_; }


    void SetAttackTriggerMelee(ActorTrigger* trigger) { attack_trigger_melee_ = trigger; }
    ActorTrigger* GetAttackTriggerMelee() { return attack_trigger_melee_; }
    void SetAttackTriggerHeal(ActorTrigger* trigger) { attack_trigger_heal_ = trigger; }
    ActorTrigger* GetAttackTriggerHeal() { return attack_trigger_heal_; }
    void SetAttackTriggerRanged(ActorTrigger* trigger) { attack_trigger_ranged_ = trigger; }
    ActorTrigger* GetAttackTriggerRanged() { return attack_trigger_ranged_; }

    void SetAttackTriggerPower(ActorTrigger* trigger) { attack_trigger_power_ = trigger; }
    ActorTrigger* GetAttackTriggerPower() { return attack_trigger_power_; }
    void SetAttackTriggerSpecial(ActorTrigger* trigger) { attack_trigger_special_ = trigger; }
    ActorTrigger* GetAttackTriggerSpecial() { return attack_trigger_special_; }


    void UpdateNormalAttackTrigger();
    bool GetNormalAttackIsTriggered();  //return is trigger triggered
    eActorAttackType GetNormalAttackTriggeredType();

    ActorTrigger* GetTriggeredAttackTrigger();

    //currently in adapter
    void ResetSkill();
    void AddSkillTarget(int target_id);
    void CommitSkill(int skill_id);
    void SetIsSkillFinished(bool is_skill_finished) { is_skill_finished_ = is_skill_finished; }
    bool GetIsSkillFinished();// { return is_skill_finished_; } //currently reading from skill control


    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }
  private:
    //static data, added every time skill is commited
    int actor_normal_attack_count_;
    int actor_power_attack_count_;
    int actor_special_attack_count_;

    eActorAttackType     actor_attack_type_;

    bool is_skill_finished_;

    int actor_skill_id_melee_;
    int actor_skill_id_ranged_;
    int actor_skill_id_heal_;

    int actor_skill_id_power_;
    int actor_skill_id_special_;

    //used in logic guard, if triggered, actor will move to attack
    eActorGuardType     guard_type_;
    ActorTrigger*       guard_trigger_;  //target searching by guard range, mostly used in Idle/Move

    //below trigger used for logic attack state, target selection process. If triggered, should be able to hit target
    // currently there should be only one normal attack trigger
    ActorTrigger*       attack_trigger_melee_;  //normal attack, for warrior/knight
    ActorTrigger*       attack_trigger_heal_;  //normal attack, for priest
    ActorTrigger*       attack_trigger_ranged_;  //normal attack, for archer/wizard

    ActorTrigger*       attack_trigger_power_;  //powerful normal attack
    ActorTrigger*       attack_trigger_special_;  //special attack (The Skill of this Actor)

  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*       actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_SKILL_DATA_H