#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

} // namespace actor