#ifndef ACTOR_TRIGGER_PREDEFINED_H
#define ACTOR_TRIGGER_PREDEFINED_H

#include "actor_trigger.h"
#include "actor_trigger_module.h"

namespace actor {

  class Actor;

  enum eActorPredefinedGuardTriggerType
  {
    kActorPredefinedGuardTriggerMelee,
    kActorPredefinedGuardTriggerRanged,
    kActorPredefinedGuardTrigger
  };

  enum eActorPredefinedAttackTriggerType
  {
    kActorPredefinedAttackTriggerMelee,
    kActorPredefinedAttackTriggerRanged,
    //kActorPredefinedTrigger,
    //kActorPredefinedTrigger,
    kActorPredefinedAttackTrigger
  };

  enum eActorPredefinedTriggerType
  {
    //kActorPredefinedTrigger,
    kActorPredefinedTrigger
  };

  ActorTrigger* GetPredefinedGuardTrigger(eActorPredefinedGuardTriggerType predefined_trigger_type, Actor* actor);
  ActorTrigger* GetPredefinedAttackTrigger(eActorPredefinedAttackTriggerType predefined_trigger_type, Actor* actor);

} // namespace actor


#endif // ACTOR_TRIGGER_PREDEFINED_H
