#ifndef ACTOR_TRIGGER_MODULE_GEOMETRY_H
#define ACTOR_TRIGGER_MODULE_GEOMETRY_H


#include "game/actor/trigger/actor_trigger_module.h"
#include "cocos2d.h"

namespace actor 
{
  enum eActorTriggerGeometryFlag  //these flag helps to decide the range faster, set at least one of (Dist || Dir)
  {
    kActorTriggerGeometryFlagShape      = 1 << 0, //if set, shape & radius & ratio_y data is used  // if not, no filter shape
    kActorTriggerGeometryFlagDirection  = 1 << 1, //if set, direction data is used // if not, no direction, not relative(may affect Distance)
    kActorTriggerGeometryFlagLocation   = 1 << 2, //if set, location data is used instead of actor position
    kActorTriggerGeometryFlag = 0
  };

  enum eActorTriggerGeometryShape
  {
    kActorTriggerGeometryShapeRectangle,
    kActorTriggerGeometryShapeCircle,
    kActorTriggerGeometryShape
  };

  class ActorTriggerModuleDataGeometry : public ActorTriggerModuleData
  {
  public:
    static const uint_32 TARGET_MODULE_TYPE;

    ActorTriggerModuleDataGeometry() 
      : ActorTriggerModuleData(),
    radius_max_(0),
    radius_min_(0),
    ratio_y_(1.0f),
    shape_(kActorTriggerGeometryShapeCircle),
    is_direction_relative_(false),
    is_direction_left_or_front_(false),
    is_location_relative_(false)
    {

    }

    //Convenient flag setter with extra parameters
    void    SetTriggerFlagShape(float radius_max, float radius_min = 0, float ratio_y = 1.0);
    void    SetTriggerFlagShape(eActorTriggerGeometryShape shape, float radius_max, float radius_min = 0, float ratio_y = 1.0);
    void    SetTriggerFlagDirection(bool is_direction_left_or_front, bool is_direction_relative = true);
    void    SetTriggerFlagLocation(cocos2d::CCPoint center_location, bool is_location_relative = true);


    //setter, maybe no use at all
    void    SetRadius(float radius_max, float radius_min = 0) { radius_max_ = radius_max; radius_min_ = radius_min; }
    void    SetRatioY(float ratio_y) { ratio_y_ = ratio_y; }
    void    SetShape(eActorTriggerGeometryShape shape) { shape_ = shape; }
    void    SetDirection(bool is_direction_left_or_front, bool is_direction_relative = true) { is_direction_left_or_front_ = is_direction_left_or_front; is_direction_relative_ = is_direction_relative; }
    void    SetLocation(cocos2d::CCPoint center_location, bool is_location_relative = true) { center_location_ = center_location; is_location_relative_ = is_location_relative; }

    //getter, maybe no use at all
    float   GetRadiusMin() { return radius_min_; }
    float   GetRadiusMax() { return radius_max_; }
    float   GetRatioY() { return ratio_y_; }
    eActorTriggerGeometryShape GetShape() { return shape_; }
    bool    GetIsDirectionLeft(bool is_actor_direction_left = true) 
    { 
      if (is_direction_relative_ == false) return is_direction_left_or_front_; 
      else return is_direction_left_or_front_ == is_actor_direction_left; 
    }
    cocos2d::CCPoint   GetLocation() { return center_location_; }
    bool   GetIsLocationRelative() { return is_location_relative_; }

    //faster loop filter
    void  ResetQuickFilter();
    bool  InitQuickFilter(Actor* actor);  //return init result: true = need filter, false = keep all
    bool  QuickFilter(Actor* ref_actor);  //return is_filtered: true = remove, false = keep

  private:
    float   radius_max_;
    float   radius_min_;
    float   ratio_y_;
    eActorTriggerGeometryShape shape_;

    bool    is_direction_relative_;
    bool    is_direction_left_or_front_;

    bool    is_location_relative_;
    cocos2d::CCPoint center_location_;


    //quick filter data
    cocos2d::CCRect     _filter_rectangle_max_;
    cocos2d::CCRect     _filter_rectangle_min_;
    cocos2d::CCPoint    _filter_shape_center_;
    cocos2d::CCPoint    _filter_actor_position_;

    bool    _filter_keep_left_side_;

    bool    _filter_is_use_rectangle_max_;
    bool    _filter_is_use_rectangle_min_;
    bool    _filter_is_use_circle_;
    bool    _filter_is_use_direction_;


  };

  class ActorTriggerModuleGeometry : public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleGeometry() {}

  public:
    static ActorTriggerModuleGeometry* Instance();
    ~ActorTriggerModuleGeometry() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateGeometry(Actor* actor, ActorTriggerModuleDataGeometry* trigger_module_data, std::list<Actor*>* actor_list);

  private:
    static const eActorTriggerModule trigger_module_type_;

  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_GEOMETRY_H