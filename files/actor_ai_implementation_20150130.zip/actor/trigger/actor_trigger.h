#ifndef ACTOR_TRIGGER_H
#define ACTOR_TRIGGER_H

#include "actor_trigger_module.h"


namespace actor 
{
  
  class Actor;

  typedef struct TriggerModuleConfig
  {
    ActorTriggerModule*   trigger_module;
    ActorTriggerModuleData* trigger_module_data;
  } sTriggerModuleConfig;


  class ActorTrigger 
  {
  public:
    ActorTrigger(Actor* actor);
    ~ActorTrigger();

    void AddTriggerModuleConfig(ActorTriggerModule* trigger_module, ActorTriggerModuleData* trigger_module_data);
    void ClearTriggerModuleConfig();

    void Update();  // loop trigger module

    bool              GetIsTriggered() { return is_triggered_; }
    
    void              ClearTriggeredList();

    std::list<Actor*>*  GetTriggeredActorList() { return triggered_actor_list_; }
    std::list<int>*     GetTriggeredActorIdList() { return triggered_actor_id_list_; }

  private:
    Actor*     actor_;

    // update result
    bool                is_triggered_;
    std::list<Actor*>*  triggered_actor_list_;
    std::list<int>*     triggered_actor_id_list_;


    // process config list
    std::list<sTriggerModuleConfig*>   trigger_module_config_list_;
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_H