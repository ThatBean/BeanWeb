#include "actor_logic_state_move.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateMove::STATE_TYPE = kActorLogicStateMove;

  LogicStateMove* LogicStateMove::Instance()
  {
    static LogicStateMove instance;
    return &instance;
  }


  void LogicStateMove::OnEnter(Actor* actor)
  {
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateMove));
  }

  void LogicStateMove::OnExit(Actor* actor)
  {
    
  }

  void LogicStateMove::Update(Actor* actor, float delta_time)
  {
    //Position
    //Target
    
    //Finished State Logic?
    if (actor->GetActorData()->GetMotionData()->GetIsMotionAnimationEnded())
    {
      //clear control data
      actor->GetActorData()->GetControlData()->ResetPosition();
      actor->GetActorData()->GetControlData()->ResetTarget();

      //back to idle
      actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
    }

    //check trigger
    if (/*actor->GetActorData()->GetControlData()->IsSet() == false && */actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdownAttack();

      if (CommonCheckAttackTrigger(actor))
      {
        //clear control data
        actor->GetActorData()->GetControlData()->ResetPosition();
        actor->GetActorData()->GetControlData()->ResetTarget();

        //goto Attack, commit attack
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
      }
    }
  }

} // namespace actor