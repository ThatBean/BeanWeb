#include "actor_logic_state_idle.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateIdle::STATE_TYPE = kActorLogicStateIdle;

  LogicStateIdle* LogicStateIdle::Instance()
  {
    static LogicStateIdle instance;
    return &instance;
  }


  void LogicStateIdle::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(true);
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIdle));
  }

  void LogicStateIdle::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);
  }

  void LogicStateIdle::Update(Actor* actor, float delta_time)
  {
    //check trigger
    if (actor->GetActorData()->GetControlData()->IsSet() == false && actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdownGuard();

      if (CommonCheckAttackTrigger(actor))
      {
        //goto Attack, commit attack
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
      }

      if (CommonCheckGuardTrigger(actor))
      {
        //goto Move, move closer and guard
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
      }
    }
  }
} // namespace actor