--[[
RoutineConfigLoader = RoutineConfigLoader or (function ()
	local RoutineConfigLoader = {}
	RoutineConfigLoader._loaded_routine_config_script = {}
	RoutineConfigLoader._lua_routine_config_script_path = "script/actor/routine/"

	RoutineConfigLoader._load_script_as_local_env = function (script_path)
		local loaded_script = loadfile(script_path)
		if (loaded_script == nil) then
			print("script load local env failed", script_path)
			return
		end
		
		local loaded_env = {}
		setmetatable(loaded_env, {__index = _G})
		setfenv(loaded_script, loaded_env)()
		return loaded_env
	end
		
	RoutineConfigLoader._load_script = function(script_path)
		if (script_path) then
			if (RoutineConfigLoader._loaded_routine_config_script[script_path]) then
				print("RoutineConfigLoader._load_script <reuse>", script_path)
				return RoutineConfigLoader._loaded_routine_config_script[script_path]
			end
			print("RoutineConfigLoader._load_script", script_path)
			local loaded_env = RoutineConfigLoader._load_script_as_local_env(script_path)
			if (loaded_env == nil) then
				print("script load failed", script_path)
				return
			end
			RoutineConfigLoader._loaded_routine_config_script[script_path] = loaded_env
			return loaded_env
		end
	end

	RoutineConfigLoader._unload_script = function(script_path)
		if (script_path) then
			RoutineConfigLoader._loaded_routine_config_script[script_path] = nil
			
			--in case
			package.loaded[script_path] = nil
		end
	end
	
	return RoutineConfigLoader
end)()
--]]


local function DEBUG_PRINT(...)
	--print(...)
	return
end


local RoutineControl = {}

RoutineControl._lua_routine_config_script_path = "script/actor/routine/"

function RoutineControl.new()
	local instance = RoutineControl:_new()
	instance:_constructor()
	return instance
end


function RoutineControl:_new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end


function RoutineControl:_constructor()
	--from config
	self.trigger_func_list = {}	-- special routine pack needed to be checked every update
	self.routine_pack_list = {}
	self.routine_global_data = {} --store settings and lua-maintained data(global)
	
	--runtime data
	self.time_update_countdown = 0
	self.time_update_countdown_default = 0.1
	self.time_total = 0
	self.time_routine_pack = 0
	self.time_routine = 0
	
	self.current_routine_pack = nil
	self.last_routine_pack = nil
end


function RoutineControl:LoadConfig(routine_config)
	DEBUG_PRINT("[RoutineControl][LoadConfig]")
	
	self.trigger_func_list = routine_config.trigger_func_list	-- special routine pack needed to be checked every update
	self.routine_pack_list = routine_config.routine_pack_list
	
	for key, value in pairs(routine_config.routine_global_data) do
		self.routine_global_data[key] = value
	end
end


function RoutineControl:Clear()
	DEBUG_PRINT("[RoutineControl][Clear]")

end


function RoutineControl:Init(actor_script_exporter)
	DEBUG_PRINT("[RoutineControl][Init]")
	--where c++ actor data comes from
	self.actor_script_exporter = actor_script_exporter
	
	self.time_update_countdown = 0
	self.time_total = 0
	self.time_routine_pack = 0
	self.time_routine = 0
end


function RoutineControl:Update(delta_time)
	DEBUG_PRINT("[RoutineControl][Update]")
	if (self:_update_time(delta_time) == false) then
		return
	end
	
	self.time_update_countdown = self.time_update_countdown_default
	
	self:_get_current_routine_pack()
	if (not self.current_routine_pack) then
		DEBUG_PRINT("[RoutineControl][Update] no <current_routine_pack>, skip update")
		return
	end
	self:_update_routine_pack(self.current_routine_pack)
end



--private function should not be called outside of this script file
function RoutineControl:_update_time(delta_time)
	self.time_total = self.time_total + delta_time
	self.time_routine_pack = self.time_routine_pack + delta_time
	self.time_routine = self.time_routine + delta_time
	
	self.time_update_countdown = self.time_update_countdown - delta_time
	
	return (self.time_update_countdown <= 0)
end


function RoutineControl:_change_routine_pack(routine_pack)
	DEBUG_PRINT("[RoutineControl][_change_routine_pack] ", routine_pack.name)

	self.last_routine_pack = self.current_routine_pack
	self.current_routine_pack = routine_pack
	self.time_routine_pack = 0
	self.time_routine = 0
end


function RoutineControl:_get_current_routine_pack()
	local routine_pack = self:_get_triggered_routine_pack()
	if (routine_pack) then
		self:_change_routine_pack(routine_pack)
	end
	
	if (not self.current_routine_pack) then
		self.current_routine_pack = self.routine_pack_list["ROUTINE_START"]
	end
	
	DEBUG_PRINT("[RoutineControl][_get_current_routine_pack] ", self.current_routine_pack.name)
	return self.current_routine_pack
end


function RoutineControl:_get_next_routine_pack()
	DEBUG_PRINT("[RoutineControl][_get_next_routine_pack]")
	local routine_pack_name = self.current_routine_pack.next_name_getter_func(self)
	local routine_pack = self.routine_pack_list[routine_pack_name]
	if (routine_pack) then
		self:_change_routine_pack(routine_pack)	--there will be an end of routine pack
	end
end


function RoutineControl:_get_triggered_routine_pack()
	DEBUG_PRINT("[RoutineControl][_get_triggered_routine_pack]")
	if (self.trigger_func_list and #(self.trigger_func_list)) then
		for index, trigger_func in pairs(self.trigger_func_list) do
			local routine_pack_name = trigger_func(self)
			local routine_pack = self.routine_pack_list[routine_pack_name]
			if (routine_pack) then
				return routine_pack
			end
		end
	end
end

function RoutineControl:_update_routine_pack(routine_pack)
	DEBUG_PRINT("[RoutineControl][_update_routine_pack] ", routine_pack.name)
	local current_routine = routine_pack.routine_list[routine_pack.current_routine_index]
	if (not current_routine) then
		self:_get_next_routine_pack()
		return
	end
	
	--change routine to next one
	if (current_routine.update_func(self, current_routine) == false) then
		routine_pack.current_routine_index = routine_pack.current_routine_index + 1
		self.time_routine = 0
		self:_update_routine_pack(routine_pack)
	end
end

--control data from lua
function RoutineControl:SetCountdown(time_update_countdown)
	self.time_update_countdown = time_update_countdown or self.time_update_countdown_default
end
function RoutineControl:GlobalData()
	return self.routine_global_data
end
function RoutineControl:GetControlTimeTotal()
	return self.time_total
end
function RoutineControl:GetControlTimeRoutinePack()
	return self.time_routine_pack
end
function RoutineControl:GetControlTimeRoutine()
	return self.time_routine
end

--export from c++
function RoutineControl:GetActorHealthPercent()
	return self.actor_script_exporter:GetActorHealthPercent()
end
function RoutineControl:GetActorPosition()
	return self.actor_script_exporter:GetActorPosition()
end
function RoutineControl:GridToPosition(grid_x, grid_y)
	return self.actor_script_exporter:GridToPosition(grid_x, grid_y)
end
function RoutineControl:ActorAutoGuard()
	return self.actor_script_exporter:ActorAutoGuard()
end
function RoutineControl:GetActorRoutineControlData()
	return self.actor_script_exporter:GetActorRoutineControlData()
end

return RoutineControl
--[[

local trigger_func = function(routine_control) {},	--only when this is trigger kind of routine
local routine_pack = {
	name = "P1",
	next_name_getter_func = function(routine_control) {return "ROUTINE_BACK"},
	routine_list = {	--the routine in list will be executed or skipped by order
		{
			--enter_func = function(routine_control) {},
			--end_func = function(routine_control) {},
			update_func = function(routine_control, routine_data) {},	--return true for reuse, return false for skip
		},
	},
	current_routine_index = 1,
}
--]]
