local MonsterBossRoutine = {
	Born = function () return function () return false end end,
	Walk = function () return function () return false end end,
	Guard = function () return function () return false end end,
	Skill = function () return function () return false end end,
	SearchAndAttack = function () return function () return false end end,
	PlayDrama = function () return function () return false end end,
}



return function (RoutineControlPresetConfig)
	local RC = RoutineControlPresetConfig
	local routine_config_raw = {
		routine_pack_arrangement = {
			{RC.ROUTINE_START, {"P1"}, RC.SWITCH_CONDITION.NO_CONDITION},
			{"P1", {"P2"}, RC.SWITCH_CONDITION.NO_CONDITION},
			{"P2", {"P3", "P4"}, RC.SWITCH_CONDITION.RANDOM},
			{"P3", {"P2"}, RC.SWITCH_CONDITION.NO_CONDITION},
			--{"P4", {"P2", "P_END"}, HEALTH_PERCENT({1, 0.2}, {0.2, 0})},
			{"P4", {"P2", "P_END"}, RC.SWITCH_CONDITION.HEALTH_PERCENT({0.5, 1}, {0, 0.5})},
			
			{RC.ROUTINE_TRIGGER, {"P_END", RC.ROUTINE_BACK}, RC.SWITCH_CONDITION.HEALTH_PERCENT({0, 0.5})}, -- ??
			--{RC.ROUTINE_TRIGGER_IDLE, "P_END", RC.SWITCH_CONDITION.HEALTH_PERCENT({0.2, 0})},  ??
			{"P_END", {RC.ROUTINE_END}, RC.SWITCH_CONDITION.NO_CONDITION},
		},
		routine_pack_routine_list = {
			P1 = {	--Boss Born
				{
					routine_update = MonsterBossRoutine.Born("place_at"),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.TIME("since_routine_start", 5 * 60),
				},
				{
					routine_update = MonsterBossRoutine.Walk(ccp(5, 5)),
					enter_condition = RC.BOOL_CONDITION.TIME("since_control_start", 5 * 60),
					end_condition = RC.BOOL_CONDITION.ACTOR_DATA("position", ccp(5, 5)),
				},
			},
			P2 = {	--Guard And Attack
				{
					routine_update = MonsterBossRoutine.Guard(),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.TIME("since_routine_start", 1 * 60),
				},
			},
			P3 = {	--Use Some Skill Combo
				{
					routine_update = MonsterBossRoutine.Skill("boss_sk_0001"),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.UPDATE_FINISH,
				},
				{
					routine_update = MonsterBossRoutine.Skill("boss_sk_0002"),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.UPDATE_FINISH,
				},
			},
			P4 = {	--Move and Attack Single Actor
				{
					routine_update = MonsterBossRoutine.SearchAndAttack("enemy", "condition_health_min", "boss_sk_0003"),
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = RC.BOOL_CONDITION.UPDATE_FINISH,
				},
			},
			P_END = {
				{
					routine_update = function(routine_control, routine_data)
						local actor_position = routine_control:GetActorPosition()
						routine_control:GetActorRoutineControlData():SetPosition(ccp(1500, actor_position.y))
						--MonsterBossRoutine.LockHealth(0.001)
						MonsterBossRoutine.PlayDrama("boss_drama_0001")(routine_control, routine_data)
					end,
					enter_condition = RC.BOOL_CONDITION.NO_CONDITION,
					end_condition = function (routine_control, routine_data)
						return (RC.BOOL_CONDITION.UPDATE_FINISH(routine_control, routine_data) or RC.BOOL_CONDITION.TIME("since_routine_start", 5 * 60)(routine_control, routine_data))
					end,
				},
			},
		},
		routine_global_data = {
		
		},
	}
	local routine_config = RC.ConvertRoutinePack(routine_config_raw)
	return routine_config
end