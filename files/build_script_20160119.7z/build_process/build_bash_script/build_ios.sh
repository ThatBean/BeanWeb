#!/bin/bash

## MOVED TO PYTHON SCRIPT
## MOVED TO PYTHON SCRIPT
## MOVED TO PYTHON SCRIPT

#WORKSPACE
#LANG_VERSION
#PRODUCT_NAME
#GLOBAL_PROJECT
#PLATFORM
#PATH_PRODUCT_VERSION_SPECIFIC
#CURRENT_DEVELOP_VERSION
#NEXT_DISTRIBUTION_VERSION_CODE
#CURRENT_VERSION_BUILD_NUMBER

#PATH_PROJECT=${WORKSPACE}/${GLOBAL_PROJECT}/ios
#PATH_PRODUCT_VERSION_SPECIFIC=${PATH_PRODUCT_VERSION_SPECIFIC}
#STRING_PRODUCT_NAME=${TARGET_NAME}_${PRODUCT_NAME}_v${STRING_VERSION_NAME}_${CONFIGURATIONS}.${CURRENT_VERSION_BUILD_NUMBER}
#STRING_VERSION_NAME=${CURRENT_DEVELOP_VERSION}
#STRING_KEYCHAIN_PASSWORD="ago@123"
#STRING_XCODE_SDK="iphoneos6.1"
#STRING_XCODE_CONFIGURATION="ReleaseAny"
#STRING_XCODE_TARGET_NAME="ChainChronicle"


function failed() {
    echo "Failed: $@" >&2
    exit 1
}

# -e      If return is not 0, exit immediately
# -x      Expand and print each command
set -ex


echo "*************************** Build iOS App ***************************"


echo [PATH_PROJECT] ${PATH_PROJECT}
echo [PATH_PRODUCT_VERSION_SPECIFIC] ${PATH_PRODUCT_VERSION_SPECIFIC}
echo [STRING_PRODUCT_NAME] ${STRING_PRODUCT_NAME}

###
# unlock keychain
#####
FILE_KEYCHAIN=~/Library/Keychains/login.keychain
security unlock-keychain -p ${STRING_KEYCHAIN_PASSWORD} ${FILE_KEYCHAIN}

###
# create dir in version folder
#####
mkdir -pv ${PATH_PRODUCT_VERSION_SPECIFIC}


###
# set version
#####
cd ${PATH_PROJECT}
agvtool new-version -all ${STRING_VERSION_NAME} 


###
# clean and build
#####
cd ${PATH_PROJECT}
xcodebuild -configuration ${STRING_XCODE_CONFIGURATION} -sdk ${STRING_XCODE_SDK} -target ${STRING_XCODE_TARGET_NAME} clean
xcodebuild -configuration ${STRING_XCODE_CONFIGURATION} -sdk ${STRING_XCODE_SDK} -target ${STRING_XCODE_TARGET_NAME}  || failed "xcode-build"


###
# pack
#####
cd build/${STRING_XCODE_CONFIGURATION}-iphoneos;

#  -r   --recurse-paths   Travel the directory structure recursively
#  -T   --test            Test  the  integrity  of  the  new zip file. If the check fails, the old zip file is unchanged and (with the -m option) no input files are removed.
#  -y   --symlinks        For UNIX and VMS (V8.3 and later), store symbolic links as such in the  zip  archive,  instead  of compressing and storing the file referred to by the link.  This can avoid multiple copies of files being included in the archive as zip recurses the directory trees and accesses files directly  and by links.

# pack raw files (app + dsym)
zip -r -T -y _temp.zip *.app* || failed "pack raw zip"
mv _temp.zip ${PATH_PRODUCT_VERSION_SPECIFIC}/${STRING_PRODUCT_NAME}.zip

# ipa
# rm -rf Payload
# mkdir -pv Payload
# mv *.app Payload
# zip -r -T -y _temp.zip Payload/*.* || failed "ipa"
# mv _temp.zip ${PATH_PRODUCT_VERSION_SPECIFIC}/${STRING_PRODUCT_NAME}.ipa

# pack ipa
xcrun -sdk iphoneos PackageApplication -v ./*.app -o ${PATH_PRODUCT_VERSION_SPECIFIC}/${STRING_PRODUCT_NAME}.ipa || failed "pack ipa"

# another copy for quick find
rm -rf ${PATH_PRODUCT_VERSION_SPECIFIC}/0_NEW_*
cp ${PATH_PRODUCT_VERSION_SPECIFIC}/${STRING_PRODUCT_NAME}.ipa ${PATH_PRODUCT_VERSION_SPECIFIC}/0_NEW_${STRING_PRODUCT_NAME}.ipa


# clean up
rm -rf *.DSYM
rm -rf *.app

###
# revert
#####
cd ${PATH_PROJECT}
svn revert . --depth=infinity