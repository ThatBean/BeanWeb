#!/usr/bin/python
#coding:utf-8 

import os

##--------------------------------------------------------------------------------------
def get_file_path_data(file_path, file_name, target_file_ext, output_file_prefix):
	
	target_file_ext = target_file_ext or ""
	output_file_prefix = output_file_prefix or ""
		
	if (file_path and file_name and (not target_file_ext or os.path.splitext(file_name)[1] == target_file_ext) and (not output_file_prefix or file_name[0] != output_file_prefix)):
		
		source_file_path = os.path.join(file_path, file_name)
		result_file_path = os.path.join(file_path, output_file_prefix + file_name)
		
		return [source_file_path, result_file_path]
	else:
		return None

def GetFileList(path, target_file_ext, output_file_prefix):
	
	print("[GetFileList] searching:", path, target_file_ext, output_file_prefix)
	
	target_file_ext = target_file_ext or ""
	output_file_prefix = output_file_prefix or ""
	
	file_list = []
	
	if os.path.isdir(path):
		print("[GetFileList] path is dir, search files...", path)
		for file_name in os.listdir(path):
			file_path = path
			if os.path.isfile(os.path.join(file_path, file_name)):
			
				path_data = get_file_path_data(file_path, file_name, target_file_ext, output_file_prefix)
				if path_data:
					file_list.append(path_data)
			
			if os.path.isdir(os.path.join(file_path, file_name)):
				# print("[GetFileList] file is sub-dir, search sub-dir...")
				
				sub_file_list = GetFileList(os.path.join(file_path, file_name), target_file_ext, output_file_prefix)
				if sub_file_list:
					file_list.extend(sub_file_list)
				
			
	elif os.path.isfile(path):
		print("[GetFileList] path is file, return directly...", path)
		file_path = os.path.dirname(path)
		file_name = os.path.basename(path)
		
		path_data = get_file_path_data(file_path, file_name, target_file_ext, output_file_prefix)
		if path_data:
			file_list.append(path_data)
		
	else:
		print("[GetFileList] <path> not found! path:", path)
		exit(1)
	
	return file_list
##--------------------------------------------------------------------------------------	


if __name__ == "__main__":
	import sys
	self_module_name = sys.argv[0].split(".")[0]
	print('''
#Generate File List#
return source & output name if a file or all file under a directory, with file extension filter and output prefix
NOTE: file extension starts with '.'

Usage:
	import %s
	output_string = %s.GetFileList("./aaa/BBB/", ".py", "_PRE_")
	print(output_string)
	''' % (self_module_name, self_module_name))