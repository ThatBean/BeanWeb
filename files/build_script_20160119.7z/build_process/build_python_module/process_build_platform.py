#!/usr/bin/python
#coding:utf-8 

import env_info
import JSON_file_reader

##should be json
valid_build_platform_list = {
	"ios" : "PLATFORM_IOS",
	"android" : "PLATFORM_ANDROID"
}


def _check_valid(build_platform):
	if (build_platform in valid_build_platform_list):
		return
	else:
		print("[Error] build platform not valid:", build_platform)
		exit(1)


def ProcessBuildPlatform(build_platform):
	_check_valid(build_platform)
	return valid_build_platform_list[build_platform]