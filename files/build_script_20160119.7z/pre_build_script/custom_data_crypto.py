#!/usr/bin/python
#coding:utf-8 

import os
import sys
import base64

# print(sys.path)
# exit(0)

#add python module path
sys.path.append("../build_process/python_module")	# from current dir
sys.path.append("./build_script/build_process/python_module")	# from program/client dir
import generate_file_list

ENCRYPTED_FILE_PREFIX = "_"

TABLE_BASE64_CRYPT = [
'+','/',
'a','b','c','d','e','f','g','h',
'A','B','C','D','E','F','G','H',
'i','j','k','l','m','n','o','p',
'I','J','K','L','M','N','O','P',
'q','r','s','t','u','v','w','x',
'Q','R','S','T','U','V','W','X',
'y','z',
'Y','Z',
'0','1','2','3','4','5','6','7',
'8','9'
]

TABLE_BASE64_STANDARD = [
'A','B','C','D','E','F','G','H',
'I','J','K','L','M','N','O','P',
'Q','R','S','T','U','V','W','X',
'Y','Z',
'a','b','c','d','e','f','g','h',
'i','j','k','l','m','n','o','p',
'q','r','s','t','u','v','w','x',
'y','z',
'0','1','2','3','4','5','6','7',
'8','9','+','/'
]

TABLE_BASE64_STANDARD_REVERSE = {}

#construct reverse table 
index = 0
for byte in TABLE_BASE64_STANDARD:
	TABLE_BASE64_STANDARD_REVERSE[byte] = index
	index += 1

'''
print(TABLE_BASE64_STANDARD_REVERSE)
print("a" in TABLE_BASE64_STANDARD)

byte = chr(65)

print(TABLE_BASE64_STANDARD_REVERSE[byte])
print(TABLE_BASE64_CRYPT[TABLE_BASE64_STANDARD_REVERSE[byte]])

#exit()	
'''

def EncryptFile(source_file_path, result_file_path):
	f1 = open(source_file_path, 'rb')
	f2 = open(result_file_path, 'wb')

	#base64.encode(f1, f2)	
	#for line in f1.read():
		#encoded_data = base64.encodebytes(line) 
	
	#direct base64 encode
	encoded_data = ""
	if ("encodebytes" in dir(base64)):
		encoded_data = base64.encodebytes(f1.read()) 
		encoded_data = encoded_data.decode("utf-8")
	else:
		encoded_data = base64.encodestring(f1.read()) 
	#print(encoded_data)
	
	#re-order encrypt
	encrypted_data = ""
	for byte in encoded_data:
		#print(byte)
		#print(type(encoded_data))
		#print(type(byte))
		if (byte and (byte in TABLE_BASE64_STANDARD)):
			encrypted_data += TABLE_BASE64_CRYPT[TABLE_BASE64_STANDARD_REVERSE[byte]]
		else:
			#this is not data, maybe " " "\n", just add and skip
			encrypted_data += byte
	
	#save to result file
	f2.write(encrypted_data.encode("ascii"))

	f1.close()
	f2.close()
	
# Encrypt to custom base-64
# USAGE:
#	> python <script_file>.py <target file extension> <source file dir> <is delete source file>
#	> <target file extension> = <required>
#	> <source file dir> = ./
#	> <is delete source file> = false
# SAMPLE:
#	> python <script_file>.py .lua
#	> python <script_file>.py .csv ./files/
#	> python <script_file>.py .lua ./files/ true

if (__name__ == "__main__"):
	
	TARGET_FILE_EXT = ""
	PATH_SRC_FILE_DIR = "./"
	IS_REMOVE_SRC_FILE = False
	
	if (len(sys.argv) >= 2) and sys.argv[1]:
		TARGET_FILE_EXT = sys.argv[1]
	else:
		print("<target file extension> not specified!")
		exit(1)
	
	if len(sys.argv) > 2:
		if sys.argv[2]:
			PATH_SRC_FILE_DIR = sys.argv[2]
	
	if len(sys.argv) > 3:
		if sys.argv[3]:
			IS_REMOVE_SRC_FILE = True
	
	#print(sys.argv, len(sys.argv), PATH_SRC_FILE_DIR, IS_REMOVE_SRC_FILE)
	print("Target Ext:",TARGET_FILE_EXT)
	print("Target Dir:",PATH_SRC_FILE_DIR)
	print("Is Remove Source:", IS_REMOVE_SRC_FILE)
	
	print("===Start Encrypting===")
	
	#get file list
	file_list = generate_file_list.GetFileList(path = PATH_SRC_FILE_DIR, target_file_ext = TARGET_FILE_EXT, output_file_prefix = ENCRYPTED_FILE_PREFIX)
	
	for file_path_data in file_list:
		#get file path
		source_file_path = file_path_data[0]
		result_file_path = file_path_data[1]
		
		print(">> Encrypting", source_file_path)
		
		EncryptFile(source_file_path = source_file_path, result_file_path = result_file_path)
		
		#remove the source file
		if IS_REMOVE_SRC_FILE:
			print(">>>> Removing", source_file_path)
			os.remove(source_file_path)
		
	print("===Finished Encrypting===")
	print("Total File:", len(file_list))