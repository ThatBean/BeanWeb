#include "actor_control_auto.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

namespace actor {

  void UpdateAutoSpecified(Actor* actor, float delta_time)
  {
    switch (actor->GetActorData()->GetBasicData()->GetActorType())
    {
    case kActorCharacter:
      UpdateAutoCharacter(actor, delta_time);
      break;
    case kActorEnemyPawn:
      UpdateAutoEnemyPawn(actor, delta_time);
      break;
    case kActorEnemyBoss:
      UpdateAutoEnemyBoss(actor, delta_time);
      break;
    default:
      assert(false);
      break;
    }
  }


  void UpdateAutoCharacter(Actor* actor, float delta_time)
  {
    ActorSpecifiedDataCharacter* specified_data = (ActorSpecifiedDataCharacter*)(actor->GetActorData()->GetSpecifiedData());
    return;
  }

  void UpdateAutoEnemyPawn(Actor* actor, float delta_time)
  {
    ActorSpecifiedDataEnemyPawn* specified_data = (ActorSpecifiedDataEnemyPawn*)(actor->GetActorData()->GetSpecifiedData());



    return;
  }

  void UpdateAutoEnemyBoss(Actor* actor, float delta_time)
  {
    ActorSpecifiedDataEnemyBoss* specified_data = (ActorSpecifiedDataEnemyBoss*)(actor->GetActorData()->GetSpecifiedData());
    return;
  }

} // namespace actor