#ifndef ACTOR_CONTROL_H
#define ACTOR_CONTROL_H


#include "game/actor/logic/actor_logic_state.h"
#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  
  enum eActorControlType
  {
    kActorControlManual,  //will check user input
    kActorControlAuto,    //will issue command automatically
    kActorControl
  };

  //enum eActorControlManualType

  enum eActorControlAutoType
  {
    kActorControlAutoCharacter,
    kActorControlAutoEnemyPawn,
    kActorControlAutoEnemyBoss,
    kActorControlAutoType
  };

  class ActorControl
  {
  public:
    ActorControl(Actor* actor);
    ~ActorControl();

    void Update();

    eActorControlType GetControlType() { return actor_control_type_; };
    void SetControlType(eActorControlType control_type) { actor_control_type_ = control_type; };

  protected:
    void UpdateManual();
    void UpdateAuto();

    eActorLogicState DecideLogicState();  //check set priority
    bool ControlLogicStateChange(eActorLogicState new_logic_state); //check if exterior logic state change valid, if true, change

  private:
    Actor*               actor_;
    eActorControlType    actor_control_type_;

    //if change of logic state needed
    eActorLogicState     result_logic_state_type_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_H
