#include "actor_trigger_predefined.h"

#include "game/actor/actor.h"

#include "trigger_module/actor_trigger_module_faction.h"
#include "trigger_module/actor_trigger_module_geometry.h"
//#include "trigger_module/actor_trigger_module_status.h"
//#include "trigger_module/actor_trigger_module_script.h"
//#include "trigger_module/actor_trigger_module_active.h"
#include "trigger_module/actor_trigger_module_sort.h"


namespace actor {
  ActorTrigger* GetPredefinedGuardTrigger(eActorPredefinedGuardTriggerType predefined_trigger_type, Actor* actor)
  {
    ActorTrigger* predefined_trigger = new ActorTrigger(actor);

    ActorTriggerModuleDataFaction* module_data_faction = dynamic_cast<ActorTriggerModuleDataFaction*>(GetActorTriggerModuleData(kActorTriggerModuleFaction, kActorTriggerFactionFlagHostile));
    ActorTriggerModuleDataGeometry* module_data_geometry = dynamic_cast<ActorTriggerModuleDataGeometry*>(GetActorTriggerModuleData(kActorTriggerModuleGeometry, kActorTriggerGeometryFlag));
    
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleFaction), module_data_faction);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleGeometry), module_data_geometry);

    switch (predefined_trigger_type)
    {
    case kActorPredefinedGuardTriggerMelee:
      module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeCircle, 1 * taomee::battle::kMapTileMinHeight);
      break;
    case kActorPredefinedGuardTriggerRanged:
      module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeRectangle, 6 * taomee::battle::kMapTileMinHeight, 0, 1 / 12.0f);
      module_data_geometry->SetTriggerFlagDirection(true, true); //front & relative
      break;
    default:
      assert(false);
      break;
    }
    return predefined_trigger;
  }




  ActorTrigger* GetPredefinedAttackTrigger(eActorPredefinedAttackTriggerType predefined_trigger_type, Actor* actor)
  {
    ActorTrigger* predefined_trigger = new ActorTrigger(actor);

    ActorTriggerModuleDataFaction* module_data_faction = dynamic_cast<ActorTriggerModuleDataFaction*>(GetActorTriggerModuleData(kActorTriggerModuleFaction, kActorTriggerFactionFlagHostile));
    ActorTriggerModuleDataGeometry* module_data_geometry = dynamic_cast<ActorTriggerModuleDataGeometry*>(GetActorTriggerModuleData(kActorTriggerModuleGeometry, kActorTriggerGeometryFlag));

    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleFaction), module_data_faction);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleGeometry), module_data_geometry);

    switch (predefined_trigger_type)
    {
    case kActorPredefinedAttackTriggerMelee:
      //should be skill data
      module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeCircle, 0.5 * taomee::battle::kMapTileMinHeight);
      //should be skill data
      //module_data_geometry->SetDistance(actor->GetActorData()->GetSkillData()->GetSkillIdByType(kActorAttackMelee));
      break;
    case kActorPredefinedAttackTriggerRanged:
      //should be skill data
      module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeRectangle, 6 * taomee::battle::kMapTileMinHeight, 0, 1 / 12.0f);
      //should be skill data
      module_data_geometry->SetTriggerFlagDirection(true, true); //front & relative
      break;
      break;
    default:
      assert(false);
      break;
    }
    return predefined_trigger;
  }

} // namespace actor
