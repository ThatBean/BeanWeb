#include "actor_logic_state_idle.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateIdle::STATE_TYPE = kActorLogicStateIdle;

  LogicStateIdle* LogicStateIdle::Instance()
  {
    static LogicStateIdle instance;
    return &instance;
  }


  void LogicStateIdle::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(true);
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIdle));
  }

  void LogicStateIdle::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);
  }

  void LogicStateIdle::Update(Actor* actor, float delta_time)
  {
    //check trigger
    if (actor->GetActorData()->GetControlData()->IsSet() == false && actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdown();

      if (CommonCheckAttackTrigger(actor))
      {
        //goto Attack, commit attack
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
      }

      if (CommonCheckGuardTrigger(actor))
      {
        //goto Move, move closer and guard
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
      }
    }
  }


/*


    //move
    //need not stay on column
    int stay_col = 0;
    if(unit->stage_stay_column() == -1)
    {
      stay_col = 0;
    }
    else
    {
      stay_col = unit->stage_stay_column();
    }

    cocos2d::CCPoint stay_col_pos = battle::GetCenterPointPositionInTile(
      battle::GetTileIndexByTileCoordinatePos(ccp(stay_col, unit->GetCurrentRowIndex())));

    // firstly born, move to stay column
    if(unit->current_pos().x < stay_col_pos.x && unit->stage_state() == army::kStageBorn)
    {
      unit->target_selection()->set_target_pos(ccp(stay_col_pos.x, unit->current_pos().y));
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, 
        kMotionStateMovePosition);
      unit->set_stage_time(0.0f);
      return kAIResultSuccess;
    }

    //default warrior dose not stay for long time
    if(unit->stage_stay_column() == -1)
    {
      if(unit->stage_state() == army::kStageBorn)
        unit->set_stage_state(army::kStageMoveEnd);
    }
    //guard warrior stay on one column
    else
    {
      if(unit->stage_state() == army::kStageBorn)
        unit->set_stage_state(army::kStageAttack);
      if(unit->stage_state() == army::kStageAttack && unit->stage_time() >= AIConfig::GetInstance().GetNearAttackerAIStayTime())
        unit->set_stage_state(army::kStageMoveEnd);
    }

    if(unit->stage_state() == army::kStageAttack)
    {
      ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateIdle); 
    }
    // nothing to do, move to terminal point
    else if(unit->stage_state() == army::kStageMoveEnd)
    {
      if ( controllable_status_flag_ & ai::kControllableStatus_CannotMove)
      {
      }
      else
      {
        unit->target_selection()->set_target_pos(ccp(battle::kMapRightMostX, unit->current_pos().y));
        ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(unit, kMotionStateMovePosition); 
      }

    }
  }*/
} // namespace actor