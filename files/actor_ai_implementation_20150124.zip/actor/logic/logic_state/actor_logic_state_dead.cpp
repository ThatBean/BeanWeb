#include "actor_logic_state_dead.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateDead::STATE_TYPE = kActorLogicStateDead;

  LogicStateDead* LogicStateDead::Instance()
  {
    static LogicStateDead instance;
    return &instance;
  }


  void LogicStateDead::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateDead));
  }

  void LogicStateDead::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);
    //should not exit???
  }

  void LogicStateDead::Update(Actor* actor, float delta_time)
  {
    //Dead logic
  }
} // namespace actor