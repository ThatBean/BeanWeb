#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorMotionData
  ActorMotionData::ActorMotionData()
    :is_weak_status_animation_(false),
    is_motion_animation_finished_(true),
    animation_direction_(kActorAnimationDirection),
    animation_direction_default_(kActorAnimationDirection)
  {
    ResetIsCachedPosition();
  }

  ActorMotionData::~ActorMotionData()
  {
  }

  void ActorMotionData::SetPosition(cocos2d::CCPoint position)
  {
    actor_adapter_->set_current_pos(position);
  }
  cocos2d::CCPoint ActorMotionData::GetPosition()
  {
    return actor_adapter_->current_pos();
  }

  bool ActorMotionData::IsPointInAnimation(cocos2d::CCPoint position)
  {
    return actor_adapter_->anima_node()->GetBoundingBox().containsPoint(position);
  }

  void ActorMotionData::SetMoveSpeedBase(float move_speed_base)
  {
    assert(false);  //currently should not set this value
  }

  float ActorMotionData::GetMoveSpeedBase()
  {
    return actor_adapter_->mover_speed_value();
  }


  taomee::SkeletonAnimation* ActorMotionData::GetAnimationNode()
  {
    return actor_adapter_->anima_node();
  }


  taomee::effect::SkeletonAnimationManager* ActorMotionData::GetAnimationManager()
  {
    return actor_adapter_->anima_manager();
  }

  void ActorMotionData::ResetAnimationDirection()
  {
    SetAnimationDirection(GetDefaultAnimationDirection());
  }

  void ActorMotionData::SetAnimationDirection(eActorAnimationDirection direction)
  {
    if (animation_direction_ == direction)
      return;

    if (direction == kActorAnimationDirectionRight)
      GetAnimationNode()->ChangeDirection(taomee::kDirectionRight);
    else if (direction == kActorAnimationDirectionLeft)
      GetAnimationNode()->ChangeDirection(taomee::kDirectionLeft);

    animation_direction_ = direction;
  }

  //ActorMotionData


} // namespace actor