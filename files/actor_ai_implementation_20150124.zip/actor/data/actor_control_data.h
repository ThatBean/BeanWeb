#ifndef ACTOR_CONTROL_DATA_H
#define ACTOR_CONTROL_DATA_H

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorTrigger;
  class ActorControlAutoData;



  const float ACTOR_CONTROL_COUNTDOWN = 0.5f; //control update interval, in second.


  enum eActorControlIncontrollableType  //the reason why the actor is incontrollable
  {
    kActorControlIncontrollableBuff,
    kActorControlIncontrollableSkill,
    kActorControlIncontrollableScript,
    kActorControlIncontrollableOther,
    kActorControlIncontrollable
  };


  //there will be 2 ActorControlData:
  //   user_control_data_ will buffer user control
  //   ActorControl will apply user_control_data_ change to control_data_
  //   control_data_ will be used in Logic update

  //#########################################################################################################
  //#########################################################################################################
  class ActorControlDataBase
  {
  public:
    ActorControlDataBase();
    ~ActorControlDataBase();
    
    virtual void    Reset();
    virtual bool    IsSet();
    virtual void    Update(float delta_time);


    void              SetPosition(cocos2d::CCPoint& position);
    cocos2d::CCPoint  GetPosition();
    bool              IsSetPosition() { return is_set_position_; }
    void              ResetPosition() { is_set_position_ = false; }
    
    void              SetTarget(int target_id);
    int               GetTarget();
    bool              IsSetTarget() { return is_set_target_; }
    void              ResetTarget() { is_set_target_ = false; }

    void              SetSkill(int skill_id);
    int               GetSkill();
    bool              IsSetSkill() { return is_set_skill_; }
    void              ResetSkill() { is_set_skill_ = false; }

    void              SetIncontrollable(eActorControlIncontrollableType incontrollable_type);
    eActorControlIncontrollableType GetIncontrollable();
    bool              IsSetIncontrollable() { return is_set_incontrollable_; }
    void              ResetIncontrollable() { is_set_incontrollable_ = false; }

    void              SetCountdown(float countdown) { countdown_ = countdown; }
    float             GetCountdown() { return countdown_; }
    void              UpdateCountdown(float delta_time) { countdown_ = (countdown_ <= delta_time ? 0 : countdown_ - delta_time); }
    void              ResetCountdown(float delta_time = ACTOR_CONTROL_COUNTDOWN) { countdown_ = delta_time; }

  private:    
    cocos2d::CCPoint  position_;
    int               target_id_;
    int               skill_id_;
    eActorControlIncontrollableType incontrollable_type_;

    bool              is_set_position_;
    bool              is_set_target_;
    bool              is_set_skill_;

    bool              is_set_incontrollable_;

    float             countdown_;
  };

  //#########################################################################################################
  //#########################################################################################################

  class ActorControlData : public ActorControlDataBase
  {
  public:
    ActorControlData();
    ~ActorControlData();

    void SetAttackTriggerAuto(ActorTrigger* trigger) { attack_trigger_auto_ = trigger; }
    ActorTrigger* GetAttackTriggerAuto() { return attack_trigger_auto_; }

    void SetGuardTriggerAuto(ActorTrigger* trigger) { guard_trigger_auto_ = trigger; }
    ActorTrigger* GetGuardTriggerAuto() { return guard_trigger_auto_; }

    ActorControlAutoData* GetActorControlAutoData();

  private:
    ActorTrigger*     attack_trigger_auto_; //target searching by auto range(maybe bigger), used in Auto Control, if true, auto attack
    ActorTrigger*     guard_trigger_auto_; //target searching by auto range(much bigger than guard), used in Auto Control, if true, auto move(approach)

    ActorControlAutoData*     actor_control_auto_data_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_DATA_H