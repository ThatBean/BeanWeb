#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorLogicdata
  ActorLogicData::ActorLogicData()
    :is_state_idle_(true),
    
    is_mute_move_(false),
    is_mute_attack_(false),
    is_immune_incontrollable_(false)
  {
    Init();
  }

  ActorLogicData::~ActorLogicData()
  {
  }

  void ActorLogicData::Init()
  {
  }


  //ActorLogicdata

} // namespace actor