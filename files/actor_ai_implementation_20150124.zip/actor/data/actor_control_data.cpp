#include "actor_data.h"

#include "game/actor/actor.h"
#include "control_data/actor_control_auto_data.h"

namespace actor {

  //ActorControlDataBase
  ActorControlDataBase::ActorControlDataBase()
  {
    Reset();
  }

  ActorControlDataBase::~ActorControlDataBase()
  {
  }

  void ActorControlDataBase::Reset()
  {
    is_set_position_ = false;
    is_set_skill_ = false;
    is_set_target_ = false;
    is_set_incontrollable_ = false;
    countdown_ = 0;
  }

  void ActorControlDataBase::Update(float delta_time)
  {
    UpdateCountdown(delta_time);
  }

  void ActorControlDataBase::SetPosition(cocos2d::CCPoint& position)
  {
    position_ = position;
    is_set_position_ = true;
  }

  void ActorControlDataBase::SetTarget(int target_id)
  {
    target_id_ = target_id;
    is_set_target_ = true;
  }
  void ActorControlDataBase::SetSkill(int skill_id)
  {
    skill_id_ = skill_id;
    is_set_skill_ = true;
  }

  void ActorControlDataBase::SetIncontrollable(eActorControlIncontrollableType incontrollable_type)
  {
    incontrollable_type_ = incontrollable_type;
    is_set_incontrollable_ = true;
  }


  cocos2d::CCPoint ActorControlDataBase::GetPosition()
  {
    assert(is_set_position_ == true);
    return position_;
  }


  int ActorControlDataBase::GetSkill()
  {
    if (is_set_skill_)
      return (skill_id_);
    else
      return -1;
  }

  int ActorControlDataBase::GetTarget()
  {
    if (is_set_target_)
      return (target_id_);
    else
      return -1;
  }

  eActorControlIncontrollableType ActorControlDataBase::GetIncontrollable()
  {
    if (is_set_incontrollable_)
      return (incontrollable_type_);
    else
      return kActorControlIncontrollable;
  }

  bool ActorControlDataBase::IsSet()
  {
    return (is_set_position_ 
      || is_set_skill_ 
      || is_set_target_
      || is_set_incontrollable_);
  }
  //ActorControlDataBase


  //ActorControlData
  ActorControlData::ActorControlData()
    :attack_trigger_auto_(NULL),
    guard_trigger_auto_(NULL)
  {
    Reset();
  }

  ActorControlData::~ActorControlData()
  {
    if (attack_trigger_auto_) delete attack_trigger_auto_;
    if (guard_trigger_auto_) delete guard_trigger_auto_;
  }

  ActorControlAutoData* ActorControlData::GetActorControlAutoData()
  {
    if (!actor_control_auto_data_)
      actor_control_auto_data_ = new ActorControlAutoData();

    return actor_control_auto_data_;
  }
  //ActorControlData

} // namespace actor