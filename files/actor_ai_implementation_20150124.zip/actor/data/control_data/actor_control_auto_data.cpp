#include "actor_control_auto_data.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

namespace actor {

  void ActorControlAutoData::Update(float delta_time)
  {
  }

} // namespace actor