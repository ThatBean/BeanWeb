#ifndef ACTOR_MOTION_STATE_BORN_H
#define ACTOR_MOTION_STATE_BORN_H

#include "game/actor/motion/actor_motion_state.h"


namespace actor {

  class MotionStateBorn : public MotionState
  {
  public:
    virtual ~MotionStateBorn() {}
    static MotionStateBorn* Instance();
    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);
    
    void CheckWeakStatus(Actor* actor);
  private:
    MotionStateBorn() {}
  };

} // namespace actor


#endif // ACTOR_MOTION_STATE_BORN_H
