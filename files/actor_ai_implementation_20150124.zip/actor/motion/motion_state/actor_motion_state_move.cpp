#include "actor_motion_state_move.h"

#include "game/actor/actor.h"

#include "game/actor/motion/actor_motion_animation_operation.h"

namespace actor {

  const int MotionStateMove::STATE_TYPE = kActorMotionStateMove;

  MotionStateMove* MotionStateMove::Instance()
  {
    static MotionStateMove instance;
    return &instance;
  }


  void MotionStateMove::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(false);
    ChangeAnimation(actor, taomee::army::kUnitAnimationWalk);
    CheckWeakStatus(actor);
  }

  void MotionStateMove::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);
  }

  void MotionStateMove::Update(Actor* actor, float delta_time)
  {
    CheckWeakStatus(actor);

    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    
    //if motion already finished, skip
    if (motion_data->GetIsMotionAnimationEnded())
      return;

    //update move
    cocos2d::CCPoint target_position;
    if (control_data->IsSetPosition())
    {  
      target_position = control_data->GetPosition();
    }
    else if (control_data->IsSetTarget())
    {
      Actor* target_actor = actor->GetActorExtEnv()->GetActorById(control_data->GetTarget());
      if (target_actor)
        target_position = target_actor->GetActorData()->GetMotionData()->GetPosition();
      else
      {
        assert(false);
        control_data->ResetTarget();
      }
    }
    else
    {
      control_data->ResetPosition();
      control_data->ResetTarget();
      motion_data->ResetIsCachedPosition();
      motion_data->SetIsMotionAnimationEnded(true); //lost target
    }

    UpdateMoveToPosition(actor, delta_time, target_position);
  }


  void MotionStateMove::UpdateMoveToPosition(Actor* actor, float delta_time, cocos2d::CCPoint target_position)
  {
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    ActorControlData* control_data = actor->GetActorData()->GetControlData();

    float move_distance = motion_data->GetPosition().getDistance(target_position);
    float move_speed_modifier = 1.0f;

    //Reached Position
    if (move_distance <= 0.01 || move_distance <= motion_data->GetMoveSpeedBase() * delta_time * move_speed_modifier)
    {
      SetAnimationPosition(actor, target_position, false);
      control_data->ResetPosition();
      control_data->ResetTarget();
      motion_data->ResetIsCachedPosition();
      motion_data->SetIsMotionAnimationEnded(true);
      return;
    }

    //The Move Move
    UpdateMoveToPositionCached(actor, target_position, delta_time, move_speed_modifier);
  }


  void MotionStateMove::CheckWeakStatus(Actor* actor)
  {
    if (actor->GetActorData()->GetBasicData()->GetIsWeakStatus() != actor->GetActorData()->GetMotionData()->GetIsWeakStatusAnimation())
    {
      if (actor->GetActorData()->GetBasicData()->GetIsWeakStatus())
        ChangeAnimation(actor, taomee::army::kUnitAnimationWeakWalk);
      else
        ChangeAnimation(actor, taomee::army::kUnitAnimationWalk);
    }
  }
} // namespace actor