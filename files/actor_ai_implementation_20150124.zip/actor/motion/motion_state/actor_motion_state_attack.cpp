#include "actor_motion_state_attack.h"

#include "game/actor/actor.h"

#include "game/actor/motion/actor_motion_animation_operation.h"

namespace actor {

  const int MotionStateAttack::STATE_TYPE = kActorMotionStateAttack;

  MotionStateAttack* MotionStateAttack::Instance()
  {
    static MotionStateAttack instance;
    return &instance;
  }

  void MotionStateAttack::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(false);

    //should assist skill system to adjust actor facing
    CheckEnemyForBetterDirection(actor);  //change actor facing, increase skill hit chance
  }

  void MotionStateAttack::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);
  }

  void MotionStateAttack::Update(Actor* actor, float delta_time)
  {
    ChangeAnimation(actor, taomee::army::kUnitAnimationIdle);

    //Give Motion control to Skill system
    if (actor->GetActorData()->GetSkillData()->GetIsSkillFinished())
    {
      //not matter skill is successful released or countered
      //back to idle
      actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);
    }
  }

} // namespace actor