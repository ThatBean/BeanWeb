#include "actor_motion_state_dead.h"

#include "game/actor/actor.h"

#include "game/actor/motion/actor_motion_animation_operation.h"

namespace actor {

  const int MotionStateDead::STATE_TYPE = kActorMotionStateDead;

  MotionStateDead* MotionStateDead::Instance()
  {
    static MotionStateDead instance;
    return &instance;
  }


  void MotionStateDead::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(false);
    ChangeAnimation(actor, taomee::army::kUnitAnimationDead, 1);

    //original dead motion+logic mixture
    /*
    const battle::eDeadReason dead_reason = unit->get_dead_reason();
    if ( dead_reason == battle::kDeadReason_Normal)
    {
      unit->ChangeAnimationToIndex(army::kUnitAnimationDead, 1);
    }
    else if ( dead_reason == battle::kDeadReason_Suicide)
    {
      unit->ChangeAnimationToIndex(army::kUnitAnimationDead_2, 1);
    }
    else if ( dead_reason == battle::kDeadReason_Disappear )
    {
      unit->ChangeAnimationToIndex(army::kUnitAnimationIdle, 1);
    }

    if ( !unit->is_temp_dead())
    {
      // hide shadow
      unit->anima_node()->FadeOutShadow();
      unit->HideHealthBar();
      unit->set_be_skill_hitmove_offset(0);
      unit->anima_node()->runAction(cocos2d::CCFadeOut::create(2.0f));
    }

    */
  }

  void MotionStateDead::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);

  }

  void MotionStateDead::Update(Actor* actor, float delta_time)
  {
  }

} // namespace actor