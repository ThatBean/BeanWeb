#ifndef ACTOR_STATE_MACHINE_H
#define ACTOR_STATE_MACHINE_H

#include "state.h"

namespace actor {
  template <class t_entity>
  class StateMachine
  {
  public:
    StateMachine(t_entity* entity) 
      :entity_(entity),
      current_state_(0),
      last_state_(0)
    {}

    virtual ~StateMachine() {}

  public:
    virtual void Update(float delta_time) { if (current_state_) current_state_->Update(entity_, delta_time); }

    virtual void ChangeState(State<t_entity>* next_state)
    {
      if (current_state_) current_state_->OnExit(entity_);
      last_state_ = current_state_;
      if (next_state) next_state->OnEnter(entity_);
      current_state_ = next_state;
    }

    virtual void SetCurrentState(State<t_entity>* current_state) { current_state_ = current_state; }
    virtual void SetLastState(State<t_entity>* last_state) { last_state_ = last_state; }
    
    virtual State<t_entity>* GetCurrentState() { return current_state_; }
    virtual State<t_entity>* GetLastState() { return last_state_; }

  protected:  
    t_entity*            entity_;
    State<t_entity>*     current_state_;
    State<t_entity>*     last_state_;
  };


} // namespace actor

#endif // ACTOR_STATE_MACHINE_H
