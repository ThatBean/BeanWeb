#ifndef ACTOR_EXT_USER_OPERATION_H
#define ACTOR_EXT_USER_OPERATION_H

#include "cocos2d.h"
#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  class ActorExtEnv;



  enum eActorExtUserOperationType
  {
    kActorExtUserOperationSelected, //only returned by update,  a state
    kActorExtUserOperationCanceled, //only returned by update, not a state
    kActorExtUserOperationFinished, //only returned by update, not a state

    kActorExtUserOperationSkip,     //keep last operation
    kActorExtUserOperationMove,     //move to operation_to_position_
    kActorExtUserOperationAttack,   //attack operation_to_actor_id_
    kActorExtUserOperationSwitch,   //operation_from_actor_id_ move to operation_to_position_, operation_to_actor_id_ move to operation_from_position_

    kActorExtUserOperation  //currently vacant
  };


  class ActorExtUserOperation
  {
  public:
    ActorExtUserOperation(ActorExtEnv* actor_ext_env);

    void Clear();

    eActorExtUserOperationType UpdateTouchStart(cocos2d::CCPoint touch_position);
    eActorExtUserOperationType UpdateTouchMove(cocos2d::CCPoint touch_position);
    eActorExtUserOperationType UpdateTouchEnd();

    bool                    IsTouchFromSet() { return is_operation_from_set_; }
    bool                    IsTouchToSet() { return is_operation_to_set_; }

    int                     GetTouchFromActorId() { assert(is_operation_from_set_); return operation_from_actor_id_; }
    int                     GetTouchToActorId() { assert(is_operation_to_set_); return operation_to_actor_id_; }
    cocos2d::CCPoint        GetTouchFromPosition() { assert(is_operation_from_set_); return operation_from_position_; }
    cocos2d::CCPoint        GetTouchToPosition() { assert(is_operation_to_set_); return operation_to_position_; }

  protected:
    void SetTouchFromData(int actor_id, cocos2d::CCPoint position);
    void SetTouchToData(int actor_id, cocos2d::CCPoint position);

    Actor* GetActorByPosition(cocos2d::CCPoint touch_position, bool is_check_manual_control);

  private:
    ActorExtEnv* actor_ext_env_;

    eActorExtUserOperationType operation_state_;

    //touch data from
    bool                    is_operation_from_set_;
    int                     operation_from_actor_id_; //the actor current touch operation start from
    cocos2d::CCPoint        operation_from_position_;

    //touch data to
    bool                    is_operation_to_set_;
    int                     operation_to_actor_id_;
    cocos2d::CCPoint        operation_to_position_;
  };


} // namespace actor


#endif // ACTOR_EXT_USER_OPERATION_H