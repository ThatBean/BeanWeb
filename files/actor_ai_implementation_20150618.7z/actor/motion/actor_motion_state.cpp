#include "actor_motion_state.h"

#include "motion_state/actor_motion_state_idle.h"
#include "motion_state/actor_motion_state_move.h"
#include "motion_state/actor_motion_state_attack.h"
#include "motion_state/actor_motion_state_incontrollable.h"
#include "motion_state/actor_motion_state_born.h"
#include "motion_state/actor_motion_state_dead.h"

namespace actor {

  const int MotionState::STATE_TYPE = kActorMotionState;


  MotionState* GetActorMotionState(eActorMotionState state_type)
  {
    switch(state_type)
    {
    case kActorMotionStateIdle:
      return MotionStateIdle::Instance();
      break;
    case kActorMotionStateMove:
      return MotionStateMove::Instance();
      break;
    case kActorMotionStateAttack:
      return MotionStateAttack::Instance();
      break;
    case kActorMotionStateIncontrollable:
      return MotionStateIncontrollable::Instance();
      break;
    case kActorMotionStateBorn:
      return MotionStateBorn::Instance();
      break;
    case kActorMotionStateDead:
      return MotionStateDead::Instance();
      break;
    case kActorMotionStateInvalid:
    default:
      return NULL;
      break;
    }
  }

} // namespace actor