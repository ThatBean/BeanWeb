#include "actor_motion_state_idle.h"

#include "game/actor/actor.h"

namespace actor {

  const int MotionStateIdle::STATE_TYPE = kActorMotionStateIdle;

  MotionStateIdle* MotionStateIdle::Instance()
  {
    static MotionStateIdle instance;
    return &instance;
  }


  void MotionStateIdle::OnEnter(Actor* actor)
  {
    actor->GetAnimation()->ChangeAnimation(taomee::army::kUnitAnimationIdle);
  }

  void MotionStateIdle::OnExit(Actor* actor)
  {

  }

  void MotionStateIdle::Update(Actor* actor, float delta_time)
  {

  }
} // namespace actor