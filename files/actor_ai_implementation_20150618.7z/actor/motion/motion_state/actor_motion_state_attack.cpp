#include "actor_motion_state_attack.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger.h"

namespace actor {

  const int MotionStateAttack::STATE_TYPE = kActorMotionStateAttack;

  MotionStateAttack* MotionStateAttack::Instance()
  {
    static MotionStateAttack instance;
    return &instance;
  }

  void MotionStateAttack::OnEnter(Actor* actor)
  {
    actor->GetActorData()->AddLog("[MotionStateAttack][OnEnter]");
    actor->GetActorData()->SetActorStatusBool(kActorMotionStatusIsBusy, true);
  }

  void MotionStateAttack::OnExit(Actor* actor)
  {
    actor->GetActorData()->AddLog("[MotionStateAttack][OnExit]");
    actor->GetActorData()->SetActorStatus(kActorSkillStatusCurrentSkillId, ACTOR_INVALID_ID);
    actor->GetActorData()->SetActorStatusBool(kActorMotionStatusIsBusy, false); //for Force Exit
  }

  void MotionStateAttack::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->AddLog("[MotionStateAttack][Update]");

    //Give Motion control to Skill system
    if (actor->GetActorData()->GetControlData()->IsSetSkill() == false
      || actor->GetActorData()->GetActorStatusBool(kActorMotionStatusIsBusy) == false)
    {
      actor->GetActorData()->SetActorStatus(kActorSkillStatusCurrentSkillId, ACTOR_INVALID_ID);
      actor->GetActorData()->SetActorStatusBool(kActorMotionStatusIsBusy, false);
      actor->GetActorData()->AddLogF("[MotionStateAttack][Idle] skill:%s motion_busy:%s skill_busy:%s",
        actor->GetActorData()->GetControlData()->IsSetSkill() ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorMotionStatusIsBusy) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorSkillStatusIsBusy) ? "true" : "false");
      return;
    }

    int skill_id = actor->GetActorData()->GetControlData()->GetSkill();
    int target_id = actor->GetActorData()->GetControlData()->IsSetTarget() ? actor->GetActorData()->GetControlData()->GetTarget() : ACTOR_INVALID_ID;

    //current skill normally finished
    if (actor->GetActorData()->GetActorStatus(kActorSkillStatusCurrentSkillId) == skill_id
      && actor->GetActorData()->GetActorStatusBool(kActorSkillStatusIsBusy) == false)
    {
      //finish current skill
      actor->GetActorData()->SetActorStatus(kActorSkillStatusCurrentSkillId, ACTOR_INVALID_ID);
      actor->GetActorData()->SetActorStatusBool(kActorMotionStatusIsBusy, false);
      actor->GetActorData()->AddLogF("[MotionStateAttack][SkillFinish] skill_id:%d", skill_id);

      if (actor->GetActorData()->GetSkillData()->GetSkillTypeById(skill_id) == kActorSkillSpecial)
        actor->GetActorData()->GetActorAttributeData(kActorAttributeEnergyCurrent)->Reset(); //unfreeze energy

      return;
    }


    if (skill_id != actor->GetActorData()->GetActorStatus(kActorSkillStatusCurrentSkillId))
    {
      //skill changed, reset skill
      actor->GetActorData()->AddLogF("[MotionStateAttack][SkillStart] skill_id:%d target_id:%d", skill_id, target_id);
      actor->GetActorData()->GetSkillData()->CommitSkill(skill_id, target_id);
      actor->GetActorData()->SetActorStatus(kActorSkillStatusCurrentSkillId, skill_id);

      if (actor->GetActorData()->GetSkillData()->GetSkillTypeById(skill_id) == kActorSkillSpecial) 
        actor->GetActorData()->SetActorAttribute(kActorAttributeEnergyCurrent, 0, 0); //freeze energy

      //check skill release successful
      assert(actor->GetActorData()->GetActorStatusBool(kActorSkillStatusIsBusy) == true);

      CheckEnemyForBetterDirection(actor);  //change actor facing, increase skill hit chance
      actor->GetActorData()->GetControlData()->ResetTarget();  //reset target after skill release
    }
  }





  //if all the enemy is behind the actor, change the direction.
  void MotionStateAttack::CheckEnemyForBetterDirection(Actor* actor)
  {
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    ActorSkillData* skill_data = actor->GetActorData()->GetSkillData();

    float actor_position_x = actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
    bool is_actor_facing_left = (actor->GetActorData()->GetActorStatus(kActorAnimationStatusDirection) == kActorAnimationDirectionLeft);
    bool is_need_change_direction = false;

    switch(skill_data->GetSkillTypeById(control_data->GetSkill()))
    {
    case kActorSkillNormal:
    case kActorSkillPower:
      {
        //check for normal attack, only check target
        if (control_data->IsSetTarget() && skill_data->GetAttackTrigger() && skill_data->GetAttackTrigger()->GetIsTriggered())
        {
          Actor* target_actor = actor->GetActorExtEnv()->GetActorById(control_data->GetTarget());
          if (target_actor && target_actor->GetIsActorAlive())
          {
            bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
            //if the enemy is in front of the actor, don't change the direction (0 | 1 | 0 = false)
            is_need_change_direction = !(is_actor_facing_left == is_enemy_at_left_side);
          }
        }
      }
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      {
        //check for special skill, need check all enemy
        std::list<Actor*>* actor_list = actor->GetActorExtEnv()->GetActorList();
        if (!actor_list || actor_list->size() == 0) return;

        is_need_change_direction = true;
        bool is_enemy_exist = false;

        int actor_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction);

        std::list<Actor*>::iterator iterator = actor_list->begin();
        while (iterator != actor_list->end())
        {
          Actor* target_actor = *iterator;

          if (target_actor->GetActorData()->GetActorStatus(kActorStatusFaction) != actor_faction)
          {
            bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
            //if there is one enemy in front of the actor, don't change the direction (1 & 0 & 1 = false)
            is_need_change_direction &= !(is_actor_facing_left == is_enemy_at_left_side);
            is_enemy_exist = true;
          }
          ++iterator;
        }

        //or no enemy at all
        is_need_change_direction &= is_enemy_exist;
      }
      break;
    case kActorSkill:
    default:
      assert(false);
      break;
    }

    if (is_need_change_direction)
    {
      actor->GetActorData()->AddLogF("[CheckEnemyForBetterDirection] change direction, is_change_to_right:%d", is_actor_facing_left);
      actor->GetActorData()->SetActorStatus(kActorAnimationStatusDirection, is_actor_facing_left ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);
    }
  }
} // namespace actor