#include "actor_buff.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorBuff
  ActorBuff::ActorBuff(Actor* actor)
    :actor_(actor)
  {
    
  }

  ActorBuff::~ActorBuff()
  {
    
  }

  void ActorBuff::Update(float delta_time)
  { 
    ActorBuffData* buff_data = actor_->GetActorData()->GetBuffData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    buff_data->UpdateIncontrollable();

    //check if incontrollable
    if (actor_->GetActorData()->GetActorStatusBool(kActorLogicStatusIsIncontrollable) == true)
      control_data->SetIncontrollable(kActorControlIncontrollableBuff, kActorControlPriorityIncontrollable);  //mute other operation with higher priority
    else
      control_data->ResetIncontrollable();
  }





  bool ActorBuff::AddBuff(int buff_id)
  {
    //from buff id should get
    int slot_key = 9999;
    eActorBuffResolveType resolve_type = kActorBuffResolve;

    std::string script_name_string = "";
    std::string arguments_string = "";


    //resolve
    if (buff_slot_map_.find(slot_key) != buff_slot_map_.end())
    {
      switch (buff_slot_map_[slot_key])
      {
      case kActorBuffResolveKeepOld:
        return false;
        break;
      case kActorBuffResolveKeepNone:
        // TODO: remove buff by slot key
        assert(false);
        return false;
        break;
      case kActorBuffResolveKeepNew:
        break;
      }
    }

    buff_slot_map_[slot_key] = resolve_type;

    //actor_->GetActorScriptExporter()->AddLuaBuff(script_name_string, arguments_string);

    return true;
  }



  cocos2d::CCPoint ActorBuff::GetBuffAnimationPosition(int position_type)
  {
    float actor_height = actor_->GetAnimation()->GetActorBox().size.height;

    switch (position_type)
    {
    case kActorBuffAnimationPositionTop:
      return ccp(0, actor_height + 50);
    case kActorBuffAnimationPositionMiddle:
      return ccp(0, actor_height * 0.5);
    case kActorBuffAnimationPositionBottom:
    default:
      return ccp(0, 0);
    }

    return ccp(0, 0);
  }


  //ActorBuff

} // namespace actor