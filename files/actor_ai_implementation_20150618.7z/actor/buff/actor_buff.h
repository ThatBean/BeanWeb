#ifndef ACTOR_BUFF_H
#define ACTOR_BUFF_H

#include "game/actor/actor_adapter.h"
#include "cocos2d.h"

namespace actor {

  class Actor;

  //also animation tag
  enum eActorBuffAnimationPositionType
  {
    kActorBuffAnimationPositionTop      = 7890001,
    kActorBuffAnimationPositionMiddle   = 7890002,
    kActorBuffAnimationPositionBottom   = 7890003,
    kActorBuffAnimationPosition
  };


  enum eActorBuffResolveType
  {
    kActorBuffResolveKeepOld = 1,
    kActorBuffResolveKeepNew,
    kActorBuffResolveKeepNone,
    kActorBuffResolve
  };


  //maintain buff interaction
  class ActorBuff
  {
  public:
    ActorBuff(Actor* actor_);
    ~ActorBuff();

    void Update(float delta_time);

    bool AddBuff(int buff_id);
    bool IsHasBuff(int buff_id);
    void RemoveBuff(int buff_id);

    void AddBuffAnimation(int buff_id);
    bool CheckBuffValid(int buff_id);

  protected:
    cocos2d::CCPoint GetBuffAnimationPosition(int position_type);

  private:
    Actor* actor_;

    std::map<int, eActorBuffResolveType> buff_slot_map_;  //for buff conflict
  };

} // namespace actor


#endif // ACTOR_BUFF_H