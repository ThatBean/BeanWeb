#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "game/actor/template_class/actor_signal_hub.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorControlData;

  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

  public:
    void Init();
    void Clear();

    void Update(float delta_time);

    //for data signal
    void OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);

    void OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data);

  //actor_based
  //actor_based
  public: 
    void ActorDataSignalConnect(int data_class_type, int actor_data_type);
    void ActorDataSignalDisconnect(int data_class_type, int actor_data_type);

    //direct access to ActorAttributeData
    bool  CheckActorAttribute(int actor_attribute_type);
    void  InitActorAttribute(int actor_attribute_type, float base = 0, float add = 0, float multiplier = 1, float extra = 0);
    void  SetActorAttribute(int actor_attribute_type, float add = 0, float multiplier = 1, float extra = 0);
    void  AddActorAttribute(int actor_attribute_type, float add = 0, float multiplier = 0, float extra = 0);
    float GetActorAttribute(int actor_attribute_type);

    //direct access to ActorStatusData
    bool  CheckActorStatus(int actor_status_type);
    void  InitActorStatus(int actor_status_type, int status);
    void  SetActorStatus(int actor_status_type, int status);
    int   GetActorStatus(int actor_status_type);
    void  InitActorStatusBool(int actor_status_type, bool bool_status);
    void  SetActorStatusBool(int actor_status_type, bool bool_status);
    bool  GetActorStatusBool(int actor_status_type);

    //direct access to ActorPositionData
    bool  CheckActorPosition(int actor_position_type);
    void  InitActorPosition(int actor_position_type, cocos2d::CCPoint position);
    void  SetActorPosition(int actor_position_type, cocos2d::CCPoint position);
    cocos2d::CCPoint&   GetActorPosition(int actor_position_type);


    ActorControlData* GetActorRoutineControlData();
    void SetActorIsAutoGuard(bool is_auto);
    void UpdateSpecialGuard(int type);
    void ShowActorLog(int max_line);
    void SetActorSkillCycleList(std::string& skill_cycle_string);

  private:
    Actor*  actor_;  //keep actor pointer
    float   cached_delta_time_;
    float   update_min_delta_time_;
    std::map<int, std::map<int, ActorSignalConnection > > lua_signal_connection_map_;



  //static method
  //static method
  public: //global
    static void SetIsAutoControl(bool is_auto_control) { is_auto_control_ = is_auto_control; }
    static bool GetIsAutoControl() { return is_auto_control_; }
  private:
    static bool is_auto_control_;

  public: //global
    static cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
    static cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
    static int GetGridXFromPositionX(float position_x);
    static int GetGridYFromPositionY(float position_y);

    static void ScriptAssert(bool expression, const std::string& message);


    //for debug
    //for debug

    //danger...
    //danger...
    static void SimulateTouchAt(float x, float y); 
    static void SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id);  //touch_event_id = 0, 1, 2, 3; safer to use CCTOUCHBEGAN etc
    static cocos2d::CCSet* GetTouchSet(float x, float y);  //this will get a modified static touch set in c++
    static bool TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node);

  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H