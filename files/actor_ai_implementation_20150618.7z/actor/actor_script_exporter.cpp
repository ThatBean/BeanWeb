#include "actor_script_exporter.h"

#include "game/actor/actor.h"
#include "game/actor/control/actor_control.h"
#include "engine/script/lua_tinker_manager.h"

#define SCRIPT_OBJECT_LUA "script/actor/script_object.lua"
#define ACTOR_SCRIPT_LUA "script/actor/actor_script.lua"
#define EFFECT_SCRIPT_LUA "script/actor/effect_script.lua"
#define DEFAULT_UPDATE_MIN_DELTA_TIME 0.1

namespace actor {

  bool ActorScriptExporter::is_auto_control_ = false;
  
  ActorScriptExporter::ActorScriptExporter(Actor* actor)
    :actor_(actor),
    cached_delta_time_(0),
    update_min_delta_time_(DEFAULT_UPDATE_MIN_DELTA_TIME)
  {
    //first update don't delay
    cached_delta_time_ = update_min_delta_time_;

    //init Lua ActorScript and RegisterScriptObjectUpgrader
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>(ACTOR_SCRIPT_LUA, "InitActorScript");
    LuaTinkerManager::GetInstance().CallLuaFunc<bool>(EFFECT_SCRIPT_LUA, "InitEffectScript");
  }

  ActorScriptExporter::~ActorScriptExporter()
  {
    Clear();
  }

  void ActorScriptExporter::Init()
  {
    //must wait for ActorScriptExporter constructor finish, or GetActorScriptExporter() will return NULL
    actor_->UpgradeScriptObject();
  }

  void ActorScriptExporter::Clear()
  {
    cached_delta_time_ = 0;
    lua_signal_connection_map_.clear();
  }


  void ActorScriptExporter::Update(float delta_time)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;

    cached_delta_time_ += delta_time;
    if (cached_delta_time_ >= update_min_delta_time_)  //Lua update will be less often
    {
      actor_->CallScriptObjectFunction("Update", cached_delta_time_);
      cached_delta_time_ = 0;
    }
  }


  void ActorScriptExporter::OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassAttribute, actor_data_type, actor_data);
  }
  void ActorScriptExporter::OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassStatus, actor_data_type, actor_data);
  }
  void ActorScriptExporter::OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassPosition, actor_data_type, actor_data);
  }


  void ActorScriptExporter::OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;

    printf("[ActorScriptExporter][OnDataOperation] id: %d | get op: %d, c: %d, d: %d\n", actor_->GetScriptObjectId(), operation_type, data_class_type, actor_data_type);

    if (lua_signal_connection_map_.find(data_class_type) != lua_signal_connection_map_.end()
      && lua_signal_connection_map_[data_class_type].find(actor_data_type) != lua_signal_connection_map_[data_class_type].end()
      )
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", 
        "EmitDataSignal", actor_->GetScriptObjectId(), operation_type, data_class_type, actor_data_type);
    }
  }

  // actor based
  void ActorScriptExporter::ActorDataSignalConnect(int data_class_type, int actor_data_type)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;
    ActorSignalConnection connection;
    if (data_class_type == kActorDataClassAttribute)
      connection = actor_->GetActorData()->GetActorAttributeData((eActorAttributeType)actor_data_type)->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnAttributeDataOperation);
    if (data_class_type == kActorDataClassStatus)
      connection = actor_->GetActorData()->GetActorStatusData((eActorStatusType)actor_data_type)->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnStatusDataOperation);
    if (data_class_type == kActorDataClassPosition)
      connection = actor_->GetActorData()->GetActorPositionData((eActorPositionType)actor_data_type)->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnPositionDataOperation);
    lua_signal_connection_map_[data_class_type][actor_data_type] = connection;
  }

  void ActorScriptExporter::ActorDataSignalDisconnect(int data_class_type, int actor_data_type)
  {
    if (actor_->GetScriptObjectId() == ACTOR_INVALID_ID) return;
    if (lua_signal_connection_map_.find(data_class_type) != lua_signal_connection_map_.end()
      && lua_signal_connection_map_[data_class_type].find(actor_data_type) != lua_signal_connection_map_[data_class_type].end())
    {
      if (data_class_type == kActorDataClassAttribute)
        actor_->GetActorData()->GetActorAttributeData((eActorAttributeType)actor_data_type)->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      if (data_class_type == kActorDataClassStatus)
        actor_->GetActorData()->GetActorStatusData((eActorStatusType)actor_data_type)->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      if (data_class_type == kActorDataClassPosition)
        actor_->GetActorData()->GetActorPositionData((eActorPositionType)actor_data_type)->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      lua_signal_connection_map_[data_class_type].erase(lua_signal_connection_map_[data_class_type].find(actor_data_type));
    }
  }

  //direct access to ActorAttributeData
  bool ActorScriptExporter::CheckActorAttribute(int actor_attribute_type)
  { return actor_->GetActorData()->CheckActorAttribute((eActorAttributeType)actor_attribute_type); }
  //normal access, with event
  void ActorScriptExporter::InitActorAttribute(int actor_attribute_type, float base/* = 0*/, float add/* = 0*/, float multiplier/* = 1*/, float extra/* = 0*/)
  { actor_->GetActorData()->InitActorAttribute((eActorAttributeType)actor_attribute_type, base, add, multiplier, extra); }
  void ActorScriptExporter::SetActorAttribute(int actor_attribute_type, float add/* = 0*/, float multiplier/* = 1*/, float extra/* = 0*/)
  { actor_->GetActorData()->SetActorAttribute((eActorAttributeType)actor_attribute_type, add, multiplier, extra); }
  void ActorScriptExporter::AddActorAttribute(int actor_attribute_type, float add/* = 0*/, float multiplier/* = 0*/, float extra/* = 0*/)
  { actor_->GetActorData()->AddActorAttribute((eActorAttributeType)actor_attribute_type, add, multiplier, extra); }
  float ActorScriptExporter::GetActorAttribute(int actor_attribute_type)
  { return actor_->GetActorData()->GetActorAttribute((eActorAttributeType)actor_attribute_type); }

  //direct access to ActorStatusData
  bool ActorScriptExporter::CheckActorStatus(int actor_status_type)
  { return actor_->GetActorData()->CheckActorStatus((eActorStatusType)actor_status_type); }
  //normal access, with event
  void ActorScriptExporter::InitActorStatus(int actor_status_type, int status)
  { actor_->GetActorData()->InitActorStatus((eActorStatusType)actor_status_type, status); }
  void ActorScriptExporter::SetActorStatus(int actor_status_type, int status)
  { actor_->GetActorData()->SetActorStatus((eActorStatusType)actor_status_type, status); }
  int ActorScriptExporter::GetActorStatus(int actor_status_type)
  { return actor_->GetActorData()->GetActorStatus((eActorStatusType)actor_status_type); }
  //normal access, with event
  void ActorScriptExporter::InitActorStatusBool(int actor_status_type, bool bool_status)
  { actor_->GetActorData()->InitActorStatusBool((eActorStatusType)actor_status_type, bool_status); }
  void ActorScriptExporter::SetActorStatusBool(int actor_status_type, bool bool_status)
  { actor_->GetActorData()->SetActorStatusBool((eActorStatusType)actor_status_type, bool_status); }
  bool ActorScriptExporter::GetActorStatusBool(int actor_status_type)
  { return actor_->GetActorData()->GetActorStatusBool((eActorStatusType)actor_status_type); }

  //direct access to ActorPositionData
  bool ActorScriptExporter::CheckActorPosition(int actor_position_type)
  { return actor_->GetActorData()->CheckActorPosition((eActorPositionType)actor_position_type); }
  void ActorScriptExporter::InitActorPosition(int actor_position_type, cocos2d::CCPoint position)
  { actor_->GetActorData()->InitActorPosition((eActorPositionType)actor_position_type, position); }
  void ActorScriptExporter::SetActorPosition(int actor_position_type, cocos2d::CCPoint position)
  { actor_->GetActorData()->SetActorPosition((eActorPositionType)actor_position_type, position); }
  cocos2d::CCPoint& ActorScriptExporter::GetActorPosition(int actor_position_type)
  { return actor_->GetActorData()->GetActorPosition((eActorPositionType)actor_position_type); }



  ActorControlData* ActorScriptExporter::GetActorRoutineControlData()
  {
    assert(actor_);
    return actor_->GetActorData()->GetRoutineControlData();
  }

  void ActorScriptExporter::SetActorIsAutoGuard(bool is_auto)
  {
    assert(actor_);
    if (is_auto == true) actor_->GetActorData()->GetActorStatusData(kActorControlStatusAutoGuardType)->Reset();
    else actor_->GetActorData()->SetActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardInvalid);
  }

  void ActorScriptExporter::UpdateSpecialGuard(int type)
  {
    assert(actor_);
    actor_->GetControl()->UpdateSpecialGuard(type);
  }

  void ActorScriptExporter::ShowActorLog(int max_line)
  {
    assert(actor_);
    actor_->GetActorData()->ShowLog(max_line);
  }

  void ActorScriptExporter::SetActorSkillCycleList(std::string& skill_cycle_string)
  {
    assert(actor_);
    actor_->GetActorData()->GetSkillData()->SetSkillCycleList(skill_cycle_string);
  }










  //export to lua // common static
  cocos2d::CCPoint ActorScriptExporter::GetPositionFromGrid(int grid_x, int grid_y)
  {
    return actor::GetPositionFromGrid(grid_x, grid_y);
  }
  cocos2d::CCPoint ActorScriptExporter::GetGridFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridFromPosition(position);
  }
  int ActorScriptExporter::GetGridXFromPositionX(float position_x)
  {
    return actor::GetGridXFromPositionX(position_x);
  }
  int ActorScriptExporter::GetGridYFromPositionY(float position_y)
  {
    return actor::GetGridYFromPositionY(position_y);
  }


  //for debug
  void ActorScriptExporter::ScriptAssert(bool expression, const std::string& message)
  {
    printf("[ActorScriptExporter][Assert] <%s> %s\n", expression ? "True" : "False", message.c_str());
    assert(expression);
  }


  //for debug
  void ActorScriptExporter::SimulateTouchAt(float x, float y)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);
    cocos2d::CCSet* touch_set = new cocos2d::CCSet;
    touch_set->addObject(touch);
    printf("[ActorScriptExporter][SimulateTouchAt] x:%f, y:%f\n", x, y);
    SimulateTouch(touch_set, CCTOUCHBEGAN);
    SimulateTouch(touch_set, CCTOUCHENDED);
    //delete touch;
    delete touch_set;
#endif
  }

  void ActorScriptExporter::SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    switch (touch_event_id)
    {
    case CCTOUCHBEGAN:
    case CCTOUCHMOVED:
    case CCTOUCHENDED:
    case CCTOUCHCANCELLED:
      CCDirector::sharedDirector()->getTouchDispatcher()->touches(touch_set, NULL, touch_event_id);
      break;
    default:
      assert(false); //touch_event_id error
      break;
    }
#endif
  }

  static CCSet* _touch_set = NULL;
  cocos2d::CCSet* ActorScriptExporter::GetTouchSet(float x, float y)
  {
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);
    if (_touch_set) delete _touch_set;
    _touch_set = new cocos2d::CCSet;
    _touch_set->addObject(touch);
    return _touch_set;
  }

  const static char* __DefaultSkeletonFilePath = "textures/skeleton/";
  bool ActorScriptExporter::TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node)
  {
    std::string skeleton_config = __DefaultSkeletonFilePath + animation_name + ".xml";
    std::string skeleton_plist = __DefaultSkeletonFilePath + animation_name + ".plist";
    std::string skeleton_texture = __DefaultSkeletonFilePath + animation_name + ".pvr.ccz";
    CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
    CCArmature* armature = CCArmature::create(animation_name.c_str());
    upper_node->addChild(armature);
    armature->getAnimation()->play("bsj", 0, -1, 0);
    return true;
  }


} // namespace actor