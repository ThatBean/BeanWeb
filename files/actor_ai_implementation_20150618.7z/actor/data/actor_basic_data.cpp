#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {
  ActorBasicData::ActorBasicData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }


  void ActorBasicData::Update(float delta_time)
  { 
    actor_data_->AddActorAttribute(kActorAttributeTimeActive, delta_time);
  }

  void ActorBasicData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorAttributeData(kActorAttributeHealthCurrent)->Connect<ActorBasicData>(this, &ActorBasicData::OnAttributeDataOperation);
    actor_data_->GetActorAttributeData(kActorAttributeHealthMax)->Connect<ActorBasicData>(this, &ActorBasicData::OnAttributeDataOperation);

    actor_data_->GetActorAttributeData(kActorAttributeEnergyCurrent)->Connect<ActorBasicData>(this, &ActorBasicData::OnAttributeDataOperation);
    actor_data_->GetActorAttributeData(kActorAttributeEnergyMax)->Connect<ActorBasicData>(this, &ActorBasicData::OnAttributeDataOperation);
  }

  void ActorBasicData::OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassAttribute, actor_data_type, actor_data);
  }

  void ActorBasicData::OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassStatus, actor_data_type, actor_data);
  }

  void ActorBasicData::OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data)
  {
    switch (actor_data_type)
    {
    case kActorAttributeHealthCurrent:
    case kActorAttributeHealthMax:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            //limit value under max value
            float value_current = actor_data_->GetActorAttribute(kActorAttributeHealthCurrent);
            float value_max = actor_data_->GetActorAttribute(kActorAttributeHealthMax);

            if (value_current > value_max) actor_data_->SetActorAttribute(kActorAttributeHealthCurrent, value_max);
            if (value_current < 0) actor_data_->SetActorAttribute(kActorAttributeHealthCurrent, 0);

            actor_data_->SetActorStatusBool(kActorAnimationStatusIsHealthChanged, true);
          }
          break;
        }
      }
      break;
    case kActorAttributeEnergyCurrent:
    case kActorAttributeEnergyMax:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            //limit value under max value
            float value_current = actor_data_->GetActorAttribute(kActorAttributeEnergyCurrent);
            float value_max = actor_data_->GetActorAttribute(kActorAttributeEnergyMax);

            if (value_current > value_max) actor_data_->SetActorAttribute(kActorAttributeEnergyCurrent, value_max);
            if (value_current < 0) actor_data_->SetActorAttribute(kActorAttributeEnergyCurrent, 0);
          }
          break;
        }
      }
      break;
    }
  }


  //ActorBasicData

  void ActorBasicData::ActorDeadCleanUp()
  {
    NastyActorDeadCleanUpAdapter(actor_adapter_);
  }

  const std::string ActorBasicData::DeadAnimationName()
  {
    return GetDeadAnimationName(actor_adapter_);
  }
  //ActorBasicData

} // namespace actor