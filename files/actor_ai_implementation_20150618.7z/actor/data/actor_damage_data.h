#ifndef ACTOR_DAMAGE_DATA_H
#define ACTOR_DAMAGE_DATA_H

#include "game/actor/template_class/actor_data_class.h"

namespace actor {

  class Actor;
  class ActorData;
  class DamagePackage;

  typedef ActorTemplateAttributeData<DamagePackage> DamageAttributeData;
  typedef ActorTemplateStatusData<DamagePackage> DamageStatusData;

  class DamagePackage {
  public:
    DamagePackage();
    ~DamagePackage();

    //new damage process
    //actor -> skill -> buff -> [final damage result] -> buff -> actor -> health change(mostly) & damage label

  public:
    //basic method
    void InitDamage();
    void AddDamage(
      eActorDamageAttributeType   damage_type,
      float   damage_add = 0,
      float   damage_multiplier = 1,
      float   damage_extra = 0
      );
    float GetDamage(unsigned long damage_type_filter); //get result total damage


    std::map<eActorDamageAttributeType, DamageAttributeData>* GetActorDamageAttributeMap() { return &damage_attribute_map_; }
    bool CheckActorDamageAttribute(eActorDamageAttributeType actor_damage_attribute_type) { return (damage_attribute_map_.find(actor_damage_attribute_type) != damage_attribute_map_.end()); }
    //get data to connect event
    DamageAttributeData* GetActorDamageAttributeData(eActorDamageAttributeType actor_damage_attribute_type) { return &(damage_attribute_map_[actor_damage_attribute_type]); }
    //normal access, with event
    void  InitActorDamageAttribute(eActorDamageAttributeType actor_damage_attribute_type, float base = 0, float add = 0, float multiplier = 1, float extra = 0) 
    { 
      damage_attribute_map_[actor_damage_attribute_type].Link(actor_damage_attribute_type, this);
      damage_attribute_map_[actor_damage_attribute_type].Init(base, add, multiplier, extra); 
    }
    void  SetActorDamageAttribute(eActorDamageAttributeType actor_damage_attribute_type, float add = 0, float multiplier = 1, float extra = 0) { damage_attribute_map_[actor_damage_attribute_type].Set(add, multiplier, extra); }
    void  AddActorDamageAttribute(eActorDamageAttributeType actor_damage_attribute_type, float add = 0, float multiplier = 0, float extra = 0) { damage_attribute_map_[actor_damage_attribute_type].Add(add, multiplier, extra); }
    float GetActorDamageAttribute(eActorDamageAttributeType actor_damage_attribute_type) { return damage_attribute_map_[actor_damage_attribute_type].Get(); }



    std::map<eActorDamageStatusType, DamageStatusData>* GetActorDamageStatusMap() { return &damage_status_map_; }
    bool CheckActorDamageStatus(eActorDamageStatusType actor_damage_status_type) { return (damage_status_map_.find(actor_damage_status_type) != damage_status_map_.end()); }
    //get data to connect event
    DamageStatusData* GetActorDamageStatusData(eActorDamageStatusType actor_damage_status_type) { return &(damage_status_map_[actor_damage_status_type]); }
    //normal access, with event
    void  InitActorDamageStatus(eActorDamageStatusType actor_damage_status_type, int status) 
    { 
      damage_status_map_[actor_damage_status_type].Link(actor_damage_status_type, this);
      damage_status_map_[actor_damage_status_type].Init(status); 
    }
    void  SetActorDamageStatus(eActorDamageStatusType actor_damage_status_type, int status) { damage_status_map_[actor_damage_status_type].Set(status); }
    int   GetActorDamageStatus(eActorDamageStatusType actor_damage_status_type) { return damage_status_map_[actor_damage_status_type].Get(); }
    //normal access, with event
    void  InitActorDamageStatusBool(eActorDamageStatusType actor_damage_status_type, bool bool_status) 
    { 
      damage_status_map_[actor_damage_status_type].Link(actor_damage_status_type, this);
      damage_status_map_[actor_damage_status_type].InitBool(bool_status); 
    }
    void  SetActorDamageStatusBool(eActorDamageStatusType actor_damage_status_type, bool bool_status) { damage_status_map_[actor_damage_status_type].SetBool(bool_status); }
    bool  GetActorDamageStatusBool(eActorDamageStatusType actor_damage_status_type) { return damage_status_map_[actor_damage_status_type].GetBool(); }


  private:
    //typed damage data list
    std::map<eActorDamageAttributeType, DamageAttributeData> damage_attribute_map_;  //each type of damage data
    std::map<eActorDamageStatusType, DamageStatusData> damage_status_map_;  //each type of damage data
  };













  class ActorDamageData
  {
  public:
    ActorDamageData(ActorData* actor_data);
    ~ActorDamageData();

    DamagePackage* CreateActorDamage(); //
    void ReceiveActorDamage(DamagePackage* damage_package); //

    //as skill releaser
    // [Process] actor -> skill -> buff -> final damage result
    void AddActorBasicDamage(DamagePackage* damage_package); //actor status
    void AddActorSkillDamage(DamagePackage* damage_package, int skill_id);  //skill
    void AddActorBuffDamage(DamagePackage* damage_package, int buff_id); //buff


    //as damage holder
    // [Process] final damage result -> buff -> actor -> health change(mostly) & damage label
    void ReduceActorBuffDamage(DamagePackage* damage_package, int buff_id);
    void ReduceActorBasicDamage(DamagePackage* damage_package);


  private:
    ActorData*    actor_data_;
    //add more below
    //add more below
    //add more below
  };
} // namespace actor


#endif // ACTOR_DAMAGE_DATA_H