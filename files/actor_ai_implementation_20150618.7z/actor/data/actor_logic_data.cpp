#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorLogicdata
  ActorLogicData::ActorLogicData(ActorData* actor_data)
    :actor_data_(actor_data)
  {
    Init();
  }

  ActorLogicData::~ActorLogicData()
  {
  }

  void ActorLogicData::Init()
  {
  }


  //ActorLogicdata

} // namespace actor