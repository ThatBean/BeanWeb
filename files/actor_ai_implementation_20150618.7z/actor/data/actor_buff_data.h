#ifndef ACTOR_BUFF_DATA_H
#define ACTOR_BUFF_DATA_H

#include "actor_data_typedef.h"

namespace actor {

  class Actor;
  class ActorData;
  class DamagePackage;


  class ActorBuffData
  {
  public:
    ActorBuffData(ActorData* actor_data);
    ~ActorBuffData();

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data);

    //not in use
    void ProcessAddDamage(DamagePackage* damage_package, int buff_id);
    void ProcessReduceDamage(DamagePackage* damage_package, int buff_id);

    //currently in adapter
    void UpdateIncontrollable();

    //messy but messy, link MoveObject data
    void SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }
  
  private:
    ActorData*    actor_data_;

    //buff_id_list  //currently active buff
    
    //script buff
    //



  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*       actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_BUFF_DATA_H