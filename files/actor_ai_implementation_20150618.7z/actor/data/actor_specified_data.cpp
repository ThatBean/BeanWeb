#include "actor_data.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {

  ActorSpecifiedData::ActorSpecifiedData(Actor* actor)
    :actor_(actor)
  {

  }


  void ActorSpecifiedData::Update(float delta_time)
  {
    if (actor_->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserOppose)
    {
      cocos2d::CCPoint grid_position = GetGridFromPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));

      // TODO: need move? | show enemy warning
      if (grid_position.x >= (GRID_X_RANGE_RIGHT_MIDDLE - 1))
        LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/WarningUI.lua", "AutoExtendWarningUIToBattleScene");

      // TODO: need move? | reduce enemy's speed
      if (grid_position.x >= GRID_X_RANGE_RIGHT_MIDDLE)
      {
        ActorAttributeData* speed_attribute = actor_->GetActorData()->GetActorAttributeData(kActorAttributeSpeedMove);
        speed_attribute->Set(speed_attribute->GetAdd(), 0.5);
      }

      if (grid_position.x > GRID_X_RANGE_RIGHT)
        AlertEnemyPassRightBorder(actor_->GetScriptObjectId());
    }
  }


  bool ActorSpecifiedData::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionInGrid(position);
  }

  bool ActorSpecifiedData::IsGridValid(cocos2d::CCPoint grid_position)
  {
    return grid_position.x >= GRID_X_RANGE_LEFT
      && grid_position.x <= GRID_X_RANGE_RIGHT
      && grid_position.y >= GRID_Y_RANGE_TOP
      && grid_position.y <= GRID_Y_RANGE_BOTTOM;
  }


  cocos2d::CCPoint ActorSpecifiedData::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
      return SnapToGrid(position);
    else
      return SnapYToGrid(position);
  }

  bool ActorSpecifiedData::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);  //for enemy pawn / boss
  }


  std::list<cocos2d::CCPoint>* ActorSpecifiedData::GetValidGridList(std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list)  //need delete after use
  {
    //record grid taken status
    int grid_position_taken[GRID_X_RANGE][GRID_Y_RANGE] = {0};
    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list->begin();
    while (iterator != actor_grid_list->end())
    {
      Actor* ref_actor = iterator->first;

      if (ref_actor != actor_ && ref_actor->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection))
      {
        cocos2d::CCPoint ref_grid_position = iterator->second;
        grid_position_taken[(int)(ref_grid_position.x - 1)][(int)(ref_grid_position.y - 1)] += 1;
      }

      ++iterator;
    }

    //search and check valid grid
    std::list<cocos2d::CCPoint>* valid_grid_list = new std::list<cocos2d::CCPoint>;
    int i, j;
    for (i = GRID_X_RANGE_LEFT; i <= GRID_X_RANGE_RIGHT; i++) {
      for (j = GRID_Y_RANGE_TOP; j <= GRID_Y_RANGE_BOTTOM; j++) {
        cocos2d::CCPoint grid_position = ccp(i, j);
        if (grid_position_taken[i - 1][j - 1] == 0 && IsGridIdleValid(grid_position)) valid_grid_list->push_back(grid_position);
      }
    }

    return valid_grid_list;
  }

  cocos2d::CCPoint ActorSpecifiedData::GetValidGrid(
    cocos2d::CCPoint preferred_grid_position, 
    std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list)
  {
    if (IsGridIdleValid(preferred_grid_position) == false)
    {
      float preferred_grid_x = actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT_MIDDLE : GRID_X_RANGE_RIGHT_MIDDLE;
      preferred_grid_position = ccp(preferred_grid_x, GRID_Y_RANGE_MIDDLE);
    }

    std::list<cocos2d::CCPoint>* valid_grid_list = GetValidGridList(actor_grid_list);
    
    bool is_backup_grid_position_valid = false;
    cocos2d::CCPoint backup_grid_position;
    float nearest_valid_grid_distance = 99999;

    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;

        if (IsGridIdleValid(grid_position))
        {
          is_backup_grid_position_valid = true;
          float distance = preferred_grid_position.getDistance(grid_position);

          if (distance < nearest_valid_grid_distance)
          {
            nearest_valid_grid_distance = distance;
            backup_grid_position = grid_position;
            if (distance == 0) break;  //find nearest, stop searching
          }
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    if (is_backup_grid_position_valid)
    {
      actor_grid_list->push_back(std::pair<Actor*, cocos2d::CCPoint>(actor_, backup_grid_position));  //prevent another actor move to 
      return backup_grid_position;
    }
    else
    {
      //so sad the lame makeshift position
      return preferred_grid_position;
    }
  }

  cocos2d::CCPoint ActorSpecifiedData::GetValidGrid()
  {
    return GetValidGrid(
      actor_->GetActorData()->GetActorPosition(kActorSpecifiedPositionLastIdleGrid), 
      actor_->GetActorExtEnv()->GetActorExtGrid()->GetActorGridList());
  }
  //ActorSpecifiedDataCharacter================================================================
  ActorSpecifiedDataCharacter::ActorSpecifiedDataCharacter(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataCharacter::IsPositionValid(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
    {
      cocos2d::CCPoint grid_position = GetGridFromPosition(position);
      if (actor_->GetActorData()->GetActorStatusBool(kActorSpecifiedStatusIsLimitGridX) && ((int)(grid_position.x) == 1))
        return (position.x > (GetPositionFromGrid(grid_position).x + 10));
      else
        return true;
    }
    else
      return false;
  }

  bool ActorSpecifiedDataCharacter::IsGridValid(cocos2d::CCPoint grid_position)
  {
    bool is_valid = ActorSpecifiedData::IsGridValid(grid_position);
    
    if (is_valid && actor_->GetActorData()->GetActorStatusBool(kActorSpecifiedStatusIsLimitGridX))
    {
      switch (actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection))
      {
      case kActorAnimationDirectionLeft:
        is_valid = grid_position.x <= PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT;
        break;
      case  kActorAnimationDirectionRight:
        is_valid = grid_position.x >= PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT;
        break;
      default:
        assert(false);
        is_valid = true;
        break;
      }
    }

    return is_valid;
  }

  bool ActorSpecifiedDataCharacter::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);  //not different from Valid
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
    {
      if (IsPositionValid(position))
        return SnapToGrid(position);
      else
      {
        cocos2d::CCPoint grid_position = GetGridFromPosition(position);

        if (actor_->GetActorData()->GetActorStatusBool(kActorSpecifiedStatusIsLimitGridX) && ((int)(grid_position.x) == 1))
          grid_position.x = 2;  // TODO: strange logic
        
        return GetPositionFromGrid(grid_position);
      }
    }
    else
      return SnapYToGrid(position);
  }


  //ActorSpecifiedDataCharacter================================================================

  //ActorSpecifiedDataEnemyPawn================================================================
  ActorSpecifiedDataEnemyPawn::ActorSpecifiedDataEnemyPawn(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyPawn::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionYInGrid(position);
  }
  //ActorSpecifiedDataEnemyPawn================================================================

  //ActorSpecifiedDataEnemyBoss================================================================
  ActorSpecifiedDataEnemyBoss::ActorSpecifiedDataEnemyBoss(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyBoss::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionYInGrid(position);
  }
  //ActorSpecifiedDataEnemyBoss================================================================
} // namespace actor