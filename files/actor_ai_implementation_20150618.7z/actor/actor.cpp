#include "actor.h"

#include "actor_script_exporter.h"

#include "control/actor_control.h"
#include "logic/actor_logic_state_machine.h"
#include "motion/actor_motion_state_machine.h"

#include "engine/base/basictypes.h"
//#include "engine/script/lua_tinker_manager.h"

namespace actor {

  Actor::Actor()
    :actor_model_type_(kActorModel),
    is_actor_active_(false),
    is_actor_pause_(false),
    actor_ext_env_(NULL),

    actor_data_(NULL),
    actor_control_(NULL),
    logic_state_machine_(NULL),
    motion_state_machine_(NULL),
    actor_buff_(NULL),
    actor_animation_(NULL),
    actor_script_exporter_(NULL)
  {
    //Init();
  }

  Actor::~Actor()
  {
    if (actor_data_) delete actor_data_;
    if (actor_control_) delete actor_control_;
    if (logic_state_machine_) delete logic_state_machine_;
    if (motion_state_machine_)  delete motion_state_machine_;
    if (actor_buff_)  delete actor_buff_;
    if (actor_animation_)  delete actor_animation_;
    if (actor_script_exporter_) delete actor_script_exporter_;

    //the actor_ext_env_ will manage actor delete
    //first actor_ext_env_ will UnLinkScript
    //so if the actor_ext_env_ is not NULL, the remove process is incorrect
    assert(actor_ext_env_ == NULL);
  }

  void Actor::Init(eActorModelType actor_model_type/* = kActorModelActor*/)
  {
    switch (actor_model_type)
    {
    case kActorModelActor:
      SetScriptObjectType("ActorScript");
      break; 
    case kActorModelEffect:
      SetScriptObjectType("EffectScript");
      break;
    case kActorModelData:
      SetScriptObjectType("DataScript");
      break;
    default:
      assert(false);
      return;
      break;
    }

    actor_model_type_ = actor_model_type;

    if (actor_model_type & kActorModuleScript) {
      actor_script_exporter_ = new ActorScriptExporter(this);
      actor_script_exporter_->Init();
    }

    if (actor_model_type & kActorModuleData) {
      actor_data_ = new ActorData(this);
      actor_data_->Init(actor_model_type);
    }
    if (actor_model_type & kActorModuleControl) actor_control_ = new ActorControl(this);

    if (actor_model_type & kActorModuleLogic) logic_state_machine_ = new LogicStateMachine(this);
    if (actor_model_type & kActorModuleMotion) motion_state_machine_ = new MotionStateMachine(this);

    if (actor_model_type & kActorModuleBuff) actor_buff_ = new ActorBuff(this);

    if (actor_model_type & kActorModuleAnimation) actor_animation_ = new ActorAnimation(this);

    assert(actor_data_);  //at least have actor_data_
  }


  void Actor::LinkScript(int actor_id, ActorExtEnv* actor_ext_env)
  { 
    assert(actor_id != ACTOR_INVALID_ID);

    ScriptObject::LinkScript(actor_id, actor_ext_env);

    actor_ext_env_ = actor_ext_env; 

//     if (GetScriptObjectId() < 100000) 
//     {
//       Actor* test_effect = actor_ext_env_->CreateActor(100000 + GetScriptObjectId());
//       test_effect->Init(kActorModelEffect);
// 
//       Actor* test_data = actor_ext_env_->CreateActor(200000 + GetScriptObjectId());
//       test_data->Init(kActorModelData);
//     }
  }

  void Actor::UnLinkScript()
  {
//     if (GetScriptObjectId() < 100000 && actor_ext_env_) 
//     {
//       actor_ext_env_->RemoveActor(100000 + GetScriptObjectId());
//       actor_ext_env_->RemoveActor(200000 + GetScriptObjectId());
//     }

    ScriptObject::UnLinkScript();

    actor_ext_env_ = NULL;
  }


  void Actor::Update(float delta_time)
  {
    //for Debug quick watch
    Actor* debug_actor = this;
    ActorData* debug_actor_data = actor_data_;
    
    //actor_data_->AddLog("[Actor][Update] ----------");

    if (actor_data_) actor_data_->Update(delta_time); //update mostly timers in ActorData
    if (actor_script_exporter_) actor_script_exporter_->Update(delta_time); //let Lua change something
    if (actor_control_) actor_control_->Update(delta_time); //deal with user control and auto
    if (actor_buff_) actor_buff_->Update(delta_time); //update actor-side buff data&logic

    //actor_skill_->Update(delta_time); //update actor-side skill data&logic

    if (is_actor_pause_ == false)
    {
      if (logic_state_machine_) logic_state_machine_->Update(delta_time); //Manage Both Logic State & Motion State 
      if (motion_state_machine_) motion_state_machine_->Update(delta_time); //Manage Position and Animation
    }

    if (actor_animation_) actor_animation_->Update(delta_time); //update animation
  }



  void Actor::SetIsActorPause(bool is_actor_pause) 
  { 
    if (is_actor_pause_ == is_actor_pause) return;
    
    actor_data_->AddLogF("[Actor][SetIsActorPause] is_actor_pause:%d", is_actor_pause);
    actor_data_->GetActorStatusData(kActorAnimationStatusIsPaused)->Stack(is_actor_pause);
    actor_data_->GetActorStatusData(kActorSkillStatusIsPaused)->Stack(is_actor_pause);

    is_actor_pause_ = is_actor_pause; 
  }

  bool Actor::GetIsActorAlive()
  {
    return is_actor_active_ && actor_data_->GetActorAttribute(kActorAttributeHealthCurrent) > 0;
  }
} // namespace actor