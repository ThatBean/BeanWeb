#ifndef ACTOR_TRIGGER_MODULE_H
#define ACTOR_TRIGGER_MODULE_H


#include "engine/base/basictypes.h"


namespace actor 
{
  
  class Actor;

  enum eActorTriggerModule
  {
    kActorTriggerModuleActorData,
    kActorTriggerModuleFaction,
    kActorTriggerModuleGeometry,
    kActorTriggerModuleStatus,
    kActorTriggerModuleScript,  //lua
    kActorTriggerModuleActive,  //will cause target status change, maybe a bad idea
    kActorTriggerModuleSort,  //
    kActorTriggerModule
  };

  

  class  ActorTriggerModuleData
  {
  public:
    static const uint_32 TARGET_MODULE_TYPE;
    ActorTriggerModuleData()
      :trigger_flag_(0)
    {}
    virtual ~ActorTriggerModuleData() {}

    void      SetTriggerFlag(uint_32 trigger_flag) { trigger_flag_ = trigger_flag; }
    void      AddTriggerFlag(uint_32 trigger_flag) { trigger_flag_ |= trigger_flag; }
    uint_32   GetTriggerFlag() { return trigger_flag_; }

  private:
    uint_32 trigger_flag_; 
  };



  class ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  public:
    ActorTriggerModule() {}
    ~ActorTriggerModule() {}

    virtual bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data, std::list<Actor*>* actor_list) = 0;

    eActorTriggerModule   GetTriggerModuleType() { return trigger_module_type_; }

  private:
    static const eActorTriggerModule trigger_module_type_;
    
  };
  
  ActorTriggerModule* GetActorTriggerModule(eActorTriggerModule module_type);
  ActorTriggerModuleData* GetActorTriggerModuleData(eActorTriggerModule module_type, uint_32 trigger_flag = 0);

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_H