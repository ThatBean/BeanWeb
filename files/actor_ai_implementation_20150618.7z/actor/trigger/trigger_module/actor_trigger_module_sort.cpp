#include "actor_trigger_module_sort.h"

#include "game/actor/actor.h"

namespace actor 
{
  //template for actor sort
  template<class Comparable>
  class ActorListSort
  {
  public:
    //typedef pair<Comparable, Actor*> SortPair;

  public:
    ActorListSort(Actor* actor)
    {
      sort_list_ = new std::vector< std::pair<Comparable, Actor*> >;
      actor_ = actor;
    }
    ~ActorListSort()
    {
      if (sort_list_) 
      {
        sort_list_->clear();
        delete sort_list_;
      }
    }

    virtual Comparable GetActorData(Actor* ref_actor) = 0;
    Actor* GetActor() { return actor_; };

    static bool Compare(std::pair<Comparable, Actor*> p1, std::pair<Comparable, Actor*> p2) { return p1.first < p2.first; }

    void SortActorList(std::list<Actor*>* actor_list)
    {
      CreateSortList(actor_list);
      SortList();
      //apply result back to actor_list
      ApplyResultToActorList(actor_list);
    }

  private:
    void CreateSortList(std::list<Actor*>* actor_list)
    {
      sort_list_->clear();
      std::list<Actor*>::iterator iterator = actor_list->begin();
      while (iterator != actor_list->end())
      {
        Actor* ref_actor = *iterator;
        Comparable actor_data = GetActorData(ref_actor);
        sort_list_->push_back(std::pair<Comparable, Actor*>(actor_data, ref_actor));
        ++iterator;
      }
    }
    //std::list<Actor*>* ResultList()
    void ApplyResultToActorList(std::list<Actor*>* actor_list)
    {
      //std::list<Actor*>* result_actor_list = new std::list<Actor*>;
      std::list<Actor*>* result_actor_list = actor_list;
      result_actor_list->clear();
      //std::vector< std::pair<Comparable, Actor*> >::iterator iterator = sort_list_->begin();
      typedef typename std::vector<std::pair<Comparable, Actor*> >::iterator ITERATOR;
      ITERATOR iterator = sort_list_->begin();
      while (iterator != sort_list_->end())
      {
        result_actor_list->push_back(iterator->second);
        ++iterator;
      }
      //return result_actor_list;
    }
    void SortList() { sort(sort_list_->begin(), sort_list_->end(), Compare); }

  private:
    Actor* actor_;
    std::vector< std::pair<Comparable, Actor*> >* sort_list_;
  };


  class ActorListSortByHealth : public ActorListSort<int>
  {
  public:
    ActorListSortByHealth(Actor* actor) :ActorListSort<int>(actor) {}
    virtual int GetActorData(Actor* ref_actor) { return ref_actor->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent); }
  };


  class ActorListSortByDistance : public ActorListSort<float>
  {
  public:
    ActorListSortByDistance(Actor* actor) :ActorListSort<float>(actor) {}
    virtual float GetActorData(Actor* ref_actor) 
    { 
      cocos2d::CCPoint actor_position = GetActor()->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint ref_actor_position = ref_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      return actor_position.getDistance(ref_actor_position);
    }
  };

  class ActorListSortByDiffGridY : public ActorListSort<float>
  {
  public:
    ActorListSortByDiffGridY(Actor* actor) :ActorListSort<float>(actor) {}
    virtual float GetActorData(Actor* ref_actor) 
    { 
      cocos2d::CCPoint actor_position = GetActor()->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint ref_actor_position = ref_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      //return abs(GetGridYFromPosition(actor_position) - GetGridYFromPosition(ref_actor_position));
      return abs(actor_position.y - ref_actor_position.y);
    }
  };


  

  const eActorTriggerModule ActorTriggerModuleSort::trigger_module_type_ = kActorTriggerModuleSort;
  const uint_32 ActorTriggerModuleDataSort::TARGET_MODULE_TYPE = kActorTriggerModuleSort;
  
  ActorTriggerModuleSort* ActorTriggerModuleSort::Instance()
  {
    static ActorTriggerModuleSort instance;
    return &instance;
  }


  bool ActorTriggerModuleSort::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataSort* trigger_module_data = dynamic_cast<ActorTriggerModuleDataSort*>(trigger_module_data_);

    assert(trigger_module_data);

    uint_32 trigger_flag = trigger_module_data->GetTriggerFlag();

    if (trigger_flag & kActorTriggerSortFlagDistance) UpdateDistance(actor, trigger_module_data, actor_list);
    if (trigger_flag & kActorTriggerSortFlagHealth) UpdateHealth(actor, trigger_module_data, actor_list);
    if (trigger_flag & kActorTriggerSortFlagDiffGridY) UpdateDiffGridY(actor, trigger_module_data, actor_list);
    
    
    if (trigger_module_data->GetIsReverse())
      actor_list->reverse();

    return (actor_list->size() > 0);
  }


  void ActorTriggerModuleSort::UpdateDistance(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list)
  {
    //sort by distance
    ActorListSortByDistance actor_list_sort(actor);
    actor_list_sort.SortActorList(actor_list);
  }

  void ActorTriggerModuleSort::UpdateHealth(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list)
  {
    //sort by health
    ActorListSortByHealth actor_list_sort(actor);
    actor_list_sort.SortActorList(actor_list);
  }

  void ActorTriggerModuleSort::UpdateDiffGridY(Actor* actor, ActorTriggerModuleDataSort* trigger_module_data, std::list<Actor*>* actor_list)
  {
    //sort by health
    ActorListSortByDiffGridY actor_list_sort(actor);
    actor_list_sort.SortActorList(actor_list);
  }

}  // namespace actor