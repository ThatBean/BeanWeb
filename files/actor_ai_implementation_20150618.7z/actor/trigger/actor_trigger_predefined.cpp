#include "actor_trigger_predefined.h"

#include "game/actor/actor.h"

#include "trigger_module/actor_trigger_module_actor_data.h"
#include "trigger_module/actor_trigger_module_faction.h"
#include "trigger_module/actor_trigger_module_geometry.h"
#include "trigger_module/actor_trigger_module_status.h"
//#include "trigger_module/actor_trigger_module_script.h"
//#include "trigger_module/actor_trigger_module_active.h"
#include "trigger_module/actor_trigger_module_sort.h"


namespace actor {
  ActorTrigger* GetPredefinedGuardTrigger(eActorPredefinedGuardTriggerType predefined_trigger_type, Actor* actor, float size_multiplier/* = 1.0f*/)
  {
    actor->GetActorData()->InitActorStatus(kActorStatusGuardAreaType, predefined_trigger_type);
    ActorTrigger* predefined_trigger = new ActorTrigger(actor);

    //add ActorModel filter first
    ActorTriggerModuleDataActorData* module_data_actor_data = dynamic_cast<ActorTriggerModuleDataActorData*>(GetActorTriggerModuleData(kActorTriggerModuleActorData, kActorTriggerActorDataFlagStatus));
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleActorData), module_data_actor_data);
    module_data_actor_data->SetFilterStatus(kActorTriggerActorDataFilterMethodEqual, kActorStatusActorModel, kActorModelActor);

    ActorTriggerModuleDataFaction* module_data_faction = dynamic_cast<ActorTriggerModuleDataFaction*>(GetActorTriggerModuleData(kActorTriggerModuleFaction, kActorTriggerFactionFlagHostile));
    ActorTriggerModuleDataGeometry* module_data_geometry = dynamic_cast<ActorTriggerModuleDataGeometry*>(GetActorTriggerModuleData(kActorTriggerModuleGeometry, kActorTriggerGeometryFlag));
    ActorTriggerModuleDataSort* module_data_sort = dynamic_cast<ActorTriggerModuleDataSort*>(GetActorTriggerModuleData(kActorTriggerModuleSort, kActorTriggerSortFlag));

    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleFaction), module_data_faction);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleGeometry), module_data_geometry);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleSort), module_data_sort);

    module_data_sort->SetTriggerFlag(kActorTriggerSortFlagDistance);

    float actor_radius_x = actor->GetAnimation()->GetActorBox().size.width * 0.5;
    float actor_radius_y = actor->GetAnimation()->GetActorBox().size.height * 0.5;

    switch (predefined_trigger_type)
    {
    case kActorPredefinedGuardTriggerCircle:
      {
        float radius_max = (1.5 * actor_radius_x) * size_multiplier;
        float radius_min = 0;
        float ratio_y = actor_radius_y / actor_radius_x;
        module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeCircle, radius_max, radius_min, ratio_y);
        actor->GetActorData()->InitActorAttribute(kActorAttributeGuardAreaRadius, radius_max);
      }
      break;
    case kActorPredefinedGuardTriggerRect:
      {
        float radius_max = 6 * GetGridBoxAverageWidth() * size_multiplier;
        float radius_min = 0;
        float ratio_y = (actor_radius_y - GetGridBoxAverageHeight() * 0.25) / radius_max;
        module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeRectangle, radius_max, radius_min, ratio_y);
        actor->GetActorData()->InitActorAttribute(kActorAttributeGuardAreaWidth, radius_max * 2);
        actor->GetActorData()->InitActorAttribute(kActorAttributeGuardAreaHeight, radius_max * ratio_y * 2);
      }
      break;
    default:
      assert(false);
      break;
    }

    return predefined_trigger;
  }




  ActorTrigger* GetPredefinedAttackTrigger(eActorPredefinedAttackTriggerType predefined_trigger_type, Actor* actor, float size_multiplier/* = 1.0f*/)
  {
    actor->GetActorData()->InitActorStatus(kActorStatusAttackAreaType, predefined_trigger_type);
    ActorTrigger* predefined_trigger = new ActorTrigger(actor);

    //add ActorModel filter first
    ActorTriggerModuleDataActorData* module_data_actor_data = dynamic_cast<ActorTriggerModuleDataActorData*>(GetActorTriggerModuleData(kActorTriggerModuleActorData, kActorTriggerActorDataFlagStatus));
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleActorData), module_data_actor_data);
    module_data_actor_data->SetFilterStatus(kActorTriggerActorDataFilterMethodEqual, kActorStatusActorModel, kActorModelActor);

    if (predefined_trigger_type == kActorPredefinedAttackTriggerHeal)
    {
      ActorTriggerModuleDataFaction* module_data_faction = dynamic_cast<ActorTriggerModuleDataFaction*>(GetActorTriggerModuleData(kActorTriggerModuleFaction, kActorTriggerFactionFlagFriendly | kActorTriggerFactionFlagSelf));
      predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleFaction), module_data_faction);
      
      ActorTriggerModuleDataStatus* module_data_status = dynamic_cast<ActorTriggerModuleDataStatus*>(GetActorTriggerModuleData(kActorTriggerModuleStatus, kActorTriggerStatusFlagHealthRatio));
      module_data_status->SetHealthRatio(0.99f, 0.00f);
      predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleStatus), module_data_status);
      
      return predefined_trigger;
    }

    ActorTriggerModuleDataFaction* module_data_faction = dynamic_cast<ActorTriggerModuleDataFaction*>(GetActorTriggerModuleData(kActorTriggerModuleFaction, kActorTriggerFactionFlagHostile));
    ActorTriggerModuleDataGeometry* module_data_geometry = dynamic_cast<ActorTriggerModuleDataGeometry*>(GetActorTriggerModuleData(kActorTriggerModuleGeometry, kActorTriggerGeometryFlag));
    ActorTriggerModuleDataSort* module_data_sort = dynamic_cast<ActorTriggerModuleDataSort*>(GetActorTriggerModuleData(kActorTriggerModuleSort, kActorTriggerSortFlag));

    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleFaction), module_data_faction);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleGeometry), module_data_geometry);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleSort), module_data_sort);

    module_data_sort->SetTriggerFlag(kActorTriggerSortFlagDistance);

    float actor_radius_x = actor->GetAnimation()->GetActorBox().size.width * 0.5;
    float actor_radius_y = actor->GetAnimation()->GetActorBox().size.height * 0.5;

    switch (predefined_trigger_type)
    {
    case kActorPredefinedAttackTriggerCircle:
      //should be skill data
      {
        float radius_max = (0.9 * actor_radius_x) * size_multiplier;
        float radius_min = 0;
        float ratio_y = actor_radius_y / actor_radius_x;
        module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeCircle, radius_max, radius_min, ratio_y);
        actor->GetActorData()->InitActorAttribute(kActorAttributeAttackAreaRadius, radius_max);
      }
      //should be skill data
      break;
    case kActorPredefinedAttackTriggerRect:
      //should be skill data
      {
        float radius_max = 6 * GetGridBoxAverageWidth() * size_multiplier;
        float radius_min = 0;
        float ratio_y = (actor_radius_y - GetGridBoxAverageHeight() * 0.5) / radius_max;
        module_data_geometry->SetTriggerFlagShape(kActorTriggerGeometryShapeRectangle, radius_max, radius_min, ratio_y);
        module_data_geometry->SetTriggerFlagDirection(true, true); //front & relative
        actor->GetActorData()->InitActorAttribute(kActorAttributeAttackAreaWidth, radius_max * 2);
        actor->GetActorData()->InitActorAttribute(kActorAttributeAttackAreaHeight, radius_max * ratio_y * 2);
      }
      //should be skill data
      break;
    default:
      assert(false);
      break;
    }
    actor->GetActorData()->InitActorStatus(kActorStatusAttackAreaType, predefined_trigger_type);
    return predefined_trigger;
  }



  ActorTrigger* GetPredefinedGuardTriggerAuto(eActorPredefinedGuardTriggerType predefined_trigger_type, Actor* actor)
  {
    ActorTrigger* predefined_trigger = new ActorTrigger(actor);

    //add ActorModel filter first
    ActorTriggerModuleDataActorData* module_data_actor_data = dynamic_cast<ActorTriggerModuleDataActorData*>(GetActorTriggerModuleData(kActorTriggerModuleActorData, kActorTriggerActorDataFlagStatus));
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleActorData), module_data_actor_data);
    module_data_actor_data->SetFilterStatus(kActorTriggerActorDataFilterMethodEqual, kActorStatusActorModel, kActorModelActor);

    ActorTriggerModuleDataFaction* module_data_faction = dynamic_cast<ActorTriggerModuleDataFaction*>(GetActorTriggerModuleData(kActorTriggerModuleFaction, kActorTriggerFactionFlagHostile));
    ActorTriggerModuleDataSort* module_data_sort = dynamic_cast<ActorTriggerModuleDataSort*>(GetActorTriggerModuleData(kActorTriggerModuleSort, kActorTriggerSortFlag));

    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleFaction), module_data_faction);
    predefined_trigger->AddTriggerModuleConfig(GetActorTriggerModule(kActorTriggerModuleSort), module_data_sort);

    switch (predefined_trigger_type)
    {
    case kActorPredefinedGuardTriggerCircle:
      module_data_sort->SetTriggerFlag(kActorTriggerSortFlagDistance);
      break;
    case kActorPredefinedGuardTriggerRect:
      module_data_sort->SetTriggerFlag(kActorTriggerSortFlagDistance | kActorTriggerSortFlagDiffGridY);
      break;
    default:
      assert(false);
      break;
    }

    return predefined_trigger;
  }
} // namespace actor
