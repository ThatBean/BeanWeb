#include "actor_animation_overhead_layer.h"

#include "game/actor/actor.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"

namespace actor {

  //ActorAnimationOverheadLayer
  ActorAnimationOverheadLayer::ActorAnimationOverheadLayer(Actor* actor)
    :actor_(actor),
    overhead_layer_(NULL),
    health_bar_layer_(NULL),
    health_bar_widget_(NULL),
    health_bar_bg_widget_(NULL),
    health_bar_left_time_(0)
  {

  }

  ActorAnimationOverheadLayer::~ActorAnimationOverheadLayer()
  {
    Clear();
  }

  void ActorAnimationOverheadLayer::Clear()
  {
    //overhead_layer_ will be cleared with skeleton_animation_node_
    if (health_bar_widget_) health_bar_widget_->release();
    if (health_bar_bg_widget_) health_bar_bg_widget_->release();

    overhead_layer_ = NULL;
    health_bar_widget_ = NULL;
    health_bar_bg_widget_ = NULL;
  }

  void ActorAnimationOverheadLayer::Init()
  {
    //create UILayer for health bar update
    overhead_layer_ = UILayer::create();
    overhead_layer_->scheduleUpdate();
    
    health_bar_layer_ = UIFactory::createWidgetFromFile("ui/agoui_player_hp.json");
    overhead_layer_->addWidget(health_bar_layer_);

    UILabelBMFont* label_friend_name = dynamic_cast<UILabelBMFont*>(overhead_layer_->getWidgetByName("Label_Friend"));
    label_friend_name->setVisible(false);

    health_bar_widget_ = dynamic_cast<UILoadingBar*>(overhead_layer_->getWidgetByName("progress_hp"));
    health_bar_widget_->loadTexture("agoui_progress_bar_white.png", UI_TEX_TYPE_PLIST);
    health_bar_widget_->setPercent(100);
    health_bar_widget_->retain();

    health_bar_bg_widget_ = dynamic_cast<UILoadingBar*>(overhead_layer_->getWidgetByName("progress_bg"));
    health_bar_bg_widget_->setIsHaveAni(true);
    health_bar_bg_widget_->setPercent(100);
    health_bar_bg_widget_->retain();

    ccColor3B color_health_bar_character_user = ccc3(0, 255, 0);
    ccColor3B color_health_bar_character_yellow = ccc3(255, 255, 0);
    ccColor3B color_health_bar_monster_red = ccc3(255, 0, 0);

    if (actor_->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport)
    {
      health_bar_widget_->setColor(color_health_bar_character_user);
    }
    else
    {
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance))
      {
      case kActorAppearanceCharacter:
        if (GetIsActorExtEnvPVP()) health_bar_widget_->setColor(color_health_bar_character_yellow);
        else health_bar_widget_->setColor(color_health_bar_monster_red);
        break;
      case kActorAppearanceEnemyBoss:
      case kActorAppearanceEnemyPawn:
        health_bar_widget_->setColor(color_health_bar_monster_red);
        break;
      }
    }
  }



  void ActorAnimationOverheadLayer::Update(float delta_time)
  {
    //always
    //health bar auto hiding
    if (actor_->GetActorData()->GetActorStatusBool(kActorAnimationStatusIsHealthChanged))
    {
      actor_->GetActorData()->SetActorStatusBool(kActorAnimationStatusIsHealthChanged, false);
      if (health_bar_layer_)
      {
        health_bar_left_time_ = ACTOR_ANIMATION_HEALTH_DISPLAY_TIME;
        health_bar_layer_->setVisible(true);
      }
    }


    if (health_bar_layer_ && health_bar_layer_->isVisible())
    {
      health_bar_left_time_ -= delta_time;

      if (health_bar_left_time_ <= 0) health_bar_layer_->setVisible(false);
      if (health_bar_widget_ && health_bar_bg_widget_)
      {
        float health_percent = 100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax);
        health_bar_widget_->setPercent(health_percent);
        health_bar_bg_widget_->setPercent(health_percent);
      }
    }
  }
} // namespace actor