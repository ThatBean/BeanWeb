#ifndef ACTOR_ANIMATION_BOTTOM_SYNC_LAYER_H
#define ACTOR_ANIMATION_BOTTOM_SYNC_LAYER_H

#include "game/actor/actor_adapter.h"
#include "cocos2d.h"

namespace taomee {
  class SkeletonAnimation;
}


namespace actor {

  class Actor;


  class ActorAnimationBottomSyncLayer
  {
  public:
    ActorAnimationBottomSyncLayer(Actor* actor_);
    ~ActorAnimationBottomSyncLayer();

    void Clear();
    void Init();

    void Update(float delta_time);

    cocos2d::CCNode* GetBottomLayerSyncNode() { return bottom_layer_sync_node_; };

    cocos2d::CCLayer* CreateGuardArea(bool is_circle_area = true);
    void StartGuardArea(float last_time);
    void RemoveGuardArea();

  private:
    Actor* actor_;

    cocos2d::CCNode* bottom_layer_sync_node_;  // for shadow or other effect that must be under all actor, position sync will be updated from here
    
    //selection guard area
    cocos2d::CCLayer* guard_area_layer_;
    float guard_area_left_time_;
  };

} // namespace actor


#endif // ACTOR_ANIMATION_BOTTOM_SYNC_LAYER_H