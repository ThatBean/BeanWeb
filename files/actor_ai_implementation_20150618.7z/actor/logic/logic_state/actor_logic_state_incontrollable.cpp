#include "actor_logic_state_incontrollable.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateIncontrollable::STATE_TYPE = kActorLogicStateIncontrollable;

  LogicStateIncontrollable* LogicStateIncontrollable::Instance()
  {
    static LogicStateIncontrollable instance;
    return &instance;
  }

  void LogicStateIncontrollable::OnEnter(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateIncontrollable][OnEnter]");

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIncontrollable));


    //buff init
    //buff init
    //buff init
    //buff init
    //buff init
    //buff init
    //buff init
    //buff init
  }

  void LogicStateIncontrollable::OnExit(Actor* actor)
  {

    actor->GetActorData()->AddLog("[LogicStateIncontrollable][OnExit]");
  }

  void LogicStateIncontrollable::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->AddLog("[LogicStateIncontrollable][Update]");
    //Wait for Buff system and Motion System to finish
    if (actor->GetActorData()->GetActorStatusBool(kActorMotionStatusIsBusy) == false)
    {
      //clear all
      actor->GetActorData()->GetControlData()->Reset();

      //back to idle
      //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
    }

  }

} // namespace actor