#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "game/actor/template_class/actor_signal_hub.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;
  class ActorControlData;

  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

  //CPP
  public:
    void Init();
    void Clear();

    void Update(float delta_time);

    //for data signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);

    //for damage event
    void OnDamageDealt(int target_actor_id, int target_model_type, int damage_attribute_type, float damage_value);
  //LUA
  //actor_based
  //actor_based
  public: 
    void ActorDataSignalConnect(int data_class_type, int actor_data_type);
    void ActorDataSignalDisconnect(int data_class_type, int actor_data_type);

    //direct access to ActorAttributeData
    bool  CheckActorAttribute(int data_key);
    void  InitActorAttribute(int data_key, float base = 0, float add = 0, float multiplier = 1, float extra = 0);
    void  SetActorAttribute(int data_key, float add = 0, float multiplier = 1, float extra = 0);
    void  AddActorAttribute(int data_key, float add = 0, float multiplier = 0, float extra = 0);
    float GetActorAttribute(int data_key);

    //direct access to ActorStatusData
    bool  CheckActorStatus(int data_key);
    void  InitActorStatus(int data_key, int status);
    void  SetActorStatus(int data_key, int status);
    int   GetActorStatus(int data_key);
    void  InitActorStatusBool(int data_key, bool bool_status);
    void  SetActorStatusBool(int data_key, bool bool_status);
    bool  GetActorStatusBool(int data_key);

    //direct access to ActorPositionData
    bool  CheckActorPosition(int data_key);
    void  InitActorPosition(int data_key, cocos2d::CCPoint position);
    void  SetActorPosition(int data_key, cocos2d::CCPoint position);
    cocos2d::CCPoint&   GetActorPosition(int data_key);

    //special operation
    ActorControlData* GetActorControlData();
    void SetActorIsAutoGuard(bool is_auto);
    void UpdateSpecialGuard(int type);
    void ShowActorLog(int max_line);
    void SetActorSkillCycleList(std::string& skill_cycle_string);

    //currently script can only create actor under actor
    int RequestCreateActor(int desired_actor_id, int actor_model_type); //will return created actor_id(may be different from initial)
    void RequestRemoveActor(int actor_id, bool instant_remove = false);

  private:
    Actor*  actor_;  //keep actor pointer
    float   cached_delta_time_;
    float   update_min_delta_time_;
    std::map<int, std::map<int, ActorSignalConnection > > lua_signal_connection_map_;



  //static method
  //static method
  public: //global
    static void SetIsAutoControl(bool is_auto_control) { is_auto_control_ = is_auto_control; }
    static bool GetIsAutoControl() { return is_auto_control_; }
  private:
    static bool is_auto_control_;

  public: //global
    static cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
    static cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
    static int GetGridXFromPositionX(float position_x);
    static int GetGridYFromPositionY(float position_y);

    static void ScriptAssert(bool expression, const std::string& message);


    static cocos2d::CCLayer* GetBattleBottomCCLayer();
    static void GenerateSkillData();

    //for debug
    //for debug


    //danger...
    //danger...
    static void SimulateTouchAt(float x, float y); 
    static void SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id);  //touch_event_id = 0, 1, 2, 3; safer to use CCTOUCHBEGAN etc
    static cocos2d::CCSet* GetTouchSet(float x, float y);  //this will get a modified static touch set in c++
    static bool TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node);

  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H