#ifndef ACTOR_ANIMATION_SKELETON_ANIMATION_H
#define ACTOR_ANIMATION_SKELETON_ANIMATION_H

#include "game/actor/actor_adapter.h"
#include "cocos2d.h"

namespace taomee {
  class SkeletonAnimation;
}


namespace actor {
  class Actor;


  class ActorAnimationSkeletonAnimation
  {
  public:
    ActorAnimationSkeletonAnimation(Actor* actor);
    ~ActorAnimationSkeletonAnimation();

    void Clear();
    void Init(std::string armature_name, float animation_scale);

    void Update(float delta_time);

    bool ChangeMovement(const std::string& movement_name, const int cycle_count = -1, const float speed = 1.0f);

    taomee::SkeletonAnimation* GetSkeletonAnimationNode() { return skeleton_animation_node_; }
    cocos2d::CCRect GetSkeletonAnimationBox();
    cocos2d::CCSize GetSkeletonAnimationBoxSize() { return skeleton_animation_box_size_; }
    cocos2d::CCPoint GetSkeletonAnimationBoxOriginOffest() { return skeleton_animation_box_origin_offset_; }
  private:
    Actor* actor_;

    taomee::SkeletonAnimation*  skeleton_animation_node_;
    cocos2d::CCSize skeleton_animation_box_size_;
    cocos2d::CCPoint skeleton_animation_box_origin_offset_; //skeleton_animation_position + skeleton_animation_box_center_offset_ = skeleton_animation_box_center
  };

} // namespace actor


#endif // ACTOR_ANIMATION_SKELETON_ANIMATION_H