#ifndef ACTOR_ANIMATION_EFFECT_H
#define ACTOR_ANIMATION_EFFECT_H

#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;

  class ActorAnimationEffect
  {
  public:
    ActorAnimationEffect(Actor* actor_);
    ~ActorAnimationEffect();

    void Clear();
    void Init();

    void Update(float delta_time);  //update animation movement

    cocos2d::CCNode* GetEffectNode() { return effect_node_; }

    cocos2d::CCRect GetEffectBox();

  private:
    Actor* actor_;

    cocos2d::CCNode* effect_node_;
  };
} // namespace actor


#endif // ACTOR_ANIMATION_EFFECT_H