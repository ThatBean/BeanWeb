#include "actor_adapter.h"

#include "actor.h"
#include "actor_script_exporter.h"
#include "game/actor/control/actor_control.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/motion/actor_motion_state_machine.h"
#include "game/actor/trigger/actor_trigger_predefined.h"
#include "game/actor/animation/actor_animation_skeleton_animation.h"


#include "game/army/unit/move_object.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"
#include "game/battle/level/levelbase.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "game/ago_skill/control/ASkillControl.h"

#include "game/battle/view/battle_view.h"
#include "game/battle/view/aim_mark.h"
#include "game/battle/view/battle_view_constant.h"

#include "game/game_manager/data_manager.h"

#include "engine/base/random_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"
#include "base/utils_string.h"

#include "game/actor/skill/actor_skill_data_extractor.h"

namespace actor
{
  //Search the string for space(the ' ', '\n', '\r', '\t'), and remove it, NOTE: will change source string
  std::string& ActorStringRemoveSpace(std::string& source_string)
  {
    std::string::iterator iterator = source_string.begin();
    while (iterator != source_string.end())
    {
      switch (*iterator)
      {
      case ' ':
      case '\n':
      case '\r':
      case '\t':
        iterator = source_string.erase(iterator);
        break;
      default:
        iterator ++;
        break;
      }
    }

    return source_string;
  }


  //Split the string at characters that matches any of the characters specified in delimiter_string.
  //delimiter can be ",|. " for multi-match split
  std::list<std::string>* ActorStringSplit(const std::string& source_string, const std::string& delimiter)
  {
    std::list<std::string>* result_list = new std::list<std::string>;
    std::string::size_type remain_string_index = 0, delimiter_index = std::string::npos, substr_count = 0;

    do {
      delimiter_index = source_string.find_first_of(delimiter, remain_string_index);
      substr_count = (delimiter_index == std::string::npos ? std::string::npos : delimiter_index - remain_string_index);
      result_list->push_back(source_string.substr(remain_string_index, substr_count));
      remain_string_index = delimiter_index + 1;  //skip delimiter
    } while (delimiter_index != std::string::npos);

    return result_list;
  }  


  std::list<EmitIdData> ParseEmitIdDataList(const std::string& source_string)
  {
    std::list<EmitIdData> emit_id_data_list;

    if (source_string.empty())
    {
      return emit_id_data_list;
    }

    //parse string
    std::list<std::string>* data_string_list = ActorStringSplit(source_string, std::string(","));
    for (std::list<std::string>::iterator iterator = data_string_list->begin(); iterator != data_string_list->end(); iterator ++)
    {
      std::string &data_string = *iterator;
      std::list<std::string>* data_item_string_list = ActorStringSplit(data_string, std::string("|"));
      std::list<std::string>::iterator iterator_data_item = data_item_string_list->begin();

      if (data_item_string_list->size() != 2 && data_item_string_list->size() != 3)
      {
        CCLog("[ParseEmitIdDataList] error data item count <%d>! source_string: %s", data_item_string_list->size(), source_string.c_str());
        assert(false);
        delete data_item_string_list;
        continue;
      }

      EmitIdData emit_id_data;

      emit_id_data.id = atoi(iterator_data_item->c_str());
      iterator_data_item ++;

      if (*iterator_data_item == "effect_timeline")
      {
        emit_id_data.type = kActorEmitEffectTimeline;
      }
      else if (*iterator_data_item == "buff")
      {
        emit_id_data.type = kActorEmitBuff;
      }
      else
      {
        CCLog("[ParseEmitIdDataList] error type string <%s>! source_string: %s", iterator_data_item->c_str(), source_string.c_str());
        assert(false);
        emit_id_data.type = kActorEmit;
      }
      iterator_data_item ++;

      if (data_item_string_list->size() > 2)
      {
        emit_id_data.fail_chance = String2Float(*iterator_data_item);
      }
      else
      {
        emit_id_data.fail_chance = 0.0f;
      }

      emit_id_data_list.push_back(emit_id_data);

      delete data_item_string_list;
    }
    delete data_string_list;

    return emit_id_data_list;
  }




  std::list<ActorSkillMovementData> ParseActorSkillMovementDataList(const std::string& source_string)
  {
    std::list<ActorSkillMovementData> skill_movement_data_list;

    if (source_string.empty())
    {
      return skill_movement_data_list;
    }

    //parse string
    std::list<std::string>* data_string_list = ActorStringSplit(source_string, std::string(","));
    for (std::list<std::string>::iterator iterator = data_string_list->begin(); iterator != data_string_list->end(); iterator ++)
    {
      std::string &data_string = *iterator;
      std::list<std::string>* data_item_string_list = ActorStringSplit(data_string, std::string("|"));
      std::list<std::string>::iterator iterator_data_item = data_item_string_list->begin();

      if (data_item_string_list->size() != 1 && data_item_string_list->size() != 2)
      {
        CCLog("[ParseActorSkillMovementDataList] error data item count <%d>! source_string: %s", data_item_string_list->size(), source_string.c_str());
        assert(false);
        delete data_item_string_list;
        continue;
      }

      ActorSkillMovementData skill_movement_data;

      skill_movement_data.movement_name = *iterator_data_item;
      iterator_data_item ++;

      if (data_item_string_list->size() > 1)
      {
        skill_movement_data.speed_scale = String2Float(*iterator_data_item);
      }
      else
      {
        skill_movement_data.speed_scale = 1.0f;
      }

      skill_movement_data_list.push_back(skill_movement_data);

      delete data_item_string_list;
    }
    delete data_string_list;

    return skill_movement_data_list;
  }




  EffectTimelineAnimationData ParseEffectTimelineAnimationData(const std::string& layer_string, const std::string& type_string, const std::string& name_string)
  {
    EffectTimelineAnimationData effect_animation_data;

    effect_animation_data.layer_type = ParseAnimationLayerType(layer_string);
    effect_animation_data.animation_type = ParseAnimationType(type_string);

    switch (effect_animation_data.animation_type)
    {
    case kActorAnimationEffectId:
      effect_animation_data.id = atoi(name_string.c_str());
      break;
    case kActorAnimationArmatureName:
    case kActorAnimationProjectileName:
      effect_animation_data.name = name_string;
      break;
    }

    return effect_animation_data;
  }



  ActorBuffConfigApplyData* ParseBuffConfigApplyData(const std::string& source_string)
  {
    ActorBuffConfigApplyData* buff_apply_data = NULL;

    if (source_string.empty())
    {
      return buff_apply_data;
    }

    buff_apply_data = new ActorBuffConfigApplyData;

    //parse string
    std::list<std::string>* data_string_list = ActorStringSplit(source_string, std::string(","));
    for (std::list<std::string>::iterator iterator = data_string_list->begin(); iterator != data_string_list->end(); iterator ++)
    {
      std::string &data_string = *iterator;
      std::list<std::string>* data_item_string_list = ActorStringSplit(data_string, std::string("|"));
      std::list<std::string>::iterator iterator_data_item = data_item_string_list->begin();


      std::string apply_type_string = data_item_string_list->empty() ? "" : *iterator_data_item;
      iterator_data_item ++;

      if (apply_type_string == "time_duration")
      {
        buff_apply_data->apply_flag |= kActorBuffConfigApplyTimeDuration;

        buff_apply_data->time_duration = String2Float(*iterator_data_item);
        iterator_data_item ++;
      }
      else if (apply_type_string == "time_tick")
      {
        buff_apply_data->apply_flag |= kActorBuffConfigApplyTimeTick;

        buff_apply_data->time_tick = String2Float(*iterator_data_item);
        iterator_data_item ++;

        if (iterator_data_item != data_item_string_list->end())
        {
          buff_apply_data->count_limit = String2Int(*iterator_data_item);
          iterator_data_item ++;
        }
      }
      else if (apply_type_string == "event")
      {
        buff_apply_data->apply_flag |= kActorBuffConfigApplyEvent;

        buff_apply_data->event_type = *iterator_data_item;
        iterator_data_item ++;

        if (iterator_data_item != data_item_string_list->end())
        {
          buff_apply_data->count_limit = String2Int(*iterator_data_item);
          iterator_data_item ++;
        }
      }
      else if (apply_type_string == "temporary")
      {
        buff_apply_data->is_temporary = true;
        iterator_data_item ++;
      }
      else
      {
        CCLog("[ParseBuffConfigApplyData] error source_string <%s>!", source_string.c_str());
        assert(false);
      }

      delete data_item_string_list;
    }
    delete data_string_list;

    assert(buff_apply_data->apply_flag != kActorBuffConfigApply);

    return buff_apply_data;
  }


  eActorAnimationType ParseAnimationType(const std::string& source_string)
  {
    if (source_string.empty()) return kActorAnimationNone;
    else if (source_string == "effect") return kActorAnimationEffectId;
    else if (source_string == "armature") return kActorAnimationArmatureName;
    else if (source_string == "projectile") return kActorAnimationProjectileName;
    else
    {
      CCLog("[ParseEffectTimelineAnimationType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorAnimation;
    }
  }
  eActorAnimationLayerType ParseAnimationLayerType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "top_layer") return kActorAnimationLayerTop;
    else if (source_string == "actor_layer") return kActorAnimationLayerActor;
    else if (source_string == "bottom_layer") return kActorAnimationLayerBottom;
    else
    {
      CCLog("[ParseEffectTimelineAnimationLayerType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorAnimationLayer;
    }
  }


  eActorMovementOriginType ParseMovementOriginType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "source_actor_location") return kActorMovementOriginSourceActorLocation;
    else if (source_string == "source_actor_attack_anchor") return kActorMovementOriginSourceActorAttackAnchor;
    else if (source_string == "screen_center") return kActorMovementOriginScreenCenter;
    else
    {
      CCLog("[ParseMovementOriginType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorMovementOrigin;
    }
  }

  eActorMovementType ParseMovementType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "none") return kActorMovementNone;
    else if (source_string == "tag_actor") return kActorMovementTagActor;
    else if (source_string == "line") return kActorMovementLine;
    else if (source_string == "homing") return kActorMovementHoming;
    else
    {
      CCLog("[ParseMovementType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorMovement;
    }
  }

  eActorEffectTimelineDirectionReferenceType ParseEffectTimelineDirectionReferenceType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "fix_right") return kActorEffectTimelineDirectionReferenceFixRight;
    else if (source_string == "actor_front") return kActorEffectTimelineDirectionReferenceActorFront;
    else
    {
      CCLog("[ParseEffectTimelineDirectionReferenceType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorEffectTimelineDirectionReference;
    }
  }

  eActorEffectConfigTriggerRangeType ParseEffectConfigTriggerRangeType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "all") return kActorEffectConfigTriggerRangeAll;
    else if (source_string == "circle") return kActorEffectConfigTriggerRangeCircle;
    else if (source_string == "rectangle") return kActorEffectConfigTriggerRangeRectangle;
    else
    {
      CCLog("[ParseEffectConfigTriggerRangeType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorEffectConfigTriggerRange;
    }
  }




  eActorBuffConfigReplaceType ParseBuffConfigReplaceType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "add_new") return kActorBuffConfigReplaceAddNew;
    else if (source_string == "replace_previous") return kActorBuffConfigReplaceReplacePrevious;
    else
    {
      CCLog("[ParseBuffConfigReplaceType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorBuffConfigReplace;
    }
  }


  eActorBuffConfigStackType ParseBuffConfigStackType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "drop_new") return kActorBuffConfigStackDropNew;
    else if (source_string == "create") return kActorBuffConfigStackCreate;
    else if (source_string == "merge") return kActorBuffConfigStackMerge;
    else
    {
      CCLog("[ParseBuffConfigStackType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorBuffConfigStack;
    }
  }


  eActorAnimationDisplayType ParseAnimationDisplayType(const std::string& source_string)
  {
    if (source_string.empty() || source_string == "above_actor") return kActorAnimationDisplayAboveActor;
    else if (source_string == "on_actor") return kActorAnimationDisplayOnActor;
    else if (source_string == "below_actor") return kActorAnimationDisplayBelowActor;
    else
    {
      CCLog("[ParseBuffStatusAnimationDisplayType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorAnimationDisplay;
    }
  }

  ActorBuffStatusBitSet ParseBuffStatusBitSet(const std::string& source_string)
  {
    ActorBuffStatusBitSet result_status_bit_set;
    
    if (source_string.empty())
    {

    }

    else if (source_string == "all_effect") 
    {
      result_status_bit_set.set();  //set all
    }

    else if (source_string == "mute_attack_all") 
    {
      result_status_bit_set.set(kActorBuffStatusMuteAttackNormal);
      result_status_bit_set.set(kActorBuffStatusMuteAttackPower);
      result_status_bit_set.set(kActorBuffStatusMuteAttackSpecial);
    }

    else if (source_string == "mute_receive_damage_all") 
    {
      result_status_bit_set.set(kActorBuffStatusMuteReceiveDamagePhysical);
      result_status_bit_set.set(kActorBuffStatusMuteReceiveDamageMagical);
    }


    else if (source_string == "mute_attack_normal") result_status_bit_set.set(kActorBuffStatusMuteAttackNormal);
    else if (source_string == "mute_attack_power") result_status_bit_set.set(kActorBuffStatusMuteAttackPower);
    else if (source_string == "mute_attack_special") result_status_bit_set.set(kActorBuffStatusMuteAttackSpecial);

    else if (source_string == "mute_receive_damage_physical") result_status_bit_set.set(kActorBuffStatusMuteReceiveDamagePhysical);
    else if (source_string == "mute_receive_damage_magical") result_status_bit_set.set(kActorBuffStatusMuteReceiveDamageMagical);

    else if (source_string == "auto_move") result_status_bit_set.set(kActorBuffStatusAutoMove);
    else if (source_string == "mute_move") result_status_bit_set.set(kActorBuffStatusMuteMove);

    else if (source_string == "status_blind") result_status_bit_set.set(kActorBuffStatusBlind);
    else if (source_string == "status_fear") result_status_bit_set.set(kActorBuffStatusFear);
    else if (source_string == "status_freeze") result_status_bit_set.set(kActorBuffStatusFreeze);
    else if (source_string == "status_invisible") result_status_bit_set.set(kActorBuffStatusInvisible);
    else if (source_string == "status_petrify") result_status_bit_set.set(kActorBuffStatusPetrify);
    else if (source_string == "status_silence") result_status_bit_set.set(kActorBuffStatusSlience);
    else if (source_string == "status_stun") result_status_bit_set.set(kActorBuffStatusStun);
    else if (source_string == "status_charmed") result_status_bit_set.set(kActorBuffStatusCharmed);
    else if (source_string == "status_intertwine") result_status_bit_set.set(kActorBuffStatusInterwine);

    else
    {
      CCLog("[ParseBuffStatusBitSet] error source_string <%s>!", source_string.c_str());
      assert(false);
    }

    return result_status_bit_set;
  }

  eActorAttributeType ParseActorAttributeType(const std::string& source_string)
  {
    std::string attribute_type_string = source_string;

    std::string::size_type found_pos = attribute_type_string.find_first_of("kActorAttribute");

    if (found_pos != std::string::npos)
    {
      attribute_type_string = attribute_type_string.replace(found_pos, strlen("kActorAttribute"), "");
    }

    if (attribute_type_string.empty()) return kActorAttribute;
    else if (attribute_type_string == "TimeActive") return kActorAttributeTimeActive;
    else if (attribute_type_string == "HealthMax") return kActorAttributeHealthMax;
    else if (attribute_type_string == "HealthCurrent") return kActorAttributeHealthCurrent;
    else if (attribute_type_string == "HealthRecover") return kActorAttributeHealthRecover;
    else if (attribute_type_string == "EnergyMax") return kActorAttributeEnergyMax;
    else if (attribute_type_string == "EnergyCurrent") return kActorAttributeEnergyCurrent;
    else if (attribute_type_string == "EnergyRecover") return kActorAttributeEnergyRecover;
    else if (attribute_type_string == "FactorCritical") return kActorAttributeFactorCritical;
    else if (attribute_type_string == "FactorCriticalResist") return kActorAttributeFactorCriticalResist;
    else if (attribute_type_string == "FactorCriticalExtra") return kActorAttributeFactorCriticalExtra;
    else if (attribute_type_string == "FactorHit") return kActorAttributeFactorHit;
    else if (attribute_type_string == "FactorDodge") return kActorAttributeFactorDodge;
    else if (attribute_type_string == "FactorDodgeExtra") return kActorAttributeFactorDodgeExtra;
    else if (attribute_type_string == "FactorDamageAdjust") return kActorAttributeFactorDamageAdjust;
    else if (attribute_type_string == "FactorDamageAdjustResist") return kActorAttributeFactorDamageAdjustResist;
    else if (attribute_type_string == "FactorDamageAdjustExtra") return kActorAttributeFactorDamageAdjustExtra;
    else if (attribute_type_string == "FactorSkillDamage") return kActorAttributeFactorSkillDamage;
    else if (attribute_type_string == "FactorSkillDamageResist") return kActorAttributeFactorSkillDamageResist;
    else if (attribute_type_string == "SpeedAttack") return kActorAttributeSpeedAttack;
    else if (attribute_type_string == "SpeedMove") return kActorAttributeSpeedMove;
    else if (attribute_type_string == "AttackPhysical") return kActorAttributeAttackPhysical;
    else if (attribute_type_string == "AttackMagical") return kActorAttributeAttackMagical;
    else if (attribute_type_string == "AttackCritical") return kActorAttributeAttackCritical;
    else if (attribute_type_string == "DefensePhysical") return kActorAttributeDefensePhysical;
    else if (attribute_type_string == "DefenseMagical") return kActorAttributeDefenseMagical;
    else if (attribute_type_string == "DefenseCritical") return kActorAttributeDefenseCritical;
    else if (attribute_type_string == "TriggerSizeScaleAttack") return kActorAttributeTriggerSizeScaleAttack;
    else if (attribute_type_string == "TriggerSizeScaleGuard") return kActorAttributeTriggerSizeScaleGuard;
    else if (attribute_type_string == "AttackAreaRadius") return kActorAttributeAttackAreaRadius;
    else if (attribute_type_string == "AttackAreaWidth") return kActorAttributeAttackAreaWidth;
    else if (attribute_type_string == "AttackAreaHeight") return kActorAttributeAttackAreaHeight;
    else if (attribute_type_string == "GuardAreaRadius ") return kActorAttributeGuardAreaRadius ;
    else if (attribute_type_string == "GuardAreaWidth ") return kActorAttributeGuardAreaWidth ;
    else if (attribute_type_string == "GuardAreaHeight ") return kActorAttributeGuardAreaHeight ;
    else if (attribute_type_string == "DamageAddition  ") return kActorAttributeDamageAddition  ;
    else if (attribute_type_string == "DamageAdditionPhysical") return kActorAttributeDamageAdditionPhysical;
    else if (attribute_type_string == "DamageAdditionMagical") return kActorAttributeDamageAdditionMagical;
    else if (attribute_type_string == "DamageAdditionCritical") return kActorAttributeDamageAdditionCritical;
    else if (attribute_type_string == "DamageAdditionHealth") return kActorAttributeDamageAdditionHealth;
    else if (attribute_type_string == "DamageAdditionEnergy") return kActorAttributeDamageAdditionEnergy;
    else if (attribute_type_string == "DamageReduction ") return kActorAttributeDamageReduction ;
    else if (attribute_type_string == "DamageReductionPhysical") return kActorAttributeDamageReductionPhysical;
    else if (attribute_type_string == "DamageReductionMagical") return kActorAttributeDamageReductionMagical;
    else if (attribute_type_string == "DamageReductionCritical") return kActorAttributeDamageReductionCritical;
    else if (attribute_type_string == "DamageReductionHealth") return kActorAttributeDamageReductionHealth;
    else if (attribute_type_string == "DamageReductionEnergy") return kActorAttributeDamageReductionEnergy;
    else if (attribute_type_string == "AttackCount") return kActorAttributeAttackCount;
    else if (attribute_type_string == "AttackNormalCount") return kActorAttributeAttackNormalCount;
    else if (attribute_type_string == "AttackPowerCount") return kActorAttributeAttackPowerCount;
    else if (attribute_type_string == "AttackSpecialCount") return kActorAttributeAttackSpecialCount;
    else if (attribute_type_string == "AnimationScale") return kActorAttributeAnimationScale;
    else
    {
      CCLog("[ParseActorAttributeType] error source_string <%s>!", attribute_type_string.c_str());
      assert(false);
      return kActorAttribute;
    }
  }

  eActorStatusType ParseActorStatusType(const std::string& source_string)
  {
    if (source_string.empty()) return kActorStatus;
    else if (source_string == "ActorId") return kActorStatusActorId;
    else if (source_string == "ActorModel") return kActorStatusActorModel;
    else if (source_string == "AnimationModel") return kActorStatusAnimationModel;
    else if (source_string == "CardId") return kActorStatusCardId;
    else if (source_string == "EffectConfigId") return kActorStatusEffectConfigId;
    else if (source_string == "Level") return kActorStatusLevel;
    else if (source_string == "Appearance") return kActorStatusAppearance;
    else if (source_string == "Faction") return kActorStatusFaction;
    else if (source_string == "Career") return kActorStatusCareer;
    else if (source_string == "GuardAreaType") return kActorStatusGuardAreaType;
    else if (source_string == "AttackAreaType") return kActorStatusAttackAreaType;
    else if (source_string == "LogicState") return kActorStatusLogicState;
    else if (source_string == "MotionState") return kActorStatusMotionState;
    else if (source_string == "CauseOfDeath") return kActorStatusCauseOfDeath;
    else if (source_string == "IsDisableUserOperation") return kActorStatusIsDisableUserOperation;
    else if (source_string == "AcceptDamage") return kActorStatusAcceptDamage;
    else if (source_string == "AcceptDamagePhysical") return kActorStatusAcceptDamagePhysical;
    else if (source_string == "AcceptDamageMagical") return kActorStatusAcceptDamageMagical;
    else if (source_string == "AcceptDamageCritical") return kActorStatusAcceptDamageCritical;
    else if (source_string == "AcceptDamageIce") return kActorStatusAcceptDamageIce;
    else if (source_string == "AcceptDamageFire") return kActorStatusAcceptDamageFire;
    else if (source_string == "AcceptDamageWind") return kActorStatusAcceptDamageWind;
    else if (source_string == "LogicIsIncontrollable") return kActorStatusLogicIsIncontrollable;
    else if (source_string == "LogicCanMove") return kActorStatusLogicCanMove;
    else if (source_string == "LogicCanAttack") return kActorStatusLogicCanAttack;
    else if (source_string == "LogicCanAttackNormal") return kActorStatusLogicCanAttackNormal;
    else if (source_string == "LogicCanAttackPower") return kActorStatusLogicCanAttackPower;
    else if (source_string == "LogicCanAttackSpecial") return kActorStatusLogicCanAttackSpecial;
    else if (source_string == "MotionIsBusy") return kActorStatusMotionIsBusy;
    else if (source_string == "ControlIsAuto") return kActorStatusControlIsAuto;
    else if (source_string == "ControlIsManual") return kActorStatusControlIsManual;
    else if (source_string == "ControlIsCounterAttack") return kActorStatusControlIsCounterAttack;
    else if (source_string == "ControlAutoGuardType") return kActorStatusControlAutoGuardType;
    else if (source_string == "ControlAutoReleaseSpecialSkillType") return kActorStatusControlAutoReleaseSpecialSkillType;
    else if (source_string == "ControlAutoReleaseSpecialSkillCount") return kActorStatusControlAutoReleaseSpecialSkillCount;
    else if (source_string == "ControlAutoReleaseSpecialSkillProbability") return kActorStatusControlAutoReleaseSpecialSkillProbability;
    else if (source_string == "BuffShaderType") return kActorStatusBuffShaderType;
    else if (source_string == "BuffIsPauseAnimation") return kActorStatusBuffIsPauseAnimation;
    else if (source_string == "BuffIsChangeColor") return kActorStatusBuffIsChangeColor;
    else if (source_string == "SkillCurrentSkillId") return kActorStatusSkillCurrentSkillId;
    else if (source_string == "SkillIsBusy") return kActorStatusSkillIsBusy;
    else if (source_string == "SkillIsPaused") return kActorStatusSkillIsPaused;
    else if (source_string == "SkillGuardType") return kActorStatusSkillGuardType;
    else if (source_string == "SkillAttackType") return kActorStatusSkillAttackType;
    else if (source_string == "AnimationIsPaused") return kActorStatusAnimationIsPaused;
    else if (source_string == "AnimationIsFocused") return kActorStatusAnimationIsFocused;
    else if (source_string == "AnimationDirection") return kActorStatusAnimationDirection;
    else if (source_string == "AnimationIsHealthChanged") return kActorStatusAnimationIsHealthChanged;
    else if (source_string == "SpecifiedHomeDirection") return kActorStatusSpecifiedHomeDirection;
    else if (source_string == "SpecifiedIsLimitGridX") return kActorStatusSpecifiedIsLimitGridX;
    else
    {
      CCLog("[ParseActorStatusType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return kActorStatus;
    }
  }













  void AutoReleaseSpecialSkill(int actor_id)
  {
    taomee::battle::BattleController::GetInstance().TriggerSpecialSkillRelease(actor_id);
  }


  ActorExtEnv* GetActorExtEnv()
  {
    return taomee::battle::BattleController::GetInstance().GetActorExtEnv();
  }


  void ShowDamageLabel(int actor_id, int damage_type, float damage_value)
  {
    Actor* actor = GetActorExtEnv()->GetActorById(actor_id);

    if (actor && actor->GetIsActorAlive())
    {
      ShowDamageLabel(actor, damage_type, damage_value);
    }
  }


  void ShowStatusLabel(int actor_id, int status_type)
  {
    ShowDamageLabel(actor_id, status_type, 0);
  }


  void ShowDamageLabel(Actor* actor, int damage_type, float damage_value)
  {
    taomee::battle::eDamageLabelType damege_label_type = taomee::battle::eDamageLabelType(damage_type);
    bool is_user_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport;

    cocos2d::CCPoint label_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
    label_position.y += actor->GetAnimation()->GetActorVisualHeight();

    taomee::battle::DamageLabel* label = taomee::battle::DamageLabel::create(damege_label_type, damage_value, is_user_faction);
    label->ShowDamageValueOnBattleLayer(taomee::battle::BattleController::GetInstance().GetBattleView(), label_position);
  }


  void ShowStatusLabel(Actor* actor, int status_type)
  {
    ShowDamageLabel(actor, status_type, 0);
  }


  void AlertEnemyPassRightBorder(int actor_id)
  {
    battle::BattleController::GetInstance().notifyMonsterMoveToRightBorder(actor_id);
  }



  const std::string GetDeadAnimationName(ActorAdapter* actor_adapter)
  {
    const taomee::battle::eDeadReason dead_reason = actor_adapter->get_dead_reason();
    std::string animation_name = "";

    switch (dead_reason)
    {
    case taomee::battle::kDeadReason_Disappear:
      animation_name = taomee::army::kUnitAnimationIdle;
      break;
    case taomee::battle::kDeadReason_Suicide:
      animation_name = taomee::army::kUnitAnimationDead_2;
      break;
    case taomee::battle::kDeadReason_Normal:
    default:
      animation_name = taomee::army::kUnitAnimationDead;
      break;
    }

    if (actor_adapter->GetActor()->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->existedAnimationName(animation_name) == false)
      animation_name = taomee::army::kUnitAnimationDead;

    return animation_name;
  }


  //add & experimental
  cocos2d::CCLayer* GetBattleBottomCCLayer()
  {
    return taomee::battle::BattleController::GetInstance().GetBattleView()->GetBattleLayer(taomee::battle::kBattleLayerBottom);
  }








  void GenerateSkillData()
  {
#ifdef WIN32
    data_extractor::ActorSkillDataExtractor actor_data_extractor;
    actor_data_extractor.Extract();
    actor_data_extractor.Reform();
    actor_data_extractor.SaveData();
#endif
  }


}