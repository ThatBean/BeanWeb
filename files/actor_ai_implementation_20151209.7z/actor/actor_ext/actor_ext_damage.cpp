#include "actor_ext_damage.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"
#include "game/actor/actor_script_exporter.h"

#include "engine/base/random_helper.h"
#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_data_table.h"
#include "game/event/event_battle/event_battle_obj.h"


namespace actor {


  DamagePackage::DamagePackage()
  {
    InitDamage();
  }
  DamagePackage::~DamagePackage()
  {
    //
  }


  //basic method
  void DamagePackage::InitDamage()
  {
    attribute_map_.GetDataMap()->clear();
    status_map_.GetDataMap()->clear();

    InitStatus(kActorDamageStatusCountAddProcessActor, 0);
    InitStatus(kActorDamageStatusCountSubProcessActor, 0);

    InitStatus(kActorDamageStatusSourceActorId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceSkillId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceBuffId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceEffectId, ACTOR_INVALID_ID);

    InitStatus(kActorDamageStatusTargetActorId, ACTOR_INVALID_ID);

    is_active_ = false;
  }

  void DamagePackage::AddDamage(
    eActorDamageAttributeType   damage_type,
    float   damage_add/* = 0*/,
    float   damage_multiplier/* = 1*/,
    float   damage_extra/* = 0*/
    )
  {
    if (damage_type == kActorDamageAttribute)
    {
      assert(false);
      return;
    }

    if (attribute_map_.Check(damage_type))
    {
      InitAttribute(damage_type);
    }

    attribute_map_.GetData(damage_type)->Add(damage_add, damage_multiplier, damage_extra);
  }

  float DamagePackage::GetDamage(unsigned long damage_type_filter)
  {
    if (!is_active_) 
    {
      assert(is_active_);
      return 0;
    }

    float result_damage = 0;

    std::map<eActorDamageAttributeType, DamageAttributeData>::iterator iterator = attribute_map_.GetDataMap()->begin();
    while (iterator != attribute_map_.GetDataMap()->end())
    {
      if (iterator->first & damage_type_filter)
        result_damage += iterator->second.Get();

      ++iterator;
    }

    return result_damage;
  }
  //DamagePackage






  //ActorExtDamage
  ActorExtDamage::ActorExtDamage(ActorExtEnv* actor_ext_env)
    :actor_ext_env_(actor_ext_env)
  {
    //
  }

  ActorExtDamage::~ActorExtDamage()
  {
    Clear();
  }

  void ActorExtDamage::Clear()
  {
    std::list<DamagePackage*>::iterator iterator = damage_package_list_.begin();

    while (iterator != damage_package_list_.end())
    {
      DamagePackage* damage_package = *iterator;

      *iterator = NULL;

      if (damage_package) delete damage_package;

      iterator++;
    }

    damage_package_list_.clear();
  }


  void ActorExtDamage::Update(float delta_time)
  {
    std::list<DamagePackage*> process_damage_package_list;

    //take a snapshot
    process_damage_package_list.assign(damage_package_list_.begin(), damage_package_list_.end());

    //ready for next row
    damage_package_list_.clear();

    std::list<DamagePackage*>::iterator iterator = process_damage_package_list.begin();
    while (iterator != process_damage_package_list.end())
    {
      DamagePackage* damage_package = *iterator;

      *iterator = NULL; //unlink damage package

      if (damage_package) ApplyDamagePackage(damage_package);
      else assert(damage_package);  //strange empty damage

      iterator++;
    }

    process_damage_package_list.clear();
  }



  void ActorExtDamage::DamageDealt(
    DamagePackage* damage_package,
    int target_actor_id, 
    float damage_value, 
    float consumed_value, 
    eActorDamageAttributeType damage_attribute_type, 
    eActorAttributeType data_key)
  {
    //target actor
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);
    if (target_actor && consumed_value > 0 && damage_attribute_type == kActorDamageAttributeHealth)
    {
      eActorSkillType skill_type = eActorSkillType(damage_package->GetStatus(kActorDamageStatusSourceSkillType));
      bool is_normal_attack = (skill_type == kActorSkillNormal);

      int damage_type = taomee::battle::kDamageTypePhysics;

      int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);
      if (skill_id != ACTOR_INVALID_ID)
      {
        SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
        damage_type = skillData ? skillData->GetDamageType() : taomee::battle::kDamageTypePhysics;
      }
      else
      {
        if (damage_value < 0)
          damage_type = taomee::battle::kDamageTypeHeal;
        else if (damage_package->GetAttribute(kActorDamageAttributeHealth) > 0)
          damage_type = taomee::battle::kDamageTypeHoly;
        else if (damage_package->GetAttribute(kActorDamageAttributeMagical) > 0)
          damage_type = taomee::battle::kDamageTypeMagic;
        else if (damage_package->GetAttribute(kActorDamageAttributePhysical) > 0)
          damage_type = taomee::battle::kDamageTypePhysics;
        else 
          damage_type = taomee::battle::kDamageTypeUnkown;
      }


      //pop damage label
      if (damage_package->GetStatusBool(kActorDamageStatusIsMissed)) 
      {
        ShowStatusLabel(target_actor, taomee::battle::eDamageLabelType_Dodge);
      }
      else if (damage_package->GetStatusBool(kActorDamageStatusIsHeal))
      {
        ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Heal, consumed_value);
      }
      else if (damage_package->GetStatusBool(kActorDamageStatusIsSuicide))
      {
        ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Physics, consumed_value);
      }
      else 
      {
        if (damage_package->GetStatusBool(kActorDamageStatusIsCritical))
        {
          ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_PhysicsCritical, consumed_value);
        }
        else
        {
          if (damage_type == taomee::battle::kDamageTypePhysics && is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Physics, consumed_value);
          else if (damage_type == taomee::battle::kDamageTypePhysics && !is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_PhysicsSkill, consumed_value);
          else if (damage_type == taomee::battle::kDamageTypeMagic && is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Magic, consumed_value);
          else if (damage_type == taomee::battle::kDamageTypeMagic && !is_normal_attack)
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_MagicSkill, consumed_value);
          else 
            ShowDamageLabel(target_actor, taomee::battle::eDamageLabelType_Physics, consumed_value);
        }
      }

      //add color shader
      if (damage_package->GetStatusBool(kActorDamageStatusIsHeal))
      {
        // add healing green effect 
        target_actor->GetAnimation()->SetColorShader(ccc4f(0.0f, 0.5f, 0.0f, 0.5f), 0.5f);
      }
      else
      {
        // add hit red effect
        target_actor->GetAnimation()->SetColorShader(ccc4f(1.0f, 0.0f, 0.0f, 0.6f), 0.5f);
      }
    }



    //source actor
    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = GetActorExtEnv()->GetActorById(source_actor_id);
    if (source_actor && source_actor->GetIsActorAlive())
    {
      if (damage_package->GetStatusBool(kActorDamageStatusIsMissed)) 
      {
        ShowStatusLabel(source_actor, taomee::battle::eDamageLabelType_Dodge);
      }
      else
      {
        //Emit Damage Dealt Event
        ActorScriptExporter* actor_ecript_exporter = (ActorScriptExporter*)(source_actor->GetScriptExporter());
        
        actor_ecript_exporter->OnDamageDealt(
          target_actor->GetActorData()->GetActorStatus(kActorStatusActorId), 
          target_actor->GetActorData()->GetActorStatus(kActorStatusActorModel), 
          damage_attribute_type, 
          consumed_value);
      }
    }

  }





  void ActorExtDamage::AddDamagePackage(DamagePackage* damage_package, bool is_hold_till_next_update/* = true*/) //For later Send(in Update)
  {
    if (is_hold_till_next_update)
    {
      damage_package_list_.push_back(damage_package);
    }
    else
    {
      ApplyDamagePackage(damage_package);
    }
  }


  void ActorExtDamage::ApplyDamagePackage(DamagePackage* damage_package) //Consume instantly
  {
    damage_package = CalcTargetSubProcess(damage_package);


    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    if (source_actor && source_actor->GetIsActorAlive())
    {
      damage_package = source_actor->GetActorData()->GetDamageData()->NotifyDamageResult(damage_package);
    }

    //currently no other use...
    if (damage_package) delete damage_package;
  }



  DamagePackage* ActorExtDamage::CalcSourceAddProcess(DamagePackage* damage_package)
  {
    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);

    if (source_actor && source_actor->GetIsActorAlive())
    {
      //add up
      damage_package = source_actor->GetActorData()->GetDamageData()->AddProcess(damage_package);

      //notice buff
      source_actor->GetBuff()->OnDamageEvent("damage_generate", damage_package);
    }
    else
    {
      CCLog("[CalcSourceAddProcess] DamagePackage source actor invalid, source_actor_id: %d", source_actor_id);
      damage_package->SetIsActive(false);
    }

    return damage_package;
  }


  DamagePackage* ActorExtDamage::CalcTargetSubProcess(DamagePackage* damage_package)
  {
    int target_actor_id = damage_package->GetStatus(kActorDamageStatusTargetActorId);
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);

    if (target_actor && target_actor->GetIsActorAlive())
    {
      //notice buff
      target_actor->GetBuff()->OnDamageEvent("damage_receive", damage_package);

      //consume up
      damage_package = target_actor->GetActorData()->GetDamageData()->SubProcess(damage_package);

      int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
      int skill_id = damage_package->GetStatus(kActorDamageStatusSourceSkillId);
      taomee::ByHitEvent::Emit(target_actor_id , source_actor_id, taomee::battle::kAttackResultNormalDamage);
      taomee::HitEvent::Emit(source_actor_id, target_actor_id, taomee::battle::kAttackResultNormalDamage, skill_id, false);
    }
    else
    {
      CCLog("[CalcTargetSubProcess] DamagePackage Target Missing! target_actor_id: %d", target_actor_id);
      damage_package->SetIsActive(false);
    }

    return damage_package;
  }






  DamagePackage* ActorExtDamage::QuickInitSkillDamage(int source_actor_id, int target_actor_id, int skill_id)
  {
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);

    if (source_actor/* && source_actor->GetIsActorAlive()*/
      && target_actor/* && target_actor->GetIsActorAlive()*/
      && skill_id != ACTOR_INVALID_ID)
    {
      DamagePackage* damage_package = new DamagePackage;

      damage_package->InitStatus(kActorDamageStatusTargetActorId, target_actor_id);

      damage_package->InitStatus(kActorDamageStatusSourceActorId, source_actor_id);
      damage_package->InitStatus(kActorDamageStatusSourceActorLevel, source_actor->GetActorData()->GetActorStatus(kActorStatusLevel));

      damage_package->InitStatus(kActorDamageStatusSourceSkillId, skill_id);

      ActorSkillInfo* skill_info = source_actor->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);

      eActorSkillType skill_type = source_actor->GetActorData()->GetSkillData()->GetSkillTypeById(skill_id);
      int skill_level = skill_info ? skill_info->skill_level : 0;

      damage_package->InitStatus(kActorDamageStatusSourceSkillLevel, skill_level);
      damage_package->InitStatus(kActorDamageStatusSourceSkillType, skill_type);
      
      damage_package->InitAttribute(kActorDamageAttributeHealth, 0);
      damage_package->InitAttribute(kActorDamageAttributeEnergy, 0);

      calculateDamagePackage(damage_package);

      return damage_package;
    }

    return NULL;
  }

  void ActorExtDamage::calculateDamagePackage( DamagePackage* damage_package )
  {
    Actor* source_actor = actor_ext_env_->GetActorById(damage_package->GetStatus(kActorDamageStatusSourceActorId));
    Actor* target_actor = actor_ext_env_->GetActorById(damage_package->GetStatus(kActorDamageStatusTargetActorId));

    ActorSkillInfo* skill_info = source_actor->GetActorData()->GetSkillData()->GetSkillInfoById(damage_package->GetStatus(kActorDamageStatusSourceSkillId));    

    //FORMULA formula_list.xlsx
    //decide Miss
    //max(min((A_Hit-B_Dodge)/1000+1+A_skillCorrect,0.95),0.02) ??A_skillCorrect??
    float factor_hit = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorHit);
    float factor_dodge = target_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorDodge);

    float temp_rate_hit = MIN( (factor_hit - factor_dodge)/1000.f + 1, 0.95);
    float rate_hit = MAX( temp_rate_hit,0.02);

    bool is_hit = taomee::random_0_1() <= rate_hit;
    if (!is_hit) 
    {
      damage_package->InitStatusBool(kActorDamageStatusIsMissed, true);
      damage_package->SetIsActive(true);
      return;
    }


    //decide Critical
    //min(max(A_Crit-B_CritResist+A_skillCorrect,1),0.02) ??A_skillCorrect??
    float factor_critical = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorCritical);
    float factor_resist_critical = target_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorCriticalResist);

    float temp_rate_critical = MAX(factor_critical-factor_resist_critical,1);
    float rate_critical = MIN(temp_rate_critical,0.02);

    bool is_critical = taomee::random_0_1() <= rate_critical;
    if (is_critical) damage_package->InitStatusBool(kActorDamageStatusIsCritical, true);

    //calculate Critical extend rate
    //A_CritExtendDamage/1000
    float factor_critical_extend = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorCriticalExtra);
    float rate_critical_extend = factor_critical_extend/1000;
    damage_package->InitAttribute(kActorDamageAttributeFactorCriticalExtendRate,rate_critical_extend);

    //kActorDamageAttribute
    //calculate ArmorRendRate
    //min(max((A_ArmorRend-B_Armor)/1000,1.5),0.8)
    float factor_damageAdjust_rend = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorDamageAdjustResist);
    float factor_damageAdjust = target_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorDamageAdjust);

    float temp_rate_damageAdjust = MAX( (factor_damageAdjust_rend-factor_damageAdjust)/1000,1.5);
    float rate_damageAdjust = MIN( temp_rate_damageAdjust,0.8 );
    damage_package->InitAttribute(kActorDamageAttributeFactorDamageAdjustRate,rate_damageAdjust);

    //calculate damage extend rate
    //min(max(A_DamageExtendAd-B_DamageExtendReduce,0.5),2)
    float factor_damage_add_extend = source_actor->GetActorData()->GetActorAttribute(kActorAttributeDamageAddition);
    float factor_damage_reduce_extend = target_actor->GetActorData()->GetActorAttribute(kActorAttributeDamageReduction);
    float temp_rate_damage_extend = MAX(factor_damage_add_extend-factor_damage_reduce_extend,0.5);
    float rate_damage_extend = MIN(temp_rate_damage_extend,2);
    damage_package->InitAttribute(kActorDamageAttributeFactorDamageExtendRate,rate_damage_extend);

    //calculate skill damage extend rate
    //A_SkillDamageRate/(1+B_SkillResist/3000*isPowerSkill) ??isPowerSkill?? skill_info->skill_damage_scale
    float factor_skill_damage_rate_denominator = source_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorSkillDamage)
                                                / (1+target_actor->GetActorData()->GetActorAttribute(kActorAttributeFactorSkillDamageResist)/3000);

    //player vs monster
    //A_Attack*ArmorRendExtendRate-B_Def

    eActorDamageAttributeType damage_attribute_type = kActorDamageAttributePhysical;
    float base_damage = 0;
    float source_attack_physical = source_actor->GetActorData()->GetActorAttribute(kActorAttributeAttackPhysical);
    float source_attack_magical = source_actor->GetActorData()->GetActorAttribute(kActorAttributeAttackMagical);
    float target_defense_physical = target_actor->GetActorData()->GetActorAttribute(kActorAttributeDefensePhysical);
    float target_defense_magical = target_actor->GetActorData()->GetActorAttribute(kActorAttributeDefenseMagical);
    if ( source_actor->GetActorData()->GetActorStatus(kActorStatusAppearance) != target_actor->GetActorData()->GetActorStatus(kActorStatusAppearance) )
    {
      if ( source_attack_physical != 0 )
      {
        base_damage = source_attack_physical*rate_damageAdjust-target_defense_physical;
        damage_attribute_type = kActorDamageAttributePhysical;
      }
      else
      {
        base_damage = source_attack_magical*rate_damageAdjust-target_defense_magical;
        damage_attribute_type = kActorDamageAttributeMagical;
      }
    }
    else //A_Attack*min(max((A_Attack/2+1000)/(B_Def+1000)*0.5,0.5),0.65)
    {
      if ( source_attack_physical != 0 )
      {
        base_damage = source_attack_physical*MIN(MAX((source_attack_physical/2+1000)/(target_defense_physical+1000)*0.5,0.5),0.65);
        damage_attribute_type = kActorDamageAttributePhysical;
      }
      else
      {
        base_damage = source_attack_magical*MIN(MAX((source_attack_magical/2+1000)/(target_defense_magical+1000)*0.5,0.5),0.65);
        damage_attribute_type = kActorDamageAttributeMagical;
      }
    }

    //calculate damage value
    //BaseDamage*(1+isCrit*(0.5+CritExtendDamageRate))*DamageExtendRate*AllSkillDamageRate
    float result_damage_value = base_damage*(1+(is_critical?1:0)*(0.5+rate_critical_extend))*rate_damage_extend;/*skill_damage/factor_skill_damage_rate_denominator*/
    damage_package->InitAttribute(damage_attribute_type,result_damage_value);

    damage_package->SetIsActive(true);
  }

} // namespace actor