#ifndef ACTOR_EXT_EFFECT_TIMELINE_H
#define ACTOR_EXT_EFFECT_TIMELINE_H

#include "game/actor/actor_ext/actor_ext_effect.h"

#include "cocos2d.h"
#include "cocos-ext.h"

class EffectTimelineData;
class EffectTimelineItemData;

namespace taomee {
  class ProjectileAnimation;
}

namespace actor {

  typedef struct tActorEffectTimelineItemUpdateData {
    tActorEffectTimelineItemUpdateData()
      : effect_timeline_item_data(NULL)
      , animation_armature(NULL)
      , animation_projectile(NULL)
      , actor_effect(NULL)
      , effect_node(NULL)
      , movement_homing_target_actor_id(ACTOR_INVALID_ID)
      , is_updatable(false)
      , is_deletable(false)
    {}

    EffectTimelineItemData* effect_timeline_item_data;

    cocos2d::extension::CCArmature* animation_armature; 
    taomee::ProjectileAnimation* animation_projectile; 
    ActorEffect* actor_effect; 

    cocos2d::CCNode* effect_node;
    cocos2d::CCPoint effect_position; //for init position or update
    cocos2d::CCPoint movement_data; //maybe vector, or position, differ for each movement
    int movement_homing_target_actor_id;

    bool is_updatable;
    bool is_deletable;
  } ActorEffectTimelineUpdateData;


  //provide data check and event check
  class ActorEffectTimeline
  {
  public:
    ActorEffectTimeline(ActorExtEffect* actor_ext_effect);
    ~ActorEffectTimeline();

    void Clear();
    void Init(int effect_timeline_key, int effect_timeline_id, ActorSkillLinkData skill_link_data);
    bool Update(float delta_time);  //return is_keep

    int GetEffectTimelineKey() { return effect_timeline_key_; }
    int GetEffectTimelineId() { return effect_timeline_id_; }

  private:
    void CreateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data);  //data init
    void UpdateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time);  //movement update
    void DeleteItem(ActorEffectTimelineUpdateData& effect_timeline_update_data);  //data clean up

    void InitMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data);
    void UpdateMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time);


  private:
    int effect_timeline_key_;
    int effect_timeline_id_;

    float time_;  //time passed

    std::list<ActorEffectTimelineUpdateData> item_update_data_list_;

    ActorSkillLinkData skill_link_data_;

    ActorExtEffect* actor_ext_effect_;
  };

} // namespace actor


#endif // ACTOR_EXT_EFFECT_TIMELINE_H