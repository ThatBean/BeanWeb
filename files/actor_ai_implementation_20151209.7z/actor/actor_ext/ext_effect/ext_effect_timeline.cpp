#include "ext_effect_timeline.h"

#include "ext_effect.h"

#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/effect_timeline_data_table.h"
#include "game/data_table/effect_config_data_table.h"

#include "game/battle/battle_controller.h"
#include "game/battle/view/battle_view.h"
#include "game/battle/view/battle_view_constant.h"


#include "engine/animation/projectile_animation.h"

#include "engine/geometry/geometry_const.h"
#include "engine/base/game_math.h"
#include "engine/base/random_helper.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

#include <algorithm>

/*
  Actor Effect
    Effect is Animation + Movement + Trigger + Data, or what a Skill will create.
    All component is optional, thus a Animation only or Data only Effect can be created

    Life Span:
      Init: 
        need: effect_id 
        optional: source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update: 
        play animation, check trigger

      OnTrigger: 
        (may or may not), triggered, apply carried Data to one or more Actor, may result in a Buff

      Clear: 
        self removal, when hit, time out, or forced to stop(from skill maybe)
*/



namespace actor {

  //ActorEffectTimeline
  ActorEffectTimeline::ActorEffectTimeline(ActorExtEffect* actor_ext_effect)
    : actor_ext_effect_(actor_ext_effect)
    , effect_timeline_key_(ACTOR_INVALID_ID)
    , effect_timeline_id_(ACTOR_INVALID_ID)
    , time_(0.0f)
  {
    Clear();
  }

  ActorEffectTimeline::~ActorEffectTimeline()
  {
    Clear();
  }

  void ActorEffectTimeline::Clear()
  {
    std::list<ActorEffectTimelineUpdateData>::iterator iterator = item_update_data_list_.begin();
    while (iterator != item_update_data_list_.end())
    {
      ActorEffectTimelineUpdateData &effect_timeline_update_data = *iterator;
      
      DeleteItem(effect_timeline_update_data);

      iterator ++;
    }
    item_update_data_list_.clear();

    effect_timeline_key_ = ACTOR_INVALID_ID;
    effect_timeline_id_ = ACTOR_INVALID_ID;
    time_ = 0.0f;
  }

  void ActorEffectTimeline::Init(int effect_timeline_key, int effect_timeline_id, ActorSkillLinkData skill_link_data)
  {
    //loop effect timeline item and save link
    EffectTimelineData* effect_timeline_data = DataManager::GetInstance().GetEffectTimelineDataTable()->GetEffectTimeline(effect_timeline_id);

//     assert(skill_link_data.skill_id > 0);
//     assert(skill_link_data.skill_config_data);


    //check valid
    if (!effect_timeline_data)
    {
      CCLog("[ActorEffectTimeline][Init] missing effect timeline id: %d", effect_timeline_id);
      assert(false);
      return;
    }
    //check valid

    Clear();

    effect_timeline_key_ = effect_timeline_key;
    effect_timeline_id_ = effect_timeline_id;
    skill_link_data_ = skill_link_data;

    std::list<EffectTimelineItemData> &effect_timeline_item_data_list = effect_timeline_data->GetItemList();
    std::list<EffectTimelineItemData>::iterator iterator = effect_timeline_item_data_list.begin();
    while (iterator != effect_timeline_item_data_list.end())
    {
      EffectTimelineItemData &effect_timeline_item_data = *iterator;

      ActorEffectTimelineUpdateData effect_timeline_update_data;
      effect_timeline_update_data.effect_timeline_item_data = &effect_timeline_item_data;
      item_update_data_list_.push_back(effect_timeline_update_data);

      iterator ++;
    }
  }
  
  bool ActorEffectTimeline::Update(float delta_time)
  {
    time_ += delta_time;

    //loop effect and check time
    std::list<ActorEffectTimelineUpdateData>::iterator iterator = item_update_data_list_.begin();
    while (iterator != item_update_data_list_.end())
    {
      ActorEffectTimelineUpdateData &effect_timeline_update_data = *iterator;

      if (effect_timeline_update_data.is_deletable)
      {
        DeleteItem(effect_timeline_update_data);
        iterator = item_update_data_list_.erase(iterator);
      }
      else 
      {
        if (effect_timeline_update_data.is_updatable)
        {
          if (time_ >= effect_timeline_update_data.effect_timeline_item_data->GetDelay() + effect_timeline_update_data.effect_timeline_item_data->GetDuration())
          {
            effect_timeline_update_data.is_deletable = true;  //time out
          }
          else
          {
            UpdateItem(effect_timeline_update_data, delta_time);
          }
        }
        else if (time_ >= effect_timeline_update_data.effect_timeline_item_data->GetDelay())
        {
          CreateItem(effect_timeline_update_data);
        }
        else
        {
          //wait the delay
        }

        iterator ++;
      }
    }

    //is_keep
    return item_update_data_list_.empty() == false;
  }


  void ActorEffectTimeline::CreateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;
    EffectTimelineAnimationData &effect_animation_data = effect_timeline_item_data->GetEffectAnimationData();

    //collect data
    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(skill_link_data_.actor_id);

    //true == actor facing left, and we need to change animation for this
    //NOTE: all animation currently made consider LEFT(x-) as default direction, so in this x+ system, it's already 180deg rotated
    bool is_animation_filp_x = (effect_timeline_item_data->GetDirectionReference() == kActorEffectTimelineDirectionReferenceActorFront
      && actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight);

    //create effect node
    switch (effect_animation_data.animation_type)
    {
    case kActorAnimationEffectId:
      {
        ActorEffectLinkData actor_effect_link_data;
        actor_effect_link_data.effect_key = ACTOR_INVALID_ID; // auto decide
        actor_effect_link_data.effect_id = effect_animation_data.id;

        actor_effect_link_data.effect_timeline_id = effect_timeline_id_;
        actor_effect_link_data.effect_timeline_item_index = effect_timeline_update_data.effect_timeline_item_data->GetId();

        actor_effect_link_data.skill_link_data = skill_link_data_;
        
        //create effect
        effect_timeline_update_data.actor_effect = actor_ext_effect_->CreateEffect(actor_effect_link_data);

        effect_timeline_update_data.effect_node = effect_timeline_update_data.actor_effect->GetAnimation()->GetActorNode();

        effect_timeline_update_data.effect_node->setRotation(effect_timeline_item_data->GetDirection());
        if (is_animation_filp_x) effect_timeline_update_data.effect_node->setRotationY(180);
      }
      break;
    case kActorAnimationArmatureName:
      {
        std::string armature_name = effect_animation_data.name;
        std::string movement_name = "bsj";

        CCArmature* armature_animation = CCArmature::create();

        if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
        {
          std::string skeleton_config = taomee::kDefaultSkeletonFilePath+armature_name+".xml";
          std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+armature_name+".plist";
          std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+armature_name+".pvr.ccz";
          CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
        }
        armature_animation->init(armature_name.c_str());
        armature_animation->getAnimation()->play(movement_name.c_str(), 0, -1, 0);

        armature_animation->setRotation(effect_timeline_item_data->GetDirection());
        if (is_animation_filp_x) armature_animation->setRotationY(180);

        effect_timeline_update_data.animation_armature = armature_animation;
        effect_timeline_update_data.effect_node = armature_animation;
      }
      break;
    case kActorAnimationProjectileName:
      {
        std::string projectile_name = effect_animation_data.name;

        taomee::ProjectileAnimation* projectile_animation = new taomee::ProjectileAnimation();
        projectile_animation->initWithName(projectile_name.c_str());
        projectile_animation->setPositionType(kCCPositionTypeRelative);
        //projectile_animation->release();

        projectile_animation->setFlipX(is_animation_filp_x);
        projectile_animation->setAniRotation(effect_timeline_item_data->GetDirection());

        effect_timeline_update_data.animation_projectile = projectile_animation;
        effect_timeline_update_data.effect_node = projectile_animation;
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }


    if (effect_timeline_update_data.effect_node)
    {
      InitMovement(effect_timeline_update_data);

      //add to view
      switch (effect_animation_data.layer_type)
      {
      case kActorAnimationLayerTop:
        taomee::battle::BattleController::GetInstance().GetBattleView()->AddNodeToBattleLayer(effect_timeline_update_data.effect_node, taomee::battle::kBattleLayerTop);
        break;
      case kActorAnimationLayerActor:
        taomee::battle::BattleController::GetInstance().GetBattleView()->AddNodeToBattleLayer(effect_timeline_update_data.effect_node, taomee::battle::kBattleLayerMiddle);
        break;
      case kActorAnimationLayerBottom:
        taomee::battle::BattleController::GetInstance().GetBattleView()->AddNodeToBattleLayer(effect_timeline_update_data.effect_node, taomee::battle::kBattleLayerBottom);
        break;
      default:
        effect_timeline_update_data.is_deletable = true;
        assert(false);
        break;
      }
    }

    effect_timeline_update_data.is_updatable = true;
  }

  void ActorEffectTimeline::UpdateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;
    EffectTimelineAnimationData &effect_animation_data = effect_timeline_item_data->GetEffectAnimationData();

    UpdateMovement(effect_timeline_update_data, delta_time);
  }

  void ActorEffectTimeline::DeleteItem(ActorEffectTimelineUpdateData& effect_timeline_update_data)
  {
    if (effect_timeline_update_data.animation_armature)
    {
      effect_timeline_update_data.animation_armature->removeFromParentAndCleanup(true);
    }

    if (effect_timeline_update_data.animation_projectile)
    {
      effect_timeline_update_data.animation_projectile->release();
      effect_timeline_update_data.animation_projectile->removeFromParentAndCleanup(true);
    }

    if (effect_timeline_update_data.actor_effect)
    {
      actor_ext_effect_->RemoveEffect(effect_timeline_update_data.actor_effect->GetEffectLinkData().effect_key);
    }

    effect_timeline_update_data.animation_armature = NULL;
    effect_timeline_update_data.animation_projectile = NULL;
    effect_timeline_update_data.actor_effect = NULL;
    effect_timeline_update_data.effect_node = NULL;
    effect_timeline_update_data.effect_timeline_item_data = NULL;
  }
















  void ActorEffectTimeline::InitMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;
    EffectTimelineAnimationData &effect_animation_data = effect_timeline_item_data->GetEffectAnimationData();

    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(skill_link_data_.actor_id);

    bool is_filp_x = (effect_timeline_item_data->GetDirectionReference() == kActorEffectTimelineDirectionReferenceActorFront
      && actor && actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionLeft);


    //position
    cocos2d::CCPoint origin_position;
    switch (effect_timeline_item_data->GetMovementOriginType())
    {
    case kActorMovementOriginSourceActorLocation:
      origin_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      break;
    case kActorMovementOriginSourceActorAttackAnchor:
      origin_position = actor->GetAnimation()->GetActorRangeAttackAnchor();
      break;
    case kActorMovementOriginScreenCenter:
      origin_position = ccp(taomee::battle::GetBattleLayerDesignSize().width * 0.5, taomee::battle::GetBattleLayerDesignSize().height * 0.5);
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }

    origin_position.x += (is_filp_x ? -1 : 1) * effect_timeline_item_data->GetPositionX();
    origin_position.y += effect_timeline_item_data->GetPositionY();
    effect_timeline_update_data.effect_node->setPosition(origin_position);


    //movement_data
    switch (effect_timeline_item_data->GetMovementType())
    {
    case kActorMovementNone:
      // nothing
      break;
    case kActorMovementTagActor:
      {
        //record delta position
        effect_timeline_update_data.movement_data = actor 
          ? ccpSub(effect_timeline_update_data.effect_node->getPosition(), actor->GetActorData()->GetActorPosition(kActorPositionAnimation)) 
          : CCPointZero;
      }
      break;
    case kActorMovementHoming:
      //get target actor id
      effect_timeline_update_data.movement_homing_target_actor_id = 1;
    case kActorMovementLine:
      {
        //calc speed vector
        //normally: from x+ (0deg), ccw
        //filp_x: from x-(180feg), cw
        float direction_degree = effect_timeline_item_data->GetDirection() * (is_filp_x ? -1 : 1) + (is_filp_x ? 180 : 0);
        float direction_radian = direction_degree * PI / 180.0f;

        effect_timeline_update_data.movement_data = ccpForAngle(direction_radian) * (GetGridBoxAverageWidth() * effect_timeline_item_data->GetMovementSpeed());
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }
  }


  void ActorEffectTimeline::UpdateMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time)
  {
    EffectTimelineItemData* effect_timeline_item_data = effect_timeline_update_data.effect_timeline_item_data;
    EffectTimelineAnimationData &effect_animation_data = effect_timeline_item_data->GetEffectAnimationData();

    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(skill_link_data_.actor_id);
    
    switch (effect_timeline_item_data->GetMovementType())
    {
    case kActorMovementNone:
      // nothing
      break;
    case kActorMovementTagActor:
      effect_timeline_update_data.effect_node->setPosition(
        ccpAdd(
          actor ? actor->GetActorData()->GetActorPosition(kActorPositionAnimation) : CCPointZero, 
          effect_timeline_update_data.movement_data));
      break;
    case kActorMovementLine:
      effect_timeline_update_data.effect_node->setPosition(
        ccpAdd(
          effect_timeline_update_data.effect_node->getPosition(), 
          effect_timeline_update_data.movement_data * delta_time));
      break;
    case kActorMovementHoming:
      {
        Actor* target_actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(effect_timeline_update_data.movement_homing_target_actor_id);
        if (!target_actor)
        {
          effect_timeline_update_data.is_deletable = true;
        }
        else
        {
          cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
          cocos2d::CCPoint effect_node_position = effect_timeline_update_data.effect_node->getPosition();
          
          cocos2d::CCPoint movement_vector = ccpSub(target_position, effect_node_position);

          float movement_speed = effect_timeline_update_data.movement_data.getLength();
          float target_distance = movement_vector.getLength();

          if (target_distance <= movement_speed * delta_time)
          {
            effect_timeline_update_data.effect_node->setPosition(target_position);  //just arrive
          }
          else
          {
            //rotate and move
            float movement_direction_radian = effect_timeline_update_data.movement_data.getAngle();
            float target_direction_radian = movement_vector.getAngle();

            float movement_speed_delta = std::min<float>(target_distance, movement_speed * delta_time);
            float movement_rotation_radian = std::min<float>(target_direction_radian - movement_direction_radian, movement_speed * (PI * 10.0f / 180.0f) * delta_time);

            cocos2d::CCPoint normalized_vector = ccpForAngle(movement_direction_radian + movement_rotation_radian);

            effect_timeline_update_data.effect_node->setPosition(
              ccpAdd(
                effect_timeline_update_data.effect_node->getPosition(), 
                normalized_vector * movement_speed_delta));

            effect_timeline_update_data.effect_node->setRotation(R2A(movement_direction_radian + movement_rotation_radian));

            effect_timeline_update_data.movement_data = normalized_vector * movement_speed; //record new
          }
        }
      }
      break;
    default:
      effect_timeline_update_data.is_deletable = true;
      assert(false);
      break;
    }


    //check out of screen
    float size_scale = 1.5f; 
    CCRect screen_box = CCRect(
      iCC_DESIGN_SIZE.width * 0.5f * (1.0f - size_scale), 
      iCC_DESIGN_SIZE.height * 0.5f * (1.0f - size_scale), 
      iCC_DESIGN_SIZE.width * size_scale, 
      iCC_DESIGN_SIZE.height * size_scale);
    if (screen_box.containsPoint(effect_timeline_update_data.effect_node->getPosition()) == false)
    {
      effect_timeline_update_data.is_deletable = true;
    }
  }



  //ActorEffectTimeline

} // namespace actor