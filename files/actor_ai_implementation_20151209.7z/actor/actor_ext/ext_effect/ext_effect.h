#ifndef ACTOR_EXT_EFFECT_H
#define ACTOR_EXT_EFFECT_H

#include "game/actor/actor.h"
#include "game/actor/actor_ext/actor_ext_effect.h"

namespace actor {
  class ActorExtEffect;
  class ActorTrigger;

  //provide data check and event check
  class ActorEffect : public Actor
  {
  public:
    ActorEffect(ActorExtEffect* actor_ext_effect);
    ~ActorEffect();

    void Clear();
    void Init(ActorEffectLinkData& effect_link_data);
    void Update(float delta_time);

    ActorEffectLinkData& GetEffectLinkData() { return effect_link_data_; }

  private:
    void OnTrigger(std::list<int>* actor_id_list);
    void ApplyEffect(int actor_id);

  private:
    ActorTrigger* trigger_;
    bool is_check_count_limit_;  //check trigger every update
    bool is_check_time_tick_;  //check trigger by time

    float trigger_tick_time_; //in seconds
    int trigger_count_limit_; //-1 = unlimited

    std::map<int, bool>  trigger_actor_id_map_; //prevent multi trigger

    ActorEffectLinkData effect_link_data_;

    ActorExtEffect* actor_ext_effect_;
  };

} // namespace actor


#endif // ACTOR_EXT_EFFECT_H