#ifndef ACTOR_EXT_SKILL_EFFECT_H
#define ACTOR_EXT_SKILL_EFFECT_H

#include "game/actor/skill/actor_skill.h"
#include "game/actor/data/actor_data_typedef.h"

#include "engine/base/basictypes.h"


class EffectConfigData;

namespace actor {
  class Actor;
  class ActorExtEnv;

  class ActorEffect;
  class ActorEffectTimeline;


  //effect needed link data
  class ActorEffectLinkData 
  {
  public:
    ActorEffectLinkData()
    {
      Clear();
    }

    void Clear()
    {
      effect_key = ACTOR_INVALID_ID;
      effect_id = ACTOR_INVALID_ID;
      effect_timeline_id = ACTOR_INVALID_ID;
      effect_timeline_item_index = ACTOR_INVALID_ID;
      effect_config_data = NULL;
      skill_link_data.Clear();
    }

  public:
    int effect_key;
    int effect_id;

    int effect_timeline_id;
    int effect_timeline_item_index;

    EffectConfigData* effect_config_data; //quick access

    ActorSkillLinkData skill_link_data;
  } ;


  // hold all skill and effect instance
  class ActorExtEffect
  {
  public:
    ActorExtEffect(ActorExtEnv* actor_ext_env);
    ~ActorExtEffect();

    void Clear(); //clear all skill and effect

    void Update(float delta_time);

    ActorEffectTimeline* CreateEffectTimeline(int effect_timeline_key, int effect_timeline_id, ActorSkillLinkData skill_link_data);
    void RemoveEffectTimeline(int effect_timeline_key);

    ActorEffect* CreateEffect(ActorEffectLinkData effect_link_data);
    void RemoveEffect(int effect_key);

    ActorExtEnv* GetActorExtEnv() { return actor_ext_env_; }

  private:
    std::map<int, ActorEffectTimeline*> effect_timeline_map_;

    std::map<int, ActorEffect*> effect_map_;

    ActorExtEnv* actor_ext_env_;
  };

} // namespace actor


#endif // ACTOR_EXT_SKILL_EFFECT_H