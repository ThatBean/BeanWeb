#include "actor_ext_env.h"

#include "actor.h"

#include "game/actor/buff/actor_buff.h"

#include "actor_ext/actor_ext_damage.h"
#include "actor_ext/actor_ext_effect.h"
#include "actor_ext/actor_ext_grid.h"
#include "actor_ext/actor_ext_user_operation.h"

#include "engine/base/random_helper.h"

namespace actor {
    ActorExtEnv::ActorExtEnv()
      :is_pause_(false)
    {
      actor_map_.clear();

      actor_focus_map_.clear();

      actor_ext_damage_ = new ActorExtDamage(this);
      actor_ext_effect_ = new ActorExtEffect(this);
      actor_ext_grid_ = new ActorExtGrid(this);
      actor_ext_user_operation_ = new ActorExtUserOperation(this);
    }

    ActorExtEnv::~ActorExtEnv()
    {
      Clear();

      if (actor_ext_damage_) delete actor_ext_damage_;
      if (actor_ext_effect_) delete actor_ext_effect_;
      if (actor_ext_grid_) delete actor_ext_grid_;
      if (actor_ext_user_operation_) delete actor_ext_user_operation_;

      actor_ext_damage_ = NULL;
      actor_ext_effect_ = NULL;
      actor_ext_grid_ = NULL;
      actor_ext_user_operation_ = NULL;
    }

    void ActorExtEnv::Clear()
    {
      if (actor_ext_damage_) actor_ext_damage_->Clear();
      if (actor_ext_effect_) actor_ext_effect_->Clear();

      std::map<int, Actor*>::iterator actor_iterator = actor_map_.begin();
      while(actor_iterator != actor_map_.end())
      {
        Actor* actor = actor_iterator->second;
        actor->GetActorData()->GetLog()->AddErrorLogF("[Error][ActorExtEnv][Clear] possible leaking actor, ID:%d", actor->GetScriptObjectId());
        assert(false);
        actor->UnLinkScript();
        delete actor;
        ++actor_iterator;
      }
      actor_map_.clear();

      actor_focus_map_.clear();

      if (actor_ext_grid_) actor_ext_grid_->Clear();
      if (actor_ext_user_operation_) actor_ext_user_operation_->Clear();
    }


    void ActorExtEnv::Update(float delta_time)
    {
      //update damage
      actor_ext_damage_->Update(delta_time);

      //update effect
      actor_ext_effect_->Update(delta_time);

      //update grid
      actor_ext_grid_->UpdateActorGridList();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetScriptObjectIsActive()) actor->Update(delta_time);
        ++iterator;
      }
    }


    Actor* ActorExtEnv::CreateActor() //will return actor_id
    {
      int actor_id = GetValidId();
      
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule

      return CreateActor(actor_id);
    }

    Actor* ActorExtEnv::CreateActor(int actor_id) //alternative, predefined actor_id
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        assert(false);
        return actor_map_[actor_id];
      }
      else
      {
        Actor* actor = new Actor;
        actor_map_[actor_id] = actor;
        actor->LinkScript(actor_id, this);  //script object
        return actor;
      }
    }

    void ActorExtEnv::RemoveActor(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        Actor* actor = actor_map_[actor_id];
        actor_map_.erase(actor_id);
        actor->UnLinkScript();
        delete actor;
      }
      else
      {
        assert(false);
      }
    }

    Actor* ActorExtEnv::GetActorById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end()) return actor_map_[actor_id];
      else return NULL;
    }

    std::list<Actor*>* ActorExtEnv::GetActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>;
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetIsActorAlive() && IsPositionXInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)))
          actor_list->push_back(actor);
        ++iterator;
      }
      return actor_list;
    }


    //should move ? should move
    //for skill pause need

    bool ActorExtEnv::CheckActorFocus(int actor_id)
    {
      return (actor_focus_map_.find(actor_id) != actor_focus_map_.end());
    }

    void ActorExtEnv::AddActorFocusById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end()) 
      {
        Actor* actor = actor_map_[actor_id];
        actor_focus_map_[actor_id] = actor;
        actor_map_[actor_id]->GetActorData()->GetLog()->AddErrorLogF("[ActorExtEnv][AddActorFocusById] Current Focused:%d", actor_focus_map_.size());

        //raise ZOrder logic
        actor->GetAnimation()->GetActorNode()->setZOrder((9999 << 8) + actor->GetAnimation()->GetActorNode()->getZOrder());
        actor->GetAnimation()->GetActorNode()->runAction(CCScaleTo::create(0.2f, 1.0f));

        actor->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsFocused, true);
      }
      else 
      {
        assert(false);
      }
    }

    void ActorExtEnv::ClearActorFocus()
    { 
      std::map<int, Actor*>::iterator iterator = actor_focus_map_.begin();
      while (iterator != actor_focus_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;

        //recover logic in ActorAnimation Update
        actor->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsFocused, false);

        ++iterator;
      }
      actor_focus_map_.clear();
    }

    void ActorExtEnv::PauseActorExceptFocus()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;

        if (actor_focus_map_.find(actor_id) != actor_focus_map_.end()) 
        {
          actor->GetActorData()->GetLog()->AddLogF("[ActorExtEnv][PauseActorExceptFocus] Focused");
          actor->SetIsPause(false);
        }
        else 
        {
          actor->GetActorData()->GetLog()->AddLogF("[ActorExtEnv][PauseActorExceptFocus] Paused");
          actor->SetIsPause(true);
        }

        ++iterator;
      }
    }

    void ActorExtEnv::ClearActorPause()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        actor->SetIsPause(false);

        ++iterator;
      }
    }

    void ActorExtEnv::SetIsPause(bool is_pause) 
    { 
      if (is_pause) PauseActorExceptFocus();
      else ClearActorPause();
      is_pause_ = is_pause; 
    }




    void ActorExtEnv::ApplyEmitIdDataList(std::list<EmitIdData>& emit_id_data_list, int actor_id/* = ACTOR_INVALID_ID*/)
    {
      ActorSkillLinkData skill_link_data;

      //check actor //check skill
      Actor* actor = GetActorById(actor_id);
      if (actor && actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy))
      {
        //copy skill link data
        skill_link_data = actor->GetSkill()->GetSkillLinkData();
      }
      else if (actor)
      {
        //create non-attack data
        skill_link_data.actor_id = actor_id;
        skill_link_data.actor_level = actor->GetActorData()->GetActorStatus(kActorStatusLevel);
      }
      else
      {
        assert(false);
      }

      //loop and create
      for (std::list<EmitIdData>::iterator iterator = emit_id_data_list.begin(); iterator != emit_id_data_list.end(); iterator ++)
      {
        EmitIdData &emit_id_data = *iterator;

        bool is_success_by_chance = (emit_id_data.fail_chance <= taomee::random_0_1());

        if (is_success_by_chance == false)
        {
          continue;
        }

        switch (emit_id_data.type)
        {
        case kActorEmitEffectTimeline:
          actor_ext_effect_->CreateEffectTimeline(ACTOR_INVALID_ID, emit_id_data.id, skill_link_data);
          break;
        case kActorEmitBuff:
          actor->GetBuff()->AddBuff(ACTOR_INVALID_ID, emit_id_data.id, skill_link_data);
          break;
        }
      }
    }


    //for skill counter attack
    void ActorExtEnv::SkillAttackedNotification(int from_actor_id, int to_actor_id, int skill_id, int health_change)
    {
      Actor* from_actor = GetActorById(from_actor_id);
      Actor* to_actor = GetActorById(to_actor_id);

      if (!from_actor || !to_actor || to_actor->GetActorData()->GetActorStatusBool(kActorStatusControlIsCounterAttack) == false || health_change <= 0)
        return;

      if (to_actor->GetActorData()->GetControlData()->GetCountdown() >= kActorControlPriorityCounterAttackAuto)
        return;

      cocos2d::CCPoint from_actor_position = from_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint to_actor_position = to_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

      float distance = from_actor_position.getDistance(to_actor_position);

      if (distance > to_actor->GetAnimation()->GetActorBox().size.width * 1.5
        || from_actor->GetActorData()->GetActorStatus(kActorStatusFaction) == to_actor->GetActorData()->GetActorStatus(kActorStatusFaction))
        return;

      //move to position only
      to_actor->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveAuto, from_actor_position);
    }
    //should move ? should move

} // namespace actor