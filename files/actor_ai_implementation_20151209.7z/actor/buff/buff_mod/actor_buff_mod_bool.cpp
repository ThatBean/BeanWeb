#include "actor_buff_mod_bool.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBool
  ActorBuffModTypedData ActorBuffModBool::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    bool result_bool = false;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyBoolNot:
      {
        result_bool = !buff_mod_data->GetExecutedArgument(0).GetBool();
      }
      break;
    case kActorBuffModKeyBoolNumber:
      {
        result_bool = buff_mod_data->GetExecutedArgument(0).GetNumber() != 0;
      }
      break;
    case kActorBuffModKeyBoolExistStatus:
      {
        result_bool = buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->CheckBuffStatus(ParseBuffStatusBitSet(buff_mod_data->GetExecutedArgument(0).GetString()));
      }
      break;
    default:
      CCLog("[ActorBuffModBool][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->is_active = false;
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBool(kActorBuffModDataBool, result_bool);
    return result_data;
  }
  //ActorBuffModBool

} // namespace actor