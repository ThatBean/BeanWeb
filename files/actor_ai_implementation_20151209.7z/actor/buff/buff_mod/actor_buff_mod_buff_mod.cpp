#include "actor_buff_mod_buff_mod.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffMod
  ActorBuffModTypedData ActorBuffModBuffMod::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    assert(false);

    ActorBuffModTypedData result_data;

    return result_data;
  }
  //ActorBuffModBuffMod

} // namespace actor