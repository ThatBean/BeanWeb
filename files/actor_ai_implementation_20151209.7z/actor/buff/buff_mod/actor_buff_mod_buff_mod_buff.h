#ifndef ACTOR_BUFF_MOD_BUFF_MOD_BUFF_H
#define ACTOR_BUFF_MOD_BUFF_MOD_BUFF_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {
  class ActorBuffModBuffModBuff : public ActorBuffMod
  {
  public:
    ActorBuffModBuffModBuff(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffModBuffMod; };
  };

} // namespace actor


#endif // ACTOR_BUFF_MOD_BUFF_MOD_BUFF_H