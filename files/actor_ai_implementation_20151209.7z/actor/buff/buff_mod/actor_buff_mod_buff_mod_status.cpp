#include "actor_buff_mod_buff_mod_status.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModStatus
  ActorBuffModTypedData ActorBuffModBuffModStatus::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyStatusAdd:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          std::string& buff_status = iterator->GetString();
          ActorBuffStatusBitSet status_bit_set = ParseBuffStatusBitSet(buff_status);
          buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatus(status_bit_set, kActorBuffStatusStateAdd);
          buff_link_data->buff_status_bit_set |= status_bit_set;  //mark
          buff_link_data->status_state_type = kActorBuffStatusStateAdd;
        }
      }
      break;
    case kActorBuffModKeyStatusImmune:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          std::string& buff_status = iterator->GetString();
          ActorBuffStatusBitSet status_bit_set = ParseBuffStatusBitSet(buff_status);
          buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatus(status_bit_set, kActorBuffStatusStateImmuneAdd);
          buff_link_data->buff_status_bit_set |= status_bit_set;  //mark
          buff_link_data->status_state_type = kActorBuffStatusStateImmuneAdd;
        }
      }
      break;
    case kActorBuffModKeyStatusRemove:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          std::string& buff_status = iterator->GetString();
          ActorBuffStatusBitSet status_bit_set = ParseBuffStatusBitSet(buff_status);
          buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatus(status_bit_set, kActorBuffStatusStateSub);
          buff_link_data->buff_status_bit_set |= status_bit_set;  //mark
          buff_link_data->status_state_type = kActorBuffStatusStateSub;
        }
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModStatus][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->is_active = false;
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModStatus

} // namespace actor