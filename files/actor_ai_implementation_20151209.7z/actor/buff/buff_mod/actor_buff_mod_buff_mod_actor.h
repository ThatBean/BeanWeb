#ifndef ACTOR_BUFF_MOD_BUFF_MOD_ACTOR_H
#define ACTOR_BUFF_MOD_BUFF_MOD_ACTOR_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {
  class ActorBuffModBuffModActor : public ActorBuffMod
  {
  public:
    ActorBuffModBuffModActor(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
      , applied_attribute_add_(0.0f)
      , applied_attribute_multiplier_(0.0f)
      , applied_attribute_extra_(0.0f)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffModBuffMod; };

  private:
    float applied_attribute_add_;
    float applied_attribute_multiplier_;
    float applied_attribute_extra_;
  };

} // namespace actor


#endif // ACTOR_BUFF_MOD_BUFF_MOD_ACTOR_H