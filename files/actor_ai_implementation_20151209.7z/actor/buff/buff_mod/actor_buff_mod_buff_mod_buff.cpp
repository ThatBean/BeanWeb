#include "actor_buff_mod_buff_mod_buff.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModBuff
  ActorBuffModTypedData ActorBuffModBuffModBuff::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyBuffAddById:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          int buff_id = iterator->GetNumber();
          buff_link_data->actor_buff->AddBuff(ACTOR_INVALID_ID, buff_id, buff_link_data->skill_link_data);
        }
      }
      break;
    case kActorBuffModKeyBuffRemoveById:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          int buff_id = iterator->GetNumber();
          buff_link_data->actor_buff->DeactivateBuffById(buff_id);
        }
      }
      break;
    case kActorBuffModKeyBuffRemoveByStatus:
      {
        ActorBuffStatusBitSet status_bit_set;

        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          std::string& buff_status = iterator->GetString();
          status_bit_set |= ParseBuffStatusBitSet(buff_status);
        }

        if (status_bit_set.any()) buff_link_data->actor_buff->DeactivateBuffByStatus(status_bit_set);
      }
      break;
    case kActorBuffModKeyBuffRemoveByKeyword:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          std::string& buff_keyword = iterator->GetString();
          buff_link_data->actor_buff->DeactivateBuffByKeyword(buff_keyword);
        }
      }
      break;
    case kActorBuffModKeyBuffRemoveByType:
      {
        // TODO: not supported
        assert(false);
        buff_link_data->is_active = false;
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModDamage][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->is_active = false;
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModBuff

} // namespace actor