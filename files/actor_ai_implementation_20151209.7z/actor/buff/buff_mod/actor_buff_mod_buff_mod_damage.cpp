#include "actor_buff_mod_buff_mod_damage.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModDamage
  ActorBuffModTypedData ActorBuffModBuffModDamage::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyDamageMod:
      {
        if (!buff_link_data->event_data_damage_package)
        {
          buff_link_data->is_active = false;
          break;
        }

        std::string& damage_data_type_string = buff_mod_data->GetExecutedArgument(0).GetString();
        float mod_value = buff_mod_data->GetExecutedArgument(1).GetNumber();

        if (damage_data_type_string == "total_health_damage")
        {
          buff_link_data->event_data_damage_package->AddAttribute(kActorDamageAttributeHealth, mod_value);
        }
        else if (damage_data_type_string == "physical_damage")
        {
          buff_link_data->event_data_damage_package->AddAttribute(kActorDamageAttributePhysical, mod_value);
        }
        else if (damage_data_type_string == "magical_damage")
        {
          buff_link_data->event_data_damage_package->AddAttribute(kActorDamageAttributeMagical, mod_value);
        }
        else
        {
          assert(false);
          buff_link_data->is_active = false;
          break;
        }
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModDamage][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->is_active = false;
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModDamage

} // namespace actor