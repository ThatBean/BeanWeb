#include "actor_buff_mod_number.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_config_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

namespace actor {

  //ActorBuffModNumber
  ActorBuffModTypedData ActorBuffModNumber::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    float result_number = 0.0f;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyNumber:
      {
        result_number = buff_mod_data->GetExecutedArgument(0).GetNumber();
      }
      break;
    case kActorBuffModKeyNumberFromActor:
      {
        Actor* actor = NULL;
        if (buff_mod_data->GetExecutedArgument(0).GetString() == "source_actor")
          actor = buff_link_data->actor_buff->GetActor();
        else if (buff_mod_data->GetExecutedArgument(0).GetString()  == "target_actor")
          actor = buff_link_data->actor_buff->GetActor()->GetActorExtEnv()->GetActorById(buff_link_data->skill_link_data.actor_id);
        else
          assert(false);

        if (!actor)
        {
          buff_link_data->is_active = false;
          break;
        }

        if (buff_mod_data->GetExecutedArgument(1).GetString() == "attribute")
          result_number = actor->GetActorData()->GetActorAttribute(ParseActorAttributeType(buff_mod_data->GetExecutedArgument(2).GetString()));
        else if (buff_mod_data->GetExecutedArgument(1).GetString()  == "status")
          result_number = actor->GetActorData()->GetActorStatus(ParseActorStatusType(buff_mod_data->GetExecutedArgument(2).GetString()));
        else
          assert(false);
      }
      break;
    case kActorBuffModKeyNumberFromSkill:
      {
        if (!buff_link_data->skill_link_data.skill_config_data)
        {
          buff_link_data->is_active = false;
          break;
        }

        if (buff_mod_data->GetExecutedArgument(0).GetString() == "skill_level_damage")\
        {
          result_number = buff_link_data->skill_link_data.skill_config_data->GetLevelAddDamage() * buff_link_data->skill_link_data.skill_level;
        }
        else
        {
          assert(false);
          buff_link_data->is_active = false;
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberFromDamage:
      {
        if (!buff_link_data->event_data_damage_package)
        {
          buff_link_data->is_active = false;
          break;
        }

        std::string& damage_data_type_string = buff_mod_data->GetExecutedArgument(0).GetString();
        
        if (damage_data_type_string == "total_health_damage")
        {
          result_number = buff_link_data->event_data_damage_package->GetDamage(0
            | kActorDamageAttributePhysical
            | kActorDamageAttributeMagical
            | kActorDamageAttributeHealth);
        }
        else if (damage_data_type_string == "physical_damage")
        {
          result_number = buff_link_data->event_data_damage_package->GetDamage(kActorDamageAttributePhysical);
        }
        else if (damage_data_type_string == "magical_damage")
        {
          result_number = buff_link_data->event_data_damage_package->GetDamage(kActorDamageAttributeMagical);
        }
        else
        {
          assert(false);
          buff_link_data->is_active = false;
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberFromPool:
      {
        if (!is_number_pool_)
        {
          number_pool_ = buff_mod_data->GetExecutedArgument(1).GetNumber();
        }

        float request_number = buff_mod_data->GetExecutedArgument(0).GetNumber();

        result_number = MIN(request_number, number_pool_);

        number_pool_ -= result_number;

        // mark buff expired
        if (number_pool_ <= 0) buff_link_data->is_active = false;
      }
      break;
    case kActorBuffModKeyNumberFromScript:
      {
        //not supported yet
        assert(false);
        buff_link_data->is_active = false;
      }
      break;
    case kActorBuffModKeyNumberMod:
      {
        float number_1 = buff_mod_data->GetExecutedArgument(1).GetNumber();
        float number_2 = buff_mod_data->GetExecutedArgument(2).GetNumber();

        if (buff_mod_data->GetExecutedArgument(0).GetString() == "add")
          result_number = number_1 + number_2;
        else if (buff_mod_data->GetExecutedArgument(0).GetString()  == "sub")
          result_number = number_1 - number_2;
        else if (buff_mod_data->GetExecutedArgument(0).GetString()  == "scale")
          result_number = number_1 * number_2;
        else if (buff_mod_data->GetExecutedArgument(0).GetString()  == "divide")
          if (number_2 == 0)
          {
            CCLog("[ActorBuffModNumber][Execute][kActorBuffModKeyNumberMod] error divide! number_2 == 0");
            assert(false);
            result_number = number_1;
          }
          else
          {
            result_number = number_1 / number_2;
          }
        else
        {
          assert(false);
          buff_link_data->is_active = false;
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberModByScript:
      {
        //not supported yet
        assert(false);
        buff_link_data->is_active = false;
      }
      break;
    default:
      CCLog("[ActorBuffModNumber][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->is_active = false;
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetNumber(kActorBuffModDataNumber, result_number);
    return result_data;
  }
  //ActorBuffModNumber

} // namespace actor