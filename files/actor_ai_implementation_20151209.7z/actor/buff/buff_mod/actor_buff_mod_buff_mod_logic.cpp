#include "actor_buff_mod_buff_mod_logic.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModLogic
  ActorBuffModTypedData ActorBuffModBuffModLogic::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyApplyIf:
      {
        bool is_apply = buff_mod_data->GetExecutedArgument(0).GetBool();

        if (is_apply)
        {
          ActorBuffModData* apply_buff_mod_data = buff_mod_data->GetExecutedArgument(1).GetBuffMod();
          GetActorBuffMod(apply_buff_mod_data->GetBuffModKeyType())->Execute(buff_link_data, apply_buff_mod_data);
        }
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModLogic][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->is_active = false;
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModLogic

} // namespace actor