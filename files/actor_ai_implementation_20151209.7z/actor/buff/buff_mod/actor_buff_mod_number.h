#ifndef ACTOR_BUFF_MOD_NUMBER_H
#define ACTOR_BUFF_MOD_NUMBER_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {

  class ActorBuffModNumber : public ActorBuffMod
  {
  public:
    ActorBuffModNumber(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
      , is_number_pool_(0.0f)
      , number_pool_(0.0f)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffModNumber; };

  private:
    bool is_number_pool_;
    float number_pool_;
  };

} // namespace actor


#endif // ACTOR_BUFF_MOD_NUMBER_H