#ifndef ACTOR_BUFF_MOD_BUFF_MOD_H
#define ACTOR_BUFF_MOD_BUFF_MOD_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {
  class ActorBuffModBuffMod : public ActorBuffMod
  {
  public:
    ActorBuffModBuffMod(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffModBuffMod; };
  };

} // namespace actor


#endif // ACTOR_BUFF_MOD_BUFF_MOD_H