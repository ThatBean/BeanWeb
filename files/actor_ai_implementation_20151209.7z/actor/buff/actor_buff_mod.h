#ifndef ACTOR_BUFF_MOD_H
#define ACTOR_BUFF_MOD_H

#include "game/actor/actor_adapter.h"
#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorBuff;
  class ActorBuffLinkData;

  class ActorBuffMod;
  class ActorBuffModData;

  //used for buff customization
  // value get
  // value set
  // simple logic


  //by return result type
  enum eActorBuffModDataType {
    //execute mod for value
    kActorBuffModDataBuffModBuffMod = 1, //a buff mod just need to be executed, result in another buff mod
    kActorBuffModDataBuffModNumber,  //a buff mod will generate a number
    kActorBuffModDataBuffModBool,  //a buff mod will generate a bool
    kActorBuffModDataBuffModString,  //a buff mod will generate a string

    //direct usable value
    kActorBuffModDataBuffMod,
    kActorBuffModDataNumber,
    kActorBuffModDataBool,
    kActorBuffModDataString,
    
    //mark for parsing, represent 0 ~ n count of execute/direct value, stop till one or more empty value is meet
    kActorBuffModDataMoreBuffMod,
    kActorBuffModDataMoreNumber,
    kActorBuffModDataMoreBool,
    kActorBuffModDataMoreString,

    kActorBuffModData = -1
  };


  enum eActorBuffModKeyType {
    kActorBuffModKeyNumber = 1,
    
    kActorBuffModKeyNumberFromActor,
    kActorBuffModKeyNumberFromSkill,
    kActorBuffModKeyNumberFromDamage,
    kActorBuffModKeyNumberFromPool,
    kActorBuffModKeyNumberFromScript,

    kActorBuffModKeyNumberMod,
    kActorBuffModKeyNumberModByScript,

    kActorBuffModKeyBoolNot,
    kActorBuffModKeyBoolNumber,
    kActorBuffModKeyBoolExistStatus,

    kActorBuffModKeyApplyIf,

    kActorBuffModKeyActorAttributeMod,
    kActorBuffModKeyActorStatusMod,
    kActorBuffModKeyActorPositionMod,

    kActorBuffModKeyDamageMod,

    kActorBuffModKeyStatusAdd,
    kActorBuffModKeyStatusImmune,
    kActorBuffModKeyStatusRemove,

    kActorBuffModKeyBuffAddById,
    kActorBuffModKeyBuffRemoveById,
    kActorBuffModKeyBuffRemoveByStatus,
    kActorBuffModKeyBuffRemoveByKeyword,
    kActorBuffModKeyBuffRemoveByType,

    kActorBuffModKeyScriptMod,

    kActorBuffModKey = -1
  };


  //packed typed data
  class ActorBuffModTypedData
  {
  public:
    ActorBuffModTypedData();
    ~ActorBuffModTypedData();

    ActorBuffModTypedData(const ActorBuffModTypedData& typed_data);

  public:
    void Clear();

    eActorBuffModDataType GetDataType() { return data_type_; }

    void SetBuffMod(eActorBuffModDataType data_type, ActorBuffModData* value);
    void SetNumber(eActorBuffModDataType data_type, float value);
    void SetBool(eActorBuffModDataType data_type, bool value);
    void SetString(eActorBuffModDataType data_type, std::string& value);

    ActorBuffModData* GetBuffMod(eActorBuffModDataType data_type = kActorBuffModDataBuffMod);
    float GetNumber(eActorBuffModDataType data_type = kActorBuffModDataNumber);
    bool GetBool(eActorBuffModDataType data_type = kActorBuffModDataBool);
    std::string& GetString(eActorBuffModDataType data_type = kActorBuffModDataString);

  private:
    eActorBuffModDataType data_type_;

    ActorBuffModData* data_buff_mod_data_;
    float data_number_;
    bool data_bool_;
    std::string data_string_;
  };




  //data store
  class ActorBuffModData
  {
  public:
    ActorBuffModData(eActorBuffModDataType buff_mod_data_type, eActorBuffModKeyType buff_mod_key_type);
    ~ActorBuffModData();

    ActorBuffModData(const ActorBuffModData& buff_mod_data);

    virtual void Clear();

    virtual void AppendArgument(ActorBuffModTypedData& argument); //no remove method

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data);  //will apply mod to linked actor

    virtual eActorBuffModDataType GetBuffModDataType() { return buff_mod_data_type_; }
    virtual eActorBuffModKeyType GetBuffModKeyType() { return buff_mod_key_type_; };

  public:
    virtual void ClearExecutedArgument();
    virtual void ExecuteArgument(ActorBuffLinkData* buff_link_data);  //will generate executed_argument_list(either direct copy or loop)

    virtual ActorBuffModTypedData& GetExecutedArgument(int index = 0);
    virtual std::list<ActorBuffModTypedData>& GetExecutedArgumentList() { return executed_argument_list_; }

  protected:
    eActorBuffModDataType buff_mod_data_type_;
    eActorBuffModKeyType buff_mod_key_type_;
    std::list<ActorBuffModTypedData> argument_list; //buff_key - buff_id | the buff related to this actor
    std::list<ActorBuffModTypedData> executed_argument_list_; //buff_key - buff_id | the buff related to this actor

  };




  //processor, packed logic
  class ActorBuffMod
  {
  public:
    ActorBuffMod(eActorBuffModKeyType buff_mod_key_type);

    virtual eActorBuffModDataType GetBuffModDataType() { assert(false); return kActorBuffModData; } //= 0;
    virtual eActorBuffModKeyType GetBuffModKeyType() { return buff_mod_key_type_; };

  public:
    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data) { assert(false); ActorBuffModTypedData typed_data; return typed_data; } //= 0;

  protected:
    eActorBuffModKeyType buff_mod_key_type_;

  };

  //the buff_mod_string_list will be consumed during parse(size change), but require delete it outside
  ActorBuffModData* ParseActorBuffModData(std::list<std::string>* buff_mod_string_list);

  ActorBuffMod* GetActorBuffMod(eActorBuffModKeyType buff_mod_key);
  ActorBuffModData* CreateActorBuffModData(eActorBuffModKeyType buff_mod_key);
} // namespace actor


#endif // ACTOR_BUFF_MOD_H