#include "actor_buff_mod.h"

#include "game/actor/buff/buff_mod/actor_buff_mod_number.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_bool.h"

//#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_actor.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_status.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_damage.h"


#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

/*
  Actor Buff Mod
    Buff is Data with Update or Event on an Actor, or what a Effect will create.
    Buff will always be added to an Actor
    Buff will interact with other existing Buff, and has replacement rules and stack rules

    Life Span:
      Init: 
        need: buff_id
        optional: source_effect_link(id + ...), source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update / OnEvent: 
        (may or may not), mod something

      Clear: 
        self removal, when time out, Buff replacement, or actor dead
*/


namespace actor {

  //ActorBuffModTypedData
  ActorBuffModTypedData::ActorBuffModTypedData()
  {
    Clear();
  }
  ActorBuffModTypedData::~ActorBuffModTypedData()
  {

  }


  ActorBuffModTypedData::ActorBuffModTypedData(const ActorBuffModTypedData& typed_data)
  {
    data_type_ = typed_data.data_type_;

    data_number_ = typed_data.data_number_;
    data_bool_ = typed_data.data_bool_;
    data_string_ = typed_data.data_string_;

    if (typed_data.data_buff_mod_data_)
      data_buff_mod_data_ = new ActorBuffModData(*(typed_data.data_buff_mod_data_));
    else
      data_buff_mod_data_ = NULL;
  }

  void ActorBuffModTypedData::Clear()
  {
    data_type_ = kActorBuffModData;

    data_buff_mod_data_ = NULL;
    data_number_ = 0.0f;
    data_bool_ = false;
    data_string_.clear();
  }

  void ActorBuffModTypedData::SetBuffMod(eActorBuffModDataType data_type, ActorBuffModData* value)
  {
    switch (data_type)
    {
    case kActorBuffModDataBuffModBuffMod:
    case kActorBuffModDataBuffModNumber:
    case kActorBuffModDataBuffModBool:
    case kActorBuffModDataBuffModString:
    case kActorBuffModDataBuffMod:
      Clear();
      data_type_ = data_type;
      data_buff_mod_data_ = value;
      break;
    default:
      assert(false);
      break;
    }
  }
  void ActorBuffModTypedData::SetNumber(eActorBuffModDataType data_type, float value)
  {
    switch (data_type)
    {
    case kActorBuffModDataNumber:
      Clear();
      data_type_ = data_type;
      data_number_ = value;
      break;
    default:
      assert(false);
      break;
    }
  }
  void ActorBuffModTypedData::SetBool(eActorBuffModDataType data_type, bool value)
  {
    switch (data_type)
    {
    case kActorBuffModDataBool:
      Clear();
      data_type_ = data_type;
      data_bool_ = value;
      break;
    default:
      assert(false);
      break;
    }
  }
  void ActorBuffModTypedData::SetString(eActorBuffModDataType data_type, std::string& value)
  {
    switch (data_type)
    {
    case kActorBuffModDataString:
      Clear();
      data_type_ = data_type;
      data_string_ = value;
      break;
    default:
      assert(false);
      break;
    }
  }

  ActorBuffModData* ActorBuffModTypedData::GetBuffMod(eActorBuffModDataType data_type/* = kActorBuffModDataBuffMod*/)
  {
    switch (data_type)
    {
    case kActorBuffModDataBuffModBuffMod:
    case kActorBuffModDataBuffModNumber:
    case kActorBuffModDataBuffModBool:
    case kActorBuffModDataBuffModString:
    case kActorBuffModDataBuffMod:
      assert(data_type_ = data_type);
      return data_buff_mod_data_;
    default:
      assert(false);
      return NULL;
    }
  }
  float ActorBuffModTypedData::GetNumber(eActorBuffModDataType data_type/* = kActorBuffModDataNumber*/)
  {
    switch (data_type)
    {
    case kActorBuffModDataNumber:
      assert(data_type_ = data_type);
      return data_number_;
    default:
      assert(false);
      return 0.0f;
    }
  }
  bool ActorBuffModTypedData::GetBool(eActorBuffModDataType data_type/* = kActorBuffModDataBool*/)
  {
    switch (data_type)
    {
    case kActorBuffModDataBool:
      assert(data_type_ = data_type);
      return data_bool_;
    default:
      assert(false);
      return false;
    }
  }
  std::string& ActorBuffModTypedData::GetString(eActorBuffModDataType data_type/* = kActorBuffModDataString*/)
  {
    switch (data_type)
    {
    case kActorBuffModDataString:
      assert(data_type_ = data_type);
      return data_string_;
    default:
      assert(false);
      return data_string_;
    }
  }
  //ActorBuffModTypedData




  //ActorBuffModData
  ActorBuffModData::ActorBuffModData(eActorBuffModDataType buff_mod_data_type, eActorBuffModKeyType buff_mod_key_type)
    : buff_mod_data_type_(buff_mod_data_type)
    , buff_mod_key_type_(buff_mod_key_type)
  {

  }

  ActorBuffModData::~ActorBuffModData()
  {
    Clear();
  }

  ActorBuffModData::ActorBuffModData(const ActorBuffModData& buff_mod_data)
  {
    Clear();

    buff_mod_data_type_ = buff_mod_data.buff_mod_data_type_;
    buff_mod_key_type_ = buff_mod_data.buff_mod_key_type_;
    argument_list = buff_mod_data.argument_list;
    //executed_argument_list_ = buff_mod_data.executed_argument_list_;  generated data, no copy
  }


  void ActorBuffModData::Clear()
  {
    for (std::list<ActorBuffModTypedData>::iterator iterator = argument_list.begin(); iterator != argument_list.end(); iterator ++)
    {
      eActorBuffModDataType data_type = iterator->GetDataType();

      switch (data_type)
      {
      case kActorBuffModDataBuffModBuffMod:
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
      case kActorBuffModDataBuffMod:
        delete iterator->GetBuffMod(data_type);
        iterator->Clear();
        break;
      default:
        break;
      }
    }

    ClearExecutedArgument();
  }

  void ActorBuffModData::ClearExecutedArgument()
  {
    for (std::list<ActorBuffModTypedData>::iterator iterator = executed_argument_list_.begin(); iterator != executed_argument_list_.end(); iterator ++)
    {
      eActorBuffModDataType data_type = iterator->GetDataType();

      switch (data_type)
      {
      case kActorBuffModDataBuffModBuffMod:
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
        delete iterator->GetBuffMod(data_type);
        iterator->Clear();
        break;
      default:
        break;
      }
    }
  }

  void ActorBuffModData::AppendArgument(ActorBuffModTypedData& argument)
  {
    argument_list.push_back(argument);
  }


  ActorBuffModTypedData ActorBuffModData::Execute(ActorBuffLinkData* buff_link_data)  //will apply mod to linked actor
  {
    ExecuteArgument(buff_link_data);
    return GetActorBuffMod(GetBuffModKeyType())->Execute(buff_link_data, this);
  }

  void ActorBuffModData::ExecuteArgument(ActorBuffLinkData* buff_link_data)
  {
    ClearExecutedArgument();

    for (std::list<ActorBuffModTypedData>::iterator iterator = argument_list.begin(); iterator != argument_list.end(); iterator ++)
    {
      ActorBuffModTypedData& typed_data = *iterator;

      switch (typed_data.GetDataType())
      {
      case kActorBuffModDataBuffModBuffMod:
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
        {
          ActorBuffModData* buff_mod_data = iterator->GetBuffMod(typed_data.GetDataType());
          buff_mod_data->ExecuteArgument(buff_link_data);
          executed_argument_list_.push_back(GetActorBuffMod(buff_mod_data->GetBuffModKeyType())->Execute(buff_link_data, buff_mod_data));
        }
        break;
      case kActorBuffModDataBuffMod:
      default:
        {
          executed_argument_list_.push_back(typed_data);
        }
        break;
      }
    }
  }


  ActorBuffModTypedData& ActorBuffModData::GetExecutedArgument(int index/* = 0*/)
  {
    assert(index < executed_argument_list_.size());

    std::list<ActorBuffModTypedData>::iterator iterator = executed_argument_list_.begin();
    while (iterator != executed_argument_list_.end() && index > 0)
    {
      iterator ++;
      index --;
    }
    ActorBuffModTypedData& typed_data = *iterator;
    return typed_data;
  }
  //ActorBuffModData



  //ActorBuffMod
  ActorBuffMod::ActorBuffMod(eActorBuffModKeyType buff_mod_key_type)
    : buff_mod_key_type_(buff_mod_key_type)
  {
    
  }
  //ActorBuffMod



  ActorBuffMod* get_actor_buff_mod(eActorBuffModKeyType buff_mod_key)
  {
    switch (buff_mod_key)
    {
    case kActorBuffModKeyNumber:
    case kActorBuffModKeyNumberFromActor:
    case kActorBuffModKeyNumberFromSkill:
    case kActorBuffModKeyNumberFromDamage:
    case kActorBuffModKeyNumberFromPool:
    case kActorBuffModKeyNumberFromScript:
    case kActorBuffModKeyNumberMod:
    case kActorBuffModKeyNumberModByScript:
      return new ActorBuffModNumber(buff_mod_key);
    case kActorBuffModKeyBoolNot:
    case kActorBuffModKeyBoolNumber:
    case kActorBuffModKeyBoolExistStatus:
      return new ActorBuffModBool(buff_mod_key);
    case kActorBuffModKeyApplyIf:
      return new ActorBuffMod(buff_mod_key);
    case kActorBuffModKeyActorAttributeMod:
    case kActorBuffModKeyActorStatusMod:
    case kActorBuffModKeyActorPositionMod:
      return new ActorBuffModBuffModActor(buff_mod_key);
    case kActorBuffModKeyDamageMod:
      return new ActorBuffModBuffModDamage(buff_mod_key);
    case kActorBuffModKeyStatusAdd:
    case kActorBuffModKeyStatusImmune:
    case kActorBuffModKeyStatusRemove:
      return new ActorBuffModBuffModStatus(buff_mod_key);
    case kActorBuffModKeyBuffAddById:
    case kActorBuffModKeyBuffRemoveById:
    case kActorBuffModKeyBuffRemoveByStatus:
    case kActorBuffModKeyBuffRemoveByKeyword:
    case kActorBuffModKeyBuffRemoveByType:
      return new ActorBuffMod(buff_mod_key);
    default:
      CCLog("[ActorBuffMod][get_actor_buff_mod] error buff_mod_key %d", buff_mod_key);
      assert(false);
      return NULL;
    }
  }

  ActorBuffMod* GetActorBuffMod(eActorBuffModKeyType buff_mod_key)
  {
    static std::map<eActorBuffModKeyType, ActorBuffMod*> actor_buff_mod_map;

    if (actor_buff_mod_map.find(buff_mod_key) == actor_buff_mod_map.end())
    {
      actor_buff_mod_map[buff_mod_key] = get_actor_buff_mod(buff_mod_key);
    }

    return actor_buff_mod_map[buff_mod_key];
  }




  ActorBuffModData* create_actor_buff_mod_data(eActorBuffModKeyType buff_mod_key)
  {
    switch (buff_mod_key)
    {
    case kActorBuffModKeyNumber:
    case kActorBuffModKeyNumberFromActor:
    case kActorBuffModKeyNumberFromSkill:
    case kActorBuffModKeyNumberFromDamage:
    case kActorBuffModKeyNumberFromPool:
    case kActorBuffModKeyNumberFromScript:
    case kActorBuffModKeyNumberMod:
    case kActorBuffModKeyNumberModByScript:
      return new ActorBuffModData(kActorBuffModDataNumber, buff_mod_key);
    case kActorBuffModKeyBoolNot:
    case kActorBuffModKeyBoolNumber:
    case kActorBuffModKeyBoolExistStatus:
      return new ActorBuffModData(kActorBuffModDataBool, buff_mod_key);
    case kActorBuffModKeyApplyIf:
    case kActorBuffModKeyActorAttributeMod:
    case kActorBuffModKeyActorStatusMod:
    case kActorBuffModKeyActorPositionMod:
    case kActorBuffModKeyDamageMod:
    case kActorBuffModKeyStatusAdd:
    case kActorBuffModKeyStatusImmune:
    case kActorBuffModKeyStatusRemove:
    case kActorBuffModKeyBuffAddById:
    case kActorBuffModKeyBuffRemoveById:
    case kActorBuffModKeyBuffRemoveByStatus:
    case kActorBuffModKeyBuffRemoveByKeyword:
    case kActorBuffModKeyBuffRemoveByType:
      return new ActorBuffModData(kActorBuffModDataBuffMod, buff_mod_key);
    default:
      CCLog("[ActorBuffMod][get_actor_buff_mod_data] error buff_mod_key %d", buff_mod_key);
      assert(false);
      return NULL;
    }
  }

  ActorBuffModData* CreateActorBuffModData(eActorBuffModKeyType buff_mod_key)
  {
    return create_actor_buff_mod_data(buff_mod_key);
  }


  eActorBuffModKeyType get_buff_mod_key(const std::string& source_string);
  std::list<eActorBuffModDataType>* get_buff_mod_argument_list(eActorBuffModKeyType buff_mod_key);
  bool parse_argument(ActorBuffModData* buff_mod_data, eActorBuffModDataType value_type, std::list<std::string>* buff_mod_string_list);  //true = need more, false = next one

  ActorBuffModData* ParseActorBuffModData(std::list<std::string>* buff_mod_string_list)
  {
    //flush "||||||" type empty string at beginning
    while (!buff_mod_string_list->empty() && buff_mod_string_list->begin()->empty())
    {
      buff_mod_string_list->pop_front();
    }

    if (buff_mod_string_list->empty())
    {
      return NULL;
    }

    eActorBuffModKeyType buff_mod_key = get_buff_mod_key(*(buff_mod_string_list->begin()));
    buff_mod_string_list->pop_front();

    ActorBuffModData* buff_mod_data = create_actor_buff_mod_data(buff_mod_key);

    std::list<eActorBuffModDataType>* buff_mod_argument_list = get_buff_mod_argument_list(buff_mod_key);

    std::list<eActorBuffModDataType>::iterator iterator = buff_mod_argument_list->begin();
    while(iterator != buff_mod_argument_list->end())
    {
      while (iterator != buff_mod_argument_list->end())
      {
        eActorBuffModDataType value_type = *iterator;

        bool is_more_needed = parse_argument(buff_mod_data, value_type, buff_mod_string_list);

        if (is_more_needed ==false)
        {
          break;
        }
        else
        {
          //special for "..." arguments
        }
      }

      //next arg
      iterator ++;
    }

    return buff_mod_data;
  }















  eActorBuffModKeyType get_buff_mod_key(const std::string& source_string)
  {
    if (source_string == "<number>")
      return kActorBuffModKeyNumber;

    else if (source_string == "<number_from_actor>")
      return kActorBuffModKeyNumberFromActor;
    else if (source_string == "<number_from_skill>")
      return kActorBuffModKeyNumberFromSkill;
    else if (source_string == "<number_from_damage>")
      return kActorBuffModKeyNumberFromDamage;
    else if (source_string == "<number_from_pool>")
      return kActorBuffModKeyNumberFromPool;
    else if (source_string == "<number_from_script>")
      return kActorBuffModKeyNumberFromScript;

    else if (source_string == "<number_mod>")
      return kActorBuffModKeyNumberMod;
    else if (source_string == "<number_mod_by_script>")
      return kActorBuffModKeyNumberModByScript;

    else if (source_string == "<bool_not>")
      return kActorBuffModKeyBoolNot;
    else if (source_string == "<bool_number>")
      return kActorBuffModKeyBoolNumber;
    else if (source_string == "<bool_exist_status>")
      return kActorBuffModKeyBoolExistStatus;

    else if (source_string == "<apply_if>")
      return kActorBuffModKeyApplyIf;

    else if (source_string == "<actor_attribute_mod>")
      return kActorBuffModKeyActorAttributeMod;
    else if (source_string == "<actor_status_mod>")
      return kActorBuffModKeyActorStatusMod;
    else if (source_string == "<actor_position_mod>")
      return kActorBuffModKeyActorPositionMod;

    else if (source_string == "<damage_mod>")
      return kActorBuffModKeyDamageMod;
    
    else if (source_string == "<status_add>")
      return kActorBuffModKeyStatusAdd;
    else if (source_string == "<status_immune>")
      return kActorBuffModKeyStatusImmune;
    else if (source_string == "<status_remove>")
      return kActorBuffModKeyStatusRemove;

    else if (source_string == "<buff_add_by_id>")
      return kActorBuffModKeyBuffAddById;
    else if (source_string == "<buff_remove_by_id>")
      return kActorBuffModKeyBuffRemoveById;
    else if (source_string == "<buff_remove_by_status>")
      return kActorBuffModKeyBuffRemoveByStatus;
    else if (source_string == "<buff_remove_by_keyword>")
      return kActorBuffModKeyBuffRemoveByKeyword;
    else if (source_string == "<buff_remove_by_type>")
      return kActorBuffModKeyBuffRemoveByType;

    else if (source_string == "<script_mod>")
      return kActorBuffModKeyScriptMod;

    else
    {
      CCLog("[ActorBuffMod][get_buff_mod_key] error source_string %s", source_string.c_str());
      assert(false);
      return kActorBuffModKey;
    }
  }




  std::list<eActorBuffModDataType>* get_buff_mod_argument_list(eActorBuffModKeyType buff_mod_key)
  {
    static std::map<eActorBuffModKeyType, std::list<eActorBuffModDataType> > buff_mod_argument_list_map;

    if (buff_mod_argument_list_map.empty())
    {
      buff_mod_argument_list_map[kActorBuffModKeyNumber].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromSkill].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromDamage].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromPool].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromPool].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromScript].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromScript].push_back(kActorBuffModDataMoreString);


      buff_mod_argument_list_map[kActorBuffModKeyNumberMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyNumberMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberModByScript].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyNumberModByScript].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberModByScript].push_back(kActorBuffModDataMoreString);


      buff_mod_argument_list_map[kActorBuffModKeyBoolNot].push_back(kActorBuffModDataBool);

      buff_mod_argument_list_map[kActorBuffModKeyBoolNumber].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyBoolExistStatus].push_back(kActorBuffModDataString);


      buff_mod_argument_list_map[kActorBuffModKeyApplyIf].push_back(kActorBuffModDataBool);
      buff_mod_argument_list_map[kActorBuffModKeyApplyIf].push_back(kActorBuffModDataBuffMod);


      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyActorStatusMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyActorStatusMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyActorPositionMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyActorPositionMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyActorPositionMod].push_back(kActorBuffModDataNumber);


      buff_mod_argument_list_map[kActorBuffModKeyDamageMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageMod].push_back(kActorBuffModDataNumber);


      buff_mod_argument_list_map[kActorBuffModKeyStatusAdd].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusAdd].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyStatusImmune].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusImmune].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyStatusRemove].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusRemove].push_back(kActorBuffModDataMoreString);


      buff_mod_argument_list_map[kActorBuffModKeyBuffAddById].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyBuffAddById].push_back(kActorBuffModDataMoreNumber);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveById].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveById].push_back(kActorBuffModDataMoreNumber);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByStatus].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByStatus].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByKeyword].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByKeyword].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByType].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByType].push_back(kActorBuffModDataMoreString);


      buff_mod_argument_list_map[kActorBuffModKeyScriptMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyScriptMod].push_back(kActorBuffModDataMoreString);
    }

    if (buff_mod_argument_list_map.find(buff_mod_key) != buff_mod_argument_list_map.end())
      return &(buff_mod_argument_list_map[buff_mod_key]);
    else
    {
      CCLog("[ActorBuffMod][get_buff_mod_argument_list] error buff_mod_key %d", buff_mod_key);
      assert(false);
      return NULL;
    }
  }



  bool parse_argument(ActorBuffModData* buff_mod_data, eActorBuffModDataType value_type, std::list<std::string>* buff_mod_string_list)  //true = need more, false = next one
  {
    if (buff_mod_string_list->empty())
    {
      return false;
    }

    //skip empty arg by default
    if (buff_mod_string_list->begin()->empty())
    {
      buff_mod_string_list->pop_front();
      return false;
    }

    std::string& buff_mod_string = *(buff_mod_string_list->begin());
    bool is_argument_buff_mod = ((!buff_mod_string.empty()) && (buff_mod_string.at(0) == '<')); //a "<_____" string means a buff mod

    ActorBuffModTypedData result_data;

    if (is_argument_buff_mod)
    {
      eActorBuffModDataType mod_value_type = kActorBuffModData;
      switch (value_type)
      {
      case kActorBuffModDataBuffMod:
      case kActorBuffModDataMoreBuffMod:
        mod_value_type = kActorBuffModDataBuffModBuffMod;
        break;
      case kActorBuffModDataNumber:
      case kActorBuffModDataMoreNumber:
        mod_value_type = kActorBuffModDataBuffModNumber;
        break;
      case kActorBuffModDataBool:
      case kActorBuffModDataMoreBool:
        mod_value_type = kActorBuffModDataBuffModBool;
        break;
      case kActorBuffModDataString:
      case kActorBuffModDataMoreString:
        mod_value_type = kActorBuffModDataBuffModString;
        break;
      default:
        CCLog("[ActorBuffMod][parse_argument][argument_buff_mod] error value_type %d", value_type);
        assert(false);
        break;
      }
      result_data.SetBuffMod(mod_value_type, ParseActorBuffModData(buff_mod_string_list));
    }
    else
    {
      switch (value_type)
      {
      case kActorBuffModDataBuffMod:
      case kActorBuffModDataMoreBuffMod:
        result_data.SetBuffMod(kActorBuffModDataBuffMod, ParseActorBuffModData(buff_mod_string_list));
        assert(result_data.GetBuffMod(kActorBuffModDataBuffMod)->GetBuffModDataType() == kActorBuffModDataBuffMod);
        break;
      case kActorBuffModDataNumber:
      case kActorBuffModDataMoreNumber:
        result_data.SetNumber(kActorBuffModDataNumber, String2Float(*(buff_mod_string_list->begin())));
        buff_mod_string_list->pop_front();
        break;
      case kActorBuffModDataBool:
      case kActorBuffModDataMoreBool:
        result_data.SetBool(kActorBuffModDataBool, String2Bool(*(buff_mod_string_list->begin())));
        buff_mod_string_list->pop_front();
        break;
      case kActorBuffModDataString:
      case kActorBuffModDataMoreString:
        result_data.SetString(kActorBuffModDataString, *(buff_mod_string_list->begin()));
        buff_mod_string_list->pop_front();
        break;
      default:
        CCLog("[ActorBuffMod][parse_argument][argument_value] error value_type %d", value_type);
        assert(false);
        break;
      }
    }

    buff_mod_data->AppendArgument(result_data);

    switch (value_type)
    {
    case kActorBuffModDataMoreBuffMod:
    case kActorBuffModDataMoreNumber:
    case kActorBuffModDataMoreBool:
    case kActorBuffModDataMoreString:
      return true;
    default:
      return false;
    }
  }



} // namespace actor