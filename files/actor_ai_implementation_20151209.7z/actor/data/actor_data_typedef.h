#ifndef ACTOR_DATA_TYPEDEF_H
#define ACTOR_DATA_TYPEDEF_H

#include <string>
#include <bitset>

#define CALC_ARRAY_LEN_BY_SIZE_OF(array) ( sizeof( array ) / sizeof( array[0] ) )

namespace actor {

  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_CIRCLE = "attack_range_circle_red.png";
  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_BOX = "attack_red.png";


  const int ACTOR_INVALID_ID = -1;


  const float ACTOR_WEAK_THRESHOLD = 0.20f; //health ratio

  const float ACTOR_CONTROL_COUNTDOWN = 0.5f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_GUARD = 0.1f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_ATTACK = 0.05f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_DEAD = 1.5f; //control update interval, in second.


  const int GRID_Y_RANGE = 3;
  const int GRID_Y_RANGE_TOP = 1;
  const int GRID_Y_RANGE_MIDDLE = 2;
  const int GRID_Y_RANGE_BOTTOM = 3;
//   const int GRID_Y_RANGE_MIDDLE = (GRID_Y_RANGE_TOP + GRID_Y_RANGE) * 0.5;
//   const int GRID_Y_RANGE_BOTTOM = GRID_Y_RANGE_TOP + (GRID_Y_RANGE - 1);

  const int GRID_X_RANGE = 6;
  const int GRID_X_RANGE_LEFT = 1;
  //const float GRID_X_RANGE_MIDDLE = 3.5;
  const int GRID_X_RANGE_RIGHT = 6;
  const int GRID_X_RANGE_LEFT_MIDDLE = 2;
  const int GRID_X_RANGE_RIGHT_MIDDLE = 5;
//   const float GRID_X_RANGE_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE) * 0.5;
//   const int GRID_X_RANGE_RIGHT = GRID_X_RANGE_LEFT + (GRID_X_RANGE - 1);
//   const int GRID_X_RANGE_LEFT_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE_MIDDLE) * 0.5;
//   const int GRID_X_RANGE_RIGHT_MIDDLE = (GRID_X_RANGE_MIDDLE + GRID_X_RANGE_RIGHT) * 0.5;


  // for player controlled actor in PVE
  const int PLAYER_IDLE_VALID_GRID_X_RANGE = 4;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = 4;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = 3;
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = GRID_X_RANGE_LEFT + (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = GRID_X_RANGE_RIGHT - (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);


  const float ACTOR_DIRECTION_CHANGE_THRESHOLD = 20;  //the minimum distance needed for a direction change

  const float ACTOR_ANIMATION_HEALTH_DISPLAY_TIME = 2.0f; //The health display time

} // namespace actor


namespace actor {

  enum eActorModuleType
  {
    kActorModuleScriptExporter  = 1 << 0,
    kActorModuleData            = 1 << 1,
    kActorModuleAnimation       = 1 << 2,
    kActorModuleControl         = 1 << 3,
    kActorModuleLogic           = 1 << 4,
    kActorModuleMotion          = 1 << 5,
    kActorModuleSkill           = 1 << 6,
    kActorModuleBuff            = 1 << 7,

    kActorModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_MODEL_ACTOR = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleSkill
    | kActorModuleBuff
    | 0;

  const unsigned long ACTOR_MODEL_EFFECT = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | kActorModuleAnimation
    | 0;

  const unsigned long ACTOR_MODEL_DATA = 0
    | kActorModuleData
    | kActorModuleScriptExporter
    | 0;


  //data dependency
  const unsigned long ACTOR_DATA_DEPENDENCY_BASIC = 0
    | kActorModuleLogic
    | kActorModuleMotion
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_SKILL = 0
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleSkill
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_BUFF = 0
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_DAMAGE = 0
    | kActorModuleAnimation
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_CONTROL = 0
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleBuff
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleScriptExporter
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_LOGIC = 0
    | kActorModuleLogic
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_MOTION = 0
    | kActorModuleMotion
    | 0;


  enum eActorAnimationModuleType
  {
    kActorAnimationModuleSkeletonAnimation  = 1 << 0,
    kActorAnimationModuleOverheadLayer      = 1 << 1,
    kActorAnimationModuleBottomSyncLayer    = 1 << 2,
    kActorAnimationModuleEffect             = 1 << 3,
    //kActorAnimationModule = 1 << 0,
    kActorAnimationModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR = 0
    | kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleOverheadLayer
    | kActorAnimationModuleBottomSyncLayer
    | 0;

  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR_LITE = 0
    | kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleOverheadLayer
    | 0;

  const unsigned long ACTOR_ANIMATION_MODEL_EFFECT = 0
    | kActorAnimationModuleEffect
//     | kActorAnimationModuleOverheadLayer
//     | kActorAnimationModuleBottomSyncLayer
    | 0;

  const unsigned long ACTOR_ANIMATION_MODEL_DATA = 0
//     | kActorAnimationModuleSkeletonAnimation
//     | kActorAnimationModuleOverheadLayer
//     | kActorAnimationModuleBottomSyncLayer
    | 0;

}



namespace actor {
  
  //BELOW WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //BELOW WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //BELOW WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]

  enum eActorModelType
  {
    kActorModelActor = ACTOR_MODEL_ACTOR,
    kActorModelEffect = ACTOR_MODEL_EFFECT,
    kActorModelData = ACTOR_MODEL_DATA,
    //kActorModel = 1 << 0,
    kActorModel = -1
  };

  enum eActorAnimationModelType
  {
    kActorAnimationModelActor = ACTOR_ANIMATION_MODEL_ACTOR,
    kActorAnimationModelActorLite = ACTOR_ANIMATION_MODEL_ACTOR_LITE,
    kActorAnimationModelEffect = ACTOR_ANIMATION_MODEL_EFFECT,
    kActorAnimationModelData = ACTOR_ANIMATION_MODEL_DATA,
    //kActorAnimationModel = 1 << 0,
    kActorAnimationModel = -1
  };

  enum eActorDataClassType
  {
    kActorDataClassAttribute = 1,
    kActorDataClassStatus,
    kActorDataClassPosition,
    kActorDataClass = -1
  };

  
  //from 1 to 9999
  enum eActorAttributeType  //independent float value
  {
    kActorAttributeInvalid = 0, //min

    //basic
    kActorAttributeTimeActive,
    
    //Health & Energy
    kActorAttributeHealthMax,  //normal
    kActorAttributeHealthCurrent,  //battle only
    kActorAttributeHealthRecover,  //recover per second, dispense by 0.2sec

    kActorAttributeEnergyMax,
    kActorAttributeEnergyCurrent,
    kActorAttributeEnergyRecover,

    //Factor
    kActorAttributeFactorCritical,
    kActorAttributeFactorCriticalResist,
    kActorAttributeFactorCriticalExtra,

    kActorAttributeFactorHit,

    kActorAttributeFactorDodge,
    kActorAttributeFactorDodgeExtra,

    kActorAttributeFactorDamageAdjust,
    kActorAttributeFactorDamageAdjustResist,
    kActorAttributeFactorDamageAdjustExtra,

    kActorAttributeFactorSkillDamage,
    kActorAttributeFactorSkillDamageResist,

    //Speed
    kActorAttributeSpeedAttack,
    kActorAttributeSpeedMove,

    //Damage Related
    kActorAttributeAttackPhysical,
    kActorAttributeAttackMagical,
    kActorAttributeAttackCritical,

    kActorAttributeDefensePhysical,
    kActorAttributeDefenseMagical,
    kActorAttributeDefenseCritical,

    //Trigger Related
    kActorAttributeTriggerSizeScaleAttack,
    kActorAttributeTriggerSizeScaleGuard,

    kActorAttributeAttackAreaRadius, //by the number of grid, not pixel
    kActorAttributeAttackAreaWidth, //by the number of grid, not pixel
    kActorAttributeAttackAreaHeight, //by the number of grid, not pixel

    kActorAttributeGuardAreaRadius, //by the number of grid, not pixel
    kActorAttributeGuardAreaWidth, //by the number of grid, not pixel
    kActorAttributeGuardAreaHeight, //by the number of grid, not pixel

    //kActorAttributeDamage,
    kActorAttributeDamageAddition,  //for all kinds, applied last
    kActorAttributeDamageAdditionPhysical,
    kActorAttributeDamageAdditionMagical,
    kActorAttributeDamageAdditionCritical,
    kActorAttributeDamageAdditionHealth,
    kActorAttributeDamageAdditionEnergy,

    kActorAttributeDamageReduction, //for all kinds, applied last
    kActorAttributeDamageReductionPhysical,
    kActorAttributeDamageReductionMagical,
    kActorAttributeDamageReductionCritical,
    kActorAttributeDamageReductionHealth,
    kActorAttributeDamageReductionEnergy,

    kActorAttributeLogicInvalid = 1000,

    kActorAttributeMotionInvalid = 2000,

    kActorAttributeControlInvalid = 3000,

    kActorAttributeBuffInvalid = 4000,

    kActorAttributeSkillInvalid = 5000,
    kActorAttributeAttackCount,
    kActorAttributeAttackNormalCount,
    kActorAttributeAttackPowerCount,
    kActorAttributeAttackSpecialCount,

    kActorAttributeAnimationInvalid = 6000,
    kActorAttributeAnimationScale,

    kActorAttributeSpecifiedInvalid = 7000,

    kActorAttribute = 9999  //max
  };


  //from 10000 to 19999
  enum eActorStatusType  //independent bool/enum/int value
  {
    kActorStatusInvalid = 10000,  //min
    
    //Basic
    kActorStatusActorId,  //actor_id access for actor_data, for actor, use script object id
    kActorStatusActorModel, //eActorModelType
    kActorStatusAnimationModel, //eActorAnimationModelType

    kActorStatusCardId,
    kActorStatusEffectConfigId, //for ExtEffect - Actor
    kActorStatusLevel,
    kActorStatusAppearance,
    kActorStatusFaction,
    kActorStatusCareer,

    kActorStatusGuardAreaType, //eActorPredefinedGuardTriggerType
    kActorStatusAttackAreaType, //eActorPredefinedAttackTriggerType

    kActorStatusLogicState,
    kActorStatusMotionState,

    kActorStatusCauseOfDeath, // COD

    kActorStatusIsDisableUserOperation, //accept manual control, use to mute ally switch

    //AcceptDamage(Immune = do not accept)
    kActorStatusAcceptDamage,
    kActorStatusAcceptDamagePhysical,
    kActorStatusAcceptDamageMagical,
    kActorStatusAcceptDamageCritical,
    kActorStatusAcceptDamageIce,
    kActorStatusAcceptDamageFire,
    kActorStatusAcceptDamageWind,

    //Logic & Motion
    kActorStatusLogicInvalid = 11000,
    kActorStatusLogicIsIncontrollable,
    kActorStatusLogicCanMove,
    kActorStatusLogicCanAttack,
    kActorStatusLogicCanAttackNormal,
    kActorStatusLogicCanAttackPower,
    kActorStatusLogicCanAttackSpecial,

    kActorStatusMotionInvalid = 12000,
    kActorStatusMotionIsBusy,  //IsMotionAnimationEnded

    kActorStatusControlInvalid = 13000,
    kActorStatusControlIsAuto,
    kActorStatusControlIsManual,
    kActorStatusControlIsCounterAttack,
    kActorStatusControlAutoGuardType,
    kActorStatusControlAutoReleaseSpecialSkillType,
    kActorStatusControlAutoReleaseSpecialSkillCount,
    kActorStatusControlAutoReleaseSpecialSkillProbability,

    kActorStatusBuffInvalid = 14000,
    kActorStatusBuffShaderType,
    kActorStatusBuffIsPauseAnimation,
    kActorStatusBuffIsChangeColor,

    kActorStatusSkillInvalid = 15000,
    kActorStatusSkillCurrentSkillId,
    kActorStatusSkillIsBusy,
    kActorStatusSkillIsPaused,
    kActorStatusSkillGuardType,
    kActorStatusSkillAttackType,

    kActorStatusAnimationInvalid = 16000,
    kActorStatusAnimationIsPaused,
    kActorStatusAnimationIsFocused,
    kActorStatusAnimationDirection,
    kActorStatusAnimationIsHealthChanged,

    kActorStatusSpecifiedInvalid = 17000,
    kActorStatusSpecifiedHomeDirection,
    kActorStatusSpecifiedIsLimitGridX,

    kActorStatusLinkInvalid = 19000,  //for data link back to source(where this Actor is created)
    kActorStatusLinkScriptObjectId,  //--> Reference to ExtEnv, dynamic data
    kActorStatusLinkScriptObjectIdActor,
    kActorStatusLinkScriptObjectIdBuff,
    //kActorStatusLinkScriptObjectIdSkill,  //not yet
    kActorStatusLinkScriptObjectIdEffect,
    
    kActorStatusLinkDataIdActor,  //--> Reference to Data Table, static data
    kActorStatusLinkDataIdBuff,
    kActorStatusLinkDataIdSkill,
    kActorStatusLinkDataIdEffect,

    kActorStatusLinkLevelActor, //quick access, record and prevent dynamic data lost(actor unlink)
    kActorStatusLinkLevelSkill,

    kActorStatus = 19999  //max
  };


  //from 20000 to 29999
  enum eActorPositionType  //independent CCPoint value
  {
    kActorPositionInvalid = 20000,  //min

    //Info
    kActorPositionAnimation,  // will apply to ActorNode in Animation update, so use as ActorPosition
    kActorPositionTargetGridBorn,  // for actor routine - Born

    kActorPositionLogicInvalid = 21000,

    kActorPositionMotionInvalid = 22000,
    kActorPositionMotionMoveTarget,     //  Target move position
    kActorPositionMotionMoveSpeedUnit,     // Normalized speed vector(the Direction)

    kActorPositionControlInvalid = 23000,
    
    kActorPositionBuffInvalid = 24000,

    kActorPositionSkillInvalid = 25000,

    kActorPositionAnimationInvalid = 26000,

    kActorPositionSpecifiedInvalid = 27000,
    //kActorPositionSpecifiedLastIdleGrid,

    kActorPosition = 29999  //max
  };


  enum eActorAppearanceType
  {
    kActorAppearanceCharacter = 1,
    kActorAppearanceEnemyPawn,
    kActorAppearanceEnemyBoss,
    kActorAppearance = -1
  };

  enum eActorFactionType
  {
    kActorFactionUserSupport  = 1 << 0,    //where user are
    kActorFactionUserOppose   = 1 << 1,   //who attacks user
    kActorFactionNeutral      = (1 << 0) + (1 << 1), //usually for some special actor that doesn't attack, or attack both
    kActorFaction             = -1
  };

  enum eActorCareerType
  {
    kActorCareerWarrior = 1,
    kActorCareerKnight,
    kActorCareerPriest,
    kActorCareerWizard,
    kActorCareerArcher,
    kActorCareer = -1
  };

  enum eActorAnimationDirection
  {
    kActorAnimationDirectionLeft = 1,
    kActorAnimationDirectionRight,
    kActorAnimationDirection = -1
  };

  enum eActorGuardType
  {
    kActorGuardMelee = 1, //Circle
    kActorGuardRanged, //Rectangle front & same row
    kActorGuard = -1
  };

  enum eActorEnergyType
  {
    kActorEnergyMana = 1,
    kActorEnergyAnger,
    kActorEnergy = -1,
  };

  enum eActorAttackType
  {
    kActorAttackMelee   = 1 << 0,
    kActorAttackRanged  = 1 << 1,
    kActorAttackHeal    = 1 << 2,
    kActorAttack = 0
  };

  enum eActorSkillType
  {
    kActorSkillNormal   = 1 << 0,
    kActorSkillPower    = 1 << 1,
    kActorSkillSpecial  = 1 << 2,
    kActorSkillBornWith = 1 << 3, //auto release at born
    kActorSkillOverload = 1 << 4,
    kActorSkill = 0
  };

  enum eActorEmitType {
    kActorEmitEffectTimeline = 1,
    kActorEmitBuff,

    kActorEmit = -1
  };

  enum eActorAnimationType {
    kActorAnimationNone = 1,
    kActorAnimationEffectId,
    kActorAnimationArmatureName,
    kActorAnimationProjectileName,

    kActorAnimation = -1
  };

  enum eActorAnimationLayerType {
    kActorAnimationLayerTop = 1,
    kActorAnimationLayerActor,
    kActorAnimationLayerBottom,

    kActorAnimationLayer = -1
  };

  enum eActorAnimationDisplayType {
    kActorAnimationDisplayAboveActor = 1,
    kActorAnimationDisplayOnActor,
    kActorAnimationDisplayBelowActor,

    kActorAnimationDisplay = -1
  };


  enum eActorMovementOriginType {
    kActorMovementOriginSourceActorLocation = 1,
    kActorMovementOriginSourceActorAttackAnchor,
    kActorMovementOriginScreenCenter,

    kActorMovementOrigin = -1
  };
  
  enum eActorMovementType {
    kActorMovementNone = 1,
    kActorMovementTagActor,
    kActorMovementLine,
    kActorMovementHoming,

    kActorMovement = -1
  };

  enum eActorEffectTimelineDirectionReferenceType {
    kActorEffectTimelineDirectionReferenceFixRight = 1,
    kActorEffectTimelineDirectionReferenceActorFront,

    kActorEffectTimelineDirectionReference = -1
  };

  enum eActorEffectConfigTriggerRangeType {
    kActorEffectConfigTriggerRangeAll = 1,
    kActorEffectConfigTriggerRangeCircle,
    kActorEffectConfigTriggerRangeRectangle,

    kActorEffectConfigTriggerRange = -1
  };
  
  enum eActorBuffConfigApplyType {
    kActorBuffConfigApplyTimeDuration   = 1 << 0,
    kActorBuffConfigApplyTimeTick       = 1 << 1,
    kActorBuffConfigApplyEvent          = 1 << 2,

    kActorBuffConfigApply = 0
  };

  enum eActorBuffConfigReplaceType {
    kActorBuffConfigReplaceAddNew = 1,
    kActorBuffConfigReplaceReplacePrevious,

    kActorBuffConfigReplace = -1
  };

  enum eActorBuffConfigStackType {
    kActorBuffConfigStackDropNew = 1,
    kActorBuffConfigStackCreate,
    kActorBuffConfigStackMerge,

    kActorBuffConfigStack = -1
  };


  //each status represents on, off, immune
  enum eActorBuffStatusStateType {
    kActorBuffStatusStateAdd = 1,
    kActorBuffStatusStateSub,
    kActorBuffStatusStateImmuneAdd,
    kActorBuffStatusStateImmuneSub,

    kActorBuffStatusState = -1
  };

  enum eActorBuffStatusType {
    kActorBuffStatusDebug = 1,

    //kActorBuffStatusAll,

    kActorBuffStatusAutoMove,
    kActorBuffStatusMuteMove,
    
    //kActorBuffStatusMuteAttack,
    kActorBuffStatusMuteAttackNormal,
    kActorBuffStatusMuteAttackPower,
    kActorBuffStatusMuteAttackSpecial,

    //kActorBuffStatusMuteReceiveDamageAll,
    kActorBuffStatusMuteReceiveDamagePhysical,
    kActorBuffStatusMuteReceiveDamageMagical,


    kActorBuffStatusBlind,
    kActorBuffStatusFear,
    kActorBuffStatusFreeze,
    kActorBuffStatusInvisible,
    kActorBuffStatusPetrify,
    kActorBuffStatusSlience,
    kActorBuffStatusStun,
    kActorBuffStatusCharmed,
    kActorBuffStatusInterwine,

    //kActorBuffStatus,

    kActorBuffStatusMax,

    kActorBuffStatus = -1
  };

  //should be enough for 
  typedef std::bitset<kActorBuffStatusMax> ActorBuffStatusBitSet;

  enum eActorDamageAttributeType
  {
    //basic
    kActorDamageAttributeFactorDamageAdjustRate = 1,
    kActorDamageAttributeFactorCriticalExtendRate = 2,
    kActorDamageAttributeFactorDamageExtendRate = 3,
    //kActorDamageAttributeFactor

    kActorDamageAttributePhysical  = 1 << 8,
    kActorDamageAttributeMagical   = 1 << 9,  //mix of Elemental?
    kActorDamageAttributeCritical  = 1 << 10,

    //modify directly
    kActorDamageAttributeHealth    = 1 << 11,   //Should be Healing, and should have (damage_value < 0)
    kActorDamageAttributeEnergy    = 1 << 12,   //Should be Energy Charging, and should have (damage_value < 0)

    //for calculation
    kActorDamageAttribute = 0,
  };

  //priority of control
  //need to keep update in lua
  enum eActorControlPriority
  {
    kActorControlPriorityMin = 0,

    kActorControlPriorityCheckGuardAuto, //skill check guard(result in auto move to target)

    kActorControlPriorityMoveAuto,

    kActorControlPriorityCheckAttackAuto, //skill check attack(result in auto normal attack)
    kActorControlPriorityCounterAttackAuto, //commit counter attack priority

    kActorControlPriorityAttackNormalAuto,
    kActorControlPriorityAttackNormalManual,
    
    kActorControlPriorityMoveManual,  //user move operation priority

    kActorControlPriorityAttackPowerAuto,
    kActorControlPriorityAttackSpecialAuto,
    kActorControlPriorityAttackSpecialManual,

    kActorControlPriorityIncontrollable,  //normally max priority

    kActorControlPriorityMax,

    kActorControlPriority = -1
  };

  //ABOVE WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //ABOVE WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]
  //ABOVE WILL BE EXPORTED TO LUA IN [actor_data_typedef.pkg]



  enum eActorControlAutoGuardType
  {
    kActorControlAutoGuardInvalid = -1,
    kActorControlAutoGuardDefault = 1,
    kActorControlAutoGuardPreferY,  //will first respond to enemy with same grid Y
    kActorControlAutoGuard = -1
  };


  enum eActorControlAutoReleaseSkillType
  {
    kActorControlAutoReleaseSkillInvalid = -1,
    kActorControlAutoReleaseSkillNoPause = 1,
    kActorControlAutoReleaseSkillWithPause,
    kActorControlAutoReleaseSkillWithProbability,
    kActorControlAutoReleaseSkillByAttackCount,
    kActorControlAutoReleaseSkill = -1
  };


  enum eActorControlIncontrollableType  //the reason why the actor is incontrollable
  {
    kActorControlIncontrollableBuff = 1,
    kActorControlIncontrollableSkill,
    kActorControlIncontrollableScript,
    kActorControlIncontrollableOther,
    kActorControlIncontrollable = -1
  };


  enum eActorDamageStatusType
  {
    kActorDamageStatusCountAddProcessActor = 1,
    kActorDamageStatusCountSubProcessActor,

    kActorDamageStatusIsMissed,
    kActorDamageStatusIsCritical,

    kActorDamageStatusIsSuicide,
    kActorDamageStatusIsHeal,
    
    kActorDamageStatusSourceActorId,
    kActorDamageStatusSourceActorLevel,

    kActorDamageStatusSourceSkillId,
    kActorDamageStatusSourceSkillLevel,
    kActorDamageStatusSourceSkillType,

    kActorDamageStatusSourceBuffId,
    kActorDamageStatusSourceEffectId,

    kActorDamageStatusTargetActorId,

    kActorDamageStatus = 0
  };



  class EmitIdData
  {
  public:
    EmitIdData()
      : id(ACTOR_INVALID_ID)
      , type(kActorEmit)
      , fail_chance(0.0f)
    {}

    int id;
    eActorEmitType type;
    float fail_chance;
  };


  class EffectTimelineAnimationData
  {
  public:
    EffectTimelineAnimationData()
      : id(ACTOR_INVALID_ID)
      , animation_type(kActorAnimation)
      , layer_type(kActorAnimationLayer)
    {}

    int id;
    std::string name;
    eActorAnimationType animation_type;
    eActorAnimationLayerType layer_type;
  };


  typedef struct tActorSkillMovementData {
    std::string movement_name;
    float speed_scale;
  } ActorSkillMovementData;
  

  typedef struct tActorSkillInfo {
    tActorSkillInfo()
      : skill_id(ACTOR_INVALID_ID)
      , skill_type(kActorSkill)
      , skill_level(0)
      , skill_damage_scale(0.0f)
      , skill_cooldown(0.0f)
      , skill_cooldown_current(0.0f)
    {}

    tActorSkillInfo(const tActorSkillInfo& source)
      : skill_id(source.skill_id)
      , skill_type(source.skill_type)
      , skill_level(source.skill_level)
      , skill_damage_scale(source.skill_damage_scale)
      , skill_cooldown(source.skill_cooldown)
      , skill_cooldown_current(source.skill_cooldown_current)
    {}

    int skill_id;
    eActorSkillType skill_type;

    int skill_level;
    float skill_damage_scale;

    float skill_cooldown; //value to reset to
    float skill_cooldown_current; //current cooldown
  } ActorSkillInfo;


  
  class ActorBuffConfigApplyData
  {
  public:
    ActorBuffConfigApplyData()
      : apply_flag(kActorBuffConfigApply)
      , is_temporary(false)
      , count_limit(-1)
      , time_duration(-1)
      , time_tick(-1)
    {}

    int apply_flag;
    
    bool is_temporary;

    int count_limit;
    
    //time_duration
    float time_duration;

    //time_tick
    float time_tick;
    
    //event
    std::string event_type;
    };


  enum eActorCauseOfDeath
  {
    kActorCauseOfDeathDefault = 1,  //default
    kActorCauseOfDeathDisappear,
    kActorCauseOfDeathTimeout,
    kActorCauseOfDeathSuicide,
    kActorCauseOfDeathExplode,

    kActorCauseOfDeath = -1,
  };


//   enum eActorIncontrollableMotionType
//   {
//     kActorIncontrollableMotionFreezed,  //Animation Stopped, No Move, No Direction Change
//     kActorIncontrollableMotionDelayed,  //Animation Idle, No Move, No Direction Change
//     kActorIncontrollableMotionRunHome,  //Animation Move, Move To Left/Right Most, Normal Direction Change
//     kActorIncontrollableMotionPushBack, //Animation Stopped, Move Backwards a little, No Direction Change
//     kActorIncontrollableMotion
//   };
// 
// 
//   enum eActorBuffColorType  //These Type will be converted to color or shader
//   {
//     kActorBuffColorFreezed,
//     kActorBuffColorOnFire,
//     kActorBuffColorPosioned,
//     kActorBuffColorShocked,
//     kActorBuffColorStoned,
//     kActorBuffColorEtc,
//     kActorBuffColor
//   };
// 
// 
//   enum eActorBuffAnimationType  //These will be overload animation, mostly used in motion Incontrollable
//   {
//     kActorBuffAnimationIdle,
//     kActorBuffAnimationMove,
//     kActorBuffAnimationAttacked,
//     kActorBuffAnimationEtc,
//     kActorBuffAnimation
//   };


} // namespace actor


#endif // ACTOR_DATA_TYPEDEF_H