#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#define DEFAULT_UPDATE_RECOVER_TICK_TIME 0.1

namespace actor {
  ActorBasicData::ActorBasicData(ActorData* actor_data)
    : actor_data_(actor_data)
    , time_recover_tick_(0.0f)
  {

  }


  void ActorBasicData::Update(float delta_time)
  { 
    actor_data_->AddActorAttribute(kActorAttributeTimeActive, delta_time);

    time_recover_tick_ += delta_time;

    float recover_health = 0.0f;
    float recover_energy = 0.0f;
    while (time_recover_tick_ > DEFAULT_UPDATE_RECOVER_TICK_TIME)
    {
      time_recover_tick_ -= DEFAULT_UPDATE_RECOVER_TICK_TIME;

      //apply recover
      recover_health += actor_data_->GetActorAttribute(kActorAttributeHealthRecover);
      recover_energy += actor_data_->GetActorAttribute(kActorAttributeEnergyRecover);
    }
    actor_data_->AddActorAttribute(kActorAttributeHealthCurrent, recover_health);
    actor_data_->AddActorAttribute(kActorAttributeEnergyCurrent, recover_energy);
  }

  void ActorBasicData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorAttributeData(kActorAttributeHealthCurrent)->Connect<ActorBasicData>(this, &ActorBasicData::OnDataOperation);
    actor_data_->GetActorAttributeData(kActorAttributeHealthMax)->Connect<ActorBasicData>(this, &ActorBasicData::OnDataOperation);

    actor_data_->GetActorAttributeData(kActorAttributeEnergyCurrent)->Connect<ActorBasicData>(this, &ActorBasicData::OnDataOperation);
    actor_data_->GetActorAttributeData(kActorAttributeEnergyMax)->Connect<ActorBasicData>(this, &ActorBasicData::OnDataOperation);
  }


  void ActorBasicData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

    switch (actor_data_type)
    {
    case kActorAttributeHealthCurrent:
    case kActorAttributeHealthMax:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            //limit value under max value
            float value_current = actor_data_->GetActorAttribute(kActorAttributeHealthCurrent);
            float value_max = actor_data_->GetActorAttribute(kActorAttributeHealthMax);

            if (value_current > value_max) actor_data_->SetActorAttribute(kActorAttributeHealthCurrent, value_max);
            if (value_current < 0) actor_data_->SetActorAttribute(kActorAttributeHealthCurrent, 0);

            actor_data_->SetActorStatusBool(kActorStatusAnimationIsHealthChanged, true);
          }
          break;
        }
      }
      break;
    case kActorAttributeEnergyCurrent:
    case kActorAttributeEnergyMax:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            //limit value under max value
            float value_current = actor_data_->GetActorAttribute(kActorAttributeEnergyCurrent);
            float value_max = actor_data_->GetActorAttribute(kActorAttributeEnergyMax);

            if (value_current > value_max) actor_data_->SetActorAttribute(kActorAttributeEnergyCurrent, value_max);
            if (value_current < 0) actor_data_->SetActorAttribute(kActorAttributeEnergyCurrent, 0);
          }
          break;
        }
      }
      break;
    }
  }


  //ActorBasicData

  const std::string ActorBasicData::DeadAnimationName()
  {
    return GetDeadAnimationName(actor_adapter_);
  }
  //ActorBasicData

} // namespace actor