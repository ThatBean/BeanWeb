#ifndef ACTOR_BASIC_DATA_H
#define ACTOR_BASIC_DATA_H

#include "../actor_data_typedef.h"
#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorDataSignalData;

  class ActorBasicData
  {
  public:
    ActorBasicData(ActorData* actor_data);

    void Update(float delta_time);

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);

    //currently in adapter

    const std::string DeadAnimationName();  //return dead animation name

    //messy but messy, link MoveObject data
    void SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }

  private:
    ActorData*    actor_data_;

    float         time_recover_tick_;

  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter* actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_BASIC_DATA_H