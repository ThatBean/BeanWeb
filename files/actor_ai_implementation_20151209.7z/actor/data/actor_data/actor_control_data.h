#ifndef ACTOR_CONTROL_DATA_H
#define ACTOR_CONTROL_DATA_H

#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;

  enum eActorControlOperationType {
    kActorControlOperationPositionMove = 1,
    //kActorControlOperationPositionAttack, //nonsense
    kActorControlOperationIdTargetMove,
    kActorControlOperationIdTargetAttack,
    kActorControlOperationIdSkill,
	kActorControlOperationTypeSkill,
    kActorControlOperationTypeIncontrollable,
    kActorControlOperation = 0
  };

  typedef struct sActorControlOperationData {
    eActorControlOperationType operation_type;
    eActorControlPriority priority;
    int data_id;
    cocos2d::CCPoint data_position;
  } ActorControlOperationData;

  //#########################################################################################################
  //#########################################################################################################
  class ActorControlData
  {
  public:
    ActorControlData();
    ~ActorControlData();
    
    virtual void    Update(float delta_time);

    virtual void    Reset();
    virtual bool    IsSetOperation();

    eActorControlPriority GetMaxPriority();
    eActorControlOperationType GetMaxPriorityOperationType();

    void AddIdOperation(eActorControlOperationType operation_type, eActorControlPriority priority, int data_id);
    void AddPositionOperation(eActorControlOperationType operation_type, eActorControlPriority priority, cocos2d::CCPoint data_position);
    
    ActorControlOperationData* GetOperationData(eActorControlOperationType operation_type);
    int               GetIdOperationData(eActorControlOperationType operation_type);
    cocos2d::CCPoint  GetPositionOperationData(eActorControlOperationType operation_type);

    bool CheckOperationData(eActorControlOperationType operation_type);
    bool CheckTopOperationData(eActorControlOperationType operation_type);  //check exist and top priority
    void RemoveOperationData(eActorControlOperationType operation_type);

    void              SetCountdown(float countdown) { countdown_ = countdown; }
    float             GetCountdown() { return countdown_; }
    void              UpdateCountdown(float delta_time) { countdown_ = (countdown_ <= delta_time ? 0 : countdown_ - delta_time); }
    void              ResetCountdown(float delta_time = ACTOR_CONTROL_COUNTDOWN) { countdown_ = delta_time; }

    void              ResetCountdownGuard() { countdown_ = ACTOR_CONTROL_COUNTDOWN_GUARD; }
    void              ResetCountdownAttack() { countdown_ = ACTOR_CONTROL_COUNTDOWN_ATTACK; }
    void              ResetCountdownDead() { countdown_ = ACTOR_CONTROL_COUNTDOWN_DEAD; }

    float             GetSkillCountdown() { return skill_countdown_; }
    void              UpdateSkillCountdown(float delta_time) { skill_countdown_ += delta_time; }
    void              ResetSkillCountdown() { skill_countdown_ = 0; }

  private:
    std::map<eActorControlOperationType, sActorControlOperationData> operation_data_map_;

    float             countdown_;
    float             skill_countdown_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_DATA_H