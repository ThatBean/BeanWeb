#ifndef ACTOR_DAMAGE_DATA_H
#define ACTOR_DAMAGE_DATA_H

#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;
  class ActorData;
  class DamagePackage;

  class ActorDamageData
  {
  public:
    ActorDamageData(ActorData* actor_data);
    ~ActorDamageData();

    //a way to share DamagePackage with Actor/Effect/Data
    void RegisterAddProcessActor(int actor_id);
    void UnRegisterAddProcessActor(int actor_id);
    void RegisterSubProcessActor(int actor_id);  
    void UnRegisterSubProcessActor(int actor_id);

    DamagePackage* AddProcess(DamagePackage* damage_package); // Recursively GenerateDamage + AddProcess
    DamagePackage* SubProcess(DamagePackage* damage_package); // Recursively SubProcess + ReceiveDamage

    DamagePackage* GenerateDamage(DamagePackage* damage_package);
    DamagePackage* ReceiveDamage(DamagePackage* damage_package);

    DamagePackage* NotifyDamageConsume(DamagePackage* damage_package, int consume_actor_id, eActorDamageAttributeType damage_attribute_type, float damage_value);
    DamagePackage* NotifyDamageResult(DamagePackage* damage_package);

    //messy but messy, link MoveObject data
    void SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }

  protected:
    //as skill releaser
    // [Process] actor -> skill -> buff(effect) -> final damage result
    //void AddActorBasicDamage(DamagePackage* damage_package);  //actor status
    void AddActorSkillDamage(DamagePackage* damage_package);  //skill

    //as damage holder
    // [Process] final damage result -> buff(effect) -> actor -> health change(mostly) & damage label
    void SubActorBasicDamage(DamagePackage* damage_package);

  private:
    ActorData*    actor_data_;

    std::list<int>  add_process_actor_id_list_; //modify damage before actually hit the actor
    std::list<int>  sub_process_actor_id_list_; //modify damage before actually hit the actor
  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*       actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };
} // namespace actor


#endif // ACTOR_DAMAGE_DATA_H