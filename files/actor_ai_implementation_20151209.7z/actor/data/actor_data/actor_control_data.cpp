#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorControlData
  ActorControlData::ActorControlData()
  {
    Reset();
  }

  ActorControlData::~ActorControlData()
  {
    Reset();
  }

  void ActorControlData::Reset()
  {
    operation_data_map_.clear();

    countdown_ = 0;
    skill_countdown_ = 0;
  }

  void ActorControlData::Update(float delta_time)
  {
    UpdateCountdown(delta_time);
    UpdateSkillCountdown(delta_time);
  }

  bool ActorControlData::IsSetOperation()
  {
    return operation_data_map_.size() > 0;
  }

  eActorControlPriority ActorControlData::GetMaxPriority()
  {
    eActorControlPriority max_priority = kActorControlPriorityMin;

    std::map<eActorControlOperationType, sActorControlOperationData>::iterator iterator = operation_data_map_.begin();
    while(iterator != operation_data_map_.end())
    {
      max_priority = max(max_priority, iterator->second.priority);
      iterator++;
    }

    return max_priority;
  }
  //  std::map<eActorControlOperationType, sActorControlOperationData> operation_data_map_;

  eActorControlOperationType ActorControlData::GetMaxPriorityOperationType()
  {
    eActorControlPriority max_priority = kActorControlPriorityMin;
    eActorControlOperationType max_priority_operation_type = kActorControlOperation;

    std::map<eActorControlOperationType, sActorControlOperationData>::iterator iterator = operation_data_map_.begin();
    while(iterator != operation_data_map_.end())
    {
      if (max_priority < iterator->second.priority)
      {
        max_priority = iterator->second.priority;
        max_priority_operation_type = iterator->first;
      }

      iterator++;
    }

    return max_priority_operation_type;
  }

  void ActorControlData::AddIdOperation(eActorControlOperationType operation_type, eActorControlPriority priority, int data_id)
  {
    if (operation_data_map_.find(operation_type) != operation_data_map_.end())
    {
      if (operation_data_map_[operation_type].priority > priority) return; //failed to replace
    }

    operation_data_map_[operation_type].operation_type = operation_type;
    operation_data_map_[operation_type].priority = priority;
    operation_data_map_[operation_type].data_id = data_id;
  }
  void ActorControlData::AddPositionOperation(eActorControlOperationType operation_type, eActorControlPriority priority, cocos2d::CCPoint data_position)
  {
    if (operation_data_map_.find(operation_type) != operation_data_map_.end())
    {
      if (operation_data_map_[operation_type].priority > priority) return; //failed to replace
    }

    operation_data_map_[operation_type].operation_type = operation_type;
    operation_data_map_[operation_type].priority = priority;
    operation_data_map_[operation_type].data_position = data_position;
  }


  ActorControlOperationData* ActorControlData::GetOperationData(eActorControlOperationType operation_type)
  {
    if (CheckOperationData(operation_type)) 
    {
      return &operation_data_map_[operation_type];
    }
    else 
    {
      assert(false);
      return NULL;
    }
  }
  int ActorControlData::GetIdOperationData(eActorControlOperationType operation_type)
  {
    if (CheckOperationData(operation_type)) 
    {
      return operation_data_map_[operation_type].data_id;
    }
    else 
    {
      assert(false);
      return ACTOR_INVALID_ID;
    }
  }
  cocos2d::CCPoint ActorControlData::GetPositionOperationData(eActorControlOperationType operation_type)
  {
    if (CheckOperationData(operation_type)) 
    {
      return operation_data_map_[operation_type].data_position;
    }
    else 
    {
      assert(false);
      return ccp(0, 0);
    }
  }


  bool ActorControlData::CheckOperationData(eActorControlOperationType operation_type)
  {
    return operation_data_map_.find(operation_type) != operation_data_map_.end();
  }
  bool ActorControlData::CheckTopOperationData(eActorControlOperationType operation_type)
  {
    return operation_data_map_.find(operation_type) != operation_data_map_.end() && operation_data_map_[operation_type].priority == GetMaxPriority();
  }
  void ActorControlData::RemoveOperationData(eActorControlOperationType operation_type)
  {
    operation_data_map_.erase(operation_type);
  }
  //ActorControlData



} // namespace actor