#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger.h"

namespace actor {
  //ActorData
  ActorData::ActorData(Actor* actor)
    :actor_(actor),
    basic_data_(NULL),
    skill_data_(NULL),
    buff_data_(NULL),
    damage_data_(NULL),
    control_data_(NULL),
    logic_data_(NULL),
    motion_data_(NULL),
    specified_data_(NULL)
  {
    default_attribute_signal_data_.actor_data = this;
    default_attribute_signal_data_.type = kActorDataClassAttribute;

    default_status_signal_data_.actor_data = this;
    default_status_signal_data_.type = kActorDataClassStatus;

    default_position_signal_data_.actor_data = this;
    default_position_signal_data_.type = kActorDataClassPosition;

    data_log_ = new DataLog;
    data_log_->SetMute(true);
  }

  ActorData::~ActorData()
  {
    ResetData();

    GetLog()->AddLog("[ActorData][~ActorData]");
    //GetLog()->ShowLog(-1);

    if (data_log_) delete data_log_;
  }

  void ActorData::Init(eActorModelType actor_model_type/* = kActorModelActor*/)
  {
    ResetData();

    if (actor_model_type & ACTOR_DATA_DEPENDENCY_BASIC) basic_data_ = new ActorBasicData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_SKILL) skill_data_ = new ActorSkillData(this, actor_);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_BUFF) buff_data_ = new ActorBuffData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_DAMAGE) damage_data_ = new ActorDamageData(this); // TODO: use it

    if (actor_model_type & ACTOR_DATA_DEPENDENCY_CONTROL) 
    {
      control_data_ = new ActorControlData();
    }

    if (actor_model_type & ACTOR_DATA_DEPENDENCY_LOGIC) logic_data_ = new ActorLogicData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_MOTION) motion_data_ = new ActorMotionData(this);

    InitActorStatus(kActorStatusActorId, actor_->GetScriptObjectId());
    InitActorStatus(kActorStatusActorModel, actor_model_type);

    ConnectDataSignal();  //link data signal

    GetLog()->SetId(actor_->GetScriptObjectId());

    GetLog()->AddLogF("[ActorData][Init] type:%s model:%d", actor_->GetScriptObjectType().c_str(), actor_model_type);
  }

  void ActorData::ResetData()
  {
    if (basic_data_) delete basic_data_;
    if (skill_data_) delete skill_data_;
    if (buff_data_) delete buff_data_;
    if (damage_data_) delete damage_data_;

    if (control_data_) delete control_data_;
    if (logic_data_) delete logic_data_;
    if (motion_data_) delete motion_data_;

    if (specified_data_) delete specified_data_;

    basic_data_ = NULL;
    skill_data_ = NULL;
    buff_data_ = NULL;
    damage_data_ = NULL;

    control_data_ = NULL;
    logic_data_ = NULL;
    motion_data_ = NULL;

    specified_data_ = NULL;

    GetLog()->AddLog("[ActorData][ResetData]");
    GetLog()->ResetStartTime();
  }

  void ActorData::ConnectDataSignal()
  {
    if (basic_data_) basic_data_->ConnectDataSignal();
    if (skill_data_) skill_data_->ConnectDataSignal();
    if (buff_data_) buff_data_->ConnectDataSignal();
    if (motion_data_) motion_data_->ConnectDataSignal();
  }

  void ActorData::Update(float delta_time)
  {
    //for Debug quick watch
    Actor* debug_actor = actor_;
    ActorData* debug_actor_data = this;
    
    if (basic_data_) basic_data_->Update(delta_time);
    if (control_data_) control_data_->Update(delta_time);
    if (specified_data_) specified_data_->Update(delta_time);
  }



  ActorSpecifiedData* ActorData::GetSpecifiedData()
  {
    if (specified_data_) return specified_data_;

    switch (GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      specified_data_ = new ActorSpecifiedDataCharacter(actor_);
      break;
    case kActorAppearanceEnemyPawn:
      specified_data_ = new ActorSpecifiedDataEnemyPawn(actor_);
      break;
    case kActorAppearanceEnemyBoss:
      specified_data_ = new ActorSpecifiedDataEnemyBoss(actor_);
      break;
    default:
      assert(false);
      specified_data_ = NULL;
      break;
    }

    return specified_data_;
  }


  void ActorData::SetActorAdapter(ActorAdapter* actor_adapter)
  {
    if (basic_data_) basic_data_->SetActorAdapter(actor_adapter);
    if (skill_data_) skill_data_->SetActorAdapter(actor_adapter);
    if (buff_data_) buff_data_->SetActorAdapter(actor_adapter);
    if (damage_data_) damage_data_->SetActorAdapter(actor_adapter);
  }

  //ActorData

} // namespace actor