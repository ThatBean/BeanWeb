#ifndef ACTOR_CONTROL_H
#define ACTOR_CONTROL_H

#include "game/actor/logic/actor_logic_state.h"

#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  class ActorControlData;
  class ActorTrigger;

  enum eActorControlType
  {
    kActorControlManual   = 1 << 0,   //will check user input
    kActorControlAuto     = 1 << 1,   //will issue command automatically
    kActorControlSemiAuto = (1 << 0) + (1 << 1),   //will issue command automatically
    kActorControl = 0
  };

  class ActorControl
  {
  public:
    ActorControl(Actor* actor);
    ~ActorControl();

    void Update(float delta_time);

    eActorLogicState DecideLogicState();  //check set priority
    bool ControlLogicStateChange(eActorLogicState next_logic_state_type); //check if exterior logic state change valid, if true, change

    void UpdateSpecialGuard(int type = 0);  // TODO: remove. //special guard for monster reaching the base line
  protected:
    void UpdateManual();
    void UpdateAuto();
    void UpdateStatus();

    //void UpdateAutoAttack();
    void UpdateAutoGuard();
    void UpdateAutoGuardMelee(ActorTrigger* guard_trigger);
    void UpdateAutoGuardMeleeX(ActorTrigger* guard_trigger);
    void UpdateAutoGuardMeleeY(ActorTrigger* guard_trigger);
    void UpdateAutoGuardRangedNearestX(ActorTrigger* guard_trigger);
    void UpdateAutoGuardRangedNearestY(ActorTrigger* guard_trigger);
    void UpdateAutoReleaseSpecialSkill();

    void ApplyAutoRangedPosition(bool is_grid_y_valid[]);
    void ApplyControlData(ActorControlData* from_control_data, ActorControlData* to_control_data);

  private:
    Actor*               actor_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_H
