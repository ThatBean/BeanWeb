#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H

#include "game/actor/data/actor_data_typedef.h"

#include "game/army/unit/move_object.h"

namespace actor {
  class ActorExtEnv;
  
  typedef taomee::army::MoveObject ActorAdapter;


  //Search the string for space(the ' ', '\n', '\r', '\t'), and remove it, NOTE: will change source string
  std::string& ActorStringRemoveSpace(std::string& source_string);

  //Split the string at characters that matches any of the characters specified in delimiter_string.
  //delimiter can be ",|. " for multi-match split
  std::list<std::string>* ActorStringSplit(const std::string& source_string, const std::string& delimiter);

  std::list<EmitIdData> ParseEmitIdDataList(const std::string& source_string);

  std::list<ActorSkillMovementData> ParseActorSkillMovementDataList(const std::string& source_string);

  EffectTimelineAnimationData ParseEffectTimelineAnimationData(const std::string& layer_string, const std::string& type_string, const std::string& name_string);

  ActorBuffConfigApplyData* ParseBuffConfigApplyData(const std::string& source_string);

  eActorAnimationType ParseAnimationType(const std::string& source_string);
  eActorAnimationLayerType ParseAnimationLayerType(const std::string& source_string);
  eActorMovementOriginType ParseMovementOriginType(const std::string& source_string);
  eActorMovementType ParseMovementType(const std::string& source_string);
  eActorEffectTimelineDirectionReferenceType ParseEffectTimelineDirectionReferenceType(const std::string& source_string);
  
  eActorEffectConfigTriggerRangeType ParseEffectConfigTriggerRangeType(const std::string& source_string);

  eActorBuffConfigReplaceType ParseBuffConfigReplaceType(const std::string& source_string);
  eActorBuffConfigStackType ParseBuffConfigStackType(const std::string& source_string);

  eActorAnimationDisplayType ParseAnimationDisplayType(const std::string& source_string);


  ActorBuffStatusBitSet ParseBuffStatusBitSet(const std::string& source_string);

  eActorAttributeType ParseActorAttributeType(const std::string& source_string);
  eActorStatusType ParseActorStatusType(const std::string& source_string);


  //Skill
  void AutoReleaseSpecialSkill(int actor_id); //Special skill with pause, for auto control

  //Battle
  ActorExtEnv* GetActorExtEnv();

  void ShowDamageLabel(int actor_id, int damage_type, float damage_value);
  void ShowStatusLabel(int actor_id, int status_type);

  void ShowDamageLabel(Actor* actor, int damage_type, float damage_value);
  void ShowStatusLabel(Actor* actor, int status_type);

  void AlertEnemyPassRightBorder(int actor_id);

  //Actor Init & Data
  const std::string GetDeadAnimationName(ActorAdapter* actor_adapter);

  cocos2d::CCLayer* GetBattleBottomCCLayer();

  //debug method
  void GenerateSkillData(); ///
} // namespace actor


#endif // ACTOR_ADAPTER_H
