#include "actor_skill.h"

#include "game/actor/actor.h"
#include "game/actor/animation/actor_animation_skeleton_animation.h"
#include "game/actor/actor_ext/actor_ext_effect.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_config_data_table.h"
#include "game/data_table/card_addon_armature_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

//Skill Data Need To Parse
//Skill Data Need To Parse
//Skill Data Need To Parse

//the basic skill data shared by most sub-data
typedef struct tActorSkillBasicData {
  int     skill_key;
  int     skill_id;
  int     actor_id;

  float skill_duration;
  bool is_hit_frame;
  bool is_release_frame;
} ActorSkillBasicData;


//the animation actor will play during the skill
typedef struct tActorSkillActorAnimationData {
  int skill_id;

  float animation_duration;
  bool is_hit_frame;
  bool is_release_frame;

  std::string animation_name;
  std::string movement_name;
} ActorSkillActorAnimationData;

//Skill Data Need To Parse
//Skill Data Need To Parse
//Skill Data Need To Parse



/*
  Actor Skill
    Skill is Data, packed data for Effect, Damage(but not Buff).

    Life Span:
      Init: 
        need: skill_id, source_actor_link(id + data + dead event + ...)

      Update: 
        play actor animation, create Effect by time/trigger

      OnStart:
        create start Effect

      OnHit: 
        (may or may not), triggered, create hit Effect

      OnEnd:
        create end Effect

      Clear: 
        self removal, when actor animation finished, or forced to stop
*/





namespace actor {


  static std::map<int, bool> skill_key_map;
  int RequestSkillKey(int start_from)
  {
    int possible_valid_id = start_from;
    if (start_from == ACTOR_INVALID_ID) possible_valid_id = skill_key_map.size() > 0 ? skill_key_map.rbegin()->first + 1 : 0; //guess best id
    while (skill_key_map.find(possible_valid_id) != skill_key_map.end()) possible_valid_id++; //check valid
    skill_key_map[possible_valid_id] = true;
    return possible_valid_id;
  }
  void ReturnSkillKey(int skill_key)
  {
    skill_key_map.erase(skill_key);
  }







  //ActorSkill
  ActorSkill::ActorSkill(Actor* actor)
    : actor_(actor)
    , skill_hit_count_(0)
  {
    
  }

  ActorSkill::~ActorSkill()
  {
    Clear();
  }


  void ActorSkill::Clear()
  { 
    DetachActorAnimationEvent();

    movement_data_list_.clear();

    ReturnSkillKey(skill_link_data_.skill_key);

    skill_link_data_.Clear();

    skill_hit_count_ = 0;
  }


  void ActorSkill::Update(float delta_time)
  { 
    //what for?
  }





  void ActorSkill::StartSkill(int skill_id)
  {
    SkillConfigData* skill_config_data = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_id);

    //check valid
    if (!skill_config_data)
    {
      CCLog("[ActorSkill][StartSkill] invalid skill_id: %d!", skill_id);
      assert(false);
      return;
    }
    //check valid

    Clear();

    //pack link data
    skill_link_data_.skill_key = RequestSkillKey(ACTOR_INVALID_ID);
    skill_link_data_.skill_id = skill_id;
    skill_link_data_.actor_id = actor_->GetScriptObjectId();
    //quick access
    skill_link_data_.actor_level = actor_->GetActorData()->GetActorStatus(kActorStatusLevel);
    skill_link_data_.skill_level = actor_->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id)->skill_level;
    skill_link_data_.skill_config_data = skill_config_data;

    //pack animation data
    std::list<ActorSkillMovementData> skill_movement_data_list = skill_config_data->GetActorMovementData();
    movement_data_list_ = skill_movement_data_list; //copy

    actor_->GetActorData()->SetActorStatusBool(kActorStatusSkillIsBusy, true);  //lock motion

    //attach skill event
    AttachActorAnimationEvent();

    OnStart();
  }


  void ActorSkill::EndSkill()
  {
    actor_->GetActorData()->SetActorStatusBool(kActorStatusSkillIsBusy, false); //unlock motion

    //detach skill event
    DetachActorAnimationEvent();

    Clear();
  }




  void ActorSkill::OnStart()
  {
    //emit
    actor_->GetActorExtEnv()->ApplyEmitIdDataList(
      skill_link_data_.skill_config_data->GetEmitDataStart(), skill_link_data_.actor_id);

    //play movement
    OnMovement();
  }


  void ActorSkill::OnMovement()
  {

    //animation
    if (movement_data_list_.empty())
    {
      //no more moves
      OnEnd();
    }
    else
    {
      //play movement
      ActorSkillMovementData movement_data = *(movement_data_list_.begin());
      movement_data_list_.pop_front();

      actor_->GetAnimation()->GetAnimationSkeletonAnimation()->ChangeMovement(movement_data.movement_name, 1, movement_data.speed_scale);

      //reset hit count
      skill_hit_count_ = 0;
    }
  }


  void ActorSkill::OnHit()
  {
    //emit by skill_hit_count_
    switch (skill_hit_count_)
    {
    case 0:
      actor_->GetActorExtEnv()->ApplyEmitIdDataList(
        skill_link_data_.skill_config_data->GetEmitDataHit1(), skill_link_data_.actor_id);
      break;
    case 1:
      actor_->GetActorExtEnv()->ApplyEmitIdDataList(
        skill_link_data_.skill_config_data->GetEmitDataHit2(), skill_link_data_.actor_id);
      break;
    case 2:
      actor_->GetActorExtEnv()->ApplyEmitIdDataList(
        skill_link_data_.skill_config_data->GetEmitDataHit3(), skill_link_data_.actor_id);
      break;
    }

    skill_hit_count_ ++;
  }


  void ActorSkill::OnEnd()
  {
    //emit
    actor_->GetActorExtEnv()->ApplyEmitIdDataList(
      skill_link_data_.skill_config_data->GetEmitDataEnd(), skill_link_data_.actor_id);

    EndSkill();
  }










  void ActorSkill::AttachActorAnimationEvent()
  {
    DetachActorAnimationEvent();

    movement_event_connection_ = actor_->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->SubscribeActionEvent<ActorSkill>(this, &ActorSkill::OnActorAnimationMovementEvent);
    frame_event_connection_ = actor_->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->SubscribeFrameEvent<ActorSkill>(this, &ActorSkill::OnActorAnimationFrameEvent);
  }
  void ActorSkill::DetachActorAnimationEvent()
  {
    movement_event_connection_.disconnect();
    frame_event_connection_.disconnect();
  }


  void ActorSkill::OnActorAnimationMovementEvent(cocos2d::extension::CCArmature* armature,
    cocos2d::extension::MovementEventType event_type,
    const char* movement_name)
  {
    switch (event_type)
    {
    case cocos2d::extension::START:
      //check unexpected movement change
//       actor_->GetActorData()->GetLog()->AddErrorLogF("[ActorSkill][OnActorAnimationMovementEvent] unexpected movement change, stop current skill_id: %d", skill_link_data_.skill_id);
//       //assert(false);
//       EndSkill();
      break;
    case cocos2d::extension::COMPLETE:
      //finished current movement, play next movement
      OnMovement();
      break;
    }
  }
  void ActorSkill::OnActorAnimationFrameEvent(cocos2d::extension::CCBone *bone,
    const char* frame_event_name,
    int origin_frame_index,
    int current_frame_index)
  {
    std::string frame_event_name_string = frame_event_name;

    //check card addon armature
    CardAddonArmatureData* card_addon_armature_data = DataManager::GetInstance().GetCardAddonArmatureDataTable()->GetCardAddonArmature(
      actor_->GetActorData()->GetActorStatus(kActorStatusCardId), 
      skill_link_data_.skill_id,
      frame_event_name_string);
    
    if (card_addon_armature_data)
    {
      actor::ActorAnimationQueueData queue_data; 
      queue_data.animation_type = actor::kActorAnimationQueueDataArmature;
      queue_data.animation_name = "bsj";
      queue_data.armature_name = card_addon_armature_data->GetCardAddonArmatureName();
      queue_data.position = CCPointZero;
      queue_data.rotation = 0;
      queue_data.is_filp_x = (actor_->GetActorData()->GetActorStatus(actor::kActorStatusAnimationDirection) == actor::kActorAnimationDirectionRight);
      queue_data.loop_count = 1;

      actor::ActorAnimationQueue* animation_queue = actor_->GetAnimation()->CreateAnimationQueue();
      animation_queue->Append(queue_data);
      animation_queue->AutoPlayAndDetach();//just play on and release for auto delete
    }


    if (frame_event_name_string == GetFrameEventName(kFrameEventRelease) 
      || frame_event_name_string == GetFrameEventName(kFrameEventHit))
    {
      OnHit();
    }
  }
  
  //ActorSkill

} // namespace actor