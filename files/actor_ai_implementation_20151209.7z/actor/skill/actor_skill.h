#ifndef ACTOR_SKILL_H
#define ACTOR_SKILL_H

#include "game/actor/data/actor_data_typedef.h"

#include "engine/animation/skeleton_animation.h"

#include "cocos2d.h"

class SkillConfigData;

namespace actor {

  class Actor;


  //skill needed link data, NOTE: only link up(effect hold link too)
  class ActorSkillLinkData 
  {
  public:
    ActorSkillLinkData()
    {
      Clear();
    }

    void Clear()
    {
      skill_key = ACTOR_INVALID_ID;
      
      skill_id = ACTOR_INVALID_ID;
      skill_level = 0;
      skill_config_data = NULL;
      
      actor_id = ACTOR_INVALID_ID;
      actor_level = 0;

      target_actor_id_list.clear();
    }

  public:
    int skill_key;

    int skill_id;
    int skill_level;  //quick access
    SkillConfigData* skill_config_data; //quick access

    int actor_id;
    int actor_level;  //quick access

    std::list<int> target_actor_id_list;

    //effect link?
  };



  //one skill per actor, or no skill at all, check logic state attack
  //mainly pack data, play actor animation, emit Effect or Buff
  class ActorSkill
  {
  public:
    ActorSkill(Actor* actor_);
    ~ActorSkill();

    void Clear(); //will force end skill

    void Update(float delta_time);

    void StartSkill(int skill_id);  //all skill starts here
    void EndSkill();  //all skill ends here

    void SetIsPause(bool is_pause);

    ActorSkillLinkData& GetSkillLinkData() { return skill_link_data_; }

  private:
    //packed logic by event
    void OnStart();
    void OnMovement();
    void OnHit();
    void OnEnd();

    //animation event
    void AttachActorAnimationEvent();
    void DetachActorAnimationEvent();
    void OnActorAnimationMovementEvent(cocos2d::extension::CCArmature* armature,
      cocos2d::extension::MovementEventType event_type,
      const char* movement_name);
    void OnActorAnimationFrameEvent(cocos2d::extension::CCBone *bone,
      const char* frame_event_name,
      int origin_frame_index,
      int current_frame_index);

  private:
    Actor* actor_;

    int skill_hit_count_;

    ActorSkillLinkData skill_link_data_;

    std::list<ActorSkillMovementData> movement_data_list_;
    
    taomee::SkeletonAnimation::ActionEventSubscriber  movement_event_connection_;
    taomee::SkeletonAnimation::FrameEventSubscriber   frame_event_connection_;
  };

} // namespace actor


#endif // ACTOR_SKILL_H