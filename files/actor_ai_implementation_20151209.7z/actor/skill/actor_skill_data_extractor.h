#ifndef ACTOR_SKILL_DATA_EXTRACTOR_H
#define ACTOR_SKILL_DATA_EXTRACTOR_H

#include <lib_json/json_lib.h>
#include "cocos2d.h"


namespace actor {
  namespace data_extractor {

    typedef struct sNestIdData { 
      int id; 
      std::string key;
      std::string type;
      float fail_chance;
    } NestIdData;

    typedef std::list<NestIdData> NestIdDataList;




    typedef struct sSkillConfig {
      std::string key;
      int id;
      std::string desc;

      std::string skill_attr_desc;

      int skill_icon_id;
      int skill_type;
      float skill_cool_down;

      std::string movement_data;

      NestIdDataList emit_data_start;
      NestIdDataList emit_data_end;
      NestIdDataList emit_data_hit_1;
      NestIdDataList emit_data_hit_2;
      NestIdDataList emit_data_hit_3;

      int damage_type;
      int damage_base;
      float card_transfer_ratio_physical;
      float card_transfer_ratio_magical;

      int level_add_damage;
      std::string level_add_attr_type;
      float level_add_attr_value;
    } SkillConfig;




    typedef struct sEffectConfig {
      std::string key;
      int id;
      std::string desc;

      NestIdDataList emit_data;

      std::string animation_type;
      std::string animation_name;
      float duration;

      std::string trigger_range_type;
      float trigger_range_width;
      float trigger_range_height;
      int trigger_range_x;
      int trigger_range_y;

      std::string trigger_check_data;
    } EffectConfig;



    typedef struct sEffectTimelineItem {
      std::string key;
      int id;
      std::string desc;

      int x;
      int y;
      float delay;
      float duration;

      std::string movement_origin_type;
      std::string movement_type;
      std::string movement_data;
      float movement_speed;

      int direction;
      std::string direction_type;

      std::string animation_item_layer;
      std::string animation_item_type;
      std::string animation_item_name;
    } EffectTimelineItem;

    typedef struct sEffectTimeline {
      std::string key;
      int id;
      std::string desc;

      int x;
      int y;
      float delay;
      float duration;

      std::list<EffectTimelineItem> item_list;
    } EffectTimeline;





    typedef struct sBuffStatusAnimation {
      std::string key;
      int id;
      std::string desc;

      std::string display_type;

      std::string start;
      std::string start_type;
      std::string loop;
      std::string loop_type;
      std::string end;
      std::string end_type;
    } BuffStatusAnimation;




    typedef struct sBuffConfig {
      std::string key;  //aura + id
      int id;
      std::string desc;

      int buff_status_animation_id;
      
      int is_positive;

      std::string buff_key;
      std::string replace_type;
      std::string stack_type;
      
      std::string apply_data;
      
      std::string buff_data;

      std::string mod_data;
    } BuffConfig;







    class ActorSkillDataExtractor
    {
    public:
      ActorSkillDataExtractor();
      ~ActorSkillDataExtractor();

      void Extract();
      void Reform();
      void SaveData();

    private:
      //get data and save in better format
      void ExtractCard();
      void ExtractSkill();
      void ExtractEffectBreak();
      void ExtractEffectAura();

      bool ExtractAnimationArmature(
        const std::string& animation_name, 
        const std::string& description, 
        const std::string& error_text);
      bool ExtractAnimationProjectile(
        const std::string& animation_name, 
        const std::string& description, 
        const std::string& error_text);
      bool ExtractCardSkillAddonArmature(CSJson::Value& root, int card_id, int skill_id);  //card + skill = predefined timeline armature

    private:
      //pick data and output(no save in class), will generate new json data, so the order is important
      void ReformSkillConfig();

      void ReformEffectConfig();
      void ReformEffectTimeline();

      void ReformBuffStatusAnimation();
      void ReformBuffConfig();

    private:
      std::string nest_id_data_list_to_string (NestIdDataList& nest_id_data_list);


    private:
      CSJson::Value json_root_armature_;
      CSJson::Value json_root_projectile_;
      CSJson::Value json_root_card_;
      CSJson::Value json_root_skill_;
      CSJson::Value json_root_effect_break_;
      CSJson::Value json_root_effect_aura_;

      std::map<int, std::list<int> > card_skill_link_map_;
      std::map<int, std::list<int> > skill_card_link_map_;
      std::map<int, std::list<int> > break_skill_link_map_;
      std::map<int, std::list<int> > aura_skill_link_map_;

      std::map<std::string, int> skill_break_key_effect_timeline_id_map_;  //for id remapping, key = skill_id|break_id, value = reformed_effect_timeline_id

      std::map<std::string, SkillConfig> skill_config_map_;

      std::map<std::string, EffectConfig> effect_config_map_;
      std::map<std::string, EffectTimeline> effect_timeline_map_;

      std::map<std::string, BuffStatusAnimation> buff_status_animation_map_;
      std::map<std::string, BuffConfig> buff_config_map_;
    };
  } // namespace data_extractor
} // namespace actor


#endif // ACTOR_SKILL_DATA_EXTRACTOR_H