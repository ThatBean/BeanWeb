#ifndef SCRIPT_OBJECT_H
#define SCRIPT_OBJECT_H

#include <map>
#include <string>

//script object
//maintain life span


namespace actor {
  const int SCRIPT_OBJECT_ID_INVALID = -1;
  const std::string SCRIPT_OBJECT_TYPE_DEFAULT = "ScriptObject";
  const std::string SCRIPT_OBJECT_NAME_DEFAULT = "";


  class ScriptObject;
  class ScriptObjectPool;


  class ScriptObject {
  public:
    ScriptObject();
    ~ScriptObject();
  public:
    virtual void      LinkScript(int script_object_id, ScriptObjectPool* script_object_pool);
    virtual void      UnLinkScript();

    //lua script to cpp function
    virtual void*     GetScriptExporter() = 0;  //return lua cast-able object pointer, may it be this or other pointer, for calling c++ method from lua

    int               GetScriptObjectId() { return script_object_id_; }

    bool              GetScriptObjectIsActive() { return script_object_is_active_; }
    void              SetScriptObjectIsActive(bool script_object_is_active) { script_object_is_active_ = script_object_is_active; }
    std::string       GetScriptObjectType() { return script_object_type_; }
    void              SetScriptObjectType(const std::string &script_object_type) { script_object_type_ = script_object_type; }
    std::string       GetScriptObjectName() { return script_object_name_; }
    void              SetScriptObjectName(const std::string &script_object_name) { script_object_name_ = script_object_name; }


    //cpp to lua script function
    void Emit(const std::string& key);  //emit to lua

    void UpgradeScriptObject(); //should be called after ScriptObject data init finished

    void CallScriptObjectFunction(const std::string& function_name, int value_int);
    void CallScriptObjectFunction(const std::string& function_name, float value_float);
    void CallScriptObjectFunction(const std::string& function_name, const std::string& value_string);

    void AddScriptObjectData(const std::string& key_string, int value_int);
    void AddScriptObjectData(const std::string& key_string, float value_float);
    void AddScriptObjectData(const std::string& key_string, const std::string& value_string);
  private:
    int script_object_id_;  //unique unchanged id
    bool script_object_is_active_;
    std::string script_object_type_;  //string for type mark
    std::string script_object_name_;  //string for other use, can change at will
    ScriptObjectPool* script_object_pool_;
  };


  class ScriptObjectPool {
  public:
    ScriptObjectPool();
    ~ScriptObjectPool();
  protected:
    friend class ScriptObject;
    void            LinkScriptObject(ScriptObject* script_object);
    ScriptObject*   UnLinkScriptObject(int script_object_id);
  public:
    int             GetValidId(int start_from = SCRIPT_OBJECT_ID_INVALID);
    void            Emit(int script_object_id, const std::string& key);
    void            EmitAll(const std::string& key);
  private:
    std::map<int, ScriptObject*> script_object_map_;
  };
} // namespace actor


#endif // SCRIPT_OBJECT_H
