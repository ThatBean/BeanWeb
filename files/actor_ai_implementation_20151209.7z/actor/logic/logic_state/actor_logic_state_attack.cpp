#include "actor_logic_state_attack.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateAttack::STATE_TYPE = kActorLogicStateAttack;

  LogicStateAttack* LogicStateAttack::Instance()
  {
    static LogicStateAttack instance;
    return &instance;
  }

  void LogicStateAttack::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateAttack][OnEnter]");

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateAttack));
  }

  void LogicStateAttack::OnExit(Actor* actor)
  {
    //clear control data
    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdSkill);  //Exit Attack State
	  actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeSkill);  //Exit Attack State
    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetAttack);  //Exit Attack State

    actor->GetActorData()->GetLog()->AddLog("[LogicStateAttack][OnExit]");
  }

  void LogicStateAttack::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[LogicStateAttack][Update]");
    //Wait for Skill system and Motion System to finish
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      actor->GetActorData()->GetControlData()->ResetSkillCountdown();  //reset cool down
      actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdSkill);  //attack motion finished
	    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationTypeSkill);  //attack motion finished
      //actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetAttack);  //attack motion finished

      if (actor->GetActorData()->GetSkillData()->CheckAttackTrigger())
      {
        //combo time!
        actor->GetActorData()->GetLog()->AddLog("[LogicStateAttack][Update] extend for COMBO!");
        actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateAttack));//re-enter
      }
      else
      {
        //not matter skill is successful released or countered
        actor->GetActorData()->GetLog()->AddLog("[LogicStateAttack][Update] finished");
        //back to idle
        //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
      }
    }
  }
} // namespace actor