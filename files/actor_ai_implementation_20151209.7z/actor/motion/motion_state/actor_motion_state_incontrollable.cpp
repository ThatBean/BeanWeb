#include "actor_motion_state_incontrollable.h"

#include "game/actor/actor.h"

namespace actor {

  const int MotionStateIncontrollable::STATE_TYPE = kActorMotionStateIncontrollable;

  MotionStateIncontrollable* MotionStateIncontrollable::Instance()
  {
    static MotionStateIncontrollable instance;
    return &instance;
  }

  void MotionStateIncontrollable::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateIncontrollable][OnExit]");
    //should assist buff system to adjust actor animation
    switch (actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationTypeIncontrollable))
    {
    case kActorControlIncontrollableBuff:
      //
      break;
    case kActorControlIncontrollableSkill:
      //should check
      break;
    case kActorControlIncontrollableScript:
      //for future?
      break;
    case kActorControlIncontrollable:
    default:
      break;
    }

    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);
  }

  void MotionStateIncontrollable::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateIncontrollable][OnExit]");
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false); //for Force Exit
  }

  void MotionStateIncontrollable::Update(Actor* actor, float delta_time)
  {
    actor->GetAnimation()->ChangeMovement(taomee::army::kUnitAnimationIdle);

    //Give Motion control to Buff system
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusLogicIsIncontrollable) == false)
    {
      //back to idle
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
    }
  }

} // namespace actor