#include "actor_motion_state_attack.h"

#include "game/actor/actor.h"
#include "game/actor/skill/actor_skill.h"
#include "game/actor/trigger/actor_trigger.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {

  const int MotionStateAttack::STATE_TYPE = kActorMotionStateAttack;

  MotionStateAttack* MotionStateAttack::Instance()
  {
    static MotionStateAttack instance;
    return &instance;
  }

  void MotionStateAttack::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateAttack][OnEnter]");
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);
  }

  void MotionStateAttack::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateAttack][OnExit]");

    if (actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId) != ACTOR_INVALID_ID
      || actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) != false
      || actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) != false)
    {
      actor->GetActorData()->GetLog()->AddErrorLogF("[MotionStateAttack][OnExit] abnormal skill exit: skill_id:%d, motion_is_busy:%s, skill_is_busy:%s", 
        actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId), 
        actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) ? "true" : "false");

      //end skill again
      actor->GetSkill()->EndSkill();
    }



    //unfreeze energy
    if (actor->GetActorData()->GetSkillData()->GetSkillTypeById(actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId)) == kActorSkillSpecial)
      actor->GetActorData()->GetActorAttributeData(kActorAttributeEnergyCurrent)->Reset(); 

    actor->GetActorData()->GetControlData()->RemoveOperationData(kActorControlOperationIdTargetAttack);  //reset target after skill state

    actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false); //for Force Exit
  }

  void MotionStateAttack::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[MotionStateAttack][Update]");

    //Strange idle, no operation, no skill playing
    if ((actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdSkill) == false 
	  && actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationTypeSkill) == false)
      || actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      //reset for state exit
      actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
      actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][Idle] skill:%s motion_busy:%s skill_busy:%s",
        actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdSkill) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) ? "true" : "false",
        actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) ? "true" : "false");
      return;
    }

    //Give Motion control to Skill system
	int skill_id;
	if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdSkill))
	{
		skill_id = actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationIdSkill);
	}
	else if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationTypeSkill))
	{
		eActorSkillType skill_type = (eActorSkillType)actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationTypeSkill);
		skill_id = actor->GetActorData()->GetSkillData()->GetSkillIdByType(skill_type);
	}
	else
	{
		assert(false);
	}

	//current skill normally finished
    if (actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId) == skill_id
      && actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) == false)
    {
      //unfreeze energy
      if (actor->GetActorData()->GetSkillData()->GetSkillTypeById(actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId)) == kActorSkillSpecial)
        actor->GetActorData()->GetActorAttributeData(kActorAttributeEnergyCurrent)->Reset(); 

      //finish current skill
      actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, ACTOR_INVALID_ID);
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
      actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][SkillFinish] skill_id:%d", skill_id);

      return;
    }


    if (skill_id != actor->GetActorData()->GetActorStatus(kActorStatusSkillCurrentSkillId))
    {
      //check skill cool down

      //cool down check - this only used to add cool down time between skill, default = 0
      eActorSkillType skill_type = actor->GetActorData()->GetSkillData()->GetSkillTypeById(skill_id);
      if (actor->GetActorData()->GetSkillData()->GetSkillCooldownByType(skill_type) <= actor->GetActorData()->GetControlData()->GetSkillCountdown())
      {
        //cool down check pass

        //skill set/changed, reset skill
        actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][SkillStart] <!> skill_id:%d", skill_id);

        //Ready to change
        bool is_use_new_skill = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_use_new_skill");
        if (is_use_new_skill)
        {
          //init skill
          actor->GetSkill()->StartSkill(skill_id);

          //check preset target(for melee attack)
          if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdTargetAttack))
          {
            int pre_selected_target_actor_id = actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationIdTargetAttack);
            actor->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][SkillStart] <!> pre_selected_target_actor_id:%d", pre_selected_target_actor_id);
            actor->GetSkill()->GetSkillLinkData().target_actor_id_list.push_back(pre_selected_target_actor_id);
          }
        }
        else
        {
          int pre_selected_target_actor_id = actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationIdTargetAttack)
            ? actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationIdTargetAttack)
            : ACTOR_INVALID_ID;

          actor->GetActorData()->GetSkillData()->CommitSkill(skill_id, pre_selected_target_actor_id);
        }


        actor->GetActorData()->SetActorStatus(kActorStatusSkillCurrentSkillId, skill_id);

        if (actor->GetActorData()->GetSkillData()->GetSkillTypeById(skill_id) == kActorSkillSpecial) 
          actor->GetActorData()->SetActorAttribute(kActorAttributeEnergyCurrent, 0, 0); //freeze energy

        //check skill release successful, should be set in skill 
        assert(actor->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) == true);

        CheckEnemyForBetterDirection(actor);  //change actor facing, increase skill hit chance

      }
      else
      {
        //waiting for cool down
        actor->GetAnimation()->ChangeMovement(taomee::army::kUnitAnimationIdle);
      }
    }
  }





  //if all the enemy is behind the actor, change the direction.
  void MotionStateAttack::CheckEnemyForBetterDirection(Actor* actor)
  {
    ActorControlData* control_data = actor->GetActorData()->GetControlData();

    float actor_position_x = actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
    bool is_actor_facing_left = (actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionLeft);
    bool is_need_change_direction = false;


    if (control_data->CheckOperationData(kActorControlOperationIdTargetAttack))
    {
      //check for preset target attack, only check this target
      Actor* target_actor = actor->GetActorExtEnv()->GetActorById(control_data->GetIdOperationData(kActorControlOperationIdTargetAttack));
      if (target_actor && target_actor->GetIsActorAlive())
      {
        bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
        //if the enemy is in front of the actor, don't change the direction (0 | 1 | 0 = false)
        is_need_change_direction = !(is_actor_facing_left == is_enemy_at_left_side);
      }
    }
    else
    {
      //check for special skill, need check all enemy
      std::list<Actor*>* actor_list = actor->GetActorExtEnv()->GetActorList();
      if (!actor_list || actor_list->size() == 0) return;

      is_need_change_direction = true;
      bool is_enemy_exist = false;

      int actor_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction);

      std::list<Actor*>::iterator iterator = actor_list->begin();
      while (iterator != actor_list->end())
      {
        Actor* target_actor = *iterator;

        if (target_actor->GetActorData()->GetActorStatus(kActorStatusFaction) != actor_faction)
        {
          bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation).x;
          //if there is one enemy in front of the actor, don't change the direction (1 & 0 & 1 = false)
          is_need_change_direction &= !(is_actor_facing_left == is_enemy_at_left_side);
          is_enemy_exist = true;
        }
        ++iterator;
      }

      delete actor_list;

      //or no enemy at all
      is_need_change_direction &= is_enemy_exist;
    }


    if (is_need_change_direction)
    {
      actor->GetActorData()->GetLog()->AddLogF("[CheckEnemyForBetterDirection] change direction, is_change_to_right:%d", is_actor_facing_left);
      actor->GetActorData()->SetActorStatus(kActorStatusAnimationDirection, is_actor_facing_left ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);
    }
  }
} // namespace actor