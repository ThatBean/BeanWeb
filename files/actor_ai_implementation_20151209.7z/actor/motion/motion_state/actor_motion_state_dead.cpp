#include "actor_motion_state_dead.h"

#include "game/actor/actor.h"

namespace actor {

  const int MotionStateDead::STATE_TYPE = kActorMotionStateDead;

  MotionStateDead* MotionStateDead::Instance()
  {
    static MotionStateDead instance;
    return &instance;
  }


  void MotionStateDead::OnEnter(Actor* actor)
  {
    const std::string animation_name = actor->GetActorData()->GetBasicData()->DeadAnimationName();

    actor->GetAnimation()->DeadMovement(animation_name);
  }

  void MotionStateDead::OnExit(Actor* actor)
  {

  }

  void MotionStateDead::Update(Actor* actor, float delta_time)
  {
  }

} // namespace actor