#include "actor_motion_state_born.h"

#include "game/actor/actor.h"

namespace actor {

  const int MotionStateBorn::STATE_TYPE = kActorMotionStateBorn;

  MotionStateBorn* MotionStateBorn::Instance()
  {
    static MotionStateBorn instance;
    return &instance;
  }


  void MotionStateBorn::OnEnter(Actor* actor)
  {
    actor->GetAnimation()->ChangeMovement(taomee::army::kUnitAnimationIdle);
  }

  void MotionStateBorn::OnExit(Actor* actor)
  {

  }

  void MotionStateBorn::Update(Actor* actor, float delta_time)
  {
  }

} // namespace actor