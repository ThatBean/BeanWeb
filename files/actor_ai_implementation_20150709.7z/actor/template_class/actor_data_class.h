#ifndef ACTOR_DATA_CLASS_H
#define ACTOR_DATA_CLASS_H

#include "actor_signal_hub.h"
#include "game/actor/data/actor_data_typedef.h"

namespace actor {

  template <class t_attribute_data>
  //calc: ((base_ + add_) * multiplier_ + extra_)
  class ActorTemplateAttributeData : public ActorSignalHub<t_attribute_data> {
  public:
    ActorTemplateAttributeData()
      :base_(0),
      add_(0),
      multiplier_(1),
      extra_(0)
    {}

    ~ActorTemplateAttributeData()
    {}

    void  Init(float base = 0, float add = 0, float multiplier = 1, float extra = 0)
    {
      base_ = base;
      add_ = add;
      multiplier_ = multiplier;
      extra_ = extra;

      this->Emit(kActorDataOperationInit);
    }


    void  Reset()
    {
      add_ = 0;
      multiplier_ = 1;
      extra_ = 0;

      this->Emit(kActorDataOperationInit);
    }


    void  Set(float add = 0, float multiplier = 1, float extra = 0)
    {
      add_ = add;
      multiplier_ = multiplier;
      extra_ = extra;

      this->Emit(kActorDataOperationSet);
    }

    void  Add(float add = 0, float multiplier = 0, float extra = 0)
    {
      add_ += add;
      multiplier_ += multiplier;
      extra_ = +extra;

      this->Emit(kActorDataOperationAdd);
    }

    float Get() { return ((base_ + add_) * multiplier_ + extra_); }
    float GetBase() { return base_; }
    float GetAdd() { return add_; }
    float GetMultiplier() { return multiplier_; }
    float GetExtra() { return extra_; }

  private:
    float base_;          //original value
    float add_;           //modify
    float multiplier_;    //modify
    float extra_;         //modify

  };



  template <class t_status_data>
  //status: 
  //    Default = 0
  //    Enum = [0, n]
  //    False = <= 0, True = >= 1
  //    False and True is stackable
  class ActorTemplateStatusData : public ActorSignalHub<t_status_data> {
  public:
    ActorTemplateStatusData()
      :base_(0),
      current_(0)
    {}
    ~ActorTemplateStatusData()
    {}

    void  Reset() { 
      current_ = base_; 

      this->Emit(kActorDataOperationReset);
    }

    // Use as Enum / Int
    void  Init(int status) { 
      base_ = status; 
      current_ = base_; 

      this->Emit(kActorDataOperationInit);
    }
    void  Set(int status) { 
      current_ = status; 

      this->Emit(kActorDataOperationSet);
    }
    int   Get() { return current_; }

    // Use as Bool
    void  InitBool(bool bool_status) { 
      base_ = (bool_status ? 1 : 0); 
      current_ = base_; 

      this->Emit(kActorDataOperationInit);
    }
    void  SetBool(bool bool_status) { Set(bool_status ? 1 : 0); }
    bool  GetBool() { return (current_ > 0); }

    void  SetFalse() { Set(0); }
    void  SetTrue() { Set(1); }

    //if use stack, make sure other method is not used also(will cause messy logic)
    void  StackFalse() { Set(current_ - 1); }
    void  StackTrue() { Set(current_ + 1); }
    void  Stack(bool bool_status) { Set(current_ + (bool_status ? 1 : -1)); }


  private:
    int   base_;     //original value
    int   current_;  //current
  };


  template <class t_position_data>
  //geometry: 
  //    default = (0, 0)
  class ActorTemplatePositionData : public ActorSignalHub<t_position_data> {
  public:
    ActorTemplatePositionData()
    {
      base_.setPoint(0, 0);
      current_.setPoint(0, 0);
    }
    ~ActorTemplatePositionData()
    {}

    void  Init(cocos2d::CCPoint &position) { 
      base_ = position; 
      current_ = base_;

      this->Emit(kActorDataOperationInit);
    }
    void  Reset() { 
      current_ = base_;

      this->Emit(kActorDataOperationReset);
    }

    void  Set(cocos2d::CCPoint &position) { 
      current_ = position; 

      this->Emit(kActorDataOperationSet);
    }
    cocos2d::CCPoint& Get() { return current_; }

  private:
    cocos2d::CCPoint   base_;
    cocos2d::CCPoint   current_;
  };

} // namespace actor


#endif // ACTOR_DATA_CLASS_H