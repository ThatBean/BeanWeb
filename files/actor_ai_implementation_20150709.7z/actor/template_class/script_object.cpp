#include "script_object.h"

#include "engine/script/lua_tinker_manager.h"

#define SCRIPT_OBJECT_LUA "script/actor/script_object.lua"


//script object
//maintain life span


namespace actor {
  ScriptObject::ScriptObject()
    :script_object_id_(SCRIPT_OBJECT_ID_INVALID),
    script_object_is_active_(false),
    script_object_type_(SCRIPT_OBJECT_TYPE_DEFAULT),
    script_object_name_(SCRIPT_OBJECT_NAME_DEFAULT),
    script_object_pool_(NULL)
  {
    //
  }

  ScriptObject::~ScriptObject() {
    UnLinkScript();
  }

  void ScriptObject::LinkScript(int script_object_id, ScriptObjectPool* script_object_pool) 
  {
    UnLinkScript();

    assert(script_object_id != SCRIPT_OBJECT_ID_INVALID && script_object_pool != NULL);

    script_object_id_ = script_object_id;
    script_object_pool_ = script_object_pool;

    script_object_pool_->LinkScriptObject(this);

    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CreateScriptObject", this);
    
    Emit(std::string("Create"));
  }

  void ScriptObject::UnLinkScript()
  { 
    if (script_object_id_ != SCRIPT_OBJECT_ID_INVALID)
    {
      Emit(std::string("Remove"));
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "RemoveScriptObject", script_object_id_);
    }

    if (script_object_pool_) 
    {
      script_object_pool_->UnLinkScriptObject(script_object_id_); 
    }

    script_object_id_ = SCRIPT_OBJECT_ID_INVALID;
    script_object_pool_ = NULL;
  }


  void ScriptObject::Emit(const std::string& key) 
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "EmitScriptObject", script_object_id_, key);
  }

  void ScriptObject::UpgradeScriptObject()
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "UpgradeScriptObject", script_object_id_);
  }

  void ScriptObject::CallScriptObjectFunction(const std::string& function_name, int value_int)
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", script_object_id_, function_name.c_str(), value_int);
  }
  void ScriptObject::CallScriptObjectFunction(const std::string& function_name, float value_float)
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", script_object_id_, function_name.c_str(), value_float);
  }
  void ScriptObject::CallScriptObjectFunction(const std::string& function_name, const std::string& value_string)
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "CallScriptObjectFunction", script_object_id_, function_name.c_str(), value_string.c_str());
  }

  void ScriptObject::AddScriptObjectData(const std::string& key_string, int value_int)
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "AddScriptObjectData", script_object_id_, key_string.c_str(), value_int);
  }
  void ScriptObject::AddScriptObjectData(const std::string& key_string, float value_float)
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "AddScriptObjectData", script_object_id_, key_string.c_str(), value_float);
  }
  void ScriptObject::AddScriptObjectData(const std::string& key_string, const std::string& value_string)
  {
    if (script_object_id_ == SCRIPT_OBJECT_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_OBJECT_LUA, "AddScriptObjectData", script_object_id_, key_string.c_str(), value_string.c_str());
  }








  ScriptObjectPool::ScriptObjectPool()
  {
    //
  }

  ScriptObjectPool::~ScriptObjectPool() {
    std::map<int, ScriptObject*>::iterator iterator = script_object_map_.begin();

    while (iterator != script_object_map_.end())
    {
      ScriptObject* script_object = UnLinkScriptObject(iterator->first);
      delete script_object;

      iterator++;
    }
  }


  int ScriptObjectPool::GetValidId(int start_from/* = SCRIPT_OBJECT_ID_INVALID*/)
  {
    int possible_valid_id = start_from;
    if (start_from == SCRIPT_OBJECT_ID_INVALID) possible_valid_id = script_object_map_.size() > 0 ? script_object_map_.rbegin()->first + 1 : 0; //guess best id
    while (script_object_map_.find(possible_valid_id) != script_object_map_.end()) possible_valid_id++; //check valid
    return possible_valid_id;
  }

  void ScriptObjectPool::LinkScriptObject(ScriptObject* script_object) 
  {
    int script_object_id = script_object->GetScriptObjectId();

    if (script_object_map_.find(script_object_id) != script_object_map_.end())
    {
      assert(false);
      UnLinkScriptObject(script_object_id); 
    }

    script_object_map_[script_object_id] = script_object;
  }

  ScriptObject* ScriptObjectPool::UnLinkScriptObject(int script_object_id) 
  {
    if (script_object_map_.find(script_object_id) != script_object_map_.end())
    {
      ScriptObject* script_object = script_object_map_[script_object_id];
      script_object_map_.erase(script_object_id);
      return script_object;
    }
    else
    {
      return NULL;
    }
  }

  void ScriptObjectPool::Emit(int script_object_id, const std::string& key) 
  {
    if (script_object_map_.find(script_object_id) != script_object_map_.end())
    {
      script_object_map_[script_object_id]->Emit(key);
    }
  }

  void ScriptObjectPool::EmitAll(const std::string& key) 
  {
    std::map<int, ScriptObject*>::iterator iterator = script_object_map_.begin();

    while (iterator != script_object_map_.end())
    {
      iterator->second->Emit(key);

      iterator++;
    }
  }


} // namespace actor