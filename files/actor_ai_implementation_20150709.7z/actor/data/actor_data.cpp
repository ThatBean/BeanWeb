#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger.h"


namespace actor {
  //Switch the Console print of Actor Log
  const bool SHOW_DEBUG_ACTOR_LOG = false;


  //ActorData
  ActorData::ActorData(Actor* actor)
    :actor_(actor),
    actor_create_timestamp_(0),
    basic_data_(NULL),
    skill_data_(NULL),
    buff_data_(NULL),
    damage_data_(NULL),
    user_control_data_(NULL),
    routine_control_data_(NULL),
    control_data_(NULL),
    logic_data_(NULL),
    motion_data_(NULL),
    specified_data_(NULL)
  {
    //Init();
  }

  ActorData::~ActorData()
  {
    ResetData();

    AddLog("[ActorData][~ActorData]");
    //ShowLog(-1);
    actor_log_.clear();
  }

  void ActorData::Init(eActorModelType actor_model_type/* = kActorModelActor*/)
  {
    ResetData();

    if (actor_model_type & ACTOR_DATA_DEPENDENCY_BASIC) basic_data_ = new ActorBasicData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_SKILL) skill_data_ = new ActorSkillData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_BUFF) buff_data_ = new ActorBuffData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_DAMAGE) damage_data_ = new ActorDamageData(this); // TODO: use it

    if (actor_model_type & ACTOR_DATA_DEPENDENCY_CONTROL) 
    {
      user_control_data_ = new ActorControlData();
      routine_control_data_ = new ActorControlData();
      control_data_ = new ActorControlData();
    }

    if (actor_model_type & ACTOR_DATA_DEPENDENCY_LOGIC) logic_data_ = new ActorLogicData(this);
    if (actor_model_type & ACTOR_DATA_DEPENDENCY_MOTION) motion_data_ = new ActorMotionData(this);

    InitActorStatus(kActorStatusActorId, actor_->GetScriptObjectId());
    InitActorStatus(kActorStatusActorModel, actor_model_type);
    AddErrorLogF("[ActorData][Init] type:%s model:%d", actor_->GetScriptObjectType().c_str(), actor_model_type);
  }

  void ActorData::ResetData()
  {
    if (basic_data_) delete basic_data_;
    if (skill_data_) delete skill_data_;
    if (buff_data_) delete buff_data_;
    if (damage_data_) delete damage_data_;

    if (user_control_data_) delete user_control_data_;
    if (routine_control_data_) delete routine_control_data_;
    if (control_data_) delete control_data_;
    if (logic_data_) delete logic_data_;
    if (motion_data_) delete motion_data_;

    if (specified_data_) delete specified_data_;

    SetCreateTime(clock());

    AddLog("[ActorData][ResetData]");
  }

  void ActorData::ConnectDataSignal()
  {
    if (basic_data_) basic_data_->ConnectDataSignal();
    if (skill_data_) skill_data_->ConnectDataSignal();
    if (buff_data_) buff_data_->ConnectDataSignal();
    if (motion_data_) motion_data_->ConnectDataSignal();
  }

  void ActorData::Update(float delta_time)
  {
    //for Debug quick watch
    Actor* debug_actor = actor_;
    ActorData* debug_actor_data = this;
    
    if (basic_data_) basic_data_->Update(delta_time);
    if (user_control_data_) user_control_data_->Update(delta_time);
    if (routine_control_data_) routine_control_data_->Update(delta_time);
    if (control_data_) control_data_->Update(delta_time);
    if (specified_data_) specified_data_->Update(delta_time);
  }



  void ActorData::AddErrorLogF(const char* format, ...)
  {
    char temp_text[1024];
    va_list ap;
    va_start(ap, format);
    vsnprintf(temp_text, 1024, format, ap);
    va_end(ap);
    AddLog(temp_text, true);
  }

  void ActorData::AddLogF(const char* format, ...)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    char temp_text[1024];
    va_list ap;
    va_start(ap, format);
    vsnprintf(temp_text, 1024, format, ap);
    va_end(ap);
    AddLog(temp_text, false);
#endif
  }


  void ActorData::AddLog(const char* log, bool is_print/* = false*/)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    std::string log_string;
    char time_text[255];
    sprintf(time_text, "<ID:%d|%.3fs|%.3fs>\t", 
      actor_->GetScriptObjectId(), 
      double(clock() - GetCreateTime()) / CLOCKS_PER_SEC, 
      double(clock()) / CLOCKS_PER_SEC);
    log_string += time_text;
    log_string += log;
    
    actor_log_.push_front(log_string + "\n");

    if (SHOW_DEBUG_ACTOR_LOG || is_print) CCLog(log_string.c_str());
#endif
  }

  void ActorData::ShowLog(int max_line/* = 20*/)
  {
    CCLog("%s",GetLogText(max_line).c_str());
  }


  std::string ActorData::GetLogText(int max_line/* = 20*/)
  {
    std::string log_text = "";
    int line_count = 0;
    std::list<std::string>::iterator iterator = actor_log_.begin();
    while (iterator != actor_log_.end() && (max_line < 0 || line_count < max_line))
    {
      log_text += *iterator;
      line_count++;
      iterator++;
    }
    return log_text;
  }





  ActorSpecifiedData* ActorData::GetSpecifiedData()
  {
    if (specified_data_) return specified_data_;

    switch (GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      specified_data_ = new ActorSpecifiedDataCharacter(actor_);
      break;
    case kActorAppearanceEnemyPawn:
      specified_data_ = new ActorSpecifiedDataEnemyPawn(actor_);
      break;
    case kActorAppearanceEnemyBoss:
      specified_data_ = new ActorSpecifiedDataEnemyBoss(actor_);
      break;
    default:
      assert(false);
      specified_data_ = NULL;
      break;
    }

    return specified_data_;
  }


  void ActorData::SetActorAdapter(ActorAdapter* actor_adapter)
  {
    if (basic_data_) basic_data_->SetActorAdapter(actor_adapter);
    if (skill_data_) skill_data_->SetActorAdapter(actor_adapter);
    if (buff_data_) buff_data_->SetActorAdapter(actor_adapter);

    ConnectDataSignal();
  }

  //ActorData

} // namespace actor