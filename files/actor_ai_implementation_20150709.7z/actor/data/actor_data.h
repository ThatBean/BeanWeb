#ifndef ACTOR_DATA_H
#define ACTOR_DATA_H

#include "game/actor/template_class/actor_data_class.h"

// include specialized data operation class
#include "actor_data/actor_basic_data.h"
#include "actor_data/actor_skill_data.h"
#include "actor_data/actor_buff_data.h"
#include "actor_data/actor_control_data.h"
#include "actor_data/actor_logic_data.h"
#include "actor_data/actor_motion_data.h"
#include "actor_data/actor_damage_data.h"
#include "actor_data/actor_specified_data.h"

#include "cocos2d.h"





namespace actor {

  class Actor;
  class ActorData;

  typedef ActorTemplateAttributeData<ActorData> ActorAttributeData;
  typedef ActorTemplateStatusData<ActorData> ActorStatusData;
  typedef ActorTemplatePositionData<ActorData> ActorPositionData;


  class ActorData
  {
  public:
    ActorData(Actor* actor);
    ~ActorData();

    void Init(eActorModelType actor_model_type = kActorModelActor);
    void ResetData();

    void ConnectDataSignal();

    void Update(float delta_time);

    void AddErrorLogF(const char* format, ...);
    void AddLogF(const char* format, ...);
    void AddLog(const char* log, bool is_print = false);
    void ShowLog(int max_line = 20);  //max_line = -1 for all log
    std::string GetLogText(int max_line = 20);  //max_line = -1 for all log

    //// Data with predefined enum keys
    //direct access to ActorAttributeData
    std::map<eActorAttributeType, ActorAttributeData>* GetActorAttributeMap() { return &actor_attribute_map_; }
    bool CheckActorAttribute(eActorAttributeType actor_attribute_type) { return (actor_attribute_map_.find(actor_attribute_type) != actor_attribute_map_.end()); }
    //get data to connect event
    ActorAttributeData* GetActorAttributeData(eActorAttributeType actor_attribute_type) { return &(actor_attribute_map_[actor_attribute_type]); }
    //normal access, with event
    void  InitActorAttribute(eActorAttributeType actor_attribute_type, float base = 0, float add = 0, float multiplier = 1, float extra = 0) 
    { 
      actor_attribute_map_[actor_attribute_type].Link(actor_attribute_type, this);
      actor_attribute_map_[actor_attribute_type].Init(base, add, multiplier, extra); 
    }
    void  SetActorAttribute(eActorAttributeType actor_attribute_type, float add = 0, float multiplier = 1, float extra = 0) { actor_attribute_map_[actor_attribute_type].Set(add, multiplier, extra); }
    void  AddActorAttribute(eActorAttributeType actor_attribute_type, float add = 0, float multiplier = 0, float extra = 0) { actor_attribute_map_[actor_attribute_type].Add(add, multiplier, extra); }
    float GetActorAttribute(eActorAttributeType actor_attribute_type) { return actor_attribute_map_[actor_attribute_type].Get(); }

    //direct access to ActorStatusData
    std::map<eActorStatusType, ActorStatusData>* GetActorStatusMap() { return &actor_status_map_; }
    bool CheckActorStatus(eActorStatusType actor_status_type) { return (actor_status_map_.find(actor_status_type) != actor_status_map_.end()); }
    //get data to connect event
    ActorStatusData* GetActorStatusData(eActorStatusType actor_status_type) { return &(actor_status_map_[actor_status_type]); }
    //normal access, with event
    void  InitActorStatus(eActorStatusType actor_status_type, int status) 
    { 
      actor_status_map_[actor_status_type].Link(actor_status_type, this);
      actor_status_map_[actor_status_type].Init(status); 
    }
    void  SetActorStatus(eActorStatusType actor_status_type, int status) { actor_status_map_[actor_status_type].Set(status); }
    int   GetActorStatus(eActorStatusType actor_status_type) { return actor_status_map_[actor_status_type].Get(); }
    //normal access, with event
    void  InitActorStatusBool(eActorStatusType actor_status_type, bool bool_status) 
    { 
      actor_status_map_[actor_status_type].Link(actor_status_type, this);
      actor_status_map_[actor_status_type].InitBool(bool_status); 
    }
    void  SetActorStatusBool(eActorStatusType actor_status_type, bool bool_status) { actor_status_map_[actor_status_type].SetBool(bool_status); }
    bool  GetActorStatusBool(eActorStatusType actor_status_type) { return actor_status_map_[actor_status_type].GetBool(); }


    //direct access to ActorPositionData
    std::map<eActorPositionType, ActorPositionData>* GetActorPositionMap() { return &actor_position_map_; }
    bool CheckActorPosition(eActorPositionType actor_position_type) { return (actor_position_map_.find(actor_position_type) != actor_position_map_.end()); }
    //get data to connect event
    ActorPositionData* GetActorPositionData(eActorPositionType actor_position_type) { return &(actor_position_map_[actor_position_type]); }
    //normal access, with event
    void  InitActorPosition(eActorPositionType actor_position_type, cocos2d::CCPoint position) 
    { 
      actor_position_map_[actor_position_type].Link(actor_position_type, this);
      actor_position_map_[actor_position_type].Init(position); 
    }
    void  SetActorPosition(eActorPositionType actor_position_type, cocos2d::CCPoint position) { actor_position_map_[actor_position_type].Set(position); }
    cocos2d::CCPoint&   GetActorPosition(eActorPositionType actor_position_type) { return actor_position_map_[actor_position_type].Get(); }



    //Actor*                GetActor() { return actor_; } //should not often be accessed directly in data

    void                  SetCreateTime(uint_32 timestamp) { actor_create_timestamp_ = timestamp; }
    uint_32               GetCreateTime() { return actor_create_timestamp_; }

    ActorBasicData*       GetBasicData() { return basic_data_; }
    ActorSkillData*       GetSkillData() { return skill_data_; }
    ActorBuffData*        GetBuffData() { return buff_data_; }
    ActorDamageData*      GetDamageData() { return damage_data_; }

    ActorControlData*     GetUserControlData() { return user_control_data_; };
    ActorControlData*     GetRoutineControlData() { return routine_control_data_; };
    ActorControlData*     GetControlData() { return control_data_; }
    ActorLogicData*       GetLogicData() { return logic_data_; }
    ActorMotionData*      GetMotionData() { return motion_data_; }

    ActorSpecifiedData*   GetSpecifiedData();
    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter);
  private:
    Actor*                actor_; //should not often be accessed directly in data
    
    std::list<std::string> actor_log_;  //debug use

    //key reserved, limited to declared type enum only
    std::map<eActorAttributeType, ActorAttributeData> actor_attribute_map_;
    std::map<eActorStatusType, ActorStatusData> actor_status_map_;
    std::map<eActorPositionType, ActorPositionData> actor_position_map_;

    uint_32               actor_create_timestamp_;  //a time 

    //Notice:
    // data in ActorData should avoid obtaining a direct pointer of Actor (Actor* actor_)
    // instead, a pointer of ActorData with actor back link is better
    ActorBasicData*       basic_data_;
    ActorSkillData*       skill_data_;
    ActorBuffData*        buff_data_; //store actor buff data
    ActorDamageData*      damage_data_;

    ActorControlData*     user_control_data_; //control data directly obtained by user operation(touch), processed by Control-Manual
    ActorControlData*     routine_control_data_;  //data for script based ActorControlRoutine
    ActorControlData*     control_data_;      //processed control data to be used in logic / motion, also a ActorControlData
    ActorLogicData*       logic_data_;        //logic input and output, (directly change this can affect logic in next Logic Update)
    ActorMotionData*      motion_data_;       //keep motion data(speed, target ...), mostly for animation

    ActorSpecifiedData*   specified_data_;    //different for each type of actor(mostly by Appearance), provide different function with the same name
  };



} // namespace actor


#endif // ACTOR_DATA_H