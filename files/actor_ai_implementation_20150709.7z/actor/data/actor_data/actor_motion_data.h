#ifndef ACTOR_MOTION_DATA_H
#define ACTOR_MOTION_DATA_H

#include "../actor_data_typedef.h"

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;

  class ActorMotionData
  {
  public:
    ActorMotionData(ActorData* actor_data);
    ~ActorMotionData();

    //void    
    void Update(float delta_time);

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data);


  private:
    ActorData*    actor_data_;
  };


} // namespace actor


#endif // ACTOR_MOTION_DATA_H