#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorControlData
  ActorControlData::ActorControlData()
  {
    Reset();
  }

  ActorControlData::~ActorControlData()
  {
  }

  void ActorControlData::Reset()
  {
    is_set_position_ = false;
    is_set_skill_ = false;
    is_set_target_ = false;
    is_set_incontrollable_ = false;

    control_priority_position_ = kActorControlPriorityMin;
    control_priority_skill_ = kActorControlPriorityMin;
    control_priority_target_ = kActorControlPriorityMin;
    control_priority_incontrollable_ = kActorControlPriorityMin;

    countdown_ = 0;
    skill_countdown_ = 0;
  }

  void ActorControlData::Update(float delta_time)
  {
    UpdateCountdown(delta_time);
    UpdateSkillCountdown(delta_time);
  }


  eActorControlPriority ActorControlData::GetMaximumControlPriority()
  {
    eActorControlPriority maximum_control_priority = kActorControlPriorityMin;

    if (is_set_position_) maximum_control_priority = max(maximum_control_priority, control_priority_position_);
    if (is_set_skill_) maximum_control_priority = max(maximum_control_priority, control_priority_skill_);
    if (is_set_target_) maximum_control_priority = max(maximum_control_priority, control_priority_target_);
    if (is_set_incontrollable_) maximum_control_priority = max(maximum_control_priority, control_priority_incontrollable_);

    return maximum_control_priority;
  }

  void ActorControlData::SetPosition(const cocos2d::CCPoint& position, eActorControlPriority control_priority)
  {
    if (is_set_position_ && control_priority_position_ > control_priority)
      return; //only preserve same or higher priority
    position_ = position;
    control_priority_position_ = control_priority;
    is_set_position_ = true;
  }

  void ActorControlData::SetTarget(int target_id, eActorControlPriority control_priority)
  {
    if (is_set_target_ && control_priority_target_ > control_priority)
      return; //only preserve same or higher priority
    target_id_ = target_id;
    control_priority_target_ = control_priority;
    is_set_target_ = true;
  }

  void ActorControlData::SetSkill(int skill_id, eActorControlPriority control_priority)
  {
    if (is_set_skill_ && control_priority_skill_ > control_priority)
      return; //only preserve same or higher priority
    skill_id_ = skill_id;
    control_priority_skill_ = control_priority;
    is_set_skill_ = true;
  }

  void ActorControlData::SetIncontrollable(eActorControlIncontrollableType incontrollable_type, eActorControlPriority control_priority)
  {
    if (is_set_incontrollable_ && control_priority_incontrollable_ > control_priority)
      return; //only preserve same or higher priority
    incontrollable_type_ = incontrollable_type;
    control_priority_incontrollable_ = control_priority;
    is_set_incontrollable_ = true;
  }


  cocos2d::CCPoint ActorControlData::GetPosition()
  {
    assert(is_set_position_ == true);
    return position_;
  }


  int ActorControlData::GetSkill()
  {
    if (is_set_skill_)
      return (skill_id_);
    else
      return ACTOR_INVALID_ID;
  }

  int ActorControlData::GetTarget()
  {
    if (is_set_target_)
      return (target_id_);
    else
      return ACTOR_INVALID_ID;
  }

  eActorControlIncontrollableType ActorControlData::GetIncontrollable()
  {
    if (is_set_incontrollable_)
      return (incontrollable_type_);
    else
      return kActorControlIncontrollable;
  }


  void ActorControlData::ResetPosition() 
  { 
    is_set_position_ = false; 
    control_priority_position_ = kActorControlPriorityMin; 
  }

  void ActorControlData::ResetSkill() 
  { 
    is_set_skill_ = false; 
    control_priority_skill_ = kActorControlPriorityMin; 
  }

  void ActorControlData::ResetTarget() 
  { 
    is_set_target_ = false; 
    control_priority_target_ = kActorControlPriorityMin; 
  }

  void ActorControlData::ResetIncontrollable() 
  { 
    is_set_incontrollable_ = false; 
    control_priority_incontrollable_ = kActorControlPriorityMin; 
  }


  bool ActorControlData::IsSet()
  {
    return (is_set_position_ 
      || is_set_skill_ 
      || is_set_target_
      || is_set_incontrollable_);
  }
  //ActorControlData



} // namespace actor