#ifndef ACTOR_SPECIFIED_DATA_H
#define ACTOR_SPECIFIED_DATA_H

#include "../actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  
  class ActorSpecifiedData  //a data class for each type of actor 
  {
  public:
    ActorSpecifiedData(Actor* actor);

    virtual void Update(float delta_time);
    virtual bool IsPositionValid(cocos2d::CCPoint position);
    virtual bool IsGridValid(cocos2d::CCPoint grid_position);
    virtual bool IsGridIdleValid(cocos2d::CCPoint grid_position); // for user controlled actor only

    virtual cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position);

    virtual std::list<cocos2d::CCPoint>* GetValidGridList(std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list);  //need delete after use 
    virtual cocos2d::CCPoint GetValidGrid(cocos2d::CCPoint preferred_grid_position, std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list);
    virtual cocos2d::CCPoint GetValidGrid();  //for idle grid decision

  protected:
    Actor* actor_;
  };
  //######################################################################################################
  //######################################################################################################
  class ActorSpecifiedDataCharacter : public ActorSpecifiedData
  {
  public:
    ActorSpecifiedDataCharacter(Actor* actor);

    virtual bool IsPositionValid(cocos2d::CCPoint position);
    virtual bool IsGridValid(cocos2d::CCPoint grid_position);
    virtual bool IsGridIdleValid(cocos2d::CCPoint grid_position); // for user controlled actor only

    virtual cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position);
  };
  //######################################################################################################
  //######################################################################################################
  class ActorSpecifiedDataEnemyPawn : public ActorSpecifiedData
  {
  public:
    ActorSpecifiedDataEnemyPawn(Actor* actor);

    virtual bool IsPositionValid(cocos2d::CCPoint position);
  };
  //######################################################################################################
  //######################################################################################################
  class ActorSpecifiedDataEnemyBoss : public ActorSpecifiedData
  {
  public:
    ActorSpecifiedDataEnemyBoss(Actor* actor);

    virtual bool IsPositionValid(cocos2d::CCPoint position);
  };
} // namespace actor


#endif // ACTOR_SPECIFIED_DATA_H