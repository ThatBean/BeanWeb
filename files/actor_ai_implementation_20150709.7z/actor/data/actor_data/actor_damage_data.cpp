#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"


namespace actor {

  const unsigned long ACTOR_DAMAGE_MODIFY_HEALTH = 0
    | kActorDamageAttributePhysical
    | kActorDamageAttributeMagical
    | kActorDamageAttributeCritical
    | kActorDamageAttributeIce
    | kActorDamageAttributeFire
    | kActorDamageAttributeWind
    | 0;

  const unsigned long ACTOR_DAMAGE_MODIFY_ENERGY = 0
    | 0;



  DamagePackage::DamagePackage()
  {
    InitDamage();
  }
  DamagePackage::~DamagePackage()
  {
    //
  }


  //basic method
  void DamagePackage::InitDamage()
  {
    damage_attribute_map_.clear();
    damage_status_map_.clear();

    damage_status_map_[kActorDamageStatusIsMissed].InitBool(false);
    damage_status_map_[kActorDamageStatusSourceActorId].Init(ACTOR_INVALID_ID);
    damage_status_map_[kActorDamageStatusSourceSkillId].Init(ACTOR_INVALID_ID);
    damage_status_map_[kActorDamageStatusTargetActorId].Init(ACTOR_INVALID_ID);
  }

  void DamagePackage::AddDamage(
    eActorDamageAttributeType   damage_type,
    float   damage_add/* = 0*/,
    float   damage_multiplier/* = 1*/,
    float   damage_extra/* = 0*/
    )
  {
    if (damage_type == kActorDamageAttribute)
    {
      assert(false);
      return;
    }

    damage_attribute_map_[damage_type].Add(damage_add, damage_multiplier, damage_extra);
  }

  float DamagePackage::GetDamage(unsigned long damage_type_filter)
  {
    float result_damage = 0;

    std::map<eActorDamageAttributeType, DamageAttributeData>::iterator iterator = damage_attribute_map_.begin();
    while (iterator != damage_attribute_map_.end())
    {
      if (iterator->first & damage_type_filter)
        result_damage += iterator->second.Get();

      ++iterator;
    }

    return result_damage;
  }






  ActorDamageData::ActorDamageData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }
  ActorDamageData::~ActorDamageData()
  {

  }

  DamagePackage* ActorDamageData::CreateActorDamage() //
  {
    DamagePackage* damage_package = new DamagePackage;

    damage_package->InitActorDamageStatus(kActorDamageStatusSourceActorId, actor_data_->GetActorStatus(kActorStatusActorId));

    return damage_package;
  }

  DamagePackage* ActorDamageData::ReceiveActorDamage(DamagePackage* damage_package) //
  {
    if (!damage_package) return NULL;

    damage_package->InitActorDamageStatus(kActorDamageStatusTargetActorId, actor_data_->GetActorStatus(kActorStatusActorId));

    // TODO: for shield, damage passing...
    //damage_process_actor_id_list_
    //damage_process_actor_id_list_
    std::list<int>::iterator iterator = damage_process_actor_id_list_.begin();

    while (iterator != damage_process_actor_id_list_.end())
    {
      Actor* actor = GetActorExtEnv()->GetActorById(*iterator);
      if (actor)
      {
        damage_package = actor->GetActorData()->GetDamageData()->ReceiveActorDamage(damage_package);
        if (!damage_package) break; //damage_package vanished
      }

      iterator++;
    }
    //damage_process_actor_id_list_
    //damage_process_actor_id_list_

    if (!damage_package) return NULL;

    //sum up damage
    damage_package->AddActorDamageAttribute(kActorDamageAttributeHealth, damage_package->GetDamage(ACTOR_DAMAGE_MODIFY_HEALTH));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeEnergy, damage_package->GetDamage(ACTOR_DAMAGE_MODIFY_ENERGY));

    //get final value
    float health_change = damage_package->GetActorDamageAttribute(kActorDamageAttributeHealth);
    float energy_change = damage_package->GetActorDamageAttribute(kActorDamageAttributeEnergy);

    //change actor attribute
    actor_data_->AddActorAttribute(kActorAttributeHealthCurrent, health_change);
    actor_data_->AddActorAttribute(kActorAttributeEnergyCurrent, energy_change);

    //free package
    if (damage_package)
    {
      delete damage_package;  //empty package, damage stops here
      return NULL;
    }
    else
    {
      return damage_package;  //still left
    }

  }

  //as damage releaser
  void ActorDamageData::AddActorBasicDamage(DamagePackage* damage_package)
  {
    //this will be calculated last
    damage_package->InitActorDamageAttribute(kActorDamageAttributeHealth, 0);
    damage_package->InitActorDamageAttribute(kActorDamageAttributeEnergy, 0);

    //basic
    damage_package->InitActorDamageAttribute(kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeAttackPhysical));
    damage_package->InitActorDamageAttribute(kActorDamageAttributeMagical, actor_data_->GetActorAttribute(kActorAttributeAttackMagical));
    damage_package->InitActorDamageAttribute(kActorDamageAttributeCritical, actor_data_->GetActorAttribute(kActorAttributeAttackCritical));
    damage_package->InitActorDamageAttribute(kActorDamageAttributeIce, 0);
    damage_package->InitActorDamageAttribute(kActorDamageAttributeFire, 0);
    damage_package->InitActorDamageAttribute(kActorDamageAttributeWind, 0);

    //addition
    damage_package->AddActorDamageAttribute(kActorDamageAttributePhysical, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionPhysical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeMagical, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionMagical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeCritical, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionCritical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeIce, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionIce));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeFire, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionFire));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeWind, actor_data_->GetActorAttribute(kActorAttributeDamageAdditionWind));
  }
  void ActorDamageData::AddActorSkillDamage(DamagePackage* damage_package, int skill_id)
  {
    damage_package->InitActorDamageStatus(kActorDamageStatusSourceSkillId, skill_id);

    // TODO: Multi Hit Damage Reduction

    ActorSkillInfo* skill_info = actor_data_->GetSkillData()->GetSkillInfoById(skill_id);

    SkillBase* skillData = DataManager::GetInstance().GetSkillDataTable()->GetSkill(skill_id);
    float damage_value = skillData->GetSkillGrowDamage(skill_info->skill_level);

    switch (skillData->GetDamageType())
    {
    case taomee::battle::kDamageTypePhysics:
      damage_package->AddActorDamageAttribute(kActorDamageAttributePhysical, damage_value);
      break;
    case taomee::battle::kDamageTypeMagic:
      damage_package->AddActorDamageAttribute(kActorDamageAttributeMagical, damage_value);
      break;
    case taomee::battle::kDamageTypeHoly:
      damage_package->AddActorDamageAttribute(kActorDamageAttributeHealth, damage_value);
      break;
    case taomee::battle::kDamageTypeHeal:
      damage_package->AddActorDamageAttribute(kActorDamageAttributeHealth, - damage_value);
      break;
    case taomee::battle::kDamageTypeSuicide:
    case taomee::battle::kDamageTypeUnkown:
      //tricky
      break;
    }


    //addition
    damage_package->AddActorDamageAttribute(kActorDamageAttributePhysical, 0, skillData->GetPhyAddedMul());
    damage_package->AddActorDamageAttribute(kActorDamageAttributeMagical, 0, skillData->GetMagAddedMul());
    damage_package->AddActorDamageAttribute(kActorDamageAttributeCritical, 0);
    damage_package->AddActorDamageAttribute(kActorDamageAttributeIce, 0);
    damage_package->AddActorDamageAttribute(kActorDamageAttributeFire, 0);
    damage_package->AddActorDamageAttribute(kActorDamageAttributeWind, 0);
  }
  void ActorDamageData::AddActorBuffDamage(DamagePackage* damage_package, int buff_id)
  {
    //check buff and pass DamagePackage for process

    //actor_data_->GetBuffData()->ProcessAddDamage(damage_package, buff_id);
  }


  //as damage holder
  void ActorDamageData::ReduceActorBuffDamage(DamagePackage* damage_package, int buff_id)
  {
    //check buff and pass DamagePackage for process

    //actor_data_->GetBuffData()->ProcessReduceDamage(damage_package, buff_id);
  }
  void ActorDamageData::ReduceActorBasicDamage(DamagePackage* damage_package)
  {
    //reduction
    damage_package->AddActorDamageAttribute(kActorDamageAttributePhysical, - actor_data_->GetActorAttribute(kActorAttributeDamageReductionPhysical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeMagical, - actor_data_->GetActorAttribute(kActorAttributeDamageReductionMagical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeCritical, - actor_data_->GetActorAttribute(kActorAttributeDamageReductionCritical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeIce, - actor_data_->GetActorAttribute(kActorAttributeDamageReductionIce));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeFire, - actor_data_->GetActorAttribute(kActorAttributeDamageReductionFire));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeWind, - actor_data_->GetActorAttribute(kActorAttributeDamageReductionWind));

    //basic
    damage_package->AddActorDamageAttribute(kActorDamageAttributePhysical, - actor_data_->GetActorAttribute(kActorAttributeDefensePhysical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeMagical, - actor_data_->GetActorAttribute(kActorAttributeDefenseMagical));
    damage_package->AddActorDamageAttribute(kActorDamageAttributeCritical, - actor_data_->GetActorAttribute(kActorAttributeDefenseCritical));


    // TODO: Critical;
    // TODO: Missed;
  }
  //ActorDamageData

} // namespace actor