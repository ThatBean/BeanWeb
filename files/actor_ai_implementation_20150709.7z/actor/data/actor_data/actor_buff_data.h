#ifndef ACTOR_BUFF_DATA_H
#define ACTOR_BUFF_DATA_H

#include "../actor_data_typedef.h"

namespace actor {

  class Actor;
  class ActorData;




  //also animation tag
  enum eActorAnimationPositionType
  {
    kActorAnimationPositionTop      = 7890001,
    kActorAnimationPositionMiddle   = 7890002,
    kActorAnimationPositionBottom   = 7890003,
    kActorAnimationPosition
  };


  enum eActorSlotResolveType
  {
    kActorSlotResolveKeepOld = 1,
    kActorSlotResolveKeepNew,
    kActorSlotResolve
  };

  //slot
  typedef struct tActorSlotData {
    int     data_id;
    eActorSlotResolveType resolve_type;
  } ActorSlotData;



  //currently max 64 flag type
  typedef unsigned long long BitFlag; //64bit data
  typedef struct tActorBitFlagData {
    void Clear() { flag = mute_flag = 0; }
    BitFlag GetFlag() { return flag & mute_flag; }

    int     data_id; //for record & debug
    BitFlag flag; //currently carried flags(max 64)
    BitFlag mute_flag;  //same as "immune", force remove active flags, default all bit 1, set 0 to mute bit
  } ActorBitFlagData;















  //buff data storage on the Actor, mainly for buff interaction (other data will be on Buff / Effect Object)
  class ActorBuffData
  {
  public:
    ActorBuffData(ActorData* actor_data);
    ~ActorBuffData();

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data);

    //slot
    bool ResolveSlot(int slot_id);  //return is slot available
    int ReserveSlot(int slot_id, int data_id, eActorSlotResolveType resolve_type);  //may return replaced data_id
    void ReleaseSlot(int slot_id);

    //bit_flag
    void AddBitFlag(int data_id, ActorBitFlagData bit_flag_data); //usually the data_id is the buff_script_object_id
    void RemoveBitFlag(int data_id);
    bool CheckBitFlag(BitFlag flag);
    BitFlag GetBitFlag();
    void UpdateBitFlag(); //merge all to buff_bit_flag_data_

    //currently in adapter
    void UpdateIncontrollable();

    //messy but messy, link MoveObject data
    void SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }
  
  private:
    ActorData*    actor_data_;

    //below id = buff_script_object_id
    std::map<int, ActorSlotData> buff_slot_map_;  //for buff conflict

    std::map<int, ActorBitFlagData> buff_bit_flag_data_map_; //currently carried flags
    ActorBitFlagData buff_bit_flag_data_;  //quick calculated access

  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*       actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_BUFF_DATA_H