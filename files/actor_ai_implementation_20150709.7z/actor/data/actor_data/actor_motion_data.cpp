#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"


namespace actor {

  //ActorMotionData
  ActorMotionData::ActorMotionData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }

  ActorMotionData::~ActorMotionData()
  {

  }

  void ActorMotionData::Update(float delta_time)
  {

  }

  //link OnDataOperation to selected signal
  void ActorMotionData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorPositionData(kActorMotionPositionMoveTarget)->Connect<ActorMotionData>(this, &ActorMotionData::OnPositionDataOperation);
  }

  //callback for data operation signal
  void ActorMotionData::OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassAttribute, actor_data_type, actor_data);
  }
  void ActorMotionData::OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassStatus, actor_data_type, actor_data);
  }
  void ActorMotionData::OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassPosition, actor_data_type, actor_data);
  }
  void ActorMotionData::OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data)
  {
    switch (actor_data_type)
    {
    case kActorMotionPositionMoveTarget:
      {
        switch (operation_type)
        {
        //case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            cocos2d::CCPoint move_target_position = actor_data->GetActorPosition(kActorMotionPositionMoveTarget);
            cocos2d::CCPoint animation_position = actor_data->GetActorPosition(kActorPositionAnimation);

            //cache speed unit
            cocos2d::CCPoint move_speed_unit = ccpSub(move_target_position, animation_position).normalize();
            actor_data->SetActorPosition(kActorMotionPositionMoveSpeedUnit, move_speed_unit);

            //check if direction change
            bool is_change_direction = abs(animation_position.x - move_target_position.x) >= ACTOR_DIRECTION_CHANGE_THRESHOLD;
            if (is_change_direction)
            {
              bool is_facing_left = move_target_position.x < animation_position.x;
              if (is_facing_left) actor_data->SetActorStatus(kActorAnimationStatusDirection, kActorAnimationDirectionLeft);
              else actor_data->SetActorStatus(kActorAnimationStatusDirection, kActorAnimationDirectionRight);
            }
          }
          break;
        }
      }
      break;
    }
  }
  //ActorMotionData


} // namespace actor