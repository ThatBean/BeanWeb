#ifndef ACTOR_ACTOR_H
#define ACTOR_ACTOR_H

#include "actor_ext_env.h"
#include "actor_ext_grid.h"

#include "data/actor_data.h"
#include "animation/actor_animation.h"

#include "game/actor/template_class/script_object.h"

namespace actor {

  class ActorBuff;
  class ActorControl;
  class LogicStateMachine;
  class MotionStateMachine;
  class ActorScriptExporter;


  class Actor : public ScriptObject
  {
  public:
    Actor();
    ~Actor();

    void    LinkScript(int actor_id, ActorExtEnv* actor_ext_env);  //script object, the link upwards to actor pool
    void    UnLinkScript();

    void*   GetScriptExporter() { return actor_script_exporter_; }  //script object

    void    Init(eActorModelType actor_model_type = kActorModelActor);
    void    Update(float delta_time);

    ActorExtEnv*      GetActorExtEnv() { return actor_ext_env_; }

    ActorControl*         GetControl() { return actor_control_; }
    LogicStateMachine*    GetLogicStateMachine() { return logic_state_machine_; }
    MotionStateMachine*   GetMotionStateMachine() { return motion_state_machine_; }
    ActorBuff*            GetBuff() { return actor_buff_; }
    ActorAnimation*       GetAnimation() { return actor_animation_; }
    ActorData*            GetActorData() { return actor_data_; }
    ActorScriptExporter*  GetActorScriptExporter() { return actor_script_exporter_; }

  public:
    eActorModelType  GetActorModelType() { return actor_model_type_; }
    bool             GetIsActorAlive();
    
    void             SetIsActorPause(bool is_actor_pause);
    bool             GetIsActorPause() { return is_actor_pause_; }
  private:
    eActorModelType       actor_model_type_;

    bool                  is_actor_pause_;

    ActorExtEnv*          actor_ext_env_;
    ActorScriptExporter*  actor_script_exporter_;

    ActorData*            actor_data_;  //collection of all actor-data-class, provide both data&functions

    //Notice:
    // below class will be & should be updated in Actor Update() by order
    ActorControl*         actor_control_; //Manual or Auto, may change Logic State
    ActorBuff*            actor_buff_; // TODO: Manage actor-side buff data&logic
    //ActorSkill*           actor_skill_; // TODO: Manage actor-side skill data&logic
    LogicStateMachine*    logic_state_machine_; //Manage Both Logic-State&Motion-State 
    MotionStateMachine*   motion_state_machine_;  //Manage Position and Animation
    ActorAnimation*       actor_animation_; //Manage Animation
  };



} // namespace actor


#endif // actor/actor.h
