#include "actor_logic_state_dead.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateDead::STATE_TYPE = kActorLogicStateDead;

  LogicStateDead* LogicStateDead::Instance()
  {
    static LogicStateDead instance;
    return &instance;
  }


  void LogicStateDead::OnEnter(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateDead][OnEnter]");
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateDead));
    //reset CD
    actor->GetActorData()->GetControlData()->ResetCountdownDead();
  }

  void LogicStateDead::OnExit(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateDead][OnExit]");
    //should not exit???
  }

  void LogicStateDead::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->AddLog("[LogicStateDead][Update]");
    //Dead logic
    if (actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      actor->GetMotionStateMachine()->ChangeState(NULL);
      actor->SetScriptObjectIsActive(false);
      actor->GetActorData()->GetBasicData()->ActorDeadCleanUp();
    }
  }
} // namespace actor