#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H


#include "game/army/unit/move_object.h"
// 
// namespace taomee {
//   namespace army {
//     class MoveObject;
//   }
// }

namespace actor {
  class ActorExtEnv;
  
  typedef taomee::army::MoveObject ActorAdapter;

  std::list<std::string>* ActorStringSplit(std::string& source_string, std::string delimiter);

  //Skill
  void ResetSkillAdapter(ActorAdapter* actor_adapter);
  void CommitSkillAdapter(ActorAdapter* actor_adapter, int skill_id, int skill_type, int target_actor_id);

  void PauseSkillAdapter(ActorAdapter* actor_adapter);
  void ResumeSkillAdapter(ActorAdapter* actor_adapter);

  void AutoReleaseSpecialSkill(int actor_id); //Special skill with pause, for auto control

  //Battle
  bool GetIsAllyActorAuto();
  bool GetIsActorExtEnvPVP();
  bool GetIsActorExtEnvPVPAuto();
  ActorExtEnv* GetActorExtEnv();

  void AlertEnemyPassRightBorder(int actor_id);

  //Actor Init & Data
  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter);

  void NastyActorInitAfterBasicDataInitAdapter(ActorAdapter* actor_adapter, Actor* actor);
  void NastyActorInitAnimationInitAdapter(ActorAdapter* actor_adapter, Actor* actor, bool is_simple_init);
  void NastyActorInitAfterAnimationInitAdapter(ActorAdapter* actor_adapter, Actor* actor);

  void NastyActorClearAnimationAdapter(ActorAdapter* actor_adapter, Actor* actor);
  
  const std::string GetDeadAnimationName(ActorAdapter* actor_adapter);
  const std::string GetSkeletonAnimationName(int card_id);
  const float GetSkeletonAnimationScale(int card_id);
} // namespace actor


#endif // ACTOR_ADAPTER_H
