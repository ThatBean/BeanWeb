#include "actor_animation.h"

#include "game/actor/actor.h"

#include "game/actor/animation/actor_animation_skeleton_animation.h"
#include "game/actor/animation/actor_animation_overhead_layer.h"
#include "game/actor/animation/actor_animation_bottom_sync_layer.h"

#include "game/actor/motion/actor_motion_state_machine.h"
#include "game/actor/actor_adapter.h"

#include "engine/script/lua_tinker_manager.h"

#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_color.h"

#include "engine/animation/projectile_animation.h"
#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/unit_constants.h"

namespace actor {

  //ActorAnimation
  ActorAnimation::ActorAnimation(Actor* actor)
    :actor_(actor),
    actor_node_(NULL),

    animation_skeleton_animation_(NULL),
    animation_overhead_layer_(NULL),
    animation_bottom_sync_layer_(NULL),

    label_debug_info_widget_(NULL),

    program_shader_color_(NULL),
    shader_color_left_time_(0),
    shader_color_total_time_(0)
  {
    shader_type_ = taomee::shader::kShaderDefault;
  }

  ActorAnimation::~ActorAnimation()
  {
    Clear();
  }

  void ActorAnimation::Clear()
  {
    if (animation_bottom_sync_layer_) delete animation_bottom_sync_layer_;
    if (animation_overhead_layer_) delete animation_overhead_layer_;
    if (animation_skeleton_animation_) 
    {
      delete animation_skeleton_animation_;
      actor_node_ = NULL; //same node
    }

    if (actor_node_) actor_node_->removeFromParentAndCleanup(true);

    animation_bottom_sync_layer_ = NULL;
    animation_overhead_layer_ = NULL;
    animation_skeleton_animation_ = NULL;
    actor_node_ = NULL;

    label_debug_info_widget_ = NULL;

    program_shader_color_ = NULL;
    shader_color_left_time_ = 0;
    shader_color_total_time_ = 0;

    shader_type_ = taomee::shader::kShaderDefault;
  }

  void ActorAnimation::Init(eActorAnimationModelType animation_model_type)
  {
    actor_->GetActorData()->InitActorStatus(kActorStatusAnimationModel, animation_model_type);

    //init actor_node_
    assert(actor_node_ == NULL);
    if (animation_model_type & kActorAnimationModuleSkeletonAnimation) //replace actor_node_
    {
      int card_id = actor_->GetActorData()->GetActorStatus(kActorStatusCardId);

      animation_skeleton_animation_ = new ActorAnimationSkeletonAnimation(actor_);
      animation_skeleton_animation_->Init(GetSkeletonAnimationName(card_id), GetSkeletonAnimationScale(card_id));
      actor_node_ = animation_skeleton_animation_->GetSkeletonAnimationNode();
    }

    if (!actor_node_) //default actor_node_
    {
      CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/agoui_icon/agoui_icon_ex.plist", "ui/agoui_icon/agoui_icon_ex.pvr.ccz");
      std::string file_name;
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusCareer))
      {
      case kActorCareerWarrior:
        file_name = "agoui_job_0.png";
        break;
      case kActorCareerKnight:
        file_name = "agoui_job_4.png";
        break;
      case kActorCareerPriest:
        file_name = "agoui_job_3.png";
        break;
      case kActorCareerWizard:
        file_name = "agoui_job_2.png";
        break;
      case kActorCareerArcher:
        file_name = "agoui_job_1.png";
        break;
      default:
        file_name = "agoui_boss_flag.png";
        break;
      }
      CCSprite* default_sprite_node = CCSprite::createWithSpriteFrameName(file_name.c_str());
      default_sprite_node->setAnchorPoint(ccp(0.5f, 0.5f));
      actor_node_ = default_sprite_node;
    }

    if (animation_model_type & kActorAnimationModuleOverheadLayer) 
    {
      animation_overhead_layer_ = new ActorAnimationOverheadLayer(actor_);
      animation_overhead_layer_->Init();
      cocos2d::extension::UILayer* overhead_layer = animation_overhead_layer_->GetOverheadLayer();
      overhead_layer->setPosition(ccp(0, GetActorVisualHeight()));
      actor_node_->addChild(overhead_layer, taomee::army::kHitPointBarFlag, taomee::army::kHitPointBarFlag);
    }

    if (animation_model_type & kActorAnimationModuleBottomSyncLayer) 
    {
      animation_bottom_sync_layer_ = new ActorAnimationBottomSyncLayer(actor_);
      animation_bottom_sync_layer_->Init();
    }

    //size debug
    bool is_show_skeleton_animation_box = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_show_actor_box");
    if (is_show_skeleton_animation_box)
    {
      CCDrawNode* debug_box_draw_node = CCDrawNode::create();
      CCRect rect_box = GetActorBox();
      rect_box.origin = ccpSub(rect_box.origin, actor_node_->getPosition());
      CCPoint vertex_list[4]={
        ccp(rect_box.getMinX(), rect_box.getMinY()), ccp(rect_box.getMaxX(), rect_box.getMinY()),
        ccp(rect_box.getMaxX(), rect_box.getMaxY()), ccp(rect_box.getMinX(), rect_box.getMaxY())};
      ccColor4F fill_color = {1, 0, 0, 0.1};  //transparent
      float debug_box_border_width = 3;
      ccColor4F border_color = {1, 1, 0, 1};  //yellow
      debug_box_draw_node->drawPolygon(vertex_list, 4, fill_color, debug_box_border_width, border_color);
      actor_node_->addChild(debug_box_draw_node, -1);
    }

    //debug info
    bool is_show_debug_info = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_show_actor_info");
    if (is_show_debug_info)
    {
      if (label_debug_info_widget_) label_debug_info_widget_->removeFromParentAndCleanup(true);
      label_debug_info_widget_ = cocos2d::CCLabelBMFont::create();
      label_debug_info_widget_->setFntFile("ui/font/font_2.fnt"); // TODO: use relative path
      label_debug_info_widget_->setPosition(ccp(0, -20));
      label_debug_info_widget_->setAnchorPoint(ccp(0.5, 1));
      label_debug_info_widget_->setScale(0.4);
      label_debug_info_widget_->setZOrder(99999);
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance))
      {
      case kActorAppearanceCharacter:
        label_debug_info_widget_->setColor(ccc3(255, 220, 220));
        break;
      case kActorAppearanceEnemyBoss:
        label_debug_info_widget_->setColor(ccc3(220, 255, 220));
        break;
      case kActorAppearanceEnemyPawn:
        label_debug_info_widget_->setColor(ccc3(220, 220, 255));
        break;
      }
      actor_node_->addChild(label_debug_info_widget_);
    }

  }



  void ActorAnimation::Update(float delta_time)
  {
    //pause
    bool is_status_pause = actor_->GetActorData()->GetActorStatusBool(kActorAnimationStatusIsPaused);

    if (animation_skeleton_animation_) animation_skeleton_animation_->Update(delta_time);
    if (animation_overhead_layer_) animation_overhead_layer_->Update(delta_time);
    if (animation_bottom_sync_layer_) animation_bottom_sync_layer_->Update(delta_time);

    //always
    //animation position
    if (actor_node_)
    {
      cocos2d::CCPoint data_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint animation_position = actor_node_->getPosition();

      if (actor_->GetActorData()->GetSpecifiedData()->IsPositionValid(data_position) == false
        && actor_->GetActorData()->GetSpecifiedData()->IsPositionValid(animation_position) == true) //check position, only moving out of box is blocked
      {
        actor_->GetActorData()->AddErrorLogF("[kActorPositionAnimation] moving out of box is blocked (%f, %f)", data_position.x, data_position.y);

        if (actor_->GetActorData()->GetActorStatus(kActorStatusMotionState) == kActorMotionStateMove)
        {
          if (actor_->GetActorData()->GetControlData()->IsSetTarget()) actor_->GetActorData()->GetControlData()->ResetTarget();
          if (actor_->GetActorData()->GetControlData()->IsSetPosition()) actor_->GetActorData()->GetControlData()->SetPosition(animation_position);
        }

        actor_->GetActorData()->SetActorPosition(kActorPositionAnimation, animation_position);
      }
      else
      {
        actor_node_->setPosition(data_position);
      }
    }

    //update color shader
    if (program_shader_color_)
    {
      if (shader_color_left_time_ > 0) 
      {
        shader_color_left_time_ -= delta_time;
        taomee::shader::ProgramChangeColor* program_shader_color = (taomee::shader::ProgramChangeColor*)program_shader_color_;
        float time_progress = shader_color_left_time_ / shader_color_total_time_ * 2.0; //0 ~ 1 opacity++, 1 ~ 2 opacity--
        float color_opacity = (time_progress <= 1 ? time_progress : 2 - time_progress);
        program_shader_color->SetTime(color_opacity);
      }
      else 
      {
        RemoveColorShader();
      }
    }

    //debug info
    if (label_debug_info_widget_)
    {
      cocos2d::CCPoint position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint grid = GetGridFromPosition(position);

      char debug_info[1024];  //please don't overflow
      sprintf(debug_info, " ID:%ld CID:%ld \n HP:%d%% EN:%d%% \n [%d,%d] [%d,%d]", 
        actor_->GetScriptObjectId(), 
        actor_->GetActorData()->GetActorStatus(kActorStatusCardId), 
        int(100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax)),
        int(100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyMax)),
        int(position.x), int(position.y),
        int(grid.x), int(grid.y));
      label_debug_info_widget_->setString(debug_info);
    }
  }


  cocos2d::CCRect ActorAnimation::GetActorBox()
  {
    if (animation_skeleton_animation_) 
    {
      return GetAnimationSkeletonAnimation()->GetSkeletonAnimationBox();
    }
    else 
    {
      CCPoint actor_position = actor_node_->getPosition();
      CCSize actor_size = actor_node_->getContentSize();
      return cocos2d::CCRect(actor_position.x, actor_position.y, actor_size.width, actor_size.height);
    }
  }

  float ActorAnimation::GetActorVisualHeight()
  {
    if (animation_skeleton_animation_) return animation_skeleton_animation_->GetSkeletonAnimationNode()->GetBonePositionInSkeleton(taomee::kBoneTypeHealthBar).y;
    else return actor_node_->getContentSize().height;
  }

  void ActorAnimation::ChangeAnimation(const std::string animation_name, const int cycle_count/* = -1*/, const float speed/* = 1.0f*/)
  {
    if (animation_skeleton_animation_) return GetAnimationSkeletonAnimation()->ChangeSkeletonAnimation(animation_name, cycle_count, speed);
    else assert(false);
  }


  void ActorAnimation::DeadAnimation(std::string animation_name)
  {
    RemoveColorShader();
    SetStatusShader(taomee::shader::kShaderDefault);

    ChangeAnimation(animation_name, 1);

    if (animation_skeleton_animation_)
    {
      animation_skeleton_animation_->GetSkeletonAnimationNode()->GetBodyNode()->runAction(cocos2d::CCFadeOut::create(ACTOR_CONTROL_COUNTDOWN_DEAD));
      animation_skeleton_animation_->GetSkeletonAnimationNode()->FadeOutShadow();
    }

    if (animation_overhead_layer_)
    {
      animation_overhead_layer_->GetOverheadLayer()->setVisible(false);
    }
  }



  void ActorAnimation::SetColorShader(cocos2d::ccColor4F shader_color, float last_time)
  {
    if (actor_->GetIsActorAlive() == false) return;
    if (shader_type_ != taomee::shader::kShaderDefault) return;

    shader_color_total_time_ = last_time;
    shader_color_left_time_ = last_time;
    if (!program_shader_color_ && animation_skeleton_animation_)
    {
      taomee::shader::ProgramChangeColor* program_shader_color = (taomee::shader::ProgramChangeColor*)taomee::shader::ShaderManager::GetInstance()->GetShaderWithType(taomee::shader::kShaderChangeColorTime);
      program_shader_color_ = program_shader_color;
      shader_color_ = shader_color;

      program_shader_color->SetTime(0.0f);
      program_shader_color->SetColor(shader_color);
      taomee::shader::SetAllNodeWithShader(animation_skeleton_animation_->GetSkeletonAnimationNode()->GetBodyNode(), program_shader_color);
    }
  }


  void ActorAnimation::RemoveColorShader()
  {
    if (program_shader_color_)
    {
      program_shader_color_ = NULL; //first clear color shader
      SetStatusShader(shader_type_);  //then reset shader to status shader
    }
  }


  void ActorAnimation::SetStatusShader(int shader_type)
  {
    shader_type_ = shader_type;
    
    if (program_shader_color_) program_shader_color_ = NULL;  //interrupt color shader

    if (animation_skeleton_animation_) taomee::shader::SetAllNodeWithShaderType(animation_skeleton_animation_->GetSkeletonAnimationNode()->GetBodyNode(), (taomee::shader::eShaderType)shader_type_);
    else taomee::shader::SetAllNodeWithShaderType(actor_node_, (taomee::shader::eShaderType)shader_type_);
  }




  cocos2d::CCNode* ActorAnimation::AttachArmatureAnimation(int tag, cocos2d::CCPoint position_offset, const std::string & armature_name, const std::string & animation_name)
  {
    if (armature_name.size()==0) return NULL;

    actor_node_->removeChildByTag(tag);

    CCArmature* armature_animation = CCArmature::create();
    actor_node_->addChild(armature_animation, 1, tag);

    if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
    {
      std::string skeleton_config = taomee::kDefaultSkeletonFilePath+armature_name+".xml";
      std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+armature_name+".plist";
      std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+armature_name+".pvr.ccz";
      CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
    }
    armature_animation->init(armature_name.c_str());
    armature_animation->getAnimation()->play(animation_name.c_str(), 0, -1, 0);
    armature_animation->setPosition(position_offset);
    armature_animation->setRotationY(actor_->GetActorData()->GetActorStatus(kActorAnimationStatusDirection) == kActorAnimationDirectionRight ? 180 : 0); 

    return armature_animation;
  }

  cocos2d::CCNode* ActorAnimation::AttachProjectileAnimation(int tag, cocos2d::CCPoint position_offset, const std::string& projectile_name)
  {
    if (projectile_name.size()==0) return NULL;

    actor_node_->removeChildByTag(tag);

    taomee::ProjectileAnimation* projectile_animation = new taomee::ProjectileAnimation();
    actor_node_->addChild(projectile_animation, 1, tag);

    projectile_animation->initWithName(projectile_name.c_str());
    projectile_animation->setPositionType(kCCPositionTypeRelative);
    projectile_animation->setPosition(ccpAdd(projectile_animation->getPosition(), position_offset));
    //projectile_animation->setParticleFlipX(actor_->GetActorData()->GetActorStatus(kActorAnimationStatusDirection) == kActorAnimationDirectionRight ? true : false); 
    projectile_animation->release();

    return projectile_animation;
  }

  void ActorAnimation::RemoveAttachAnimation(int tag)
  {
    actor_node_->removeChildByTag(tag);
  }


  ActorArmatureQueue* ActorAnimation::GetArmatureQueueByTag(int tag)
  {
    actor_node_->removeChildByTag(tag);

    CCArmature* armature_animation = CCArmature::create();
    actor_node_->addChild(armature_animation, 1, tag);
    armature_animation->setRotationY(actor_->GetActorData()->GetActorStatus(kActorAnimationStatusDirection) == kActorAnimationDirectionRight ? 180 : 0); 

    ActorArmatureQueue* armature_queue = new ActorArmatureQueue;
    armature_queue->Attach(armature_animation);

    return armature_queue;
  }


  //ActorAnimation









  ActorArmatureQueue::ActorArmatureQueue() 
    :attached_armature_(NULL)
  {}

  ActorArmatureQueue::~ActorArmatureQueue() 
  {
    printf("[~ActorArmatureQueue] successful");
  }

  void ActorArmatureQueue::OnMovementEvent(cocos2d::extension::CCArmature* armature, cocos2d::extension::MovementEventType event_type,const char* movement_name)
  {
    switch (event_type)
    {
    case COMPLETE:
      PlayNext();
      break;
    case LOOP_COMPLETE:
      break;
    default:
      break;
    }
  }

  void ActorArmatureQueue::AppendArmatureName(const std::string &armature_name, const std::string &animation_name)
  {
    armature_name_queue_.push_back(armature_name);
    animation_name_queue_.push_back(animation_name);
  }

  void ActorArmatureQueue::Attach(cocos2d::extension::CCArmature* armature) 
  {
    assert(attached_armature_ == NULL);

    armature->getAnimation()->setMovementEventCallFunc(this, (SEL_MovementEventCallFunc)(&ActorArmatureQueue::OnMovementEvent));
    attached_armature_ = armature;

    this->autorelease();
    this->retain();
  }

  void ActorArmatureQueue::PlayNext()
  {
    if (attached_armature_ && armature_name_queue_.size() > 0)
    {
      std::string armature_name = *(armature_name_queue_.begin());
      std::string animation_name = *(animation_name_queue_.begin());

      if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
      {
        std::string skeleton_config = taomee::kDefaultSkeletonFilePath+armature_name+".xml";
        std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+armature_name+".plist";
        std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+armature_name+".pvr.ccz";
        CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
      }

      attached_armature_->init(armature_name.c_str());
      attached_armature_->getAnimation()->play(animation_name.c_str(), 0, -1, 0);

      armature_name_queue_.pop_front();
      animation_name_queue_.pop_front();
    }
  }


} // namespace actor