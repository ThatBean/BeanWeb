#ifndef ACTOR_ANIMATION_H
#define ACTOR_ANIMATION_H

#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace taomee {
  class SkeletonAnimation;
}


namespace actor {

  class Actor;
  class ActorAnimationSkeletonAnimation;
  class ActorAnimationOverheadLayer;
  class ActorAnimationBottomSyncLayer;


  class ActorArmatureQueue : public CCObject
  {
  public:
    ActorArmatureQueue();
    ~ActorArmatureQueue();
    void OnMovementEvent(cocos2d::extension::CCArmature* armature, cocos2d::extension::MovementEventType event_type,const char* movement_name);
    void AppendArmatureName(const std::string &armature_name, const std::string &animation_name);
    void Attach(cocos2d::extension::CCArmature* armature);
    void PlayNext();
    cocos2d::extension::CCArmature* GetAttachedArmature() { return attached_armature_; }
  private:
    std::list<std::string> armature_name_queue_;
    std::list<std::string> animation_name_queue_;
    cocos2d::extension::CCArmature* attached_armature_;
  };




  class ActorAnimation
  {
  public:
    ActorAnimation(Actor* actor_);
    ~ActorAnimation();

    void Clear();
    void Init(eActorAnimationModelType animation_model_type);

    void Update(float delta_time);

    ActorAnimationSkeletonAnimation*  GetAnimationSkeletonAnimation() { return animation_skeleton_animation_; }
    ActorAnimationOverheadLayer*      GetAnimationOverheadLayer() { return animation_overhead_layer_; }
    ActorAnimationBottomSyncLayer*    GetAnimationBottomSyncLayer() { return animation_bottom_sync_layer_; }

    cocos2d::CCNode* GetActorNode() { return actor_node_; }
    cocos2d::CCRect GetActorBox();
    float GetActorVisualHeight();

    void ChangeAnimation(const std::string animation_name, const int cycle_count = -1, const float speed = 1.0f);
    void DeadAnimation(std::string animation_name);  //play dead cc action

    void SetColorShader(cocos2d::ccColor4F shader_color, float last_time);
    void RemoveColorShader();
    void SetStatusShader(int shader_type);

    cocos2d::CCNode* AttachArmatureAnimation(int tag, cocos2d::CCPoint position_offset, const std::string & armature_name, const std::string & animation_name);
    cocos2d::CCNode* AttachProjectileAnimation(int tag, cocos2d::CCPoint position_offset, const std::string& projectile_name);
    void RemoveAttachAnimation(int tag);
    
    ActorArmatureQueue* GetArmatureQueueByTag(int tag);
  private:
    Actor* actor_;

    cocos2d::CCNode*  actor_node_;  //default CCSprite node or ActorAnimationSkeletonAnimation

    ActorAnimationSkeletonAnimation*  animation_skeleton_animation_;
    ActorAnimationOverheadLayer*      animation_overhead_layer_;
    ActorAnimationBottomSyncLayer*    animation_bottom_sync_layer_;

    cocos2d::CCLabelBMFont* label_debug_info_widget_;

    //selection shader
    cocos2d::ccColor4F shader_color_;
    cocos2d::CCGLProgram* program_shader_color_;  //actually taomee::shader::ProgramChangeColor*
    float shader_color_left_time_;
    float shader_color_total_time_;

    // TODO: save to actor data
    //status shader | will conflict with selection shader(use status shader only)
    int shader_type_; //default is kShaderDefault
  };
} // namespace actor


#endif // ACTOR_ANIMATION_H