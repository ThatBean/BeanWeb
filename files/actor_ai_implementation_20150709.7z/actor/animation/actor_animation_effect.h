#ifndef ACTOR_ANIMATION_EFFECT_H
#define ACTOR_ANIMATION_EFFECT_H

#include "game/actor/data/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorArmatureQueue;
//   class ActorArmatureQueue : public CCObject
//   {
//   public:
//     ActorArmatureQueue();
//     ~ActorArmatureQueue();
//     void OnMovementEvent(cocos2d::extension::CCArmature* armature, cocos2d::extension::MovementEventType event_type,const char* movement_name);
//     void AppendArmatureName(const std::string &armature_name, const std::string &animation_name);
//     void Attach(cocos2d::extension::CCArmature* armature);
// 
//     void PlayNext();
//   private:
//     std::list<std::string> armature_name_queue_;
//     std::list<std::string> animation_name_queue_;
//     cocos2d::extension::CCArmature* attached_armature_;
//   };




  class ActorAnimationEffect
  {
  public:
    ActorAnimationEffect(Actor* actor_);
    ~ActorAnimationEffect();

    void Clear();
    void Init();

    void Update(float delta_time);

    cocos2d::CCNode* PlayArmatureAnimation(cocos2d::CCNode* parent_node, int tag, cocos2d::CCPoint position_offset, const std::string & armature_name, const std::string & animation_name);
    ActorArmatureQueue* GetArmatureQueueByTag(cocos2d::CCNode* parent_node, int tag);
    void RemoveArmatureAnimation(cocos2d::CCNode* parent_node, int tag);

    cocos2d::CCNode* PlayProjectileAnimation(cocos2d::CCNode* parent_node, int tag,  const std::string& projectile_name, cocos2d::CCPoint position_offset);
    void RemoveProjectileAnimation(cocos2d::CCNode* parent_node, int tag);

  private:
    Actor* actor_;
  };
} // namespace actor


#endif // ACTOR_ANIMATION_EFFECT_H