#include "actor_animation_effect.h"

#include "game/actor/actor.h"

#include "game/actor/actor_adapter.h"

#include "engine/script/lua_tinker_manager.h"

#include "engine/animation/projectile_animation.h"
#include "engine/animation/skeleton_animation.h"
#include "game/army/unit/unit_constants.h"

namespace actor {

  //ActorAnimationEffect
  ActorAnimationEffect::ActorAnimationEffect(Actor* actor)
    :actor_(actor)
  {
    //
  }

  ActorAnimationEffect::~ActorAnimationEffect()
  {
    Clear();
  }

  void ActorAnimationEffect::Clear()
  {
    
  }

  void ActorAnimationEffect::Init()
  {
    
  }


  void ActorAnimationEffect::Update(float delta_time)
  {
    
  }


  cocos2d::CCNode* ActorAnimationEffect::PlayArmatureAnimation(cocos2d::CCNode* parent_node, int tag, cocos2d::CCPoint position_offset, const std::string & armature_name, const std::string & animation_name)
  {
    if (armature_name.size()==0) return NULL;

    //if (skeleton_animation_node_->getChildByTag(tag)) return skeleton_animation_node_->getChildByTag(tag);
    parent_node->removeChildByTag(tag);

    CCArmature* armature_animation = CCArmature::create();
    parent_node->addChild(armature_animation, 1, tag);
    armature_animation->setPosition(position_offset);
    //armature_animation->setRotationY(skeleton_animation_node_->GetDirection() == taomee::kDirectionRight ? 180 : 0); 

    if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(armature_name.c_str()) == NULL)
    {
      std::string skeleton_config = taomee::kDefaultSkeletonFilePath+armature_name+".xml";
      std::string skeleton_plist = taomee::kDefaultSkeletonFilePath+armature_name+".plist";
      std::string skeleton_texture = taomee::kDefaultSkeletonFilePath+armature_name+".pvr.ccz";
      CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(skeleton_texture.c_str(), skeleton_plist.c_str(), skeleton_config.c_str());
    }

    armature_animation->init(armature_name.c_str());
    armature_animation->getAnimation()->play(animation_name.c_str(), 0, -1, 0);

    return armature_animation;
  }


  ActorArmatureQueue* ActorAnimationEffect::GetArmatureQueueByTag(cocos2d::CCNode* parent_node, int tag)
  {
    parent_node->removeChildByTag(tag);

    CCArmature* armature_animation = CCArmature::create();
    parent_node->addChild(armature_animation, 1, tag);
    //armature_animation->setRotationY(skeleton_animation_node_->GetDirection() == taomee::kDirectionRight ? 180 : 0); 

    ActorArmatureQueue* armature_queue = new ActorArmatureQueue;
    armature_queue->Attach(armature_animation);

    return armature_queue;
  }

  void ActorAnimationEffect::RemoveArmatureAnimation(cocos2d::CCNode* parent_node, int tag)
  {
    parent_node->removeChildByTag(tag);
  }

  cocos2d::CCNode* ActorAnimationEffect::PlayProjectileAnimation(cocos2d::CCNode* parent_node, int tag, const std::string& projectile_name, cocos2d::CCPoint position_offset)
  {
    if (projectile_name.size()==0) return NULL;

    parent_node->removeChildByTag(tag);

    taomee::ProjectileAnimation* projectile_animation = new taomee::ProjectileAnimation();
    projectile_animation->initWithName(projectile_name.c_str());
    projectile_animation->setPositionType(kCCPositionTypeRelative);
    projectile_animation->setPosition(ccpAdd(projectile_animation->getPosition(), position_offset));

    parent_node->addChild(projectile_animation, 1, tag);
    projectile_animation->release();

    return projectile_animation;
  }

  void ActorAnimationEffect::RemoveProjectileAnimation(cocos2d::CCNode* parent_node, int tag)
  {
    parent_node->removeChildByTag(tag);
  }
  //ActorAnimationEffect
} // namespace actor