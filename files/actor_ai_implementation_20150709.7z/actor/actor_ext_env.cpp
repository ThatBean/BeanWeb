#include "actor_ext_env.h"

#include "actor.h"
#include "actor_ext_grid.h"
#include "actor_ext_user_operation.h"

//#include "game/battle/tiled_map/coordinate_helper.h"

namespace actor {
    ActorExtEnv::ActorExtEnv()
      :is_pause_(false)
    {
      actor_map_.clear();

      actor_focus_map_.clear();

      actor_ext_grid_ = new ActorExtGrid(this);
      actor_ext_user_operation_ = new ActorExtUserOperation(this);
    }

    ActorExtEnv::~ActorExtEnv()
    {
      Clear();

      if (actor_ext_grid_) delete actor_ext_grid_;
      if (actor_ext_user_operation_) delete actor_ext_user_operation_;

      actor_ext_grid_ = NULL;
      actor_ext_user_operation_ = NULL;
    }

    void ActorExtEnv::Clear()
    {
      std::map<int, Actor*>::iterator actor_iterator = actor_map_.begin();
      while(actor_iterator != actor_map_.end())
      {
        Actor* actor = actor_iterator->second;
        actor->GetActorData()->AddErrorLogF("[Error][ActorExtEnv][Clear] possible leaking actor, ID:%d", actor->GetScriptObjectId());
        assert(false);
        actor->UnLinkScript();
        delete actor;
        ++actor_iterator;
      }
      actor_map_.clear();

      actor_focus_map_.clear();
      if (actor_ext_grid_) actor_ext_grid_->Clear();
      if (actor_ext_user_operation_) actor_ext_user_operation_->Clear();
    }


    void ActorExtEnv::Update(float delta_time)
    {
      //update grid
      actor_ext_grid_->UpdateActorGridList();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetScriptObjectIsActive()) actor->Update(delta_time);
        ++iterator;
      }
    }


    Actor* ActorExtEnv::CreateActor() //will return actor_id
    {
      int actor_id = GetValidId();
      
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule

      return CreateActor(actor_id);
    }

    Actor* ActorExtEnv::CreateActor(int actor_id) //alternative, predefined actor_id
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        assert(false);
        return actor_map_[actor_id];
      }
      else
      {
        Actor* actor = new Actor;
        actor_map_[actor_id] = actor;
        actor->LinkScript(actor_id, this);  //script object
        return actor;
      }
    }

    void ActorExtEnv::RemoveActor(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        Actor* actor = actor_map_[actor_id];
        actor_map_.erase(actor_id);
        actor->UnLinkScript();
        delete actor;
      }
      else
      {
        assert(false);
      }
    }

    Actor* ActorExtEnv::GetActorById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end()) return actor_map_[actor_id];
      else return NULL;
    }

    std::list<Actor*>* ActorExtEnv::GetActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>;
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetIsActorAlive() && IsPositionXInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)))
          actor_list->push_back(actor);
        ++iterator;
      }
      return actor_list;
    }


    //should move ? should move
    //for skill pause need
    void ActorExtEnv::AddActorFocusById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end()) 
      {
        actor_focus_map_[actor_id] = actor_map_[actor_id];
        actor_map_[actor_id]->GetActorData()->AddErrorLogF("[ActorExtEnv][AddActorFocusById] Current Focused:%d", actor_focus_map_.size());
      }
      else 
      {
        assert(false);
      }
    }

    void ActorExtEnv::PauseActorExceptFocus()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;

        if (actor_focus_map_.find(actor_id) != actor_focus_map_.end()) 
        {
          actor->GetActorData()->AddLogF("[ActorExtEnv][PauseActorExceptFocus] Focused");
          actor->SetIsActorPause(false);
        }
        else 
        {
          actor->GetActorData()->AddLogF("[ActorExtEnv][PauseActorExceptFocus] Paused");
          actor->SetIsActorPause(true);
        }

        ++iterator;
      }
    }

    void ActorExtEnv::ClearActorPause()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        actor->SetIsActorPause(false);

        ++iterator;
      }
    }

    void ActorExtEnv::SetIsPause(bool is_pause) 
    { 
      if (is_pause) PauseActorExceptFocus();
      else ClearActorPause();
      is_pause_ = is_pause; 
    }

    //for skill counter attack
    void ActorExtEnv::SkillAttackedNotification(int from_actor_id, int to_actor_id, int skill_id, int health_change)
    {
      Actor* from_actor = GetActorById(from_actor_id);
      Actor* to_actor = GetActorById(to_actor_id);

      if (!from_actor || !to_actor || health_change <= 0)
        return;

      if (to_actor->GetActorData()->GetControlData()->GetMaximumControlPriority() >= kActorControlPriorityCounterAttackAuto)
        return;

      cocos2d::CCPoint from_actor_position = from_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint to_actor_position = to_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

      float distance = from_actor_position.getDistance(to_actor_position);

      if (distance > to_actor->GetAnimation()->GetActorBox().size.width * 1.5
        || from_actor->GetActorData()->GetActorStatus(kActorStatusFaction) == to_actor->GetActorData()->GetActorStatus(kActorStatusFaction))
        return;

      //move to position only
      to_actor->GetActorData()->GetUserControlData()->SetPosition(from_actor_position, kActorControlPriorityMoveAuto);
    }
    //should move ? should move

} // namespace actor