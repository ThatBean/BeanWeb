#ifndef ACTOR_EXT_ENV_H
#define ACTOR_EXT_ENV_H

#include "cocos2d.h"
#include "engine/base/basictypes.h"

#include "game/actor/template_class/script_object.h"

namespace actor {

  class Actor;
  class ActorExtGrid;
  class ActorExtUserOperation;


  // the map / battlefield where actors live in (Actor Pool)
  class ActorExtEnv : public ScriptObjectPool  //ActorExternalEnvironment
  {
  public:
    ActorExtEnv();
    ~ActorExtEnv();

    void      Clear();
    void      Update(float delta_time);
  
  public:
    Actor*    CreateActor(); //will return actor with valid id
    Actor*    CreateActor(int actor_id); //alternative, predefined actor_id
    void      RemoveActor(int actor_id);
    Actor*    GetActorById(int actor_id);

    std::list<Actor*>*        GetActorList();  //should delete after use, alive and in grid actor only, mostly used in trigger raw actor list
    std::map<int, Actor*>*    GetActorMap() { return &actor_map_; }

    //should move ? should move
    //for skill pause need
    void AddActorFocusById(int actor_id);
    void ClearActorFocus() { actor_focus_map_.clear(); }
    void PauseActorExceptFocus();
    void ClearActorPause();

    void SetIsPause(bool is_pause);

    //for geometry
    ActorExtGrid*           GetActorExtGrid() { return actor_ext_grid_; }
    //for touch
    ActorExtUserOperation*  GetUserOperation() { return actor_ext_user_operation_; }

    //for skill counter attack
    void SkillAttackedNotification(int from_actor_id, int to_actor_id, int skill_id, int health_change);
    //should move ? should move

  private:
    std::map<int, Actor*>         actor_map_;

    ActorExtGrid*             actor_ext_grid_;
    ActorExtUserOperation*    actor_ext_user_operation_;

    //for skill pause need
    std::map<int, Actor*>     actor_focus_map_;
    bool                      is_pause_;
  };

} // namespace actor


#endif // ACTOR_EXT_ENV_H