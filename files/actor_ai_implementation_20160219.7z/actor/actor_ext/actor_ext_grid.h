#ifndef ACTOR_EXT_GRID_H
#define ACTOR_EXT_GRID_H

#include "cocos2d.h"
#include "engine/base/basictypes.h"

namespace actor {
  class Actor;
  class ActorExtEnv;


  //Position & Grid
  cocos2d::CCPoint GetPositionFromGrid(const cocos2d::CCPoint& grid_position);
  cocos2d::CCPoint GetPositionFromGrid(const int& grid_x, const int& grid_y);
  float GetPositionXFromGridX(const int& grid_x);
  float GetPositionYFromGridY(const int& grid_y);

  cocos2d::CCPoint GetGridFromPosition(const cocos2d::CCPoint& position);
  cocos2d::CCPoint GetGridFromPosition(const float& position_x, const float& position_y);
  int GetGridXFromPositionX(const float& position_x);
  int GetGridYFromPositionY(const float& position_y);

  float GetGridBoxAverageWidth();
  float GetGridBoxAverageHeight();

  bool IsPositionInGrid(const cocos2d::CCPoint& position);
  bool IsPositionXInGrid(const cocos2d::CCPoint& position);
  bool IsPositionYInGrid(const cocos2d::CCPoint& position);
  cocos2d::CCPoint SnapToGrid(const cocos2d::CCPoint& position);
  cocos2d::CCPoint SnapXToGrid(const cocos2d::CCPoint& position);
  cocos2d::CCPoint SnapYToGrid(const cocos2d::CCPoint& position);
  //Position & Grid



  // the geometry map where actors live in (Actor Pool)
  class ActorExtGrid  //ActorExternalGrid
  {
  public:
    ActorExtGrid(ActorExtEnv* actor_ext_env);
    ~ActorExtGrid();

    void Clear();


    //position/animation related
    Actor*    GetActorAtGrid(const cocos2d::CCPoint& target_grid_position);
    Actor*    GetActorAtPosition(const cocos2d::CCPoint& target_position);
    std::list<Actor*>*    GetActorListAtGrid(const cocos2d::CCPoint& target_grid_position);
    std::list<Actor*>*    GetActorListAtPosition(const cocos2d::CCPoint& target_position);

    std::list<Actor*>*    GetActorListByDistance(const cocos2d::CCPoint& center_position);

    //index: the index in a near-frist list. [0, +] by near; [-, -1] by far;
    Actor* QuickGetActorByFactionAndPosition(int target_faction, const cocos2d::CCPoint& center_position, int index_in_near_first_list);
    //position/animation related


    //position decision
    std::list<cocos2d::CCPoint>* GetValidGridList(Actor* actor);  //need delete after use 
    cocos2d::CCPoint GetValidGrid(Actor* actor, const cocos2d::CCPoint& preferred_grid_position);
    cocos2d::CCPoint GetValidGrid(Actor* actor);  //for idle grid decision
    //position decision


    //for actor grid need, update every Update()
    void UpdateActorGridList();
    std::list< std::pair<Actor*, cocos2d::CCPoint> >* GetActorGridList() { return &actor_grid_list_; }
    bool CheckActorGridOverlap(Actor* actor);
    bool CheckActorGridOverlap(Actor* actor, const cocos2d::CCPoint& grid_position);
    //for actor grid need, update every Update()

  private:
    std::list< std::pair<Actor*, cocos2d::CCPoint> >     actor_grid_list_;

    ActorExtEnv* actor_ext_env_;
  };

} // namespace actor


#endif // ACTOR_EXT_GRID_H