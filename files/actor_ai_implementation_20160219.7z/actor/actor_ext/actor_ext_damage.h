#ifndef ACTOR_EXT_DAMAGE_H
#define ACTOR_EXT_DAMAGE_H

#include "game/actor/template_class/actor_data_class.h"
#include "game/actor/template_class/actor_data_map_class.h"
#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/typedef/actor_buff_data_typedef.h"

#include "cocos2d.h"
#include "engine/base/basictypes.h"

namespace actor {
  class Actor;
  class ActorExtEnv;


  class DamagePackage;

  typedef ActorTemplateAttributeData<DamagePackage> DamageAttributeData;
  typedef ActorTemplateStatusData<DamagePackage> DamageStatusData;

  typedef ActorTemplateAttributeDataMap<DamagePackage, eActorDamageAttributeType> DamageAttributeMap;
  typedef ActorTemplateStatusDataMap<DamagePackage, eActorDamageStatusType> DamageStatusMap;


  //new damage process
  //actor -> skill -> buff -> [final damage result] -> buff -> actor -> health change(mostly) & damage label

  //Damage Value Calculation: actor_value = actor_value - damage_value
  // so positive damage value reduce health/energy
  // so negative damage value increase health/energy

  class DamagePackage {
  public:
    DamagePackage();
    ~DamagePackage();

  public:
    //basic method
    
    bool GetIsActive() { return is_active_; }
    void SetIsActive(bool is_active) { is_active_ = is_active; }

    ActorBuffStatusBitSet GetStatusBitSet() { return status_bit_set_; }
    void SetStatusBitSet(const ActorBuffStatusBitSet& status_bit_set) { status_bit_set_ = status_bit_set; }
    
    void InitDamage();
    void AddDamage(
      eActorDamageAttributeType   damage_type,
      float   damage_add = 0,
      float   damage_multiplier = 1,
      float   damage_extra = 0);
    float GetDamage(unsigned long damage_type_filter); //get result total damage

    bool CheckAttribute(eActorDamageAttributeType data_key) { return attribute_map_.Check(data_key); }
    //get data to connect event
    DamageAttributeData* GetAttributeData(eActorDamageAttributeType data_key) { return attribute_map_.GetData(data_key); }
    //normal access, with event
    void  InitAttribute(eActorDamageAttributeType data_key, float base = 0, float add = 0, float multiplier = 1, float extra = 0) 
    { 
      DamageAttributeData* data = attribute_map_.GetData(data_key);
      data->SetDefault(data_key, this);
      data->Init(base, add, multiplier, extra); 
    }
    void  SetAttribute(eActorDamageAttributeType data_key, float add = 0, float multiplier = 1, float extra = 0) { attribute_map_.Set(data_key, add, multiplier, extra); }
    void  AddAttribute(eActorDamageAttributeType data_key, float add = 0, float multiplier = 0, float extra = 0) { attribute_map_.Add(data_key, add, multiplier, extra); }
    float GetAttribute(eActorDamageAttributeType data_key) { return attribute_map_.Get(data_key); }


    bool CheckStatus(eActorDamageStatusType data_key) { return status_map_.Check(data_key); }
    //get data to connect event
    DamageStatusData* GetStatusData(eActorDamageStatusType data_key) { return status_map_.GetData(data_key); }
    //normal access, with event
    void  InitStatus(eActorDamageStatusType data_key, int status) 
    { 
      DamageStatusData* data = status_map_.GetData(data_key);
      data->SetDefault(data_key, this);
      data->Init(status); 
    }
    void  SetStatus(eActorDamageStatusType data_key, int status) { status_map_.Set(data_key, status); }
    int   GetStatus(eActorDamageStatusType data_key) { return status_map_.Get(data_key); }
    //normal access, with event
    void  InitStatusBool(eActorDamageStatusType data_key, bool bool_status) 
    {  
      DamageStatusData* data = status_map_.GetData(data_key);
      data->SetDefault(data_key, this);
      data->InitBool(bool_status); 
    }
    void  SetStatusBool(eActorDamageStatusType data_key, bool bool_status) { status_map_.SetBool(data_key, bool_status); }
    bool  GetStatusBool(eActorDamageStatusType data_key) { return status_map_.GetBool(data_key); }

  private:
    bool is_active_;

    ActorBuffStatusBitSet  status_bit_set_;

    DamageAttributeMap     attribute_map_;
    DamageStatusMap        status_map_;
  };












  // pass or hold the damage between actor (Actor Damage Pool)
  class ActorExtDamage  //ActorExternalDamage
  {
  public:
    ActorExtDamage(ActorExtEnv* actor_ext_env);
    ~ActorExtDamage();

    void Clear();

    void Update(float delta_time);

    //ACK of Damage
    void DamageDealt(
      DamagePackage* damage_package,
      int target_actor_id, 
      float damage_value, 
      float consumed_value, 
      eActorDamageAttributeType damage_attribute_type, 
      eActorAttributeType data_key);

    void AddDamagePackage(DamagePackage* damage_package, bool is_hold_till_next_update = true); //hold for later Apply(in Update)
    void ApplyDamagePackage(DamagePackage* damage_package); //Consume instantly

    
    DamagePackage* CalcSourceAddProcess(DamagePackage* damage_package);
    DamagePackage* CalcTargetSubProcess(DamagePackage* damage_package);
    
    DamagePackage* QuickInitDamage(int source_actor_id, int target_actor_id);
    DamagePackage* QuickInitSkillDamage(int source_actor_id, int target_actor_id, int skill_id);

  private:
    void calculateDamagePackage(DamagePackage* damage_package);

  private:
    std::list<DamagePackage*> damage_package_list_; //hold till next update

    ActorExtEnv* actor_ext_env_;
  };

} // namespace actor


#endif // ACTOR_EXT_DAMAGE_H