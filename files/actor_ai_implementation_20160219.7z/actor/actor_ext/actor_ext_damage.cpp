#include "actor_ext_damage.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"
#include "game/actor/actor_script_exporter.h"

#include "game/battle/view/battle_damage_label.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_config_data_table.h"

#include "engine/base/random_helper.h"

namespace actor {


  DamagePackage::DamagePackage()
  {
    InitDamage();
  }
  DamagePackage::~DamagePackage()
  {
    //
  }


  //basic method
  void DamagePackage::InitDamage()
  {
    attribute_map_.GetDataMap()->clear();
    status_map_.GetDataMap()->clear();

    InitStatus(kActorDamageStatusCountAddProcessActor, 0);
    InitStatus(kActorDamageStatusCountSubProcessActor, 0);

    InitStatus(kActorDamageStatusSourceActorId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceSkillId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceBuffId, ACTOR_INVALID_ID);
    InitStatus(kActorDamageStatusSourceEffectId, ACTOR_INVALID_ID);

    InitStatus(kActorDamageStatusTargetActorId, ACTOR_INVALID_ID);

    is_active_ = false;
  }

  void DamagePackage::AddDamage(
    eActorDamageAttributeType   damage_type,
    float   damage_add/* = 0*/,
    float   damage_multiplier/* = 1*/,
    float   damage_extra/* = 0*/
    )
  {
    if (damage_type == kActorDamageAttribute)
    {
      assert(false);
      return;
    }

    if (attribute_map_.Check(damage_type))
    {
      InitAttribute(damage_type);
    }

    attribute_map_.GetData(damage_type)->Add(damage_add, damage_multiplier, damage_extra);
  }

  float DamagePackage::GetDamage(unsigned long damage_type_filter)
  {
    if (!is_active_) 
    {
      assert(is_active_);
      return 0;
    }

    float result_damage = 0;

    for (std::map<eActorDamageAttributeType, DamageAttributeData>::iterator iterator = attribute_map_.GetDataMap()->begin(); iterator != attribute_map_.GetDataMap()->end(); iterator ++)
    {
      if (iterator->first & damage_type_filter)
        result_damage += iterator->second.Get();
    }

    return result_damage;
  }
  //DamagePackage






  //ActorExtDamage
  ActorExtDamage::ActorExtDamage(ActorExtEnv* actor_ext_env)
    :actor_ext_env_(actor_ext_env)
  {
    //
  }

  ActorExtDamage::~ActorExtDamage()
  {
    Clear();
  }

  void ActorExtDamage::Clear()
  {
    for (std::list<DamagePackage*>::iterator iterator = damage_package_list_.begin(); iterator != damage_package_list_.end(); iterator ++)
    {
      DamagePackage* damage_package = *iterator;
      
      delete damage_package;
    }
    damage_package_list_.clear();
  }


  void ActorExtDamage::Update(float delta_time)
  {
    std::list<DamagePackage*> process_damage_package_list;

    //take a snapshot copy
    process_damage_package_list.assign(damage_package_list_.begin(), damage_package_list_.end());
    damage_package_list_.clear();

    //calc damage
    for (std::list<DamagePackage*>::iterator iterator = process_damage_package_list.begin(); iterator != process_damage_package_list.end(); iterator ++)
    {
      DamagePackage* damage_package = *iterator;

      ApplyDamagePackage(damage_package);
    }
    process_damage_package_list.clear();
  }



  void ActorExtDamage::DamageDealt(
    DamagePackage* damage_package,
    int target_actor_id, 
    float damage_value, 
    float consumed_value, 
    eActorDamageAttributeType damage_attribute_type, 
    eActorAttributeType data_key)
  {
    //signal first
    ActorEventData event_data;
    event_data.data_type = kActorEventDataAttribute;
    event_data.data_value.attribute = consumed_value;
    actor_ext_env_->GetSignalHub()->Emit(kActorEventDamageDealt, target_actor_id, &event_data);


    //target actor
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);
    if (target_actor)
    {
      if (consumed_value != 0)
      {
        //per-damage-type label
        ShowDamageLabel(damage_package, target_actor_id, damage_value, damage_attribute_type);
        

        //add color shader
        if (consumed_value < 0)
        {
          target_actor->GetAnimation()->SetColorShader(cocos2d::ccc4f(0.0f, 0.5f, 0.0f, 0.5f), 0.5f);// add healing green effect 
        }
        else
        { 
          target_actor->GetAnimation()->SetColorShader(cocos2d::ccc4f(1.0f, 0.0f, 0.0f, 0.6f), 0.5f);// add hit red effect
        }
      }
    }


    //source actor
    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    if (source_actor && source_actor->GetIsActorAlive())
    {
      std::ostringstream string_stream;  // associate stream buffer to stream
      string_stream << "[DamageDealt] DV:" << damage_value << " CV:" << consumed_value << " To:" << target_actor_id;
      ((ActorScriptExporter*)source_actor->GetScriptExporter())->AddDebugText(string_stream.str());


      //test stiff
      ActorSkillLinkData skill_link_data;
      skill_link_data.actor_id = source_actor_id;
      skill_link_data.actor_level = source_actor->GetActorData()->GetActorStatus(kActorStatusLevel);
      target_actor->GetBuff()->AddBuff(ACTOR_INVALID_ID, ACTOR_DEFAULT_BUFF_ID_STIFF, skill_link_data);
      //target_actor->GetBuff()->AddBuff(ACTOR_INVALID_ID, ACTOR_DEFAULT_BUFF_ID_KNOCK_BACK_XL, skill_link_data);
      //test stiff


      if (target_actor && (source_actor != target_actor))
      {
        //check kill and add kill count
        if (target_actor->GetIsActorAlive() == false) 
        {
          source_actor->GetActorData()->GetLog()->AddErrorLogF("[Kill] killed actor: %d", target_actor_id);
          source_actor->GetActorData()->AddActorAttribute(kActorAttributeKillCount, 1);

          //send actor event
          ActorEventData event_data(target_actor);
          source_actor->GetActorExtEnv()->GetSignalHub()->Emit(kActorEventActorKill, source_actor_id, &event_data);
        }


        //counter attack logic
        if (target_actor->GetIsActorAlive() == true
          && target_actor->GetActorData()->GetActorStatusBool(kActorStatusControlIsCounterAttack)
          && target_actor->GetActorData()->GetControlData()->GetMaxPriority() < kActorControlPriorityCounterAttackAuto
          && source_actor->GetActorData()->GetActorStatus(kActorStatusFaction) != target_actor->GetActorData()->GetActorStatus(kActorStatusFaction))
        {
          cocos2d::CCPoint source_actor_position = source_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
          cocos2d::CCPoint target_actor_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

          float distance = source_actor_position.getDistance(target_actor_position);
          if (distance <= target_actor->GetAnimation()->GetActorBox().size.width * 1.5)
          {
            //move to position of actor only
            target_actor->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveAuto, target_actor_position);
          }
        }
      }
    }
  }





  void ActorExtDamage::AddDamagePackage(DamagePackage* damage_package, bool is_hold_till_next_update/* = true*/) //For later Send(in Update)
  {
    assert(damage_package);
    assert(damage_package->GetIsActive());

    damage_package = CalcSourceAddProcess(damage_package);

    if (is_hold_till_next_update)
      damage_package_list_.push_back(damage_package);
    else
      ApplyDamagePackage(damage_package);
  }


  void ActorExtDamage::ApplyDamagePackage(DamagePackage* damage_package) //Consume instantly
  {
    damage_package = CalcTargetSubProcess(damage_package);

    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    if (source_actor && source_actor->GetIsActorAlive())
    {
      damage_package = source_actor->GetActorData()->GetDamageData()->NotifyDamageResult(damage_package);
    }

    //currently no other use...
    if (damage_package) delete damage_package;
  }



  DamagePackage* ActorExtDamage::CalcSourceAddProcess(DamagePackage* damage_package)
  {
    int source_actor_id = damage_package->GetStatus(kActorDamageStatusSourceActorId);
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);

    if (source_actor && source_actor->GetIsActorAlive() && damage_package->GetIsActive())
    {
      damage_package = source_actor->GetActorData()->GetDamageData()->AddProcess(damage_package); //add up

      ActorEventData event_data(damage_package);
      source_actor->GetActorExtEnv()->GetSignalHub()->Emit(kActorEventDamageGenerate, source_actor_id, &event_data);
    }
    else
    {
      cocos2d::CCLog("[CalcSourceAddProcess] DamagePackage source actor invalid, source_actor_id: %d", source_actor_id);
      damage_package->SetIsActive(false);
    }

    return damage_package;
  }


  DamagePackage* ActorExtDamage::CalcTargetSubProcess(DamagePackage* damage_package)
  {
    int target_actor_id = damage_package->GetStatus(kActorDamageStatusTargetActorId);
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);

    if (target_actor && target_actor->GetIsActorAlive() && damage_package->GetIsActive())
    {
      ActorEventData event_data(damage_package);
      target_actor->GetActorExtEnv()->GetSignalHub()->Emit(kActorEventDamageReceive, target_actor_id, &event_data);

      damage_package = target_actor->GetActorData()->GetDamageData()->SubProcess(damage_package); //consume up
    }
    else
    {
      cocos2d::CCLog("[CalcTargetSubProcess] DamagePackage Target Missing! target_actor_id: %d", target_actor_id);
      damage_package->SetIsActive(false);
    }

    return damage_package;
  }




  DamagePackage* ActorExtDamage::QuickInitDamage(int source_actor_id, int target_actor_id)
  {
    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);
    Actor* target_actor = actor_ext_env_->GetActorById(target_actor_id);

    if (source_actor/* && source_actor->GetIsActorAlive()*/
      && target_actor/* && target_actor->GetIsActorAlive()*/)
    {
      DamagePackage* damage_package = new DamagePackage;

      //actor
      damage_package->InitStatus(kActorDamageStatusTargetActorId, target_actor_id);

      damage_package->InitStatus(kActorDamageStatusSourceActorId, source_actor_id);
      damage_package->InitStatus(kActorDamageStatusSourceActorLevel, source_actor->GetActorData()->GetActorStatus(kActorStatusLevel));

      damage_package->SetStatusBitSet(source_actor->GetActorData()->GetBuffData()->GetBuffStatusBitSet());

      //skill
      damage_package->InitStatus(kActorDamageStatusSourceSkillId, ACTOR_INVALID_ID);
      damage_package->InitStatus(kActorDamageStatusSourceSkillLevel, 0);
      damage_package->InitStatus(kActorDamageStatusSourceSkillType, kActorSkill);

      //damage value
      damage_package->InitAttribute(kActorDamageAttributeHealth, 0);
      damage_package->InitAttribute(kActorDamageAttributeEnergy, 0);

      return damage_package;
    }

    return NULL;
  }


  DamagePackage* ActorExtDamage::QuickInitSkillDamage(int source_actor_id, int target_actor_id, int skill_id)
  {
    DamagePackage* damage_package = QuickInitDamage(source_actor_id, target_actor_id);

    Actor* source_actor = actor_ext_env_->GetActorById(source_actor_id);

    if (damage_package
      && source_actor/* && source_actor->GetIsActorAlive()*/
      && skill_id != ACTOR_INVALID_ID)
    {
      
      //skill
      damage_package->InitStatus(kActorDamageStatusSourceSkillId, skill_id);

      ActorSkillInfo* skill_info = source_actor->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);
      damage_package->InitStatus(kActorDamageStatusSourceSkillLevel, skill_info ? skill_info->skill_level : 0);
      damage_package->InitStatus(kActorDamageStatusSourceSkillType, skill_info ? skill_info->skill_type : kActorSkillOverload);
      
      calculateDamagePackage(damage_package);

      return damage_package;
    }

    return NULL;
  }


  //NOTE: Below logic need to sync with Damage Formula
  //NOTE: Below logic need to sync with Damage Formula
  //NOTE: Below logic need to sync with Damage Formula
  //NOTE: Below logic need to sync with Damage Formula
  void ActorExtDamage::calculateDamagePackage( DamagePackage* damage_package )
  {
    Actor* source_actor = actor_ext_env_->GetActorById(damage_package->GetStatus(kActorDamageStatusSourceActorId));
    Actor* target_actor = actor_ext_env_->GetActorById(damage_package->GetStatus(kActorDamageStatusTargetActorId));

    ActorData* source_actor_data = source_actor->GetActorData();
    ActorData* target_actor_data = target_actor->GetActorData();

    
    ActorBuffStatusBitSet damage_status_bit_set = damage_package->GetStatusBitSet();
    ActorBuffStatusBitSet target_status_bit_set = target_actor_data->GetBuffData()->GetBuffStatusBitSet();

    bool is_element_positive = GetElementCorrectionPositive(damage_status_bit_set, target_status_bit_set) > 0;
    bool is_element_negative = GetElementCorrectionNegative(damage_status_bit_set, target_status_bit_set) < 0;

    float skill_damage_scale = 1.0f;
    std::map<actor::eActorAttributeType, float> skill_attribute_mod_data;
    ActorDamageCalcData damage_calc_data_base;

    ActorSkillInfo* skill_info = source_actor_data->GetSkillData()->GetSkillInfoById(damage_package->GetStatus(kActorDamageStatusSourceSkillId)); 
    if (skill_info)
    {
      skill_damage_scale = skill_info->skill_damage_scale;

      SkillConfigData* skill_config_data = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_info->skill_id);
      if (skill_config_data) 
      {
        skill_attribute_mod_data = skill_config_data->GetAttributeModData();
        damage_calc_data_base = skill_config_data->GetDamageCalcDataBase();
      }
    }


    //FORMULA formula_list.xlsx
    // SVN\trunk\design\2ϵͳ���\�����ĵ�\���Է���.xlsx

    //MISS DEFAULT
    bool IS_MISS= false;
    {
      //decide perfect miss
      float rate_perfect_dodge = target_actor_data->GetActorAttribute(kActorAttributeFactorDodgeExtra) * 0.001f;
      bool is_perfect_dodge = taomee::random_0_1() <= rate_perfect_dodge;
      
      //decide element hit
      float rate_element_hit = 0.80f; //temp 80%
      bool is_element_dodge = is_element_negative && (taomee::random_0_1() > rate_element_hit);
      
      //max(min((A_Hit-B_Dodge)/1000+1+A_skillCorrect,0.95),0.02) ??A_skillCorrect??
      float factor_hit = source_actor_data->GetActorAttribute(kActorAttributeFactorHit) + skill_attribute_mod_data[kActorAttributeFactorHit];
      float factor_dodge = target_actor_data->GetActorAttribute(kActorAttributeFactorDodge);
      float rate_hit = (factor_hit - factor_dodge) * 0.001f + 1/* + A_skillCorrect*/;
      rate_hit = CLAMP(rate_hit, 0.02, 0.95);
      bool is_dodge = taomee::random_0_1() > rate_hit;
      
      if (is_perfect_dodge || is_element_dodge || is_dodge) 
      {
        IS_MISS = true;
      }
    }
    damage_package->InitStatusBool(kActorDamageStatusIsMissed, IS_MISS);

    //CRITICAL DEFAULT
    bool IS_CRITICAL = false;
    float RATE_DAMAGE_CRITICAL = 0;
    {
      //min(max(A_Crit-B_CritResist+A_skillCorrect,1),0.02) ??A_skillCorrect??
      float rate_perfect_critical = (source_actor_data->GetActorAttribute(kActorAttributeFactorCriticalExtra) + skill_attribute_mod_data[kActorAttributeFactorCriticalExtra]) 
        * 0.001f;
      bool is_perfect_critical = taomee::random_0_1() <= rate_perfect_critical;

      float rate_critical = source_actor_data->GetActorAttribute(kActorAttributeFactorCritical) + skill_attribute_mod_data[kActorAttributeFactorCritical] 
        - target_actor_data->GetActorAttribute(kActorAttributeFactorCriticalResist);
      rate_critical = CLAMP(rate_critical, 0.02f, 1.0f);
      bool is_critical = taomee::random_0_1() <= rate_critical;

      if (is_perfect_critical || is_critical) 
      {
        IS_CRITICAL = true;
      }

      //(1+isCrit*(0.5+CritExtendDamageRate))*(1+0.5*isElementCrit)

      //calculate Critical extend rate
      //A_CritExtendDamage/1000
      float rate_critical_extend = (source_actor_data->GetActorAttribute(kActorAttributeAttackCritical) + skill_attribute_mod_data[kActorAttributeAttackCritical]) 
        * 0.001f;

      bool is_element_crit = is_element_positive ? taomee::random_0_1() <= 0.5 : false;

      //calculate damage value
      //(1+isCrit*(0.5+CritExtendDamageRate))*(1+0.5*isElementCrit)
      RATE_DAMAGE_CRITICAL = 1.0f 
        * (IS_CRITICAL ? (1.5f + rate_critical_extend) : 1) 
        * (is_element_crit ? 1.5f : 1)
        ;
    }
    damage_package->InitStatusBool(kActorDamageStatusIsCritical, IS_CRITICAL);


    //DAMAGE TYPE
    eActorDamageAttributeType DAMAGE_ATTRIBUTE_TYPE = kActorDamageAttribute;
    float SOURCE_DAMAGE = 0;
    float TARGET_DEFENSE = 0;
    {
      float source_attack_physical = source_actor_data->GetActorAttribute(kActorAttributeAttackPhysical) + skill_attribute_mod_data[kActorAttributeAttackPhysical];
      float source_attack_magical = source_actor_data->GetActorAttribute(kActorAttributeAttackMagical) + skill_attribute_mod_data[kActorAttributeAttackMagical];
      if (source_attack_physical != 0)
      {
        DAMAGE_ATTRIBUTE_TYPE = kActorDamageAttributePhysical;
        SOURCE_DAMAGE = source_attack_physical;
        TARGET_DEFENSE = target_actor_data->GetActorAttribute(kActorAttributeDefensePhysical);
      }
      else
      {
        DAMAGE_ATTRIBUTE_TYPE = kActorDamageAttributeMagical;
        SOURCE_DAMAGE = source_attack_magical;
        TARGET_DEFENSE = target_actor_data->GetActorAttribute(kActorAttributeDefenseMagical);
      }
    }


    //DAMAGE BASE
    float BASE_DAMAGE = 0;
    switch (damage_calc_data_base.calc_type)
    {
    case kActorDamageCalcTypeBaseDefault:
      {
        //min(max(1+(A_ArmorRend-B_Armor)/1000,0.8),1.5)
        float rate_damage_adjust = 1 + (
          source_actor_data->GetActorAttribute(kActorAttributeFactorDamageAdjustResist) + skill_attribute_mod_data[kActorAttributeFactorDamageAdjustResist] 
        - target_actor_data->GetActorAttribute(kActorAttributeFactorDamageAdjust)
          ) * 0.001f;
        rate_damage_adjust = CLAMP(rate_damage_adjust, 0.8, 1.5);

        bool is_pvp = (source_actor_data->GetActorStatus(kActorStatusFaction) != target_actor_data->GetActorStatus(kActorStatusFaction))
          && (source_actor_data->GetActorStatus(kActorStatusAppearance) == target_actor_data->GetActorStatus(kActorStatusAppearance));

        if (is_pvp)
        {
          //A_Attack*ArmorRendExtendRate*min(max((A_Attack/2+1000)/(B_Def+1000)*0.5,0.5),0.65)
          float rate_pvp_limit = (SOURCE_DAMAGE * 0.5f + 1000) / (TARGET_DEFENSE + 1000) * 0.5f;
          rate_pvp_limit = CLAMP(rate_pvp_limit, 0.5f, 0.65f);

          BASE_DAMAGE = SOURCE_DAMAGE * rate_damage_adjust * rate_pvp_limit;
        }
        else 
        {
          //A_Attack*ArmorRendExtendRate-B_Def
          BASE_DAMAGE = SOURCE_DAMAGE * rate_damage_adjust - TARGET_DEFENSE;
        }
      }
      break;
    case kActorDamageCalcTypeBaseTransferHealthCurrent:
      {
        float rate_transfer = *(damage_calc_data_base.argument_list.begin());
        BASE_DAMAGE = 1 + source_actor_data->GetActorAttribute(kActorAttributeHealthCurrent) * rate_transfer;
      }
      break;
    case kActorDamageCalcTypeBaseTransferHealthMax:
      {
        float rate_transfer = *(damage_calc_data_base.argument_list.begin());
        BASE_DAMAGE = 1 + source_actor_data->GetActorAttribute(kActorAttributeHealthMax) * rate_transfer;
      }
      break;
    default:
      {
        assert(false);
        return;
      }
      break;
    }




    //ELEMENT DAMAGE BASE
    float ELEMENT_BASE_DAMAGE;
    {
      ELEMENT_BASE_DAMAGE = SOURCE_DAMAGE * (is_element_positive ? 0.35f : 0);
    }


    //DAMAGE FINAL
    float DAMAGE_VALUE = 0;
    {
      //calculate skill damage extend rate
      //skill_damage_scale*(1+A_SkillDamageRate)/(1+B_SkillResist/3000*isPowerSkill)
      /*(1+A_SkillDamageRate) "1 was already added when reading character_data_table"*/
      float rate_skill_damage = skill_damage_scale 
        * (source_actor_data->GetActorAttribute(kActorAttributeFactorSkillDamage) + skill_attribute_mod_data[kActorAttributeFactorSkillDamage]) 
        / (1 + target_actor_data->GetActorAttribute(kActorAttributeFactorSkillDamageResist) / 3000.0f/* * isPowerSkill*/);

      //calculate damage extend rate
      //min(max(1+A_DamageExtendAd-B_DamageExtendReduce,0.5),2)
      float rate_damage_extend = 1 
        + source_actor_data->GetActorAttribute(kActorAttributeDamageAddition) + skill_attribute_mod_data[kActorAttributeDamageAddition]
        - target_actor_data->GetActorAttribute(kActorAttributeDamageReduction);
      rate_damage_extend = CLAMP(rate_damage_extend, 0.5, 2);

      //calculate damage value
      //BaseDamage*(1+isCrit*(0.5+CritExtendDamageRate))*(1+0.5*isElementCrit)*DamageExtendRate*AllSkillDamageRate
      //BaseDamage*rate_damage_critical*DamageExtendRate*AllSkillDamageRate
      DAMAGE_VALUE = MAX(BASE_DAMAGE, ELEMENT_BASE_DAMAGE) 
        * RATE_DAMAGE_CRITICAL
        * rate_damage_extend 
        * rate_skill_damage 
        ;
    }
    DAMAGE_VALUE = MAX(DAMAGE_VALUE, 1);

    
    damage_package->InitAttribute(DAMAGE_ATTRIBUTE_TYPE, DAMAGE_VALUE);
    damage_package->SetIsActive(true);
  }

} // namespace actor