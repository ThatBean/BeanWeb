#ifndef ACTOR_EXT_EFFECT_H
#define ACTOR_EXT_EFFECT_H

#include "game/actor/typedef/actor_effect_data_typedef.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext/actor_ext_effect.h"

namespace actor {
  class ActorExtEffect;
  class ActorTrigger;

  //provide data check and event check
  class ActorEffect : public Actor
  {
  public:
    ActorEffect(ActorExtEffect* actor_ext_effect);
    ~ActorEffect();

    void Clear();
    void Init(const ActorEffectLinkData& effect_link_data);
    void Update(const float delta_time);

    ActorEffectLinkData& GetEffectLinkData() { return effect_link_data_; }

  private:
    void OnTrigger(const std::list<int>* actor_id_list);
    void ApplyEffect(const int actor_id);

  private:
    ActorTrigger* trigger_;
    bool is_check_count_limit_;  //check trigger every update
    bool is_check_time_tick_;  //check trigger by time
    bool is_check_ignore_source_actor_;

    float trigger_tick_time_; //in seconds
    int trigger_count_limit_; //-1 = unlimited

    std::map<int, bool> trigger_actor_id_map_; //prevent multi trigger

    int attached_actor_id_;
    ActorEffectLinkData effect_link_data_;

    ActorExtEffect* actor_ext_effect_;
  };

} // namespace actor


#endif // ACTOR_EXT_EFFECT_H