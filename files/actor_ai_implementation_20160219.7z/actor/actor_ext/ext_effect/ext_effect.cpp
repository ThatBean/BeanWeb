#include "ext_effect.h"

#include "game/actor/actor.h"
#include "game/actor/animation/actor_animation_effect.h"
#include "game/actor/trigger/actor_trigger_predefined.h"
#include "game/actor/actor_ext/actor_ext_damage.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/effect_config_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

/*
  Actor Effect
    Effect is Animation + Movement + Trigger + Data, or what a Skill will create.
    All component is optional, thus a Animation only or Data only Effect can be created

    Life Span:
      Init: 
        need: effect_id 
        optional: source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update: 
        play animation, check trigger

      OnTrigger: 
        (may or may not), triggered, apply carried Data to one or more Actor, may result in a Buff

      Clear: 
        self removal, when hit, time out, or forced to stop(from skill maybe)
*/



namespace actor {

  //ActorEffect
  ActorEffect::ActorEffect(ActorExtEffect* actor_ext_effect)
    : actor_ext_effect_(actor_ext_effect)
    , trigger_(NULL)
    , is_check_count_limit_(false)
    , is_check_time_tick_(false)
    , is_check_ignore_source_actor_(false)
    , trigger_tick_time_(0.0f)
    , trigger_count_limit_(-1)
  {

  }

  ActorEffect::~ActorEffect()
  {
    Clear();
  }

  void ActorEffect::Clear()
  {
    if (trigger_)
    {
      delete trigger_;
      trigger_ = NULL;
    }

    effect_link_data_.Clear();

    is_check_count_limit_ = false;
    is_check_time_tick_ = false;
    is_check_ignore_source_actor_ = false;
    trigger_tick_time_ = 0.0f;
    trigger_count_limit_ = -1;
    trigger_actor_id_map_.clear();
  }

  void ActorEffect::Init(const ActorEffectLinkData& effect_link_data)
  { 
    EffectConfigData* effect_config_data = DataManager::GetInstance().GetEffectConfigDataTable()->GetEffectConfig(effect_link_data.effect_id);

    //check valid
    if (!effect_config_data)
    {
      CCLog("[ActorEffect][Init] missing effect config id: %d", effect_link_data.effect_id);
      assert(false);
      return;
    }
    //check valid

    Clear();

    //init data
    effect_link_data_ = effect_link_data;
    effect_link_data_.effect_config_data = effect_config_data;

    if (effect_link_data_.effect_config_data->GetTriggerTickTime() > 0)
    {
      is_check_time_tick_ = true;
      trigger_tick_time_ = effect_link_data_.effect_config_data->GetTriggerTickTime();
    }

    if (effect_link_data_.effect_config_data->GetTriggerCountLimit() > 0)
    {
      is_check_count_limit_ = true;
      trigger_count_limit_ = effect_link_data_.effect_config_data->GetTriggerCountLimit();
    }

    is_check_ignore_source_actor_ = effect_link_data_.effect_config_data->GetTriggerIsIgnoreSourceActor();
    

    //ActorEffectInit
    Actor::Init(kActorModelEffect);

    //copy necessary data from actor to effect_actor
    Actor* actor = actor_ext_effect_->GetActorExtEnv()->GetActorById(effect_link_data_.attached_actor_id);
    GetActorData()->InitActorAttribute(kActorAttributeHealthCurrent, actor->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent));
    GetActorData()->InitActorAttribute(kActorAttributeHealthMax, actor->GetActorData()->GetActorAttribute(kActorAttributeHealthMax));
    GetActorData()->InitActorAttribute(kActorAttributeEnergyCurrent, actor->GetActorData()->GetActorAttribute(kActorAttributeEnergyCurrent));
    GetActorData()->InitActorAttribute(kActorAttributeEnergyMax, actor->GetActorData()->GetActorAttribute(kActorAttributeEnergyMax));

    GetActorData()->InitActorStatus(kActorStatusFaction, actor->GetActorData()->GetActorStatus(kActorStatusFaction));
    GetActorData()->InitActorStatus(kActorStatusHomeDirection, actor->GetActorData()->GetActorStatus(kActorStatusHomeDirection));
    GetActorData()->InitActorStatus(kActorStatusActorId, actor->GetActorData()->GetActorStatus(kActorStatusActorId));
    GetActorData()->InitActorStatus(kActorStatusCardId, actor->GetActorData()->GetActorStatus(kActorStatusCardId));
    GetActorData()->InitActorStatus(kActorStatusLevel, actor->GetActorData()->GetActorStatus(kActorStatusLevel));
    GetActorData()->InitActorStatus(kActorStatusAppearance, actor->GetActorData()->GetActorStatus(kActorStatusAppearance));
    GetActorData()->InitActorStatus(kActorStatusCareer, actor->GetActorData()->GetActorStatus(kActorStatusCareer));

    GetActorData()->InitActorStatus(kActorStatusIsFactionReversed, actor->GetActorData()->GetActorStatus(kActorStatusIsFactionReversed));

    GetActorData()->InitActorStatusBool(kActorStatusIsSearchable, false);
    GetActorData()->InitActorStatusBool(kActorStatusIsAttackable, false);
    GetActorData()->InitActorStatusBool(kActorStatusIsDisableUserOperation, true);
    


    // TODO: sort direction logic
    //special
    GetActorData()->InitActorStatus(kActorStatusAnimationDirection, actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection));
    // TODO: sort direction logic
    // TODO: sort direction logic


    GetActorData()->InitActorStatus(kActorStatusEffectConfigId, effect_link_data_.effect_id);
    GetActorData()->InitActorAttribute(kActorAttributeTimeActive, 0);


    //animation
    GetAnimation()->Init(kActorAnimationModelEffect);

    //init trigger
    trigger_ = effect_link_data_.effect_config_data->GetEffectTrigger(this);

    //set active
    SetScriptObjectIsActive(true);
  }

  void ActorEffect::Update(float delta_time)
  { 
    //update position from animation to data
    GetActorData()->SetActorPosition(kActorPositionAnimation, GetAnimation()->GetActorNode()->getPosition());

    //update time
    GetActorData()->AddActorAttribute(kActorAttributeTimeActive, delta_time);

    //check active
    SetScriptObjectIsActive((!is_check_count_limit_ || trigger_count_limit_ > 0));

    //check trigger
    if (GetScriptObjectIsActive()
      && (!is_check_time_tick_ || trigger_tick_time_ <= GetActorData()->GetActorAttribute(kActorAttributeTimeActive)))
    {
      trigger_->Update();

      if (trigger_->GetIsTriggered())
      {
        OnTrigger(trigger_->GetTriggeredActorIdList());
      }

      if (is_check_time_tick_)
      {
        GetActorData()->GetActorAttributeData(kActorAttributeTimeActive)->Reset();
        trigger_actor_id_map_.clear();  //clear map
      }
    }

//     Actor::Update(delta_time);
  }

  void ActorEffect::OnTrigger(const std::list<int>* actor_id_list)
  { 
    //first check skill preset target exist
    for (std::list<int>::iterator iterator_target = effect_link_data_.skill_link_data.target_actor_id_list.begin(); iterator_target != effect_link_data_.skill_link_data.target_actor_id_list.end(); iterator_target ++)
    {
      int target_actor_id = *iterator_target;

      if (trigger_actor_id_map_.find(target_actor_id) == trigger_actor_id_map_.end())
      {
        for (std::list<int>::const_iterator iterator = actor_id_list->begin(); iterator != actor_id_list->end(); iterator ++)
        {
          if (target_actor_id == *iterator)
          {
            ApplyEffect(target_actor_id);
          }
        }
      }
    }


    //then pick actor from list by order
    for (std::list<int>::const_iterator iterator = actor_id_list->begin(); iterator != actor_id_list->end(); iterator ++)
    {
      int target_actor_id = *iterator;

      ApplyEffect(target_actor_id);
    }
  }



  void ActorEffect::ApplyEffect(const int actor_id)
  {
    if (
      (is_check_count_limit_ == false || trigger_count_limit_ > 0)
      && (is_check_ignore_source_actor_ == false || actor_id != effect_link_data_.attached_actor_id)
      && (trigger_actor_id_map_.find(actor_id) == trigger_actor_id_map_.end())
    )
    {
      //data
      trigger_actor_id_map_[actor_id] = true;
      if (trigger_count_limit_ > 0) trigger_count_limit_ --;

      //emit
      if (effect_link_data_.effect_config_data->GetEmitData().empty() == false)
      {
        ActorSkillLinkData skill_link_data = effect_link_data_.skill_link_data;

        //skill_link_data.actor_id = actor_id;//use target //GetScriptObjectId();

        actor_ext_effect_->GetActorExtEnv()->ApplyEmitDataList(
          effect_link_data_.effect_config_data->GetEmitData(), 
          actor_id, 
          skill_link_data);
      }

      //damage
      if (effect_link_data_.effect_config_data->GetTriggerGenerateDamage())
      {
        actor::ActorExtDamage* actor_ext_damage = this->GetActorExtEnv()->GetActorExtDamage();

        actor::DamagePackage* damage_package = actor_ext_damage->QuickInitSkillDamage(
          effect_link_data_.attached_actor_id, 
          actor_id, 
          effect_link_data_.skill_link_data.skill_id);

        actor_ext_damage->AddDamagePackage(damage_package, true);
      }
    }
  }
  
  //ActorEffect

} // namespace actor