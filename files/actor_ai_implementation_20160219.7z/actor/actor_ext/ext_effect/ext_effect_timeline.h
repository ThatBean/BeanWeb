#ifndef ACTOR_EXT_EFFECT_TIMELINE_H
#define ACTOR_EXT_EFFECT_TIMELINE_H

#include "game/actor/typedef/actor_effect_data_typedef.h"

#include "game/actor/actor_ext/actor_ext_effect.h"

#include "cocos2d.h"
#include "cocos-ext.h"

class EffectTimelineData;
class EffectTimelineItemData;

namespace taomee {
  class ProjectileAnimation;
}

namespace actor {

  class ActorEffectTimelineUpdateData {
  public:
    ActorEffectTimelineUpdateData()
      : effect_timeline_item_data(NULL)
      , animation_armature(NULL)
      , animation_projectile(NULL)
      , actor_effect(NULL)
      , effect_node(NULL)
      , movement_cycle_time(0.0f)
      , movement_cycle_radius(0.0f)
      , movement_homing_target_actor_id(ACTOR_INVALID_ID)
      , is_updatable(false)
      , is_deletable(false)
    {}

  public:
    EffectTimelineItemData* effect_timeline_item_data;

    cocos2d::extension::CCArmature* animation_armature; 
    taomee::ProjectileAnimation* animation_projectile; 
    ActorEffect* actor_effect; 

    cocos2d::CCNode* effect_node;
    cocos2d::CCPoint effect_position; //for init position or update

    cocos2d::CCPoint movement_position_data; //maybe vector, or position, differ for each movement
    float movement_cycle_time;
    float movement_cycle_radius;
    int movement_homing_target_actor_id;

    bool is_updatable;
    bool is_deletable;
  };


  //provide data check and event check
  class ActorEffectTimeline
  {
  public:
    ActorEffectTimeline(ActorExtEffect* actor_ext_effect);
    ~ActorEffectTimeline();

    void Clear();
    void Init(const int effect_timeline_key, const int effect_timeline_id, const int attached_actor_id, const ActorSkillLinkData& skill_link_data);
    bool Update(const float delta_time);  //return is_keep

    int GetEffectTimelineKey() { return effect_timeline_key_; }
    int GetEffectTimelineId() { return effect_timeline_id_; }

  private:
    void CreateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data);  //data init
    void UpdateItem(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time);  //movement update
    void DeleteItem(ActorEffectTimelineUpdateData& effect_timeline_update_data);  //data clean up

    void InitMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data);
    void UpdateMovement(ActorEffectTimelineUpdateData& effect_timeline_update_data, float delta_time);


  private:
    int effect_timeline_key_;
    int effect_timeline_id_;

    float time_;  //time passed

    std::list<ActorEffectTimelineUpdateData> item_update_data_list_;

    int attached_actor_id_;

    ActorSkillLinkData skill_link_data_;

    ActorExtEffect* actor_ext_effect_;
  };

} // namespace actor


#endif // ACTOR_EXT_EFFECT_TIMELINE_H