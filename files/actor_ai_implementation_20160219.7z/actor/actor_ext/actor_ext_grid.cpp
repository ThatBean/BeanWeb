#include "actor_ext_grid.h"

#include "game/actor/actor.h"
#include "game/actor/typedef/actor_grid_typedef.h"

namespace actor {
  

  namespace separate_2d {
    /* Separate2D
         /  |  \
        /   |   \
       /    |    \
    */
  
    enum eSeparate2DResultType
    {
      kSeparate2DResultLeft   = 1 << 0,
      kSeparate2DResultRight  = 1 << 1,
      kSeparate2DResultUp     = 1 << 2,
      kSeparate2DResultDown   = 1 << 3,
      kSeparate2DResultFailed = 0  //given point is on the line
      //kSeparate2DResult,
    };

    //Separate2D
    class Separate2D
    {
    public:
      Separate2D();
      Separate2D(const float& a, const float& b, const float& c);

      void FromPoints(const float& x1, const float& y1, const float& x2, const float& y2);
      void Set(const float& a, const float& b, const float& c);

      unsigned int Separate(const float& x, const float& y);

      bool IsLeft(const float& x, const float& y);
      bool IsRight(const float& x, const float& y);
      bool IsUp(const float& x, const float& y);
      bool IsDown(const float& x, const float& y);

      float GetY(const float& x);
      float GetX(const float& y);

    private:
      //0 = a * x + b * y + c
      float a_;
      float b_;
      float c_;

      //cached for speed
      //a != 0 | 0 = x + x_b * y + x_c
      float cache_x_b_;
      float cache_x_c_;

      //b != 0 | 0 = y_a * x + y + y_c
      float cache_y_a_;
      float cache_y_c_;
    };
  
    Separate2D::Separate2D() { Set(0, 0, 0); }  //all is kSeparate2DResultFailed
    Separate2D::Separate2D(const float& a, const float& b, const float& c) { Set(a, b, c); }

    void Separate2D::FromPoints(const float& x1, const float& y1, const float& x2, const float& y2)
    {
      float a = y2 - y1;
      float b = x1 - x2;
      float c = x2 * y1 - x1 * y2;

      Set(a, b, c);
    }

    void Separate2D::Set(const float& a, const float& b, const float& c)
    {
      a_ = a;
      b_ = b;
      c_ = c;

      cache_x_b_ = (a != 0) ? (b / a) : 0;
      cache_x_c_ = (a != 0) ? (c / a) : 0;

      cache_y_a_ = (b != 0) ? (a / b) : 0;
      cache_y_c_ = (b != 0) ? (c / b) : 0;
    }


    unsigned int Separate2D::Separate(const float& x, const float& y)
    {
      unsigned int result = kSeparate2DResultFailed;
    
      if (a_ != 0)
      {
        //can separate left and right
        float res = (x + cache_x_b_ * y + cache_x_c_);
        if (res < 0) result |= kSeparate2DResultLeft;
        if (res > 0) result |= kSeparate2DResultRight;
      }

      if (b_ != 0)
      {
        //can separate down and up
        float res = (cache_y_a_ * x + y + cache_y_c_);
        if (res < 0) result |= kSeparate2DResultDown;
        if (res > 0) result |= kSeparate2DResultUp;
      }

      return result;
    }


    bool Separate2D::IsLeft(const float& x, const float& y)
    {
      //assert(a_ != 0);  //no left and right
      return (Separate(x, y) & kSeparate2DResultLeft) != 0;
    }

    bool Separate2D::IsRight(const float& x, const float& y)
    {
      //assert(a_ != 0);  //no left and right
      return (Separate(x, y) & kSeparate2DResultRight) != 0;
    }

    bool Separate2D::IsUp(const float& x, const float& y)
    {
      //assert(b_ != 0);  //no down and up
      return (Separate(x, y) & kSeparate2DResultUp) != 0;
    }

    bool Separate2D::IsDown(const float& x, const float& y)
    {
      //assert(b_ != 0);  //no down and up
      return (Separate(x, y) & kSeparate2DResultDown) != 0;
    }

    float Separate2D::GetY(const float& x)
    {
      assert(b_ != 0);
      return - (a_ * x + c_) / b_;
    }

    float Separate2D::GetX(const float& y)
    {
      assert(a_ != 0);
      return - (b_ * y + c_) / a_;
    }
    //Separate2D
  } // namespace separate_2d





  namespace actor_grid_const {
    //compiler calculated grid value
    const float grid_box_average_width_top = (METRIC_GRID_TOP_RIGHT_X - METRIC_GRID_TOP_LEFT_X) / GRID_X_RANGE;
    const float grid_box_average_width_bottom = (METRIC_GRID_BOTTOM_RIGHT_X - METRIC_GRID_BOTTOM_LEFT_X) / GRID_X_RANGE;
    const float grid_box_average_height_left = (METRIC_GRID_TOP_LEFT_Y - METRIC_GRID_BOTTOM_LEFT_Y) / GRID_Y_RANGE;
    const float grid_box_average_height_right = (METRIC_GRID_TOP_RIGHT_Y - METRIC_GRID_BOTTOM_RIGHT_Y) / GRID_Y_RANGE;

    const float grid_box_average_width = (grid_box_average_width_top + grid_box_average_width_bottom) * 0.5f;
    const float grid_box_average_height = (grid_box_average_height_left + grid_box_average_height_right) * 0.5f;

    const float grid_center_position_x = (METRIC_GRID_TOP_RIGHT_X + METRIC_GRID_TOP_LEFT_X + METRIC_GRID_BOTTOM_RIGHT_X + METRIC_GRID_BOTTOM_LEFT_X) * 0.25f;
    const float grid_center_position_y = (METRIC_GRID_TOP_LEFT_Y + METRIC_GRID_BOTTOM_LEFT_Y + METRIC_GRID_TOP_RIGHT_Y + METRIC_GRID_BOTTOM_RIGHT_Y) * 0.25f;

    const int grid_row_size = GRID_X_RANGE + 2 * GRID_X_EXTEND; // grid x range is [1 - GRID_X_EXTEND, GRID_X_RANGE + GRID_X_EXTEND]
    const int grid_col_size = GRID_Y_RANGE + 2 * GRID_Y_EXTEND; 

    const int grid_row_min = 1 - GRID_X_EXTEND; 
    const int grid_row_max = GRID_X_RANGE + GRID_X_EXTEND; 
    const int grid_col_min = 1 - GRID_Y_EXTEND; 
    const int grid_col_max = GRID_Y_RANGE + GRID_Y_EXTEND; 

    const int grid_valid_row_min = 1; 
    const int grid_valid_row_max = GRID_X_RANGE; 
    const int grid_valid_col_min = 1; 
    const int grid_valid_col_max = GRID_Y_RANGE; 


    //dynamic calculated grid value
    static float grid_row_joint_top_list[grid_row_size + 1]; // index is re-mapped from [min, max + 1] to [0, size]
    static float grid_row_joint_bottom_list[grid_row_size + 1];
    static float grid_col_joint_left_list[grid_col_size + 1];
    static float grid_col_joint_right_list[grid_col_size + 1];

    static separate_2d::Separate2D grid_row_separate_line[grid_row_size + 1];
    static separate_2d::Separate2D grid_col_separate_line[grid_col_size + 1];

    static cocos2d::CCPoint grid_box_center_list[grid_col_size][grid_row_size]; // index is re-mapped from [min, max] to [0, size - 1]

    float interpolate(const float& a, const float& b, const float& gradient)
    {
      assert(gradient >= 0.0f && gradient <= 1.0f);
      return a + (b - a) * gradient;
    }


    class CalculateGridBox
    {
    public:
      CalculateGridBox()
      {
        int i, j;

        // joint
        for (i = 0; i <= grid_row_size; i++) { //i: row separate line
          grid_row_joint_top_list[i] = METRIC_GRID_TOP_LEFT_X + (i - GRID_X_EXTEND) * grid_box_average_width_top;
          grid_row_joint_bottom_list[i] = METRIC_GRID_BOTTOM_LEFT_X + (i - GRID_X_EXTEND) * grid_box_average_width_bottom;
        }

        for (j = 0; j <= grid_col_size; j++) { //j: col separate line
          grid_col_joint_left_list[j] = METRIC_GRID_BOTTOM_LEFT_Y + (j - GRID_Y_EXTEND) * grid_box_average_height_left;
          grid_col_joint_right_list[j] = METRIC_GRID_BOTTOM_RIGHT_Y + (j - GRID_Y_EXTEND) * grid_box_average_height_right;
        }

        // line
        for (i = 0; i <= grid_row_size; i++) { //i: row separate line
          grid_row_separate_line[i].FromPoints(
            grid_row_joint_bottom_list[i], 
            interpolate(grid_col_joint_left_list[0], grid_col_joint_right_list[0], float(i) / grid_row_size), 
            grid_row_joint_top_list[i], 
            interpolate(grid_col_joint_left_list[grid_col_size], grid_col_joint_right_list[grid_col_size], float(i) / grid_row_size));
        }

        for (j = 0; j <= grid_col_size; j++) { //j: col separate line
          grid_col_separate_line[j].FromPoints(
            interpolate(grid_row_joint_bottom_list[0], grid_row_joint_top_list[0], float(j) / grid_col_size), 
            grid_col_joint_left_list[j],
            interpolate(grid_row_joint_bottom_list[grid_col_size], grid_row_joint_top_list[grid_col_size], float(j) / grid_col_size), 
            grid_col_joint_right_list[j]);
        }

        // box
        cocos2d::CCPoint grid_box_joint_list[grid_col_size + 1][grid_row_size + 1]; //used here only

        for (i = 0; i <= grid_row_size; i++) {
          for (j = 0; j <= grid_col_size; j++) { //i: row joint | j: col joint
            grid_box_joint_list[j][i].setPoint(
              interpolate(grid_row_joint_bottom_list[i], grid_row_joint_top_list[i], float(j) / grid_col_size),
              interpolate(grid_col_joint_left_list[j], grid_col_joint_right_list[j], float(i) / grid_row_size));
          }
        }

        for (i = 0; i < grid_row_size; i++) {
          for (j = 0; j < grid_col_size; j++) { //i: row | j: col
            cocos2d::CCPoint center_position_4 = ccpAdd(
              ccpAdd(grid_box_joint_list[j][i], grid_box_joint_list[j][i + 1]), 
              ccpAdd(grid_box_joint_list[j + 1][i], grid_box_joint_list[j + 1][i + 1]));

            grid_box_center_list[j][i].setPoint(center_position_4.x * 0.25f, center_position_4.y * 0.25f);
          }
        }
      }
    };

    static CalculateGridBox calculate_grid_box; //for a one time init
  } // namespace actor_grid_const



  
  cocos2d::CCPoint GetPositionFromGrid(const cocos2d::CCPoint& grid_position) 
  { 
    return GetPositionFromGrid(grid_position.x, grid_position.y); 
  }
  cocos2d::CCPoint GetPositionFromGrid(const int& grid_x, const int& grid_y)
  {
    if (grid_x >= actor_grid_const::grid_row_min && grid_x <= actor_grid_const::grid_row_max 
      && grid_y >= actor_grid_const::grid_col_min && grid_y <= actor_grid_const::grid_col_max)
    {
      return actor_grid_const::grid_box_center_list[grid_y - actor_grid_const::grid_col_min][grid_x - actor_grid_const::grid_row_min];
    }
    else
    {
      assert(grid_x >= actor_grid_const::grid_row_min && grid_x <= actor_grid_const::grid_row_max 
        && grid_y >= actor_grid_const::grid_col_min && grid_y <= actor_grid_const::grid_col_max);
      return cocos2d::CCPointZero;
    }
  }

  float GetPositionXFromGridX(const int& grid_x)
  {
    if (grid_x >= actor_grid_const::grid_row_min && grid_x <= actor_grid_const::grid_row_max)
      return actor_grid_const::grid_box_center_list[int(GRID_X_RANGE_MIDDLE + 0.5) - actor_grid_const::grid_col_min][grid_x - actor_grid_const::grid_row_min].x; //use middle
    else
    {
      assert(grid_x >= actor_grid_const::grid_row_min && grid_x <= actor_grid_const::grid_row_max);
      return -1;
    }
  }
  float GetPositionYFromGridY(const int& grid_y)
  {
    if (grid_y >= actor_grid_const::grid_col_min && grid_y <= actor_grid_const::grid_col_max)
      return actor_grid_const::grid_box_center_list[grid_y - actor_grid_const::grid_col_min][int(GRID_Y_RANGE_MIDDLE + 0.5) - actor_grid_const::grid_row_min].y; //use middle
    else
    {
      assert(grid_y >= actor_grid_const::grid_col_min && grid_y <= actor_grid_const::grid_col_max);
      return -1;
    }
  }

  cocos2d::CCPoint GetGridFromPosition(const cocos2d::CCPoint& position)
  {
    return GetGridFromPosition(position.x, position.y);
  }
  cocos2d::CCPoint GetGridFromPosition(const float& position_x, const float& position_y)
  {
    int i, j, grid_row = actor_grid_const::grid_row_min - 1, grid_col = actor_grid_const::grid_col_min - 1;
    for (i = 0; i <= actor_grid_const::grid_row_size; i++) { //i: row separate line
      if (actor_grid_const::grid_row_separate_line[i].IsLeft(position_x, position_y)) break;
      grid_row++;
    }
    for (j = 0; j <= actor_grid_const::grid_col_size; j++) { //j: col separate line
      if (actor_grid_const::grid_col_separate_line[j].IsDown(position_x, position_y)) break;
      grid_col++;
    }
    return ccp(grid_row, grid_col);
  }

  int GetGridXFromPositionX(const float& position_x)
  {
    int i, grid_row = actor_grid_const::grid_row_min - 1;
    for (i = 0; i <= actor_grid_const::grid_row_size; i++) { //i: row separate line
      if (actor_grid_const::grid_row_separate_line[i].IsLeft(position_x, actor_grid_const::grid_center_position_y)) break; //use middle
      grid_row++;
    }
    return grid_row;
  }
  int GetGridYFromPositionY(const float& position_y)
  {
    int j, grid_col = actor_grid_const::grid_col_min - 1;
    for (j = 0; j <= actor_grid_const::grid_col_size; j++) { //j: col separate line
      if (actor_grid_const::grid_col_separate_line[j].IsDown(actor_grid_const::grid_center_position_x, position_y)) break; //use middle
      grid_col++;
    }
    return grid_col;
  }

  float GetGridBoxAverageWidth()
  {
    return actor_grid_const::grid_box_average_width;
  }
  float GetGridBoxAverageHeight()
  {
    return actor_grid_const::grid_box_average_height;
  }


  bool IsPositionInGrid(const cocos2d::CCPoint& position)
  {
    return (actor_grid_const::grid_row_separate_line[actor_grid_const::grid_valid_row_min - actor_grid_const::grid_row_min].IsRight(position.x, position.y) 
      && actor_grid_const::grid_row_separate_line[actor_grid_const::grid_valid_row_max - actor_grid_const::grid_row_min + 1].IsLeft(position.x, position.y)
      && actor_grid_const::grid_col_separate_line[actor_grid_const::grid_valid_col_min - actor_grid_const::grid_col_min].IsUp(position.x, position.y) 
      && actor_grid_const::grid_col_separate_line[actor_grid_const::grid_valid_col_max - actor_grid_const::grid_col_min + 1].IsDown(position.x, position.y));
  }

  bool IsPositionXInGrid(const cocos2d::CCPoint& position)
  {
    return (actor_grid_const::grid_row_separate_line[actor_grid_const::grid_valid_row_min - actor_grid_const::grid_row_min].IsRight(position.x, position.y) 
      && actor_grid_const::grid_row_separate_line[actor_grid_const::grid_valid_row_max - actor_grid_const::grid_row_min + 1].IsLeft(position.x, position.y));
  }

  bool IsPositionYInGrid(const cocos2d::CCPoint& position)
  {
    return (actor_grid_const::grid_col_separate_line[actor_grid_const::grid_valid_col_min - actor_grid_const::grid_col_min].IsUp(position.x, position.y) 
      && actor_grid_const::grid_col_separate_line[actor_grid_const::grid_valid_col_max - actor_grid_const::grid_col_min + 1].IsDown(position.x, position.y));
  }

  cocos2d::CCPoint SnapToGrid(const cocos2d::CCPoint& position)
  {
    cocos2d::CCPoint grid = GetGridFromPosition(position.x, position.y);

    return GetPositionFromGrid(
      CLAMP(grid.x, actor_grid_const::grid_row_min, actor_grid_const::grid_row_max),
      CLAMP(grid.y, actor_grid_const::grid_col_min, actor_grid_const::grid_col_max)); //always in grid
  }

  cocos2d::CCPoint SnapXToGrid(const cocos2d::CCPoint& position)
  {
    int grid_x = GetGridXFromPositionX(position.x);
    float position_x = GetPositionXFromGridX(CLAMP(grid_x, actor_grid_const::grid_row_min, actor_grid_const::grid_row_max)); //always in grid
    return cocos2d::CCPoint(position_x, position.y);
  }

  cocos2d::CCPoint SnapYToGrid(const cocos2d::CCPoint& position)
  {
    int grid_y = GetGridYFromPositionY(position.y);
    float position_y = GetPositionYFromGridY(CLAMP(grid_y, actor_grid_const::grid_col_min, actor_grid_const::grid_col_max)); //always in grid
    return cocos2d::CCPoint(position.x, position_y);
  }








  ActorExtGrid::ActorExtGrid(ActorExtEnv* actor_ext_env)
    :actor_ext_env_(actor_ext_env)
  {
    Clear();
  }

  ActorExtGrid::~ActorExtGrid()
  {
    Clear();
  }

  void ActorExtGrid::Clear()
  {
    actor_grid_list_.clear();
  }


  //position/animation related
  Actor* ActorExtGrid::GetActorAtGrid(const cocos2d::CCPoint& target_grid_position)
  {
    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor)
      {
        cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
        if (IsPositionInGrid(actor_position))
        {
          cocos2d::CCPoint actor_grid_position = GetGridFromPosition(actor_position);
          if (actor_grid_position.equals(target_grid_position))
            return actor;
        }
      }

      ++iterator;
    }

    return NULL;
  }

  Actor* ActorExtGrid::GetActorAtPosition(const cocos2d::CCPoint& target_position)
  {
    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor
        && actor->GetAnimation()->GetActorBox().containsPoint(target_position))
        return actor;

      ++iterator;
    }

    return NULL;
  }


  std::list<Actor*>*    ActorExtGrid::GetActorListAtGrid(const cocos2d::CCPoint&target_grid_position)
  {
    std::list<Actor*>* result_actor_list = new std::list<Actor*>;

    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor)
      {
        cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
        if (IsPositionInGrid(actor_position))
        {
          cocos2d::CCPoint actor_grid_position = GetGridFromPosition(actor_position);
          if (actor_grid_position.equals(target_grid_position))
            result_actor_list->push_back(actor);
        }
      }

      ++iterator;
    }

    return result_actor_list;
  }

  std::list<Actor*>*    ActorExtGrid::GetActorListAtPosition(const cocos2d::CCPoint& target_position)
  {
    std::list<Actor*>* result_actor_list = new std::list<Actor*>;

    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor
        && actor->GetAnimation() && actor->GetAnimation()->GetActorBox().containsPoint(target_position)) 
      {
        result_actor_list->push_back(actor);
      }

      ++iterator;
    }

    return result_actor_list;
  }


  static cocos2d::CCPoint compare_position;
  bool compare_by_distance(Actor* first, Actor* second)
  {
    float distance_first = first->GetActorData()->GetActorPosition(kActorPositionAnimation).getDistanceSq(compare_position);
    float distance_second = second->GetActorData()->GetActorPosition(kActorPositionAnimation).getDistanceSq(compare_position);
    return ( distance_first < distance_second );
  }


  std::list<Actor*>* ActorExtGrid::GetActorListByDistance(const cocos2d::CCPoint& center_position)
  {
    std::list<Actor*>* result_actor_list = actor_ext_env_->GetActorList();

    compare_position = center_position;
    
    result_actor_list->sort(compare_by_distance);

    return result_actor_list;
  }


  Actor* ActorExtGrid::QuickGetActorByFactionAndPosition(int target_faction, const cocos2d::CCPoint& center_position, int index_in_near_first_list)
  {
    Actor* result_actor = NULL;

    std::list<Actor*>* actor_list = GetActorListByDistance(center_position);


    std::list<Actor*>::iterator actor_iterator = actor_list->begin();
    while (actor_iterator != actor_list->end())
    {
      Actor * target_actor = *actor_iterator;

      if (target_actor->GetActorData()->GetActorStatus(kActorStatusFaction) == target_faction)
        actor_iterator ++;
      else
        actor_iterator = actor_list->erase(actor_iterator);
    }


    if (!actor_list->empty())
    {
      index_in_near_first_list = index_in_near_first_list % actor_list->size();

      actor_iterator = actor_list->begin();
      while (index_in_near_first_list > 1)
      {
        index_in_near_first_list --;
        actor_iterator ++;
      }

      result_actor = (*actor_iterator);
    }

    
    delete actor_list;

    return result_actor;
  }
  //position/animation related



  //position decision

  std::list<cocos2d::CCPoint>* ActorExtGrid::GetValidGridList(Actor* actor)  //need delete after use
  {
    //record grid taken status
    int grid_position_taken[GRID_X_RANGE][GRID_Y_RANGE] = {0};
    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list_.begin();
    while (iterator != actor_grid_list_.end())
    {
      Actor* ref_actor = iterator->first;

      if (ref_actor != actor && ref_actor->GetActorData()->GetActorStatus(kActorStatusHomeDirection) == actor->GetActorData()->GetActorStatus(kActorStatusHomeDirection))
      {
        cocos2d::CCPoint ref_grid_position = iterator->second;
        grid_position_taken[(int)(ref_grid_position.x - 1)][(int)(ref_grid_position.y - 1)] += 1;
      }

      ++iterator;
    }

    //search and check valid grid
    std::list<cocos2d::CCPoint>* valid_grid_list = new std::list<cocos2d::CCPoint>;
    int i, j;
    for (i = GRID_X_RANGE_LEFT; i <= GRID_X_RANGE_RIGHT; i++) {
      for (j = GRID_Y_RANGE_BOTTOM; j <= GRID_Y_RANGE_TOP; j++) {
        cocos2d::CCPoint grid_position = ccp(i, j);
        if (grid_position_taken[i - 1][j - 1] == 0 
          && actor->GetActorData()->GetSpecifiedData()->IsGridIdleValid(grid_position)) 
        {
          valid_grid_list->push_back(grid_position);
        }
      }
    }

    return valid_grid_list;
  }

  cocos2d::CCPoint ActorExtGrid::GetValidGrid(Actor* actor, const cocos2d::CCPoint& preferred_grid_position)
  {
    std::list<cocos2d::CCPoint>* valid_grid_list = GetValidGridList(actor);

    bool is_backup_grid_position_valid = false;
    cocos2d::CCPoint backup_grid_position;
    float nearest_valid_grid_distance = 99999;

    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;

        if (actor->GetActorData()->GetSpecifiedData()->IsGridIdleValid(grid_position))
        {
          is_backup_grid_position_valid = true;
          float distance = preferred_grid_position.getDistance(grid_position);

          if (distance < nearest_valid_grid_distance)
          {
            nearest_valid_grid_distance = distance;
            backup_grid_position = grid_position;
            if (distance == 0) break;  //find nearest, stop searching
          }
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    if (is_backup_grid_position_valid)
    {
      actor_grid_list_.push_back(std::pair<Actor*, cocos2d::CCPoint>(actor, backup_grid_position));  //prevent another actor move to 
      return backup_grid_position;
    }
    else
    {
      if (actor->GetActorData()->GetSpecifiedData()->IsGridIdleValid(preferred_grid_position) == false)
      {
        float preferred_grid_x = actor->GetActorData()->GetActorStatus(kActorStatusHomeDirection) == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT_MIDDLE : GRID_X_RANGE_RIGHT_MIDDLE;
        //so sad the lame makeshift position
        return ccp(preferred_grid_x, GRID_Y_RANGE_MIDDLE);
      }
      else
      {
        return preferred_grid_position;
      }
    }
  }

  cocos2d::CCPoint ActorExtGrid::GetValidGrid(Actor* actor)
  {
    return GetValidGrid(actor, GetGridFromPosition(actor->GetActorData()->GetActorPosition(kActorPositionAnimation))
      //actor_->GetActorData()->GetActorPosition(kActorPositionSpecifiedLastIdleGrid)
      );
  }
  //position decision




  //for actor grid need, update every Update()
  void ActorExtGrid::UpdateActorGridList()
  {
    actor_grid_list_.clear();

    std::map<int, Actor*>::iterator iterator = actor_ext_env_->GetActorMap()->begin();
    while (iterator != actor_ext_env_->GetActorMap()->end())
    {
      int actor_id = iterator->first;
      Actor* actor = iterator->second;

      if (actor->GetActorModelType() == kActorModelActor && actor->GetIsActorAlive())
      {
        cocos2d::CCPoint actor_position;
        if (actor->GetActorData()->GetControlData()->CheckOperationData(kActorControlOperationPositionMove))
        {  
          cocos2d::CCPoint actor_position = actor->GetActorData()->GetControlData()->GetPositionOperationData(kActorControlOperationPositionMove);
          if (IsPositionInGrid(actor_position))
            actor_grid_list_.push_back(std::pair<Actor*, cocos2d::CCPoint>(actor, GetGridFromPosition(actor_position)));
        }

        if (actor->GetActorData()->GetActorStatus(kActorStatusMotionIsBusy) == false)
        {
          cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
          if (IsPositionInGrid(actor_position))
            actor_grid_list_.push_back(std::pair<Actor*, cocos2d::CCPoint>(actor, GetGridFromPosition(actor_position)));
        }
      }

      ++iterator;
    }

    return;
  }

  bool ActorExtGrid::CheckActorGridOverlap(Actor* actor)
  {
    cocos2d::CCPoint actor_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

    if (IsPositionInGrid(actor_position) == false) return false;
    else return CheckActorGridOverlap(actor, GetGridFromPosition(actor_position));
  }

  bool ActorExtGrid::CheckActorGridOverlap(Actor* actor, const cocos2d::CCPoint& grid_position)
  {
    int actor_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction);

    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list_.begin();
    while (iterator != actor_grid_list_.end())
    {
      Actor* ref_actor = iterator->first;
      cocos2d::CCPoint ref_actor_grid_position = iterator->second;

      if (actor != ref_actor 
        && grid_position.equals(ref_actor_grid_position) 
        && actor_faction == ref_actor->GetActorData()->GetActorStatus(kActorStatusFaction))
        return true;

      ++iterator;
    }

    return false;
  }


} // namespace actor