#include "actor_buff_mod.h"
#include "actor_buff.h"

#include "game/actor/buff/buff_mod/actor_buff_mod_number.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_bool.h"

#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_actor.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_status.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_damage.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_emit.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_logic.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_buff.h"
#include "game/actor/buff/buff_mod/actor_buff_mod_buff_mod_script.h"

#include "game/actor/actor.h"
#include "game/actor/actor_ext/actor_ext_damage.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_data_tunnel.h"
#include "engine/base/utils_string.h"

/*
  Actor Buff Mod
    Buff is Data with Update or Event on an Actor, or what a Effect will create.
    Buff will always be added to an Actor
    Buff will interact with other existing Buff, and has replacement rules and stack rules

    Life Span:
      Init: 
        need: buff_id
        optional: source_effect_link(id + ...), source_skill_link(id + level + ...), source_actor_link(id + data + dead event + ...)

      Update / OnEvent: 
        (may or may not), mod something

      Clear: 
        self removal, when time out, Buff replacement, or actor dead
*/


namespace actor {


  static int DEBUG_ACTOR_BUFF_MOD_TYPED_DATA_COUNT = 0;
  static int DEBUG_ACTOR_BUFF_MOD_DATA_COUNT = 0;

  //ActorBuffModTypedData
  ActorBuffModTypedData::ActorBuffModTypedData()
  {
    DEBUG_ACTOR_BUFF_MOD_TYPED_DATA_COUNT ++;

    Clear();
  }
  ActorBuffModTypedData::~ActorBuffModTypedData()
  {
    DEBUG_ACTOR_BUFF_MOD_TYPED_DATA_COUNT --;
  }


  ActorBuffModTypedData::ActorBuffModTypedData(const ActorBuffModTypedData& typed_data)
  {
    DEBUG_ACTOR_BUFF_MOD_TYPED_DATA_COUNT ++;

    data_type_ = typed_data.data_type_;

    data_number_ = typed_data.data_number_;
    data_bool_ = typed_data.data_bool_;
    data_string_ = typed_data.data_string_;
    data_buff_mod_data_ = typed_data.data_buff_mod_data_; //ActorBuffModTypedData won't create/delete ActorBuffModData
  }

  void ActorBuffModTypedData::Clear()
  {
    data_type_ = kActorBuffModData;

    data_buff_mod_data_ = NULL; //ActorBuffModTypedData won't create/delete ActorBuffModData
    data_number_ = 0.0f;
    data_bool_ = false;
    data_string_.clear();
  }

  void ActorBuffModTypedData::SetBuffMod(eActorBuffModDataType data_type, ActorBuffModData* value)
  {
    switch (data_type)
    {
    case kActorBuffModDataBuffModNumber:
    case kActorBuffModDataBuffModBool:
    case kActorBuffModDataBuffModString:
    case kActorBuffModDataBuffMod:
      Clear();
      data_type_ = data_type;
      data_buff_mod_data_ = value; //ActorBuffModTypedData won't create/delete ActorBuffModData
      break;
    default:
      assert(
        data_type == kActorBuffModDataBuffModNumber
        || data_type == kActorBuffModDataBuffModBool
        || data_type == kActorBuffModDataBuffModString
        || data_type == kActorBuffModDataBuffMod
        );
      break;
    }
  }
  void ActorBuffModTypedData::SetNumber(eActorBuffModDataType data_type, float value)
  {
    switch (data_type)
    {
    case kActorBuffModDataNumber:
      Clear();
      data_type_ = data_type;
      data_number_ = value;
      break;
    default:
      assert(data_type == kActorBuffModDataNumber);
      break;
    }
  }
  void ActorBuffModTypedData::SetBool(eActorBuffModDataType data_type, bool value)
  {
    switch (data_type)
    {
    case kActorBuffModDataBool:
      Clear();
      data_type_ = data_type;
      data_bool_ = value;
      break;
    default:
      assert(data_type == kActorBuffModDataBool);
      break;
    }
  }
  void ActorBuffModTypedData::SetString(eActorBuffModDataType data_type, std::string& value)
  {
    switch (data_type)
    {
    case kActorBuffModDataString:
      Clear();
      data_type_ = data_type;
      data_string_ = value;
      break;
    default:
      assert(data_type == kActorBuffModDataString);
      break;
    }
  }

  ActorBuffModData* ActorBuffModTypedData::GetBuffMod(eActorBuffModDataType data_type/* = kActorBuffModDataBuffMod*/) const
  {
    switch (data_type)
    {
    case kActorBuffModDataBuffModNumber:
    case kActorBuffModDataBuffModBool:
    case kActorBuffModDataBuffModString:
    case kActorBuffModDataBuffMod:
      assert(data_type_ == data_type);
      return data_buff_mod_data_;
    default:
      assert(
        data_type == kActorBuffModDataBuffModNumber
        || data_type == kActorBuffModDataBuffModBool
        || data_type == kActorBuffModDataBuffModString
        || data_type == kActorBuffModDataBuffMod
        );
      return NULL;
    }
  }
  float ActorBuffModTypedData::GetNumber(eActorBuffModDataType data_type/* = kActorBuffModDataNumber*/) const
  {
    switch (data_type)
    {
    case kActorBuffModDataNumber:
      assert(data_type_ == data_type);
      return data_number_;
    default:
      assert(data_type == kActorBuffModDataNumber);
      return 0.0f;
    }
  }
  bool ActorBuffModTypedData::GetBool(eActorBuffModDataType data_type/* = kActorBuffModDataBool*/) const
  {
    switch (data_type)
    {
    case kActorBuffModDataBool:
      assert(data_type_ == data_type);
      return data_bool_;
    default:
      assert(data_type == kActorBuffModDataBool);
      return false;
    }
  }
  const std::string& ActorBuffModTypedData::GetString(eActorBuffModDataType data_type/* = kActorBuffModDataString*/) const
  {
    switch (data_type)
    {
    case kActorBuffModDataString:
      assert(data_type_ == data_type);
      return data_string_;
    default:
      assert(data_type == kActorBuffModDataString);
      return data_string_;
    }
  }
  //ActorBuffModTypedData




  //ActorBuffModData
  ActorBuffModData::ActorBuffModData(eActorBuffModDataType buff_mod_data_type, eActorBuffModKeyType buff_mod_key_type)
    : buff_mod_data_type_(buff_mod_data_type)
    , buff_mod_key_type_(buff_mod_key_type)
  {
    DEBUG_ACTOR_BUFF_MOD_DATA_COUNT ++;
  }

  ActorBuffModData::~ActorBuffModData()
  {
    Clear();

    DEBUG_ACTOR_BUFF_MOD_DATA_COUNT --;
  }

  ActorBuffModData::ActorBuffModData(const ActorBuffModData& buff_mod_data)
  {
    DEBUG_ACTOR_BUFF_MOD_DATA_COUNT ++;

    Clear();

    buff_mod_data_type_ = buff_mod_data.buff_mod_data_type_;
    buff_mod_key_type_ = buff_mod_data.buff_mod_key_type_;

    for (std::list<ActorBuffModTypedData>::const_iterator iterator = buff_mod_data.argument_list.begin(); iterator != buff_mod_data.argument_list.end(); iterator ++)
    {
      ActorBuffModTypedData typed_data_copy(*iterator);
      eActorBuffModDataType data_type = typed_data_copy.GetDataType();

      switch (data_type)
      {
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
      case kActorBuffModDataBuffMod:
        typed_data_copy.SetBuffMod(
          data_type, 
          new ActorBuffModData( *(typed_data_copy.GetBuffMod(data_type)) ) 
          ); //create ActorBuffModData
        break;
      default:
        break;
      }

      argument_list.push_back(typed_data_copy);
    }

    //executed_argument_list_ = buff_mod_data.executed_argument_list_;  generated data, no copy
  }


  void ActorBuffModData::Clear()
  {
    for (std::list<ActorBuffModTypedData>::iterator iterator = argument_list.begin(); iterator != argument_list.end(); iterator ++)
    {
      eActorBuffModDataType data_type = iterator->GetDataType();

      switch (data_type)
      {
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
      case kActorBuffModDataBuffMod:
        delete iterator->GetBuffMod(data_type); //delete ActorBuffModData
        break;
      default:
        break;
      }
    }
    argument_list.clear();

    ClearExecutedArgument();
  }

  void ActorBuffModData::ClearExecutedArgument()
  {
    for (std::list<ActorBuffModTypedData>::iterator iterator = executed_argument_list_.begin(); iterator != executed_argument_list_.end(); iterator ++)
    {
      eActorBuffModDataType data_type = iterator->GetDataType();

      switch (data_type)
      {
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
        //shouldn't generate these type of second-level buff mod
        assert(false);
        delete iterator->GetBuffMod(data_type); //delete ActorBuffModData
        break;
      case kActorBuffModDataBuffMod:
        break;
      default:
        break;
      }
    }
    executed_argument_list_.clear();
  }

  void ActorBuffModData::AppendArgument(ActorBuffModTypedData& argument)
  {
    argument_list.push_back(argument);
  }

  ActorBuffModTypedData& ActorBuffModData::GetArgument(int index/* = 0*/)
  {
    assert(index < argument_list.size());

    std::list<ActorBuffModTypedData>::iterator iterator = argument_list.begin();
    while (iterator != argument_list.end() && index > 0)
    {
      iterator ++;
      index --;
    }
    ActorBuffModTypedData& typed_data = *iterator;
    return typed_data;
  }

  ActorBuffModTypedData ActorBuffModData::Execute(ActorBuffLinkData* buff_link_data)  //will apply mod to linked actor
  {
    ExecuteArgument(buff_link_data);
    return GetActorBuffMod(GetBuffModKeyType())->Execute(buff_link_data, this);
  }

  void ActorBuffModData::ExecuteArgument(ActorBuffLinkData* buff_link_data)
  {
    ClearExecutedArgument();

    for (std::list<ActorBuffModTypedData>::iterator iterator = argument_list.begin(); iterator != argument_list.end(); iterator ++)
    {
      ActorBuffModTypedData& typed_data = *iterator;

      switch (typed_data.GetDataType())
      {
      case kActorBuffModDataBuffModNumber:
      case kActorBuffModDataBuffModBool:
      case kActorBuffModDataBuffModString:
        {
          ActorBuffModData* buff_mod_data = iterator->GetBuffMod(typed_data.GetDataType());
          buff_mod_data->ExecuteArgument(buff_link_data);
          executed_argument_list_.push_back(GetActorBuffMod(buff_mod_data->GetBuffModKeyType())->Execute(buff_link_data, buff_mod_data));
        }
        break;
      case kActorBuffModDataBuffMod:
      default:
        {
          //no execute
          executed_argument_list_.push_back(typed_data);
        }
        break;
      }
    }
  }


  ActorBuffModTypedData& ActorBuffModData::GetExecutedArgument(int index/* = 0*/)
  {
    assert(index < executed_argument_list_.size());

    std::list<ActorBuffModTypedData>::iterator iterator = executed_argument_list_.begin();
    while (iterator != executed_argument_list_.end() && index > 0)
    {
      iterator ++;
      index --;
    }
    ActorBuffModTypedData& typed_data = *iterator;
    return typed_data;
  }
  //ActorBuffModData



  //ActorBuffMod
  ActorBuffMod::ActorBuffMod(eActorBuffModKeyType buff_mod_key_type)
    : buff_mod_key_type_(buff_mod_key_type)
  {
    
  }
  //ActorBuffMod



  ActorBuffMod* get_actor_buff_mod(eActorBuffModKeyType buff_mod_key)
  {
    switch (buff_mod_key)
    {
    case kActorBuffModKeyNumber:
    case kActorBuffModKeyNumberFromActor:
    case kActorBuffModKeyNumberFromSkill:
    case kActorBuffModKeyNumberFromDamage:
    case kActorBuffModKeyNumberFromBuff:
    case kActorBuffModKeyNumberFromBattle:
    case kActorBuffModKeyNumberFromPool:
    case kActorBuffModKeyNumberMod:
    case kActorBuffModKeyNumberRandom:
    case kActorBuffModKeyNumberFromScript:
      return new ActorBuffModNumber(buff_mod_key);
    case kActorBuffModKeyBoolNot:
    case kActorBuffModKeyBoolNumber:
    case kActorBuffModKeyBoolExistStatus:
    case kActorBuffModKeyBoolExistKeyword:
    case kActorBuffModKeyBoolCheckDamage:
    case kActorBuffModKeyBoolMod:
    case kActorBuffModKeyBoolRandom:
      return new ActorBuffModBool(buff_mod_key);
    case kActorBuffModKeyApplyIf:
      return new ActorBuffModBuffModLogic(buff_mod_key);
    case kActorBuffModKeyActorAttributeMod:
    case kActorBuffModKeyActorStatusMod:
    case kActorBuffModKeyActorPositionMod:
      return new ActorBuffModBuffModActor(buff_mod_key);
    case kActorBuffModKeyStatusAdd:
    case kActorBuffModKeyStatusRemove:
    case kActorBuffModKeyStatusImmuneAdd:
    case kActorBuffModKeyStatusImmuneRemove:
      return new ActorBuffModBuffModStatus(buff_mod_key);
    case kActorBuffModKeyDamageMod:
    case kActorBuffModKeyDamageAddByValue:
    case kActorBuffModKeyDamageAddByPercent:
      return new ActorBuffModBuffModDamage(buff_mod_key);
    case kActorBuffModKeyEmitEffectTimeline:
      return new ActorBuffModBuffModEmit(buff_mod_key);
    case kActorBuffModKeyBuffAddById:
    case kActorBuffModKeyBuffRemoveById:
    case kActorBuffModKeyBuffRemoveByStatus:
    case kActorBuffModKeyBuffRemoveByKeyword:
    case kActorBuffModKeyBuffRemoveByType:
      return new ActorBuffModBuffModBuff(buff_mod_key);
    case kActorBuffModKeyScriptMod:
      return new ActorBuffModBuffModScript(buff_mod_key);
    case kActorBuffModKeyScriptModNumber:
      return new ActorBuffModBuffModScriptNumber(buff_mod_key);
    case kActorBuffModKeyScriptModBool:
      return new ActorBuffModBuffModScriptBool(buff_mod_key);
    default:
      CCLog("[ActorBuffMod][get_actor_buff_mod] error buff_mod_key %d", buff_mod_key);
      assert(false);
      return NULL;
    }
  }

  ActorBuffMod* GetActorBuffMod(eActorBuffModKeyType buff_mod_key)
  {
    static std::map<eActorBuffModKeyType, ActorBuffMod*> actor_buff_mod_map;

    if (actor_buff_mod_map.find(buff_mod_key) == actor_buff_mod_map.end())
    {
      actor_buff_mod_map[buff_mod_key] = get_actor_buff_mod(buff_mod_key);
    }

    return actor_buff_mod_map[buff_mod_key];
  }




  ActorBuffModData* create_actor_buff_mod_data(eActorBuffModKeyType buff_mod_key)
  {
    switch (buff_mod_key)
    {
    case kActorBuffModKeyNumber:
    case kActorBuffModKeyNumberFromActor:
    case kActorBuffModKeyNumberFromSkill:
    case kActorBuffModKeyNumberFromDamage:
    case kActorBuffModKeyNumberFromBuff:
    case kActorBuffModKeyNumberFromBattle:
    case kActorBuffModKeyNumberFromPool:
    case kActorBuffModKeyNumberMod:
    case kActorBuffModKeyNumberRandom:
    case kActorBuffModKeyNumberFromScript:
    case kActorBuffModKeyScriptModNumber:
      return new ActorBuffModData(kActorBuffModDataNumber, buff_mod_key);
    case kActorBuffModKeyBoolNot:
    case kActorBuffModKeyBoolNumber:
    case kActorBuffModKeyBoolExistStatus:
    case kActorBuffModKeyBoolExistKeyword:
    case kActorBuffModKeyBoolCheckDamage:
    case kActorBuffModKeyBoolMod:
    case kActorBuffModKeyBoolRandom:
    case kActorBuffModKeyScriptModBool:
      return new ActorBuffModData(kActorBuffModDataBool, buff_mod_key);
    case kActorBuffModKeyApplyIf:
    case kActorBuffModKeyActorAttributeMod:
    case kActorBuffModKeyActorStatusMod:
    case kActorBuffModKeyActorPositionMod:
    case kActorBuffModKeyStatusAdd:
    case kActorBuffModKeyStatusRemove:
    case kActorBuffModKeyStatusImmuneAdd:
    case kActorBuffModKeyStatusImmuneRemove:
    case kActorBuffModKeyDamageMod:
    case kActorBuffModKeyDamageAddByValue:
    case kActorBuffModKeyDamageAddByPercent:
    case kActorBuffModKeyEmitEffectTimeline:
    case kActorBuffModKeyBuffAddById:
    case kActorBuffModKeyBuffRemoveById:
    case kActorBuffModKeyBuffRemoveByStatus:
    case kActorBuffModKeyBuffRemoveByKeyword:
    case kActorBuffModKeyBuffRemoveByType:
    case kActorBuffModKeyScriptMod:
      return new ActorBuffModData(kActorBuffModDataBuffMod, buff_mod_key);
    default:
      CCLog("[ActorBuffMod][get_actor_buff_mod_data] error buff_mod_key %d", buff_mod_key);
      assert(false);
      return NULL;
    }
  }

  ActorBuffModData* CreateActorBuffModData(eActorBuffModKeyType buff_mod_key)
  {
    return create_actor_buff_mod_data(buff_mod_key);
  }


  eActorBuffModKeyType get_buff_mod_key(const std::string& source_string);
  std::list<eActorBuffModDataType>* get_buff_mod_argument_list(eActorBuffModKeyType buff_mod_key);
  bool parse_argument(ActorBuffModData* buff_mod_data, eActorBuffModDataType value_type, std::list<std::string>* buff_mod_string_list);  //true = need more, false = next one


  ActorBuffModData* ParseActorBuffModData(std::list<std::string>* buff_mod_string_list)
  {
    //flush "||||||" type empty string at beginning
    while (!buff_mod_string_list->empty() && buff_mod_string_list->begin()->empty())
    {
      buff_mod_string_list->pop_front();
    }

    if (buff_mod_string_list->empty())
    {
      return NULL;
    }

    eActorBuffModKeyType buff_mod_key = get_buff_mod_key(*(buff_mod_string_list->begin()));
    buff_mod_string_list->pop_front();

    ActorBuffModData* buff_mod_data = create_actor_buff_mod_data(buff_mod_key);

    std::list<eActorBuffModDataType>* buff_mod_argument_list = get_buff_mod_argument_list(buff_mod_key);

    std::list<eActorBuffModDataType>::iterator iterator = buff_mod_argument_list->begin();
    while(iterator != buff_mod_argument_list->end())
    {
      while (iterator != buff_mod_argument_list->end())
      {
        eActorBuffModDataType value_type = *iterator;

        bool is_more_needed = parse_argument(buff_mod_data, value_type, buff_mod_string_list);

        if (is_more_needed ==false)
        {
          break;
        }
        else
        {
          //special for "..." arguments
        }
      }

      //next arg
      iterator ++;
    }

    return buff_mod_data;
  }



  bool parse_argument(ActorBuffModData* buff_mod_data, eActorBuffModDataType value_type, std::list<std::string>* buff_mod_string_list)  //true = need more, false = next one
  {
    if (buff_mod_string_list->empty())
    {
      return false;
    }

    //skip empty arg by default
    if (buff_mod_string_list->begin()->empty())
    {
      //flush all empty empty string
      while (!buff_mod_string_list->empty() && buff_mod_string_list->begin()->empty())
      {
        buff_mod_string_list->pop_front();
      }
      return false;
    }

    std::string& buff_mod_string = *(buff_mod_string_list->begin());
    bool is_argument_buff_mod = ((!buff_mod_string.empty()) && (buff_mod_string.at(0) == '<')); //a "<_____" string means a buff mod

    ActorBuffModTypedData result_data;

    if (is_argument_buff_mod)
    {
      ActorBuffModData* buff_mod_data = ParseActorBuffModData(buff_mod_string_list);
      eActorBuffModDataType mod_result_data_type = buff_mod_data->GetBuffModDataType();

      //check is expected mod type
      switch (value_type)
      {
      case kActorBuffModDataBuffMod:
      case kActorBuffModDataMoreBuffMod:
        assert(mod_result_data_type == kActorBuffModDataBuffMod);
        result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
        break;
      case kActorBuffModDataNumber:
      case kActorBuffModDataMoreNumber:
        assert(mod_result_data_type == kActorBuffModDataNumber);
        result_data.SetBuffMod(kActorBuffModDataBuffModNumber, buff_mod_data);
        break;
      case kActorBuffModDataBool:
      case kActorBuffModDataMoreBool:
        assert(mod_result_data_type == kActorBuffModDataBool);
        result_data.SetBuffMod(kActorBuffModDataBuffModBool, buff_mod_data);
        break;
      case kActorBuffModDataString:
      case kActorBuffModDataMoreString:
        assert(mod_result_data_type == kActorBuffModDataString);
        result_data.SetBuffMod(kActorBuffModDataBuffModString, buff_mod_data);
        break;
      case kActorBuffModDataMore:
        //no check, only for script mod arg //assert(mod_result_data_type == kActorBuffModDataString);
        switch (mod_result_data_type)
        {
        case kActorBuffModDataBuffMod:
          result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
          break;
        case kActorBuffModDataNumber:
          result_data.SetBuffMod(kActorBuffModDataBuffModNumber, buff_mod_data);
          break;
        case kActorBuffModDataBool:
          result_data.SetBuffMod(kActorBuffModDataBuffModBool, buff_mod_data);
          break;
        case kActorBuffModDataString:
          result_data.SetBuffMod(kActorBuffModDataBuffModString, buff_mod_data);
          break;
        default:
          assert(false);
          break;
        }
        break;
      default:
        CCLog("[ActorBuffMod][parse_argument][argument_buff_mod] error value_type %d", value_type);
        assert(false);
        break;
      }
    }
    else
    {
      switch (value_type)
      {
      case kActorBuffModDataBuffMod:
      case kActorBuffModDataMoreBuffMod:
        CCLog("[ActorBuffMod][parse_argument][argument_value] type value mis-match, buff mod expected!");
        assert(false); //result_data.SetBuffMod(kActorBuffModDataBuffMod, ParseActorBuffModData(buff_mod_string_list));
        break;
      case kActorBuffModDataNumber:
      case kActorBuffModDataMoreNumber:
        result_data.SetNumber(kActorBuffModDataNumber, String2Float(*(buff_mod_string_list->begin())));
        buff_mod_string_list->pop_front();
        break;
      case kActorBuffModDataBool:
      case kActorBuffModDataMoreBool:
        result_data.SetBool(kActorBuffModDataBool, String2Bool(*(buff_mod_string_list->begin())));
        buff_mod_string_list->pop_front();
        break;
      case kActorBuffModDataString:
      case kActorBuffModDataMoreString:
      case kActorBuffModDataMore:
        result_data.SetString(kActorBuffModDataString, *(buff_mod_string_list->begin()));
        buff_mod_string_list->pop_front();
        break;
      default:
        CCLog("[ActorBuffMod][parse_argument][argument_value] error value_type %d", value_type);
        assert(false);
        break;
      }
    }

    buff_mod_data->AppendArgument(result_data);

    switch (value_type)
    {
    case kActorBuffModDataMoreBuffMod:
    case kActorBuffModDataMoreNumber:
    case kActorBuffModDataMoreBool:
    case kActorBuffModDataMoreString:
    case kActorBuffModDataMore:
      return true;
    default:
      return false;
    }
  }














  eActorBuffModKeyType get_buff_mod_key(const std::string& source_string)
  {
    if (source_string == "<number>")
      return kActorBuffModKeyNumber;

    else if (source_string == "<number_from_actor>")
      return kActorBuffModKeyNumberFromActor;
    else if (source_string == "<number_from_skill>")
      return kActorBuffModKeyNumberFromSkill;
    else if (source_string == "<number_from_damage>")
      return kActorBuffModKeyNumberFromDamage;
    else if (source_string == "<number_from_buff>")
      return kActorBuffModKeyNumberFromBuff;
    else if (source_string == "<number_from_battle>")
      return kActorBuffModKeyNumberFromBattle;
    else if (source_string == "<number_from_pool>")
      return kActorBuffModKeyNumberFromPool;
    else if (source_string == "<number_mod>")
      return kActorBuffModKeyNumberMod;
    else if (source_string == "<number_random>")
      return kActorBuffModKeyNumberRandom;
    else if (source_string == "<number_from_script>")
      return kActorBuffModKeyNumberFromScript;

    else if (source_string == "<bool_not>")
      return kActorBuffModKeyBoolNot;
    else if (source_string == "<bool_number>")
      return kActorBuffModKeyBoolNumber;
    else if (source_string == "<bool_exist_status>")
      return kActorBuffModKeyBoolExistStatus;
    else if (source_string == "<bool_exist_keyword>")
      return kActorBuffModKeyBoolExistKeyword;
    else if (source_string == "<bool_check_damage>")
      return kActorBuffModKeyBoolCheckDamage;
    else if (source_string == "<bool_mod>")
      return kActorBuffModKeyBoolMod;
    else if (source_string == "<bool_random>")
      return kActorBuffModKeyBoolRandom;

    else if (source_string == "<apply_if>")
      return kActorBuffModKeyApplyIf;

    else if (source_string == "<actor_attribute_mod>")
      return kActorBuffModKeyActorAttributeMod;
    else if (source_string == "<actor_status_mod>")
      return kActorBuffModKeyActorStatusMod;
    else if (source_string == "<actor_position_mod>")
      return kActorBuffModKeyActorPositionMod;

    else if (source_string == "<status_add>")
      return kActorBuffModKeyStatusAdd;
    else if (source_string == "<status_remove>")
      return kActorBuffModKeyStatusRemove;
    else if (source_string == "<status_immune_add>")
      return kActorBuffModKeyStatusImmuneAdd;
    else if (source_string == "<status_immune_remove>")
      return kActorBuffModKeyStatusImmuneRemove;

    else if (source_string == "<damage_mod>")
      return kActorBuffModKeyDamageMod;
    else if (source_string == "<damage_add_by_value>")
      return kActorBuffModKeyDamageAddByValue;
    else if (source_string == "<damage_add_by_percent>")
      return kActorBuffModKeyDamageAddByPercent;

    else if (source_string == "<emit_effect_timeline>")
      return kActorBuffModKeyEmitEffectTimeline;
    
    else if (source_string == "<buff_add_by_id>")
      return kActorBuffModKeyBuffAddById;
    else if (source_string == "<buff_remove_by_id>")
      return kActorBuffModKeyBuffRemoveById;
    else if (source_string == "<buff_remove_by_status>")
      return kActorBuffModKeyBuffRemoveByStatus;
    else if (source_string == "<buff_remove_by_keyword>")
      return kActorBuffModKeyBuffRemoveByKeyword;
    else if (source_string == "<buff_remove_by_type>")
      return kActorBuffModKeyBuffRemoveByType;

    else if (source_string == "<script_mod>")
      return kActorBuffModKeyScriptMod;
    else if (source_string == "<script_mod_number>")
      return kActorBuffModKeyScriptModNumber;
    else if (source_string == "<script_mod_bool>")
      return kActorBuffModKeyScriptModBool;

    else
    {
      CCLog("[ActorBuffMod][get_buff_mod_key] error source_string %s", source_string.c_str());
      assert(false);
      return kActorBuffModKey;
    }
  }




  std::list<eActorBuffModDataType>* get_buff_mod_argument_list(eActorBuffModKeyType buff_mod_key)
  {
    static std::map<eActorBuffModKeyType, std::list<eActorBuffModDataType> > buff_mod_argument_list_map;

    if (buff_mod_argument_list_map.empty())
    {
      buff_mod_argument_list_map[kActorBuffModKeyNumber].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromActor].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromSkill].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromDamage].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromBuff].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromBattle].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromBattle].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromPool].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromPool].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyNumberMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberRandom].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyNumberRandom].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyNumberFromScript].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyNumberFromScript].push_back(kActorBuffModDataMore);


      buff_mod_argument_list_map[kActorBuffModKeyBoolNot].push_back(kActorBuffModDataBool);

      buff_mod_argument_list_map[kActorBuffModKeyBoolNumber].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBoolNumber].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyBoolExistStatus].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBoolExistStatus].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyBoolExistKeyword].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBoolExistKeyword].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyBoolCheckDamage].push_back(kActorBuffModDataString);

      buff_mod_argument_list_map[kActorBuffModKeyBoolMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBoolMod].push_back(kActorBuffModDataBool);
      buff_mod_argument_list_map[kActorBuffModKeyBoolMod].push_back(kActorBuffModDataBool);

      buff_mod_argument_list_map[kActorBuffModKeyBoolRandom].push_back(kActorBuffModDataNumber);


      buff_mod_argument_list_map[kActorBuffModKeyApplyIf].push_back(kActorBuffModDataBool);
      buff_mod_argument_list_map[kActorBuffModKeyApplyIf].push_back(kActorBuffModDataBuffMod);


      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyActorAttributeMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyActorStatusMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyActorStatusMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyActorPositionMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyActorPositionMod].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyActorPositionMod].push_back(kActorBuffModDataNumber);


      buff_mod_argument_list_map[kActorBuffModKeyStatusAdd].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusAdd].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyStatusRemove].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusRemove].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyStatusImmuneAdd].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusImmuneAdd].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyStatusImmuneRemove].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyStatusImmuneRemove].push_back(kActorBuffModDataMoreString);


      buff_mod_argument_list_map[kActorBuffModKeyDamageMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageMod].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByValue].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByValue].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByValue].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByValue].push_back(kActorBuffModDataNumber);

      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByPercent].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByPercent].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByPercent].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByPercent].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyDamageAddByPercent].push_back(kActorBuffModDataNumber);


      buff_mod_argument_list_map[kActorBuffModKeyEmitEffectTimeline].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyEmitEffectTimeline].push_back(kActorBuffModDataMoreNumber);
      

      buff_mod_argument_list_map[kActorBuffModKeyBuffAddById].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffAddById].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyBuffAddById].push_back(kActorBuffModDataMoreNumber);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveById].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveById].push_back(kActorBuffModDataNumber);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveById].push_back(kActorBuffModDataMoreNumber);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByStatus].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByStatus].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByStatus].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByKeyword].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByKeyword].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByKeyword].push_back(kActorBuffModDataMoreString);

      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByType].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByType].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyBuffRemoveByType].push_back(kActorBuffModDataMoreString);


      buff_mod_argument_list_map[kActorBuffModKeyScriptMod].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyScriptMod].push_back(kActorBuffModDataMore);

      buff_mod_argument_list_map[kActorBuffModKeyScriptModNumber].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyScriptModNumber].push_back(kActorBuffModDataMore);

      buff_mod_argument_list_map[kActorBuffModKeyScriptModBool].push_back(kActorBuffModDataString);
      buff_mod_argument_list_map[kActorBuffModKeyScriptModBool].push_back(kActorBuffModDataMore);
    }

    if (buff_mod_argument_list_map.find(buff_mod_key) != buff_mod_argument_list_map.end())
      return &(buff_mod_argument_list_map[buff_mod_key]);
    else
    {
      CCLog("[ActorBuffMod][get_buff_mod_argument_list] error buff_mod_key %d", buff_mod_key);
      assert(false);
      return NULL;
    }
  }




  Actor* QuickGetSelectedActor(ActorBuffLinkData* buff_link_data, const std::string& selected_actor_type)
  {
    Actor* actor = NULL;

    if (selected_actor_type == "self")
    {
      actor = buff_link_data->actor_buff->GetActor();
    }
    else if (selected_actor_type == "skill_source")
    {
      actor = buff_link_data->actor_buff->GetActor()->GetActorExtEnv()->GetActorById(buff_link_data->skill_link_data.actor_id);
    }
    else if (selected_actor_type == "damage_source")
    {
      if (buff_link_data->buff_event_data.data_type == kActorEventDataDamagePackage)
      {
        int actor_id = buff_link_data->buff_event_data.data_value.damage_package->GetStatus(kActorDamageStatusSourceActorId);
        actor = buff_link_data->actor_buff->GetActor()->GetActorExtEnv()->GetActorById(actor_id);
      }
      else
      {
        assert(buff_link_data->buff_event_data.data_type == kActorEventDataDamagePackage);
      }
    }
    else if (selected_actor_type == "damage_target")
    {
      if (buff_link_data->buff_event_data.data_type == kActorEventDataDamagePackage)
      {
        int actor_id = buff_link_data->buff_event_data.data_value.damage_package->GetStatus(kActorDamageStatusTargetActorId);
        actor = buff_link_data->actor_buff->GetActor()->GetActorExtEnv()->GetActorById(actor_id);
      }
      else
      {
        assert(buff_link_data->buff_event_data.data_type == kActorEventDataDamagePackage);
      }
    }
    else
    {
      assert(
        selected_actor_type == "self" 
        || selected_actor_type == "skill_source" 
        || selected_actor_type == "damage_source" 
        || selected_actor_type == "damage_target"
      );
    }

    return actor;
  }



  taomee::battle::BattleController* QuickGetBattleController()
  {
    return &taomee::battle::BattleController::GetInstance();
  }


  lua_tinker::table QuickPackLuaArgumentTable(const std::list<ActorBuffModTypedData>& argument_list, int skip_count/* = 0*/)
  {
    std::list<ActorBuffModTypedData>::const_iterator iterator = argument_list.begin();

    //skip argument
    while (skip_count > 0 && iterator != argument_list.end())
    {
      iterator ++;
      skip_count --;
    }

    //create lua argument_data_table
    lua_tinker::table argument_data_table = lua_tinker::table(lua_data_tunnel::GetLuaState());
    int lua_table_index = 1;
    for ( ; iterator != argument_list.end(); iterator ++)
    {
      const ActorBuffModTypedData& typed_data = *iterator;

      switch (typed_data.GetDataType())
      {
      case kActorBuffModDataBool:
        argument_data_table.set(lua_table_index, typed_data.GetBool());
        break;
      case kActorBuffModDataNumber:
        argument_data_table.set(lua_table_index, typed_data.GetNumber());
        break;
      case kActorBuffModDataString:
        argument_data_table.set(lua_table_index, typed_data.GetString().c_str());
        break;
      default:
        CCLog("[ActorBuffModBuffModScript][Execute] error script argument data_type %d", typed_data.GetDataType());
        assert(false);
        break;
      }

      lua_table_index ++;
    }

    return argument_data_table;
  }



  battle_data::eBattleAttributeType ParseBattleAttributeType(const std::string& source_string)
  {
    std::string attribute_type_string = source_string;

    std::string::size_type found_pos = attribute_type_string.find_first_of("kBattleAttribute");

    if (found_pos != std::string::npos)
    {
      attribute_type_string = attribute_type_string.replace(found_pos, strlen("kBattleAttribute"), "");
    }

    /*if (attribute_type_string.empty()) return battle_data::kBattleAttribute;
    else */if (attribute_type_string == "TimeTotal") return battle_data::kBattleAttributeTimeTotal;
    else if (attribute_type_string == "TimeBattleTotal") return battle_data::kBattleAttributeTimeBattleTotal;
    else if (attribute_type_string == "TimeBattleActive") return battle_data::kBattleAttributeTimeBattleActive;
    else if (attribute_type_string == "TimeBattleActiveLimit") return battle_data::kBattleAttributeTimeBattleActiveLimit;
    else if (attribute_type_string == "TimeSwitchWave") return battle_data::kBattleAttributeTimeSwitchWave;
    else if (attribute_type_string == "TimeSwitchWaveLimit") return battle_data::kBattleAttributeTimeSwitchWaveLimit;
    else if (attribute_type_string == "WaveCurrent") return battle_data::kBattleAttributeWaveCurrent;
    else if (attribute_type_string == "WaveCurrentTime") return battle_data::kBattleAttributeWaveCurrentTime;
    else if (attribute_type_string == "WaveSize") return battle_data::kBattleAttributeWaveSize;
    else if (attribute_type_string == "WaveCurrentActorLeft") return battle_data::kBattleAttributeWaveCurrentActorLeft;
    else if (attribute_type_string == "ActorCountTotal") return battle_data::kBattleAttributeActorCountTotal;
    else if (attribute_type_string == "ActorCountAlive") return battle_data::kBattleAttributeActorCountAlive;
    else if (attribute_type_string == "ActorCountLeft") return battle_data::kBattleAttributeActorCountLeft;
    else if (attribute_type_string == "ActorCountDead") return battle_data::kBattleAttributeActorCountDead;
    else if (attribute_type_string == "ActorCountUserSupportTotal") return battle_data::kBattleAttributeActorCountUserSupportTotal;
    else if (attribute_type_string == "ActorCountUserSupportAlive") return battle_data::kBattleAttributeActorCountUserSupportAlive;
    else if (attribute_type_string == "ActorCountUserSupportLeft") return battle_data::kBattleAttributeActorCountUserSupportLeft;
    else if (attribute_type_string == "ActorCountUserSupportDead") return battle_data::kBattleAttributeActorCountUserSupportDead;
    else if (attribute_type_string == "ActorCountUserOpposeTotal") return battle_data::kBattleAttributeActorCountUserOpposeTotal;
    else if (attribute_type_string == "ActorCountUserOpposeAlive") return battle_data::kBattleAttributeActorCountUserOpposeAlive;
    else if (attribute_type_string == "ActorCountUserOpposeLeft") return battle_data::kBattleAttributeActorCountUserOpposeLeft;
    else if (attribute_type_string == "ActorCountUserOpposeDead") return battle_data::kBattleAttributeActorCountUserOpposeDead;
    else
    {
      CCLog("[ParseBattleAttributeType] error attribute_type_string <%s>!", attribute_type_string.c_str());
      assert(false);
      return battle_data::kBattleAttribute;
    }
  }

  battle_data::eBattleStatusType ParseBattleStatusType(const std::string& source_string)
  {
    /*if (source_string.empty()) return battle_data::kBattleStatus;
    else */if (source_string == "BattleType") return battle_data::kBattleStatusBattleType;
    else if (source_string == "SceneType") return battle_data::kBattleStatusSceneType;
    else if (source_string == "LevelId") return battle_data::kBattleStatusLevelId;
    else if (source_string == "State") return battle_data::kBattleStatusState;
    else if (source_string == "IsPaused") return battle_data::kBattleStatusIsPaused;
    else if (source_string == "IsSkillMask") return battle_data::kBattleStatusIsSkillMask;
    else if (source_string == "IsUserQuit") return battle_data::kBattleStatusIsUserQuit;
    else if (source_string == "ConnectorActorSkillReady") return battle_data::kBattleStatusConnectorActorSkillReady;
    else if (source_string == "ConnectorActorSkillRelease") return battle_data::kBattleStatusConnectorActorSkillRelease;
    else if (source_string == "ConnectorActorBorn") return battle_data::kBattleStatusConnectorActorBorn;
    else if (source_string == "ConnectorActorDead") return battle_data::kBattleStatusConnectorActorDead;
    else if (source_string == "ResultIsWin") return battle_data::kBattleStatusResultIsWin;
    else if (source_string == "ResultStar") return battle_data::kBattleStatusResultStar;
    else if (source_string == "FinishedIsUserQuit") return battle_data::kBattleStatusFinishedIsUserQuit;
    else if (source_string == "FinishedInLimitedTime") return battle_data::kBattleStatusFinishedInLimitedTime;
    else if (source_string == "FinishedAllAllyAlive") return battle_data::kBattleStatusFinishedAllAllyAlive;
    else if (source_string == "FinishedWithSkillKill") return battle_data::kBattleStatusFinishedWithSkillKill;
    else if (source_string == "FinishedUnexplainableGrade") return battle_data::kBattleStatusFinishedUnexplainableGrade;
    else if (source_string == "IsTouchEnabled") return battle_data::kBattleStatusIsTouchEnabled;
    else if (source_string == "IsTouchLimited") return battle_data::kBattleStatusIsTouchLimited;
    else if (source_string == "TouchLimitSourceId") return battle_data::kBattleStatusTouchLimitSourceId;
    else if (source_string == "TouchLimitTargetId") return battle_data::kBattleStatusTouchLimitTargetId;
    else if (source_string == "LevelConfigIsSkipMessageEnd") return battle_data::kBattleStatusLevelConfigIsSkipMessageEnd;
    else if (source_string == "LevelConfigIsSkipSwitchWaveUI") return battle_data::kBattleStatusLevelConfigIsSkipSwitchWaveUI;
    else if (source_string == "LevelConfigIsSkipResult") return battle_data::kBattleStatusLevelConfigIsSkipResult;
    else if (source_string == "LevelConfigIsHideToolButton") return battle_data::kBattleStatusLevelConfigIsHideToolButton;
    else
    {
      CCLog("[ParseBattleStatusType] error source_string <%s>!", source_string.c_str());
      assert(false);
      return battle_data::kBattleStatus;
    }
  }

} // namespace actor