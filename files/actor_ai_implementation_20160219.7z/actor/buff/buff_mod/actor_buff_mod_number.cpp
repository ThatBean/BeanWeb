#include "actor_buff_mod_number.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"
#include "game/actor/actor_ext/actor_ext_damage.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_config_data_table.h"
#include "game/data_table/buff_config_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"
#include "engine/base/random_helper.h"

namespace actor {

  //ActorBuffModNumber
  ActorBuffModTypedData ActorBuffModNumber::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    float result_number = 0.0f;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyNumber:
      {
        result_number = buff_mod_data->GetExecutedArgument(0).GetNumber();
      }
      break;
    case kActorBuffModKeyNumberFromActor:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        const std::string& actor_data_type_selected = buff_mod_data->GetExecutedArgument(1).GetString();
        if (actor_data_type_selected == "attribute")
        {
          eActorAttributeType attribute_type = ParseActorAttributeType(buff_mod_data->GetExecutedArgument(2).GetString());
          ActorAttributeData* attribute_data = actor->GetActorData()->GetActorAttributeData(attribute_type);

          const std::string& attribute_data_selected = buff_mod_data->GetExecutedArgument(3).GetString();
          if (attribute_data_selected == "value")
            result_number = attribute_data->Get();
          else if (attribute_data_selected == "base")
            result_number = attribute_data->GetBase();
          else if (attribute_data_selected == "add")
            result_number = attribute_data->GetAdd();
          else if (attribute_data_selected == "multiplier")
            result_number = attribute_data->GetMultiplier();
          else if (attribute_data_selected == "extra")
            result_number = attribute_data->GetExtra();
          else
            assert(attribute_data_selected == "value" 
            || attribute_data_selected == "base" 
            || attribute_data_selected == "add" 
            || attribute_data_selected == "multiplier" 
            || attribute_data_selected == "extra");
        }
        else if (actor_data_type_selected == "status")
        {
          eActorStatusType status_type = ParseActorStatusType(buff_mod_data->GetExecutedArgument(2).GetString());
          ActorStatusData* status_data = actor->GetActorData()->GetActorStatusData(status_type);

          const std::string& status_data_selected = buff_mod_data->GetExecutedArgument(3).GetString();
          if (status_data_selected == "value")
            result_number = status_data->Get();
          else if (status_data_selected == "base")
            result_number = status_data->GetBase();
          else if (status_data_selected == "bool")
            result_number = status_data->GetBool() ? 1 : 0;
          else
            assert(status_data_selected == "value"
              || status_data_selected == "base" 
              || status_data_selected == "bool");
        }
        else
          assert(actor_data_type_selected == "attribute" 
            || actor_data_type_selected == "status");
      }
      break;
    case kActorBuffModKeyNumberFromSkill:
      {
        SkillConfigData* skill_config_data = buff_link_data->skill_link_data.skill_config_data;

        if (!skill_config_data)
        {
          buff_link_data->Deactivate();
          break;
        }

        const std::string& skill_data_type_string = buff_mod_data->GetExecutedArgument(0).GetString();

        if (skill_data_type_string == "energy_cost")
        {
          result_number = skill_config_data->GetCostValue();
        }
        else if (skill_data_type_string == "energy_recover")
        {
          result_number = skill_config_data->GetRecoverValue();
        }
        else if (skill_data_type_string == "cooldown_init")
        {
          result_number = skill_config_data->GetCooldownInit();
        }
        else if (skill_data_type_string == "cooldown_reset")
        {
          result_number = skill_config_data->GetCooldown();
        }
        else if (skill_data_type_string == "damage_base")
        {
          //special: use Physical/Magical Attack * skill_damage_scale
          Actor* actor = buff_link_data->actor_buff->GetActor()->GetActorExtEnv()->GetActorById(buff_link_data->skill_link_data.actor_id);
          
          float actor_attack_value = actor->GetActorData()->GetActorAttribute(kActorAttributeAttackPhysical) 
            + actor->GetActorData()->GetActorAttribute(kActorAttributeAttackMagical);

          result_number = actor_attack_value 
            * (buff_link_data->skill_link_data.skill_level * skill_config_data->GetLevelAddDamageScale() * 0.01f + 1.0f)
            * skill_config_data->GetDamageScaleBase();
        }
        else if (skill_data_type_string == "damage_scale")
        {
          //skill_damage_scale = (skill_level * skill_level_add_damage_scale * 0.01 + 1) * skill_damage_scale_base
          result_number = (
              buff_link_data->skill_link_data.skill_level * skill_config_data->GetLevelAddDamageScale() * 0.01f 
              + 1.0f
            ) * skill_config_data->GetDamageScaleBase();
        }
        else if (skill_data_type_string == "level")
        {
          result_number = buff_link_data->skill_link_data.skill_level;
        }
        else
        {
          assert(skill_data_type_string == "energy_cost" 
            || skill_data_type_string == "energy_recover"
            || skill_data_type_string == "cooldown_init"
            || skill_data_type_string == "cooldown_reset"
            || skill_data_type_string == "damage_base"
            || skill_data_type_string == "damage_scale"
            || skill_data_type_string == "level");
          buff_link_data->Deactivate();
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberFromDamage:
      {
        const std::string& damage_data_type_string = buff_mod_data->GetExecutedArgument(0).GetString();

        switch (buff_link_data->buff_event_data.data_type)
        {
        case kActorEventDataDamagePackage:
          {
            if (damage_data_type_string == "damage_health_total")
            {
              result_number = buff_link_data->buff_event_data.data_value.damage_package->GetDamage(0
                | kActorDamageAttributePhysical
                | kActorDamageAttributeMagical
                | kActorDamageAttributeHealth);
            }
            else if (damage_data_type_string == "damage_physical")
            {
              result_number = buff_link_data->buff_event_data.data_value.damage_package->GetDamage(kActorDamageAttributePhysical);
            }
            else if (damage_data_type_string == "damage_magical")
            {
              result_number = buff_link_data->buff_event_data.data_value.damage_package->GetDamage(kActorDamageAttributeMagical);
            }
            else if (damage_data_type_string == "heal_health_total")
            {
              result_number = -1.0f * buff_link_data->buff_event_data.data_value.damage_package->GetDamage(0
                | kActorDamageAttributePhysical
                | kActorDamageAttributeMagical
                | kActorDamageAttributeHealth);
            }
            else if (damage_data_type_string == "heal_physical")
            {
              result_number = -1.0f * buff_link_data->buff_event_data.data_value.damage_package->GetDamage(kActorDamageAttributePhysical);
            }
            else if (damage_data_type_string == "heal_magical")
            {
              result_number = -1.0f * buff_link_data->buff_event_data.data_value.damage_package->GetDamage(kActorDamageAttributeMagical);
            }
            else
            {
              assert(damage_data_type_string == "damage_health_total" 
                || damage_data_type_string == "damage_physical"
                || damage_data_type_string == "damage_magical"
                || damage_data_type_string == "heal_health_total"
                || damage_data_type_string == "heal_physical"
                || damage_data_type_string == "heal_magical");
              buff_link_data->Deactivate();
              break;
            }

          }
          break;
        case kActorEventDataAttribute:
          {
            if (damage_data_type_string == "damage_dealt")
            {
              result_number = buff_link_data->buff_event_data.data_value.attribute;
            }
            else if (damage_data_type_string == "heal_dealt")
            {
              result_number = buff_link_data->buff_event_data.data_value.attribute * -1.0f;
            }
            else
            {
              assert(damage_data_type_string == "damage_dealt" 
                || damage_data_type_string == "heal_dealt");
              buff_link_data->Deactivate();
              break;
            }

          }
          break;
        default:
          buff_link_data->Deactivate();
          break;
        }

        result_number = MAX(0, result_number);
      }
      break;
    case kActorBuffModKeyNumberFromBuff:
      {
        const std::string& battle_data_type_selected = buff_mod_data->GetExecutedArgument(0).GetString();
        if (battle_data_type_selected == "stack_count")
        {
          result_number = buff_link_data->stack_count;
        }
        else if (battle_data_type_selected == "applied_time")
        {
          result_number = buff_link_data->applied_time;
        }
        else if (battle_data_type_selected == "applied_time_limit")
        {
          result_number = buff_link_data->buff_config_data->GetApplyData()->limit_time;
        }
        else if (battle_data_type_selected == "applied_count")
        {
          result_number = buff_link_data->applied_count;
        }
        else if (battle_data_type_selected == "applied_count_limit")
        {
          result_number = buff_link_data->buff_config_data->GetApplyData()->limit_count;
        }
        else
        {
          assert(battle_data_type_selected == "stack_count" 
            || battle_data_type_selected == "applied_time"
            || battle_data_type_selected == "applied_time_limit"
            || battle_data_type_selected == "applied_count"
            || battle_data_type_selected == "applied_count_limit");
          buff_link_data->Deactivate();
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberFromBattle:
      {
        const std::string& battle_data_type_selected = buff_mod_data->GetExecutedArgument(0).GetString();
        if (battle_data_type_selected == "attribute")
        {
          battle_data::eBattleAttributeType attribute_type = ParseBattleAttributeType(buff_mod_data->GetExecutedArgument(1).GetString());
          result_number = QuickGetBattleController()->GetBattleAttribute(attribute_type);
        }
        else if (battle_data_type_selected == "status")
        {
          battle_data::eBattleStatusType status_type = ParseBattleStatusType(buff_mod_data->GetExecutedArgument(1).GetString());
          result_number = QuickGetBattleController()->GetBattleStatus(status_type);
        }
        else
        {
          assert(battle_data_type_selected == "attribute" 
            || battle_data_type_selected == "status");
          buff_link_data->Deactivate();
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberFromPool:
      {
        float current_pool_size;

        if (buff_mod_data->GetExecutedArgumentList().size() == 2)
        {
          //first time init pool size as argument 2(the third)
          current_pool_size = buff_mod_data->GetExecutedArgument(1).GetNumber();

          ActorBuffModTypedData typed_data;
          typed_data.SetNumber(kActorBuffModDataNumber, current_pool_size);
          buff_mod_data->AppendArgument(typed_data);
        }
        else
        {
          current_pool_size = buff_mod_data->GetExecutedArgument(2).GetNumber();
        }

        float request_number = buff_mod_data->GetExecutedArgument(0).GetNumber();

        result_number = MIN(request_number, current_pool_size);

        current_pool_size -= result_number;

        // mark buff expired
        if (current_pool_size <= 0) 
          buff_link_data->Deactivate();
        else 
          buff_mod_data->GetArgument(2).SetNumber(kActorBuffModDataNumber, current_pool_size);
      }
      break;
    case kActorBuffModKeyNumberMod:
      {
        const std::string& number_operation_type = buff_mod_data->GetExecutedArgument(0).GetString();
        float number_1 = buff_mod_data->GetExecutedArgument(1).GetNumber();
        float number_2 = buff_mod_data->GetExecutedArgument(2).GetNumber();

        if (number_operation_type == "add")
          result_number = number_1 + number_2;
        else if (number_operation_type == "sub")
          result_number = number_1 - number_2;
        else if (number_operation_type == "scale")
          result_number = number_1 * number_2;
        else if (number_operation_type == "divide")
          if (number_2 == 0)
          {
            CCLog("[ActorBuffModNumber][Execute][kActorBuffModKeyNumberMod] error divide! number_2 == 0");
            assert(false);
            result_number = number_1;
          }
          else
          {
            result_number = number_1 / number_2;
          }
        else
        {
          assert(number_operation_type == "add" 
            || number_operation_type == "sub"
            || number_operation_type == "scale"
            || number_operation_type == "divide");
          buff_link_data->Deactivate();
          break;
        }
      }
      break;
    case kActorBuffModKeyNumberRandom:
      {
        float number_from = buff_mod_data->GetExecutedArgument(0).GetNumber();
        float number_to = buff_mod_data->GetExecutedArgument(1).GetNumber();

        result_number = random_lower_upper(number_from, number_to);
      }
      break;
    case kActorBuffModKeyNumberFromScript:
      {
        //create lua argument_data_table
        lua_tinker::table argument_data_table = QuickPackLuaArgumentTable(buff_mod_data->GetExecutedArgumentList(), 1);

        result_number = LuaTinkerManager::GetInstance().CallLuaFunc<float>("script/actor/buff/lua_buff_mod_number.lua", 
          "Execute", 
          buff_mod_data->GetExecutedArgument(0).GetString().c_str(),
          buff_link_data,
          argument_data_table);
      }
      break;
    default:
      CCLog("[ActorBuffModNumber][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetNumber(kActorBuffModDataNumber, result_number);
    return result_data;
  }
  //ActorBuffModNumber

} // namespace actor