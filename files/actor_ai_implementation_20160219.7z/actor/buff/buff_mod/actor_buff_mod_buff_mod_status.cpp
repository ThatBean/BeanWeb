#include "actor_buff_mod_buff_mod_status.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModStatus
  ActorBuffModTypedData ActorBuffModBuffModStatus::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    //Apply Count
    buff_link_data->applied_count ++;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyStatusAdd:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          const std::string& buff_status = iterator->GetString();
          buff_link_data->applied_buff_status_bit_set |= ParseBuffStatusBitSet(buff_status);  //mark
        }
        buff_link_data->applied_buff_status_bit_set = buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(buff_link_data->applied_buff_status_bit_set, kActorBuffStatusStateOperationAdd);
        buff_link_data->applied_status_state_operation_type = kActorBuffStatusStateOperationAdd;

        //check special mute(not good for speed if check in buff update)
        bool is_deactive_positive = buff_link_data->applied_buff_status_bit_set.test(kActorBuffStatusMuteAllPositive);
        bool is_deactive_negative = buff_link_data->applied_buff_status_bit_set.test(kActorBuffStatusMuteAllNegative);
        if (is_deactive_positive && is_deactive_negative)
          buff_link_data->actor_buff->DeactivateBuffByType("all");
        else if (is_deactive_positive)
          buff_link_data->actor_buff->DeactivateBuffByType("positive");
        else if (is_deactive_negative)
          buff_link_data->actor_buff->DeactivateBuffByType("negative");
      }
      break;
    case kActorBuffModKeyStatusRemove:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          const std::string& buff_status = iterator->GetString();
          buff_link_data->applied_buff_status_bit_set |= ParseBuffStatusBitSet(buff_status);  //mark
        }
        buff_link_data->applied_buff_status_bit_set = buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(buff_link_data->applied_buff_status_bit_set, kActorBuffStatusStateOperationSub);
        buff_link_data->applied_status_state_operation_type = kActorBuffStatusStateOperationSub;
      }
      break;
    case kActorBuffModKeyStatusImmuneAdd:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          const std::string& buff_status = iterator->GetString();
          buff_link_data->applied_buff_status_bit_set |= ParseBuffStatusBitSet(buff_status);  //mark
        }
        
        //flush immune first(reset status active to 0)
        buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->FlushImmuneBuffStatusBitSet(buff_link_data->applied_buff_status_bit_set);

        buff_link_data->applied_buff_status_bit_set = buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(buff_link_data->applied_buff_status_bit_set, kActorBuffStatusStateOperationImmuneAdd);
        buff_link_data->applied_status_state_operation_type = kActorBuffStatusStateOperationImmuneAdd;
      }
      break;
    case kActorBuffModKeyStatusImmuneRemove:
      {
        for (std::list<ActorBuffModTypedData>::iterator iterator = buff_mod_data->GetExecutedArgumentList().begin(); iterator != buff_mod_data->GetExecutedArgumentList().end(); iterator ++)
        {
          const std::string& buff_status = iterator->GetString();
          buff_link_data->applied_buff_status_bit_set |= ParseBuffStatusBitSet(buff_status);  //mark
        }
        buff_link_data->applied_buff_status_bit_set = buff_link_data->actor_buff->GetActor()->GetActorData()->GetBuffData()->AddBuffStatusBitSet(buff_link_data->applied_buff_status_bit_set, kActorBuffStatusStateOperationImmuneSub);
        buff_link_data->applied_status_state_operation_type = kActorBuffStatusStateOperationImmuneSub;
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModStatus][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModStatus

} // namespace actor