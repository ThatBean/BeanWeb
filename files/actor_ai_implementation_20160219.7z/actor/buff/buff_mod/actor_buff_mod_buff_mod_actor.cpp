#include "actor_buff_mod_buff_mod_actor.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModActor
  ActorBuffModTypedData ActorBuffModBuffModActor::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    //Apply Count
    buff_link_data->applied_count ++;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyActorAttributeMod:
      {
        eActorAttributeType attribute_key = ParseActorAttributeType(buff_mod_data->GetExecutedArgument(0).GetString());
        float number_add = buff_mod_data->GetExecutedArgument(1).GetNumber();
        float number_multiplier = buff_mod_data->GetExecutedArgumentList().size() >= 3 ? buff_mod_data->GetExecutedArgument(2).GetNumber() : 0;
        float number_extra = buff_mod_data->GetExecutedArgumentList().size() >= 4 ? buff_mod_data->GetExecutedArgument(3).GetNumber() : 0;

        ActorAttributeData* attribute_data = buff_link_data->actor_buff->GetActor()->GetActorData()->GetActorAttributeData(attribute_key);

        // TODO: use value directly or use delta change?

        //record value change for recover
        float delta_attribute_add = attribute_data->GetAdd();
        float delta_attribute_multiplier = attribute_data->GetMultiplier();
        float delta_attribute_extra = attribute_data->GetExtra();

        attribute_data->Add(number_add, number_multiplier, number_extra);

        delta_attribute_add -= attribute_data->GetAdd();
        delta_attribute_multiplier -= attribute_data->GetMultiplier();
        delta_attribute_extra -= attribute_data->GetExtra();

        buff_link_data->revert_attribute_add += delta_attribute_add;
        buff_link_data->revert_attribute_multiplier += delta_attribute_multiplier;
        buff_link_data->revert_attribute_extra += delta_attribute_extra;

        assert(buff_link_data->applied_attribute_type == attribute_key || buff_link_data->applied_attribute_type == kActorAttribute);

        buff_link_data->applied_attribute_type = attribute_key;
      }
      break;
    case kActorBuffModKeyActorStatusMod:
      {
        eActorStatusType status_key = ParseActorStatusType(buff_mod_data->GetExecutedArgument(0).GetString());
        int number_status = buff_mod_data->GetExecutedArgument(1).GetNumber();

        buff_link_data->actor_buff->GetActor()->GetActorData()->SetActorStatus(status_key, number_status);
      }
      break;
    case kActorBuffModKeyActorPositionMod:
      {
        //not supported yet
        assert(false);
        buff_link_data->Deactivate();
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModActor][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModActor

} // namespace actor