#ifndef ACTOR_BUFF_MOD_BUFF_MOD_STATUS_H
#define ACTOR_BUFF_MOD_BUFF_MOD_STATUS_H

#include "game/actor/buff/actor_buff_mod.h"

namespace actor {
  class ActorBuffModBuffModStatus : public ActorBuffMod
  {
  public:
    ActorBuffModBuffModStatus(eActorBuffModKeyType buff_mod_key_type)
      : ActorBuffMod(buff_mod_key_type)
    {}

    virtual ActorBuffModTypedData Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data);
    virtual eActorBuffModDataType GetBuffModDataType() { return kActorBuffModDataBuffMod; };
  };

} // namespace actor


#endif // ACTOR_BUFF_MOD_BUFF_MOD_STATUS_H