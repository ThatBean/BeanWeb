#include "actor_buff_mod_buff_mod_buff.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModBuff
  ActorBuffModTypedData ActorBuffModBuffModBuff::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    //Apply Count
    buff_link_data->applied_count ++;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyBuffAddById:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        //pick id list from ExecutedArgumentList [prevent looped executed overwrite ExecutedArgumentList]
        std::list<ActorBuffModTypedData> spliced_executed_argument_list;
        spliced_executed_argument_list.splice(
          spliced_executed_argument_list.begin(), 
          buff_mod_data->GetExecutedArgumentList(), 
          ++ buff_mod_data->GetExecutedArgumentList().begin(), //skip first argument(String)
          buff_mod_data->GetExecutedArgumentList().end());

        for (std::list<ActorBuffModTypedData>::iterator iterator = spliced_executed_argument_list.begin(); iterator != spliced_executed_argument_list.end(); iterator ++)

        {
          int buff_id = iterator->GetNumber();
          actor->GetBuff()->AddBuff(ACTOR_INVALID_ID, buff_id, buff_link_data->skill_link_data);
        }
      }
      break;
    case kActorBuffModKeyBuffRemoveById:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        //pick id list from ExecutedArgumentList [prevent looped executed overwrite ExecutedArgumentList]
        std::list<ActorBuffModTypedData> spliced_executed_argument_list;
        spliced_executed_argument_list.splice(
          spliced_executed_argument_list.begin(), 
          buff_mod_data->GetExecutedArgumentList(), 
          ++ buff_mod_data->GetExecutedArgumentList().begin(), //skip first argument(String)
          buff_mod_data->GetExecutedArgumentList().end());

        for (std::list<ActorBuffModTypedData>::iterator iterator = spliced_executed_argument_list.begin(); iterator != spliced_executed_argument_list.end(); iterator ++)

        {
          int buff_id = iterator->GetNumber();
          actor->GetBuff()->DeactivateBuffById(buff_id);
        }
      }
      break;
    case kActorBuffModKeyBuffRemoveByStatus:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        ActorBuffStatusBitSet status_bit_set;

        //pick id list from ExecutedArgumentList [prevent looped executed overwrite ExecutedArgumentList]
        std::list<ActorBuffModTypedData> spliced_executed_argument_list;
        spliced_executed_argument_list.splice(
          spliced_executed_argument_list.begin(), 
          buff_mod_data->GetExecutedArgumentList(), 
          ++ buff_mod_data->GetExecutedArgumentList().begin(), //skip first argument(String)
          buff_mod_data->GetExecutedArgumentList().end());

        for (std::list<ActorBuffModTypedData>::iterator iterator = spliced_executed_argument_list.begin(); iterator != spliced_executed_argument_list.end(); iterator ++)

        {
          const std::string& buff_status = iterator->GetString();
          status_bit_set |= ParseBuffStatusBitSet(buff_status);
        }

        if (status_bit_set.any()) actor->GetBuff()->DeactivateBuffByStatus(status_bit_set);
      }
      break;
    case kActorBuffModKeyBuffRemoveByKeyword:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        //pick id list from ExecutedArgumentList [prevent looped executed overwrite ExecutedArgumentList]
        std::list<ActorBuffModTypedData> spliced_executed_argument_list;
        spliced_executed_argument_list.splice(
          spliced_executed_argument_list.begin(), 
          buff_mod_data->GetExecutedArgumentList(), 
          ++ buff_mod_data->GetExecutedArgumentList().begin(), //skip first argument(String)
          buff_mod_data->GetExecutedArgumentList().end());

        for (std::list<ActorBuffModTypedData>::iterator iterator = spliced_executed_argument_list.begin(); iterator != spliced_executed_argument_list.end(); iterator ++)

        {
          const std::string& buff_keyword = iterator->GetString();
          actor->GetBuff()->DeactivateBuffByKeyword(buff_keyword);
        }
      }
      break;
    case kActorBuffModKeyBuffRemoveByType:
      {
        // TODO: not supported
        assert(false);
        buff_link_data->Deactivate();
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModBuff][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModBuff

} // namespace actor