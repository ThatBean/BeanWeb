#include "actor_buff_mod_buff_mod_damage.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"
#include "game/actor/actor_ext/actor_ext_damage.h"

#include "game/game_manager/data_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModDamage
  ActorBuffModTypedData ActorBuffModBuffModDamage::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    //Apply Count
    buff_link_data->applied_count ++;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyDamageMod:
      {
        if (buff_link_data->buff_event_data.data_type != kActorEventDataDamagePackage)
        {
          buff_link_data->Deactivate();
          break;
        }

        const std::string& damage_data_type_string = buff_mod_data->GetExecutedArgument(0).GetString();
        float mod_value = buff_mod_data->GetExecutedArgument(1).GetNumber();

        bool is_heal = false;
        DamageAttributeData* damage_attribute_data = NULL;

        if (damage_data_type_string == "damage_health_total")
        {
          damage_attribute_data = buff_link_data->buff_event_data.data_value.damage_package->GetAttributeData(kActorDamageAttributeHealth);
        }
        else if (damage_data_type_string == "damage_physical")
        {
          damage_attribute_data = buff_link_data->buff_event_data.data_value.damage_package->GetAttributeData(kActorDamageAttributePhysical);
        }
        else if (damage_data_type_string == "damage_magical")
        {
          damage_attribute_data = buff_link_data->buff_event_data.data_value.damage_package->GetAttributeData(kActorDamageAttributeMagical);
        }
        else if (damage_data_type_string == "heal_health_total")
        {
          damage_attribute_data = buff_link_data->buff_event_data.data_value.damage_package->GetAttributeData(kActorDamageAttributeHealth);
          is_heal = true;
        }
        else if (damage_data_type_string == "heal_physical")
        {
          damage_attribute_data = buff_link_data->buff_event_data.data_value.damage_package->GetAttributeData(kActorDamageAttributePhysical);
          is_heal = true;
        }
        else if (damage_data_type_string == "heal_magical")
        {
          damage_attribute_data = buff_link_data->buff_event_data.data_value.damage_package->GetAttributeData(kActorDamageAttributeMagical);
          is_heal = true;
        }
        else
        {
          assert(false);
          buff_link_data->Deactivate();
          break;
        }

        if (damage_attribute_data)
        {
          mod_value = MAX(-1.0f * damage_attribute_data->GetBase(), mod_value); //Base + mod_value >= 0 , prevent damage - heal conversion

          //damage (result should >= 0)
          //heal (result should <= 0)
          if (is_heal) mod_value *= -1.0f; //Base + mod_value <= 0 

          damage_attribute_data->Add(mod_value, 0, 0);
        }
      }
      break;
    case kActorBuffModKeyDamageAddByValue:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }


        bool is_damage = true;
        const std::string& damage_type_string = buff_mod_data->GetExecutedArgument(1).GetString(); //damage/heal
        if (damage_type_string == "damage")
        {
          is_damage = true;
        }
        else if (damage_type_string == "heal")
        {
          is_damage = false;
        }
        else
        {
          assert(damage_type_string == "damage"
            || damage_type_string == "heal");
          buff_link_data->Deactivate();
          break;
        }

        eActorDamageAttributeType damage_attribute_type = kActorDamageAttribute;
        const std::string& damage_attribute_type_string = buff_mod_data->GetExecutedArgument(2).GetString(); //health/energy
        if (damage_attribute_type_string == "health")
        {
          damage_attribute_type = kActorDamageAttributeHealth;
        }
        else if (damage_attribute_type_string == "energy")
        {
          damage_attribute_type = kActorDamageAttributeEnergy;
        }
        else
        {
          assert(damage_attribute_type_string == "health"
            || damage_attribute_type_string == "energy");
          buff_link_data->Deactivate();
          break;
        }


        float damage_value = buff_mod_data->GetExecutedArgument(3).GetNumber();
        if (is_damage == false)
          damage_value *= -1;


        //create damage package
        actor::DamagePackage* damage_package = actor->GetActorExtEnv()->GetActorExtDamage()->QuickInitDamage(
          buff_link_data->skill_link_data.actor_id, 
          actor->GetScriptObjectId());
        damage_package->SetAttribute(damage_attribute_type, damage_value);
        damage_package->SetIsActive(true);
        actor->GetActorExtEnv()->GetActorExtDamage()->AddDamagePackage(damage_package);
      }
      break;
    case kActorBuffModKeyDamageAddByPercent:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }


        bool is_damage = true;
        const std::string& damage_type_string = buff_mod_data->GetExecutedArgument(1).GetString(); //damage/heal
        if (damage_type_string == "damage")
        {
          is_damage = true;
        }
        else if (damage_type_string == "heal")
        {
          is_damage = false;
        }
        else
        {
          assert(damage_type_string == "damage"
            || damage_type_string == "heal");
          buff_link_data->Deactivate();
          break;
        }

        eActorDamageAttributeType damage_attribute_type = kActorDamageAttribute;
        const std::string& damage_attribute_type_string = buff_mod_data->GetExecutedArgument(2).GetString(); //health/energy
        if (damage_attribute_type_string == "health")
        {
          damage_attribute_type = kActorDamageAttributeHealth;
        }
        else if (damage_attribute_type_string == "energy")
        {
          damage_attribute_type = kActorDamageAttributeEnergy;
        }
        else
        {
          assert(damage_attribute_type_string == "health"
            || damage_attribute_type_string == "energy");
          buff_link_data->Deactivate();
          break;
        }

        float percent_attribute_value = 0.0f;
        const std::string& damage_percent_type_string = buff_mod_data->GetExecutedArgument(3).GetString(); //health/energy
        if (damage_percent_type_string == "current")
        {
          if (damage_attribute_type == kActorDamageAttributeHealth)
            percent_attribute_value = actor->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent);
          else
            percent_attribute_value = actor->GetActorData()->GetActorAttribute(kActorAttributeEnergyCurrent);
        }
        else if (damage_percent_type_string == "max")
        {
          if (damage_attribute_type == kActorDamageAttributeHealth)
            percent_attribute_value = actor->GetActorData()->GetActorAttribute(kActorAttributeHealthMax);
          else
            percent_attribute_value = actor->GetActorData()->GetActorAttribute(kActorAttributeEnergyMax);
        }
        else
        {
          assert(damage_percent_type_string == "current"
            || damage_percent_type_string == "max");
          buff_link_data->Deactivate();
          break;
        }

        float damage_percent = buff_mod_data->GetExecutedArgument(4).GetNumber();
        if (is_damage == false)
          damage_percent *= -1;


        //create damage package
        actor::DamagePackage* damage_package = actor->GetActorExtEnv()->GetActorExtDamage()->QuickInitDamage(
          buff_link_data->skill_link_data.actor_id, 
          actor->GetScriptObjectId());
        damage_package->SetAttribute(damage_attribute_type, percent_attribute_value * damage_percent);
        damage_package->SetIsActive(true);
        actor->GetActorExtEnv()->GetActorExtDamage()->AddDamagePackage(damage_package);
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModDamage][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModDamage

} // namespace actor