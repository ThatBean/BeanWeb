#include "actor_buff_mod_buff_mod_emit.h"

#include "game/actor/actor.h"
#include "game/actor/buff/actor_buff.h"
#include "game/actor/actor_ext/actor_ext_effect.h"

#include "game/game_manager/data_manager.h"

#include "engine/base/utils_string.h"


namespace actor {

  //ActorBuffModBuffModEmit
  ActorBuffModTypedData ActorBuffModBuffModEmit::Execute(ActorBuffLinkData* buff_link_data, ActorBuffModData* buff_mod_data)
  {
    //Apply Count
    buff_link_data->applied_count ++;

    switch (buff_mod_key_type_)
    {
    case kActorBuffModKeyEmitEffectTimeline:
      {
        Actor* actor = QuickGetSelectedActor(buff_link_data, buff_mod_data->GetExecutedArgument(0).GetString());
        if (!actor)
        {
          buff_link_data->Deactivate();
          break;
        }

        //pick id list from ExecutedArgumentList [prevent looped executed overwrite ExecutedArgumentList]
        std::list<ActorBuffModTypedData> spliced_executed_argument_list;
        spliced_executed_argument_list.splice(
          spliced_executed_argument_list.begin(), 
          buff_mod_data->GetExecutedArgumentList(), 
          ++ buff_mod_data->GetExecutedArgumentList().begin(), //skip first argument(String)
          buff_mod_data->GetExecutedArgumentList().end());

        for (std::list<ActorBuffModTypedData>::iterator iterator = spliced_executed_argument_list.begin(); iterator != spliced_executed_argument_list.end(); iterator ++)
        {
          int effect_timeline_id = iterator->GetNumber();
          actor->GetActorExtEnv()->GetActorExtEffect()->CreateEffectTimeline(ACTOR_INVALID_ID, effect_timeline_id, actor->GetScriptObjectId(), buff_link_data->skill_link_data);
        }
      }
      break;
    default:
      CCLog("[ActorBuffModBuffModEmit][Execute] error buff_mod_key_type_ %d", buff_mod_key_type_);
      assert(false);
      buff_link_data->Deactivate();
      break;
    }

    ActorBuffModTypedData result_data;
    result_data.SetBuffMod(kActorBuffModDataBuffMod, buff_mod_data);
    return result_data;
  }
  //ActorBuffModBuffModEmit

} // namespace actor