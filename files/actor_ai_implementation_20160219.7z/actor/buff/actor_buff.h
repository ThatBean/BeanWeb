#ifndef ACTOR_BUFF_H
#define ACTOR_BUFF_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/typedef/actor_link_data_typedef.h"
#include "game/actor/typedef/actor_buff_data_typedef.h"

#include "game/actor/actor_adapter.h"

#include "cocos2d.h"


class BuffConfigData;


namespace actor {

  class Actor;
  class DamagePackage;

  class ActorBuff;
  class ActorBuffModData;


  //buff needed link data
  class ActorBuffLinkData
  {
  public:
    ActorBuffLinkData();
    ~ActorBuffLinkData();

    void Clear();
    void Init();
    void StackReset(const ActorBuffLinkData& buff_link_data);
    void StackMerge(const ActorBuffLinkData& buff_link_data);
    void Update(float delta_time);

    void Deactivate();
    bool GetIsActive();
    
    void ExecutBuffMod(); //apply mod
    void ClearBuffMod();  //for some mod. maybe reverse applied data

    void OnCreate();
    void OnEvent(eActorEventType event_type, int linked_value, ActorEventData* event_data);

  private:
    void CreateEffectAnimation();
    void AdvanceEffectAnimation();
    void AdvanceAndRemoveEffectAnimation();
    void RemoveEffectAnimation();

  public:
    int     buff_key;

    int     stack_count;
    int     applied_count;
    float   applied_time;

    // linked data
    int                 buff_id;       // --> Buff Data Table
    ActorBuff*          actor_buff;
    BuffConfigData*     buff_config_data;
    ActorSkillLinkData  skill_link_data;
    
    //runtime data
    ActorEventData buff_event_data;  //event related data

    eActorAttributeType applied_attribute_type;
    float revert_attribute_add;
    float revert_attribute_multiplier;
    float revert_attribute_extra;

    eActorBuffStatusStateOperationType applied_status_state_operation_type;
    ActorBuffStatusBitSet applied_buff_status_bit_set;

  private:
    bool    is_active_;

    int     limit_condition_check_data_reference_;
    bool    is_limit_condition_check_data_pass_;

    float   trigger_time_current_;
    
    int     trigger_condition_check_data_reference_;
    bool    is_trigger_condition_check_data_pass_;

    ActorBuffModData* buff_mod_data_;
    ActorBuffConfigApplyData* apply_data_;

    int     buff_animation_id_;
    int     revert_tick_count_current_;
  };



  //tag on actor, end when actor dead
  class ActorBuff
  {
  public:
    ActorBuff(Actor* actor_);
    ~ActorBuff();

    void Clear();
    void Init();
    void Update(float delta_time);

    //buff operation
    ActorBuffLinkData* AddBuff(int buff_key, int buff_id, const ActorSkillLinkData& skill_link_data);

    //multi-deactivate
    void DeactivateBuffByKeyword(const std::string& buff_keyword);
    void DeactivateBuffById(int buff_id);
    void DeactivateBuffByStatus(const ActorBuffStatusBitSet& buff_status_bit_set);
    void DeactivateBuffByType(const std::string& buff_type);

    Actor* GetActor() { return actor_; }

    void OnEvent(int signal_type, int linked_value, ActorEventData* event_data);

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  protected:
    void RemoveBuff(int buff_key);

  private:
    Actor* actor_;

    std::map<int, ActorBuffLinkData*> buff_link_data_map_; //buff_key - ActorBuffLinkData
  };

} // namespace actor


#endif // ACTOR_BUFF_H