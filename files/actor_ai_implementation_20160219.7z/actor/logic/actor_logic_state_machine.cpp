#include "actor_logic_state_machine.h"

#include "game/actor/actor.h"

namespace actor {

  void LogicStateMachine::Update(float delta_time)
  { 
    if (current_state_) 
      current_state_->Update(entity_, delta_time); 
  }

  void LogicStateMachine::ChangeState(State<Actor>* next_state)
  {
    Actor* actor = entity_;

    actor->GetActorData()->GetLog()->AddLogF("[LogicStateMachine][ChangeState] %d -> %d", 
      current_state_ ? current_state_->GetStateType() : kActorLogicStateInvalid, 
      next_state ? next_state->GetStateType() : kActorLogicStateInvalid);

    last_state_ = current_state_;
    if (last_state_) 
    {
      last_state_->OnExit(entity_);
      actor->GetActorData()->SetActorStatus(kActorStatusLogicState, kActorLogicStateInvalid);
    }

    current_state_ = next_state;

    if (current_state_) 
    {
      actor->GetActorData()->SetActorStatus(kActorStatusLogicState, current_state_->GetStateType());
      current_state_->OnEnter(entity_);
    }
  }

} // namespace actor