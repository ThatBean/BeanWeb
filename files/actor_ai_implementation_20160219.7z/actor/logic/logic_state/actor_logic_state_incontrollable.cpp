#include "actor_logic_state_incontrollable.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

#include "engine/geometry/geometry_const.h"

namespace actor {

  const int LogicStateIncontrollable::STATE_TYPE = kActorLogicStateIncontrollable;

  LogicStateIncontrollable* LogicStateIncontrollable::Instance()
  {
    static LogicStateIncontrollable instance;
    return &instance;
  }

  void LogicStateIncontrollable::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[LogicStateIncontrollable][OnEnter]");

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIncontrollable));
  }

  void LogicStateIncontrollable::OnExit(Actor* actor)
  {

    actor->GetActorData()->GetLog()->AddLog("[LogicStateIncontrollable][OnExit]");
  }

  void LogicStateIncontrollable::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->GetLog()->AddLog("[LogicStateIncontrollable][Update]");

    if (actor->GetActorData()->GetActorStatusBool(kActorStatusBuffIsIncontrollable) == false)
    {
      //clear all operation
      actor->GetActorData()->GetControlData()->Reset();
      return;
    }


    //Wait for Buff system and Motion System to finish
    if (actor->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) == false)
    {
      //random new move position
      if (actor->GetActorData()->GetActorStatusBool(kActorStatusIsMuteMove) == false
        && actor->GetActorData()->GetActorStatusBool(kActorStatusBuffIsMuteMove) == false
        && actor->GetActorData()->GetActorStatusBool(kActorStatusBuffIsAutoMove) == true)
      {
        cocos2d::CCPoint auto_move_position = cocos2d::CCPoint::forAngle(rand() * 2.0 * PI / RAND_MAX);
        auto_move_position = auto_move_position * (GetGridBoxAverageWidth() * (0.25 + rand() * 0.50 / RAND_MAX));
        auto_move_position = auto_move_position + actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

        actor->GetActorData()->GetControlData()->AddPositionOperation(kActorControlOperationPositionMove, kActorControlPriorityMoveManual, auto_move_position);

        actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateMove));
      }
    }
  }

} // namespace actor