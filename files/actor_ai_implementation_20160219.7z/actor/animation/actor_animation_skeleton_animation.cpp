#include "actor_animation_skeleton_animation.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/base/utils_string.h"

namespace actor {

  //ActorAnimationSkeletonAnimation
  ActorAnimationSkeletonAnimation::ActorAnimationSkeletonAnimation(Actor* actor)
    :actor_(actor),
    skeleton_animation_node_(NULL)
  {

  }

  ActorAnimationSkeletonAnimation::~ActorAnimationSkeletonAnimation()
  {
    Clear();
  }

  void ActorAnimationSkeletonAnimation::Clear()
  {
    if (skeleton_animation_node_) 
    {
      skeleton_animation_node_->ClearAnimation();
      skeleton_animation_node_->removeFromParentAndCleanup(true);
      CC_SAFE_RELEASE_NULL(skeleton_animation_node_);
    }

    //clean up
    skeleton_animation_node_ = NULL;
  }


  void ActorAnimationSkeletonAnimation::Init(std::string armature_name, float animation_scale)
  {
    //std::string string_card_id = Int2String(card_id);

    //link and initialize SkeletonAnimationNode
    skeleton_animation_node_ = new taomee::SkeletonAnimation();
    skeleton_animation_node_->Init(armature_name.c_str(), armature_name.c_str());
    //skeleton_animation_node_->set_tag(actor_->GetScriptObjectId());
    //skeleton_animation_node_->GetArmatureNode()->setUserObject(cocos2d::CCString::create(string_card_id));
    //skeleton_animation_node_->GetArmatureNode()->setTag(card_id);
    skeleton_animation_node_->SetAnimationScale(animation_scale);
    skeleton_animation_node_->HideBone(taomee::kBoneTypeHealthBar);
    skeleton_animation_node_->HideBone(taomee::kBoneTypeProjectile);
    skeleton_animation_node_->AddShadow();
    
    //calculate box and center point offset
    cocos2d::CCPoint skeleton_animation_position = skeleton_animation_node_->getPosition();
    cocos2d::CCRect skeleton_animation_bounding_box = CCRectApplyAffineTransform(
      CCRectApplyAffineTransform(
        skeleton_animation_node_->GetArmatureNode()->boundingBox(), 
        skeleton_animation_node_->GetArmatureNode()->nodeToParentTransform()), 
      skeleton_animation_node_->nodeToParentTransform());

    skeleton_animation_box_size_.setSize(
      int(MAX(skeleton_animation_bounding_box.size.width, GetGridBoxAverageWidth()) 
        / GetGridBoxAverageWidth()) * GetGridBoxAverageWidth(),
      int(MAX(skeleton_animation_bounding_box.size.height, GetGridBoxAverageHeight()) 
        / GetGridBoxAverageHeight()) * GetGridBoxAverageHeight());

    //not centered
//     skeleton_animation_box_origin_offset_ = ccp(
//       skeleton_animation_bounding_box.origin.x - skeleton_animation_position.x, 
//       skeleton_animation_bounding_box.origin.y - skeleton_animation_position.y);

    //centered
    skeleton_animation_box_origin_offset_ = ccp(skeleton_animation_box_size_.width * -0.5, 0);
  }



  void ActorAnimationSkeletonAnimation::Update(float delta_time)
  {
    //pause
    bool is_status_pause = actor_->GetActorData()->GetActorStatusBool(kActorStatusAnimationIsPaused);
    bool is_animation_pause = (skeleton_animation_node_->state() == taomee::SkeletonAnimation::kStatePaused);

    if (is_status_pause != is_animation_pause)
    {
      if (is_status_pause) skeleton_animation_node_->Pause();
      else skeleton_animation_node_->Resume();
      actor_->GetActorData()->GetLog()->AddLogF("[ActorAnimationSkeletonAnimation][Update] is pause: %s", is_status_pause ? "true" : "false");
    }

    //always

    //active only
    if (is_status_pause == false)
    {
      //direction
      eActorAnimationDirection status_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorStatusAnimationDirection);
      eActorAnimationDirection animation_direction = (skeleton_animation_node_->GetDirection() == taomee::kDirectionLeft ? kActorAnimationDirectionLeft : kActorAnimationDirectionRight);

      if (status_direction != animation_direction)
      {
        skeleton_animation_node_->ChangeDirection(status_direction == kActorAnimationDirectionLeft ? taomee::kDirectionLeft : taomee::kDirectionRight);
        actor_->GetActorData()->GetLog()->AddLogF("[ActorAnimationSkeletonAnimation][Update] change direction: %s", status_direction == kActorAnimationDirectionLeft ? "left" : "right");
      }

      //weak animation
      if (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)  //only character has weak animation
      {
        bool is_weak_status = actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) 
          < actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax) * ACTOR_WEAK_THRESHOLD;

        switch (actor_->GetActorData()->GetActorStatus(kActorStatusMotionState))
        {
        case kActorMotionStateIdle:
          {
            if (is_weak_status) ChangeMovement(kActorAnimationMovementIdleWeak);
            else ChangeMovement(kActorAnimationMovementIdle);
          }
          break;
        case kActorMotionStateMove:
          {
            if (is_weak_status) ChangeMovement(kActorAnimationMovementWalkWeak);
            else ChangeMovement(kActorAnimationMovementWalk);
          }
          break;
        }
      }
    }
  }


  bool ActorAnimationSkeletonAnimation::ChangeMovement(const std::string& movement_name, const int cycle_count/* = -1 */, const float speed/* = 1.0f */)
  {
    //check first
    if (movement_name == "" || skeleton_animation_node_->existedAnimationName(movement_name) == false)
    {
      actor_->GetActorData()->GetLog()->AddErrorLogF("[Error][ActorAnimationSkeletonAnimation][ChangeSkeletonAnimation] failed to change to <%s>", movement_name.c_str());

      cocos2d::CCLog(">  valid movement_name name:");
      std::vector<std::string> &animation_name_vector = skeleton_animation_node_->GetArmatureNode()->getAnimation()->getAnimationData()->movementNames;
      for (std::vector<std::string>::iterator iterator = animation_name_vector.begin(); iterator != animation_name_vector.end(); iterator ++)
      {
        cocos2d::CCLog(">  -- <%s>", iterator->c_str());
      }

      cocos2d::CCLog("State: Logic: %d, \tMotion: %d, \tMotionIsBusy: %s, \tSkillIsBusy: %s", 
        actor_->GetActorData()->GetActorStatus(kActorStatusLogicState), 
        actor_->GetActorData()->GetActorStatus(kActorStatusMotionState),
        actor_->GetActorData()->GetActorStatusBool(kActorStatusMotionIsBusy) ? "true" : "false",
        actor_->GetActorData()->GetActorStatusBool(kActorStatusSkillIsBusy) ? "true" : "false");
      
      //assert(false);
      return false;
    }

    //filter again
    std::string current_animation_name = skeleton_animation_node_->GetArmatureNode()->getAnimation()->getCurrentMovementID();
    if (cycle_count != -1 //change play time
      || current_animation_name != movement_name) //change animation
    {
      skeleton_animation_node_->Stop();
      skeleton_animation_node_->Play(movement_name, cycle_count, speed);
    }
    return true;
  }


  cocos2d::CCRect ActorAnimationSkeletonAnimation::GetSkeletonAnimationBox()
  {
    cocos2d::CCPoint skeleton_animation_position = skeleton_animation_node_->getPosition();

    return cocos2d::CCRect(
      skeleton_animation_box_origin_offset_.x + skeleton_animation_position.x, 
      skeleton_animation_box_origin_offset_.y + skeleton_animation_position.y, 
      skeleton_animation_box_size_.width, skeleton_animation_box_size_.height);
  }
} // namespace actor