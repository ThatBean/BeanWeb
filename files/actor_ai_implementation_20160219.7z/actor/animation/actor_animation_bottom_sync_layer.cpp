#include "actor_animation_bottom_sync_layer.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger_predefined.h"

#include "game/battle/battle_controller.h"
#include "game/battle/view/battle_view.h"

namespace actor {

  //ActorAnimationBottomSyncLayer
  ActorAnimationBottomSyncLayer::ActorAnimationBottomSyncLayer(Actor* actor)
    :actor_(actor),
    bottom_layer_sync_node_(NULL),
    guard_area_layer_(NULL),
    guard_area_left_time_(0)
  {
    //
  }

  ActorAnimationBottomSyncLayer::~ActorAnimationBottomSyncLayer()
  {
    Clear();
  }

  void ActorAnimationBottomSyncLayer::Clear()
  {
    bottom_layer_sync_node_->removeFromParentAndCleanup(true);
    bottom_layer_sync_node_ = NULL;
    guard_area_layer_ = NULL;
    guard_area_left_time_ = 0;
  }

  void ActorAnimationBottomSyncLayer::Init()
  {
    //create a node under all actor at BattleView - BottomLayerSyncNode
    bottom_layer_sync_node_ = cocos2d::CCNode::create();
    bottom_layer_sync_node_->setTag(actor_->GetScriptObjectId());
    taomee::battle::BattleController::GetInstance().AddNodeByLayerType(bottom_layer_sync_node_, taomee::battle::kBattleLayerBottom);
  }




  void ActorAnimationBottomSyncLayer::Update(float delta_time)
  { 
    //update tagged node position
    bottom_layer_sync_node_->setPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));

    //update guard_area
    if (guard_area_layer_)
    {
      if (guard_area_left_time_ > 0)
      {
        guard_area_left_time_ -= delta_time;
      }
      else 
      {
        RemoveGuardArea();
      }
    }
  }


  cocos2d::CCLayer* ActorAnimationBottomSyncLayer::CreateGuardArea(bool is_circle_area)
  {
    cocos2d::CCLayer* guard_area_layer = new cocos2d::CCLayer;
    guard_area_layer->autorelease();

    float actor_radius_x = actor_->GetAnimation()->GetActorBox().size.width * 0.5;
    float actor_radius_y = actor_->GetAnimation()->GetActorBox().size.height * 0.5;


    if (is_circle_area)
    {
      CCSprite* sprite = CCSprite::createWithSpriteFrameName(ACTOR_GUARD_AREA_TEXTURE_NAME_CIRCLE.c_str());
      sprite->setAnchorPoint(ccp(0.5f, 0.5f));

      int tile_radius = actor_->GetActorData()->GetActorAttribute(kActorAttributeGuardAreaRadius);
      tile_radius = tile_radius > 0 ? tile_radius : actor_radius_x;
      float texture_width = sprite->getContentSize().width;
      float scale = 2 * tile_radius / texture_width;
      sprite->setScaleX(scale);
      sprite->setScaleY(scale * actor_radius_y / actor_radius_x);

      guard_area_layer->addChild(sprite);
    }
    else
    {
      CCScale9Sprite* sprite = CCScale9Sprite::createWithSpriteFrameName(ACTOR_GUARD_AREA_TEXTURE_NAME_BOX.c_str());
      sprite->setInsetBottom(40);
      sprite->setInsetLeft(40);
      sprite->setInsetRight(40);
      sprite->setInsetTop(40);

      int tile_width = actor_->GetActorData()->GetActorAttribute(kActorAttributeGuardAreaWidth);
      int tile_height = actor_->GetActorData()->GetActorAttribute(kActorAttributeGuardAreaHeight) * 0.5;
      float width = tile_width;
      float height = MAX(tile_height, GetGridBoxAverageHeight() * 0.8);
      sprite->setPreferredSize(CCSizeMake(width, height));
      
      if (actor_->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionLeft)
        sprite->setAnchorPoint(ccp(1.0f, 0.5f));
      else
        sprite->setAnchorPoint(ccp(0.0f, 0.5f));
      guard_area_layer->addChild(sprite);
    }

    return guard_area_layer;
  }


  void ActorAnimationBottomSyncLayer::StartGuardArea(float last_time)
  {
    guard_area_left_time_ = last_time;
    if (!guard_area_layer_ && bottom_layer_sync_node_)
    {
      bool is_circle_area;
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusGuardAreaType))
      {
      case kActorPredefinedGuardTriggerCircle:
        is_circle_area = true;
        break;
      case kActorPredefinedGuardTriggerRect:
        is_circle_area = false;
        break;
      default:
        //assert(false);
        return;
        break;
      }

      guard_area_layer_ = CreateGuardArea(is_circle_area);
      bottom_layer_sync_node_->addChild(guard_area_layer_);
    }
  }

  void ActorAnimationBottomSyncLayer::RemoveGuardArea()
  {
    if (guard_area_layer_)
    {
      guard_area_layer_->runAction(CCSequence::create(CCDelayTime::create(0.5f), CCRemoveSelf::create(), NULL));
      guard_area_layer_ = NULL;
    }
  }
} // namespace actor