#include "actor_animation_overhead_layer.h"

#include "game/actor/actor.h"
#include "game/actor/typedef/actor_animation_data_typedef.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/buff_status_animation_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"

namespace actor {

  class ActorBuffStatusIcon
  {
  public:
    ActorBuffStatusIcon()
    {
      //cocos2d::CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("ui/agoui_battle_buff_status_icon/agoui_battle_buff_status_icon_ex.plist");

      root_widget = UIFactory::createWidgetFromFile("ui/agoui_battle_actor_buff_status_icon.json");
      status_icon_widget = dynamic_cast<cocos2d::extension::UIImageView*>(root_widget->getChildByName("ImageView_Icon"));
      status_count_widget = dynamic_cast<cocos2d::extension::UILabelBMFont*>(root_widget->getChildByName("LabelBMFont_Count"));
    }

    ~ActorBuffStatusIcon()
    {
      root_widget->removeFromParentAndCleanup(true);
    }

    void UpdateDisplay(int buff_status_animation_id, int status_count)
    {
      BuffStatusAnimationData* status_animation_data = DataManager::GetInstance().GetBuffStatusAnimationDataTable()->GetBuffStatusAnimation(buff_status_animation_id);

      status_icon_widget->loadTexture(status_animation_data->GetStatusIconName().c_str(), cocos2d::extension::UI_TEX_TYPE_PLIST);
      status_icon_widget->setSize(cocos2d::CCSize(50, 50));

      std::ostringstream string_stream;
      string_stream << status_count;
      //status_count_widget->setFntFile("ui/font/font_2.fnt");
      status_count_widget->setText(string_stream.str().c_str());
    }


    void UpdatePosition(const cocos2d::CCPoint& position)
    {
      root_widget->setPosition(position);
    }

  public:
    cocos2d::extension::UIWidget* root_widget;
    cocos2d::extension::UIImageView* status_icon_widget;
    cocos2d::extension::UILabelBMFont* status_count_widget;
  };







  //ActorAnimationOverheadLayer
  ActorAnimationOverheadLayer::ActorAnimationOverheadLayer(Actor* actor)
    : actor_(actor)
    , overhead_layer_(NULL)
    , health_bar_layer_(NULL)
    , health_bar_widget_(NULL)
    , health_bar_bg_widget_(NULL)
    , health_bar_left_time_(0)
    , buff_status_icon_panel_(NULL)
  {

  }

  ActorAnimationOverheadLayer::~ActorAnimationOverheadLayer()
  {
    Clear();
  }

  void ActorAnimationOverheadLayer::Clear()
  {
    //overhead_layer_ will be cleared with skeleton_animation_node_
    if (health_bar_widget_) health_bar_widget_->release();
    if (health_bar_bg_widget_) health_bar_bg_widget_->release();

    overhead_layer_ = NULL;
    health_bar_widget_ = NULL;
    health_bar_bg_widget_ = NULL;

    health_bar_left_time_ = 0;

    buff_status_icon_panel_ = NULL;
  }

  void ActorAnimationOverheadLayer::Init()
  {
    //create UILayer for health bar update
    overhead_layer_ = cocos2d::extension::UILayer::create();
    

    health_bar_layer_ = UIFactory::createWidgetFromFile("ui/agoui_battle_actor_health_bar.json");
    health_bar_layer_->setScale(1.2);
    overhead_layer_->addWidget(health_bar_layer_);


    ActorBuffStatusBitSet status_bit_set = actor_->GetActorData()->GetBuffData()->GetBuffStatusBitSet();
    cocos2d::extension::UIImageView* icon_widget = dynamic_cast<cocos2d::extension::UIImageView*>(health_bar_layer_->getChildByName("ImageView_Icon"));
    if (status_bit_set.test(kActorBuffStatusElementFire)) icon_widget->loadTexture("agoui_element_1.png", cocos2d::extension::UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementWater)) icon_widget->loadTexture("agoui_element_2.png", cocos2d::extension::UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementWind)) icon_widget->loadTexture("agoui_element_3.png", cocos2d::extension::UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementLight)) icon_widget->loadTexture("agoui_element_4.png", cocos2d::extension::UI_TEX_TYPE_PLIST);
    else if (status_bit_set.test(kActorBuffStatusElementDark)) icon_widget->loadTexture("agoui_element_5.png", cocos2d::extension::UI_TEX_TYPE_PLIST);
    else icon_widget->loadTexture("agoui_element_0.png", cocos2d::extension::UI_TEX_TYPE_PLIST);

    health_bar_widget_ = dynamic_cast<cocos2d::extension::UILoadingBar*>(health_bar_layer_->getChildByName("LoadingBar_Fg"));
    health_bar_widget_->setPercent(100);
    health_bar_widget_->retain();

    cocos2d::ccColor3B color_health_bar_character_user = ccc3(60, 240, 70);
    cocos2d::ccColor3B color_health_bar_character_yellow = ccc3(255, 200, 0);
    cocos2d::ccColor3B color_health_bar_monster_red = ccc3(200, 0, 0);
    cocos2d::ccColor3B color_health_bar_monster_boss_red = ccc3(255, 0, 0);
    if (actor_->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport)
    {
      health_bar_widget_->setColor(color_health_bar_character_user);
    }
    else
    {
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance))
      {
      case kActorAppearanceCharacter:
        health_bar_widget_->setColor(color_health_bar_character_yellow);
        break;
      case kActorAppearanceEnemyPawn:
        health_bar_widget_->setColor(color_health_bar_monster_red);
        break;
      case kActorAppearanceEnemyBoss:
        health_bar_widget_->setColor(color_health_bar_monster_boss_red);
        break;
      }
    }

    health_bar_bg_widget_ = dynamic_cast<cocos2d::extension::UILoadingBar*>(health_bar_layer_->getChildByName("LoadingBar_Bg"));
    health_bar_bg_widget_->setIsHaveAni(true);
    health_bar_bg_widget_->setPercent(100);
    health_bar_bg_widget_->retain();

    cocos2d::ccColor3B color_health_bar_bg = ccc3(200, 0, 0);
    health_bar_bg_widget_->setColor(color_health_bar_bg);

    buff_status_icon_panel_ = dynamic_cast<cocos2d::extension::Layout*>(health_bar_layer_->getChildByName("Panel_Status_Icon"));
  }



  void ActorAnimationOverheadLayer::Update(float delta_time)
  {
    //always

    if (health_bar_layer_)
    {
      //health bar auto hiding
//       if (actor_->GetActorData()->GetActorStatusBool(kActorStatusAnimationIsHealthChanged))
//       {
//         actor_->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsHealthChanged, false);
//         health_bar_left_time_ = ACTOR_ANIMATION_HEALTH_DISPLAY_TIME;
//         health_bar_layer_->setVisible(true);
//       }
// 
//       if (health_bar_layer_->isVisible())
//       {
//         health_bar_left_time_ -= delta_time;
// 
//         if (health_bar_left_time_ <= 0) 
//           health_bar_layer_->setVisible(false);
//       }
    }

    //update health
    if (health_bar_widget_ && health_bar_bg_widget_)
    {
      float health_percent = 100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax);
      health_bar_widget_->setPercent(health_percent);
      health_bar_bg_widget_->setPercent(health_percent);
    }


    //update buff status
    if (buff_status_icon_panel_ && actor_->GetActorData()->GetActorStatusBool(kActorStatusAnimationIsBuffChanged))
    {
      actor_->GetActorData()->SetActorStatusBool(kActorStatusAnimationIsBuffChanged, false);

      std::map<int, int> status_display_data = actor_->GetActorData()->GetBuffData()->GetBuffStatusDisplayData();

      //first update exist icon and delete expired icon
      std::map<int, ActorBuffStatusIcon*>::iterator iterator = buff_status_icon_map_.begin();
      while (iterator != buff_status_icon_map_.end())
      {
        int buff_status_animation_id = iterator->first;
        ActorBuffStatusIcon* buff_status_icon = iterator->second;

        iterator ++;

        if (status_display_data.find(buff_status_animation_id) != status_display_data.end())
        {
          //update
          buff_status_icon->UpdateDisplay(buff_status_animation_id, status_display_data[buff_status_animation_id]);
          status_display_data.erase(buff_status_animation_id);  //remove from map
        }
        else
        {
          //remove
          delete buff_status_icon;
          buff_status_icon_map_.erase(buff_status_animation_id);
        }
      }

      //then add new icon
      for (std::map<int, int>::iterator iterator = status_display_data.begin(); iterator != status_display_data.end(); iterator ++)
      {
        int buff_status_animation_id = iterator->first;
        int status_count = iterator->second;

        ActorBuffStatusIcon* buff_status_icon = new ActorBuffStatusIcon;
        buff_status_icon->UpdateDisplay(buff_status_animation_id, status_count);
        buff_status_icon_panel_->addChild(buff_status_icon->root_widget);
        buff_status_icon_map_[buff_status_animation_id] = buff_status_icon;
      }

      //reset icon position
      float position_x = 0;
      float position_y = 0;
      for (std::map<int, ActorBuffStatusIcon*>::iterator iterator = buff_status_icon_map_.begin(); iterator != buff_status_icon_map_.end(); iterator ++)
      {
        int buff_status_animation_id = iterator->first;
        ActorBuffStatusIcon* buff_status_icon = iterator->second;

        buff_status_icon->UpdatePosition(cocos2d::CCPoint(position_x, position_y));

        position_x += 32;
      }
    }
  }

} // namespace actor