#ifndef ACTOR_CONTROL_H
#define ACTOR_CONTROL_H

#include "game/actor/logic/actor_logic_state.h"

#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  class ActorControlData;
  class ActorTrigger;

  enum eActorControlType
  {
    kActorControlManual   = 1 << 0,   //will check user input
    kActorControlAuto     = 1 << 1,   //will issue command automatically

    kActorControl = 0
  };

  class ActorControl
  {
  public:
    ActorControl(Actor* actor);
    ~ActorControl();

    void Update(float delta_time);

    void UpdateSpecialGuard(int type = 0);  // TODO: remove. //special auto for monster reaching the base line
  protected:
    void UpdateManual();
    void UpdateAuto();
    void UpdateStatus();
    void UpdateLogic();

    eActorLogicState DecideLogicState();  //check set priority
    bool ControlLogicStateChange(eActorLogicState next_logic_state_type); //check if exterior logic state change valid, if true, change

    void UpdateAutoReleaseSpecialSkill();
    
    void UpdateAutoGuard();
    void UpdateAutoGuardMelee(ActorTrigger* auto_trigger);
    void UpdateAutoGuardMeleeX(ActorTrigger* auto_trigger);
    void UpdateAutoGuardMeleeY(ActorTrigger* auto_trigger);
    void UpdateAutoGuardRangedNearestX(ActorTrigger* auto_trigger);
    void UpdateAutoGuardRangedNearestY(ActorTrigger* auto_trigger);
    void ApplyAutoRangedPosition(bool is_grid_y_valid[]);
  private:
    Actor*               actor_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_H
