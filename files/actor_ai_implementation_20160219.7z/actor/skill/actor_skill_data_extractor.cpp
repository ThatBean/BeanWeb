#include "actor_skill_data_extractor.h"

#ifdef WIN32_NOT_USING
#include "game/actor/actor.h"
#include "game/army/unit/move_object.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"
#include "game/game_manager/data_manager.h"

#include "game/passive_ability/aura.h"

#include "engine/animation/projectile_animation_cache_manager.h"
#include "engine/particle/particle_manager.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"
#include "engine/base/utils_string.h"
#include "game/data_table/skill_data_table.h"
#include "game/data_table/skill_attack_range_table.h"
#include "game/data_table/skill_brk_data_table.h"
#include "game/data_table/character_data_table.h"
#include "game/data_table/projectiles_data_table.h"

#include <fstream>


#define FIX_JSON_APPEND(json_object, append_data) (json_object)[(json_object).size()] = append_data


namespace actor {
  namespace data_extractor {

    const std::string EFFECT_TYPE_HIT = "effect_hit"; //hit effect mostly
    const std::string EFFECT_TYPE_HIT_1 = "effect_hit_1"; //hit effect mostly
    const std::string EFFECT_TYPE_HIT_2 = "effect_hit_2"; //hit effect mostly
    const std::string EFFECT_TYPE_HIT_3 = "effect_hit_3"; //hit effect mostly
    const std::string EFFECT_TYPE_START = "effect_start"; //start effect mostly
    const std::string EFFECT_TYPE_END = "effect_end"; //end effect mostly

    const std::string BUFF_TYPE_SELF = "buff_self"; //start and to self
    const std::string BUFF_TYPE_HIT_ALLY = "buff_hit_ally"; //effect trigger and to ally
    const std::string BUFF_TYPE_HIT_ENEMY = "bufff_hit_enemy"; //effect trigger and to enemy

    const std::string effect_break_position_transfer_array[] = {
      "source_actor_location",
      "source_actor_attack_anchor",
      "ErrorValue",
      "screen_center"
    };

    const std::string effect_break_animation_layer_transfer_array[] = {
      "ErrorValue",
      "bottom_layer",
      "actor_layer",
      "top_layer"
    };

    const std::string effect_break_target_filter_transfer_array[] = {
      "", //0

      "actor_faction|self", //1
      "actor_faction|ally", //2
      "actor_faction|self|ally",
      "actor_faction|enemy",  //4
      "actor_faction|self|enemy", 

      "",
      "",
      "",
      "",
      "",

      "",
      "",
      "",
      "",
      "",

      "actor_faction|ally, actor_health_lowest", //16
      "actor_faction|self|ally, actor_health_lowest"
    };

    const std::string skill_damage_type_transfer_array[] = {
      "physical",
      "magical",
      "holy",
      "explode",
      "healing"
    };


    const std::string FRAME_EVENT_TAG_HIT = "hit";
    const std::string FRAME_EVENT_TAG_POWER = "power";
    const std::string FRAME_EVENT_TAG_POWER_2 = "power2";
    const std::string FRAME_EVENT_TAG_RELEASE = "release";


    static std::list<std::string> static_error_log_list;
    void LOG_ERROR(const char* format, ...)
    {
      char temp_text[1024];
      va_list ap;
      va_start(ap, format);
      vsnprintf(temp_text, 1024, format, ap);
      va_end(ap);
      std::string temp_string = temp_text;
      CCLog(temp_string.c_str()); //print
    
      static_error_log_list.push_back(temp_string.c_str());  //record
    }


    static std::map<int, SkillBase* > static_skill_map;//stupid skill id mapping

    typedef struct sSkillMaxHitCountData {
      int card_id;
      int skill_id;
      int max_hit_count;
    } SkillMaxHitCountData;

    static std::map<int, SkillMaxHitCountData> static_skill_max_hit_count_map;//record max skill hit tag count



  

    void save_string_to_file(const std::string& string_text, const std::string& file_path);
    void save_json_to_file(const CSJson::Value& root, const std::string& file_path);


    CCAnimationData* quick_load_armature_animation_data(const std::string& animation_name);//load and return armature data, can be used to check exist
    std::string quick_load_projectile_animation_data(const std::string& animation_name);//load and return content info

    CSJson::Value extract_armature_animation_movement_frame_data(CCMovementData* movement_data);
    CSJson::Value extract_armature_animation_movement_data(std::string animation_name, std::string movement_name);
    CSJson::Value extract_armature_animation_data(std::string animation_name);

    CSJson::Value extract_projectile_animation_data(std::string animation_name);

    void collect_card_skill_armature_movement_data(CSJson::Value& root, CharacterData* card_data, SkillBase* skill_base);


    void quick_add_skill_aura_data(CSJson::Value& root, const std::string& aura_id_string, const std::string& aura_type, int aura_apply_possibility, int skill_id);


    void generate_card_skill_link(
      std::map<int, std::list<int> >& card_skill_link_map, 
      std::map<int, std::list<int> >& skill_card_link_map,
      std::map<int, SkillBase* >& skill_map);

    void generate_skill_break_link(
      std::map<int, std::list<int> >& skill_card_link_map,
      std::map<int, std::list<int> >& break_skill_link_map, 
      std::map<int, SkillBase* >& skill_map);

    void generate_skill_aura_link(
      std::map<int, std::list<int> >& skill_card_link_map,
      std::map<int, std::list<int> >& aura_skill_link_map, 
      std::map<int, SkillBase* >& skill_map);



    //ActorSkillDataExtractor
    ActorSkillDataExtractor::ActorSkillDataExtractor()
    {
      static_skill_max_hit_count_map.clear();

      //stupid skill id mapping
      static_skill_map.clear();

      vector<SkillBase*>* skill_base_array = DataManager::GetInstance().GetSkillDataTable()->getAllSkillArray();
      vector<SkillBase*>::iterator iterator_skill_base = skill_base_array->begin();
      while (iterator_skill_base != skill_base_array->end())
      {
        SkillBase* skill_base = *iterator_skill_base;
        static_skill_map[skill_base->getSkillID()] = skill_base;

        iterator_skill_base++;
      }

      //reset error log
      static_error_log_list.clear();
    }

    ActorSkillDataExtractor::~ActorSkillDataExtractor()
    {
      static_skill_max_hit_count_map.clear();
      static_skill_map.clear();

      //reset error log
      static_error_log_list.clear();
    }


    void ActorSkillDataExtractor::Extract()
    {
      //generate link
      generate_card_skill_link(
        card_skill_link_map_, 
        skill_card_link_map_,
        static_skill_map);


      ExtractCard();
      ExtractSkill();


      //generate link
      generate_skill_break_link(
        skill_card_link_map_,
        break_skill_link_map_,
        static_skill_map);


      //generate link
      generate_skill_aura_link(
        skill_card_link_map_,
        aura_skill_link_map_,
        static_skill_map);


      ExtractEffectBreak();
      ExtractEffectAura();


    }




    void ActorSkillDataExtractor::ExtractCard()
    {
      std::map<int, std::list<int> >::iterator iterator_card_skill_link = card_skill_link_map_.begin();
      while (iterator_card_skill_link != card_skill_link_map_.end())
      {
        int card_id = iterator_card_skill_link->first;
        CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);


        //animation in card data
        ExtractAnimationArmature(
          card_data->GetName(), 
          std::string("ACTOR|") + card_data->GetName() + "|" + Int2String(card_id), 
          std::string("card_id: ") + Int2String(card_id));

        //movement data from linked skill
        CSJson::Value json_card_skill_list_data(CSJson::nullValue);
        CSJson::Value json_card_skill_armature_movement_data(CSJson::objectValue);
        CSJson::Value json_card_skill_addon_armature_data(CSJson::objectValue);

        std::list<int> &skill_id_list = iterator_card_skill_link->second;
        std::list<int>::iterator iterator_skill_id = skill_id_list.begin();
        while (iterator_skill_id != skill_id_list.end())
        {
          int skill_id = *iterator_skill_id;
          SkillBase* skill_base = static_skill_map[skill_id];

          collect_card_skill_armature_movement_data(json_card_skill_armature_movement_data, card_data, skill_base);
          ExtractCardSkillAddonArmature(json_card_skill_addon_armature_data, card_id, skill_id);
        
          FIX_JSON_APPEND(json_card_skill_list_data, skill_id);

          iterator_skill_id ++;
        }


        CSJson::Value json_card_data(CSJson::objectValue);

        json_card_data["card_id"] = card_id;
        json_card_data["card_name"] = card_data->GetName();

        json_card_data["card_actor_armature_name"] = card_data->GetName();

        json_card_data["card_skill_list"] = json_card_skill_list_data;
        json_card_data["card_skill_armature_movement_data"] = json_card_skill_armature_movement_data;
        json_card_data["card_skill_addon_armature_data"] = json_card_skill_addon_armature_data;

        json_root_card_[Int2String(card_id)] = json_card_data;


        CCLog("[ExtractCard] get card_id: %d, card_skill_armature_movement_data count: %d", card_id, json_card_data["card_skill_armature_movement_data"].size());
      
        iterator_card_skill_link ++;
      }
      CCLog("[ExtractCard] get json_card_data count: %d", json_root_card_.size());
    }





    void ActorSkillDataExtractor::ExtractSkill()
    {
      std::map<int, std::list<int> >::iterator iterator_skill_card_link = skill_card_link_map_.begin();
      while (iterator_skill_card_link != skill_card_link_map_.end())
      {
        int skill_id = iterator_skill_card_link->first;
        SkillBase* skill_base = static_skill_map[skill_id];


        //animation in skill data
        //power effect, the armature played when card frame event is fired
        if (skill_base->GetPowerEffect().empty() == false)
        {
          ExtractAnimationArmature(
            skill_base->GetPowerEffect(), 
            std::string("ADDON|") + skill_base->GetPowerEffect() + "|" + Int2String(skill_id) + "|PowerEffect", 
            std::string("skill_id: ") + Int2String(skill_id) + "|PowerEffect");
        }

        if (skill_base->GetPower2Effect().empty() == false)
        {
          ExtractAnimationArmature(
            skill_base->GetPower2Effect(), 
            std::string("ADDON|") + skill_base->GetPower2Effect() + "|" + Int2String(skill_id) + "|Power2Effect", 
            std::string("skill_id: ") + Int2String(skill_id) + "|Power2Effect");
        }

        //attack_data
        CSJson::Value json_skill_attack_data(CSJson::objectValue);
        json_skill_attack_data["damage_base"] = skill_base->GetInitDamage();
        json_skill_attack_data["damage_base_add"] = skill_base->GetAddDamage();
        json_skill_attack_data["damage_base_type"] = skill_damage_type_transfer_array[skill_base->GetDamageType()];
        json_skill_attack_data["damage_transfer_rate_card_physical"] = skill_base->GetPhyAddedMul();
        json_skill_attack_data["damage_transfer_rate_card_magical"] = skill_base->GetMagAddedMul();


        //break_data
        CSJson::Value json_skill_break_data(CSJson::objectValue);
        if (skill_base->GetSelfBreakId() > 0) json_skill_break_data[Int2String(skill_base->GetSelfBreakId())] = EFFECT_TYPE_START;
        if (skill_base->GetEffBreakId() > 0) json_skill_break_data[Int2String(skill_base->GetEffBreakId())] = EFFECT_TYPE_END;


        //break in skill data
        // note the triple break caused by triple hit frame event tag
        int skill_max_hit_count = static_skill_max_hit_count_map.find(skill_id) != static_skill_max_hit_count_map.end() 
          ? static_skill_max_hit_count_map[skill_id].max_hit_count : 0;
        int hit_break_id = skill_base->GetTagBreakId(); //will be triggered by hit

        bool is_hit_event_exist = skill_max_hit_count > 0;
        bool is_hit_break_exist = hit_break_id > 0;

        //check valid
        if (is_hit_event_exist != is_hit_break_exist)
        {
          LOG_ERROR("[generate_skill_break_link] error mismatch skill_hit_event - skill_hit_break! hit_event_exist: %d, hit_break_exist: %d, skill_id: %d, hit_break_id: %d",
            is_hit_event_exist,
            is_hit_break_exist, 
            skill_id, 
            hit_break_id);
        }
        else if (is_hit_event_exist)
        {
          int current_hit_id = 1;
          while (skill_max_hit_count > 0)
          {
            json_skill_break_data[Int2String(hit_break_id + current_hit_id - 1)] = EFFECT_TYPE_HIT + "_" + Int2String(current_hit_id);

            current_hit_id ++;
            skill_max_hit_count --;
          }
        }









        //explode(most nasty) data
        if (skill_base->GetDamageSelfPercent() > 0 || skill_base->GetDamgeEnemyPercent() > 0)
        {
          json_skill_break_data["explode"]["damage_health_percent_self"] = skill_base->GetDamageSelfPercent();
          json_skill_break_data["explode"]["damage_health_percent_target"] = skill_base->GetDamgeEnemyPercent();
        }


        //aura data
        CSJson::Value json_skill_aura_data(CSJson::objectValue);
        quick_add_skill_aura_data(json_skill_aura_data, skill_base->GetTagPlayerStatus(), BUFF_TYPE_HIT_ALLY, skill_base->GetTagPlayerStatusRatio(), skill_id);
        quick_add_skill_aura_data(json_skill_aura_data, skill_base->GetSelfStatus(), BUFF_TYPE_SELF, skill_base->GetSelfStatusRatio(), skill_id);
        quick_add_skill_aura_data(json_skill_aura_data, skill_base->GetTagStatus(), BUFF_TYPE_HIT_ENEMY, skill_base->GetTagStatusRatio(), skill_id);
      

        //back link to linked card
        CSJson::Value json_skill_card_list_data(CSJson::nullValue);

        std::list<int> &card_id_list = iterator_skill_card_link->second;
        std::list<int>::iterator iterator_card_id = card_id_list.begin();
        while (iterator_card_id != card_id_list.end())
        {
          int card_id = *iterator_card_id;
          CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);


          FIX_JSON_APPEND(json_skill_card_list_data, card_id);

          iterator_card_id ++;
        }


        CSJson::Value json_skill_data(CSJson::objectValue);

        json_skill_data["skill_id"] = skill_id;
        json_skill_data["actor_movement"] = skill_base->GetMotion();
        json_skill_data["actor_movement_loop_count"] = int(skill_base->GetMotionCount());
        json_skill_data["actor_movement_speed_scale"] = skill_base->GetMotionSpeedRate();
      
        json_skill_data["skill_card_list"] = json_skill_card_list_data;
        json_skill_data["skill_attack_data"] = json_skill_attack_data;
        json_skill_data["skill_break_data"] = json_skill_break_data;
        json_skill_data["skill_aura_data"] = json_skill_aura_data;

        json_root_skill_[Int2String(skill_id)] = json_skill_data;

        CCLog("[ExtractSkill] get skill_id: %d", skill_id);

        iterator_skill_card_link ++;
      }
      CCLog("[ExtractSkill] get json_skill_data count: %d", json_root_skill_.size());
    }




    void ActorSkillDataExtractor::ExtractEffectBreak()
    {
      std::map<int, std::list<int> >::iterator iterator_break_skill_link = break_skill_link_map_.begin();
      while (iterator_break_skill_link != break_skill_link_map_.end())
      {
        int break_id = iterator_break_skill_link->first;
        skillBreakBase* break_base = DataManager::GetInstance().GetSkillBrkTable()->GetSkillBrk(break_id);


        //loop break item

        CSJson::Value json_break_item_list(CSJson::nullValue);

        std::vector<skillBreak_t>::iterator iterator_break_item = break_base->skill_break_list.begin();
        while (iterator_break_item != break_base->skill_break_list.end())
        {
          skillBreak_t &break_item = *iterator_break_item;

          CSJson::Value json_break_item_data(CSJson::objectValue);

          //time
          float time_duration = (break_item.sleep_time + break_item.survival_time) * 0.001f;
          json_break_item_data["time_delay"] = break_item.sleep_time * 0.001f;
          json_break_item_data["time_duration"] = time_duration;

          if (time_duration <= 0)
          {
            LOG_ERROR("[ExtractEffectBreak] error time_duration! sleep_time: %d, survival_time: %d, break_id: %d", break_item.sleep_time, break_item.survival_time, break_id);
            json_break_item_data["time_duration"] = 0.001f;
            time_duration = 0.001f;
          }

          //position
          json_break_item_data["position_adjust_x"] = break_item.x;
          json_break_item_data["position_adjust_y"] = break_item.y;

          //direction
          //a mess
          switch (break_item.attr_id)
          {
          case 0:
            //the direction is clockwise(normally ccw), from 0 to 32, and assume x- axis as origin(normally x+)
            //changed to normal
            json_break_item_data["direction_reference"] = "fix_right";  
            json_break_item_data["direction"] = int(180.0f + 360.0f * (1 - break_item.dir / 32.0f)) % 360; 
            break;
          case 1:
            //changed to normal, omit transform assume x- axis as origin(normally x+)
            json_break_item_data["direction_reference"] = "actor_front";
            json_break_item_data["direction"] = int(360.0f * (1 - break_item.dir / 32.0f)) % 360; 
            break;
          case 2:
            //changed to normal
            json_break_item_data["is_position_adjust_calc_random"] = true;
            json_break_item_data["direction_reference"] = "fix_right"; 
            json_break_item_data["direction"] = int(180.0f + 360.0f * (1 - break_item.dir / 32.0f)) % 360; 
            break;
          default:
            LOG_ERROR("[ExtractEffectBreak] error break_item attr_id! attr_id: %d, break_id: %d", break_item.attr_id, break_id);
            json_break_item_data["direction_reference"] = "ErrorValue";
            json_break_item_data["direction"] = 0; 
            break;
          }


          //track(movement)
          //��������ķ��й켣, 1ֱ��, 2������, 4���� 8 �����������  16 ���������� 32 ������Զ���� 64  ������Զ���
          CSJson::Value json_break_item_movement_data(CSJson::objectValue);
          switch (break_item.track)
          {        
          case 1:
            if (break_item.raw_move_dist > 0)
            {
              json_break_item_movement_data["type"] = "line";
              json_break_item_movement_data["speed"] = float(break_item.raw_move_dist) / time_duration; //transfer to grid per second
            }
            else
            {
              json_break_item_movement_data["type"] = "none";
              json_break_item_movement_data["speed"] = 0.0f;
            }
            break;
          case 4:
            json_break_item_movement_data["type"] = "tag_actor";
            json_break_item_movement_data["speed"] = 0.0f;
            break;
          case 8:
            json_break_item_movement_data["type"] = "homing";
            json_break_item_movement_data["homing_target_count"] = 1;
            json_break_item_movement_data["homing_order"] = "first_near";
            json_break_item_movement_data["speed"] = float(break_item.raw_move_dist) / time_duration; //transfer to grid per second
            break;
          case 16:
            json_break_item_movement_data["type"] = "homing";
            json_break_item_movement_data["homing_target_count"] = -1;
            json_break_item_movement_data["homing_order"] = "first_near";
            json_break_item_movement_data["speed"] = float(break_item.raw_move_dist) / time_duration; //transfer to grid per second
            break;
          case 32:
            json_break_item_movement_data["type"] = "homing";
            json_break_item_movement_data["homing_target_count"] = 1;
            json_break_item_movement_data["homing_order"] = "first_far";
            json_break_item_movement_data["speed"] = float(break_item.raw_move_dist) / time_duration; //transfer to grid per second
            break;
          case 64:
            json_break_item_movement_data["type"] = "homing";
            json_break_item_movement_data["homing_target_count"] = -1;
            json_break_item_movement_data["homing_order"] = "first_far";
            json_break_item_movement_data["speed"] = float(break_item.raw_move_dist) / time_duration; //transfer to grid per second
            break;
          default:
            if (break_item.raw_move_dist > 0 && break_item.track > 0)
            {
              LOG_ERROR("[ExtractEffectBreak] error break_item track! track: %d, break_id: %d", break_item.track, break_id);
              json_break_item_movement_data["type"] = "ErrorValue";
              json_break_item_movement_data["speed"] = float(break_item.raw_move_dist) / time_duration; //transfer to grid per second
            }
            else
            {
              json_break_item_movement_data["type"] = "none";
              json_break_item_movement_data["speed"] = 0.0f;
            }
            break;
          }
          if (json_break_item_movement_data.size() > 0) json_break_item_data["movement_data"] = json_break_item_movement_data;


          //animation
          CSJson::Value json_break_item_animation_data(CSJson::objectValue);
          if (break_item.proc_armature.empty() == false)
          {
            ExtractAnimationArmature(
              break_item.proc_armature, 
              std::string("BREAK|") + break_item.proc_armature + "|" + Int2String(break_id), 
              std::string("break_id: ") + Int2String(break_id));

            json_break_item_animation_data["animation"] = break_item.proc_armature;
            json_break_item_animation_data["animation_type"] = "armature";
          }
          else
          {
            if (break_item.proc_particle.empty() == false)
            {
              ExtractAnimationProjectile(
                break_item.proc_particle, 
                std::string("BREAK|") + break_item.proc_particle + "|" + Int2String(break_id), 
                std::string("break_id: ") + Int2String(break_id));

              json_break_item_animation_data["animation"] = break_item.proc_particle;
              json_break_item_animation_data["animation_type"] = "projectile";
            }

            // NOTE: all three only exists one, so end particle is a lie
            if (break_item.ending_particle.empty() == false)
            {
              ExtractAnimationProjectile(
                break_item.ending_particle, 
                std::string("BREAK|") + break_item.ending_particle + "|" + Int2String(break_id), 
                std::string("break_id: ") + Int2String(break_id));

              json_break_item_animation_data["animation"] = break_item.ending_particle;
              json_break_item_animation_data["animation_type"] = "projectile";
            }
          }
          if (json_break_item_animation_data.size() > 0) json_break_item_data["animation_data"] = json_break_item_animation_data;

          json_break_item_data["animation_layer"] = effect_break_animation_layer_transfer_array[break_item.layer];

          //attack 
          CSJson::Value json_break_item_attack_data(CSJson::objectValue);
          if (break_item.val_proc_unit > 0)
          {
            SkillAttackRangeData* attack_range_data = DataManager::GetInstance().GetSkillAttackRangeTable()->GetSkillAttackRangeData(break_item.val_proc_unit);
          
            if (attack_range_data && break_item.val_proc_count != 0)
            {
              switch (attack_range_data->GetZoneType())
              {
              case 1:
                json_break_item_attack_data["trigger_range_type"] = "circle";
                json_break_item_attack_data["trigger_range_width"] = attack_range_data->GetWidth();
                json_break_item_attack_data["trigger_range_height"] = attack_range_data->GetWidth();
                break;
              case 2:
                json_break_item_attack_data["trigger_range_type"] = "rectangle";
                json_break_item_attack_data["trigger_range_width"] = attack_range_data->GetWidth();
                json_break_item_attack_data["trigger_range_height"] = attack_range_data->GetHeight();
                break;
              case 3:
                json_break_item_attack_data["trigger_range_type"] = "all";
                break;
              default:
                LOG_ERROR("[ExtractEffectBreak] error break_item attack_range_data ZoneType! ZoneType: %d, break_id: %d", attack_range_data->GetZoneType(), break_id);
                break;
              }

              if (json_break_item_attack_data.size() > 0)
              {
                json_break_item_attack_data["position_adjust_x"] = -1 * attack_range_data->GetOffsetX();  //fix left to fix front transform
                json_break_item_attack_data["position_adjust_y"] = attack_range_data->GetOffsetY();


                std::string trigger_check_data = "";

                if (break_item.val_proc_count > 0)
                {
                  trigger_check_data = std::string("count_limit|") + Int2String(break_item.val_proc_count);
                }

                switch (attack_range_data->GetValProcType())
                {
                case 1: //               1:��ͼ����ʧ��ʱ����㣨ը���ķ�����
                  if (trigger_check_data.empty() == false) trigger_check_data += ", ";
                  trigger_check_data += "on_effect_end";
                  break;
                case 2: //               2:������˲����㣨ֻҪ�����ͽ��㣩
                  if (trigger_check_data.empty() == false) trigger_check_data += ", ";
                  trigger_check_data += "on_hit_actor";
                  break;
                case 3: //               3:���һ��ʱ����㣨���ǽ��
                  if (trigger_check_data.empty() == false) trigger_check_data += ", ";
                  trigger_check_data += "on_time_tick";
                  {
                    //use first, drop excess original data
                    if (break_skill_link_map_[break_id].size() != 1)
                    {
                      LOG_ERROR("[ExtractEffectBreak] dropped break_item attack_range_data tick time data! break_id: %d, skill_count: %d", 
                        break_id,
                        break_skill_link_map_[break_id].size());
                    }

                    int skill_id = *(break_skill_link_map_[break_id].begin());
                    SkillBase* skill_base = static_skill_map[skill_id];
                    trigger_check_data += "|" + Float2String2f(skill_base->GetDamageTick() * 0.001f);
                  }
                  break;
                }

                json_break_item_attack_data["trigger_check_data"] = trigger_check_data;

                //no use drop all data
                // 0x00000001: �Ͷ���һ��������ʱ�䡭 // 0x00000002: ճ�ڶ�Ӧ�Ķ�������һ���˶� // 0x00000004: ���ʩ��������
                //switch (attack_range_data->GetSurvivalType())
              }
            }
            else
            {
              LOG_ERROR("[ExtractEffectBreak] error break_item val_proc_unit! val_proc_unit: %d, val_proc_count: %d, break_id: %d", 
                break_item.val_proc_unit, 
                break_item.val_proc_count, 
                break_id);
            }
          }
          if (json_break_item_attack_data.size() > 0) json_break_item_data["attack_data"] = json_break_item_attack_data;

          if (json_break_item_data.isMember("attack_data") || json_break_item_data.isMember("animation_data"))
          {
            FIX_JSON_APPEND(json_break_item_list, json_break_item_data);
          }
          else
          {
            LOG_ERROR("[ExtractEffectBreak] error break_item no attack_data or animation_data! break_id: %d", 
              break_id);
          }

          iterator_break_item ++;
        }


        //back link to linked skill
        CSJson::Value json_effect_skill_list_data(CSJson::nullValue);

        bool is_hit_break = false;
        bool is_start_break = false;
        bool is_end_break = false;
        std::string break_id_string = Int2String(break_id);

        std::list<int> &skill_id_list = iterator_break_skill_link->second;
        std::list<int>::iterator iterator_skill_id = skill_id_list.begin();
        while (iterator_skill_id != skill_id_list.end())
        {
          int skill_id = *iterator_skill_id;
          SkillBase* skill_base = static_skill_map[skill_id];

          std::string& break_type = json_root_skill_[Int2String(skill_id)]["skill_break_data"][break_id_string].asString();
          is_hit_break |= (break_type == EFFECT_TYPE_HIT_1);
          is_hit_break |= (break_type == EFFECT_TYPE_HIT_2);
          is_hit_break |= (break_type == EFFECT_TYPE_HIT_3);
          is_start_break |= (break_type == EFFECT_TYPE_START);
          is_end_break |= (break_type == EFFECT_TYPE_END);

          FIX_JSON_APPEND(json_effect_skill_list_data, skill_id);

          //back link
          FIX_JSON_APPEND(json_root_skill_[Int2String(skill_id)]["skill_break_list"], break_id);

          iterator_skill_id ++;
        }


        CSJson::Value json_effect_break_data(CSJson::objectValue);

        json_effect_break_data["break_id"] = break_id;

        json_effect_break_data["effect_skill_list"] = json_effect_skill_list_data;
        json_effect_break_data["break_item_list"] = json_break_item_list;
      
        json_effect_break_data["origin_position_type"] = effect_break_position_transfer_array[break_base->attr_id];
        json_effect_break_data["position_adjust_x"] = break_base->o_x;
        json_effect_break_data["position_adjust_y"] = break_base->o_y;

        json_effect_break_data["is_hit_break"] = is_hit_break;
        json_effect_break_data["is_start_break"] = is_start_break;
        json_effect_break_data["is_end_break"] = is_end_break;

        json_root_effect_break_[Int2String(break_id)] = json_effect_break_data;

        CCLog("[ExtractEffectBreak] get break_id: %d", break_id);

        iterator_break_skill_link ++;
      }
      CCLog("[ExtractEffectBreak] get json_effect_break_data count: %d", json_root_effect_break_.size());
    }


    void ActorSkillDataExtractor::ExtractEffectAura()
    {
      //first loop push data
      std::map<int, std::list<int> >::iterator iterator_aura_skill_link = aura_skill_link_map_.begin();
      while (iterator_aura_skill_link != aura_skill_link_map_.end())
      {
        int aura_id = iterator_aura_skill_link->first;
        const AuraData* aura_data = DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id);

        for (int i = 0; i < aura_data->get_mod_count(); i ++)
        {
          const ModifierData* mod_data = aura_data->getConstModifier(i);

          LuaTinkerManager::GetInstance().CallLuaFunc<bool>(
            "script/debug_run/debug_run_aura_decode.lua", 
            "AddAuraData",
            aura_id,
            mod_data->m_type,
            mod_data->m_param0.c_str(),
            mod_data->m_param1.c_str(),
            mod_data->m_param2.c_str(),
            mod_data->m_param3.c_str());
        }

        iterator_aura_skill_link ++;
      }


      //decode
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>(
        "script/debug_run/debug_run_aura_decode.lua", 
        "DecodeAllAuraData");


      //get decoded data
      iterator_aura_skill_link = aura_skill_link_map_.begin();
      while (iterator_aura_skill_link != aura_skill_link_map_.end())
      {
        int aura_id = iterator_aura_skill_link->first;
        const AuraData* aura_data = DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id);

        CSJson::Value json_effect_aura_data(CSJson::objectValue);

        //data from lua decode
        std::string decoded_aura_data_string = LuaTinkerManager::GetInstance().CallLuaFunc<char*>(
          "script/debug_run/debug_run_aura_decode.lua", 
          "GetDecodedAuraData",
          aura_id);

        CSJson::Reader reader;
        bool is_success = reader.parse(decoded_aura_data_string, json_effect_aura_data, false);
        if (is_success == false)
        {
          LOG_ERROR("[ExtractEffectAura] error parse decoded aura data, data: %s, aura_id: %d", 
            decoded_aura_data_string.c_str(), 
            aura_id);
          assert(false);
        }
      

        //status
        json_effect_aura_data["aura_status_for_actor"] = LuaTinkerManager::GetInstance().CallLuaFunc<char*>(
          "script/debug_run/debug_run_aura_decode.lua", 
          "GetAuraStatusFlagType",
          aura_data->get_aura_status().c_str());


        //replace rule
        switch (aura_data->get_replace_rule())
        {
        case taomee::ability::kAuraReplaceRule_Replace:
          json_effect_aura_data["replace_type"] = "replace_previous";
          break;
        case taomee::ability::kAuraReplaceRule_Coexist:
          json_effect_aura_data["replace_type"] = "add_new";
          break;
        case taomee::ability::kAuraReplaceRule_Overlay:
          json_effect_aura_data["replace_type"] = "stack_value";
          break;
        }

        //effect position
        switch (aura_data->get_interrupt_type())
        {
        case taomee::ability::kInterruptType_CanNot:
          //nothing
          break;
        case taomee::ability::kInterruptType_Attacked:
          json_effect_aura_data["additional_stop_event_check"] = "receive_damage";
          break;
        case taomee::ability::kInterruptType_SkillOver:
          json_effect_aura_data["additional_stop_event_check"] = "skill_end";
          break;
        }


        json_effect_aura_data["is_positive_aura"] = aura_data->get_gains();



        if (aura_data->get_time() == 0)
        {
          json_effect_aura_data["apply_data"] = "instant";
        }
        else 
        {
          std::string apply_data = "time|" + Float2String2f(aura_data->get_time());

          if (json_effect_aura_data["decoded_sub_aura_data"].empty() == false
            && json_effect_aura_data["decoded_sub_aura_data"][0].isMember("attribute_modify_data")
            && json_effect_aura_data["decoded_sub_aura_data"][0]["attribute_modify_data"][0].isMember("time_tick"))
          {
            apply_data += "|" + json_effect_aura_data["decoded_sub_aura_data"][0]["attribute_modify_data"][0]["time_tick"].asString();
          }


          std::string decoded_apply_data_string = LuaTinkerManager::GetInstance().CallLuaFunc<char*>(
            "script/debug_run/debug_run_aura_decode.lua", 
            "GetDecodedApplyData",
            aura_id);
          if (decoded_apply_data_string.empty() == false)
          {
            if (apply_data.empty() == false) apply_data += ", ";
            apply_data += decoded_apply_data_string;
          }


          json_effect_aura_data["apply_data"] = apply_data;
        }



        std::string decoded_buff_data_string = LuaTinkerManager::GetInstance().CallLuaFunc<char*>(
          "script/debug_run/debug_run_aura_decode.lua", 
          "GetDecodedBuffData",
          aura_id);
        json_effect_aura_data["buff_data"] = decoded_buff_data_string;
        


        //animation
        CSJson::Value json_aura_animation_data(CSJson::objectValue);
        if (aura_data->get_effect().empty() == false)
        {
          ExtractAnimationProjectile(
            aura_data->get_effect(), 
            std::string("AURA|") + aura_data->get_effect() + "|" + Int2String(aura_id), 
            std::string("aura_id: ") + Int2String(aura_id));

          json_aura_animation_data["animation_loop"] = aura_data->get_effect();
          json_aura_animation_data["animation_loop_type"] = "projectile";
        }

        if (aura_data->get_effect_stage1().empty() == false)
        {
          ExtractAnimationArmature(
            aura_data->get_effect_stage1(), 
            std::string("AURA|") + aura_data->get_effect_stage1() + "|" + Int2String(aura_id), 
            std::string("aura_id: ") + Int2String(aura_id));

          json_aura_animation_data["animation_start"] = aura_data->get_effect_stage1();
          json_aura_animation_data["animation_start_type"] = "armature";
        }
        if (aura_data->get_effect_stage2().empty() == false)
        {
          ExtractAnimationArmature(
            aura_data->get_effect_stage2(), 
            std::string("AURA|") + aura_data->get_effect_stage2() + "|" + Int2String(aura_id), 
            std::string("aura_id: ") + Int2String(aura_id));

          json_aura_animation_data["animation_loop"] = aura_data->get_effect_stage2();
          json_aura_animation_data["animation_loop_type"] = "armature";
        }
        if (aura_data->get_effect_stage3().empty() == false)
        {
          ExtractAnimationArmature(
            aura_data->get_effect_stage3(), 
            std::string("AURA|") + aura_data->get_effect_stage3() + "|" + Int2String(aura_id), 
            std::string("aura_id: ") + Int2String(aura_id));

          json_aura_animation_data["animation_end"] = aura_data->get_effect_stage3();
          json_aura_animation_data["animation_end_type"] = "armature";
        }
        if (json_aura_animation_data.size() > 0) 
        {
          //effect position
          switch (aura_data->get_effect_pos())
          {
          case taomee::ability::kEffectPositionType_Top:
            json_aura_animation_data["position_type"] = "above_actor";
            break;
          case taomee::ability::kEffectPositionType_Mid:
            json_aura_animation_data["position_type"] = "on_actor";
            break;
          case taomee::ability::kEffectPositionType_Bottom:
            json_aura_animation_data["position_type"] = "below_actor";
            break;
          }

          json_effect_aura_data["animation_data"] = json_aura_animation_data;
        }
      
        //back link to linked skill
        CSJson::Value json_aura_skill_list_data(CSJson::nullValue);

        std::list<int> &skill_id_list = iterator_aura_skill_link->second;
        std::list<int>::iterator iterator_skill_id = skill_id_list.begin();
        while (iterator_skill_id != skill_id_list.end())
        {
          int skill_id = *iterator_skill_id;
          SkillBase* skill_base = static_skill_map[skill_id];

          //back link
          FIX_JSON_APPEND(json_root_skill_[Int2String(skill_id)]["skill_aura_list"], aura_id);

          FIX_JSON_APPEND(json_aura_skill_list_data, skill_id);

          iterator_skill_id ++;
        }




        json_effect_aura_data["aura_id"] = aura_id;

        json_effect_aura_data["aura_skill_list"] = json_aura_skill_list_data;

        json_root_effect_aura_[Int2String(aura_id)] = json_effect_aura_data;

        CCLog("[ExtractEffectAura] get aura_id: %d", aura_id);

        iterator_aura_skill_link ++;
      }
      CCLog("[ExtractEffectAura] get json_effect_aura_data count: %d", json_root_effect_aura_.size());
    }



    bool ActorSkillDataExtractor::ExtractAnimationArmature(
      const std::string& animation_name, 
      const std::string& description, 
      const std::string& error_text)
    {
      if (animation_name.empty())
      {
        assert(false);
        return false; //no animation
      }

      if (json_root_armature_.isMember(animation_name))
      {
        return true; //skip
      }

      CSJson::Value animation_data = extract_armature_animation_data(animation_name);

      if (animation_data.size() > 0)
      {
        animation_data["description"] = description;
        json_root_armature_[animation_name] = animation_data;
        return true;
      }
      else
      {
        LOG_ERROR("[ExtractAnimationArmature] missing armature animation <%s>, info: %s", animation_name.c_str(), error_text.c_str());
        return false;
      }
    }

    bool ActorSkillDataExtractor::ExtractAnimationProjectile(
      const std::string& animation_name, 
      const std::string& description, 
      const std::string& error_text)
    {
      if (animation_name.empty())
      {
        assert(false);
        return false; //no animation
      }

      if (json_root_projectile_.isMember(animation_name))
      {
        return true; //skip
      }

      CSJson::Value animation_data = extract_projectile_animation_data(animation_name);

      if (animation_data.size() > 0)
      {
        animation_data["description"] = description;
        json_root_projectile_[animation_name] = animation_data;
        return true;
      }
      else
      {
        LOG_ERROR("[ExtractAnimationProjectile] missing projectile animation <%s>, info: %s", animation_name.c_str(), error_text.c_str());
        return false;
      }
    }



    bool ActorSkillDataExtractor::ExtractCardSkillAddonArmature(CSJson::Value& root, int card_id, int skill_id)
    {
      CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);
      SkillBase* skill_base = static_skill_map[skill_id];

      std::string animation_name = card_data->GetName();
      std::string movement_name = skill_base->GetMotion();

      //check
      if (animation_name.empty() 
        || movement_name.empty() 
        || json_root_armature_.isMember(animation_name.c_str()) == false
        || json_root_armature_[animation_name].isMember(movement_name.c_str()) == false)
      {
        return false;
      }


      CSJson::Value frame_data = json_root_armature_[animation_name][movement_name]["frame_data"];


      //record max hit
      if (frame_data["event_tag_frame_map"].isMember(FRAME_EVENT_TAG_HIT))
      {
        int skill_hit_count = frame_data["event_tag_frame_map"][FRAME_EVENT_TAG_HIT].size();

        if (static_skill_max_hit_count_map[skill_id].max_hit_count < skill_hit_count)
        {
          static_skill_max_hit_count_map[skill_id].card_id = card_id;
          static_skill_max_hit_count_map[skill_id].skill_id = skill_id;
          static_skill_max_hit_count_map[skill_id].max_hit_count = skill_hit_count;

          if (skill_hit_count > 3)
          {
            LOG_ERROR("[ExtractSkill] unnatural skill_max_hit_count: %d, card_id: %d, skill_id: %d", skill_hit_count, card_id, skill_id);
          }
        }
      }


      CSJson::Value frame_event_tag_data(CSJson::objectValue);

      if (skill_base->GetPowerEffect().empty() == false)
      {
        if (frame_data["event_tag_frame_map"].isMember(FRAME_EVENT_TAG_POWER.c_str()))
        {
          frame_event_tag_data[skill_base->GetPowerEffect()] = FRAME_EVENT_TAG_POWER;
        }
        else
        {
          LOG_ERROR("[ExtractCardSkillAddonArmature] missing event tag for card_id: %d, skill_id: %d, addon armature: %s, tag: %s, animation: %s, movement: %s", 
            card_id, 
            skill_id, 
            skill_base->GetPowerEffect().c_str(), 
            FRAME_EVENT_TAG_POWER.c_str(),
            animation_name.c_str(),
            movement_name.c_str());
        }
      }

      if (skill_base->GetPower2Effect().empty() == false)
      {
        if (frame_data["event_tag_frame_map"].isMember(FRAME_EVENT_TAG_POWER_2.c_str()))
        {
          frame_event_tag_data[skill_base->GetPower2Effect()] = FRAME_EVENT_TAG_POWER_2;
        }
        else
        {
          LOG_ERROR("[ExtractCardSkillAddonArmature] missing event tag for card_id: %d, skill_id: %d, addon armature: %s, tag: %s, animation: %s, movement: %s", 
            card_id, 
            skill_id, 
            skill_base->GetPower2Effect().c_str(), 
            FRAME_EVENT_TAG_POWER_2.c_str(),
            animation_name.c_str(),
            movement_name.c_str());
        }
      }

      if (frame_event_tag_data.empty())
      {
        return false;
      }

      CSJson::Value json_data(CSJson::objectValue);
      json_data["card_id"] = card_id;
      json_data["skill_id"] = skill_id;
      json_data["animation_name"] = animation_name;
      json_data["movement_name"] = movement_name;
      json_data["frame_event_tag_data"] = frame_event_tag_data;

      root[Int2String(skill_id)] = json_data;

      return true;
    }








    std::string ActorSkillDataExtractor::nest_id_data_list_to_string (NestIdDataList& nest_id_data_list)
    {
      std::string result_string;
      for (NestIdDataList::iterator iterator = nest_id_data_list.begin(); iterator != nest_id_data_list.end(); iterator ++)
      {
        NestIdData &nest_id_data = *iterator;

        if (nest_id_data.key.empty() == false)
        {
          if (nest_id_data.type == "effect_timeline")
          {
            nest_id_data.id = skill_break_key_effect_timeline_id_map_[nest_id_data.key];
          }
        }


        result_string += ", " + Int2String(nest_id_data.id) + "|" + nest_id_data.type + "|" + Float2String2f(nest_id_data.fail_chance);
      }
      return result_string.empty() 
        ? "" 
        : result_string.substr(2);  //lose first ", "
    }


    void ActorSkillDataExtractor::Reform()
    {
      ReformBuffStatusAnimation();
      ReformBuffConfig();

      ReformEffectConfig();
      ReformEffectTimeline();

      ReformSkillConfig();
    }


    void ActorSkillDataExtractor::ReformSkillConfig()
    {
      for (CSJson::Value::iterator json_iterator = json_root_skill_.begin(); json_iterator != json_root_skill_.end(); json_iterator ++)
      {
        std::string skill_id_string = json_iterator.memberName();
        int skill_id = atoi(skill_id_string.c_str());

        if (skill_id <= 0)
        {
          continue;
        }

        CSJson::Value &json_skill = json_root_skill_[skill_id_string];
        SkillBase* skill_base = static_skill_map[skill_id];

        //base info
        SkillConfig skill_config;
        skill_config.key = std::string("skill") + skill_id_string;
        skill_config.id = skill_id;
        skill_config.desc = skill_base->GetSkillDesc();
        skill_config.skill_attr_desc = skill_base->GetSkillDescAttr();

        skill_config.skill_icon = skill_base->GetIconPath();
        skill_config.skill_type = skill_base->GetSkillType();
        skill_config.skill_cool_down = skill_base->getCDTick();

        int movement_added_count = 0;
        while (movement_added_count < json_skill["actor_movement_loop_count"].asInt())
        {
          if (skill_config.movement_data.empty() == false) skill_config.movement_data += ", ";
          skill_config.movement_data += json_skill["actor_movement"].asString() + "|" + Float2String2f(json_skill["actor_movement_speed_scale"].asFloat());
          movement_added_count ++;
        }

        skill_config.damage_type = skill_base->GetDamageType();
        skill_config.damage_base = skill_base->GetInitDamage();
        skill_config.card_transfer_ratio_physical = skill_base->GetPhyAddedMul();
        skill_config.card_transfer_ratio_magical = skill_base->GetMagAddedMul();

        skill_config.level_add_damage = skill_base->GetInitDamage();
        skill_config.level_add_attr_type = "";
        skill_config.level_add_attr_value = 0;

        //fill effect list
        CSJson::Value &json_reformed_effect_timeline_id = json_skill["reformed_effect_timeline_id"];
        for (CSJson::Value::iterator json_iterator = json_reformed_effect_timeline_id.begin(); json_iterator != json_reformed_effect_timeline_id.end(); json_iterator ++)
        {
          std::string reformed_effect_timeline_type = json_iterator.memberName();
          int reformed_effect_timeline_id = json_reformed_effect_timeline_id[reformed_effect_timeline_type].asInt();

          NestIdData nest_id_data;
          nest_id_data.id = reformed_effect_timeline_id;
          nest_id_data.type = "effect_timeline";
          nest_id_data.fail_chance = 0;

          if (reformed_effect_timeline_type == EFFECT_TYPE_START)
            skill_config.emit_data_start.push_back(nest_id_data);
          //if (reformed_effect_timeline_type == EFFECT_TYPE_END) //explotion effect, all in effect config
            //skill_config.emit_data_end.push_back(nest_id_data);
          if (reformed_effect_timeline_type == EFFECT_TYPE_HIT_1)
            skill_config.emit_data_hit_1.push_back(nest_id_data);
          if (reformed_effect_timeline_type == EFFECT_TYPE_HIT_2)
            skill_config.emit_data_hit_2.push_back(nest_id_data);
          if (reformed_effect_timeline_type == EFFECT_TYPE_HIT_3)
            skill_config.emit_data_hit_3.push_back(nest_id_data);
        }


        //check self buff link
        for (CSJson::Value::iterator json_skill_aura_iterator = json_skill["skill_aura_data"].begin(); json_skill_aura_iterator != json_skill["skill_aura_data"].end(); json_skill_aura_iterator ++)
        {
          std::string aura_id_string = json_skill_aura_iterator.memberName();
          int aura_id = atoi(aura_id_string.c_str());
          CSJson::Value &json_skill_aura = json_skill["skill_aura_data"][aura_id_string];

          if (json_skill_aura["type"].asString() == BUFF_TYPE_SELF)
          {
            NestIdData nest_id_data;
            nest_id_data.id = aura_id;
            nest_id_data.type = "buff";
            nest_id_data.fail_chance = 1.0f - json_skill_aura["apply_possibility"].asInt() * 0.01f;
            skill_config.emit_data_start.push_back(nest_id_data);
          }

          if (json_skill_aura["type"].asString() == BUFF_TYPE_HIT_ALLY
            || json_skill_aura["type"].asString() == BUFF_TYPE_HIT_ENEMY)
          {
            //skip, processed in effect
          }
        }

        skill_config_map_[skill_config.key] = skill_config;

        CCLog("[ReformSkillConfig] get skill_id: %d", skill_id);
      }
    }


    void ActorSkillDataExtractor::ReformEffectConfig()
    {
      //need check skill/break/aura at once! may generate more buff trigger effect, will change id
      for (CSJson::Value::iterator json_iterator = json_root_effect_break_.begin(); json_iterator != json_root_effect_break_.end(); json_iterator ++)
      {
        std::string break_id_string = json_iterator.memberName();
        int break_id = atoi(break_id_string.c_str());

        CSJson::Value &json_break = json_root_effect_break_[break_id_string];
        CSJson::Value &json_break_item_list = json_break["break_item_list"];

        int break_item_count = json_break_item_list.size();
        for (int break_item_index = 0; break_item_index < break_item_count; break_item_index ++)
        {
          CSJson::Value &json_break_item = json_break_item_list[break_item_index];

          if (json_break_item.isMember("attack_data") == false)
          {
            continue; // not Effect, only animation
          }

          EffectConfig effect_config;
          effect_config.key = std::string("effect") + break_id_string + "|index" + Int2String(break_item_index);
          effect_config.desc = "";

          //later... check skill
          // effect_config.emit_data;

          if (json_break_item.isMember("animation_data"))
          {
            effect_config.animation_type = json_break_item["animation_data"]["animation_type"].asString();
            effect_config.animation_name = json_break_item["animation_data"]["animation"].asString();
          }
          effect_config.duration = json_break_item["time_duration"].asFloat();
          
          effect_config.trigger_range_type = json_break_item["attack_data"]["trigger_range_type"].asString();
          effect_config.trigger_range_width = json_break_item["attack_data"]["trigger_range_width"].asFloat();
          effect_config.trigger_range_height = json_break_item["attack_data"]["trigger_range_height"].asFloat();
          effect_config.trigger_range_x = json_break_item["attack_data"]["position_adjust_x"].asInt();
          effect_config.trigger_range_y = json_break_item["attack_data"]["position_adjust_y"].asInt();

          effect_config.trigger_check_data = json_break_item["attack_data"]["trigger_check_data"].asString();

          //check and pull skill useTagType, effBreakId down a level

          for (std::list<int>::iterator skill_id_iterator = break_skill_link_map_[break_id].begin(); skill_id_iterator != break_skill_link_map_[break_id].end(); skill_id_iterator ++)
          {
            int skill_id = *skill_id_iterator;
            std::string skill_id_string = Int2String(skill_id);
            CSJson::Value &json_skill = json_root_skill_[skill_id_string];
            SkillBase* skill_base = static_skill_map[skill_id];


            //make copy, anyway
            EffectConfig effect_config_per_skill = effect_config;

            effect_config_per_skill.desc += "|skill" + skill_id_string;

            //add target filter data
            const std::string &break_target_filter = effect_break_target_filter_transfer_array[skill_base->GetUseTagType()];
            if (break_target_filter.empty() == false)
            {
              if (effect_config_per_skill.trigger_check_data.empty())
                effect_config_per_skill.trigger_check_data = break_target_filter;
              else
                effect_config_per_skill.trigger_check_data += ", " + break_target_filter;

              //add mark to key
              effect_config_per_skill.key += "|filter" + break_target_filter;
            }


            //add explosion effect, hit buff data
            std::string &break_type = json_skill["skill_break_data"][break_id_string].asString();
            if (break_type == EFFECT_TYPE_START
              || break_type == EFFECT_TYPE_END)
            {
              //nothing special
            }

            if (break_type == EFFECT_TYPE_HIT_1
              || break_type == EFFECT_TYPE_HIT_2
              || break_type == EFFECT_TYPE_HIT_3)
            {
              //add explode effect link //effect_config.emit_data;
              if (skill_base->GetEffBreakId() > 0)
              {
                bool is_effect_timeline = json_root_effect_break_[Int2String(skill_base->GetEffBreakId())]["break_item_list"].size() > 1;

                NestIdData nest_id_data;
                nest_id_data.id = 0;
                nest_id_data.key = skill_id_string + "|" + Int2String(skill_base->GetEffBreakId());
                nest_id_data.type = "effect_timeline";
                nest_id_data.fail_chance = 0;
                effect_config_per_skill.emit_data.push_back(nest_id_data);

                //add mark to key
                effect_config_per_skill.key += "|explode" + Int2String(skill_base->GetEffBreakId());
              }


              //add buff link //effect_config.emit_data;
              for (CSJson::Value::iterator json_skill_aura_iterator = json_skill["skill_aura_data"].begin(); json_skill_aura_iterator != json_skill["skill_aura_data"].end(); json_skill_aura_iterator ++)
              {
                std::string aura_id_string = json_skill_aura_iterator.memberName();
                int aura_id = atoi(aura_id_string.c_str());
                CSJson::Value &json_skill_aura = json_skill["skill_aura_data"][aura_id_string];

                if (json_skill_aura["type"].asString() == BUFF_TYPE_SELF)
                {
                  //check in skill
                }

                if (json_skill_aura["type"].asString() == BUFF_TYPE_HIT_ALLY
                  || json_skill_aura["type"].asString() == BUFF_TYPE_HIT_ENEMY)
                {
                  NestIdData nest_id_data;
                  nest_id_data.id = aura_id;
                  nest_id_data.type = "buff";
                  nest_id_data.fail_chance = 1.0f - json_skill_aura["apply_possibility"].asInt() * 0.01f;
                  effect_config_per_skill.emit_data.push_back(nest_id_data);

                  json_skill_aura["reformed_effect_config_key"] = effect_config_per_skill.key;

                  //add mark to key
                  effect_config_per_skill.key += "|buff" + aura_id_string;
                }
              }
            }


            if (effect_config_map_.find(effect_config_per_skill.key) == effect_config_map_.end())
            {
              effect_config_per_skill.id = effect_config_map_.size() + 1;
              effect_config_map_[effect_config_per_skill.key] = effect_config_per_skill;
            }

            //append link info to desc
            effect_config_map_[effect_config_per_skill.key].desc += "|desc" + effect_config_per_skill.desc;

            //record id back to break item
            json_break_item["reformed_effect_config_id"][skill_id_string] = effect_config_map_[effect_config_per_skill.key].id;


            CCLog("[ReformEffectConfig] get break_id: %d, break_item_index: %d, skill_id: %d", break_id, break_item_index, skill_id);
          }
          CCLog("[ReformEffectConfig] get break_id: %d, break_item_index: %d", break_id, break_item_index);
        }
        CCLog("[ReformEffectConfig] get break_id: %d", break_id);
      }
    }


    void ActorSkillDataExtractor::ReformEffectTimeline()
    {
      for (CSJson::Value::iterator json_iterator = json_root_effect_break_.begin(); json_iterator != json_root_effect_break_.end(); json_iterator ++)
      {
        std::string break_id_string = json_iterator.memberName();
        int break_id = atoi(break_id_string.c_str());

        CSJson::Value &json_break = json_root_effect_break_[break_id_string];

        EffectTimeline effect_timeline;
        effect_timeline.key = std::string("timeline") + break_id_string;
        effect_timeline.id = atoi(break_id_string.c_str());
        effect_timeline.desc = "";

        effect_timeline.x = 0;
        effect_timeline.y = 0;
        effect_timeline.delay = 0;
        effect_timeline.duration = 0;

        CSJson::Value &json_break_item_list = json_break["break_item_list"];
        int break_item_count = json_break_item_list.size();

        //get normal data(no skill difference)
        for (int break_item_index = 0; break_item_index < break_item_count; break_item_index ++)
        {
          CSJson::Value &json_break_item = json_break_item_list[break_item_index];

          EffectTimelineItem effect_timeline_item;
          effect_timeline_item.key = std::string("timeline_item") + break_id_string + "|index" + Int2String(break_item_index);
          effect_timeline_item.id = break_item_index;
          effect_timeline_item.desc = effect_timeline_item.key;

          effect_timeline_item.x = json_break_item["position_adjust_x"].asInt();
          effect_timeline_item.y = json_break_item["position_adjust_y"].asInt();
          effect_timeline_item.delay = json_break_item["time_delay"].asFloat();
          effect_timeline_item.duration = json_break_item["time_duration"].asFloat();

          effect_timeline_item.movement_origin_type = json_break["origin_position_type"].asString();
          effect_timeline_item.movement_type = json_break_item["movement_data"]["type"].asString();
          if (json_break_item["movement_data"]["type"] == "homing")
          {
            effect_timeline_item.movement_data = std::string("homing") 
              + "|" + json_break_item["movement_data"]["homing_order"].asString() 
              + "|" + Int2String(json_break_item["movement_data"]["homing_target_count"].asInt());
          }
          if (json_break_item["movement_data"]["type"] == "homing")
          {
            effect_timeline_item.movement_data = std::string("homing") 
              + "|" + json_break_item["movement_data"]["homing_order"].asString() 
              + "|" + Int2String(json_break_item["movement_data"]["homing_target_count"].asInt());
          }
          if (json_break_item.isMember("is_position_adjust_calc_random"))
          {
            if (effect_timeline_item.movement_data.empty())
            {
              effect_timeline_item.movement_data = "position_random";
            }
            else
            {
              effect_timeline_item.movement_data += ", position_random";
            }
          }

          effect_timeline_item.movement_speed = json_break_item["movement_data"].isMember("speed") 
            ? json_break_item["movement_data"]["speed"].asFloat() 
            : 0.0f;
          effect_timeline_item.direction = json_break_item["direction"].asInt();
          effect_timeline_item.direction_type = json_break_item["direction_reference"].asString();
          effect_timeline_item.animation_item_layer = json_break_item["animation_layer"].asString();

          if (json_break_item.isMember("reformed_effect_config_id"))
          {
            //wait for loop
          }
          else if (json_break_item.isMember("animation_data"))
          {
            effect_timeline_item.animation_item_name = json_break_item["animation_data"]["animation"].asString();
            effect_timeline_item.animation_item_type = json_break_item["animation_data"]["animation_type"].asString();
          }

          effect_timeline.item_list.push_back(effect_timeline_item);
        }


        //check skill
        for (std::list<int>::iterator skill_id_iterator = break_skill_link_map_[break_id].begin(); skill_id_iterator != break_skill_link_map_[break_id].end(); skill_id_iterator ++)
        {
          int skill_id = *skill_id_iterator;
          std::string skill_id_string = Int2String(skill_id);
          CSJson::Value &json_skill = json_root_skill_[skill_id_string];
          SkillBase* skill_base = static_skill_map[skill_id];


          //make copy, anyway
          EffectTimeline effect_timeline_per_skill = effect_timeline;

          effect_timeline_per_skill.desc += "|skill" + skill_id_string;


          int break_item_index = 0;
          for (std::list<EffectTimelineItem>::iterator iterator = effect_timeline_per_skill.item_list.begin(); iterator != effect_timeline_per_skill.item_list.end(); iterator ++)
          {
            CSJson::Value &json_break_item = json_break_item_list[break_item_index];
            break_item_index ++;

            EffectTimelineItem &effect_timeline_item = *iterator;

            if (json_break_item.isMember("reformed_effect_config_id"))
            {
              int effect_config_id = json_break_item["reformed_effect_config_id"][skill_id_string].asInt();

              effect_timeline_item.animation_item_name = Int2String(effect_config_id);
              effect_timeline_item.animation_item_type = "effect";

              //add mark to key
              effect_timeline_per_skill.key += "|effect" + Int2String(effect_config_id);
            }
          }


          //check key
          if (effect_timeline_map_.find(effect_timeline_per_skill.key) == effect_timeline_map_.end())
          {
            effect_timeline_per_skill.id = effect_timeline_map_.size() + 1;
            effect_timeline_map_[effect_timeline_per_skill.key] = effect_timeline_per_skill;
          }

          //append link info to desc
          effect_timeline_map_[effect_timeline_per_skill.key].desc += effect_timeline_per_skill.desc;

          //add id back to skill
          json_skill["reformed_effect_timeline_id"][json_skill["skill_break_data"][break_id_string].asString()] = effect_timeline_map_[effect_timeline_per_skill.key].id;

          skill_break_key_effect_timeline_id_map_[skill_id_string + "|" + break_id_string] = effect_timeline_map_[effect_timeline_per_skill.key].id;

          CCLog("[ReformEffectTimeline] get break_id: %d, skill_id: %d", break_id, skill_id);
        }
        CCLog("[ReformEffectTimeline] get break_id: %d", break_id);
      }
    }

  
    void ActorSkillDataExtractor::ReformBuffStatusAnimation()
    {
      for (CSJson::Value::iterator json_iterator = json_root_effect_aura_.begin(); json_iterator != json_root_effect_aura_.end(); json_iterator ++)
      {
        std::string aura_id_string = json_iterator.memberName();
        int aura_id = atoi(aura_id_string.c_str());
        CSJson::Value &json_aura = json_root_effect_aura_[aura_id_string];

        if (json_aura.isMember("animation_data"))
        {
          CSJson::Value &json_animation_data = json_aura["animation_data"];

          //has animation, get key
          BuffStatusAnimation buff_status_animation;

          if (json_animation_data.isMember("animation_start")) {
            buff_status_animation.key += json_animation_data["animation_start"].asString();
            buff_status_animation.start = json_animation_data["animation_start"].asString();
            buff_status_animation.start_type = json_animation_data["animation_start_type"].asString();
          }

          if (json_animation_data.isMember("animation_loop")) {
            buff_status_animation.key += json_animation_data["animation_loop"].asString();
            buff_status_animation.loop = json_animation_data["animation_loop"].asString();
            buff_status_animation.loop_type = json_animation_data["animation_loop_type"].asString();
          }

          if (json_animation_data.isMember("animation_end")) {
            buff_status_animation.key += json_animation_data["animation_end"].asString();
            buff_status_animation.end = json_animation_data["animation_end"].asString();
            buff_status_animation.end_type = json_animation_data["animation_end_type"].asString();
          }

          buff_status_animation.key += json_animation_data["position_type"].asString();
          buff_status_animation.display_type = json_animation_data["position_type"].asString();

          //check key
          if (buff_status_animation_map_.find(buff_status_animation.key) == buff_status_animation_map_.end())
          {
            buff_status_animation.id = buff_status_animation_map_.size() + 1;
            buff_status_animation.desc = json_aura["aura_desc"].asString();

            buff_status_animation_map_[buff_status_animation.key] = buff_status_animation;
          }
        
          //add id back to aura
          json_aura["reformed_buff_status_animation_id"] = buff_status_animation_map_[buff_status_animation.key].id;
        }
        CCLog("[ReformBuffStatusAnimation] get aura_id: %d", aura_id);
      }
    }


    void ActorSkillDataExtractor::ReformBuffConfig()
    {
      //aura to buff, no id change
      CSJson::FastWriter fast_writer;

      for (CSJson::Value::iterator json_iterator = json_root_effect_aura_.begin(); json_iterator != json_root_effect_aura_.end(); json_iterator ++)
      {
        std::string aura_id_string = json_iterator.memberName();
        CSJson::Value &json_aura = json_root_effect_aura_[aura_id_string];

        BuffConfig buff_config;
        buff_config.key = std::string("buff") + aura_id_string;
        buff_config.id = atoi(aura_id_string.c_str());
        buff_config.desc = json_aura["aura_desc"].asString();

        buff_config.buff_status_animation_id = json_aura["reformed_buff_status_animation_id"].asInt();
        
        buff_config.is_positive = json_aura["is_positive_aura"].asBool() ? 1 : 0;
        buff_config.buff_key = "";
        buff_config.replace_type = json_aura["replace_type"].asString();
        buff_config.stack_type = "";

        buff_config.apply_data = json_aura["apply_data"].asString();

        buff_config.buff_data = json_aura["buff_data"].asString();

        buff_config.mod_data = fast_writer.write(json_aura["decoded_sub_aura_data"]);

        buff_config_map_[buff_config.key] = buff_config;

        CCLog("[ReformBuffConfig] get aura_id: %d", buff_config.id);
      }
    }






    const std::string FILE_NAME_PATH_PREFIX = "D:\\"; //windows only

    const std::string FILE_NAME_ERROR = FILE_NAME_PATH_PREFIX + "generated_error_data.txt";
    const std::string FILE_NAME_ID_LIST = FILE_NAME_PATH_PREFIX + "generated_id_list.txt";

    const std::string FILE_NAME_CARD = FILE_NAME_PATH_PREFIX + "generated_card_data.json";
    const std::string FILE_NAME_SKILL = FILE_NAME_PATH_PREFIX + "generated_skill_data.json";
    const std::string FILE_NAME_EFFECT_BREAK = FILE_NAME_PATH_PREFIX + "generated_effect_break_data.json";
    const std::string FILE_NAME_EFFECT_AURA = FILE_NAME_PATH_PREFIX + "generated_effect_aura_data.json";
    const std::string FILE_NAME_ANIMATION_ARMATURE = FILE_NAME_PATH_PREFIX + "generated_animation_armature_data.json";
    const std::string FILE_NAME_ANIMATION_PROJECTILE = FILE_NAME_PATH_PREFIX + "generated_animation_projectile_data.json";

    const std::string FILE_NAME_CARD_ADDON_ARMATURE = FILE_NAME_PATH_PREFIX + "reformed_card_addon_armature_data.txt";

    const std::string FILE_NAME_REFORM_SKILL_CONFIG = FILE_NAME_PATH_PREFIX + "reformed_skill_config.txt";
    const std::string FILE_NAME_REFORM_EFFECT_CONFIG = FILE_NAME_PATH_PREFIX + "reformed_effect_config.txt";
    const std::string FILE_NAME_REFORM_EFFECT_TIMELINE = FILE_NAME_PATH_PREFIX + "reformed_effect_timeline.txt";
    const std::string FILE_NAME_REFORM_BUFF_STATUS_ANIMATION = FILE_NAME_PATH_PREFIX + "reformed_buff_status_animation.txt";
    const std::string FILE_NAME_REFORM_BUFF_CONFIG = FILE_NAME_PATH_PREFIX + "reformed_buff_config.txt";

    
    void ActorSkillDataExtractor::SaveData()
    {
      //pack and save error log
      //pack and save error log
      //pack and save error log

      CCLog("[SaveData] saving error log... total: %d", static_error_log_list.size());

      std::string error_log_string = std::string("[ERROR LOG] total: " + Int2String(static_error_log_list.size()) + "\n");
      for (std::list<std::string>::iterator iterator = static_error_log_list.begin(); iterator != static_error_log_list.end(); iterator ++)
        error_log_string += *iterator + "\n";
      save_string_to_file(error_log_string, FILE_NAME_ERROR.c_str());



      //id list
      //id list
      //id list

      CCLog("[SaveData] saving extracted id list... skill: %d, break: %d, aura: %d", 
        skill_card_link_map_.size(), 
        break_skill_link_map_.size(), 
        aura_skill_link_map_.size());

      std::string id_list_string = "[ID LIST]";

      id_list_string += "\n\n<skill id>\n";
      for (std::map<int, std::list<int> >::iterator iterator = skill_card_link_map_.begin(); iterator != skill_card_link_map_.end(); iterator ++)
        id_list_string += Int2String(iterator->first) + " ";

      id_list_string += "\n\n<break id>\n";
      for (std::map<int, std::list<int> >::iterator iterator = break_skill_link_map_.begin(); iterator != break_skill_link_map_.end(); iterator ++)
        id_list_string += Int2String(iterator->first) + " ";

      id_list_string += "\n\n<aura id>\n";
      for (std::map<int, std::list<int> >::iterator iterator = aura_skill_link_map_.begin(); iterator != aura_skill_link_map_.end(); iterator ++)
        id_list_string += Int2String(iterator->first) + " ";

      save_string_to_file(id_list_string, FILE_NAME_ID_LIST.c_str());


      //save extracted json data
      //save extracted json data
      //save extracted json data

      CCLog("[SaveData] saving json <json_root_card_>...");
      save_json_to_file(json_root_card_, FILE_NAME_CARD.c_str());

      CCLog("[SaveData] saving json <json_root_skill_>...");
      save_json_to_file(json_root_skill_, FILE_NAME_SKILL.c_str());

      CCLog("[SaveData] saving json <json_root_effect_break_>...");
      save_json_to_file(json_root_effect_break_, FILE_NAME_EFFECT_BREAK.c_str());

      CCLog("[SaveData] saving json <json_root_effect_aura_>...");
      save_json_to_file(json_root_effect_aura_, FILE_NAME_EFFECT_AURA.c_str());

      CCLog("[SaveData] saving json <json_root_armature_>...");
      save_json_to_file(json_root_armature_, FILE_NAME_ANIMATION_ARMATURE.c_str());

      CCLog("[SaveData] saving json <json_root_projectile_>...");
      save_json_to_file(json_root_projectile_, FILE_NAME_ANIMATION_PROJECTILE.c_str());




      //save reformed data
      //save reformed data
      //save reformed data

      CCLog("[SaveData] saving card_addon_armature...");
      {
        std::string reform_string = "[SKILL_CONFIG]";
        reform_string += "\n";
        reform_string += "card_id\t";
        reform_string += "skill_id\t";
        reform_string += "armature_name\t";
        reform_string += "movement_name\t";
        reform_string += "frame_event_tag\t";
        reform_string += "card_addon_armature\t";

        for (CSJson::Value::iterator json_iterator = json_root_card_.begin(); json_iterator != json_root_card_.end(); json_iterator ++)
        {
          std::string card_id_string = json_iterator.memberName();
          int card_id = atoi(card_id_string.c_str());
          CSJson::Value &json_card = json_root_card_[card_id_string];

          if (json_card.isMember("card_skill_addon_armature_data") && json_card["card_skill_addon_armature_data"].empty() == false)
          {
            CSJson::Value &json_card_skill_addon_armature_data = json_card["card_skill_addon_armature_data"];
            for (CSJson::Value::iterator json_iterator_card_skill_addon_armature = json_card_skill_addon_armature_data.begin(); json_iterator_card_skill_addon_armature != json_card_skill_addon_armature_data.end(); json_iterator_card_skill_addon_armature ++)
            {
              std::string skill_id_string = json_iterator_card_skill_addon_armature.memberName();
              CSJson::Value &json_frame_event_tag_data = json_card_skill_addon_armature_data[skill_id_string]["frame_event_tag_data"];
              for (CSJson::Value::iterator json_frame_event_tag = json_frame_event_tag_data.begin(); json_frame_event_tag != json_frame_event_tag_data.end(); json_frame_event_tag ++)
              {
                reform_string += "\n";
                reform_string += card_id_string + "\t";
                reform_string += skill_id_string + "\t";
                reform_string += json_card_skill_addon_armature_data[skill_id_string]["animation_name"].asString() + "\t";
                reform_string += json_card_skill_addon_armature_data[skill_id_string]["movement_name"].asString() + "\t";
                reform_string += json_frame_event_tag_data[json_frame_event_tag.memberName()].asString() + "\t";
                reform_string += std::string(json_frame_event_tag.memberName()) + "\t";
              }
            }
          }
        }

        save_string_to_file(reform_string, FILE_NAME_CARD_ADDON_ARMATURE.c_str());
      }




      CCLog("[SaveData] saving skill config... total: %d", skill_config_map_.size());
      //skill config //to text and to file
      {
        std::string reform_string = "[SKILL_CONFIG]";
        reform_string += "\n";
        reform_string += "id\t";
        reform_string += "key\t";
        reform_string += "desc\t";

        reform_string += "skill_attr_desc\t";

        reform_string += "skill_icon_id\t";
        reform_string += "skill_type\t";
        reform_string += "skill_cool_down\t";
        reform_string += "movement_data\t";

        reform_string += "emit_data_start\t";
        reform_string += "emit_data_end\t";
        reform_string += "emit_data_hit_1\t";
        reform_string += "emit_data_hit_2\t";
        reform_string += "emit_data_hit_3\t";

        reform_string += "damage_type\t";
        reform_string += "damage_base\t";
        reform_string += "card_transfer_ratio_physical\t";
        reform_string += "card_transfer_ratio_magical\t";

        reform_string += "level_add_damage\t";
        reform_string += "level_add_attr_type\t";
        reform_string += "level_add_attr_value\t";

        for (std::map<std::string, SkillConfig>::iterator iterator = skill_config_map_.begin(); iterator != skill_config_map_.end(); iterator ++)
        {
          SkillConfig &skill_config = iterator->second;

          reform_string += "\n";
          reform_string += Int2String(skill_config.id) + "\t";
          reform_string += skill_config.key + "\t";
          reform_string += skill_config.desc + "\t";
        
          reform_string += skill_config.skill_attr_desc + "\t";

          reform_string += skill_config.skill_icon + "\t";
          reform_string += Int2String(skill_config.skill_type) + "\t";
          reform_string += Float2String2f(skill_config.skill_cool_down) + "\t";
          reform_string += skill_config.movement_data + "\t";

          reform_string += nest_id_data_list_to_string(skill_config.emit_data_start) + "\t";
          reform_string += nest_id_data_list_to_string(skill_config.emit_data_end) + "\t";
          reform_string += nest_id_data_list_to_string(skill_config.emit_data_hit_1) + "\t";
          reform_string += nest_id_data_list_to_string(skill_config.emit_data_hit_2) + "\t";
          reform_string += nest_id_data_list_to_string(skill_config.emit_data_hit_3) + "\t";

          reform_string += Int2String(skill_config.damage_type) + "\t";
          reform_string += Int2String(skill_config.damage_base) + "\t";
          reform_string += Float2String2f(skill_config.card_transfer_ratio_physical) + "\t";
          reform_string += Float2String2f(skill_config.card_transfer_ratio_magical) + "\t";

          reform_string += Int2String(skill_config.level_add_damage) + "\t";
          reform_string += skill_config.level_add_attr_type + "\t";
          reform_string += Float2String2f(skill_config.level_add_attr_value) + "\t";
        }

        save_string_to_file(reform_string, FILE_NAME_REFORM_SKILL_CONFIG.c_str());
      }












      CCLog("[SaveData] saving effect config... total: %d", effect_config_map_.size());
      //effect config //to text and to file
      {
        std::string reform_string = "[EFFECT_CONFIG]";
        reform_string += "\n";
        reform_string += "id\t";
        reform_string += "key\t";
        reform_string += "desc\t";

        reform_string += "emit_data\t";
        
        reform_string += "animation_type\t";
        reform_string += "animation_name\t";
        reform_string += "duration\t";

        reform_string += "trigger_range_type\t";
        reform_string += "trigger_range_width\t";
        reform_string += "trigger_range_height\t";
        reform_string += "trigger_range_x\t";
        reform_string += "trigger_range_y\t";

        reform_string += "trigger_check_data\t";

        for (std::map<std::string, EffectConfig>::iterator iterator = effect_config_map_.begin(); iterator != effect_config_map_.end(); iterator ++)
        {
          EffectConfig &effect_config = iterator->second;

          reform_string += "\n";
          reform_string += Int2String(effect_config.id) + "\t";
          reform_string += effect_config.key + "\t";
          reform_string += effect_config.desc + "\t";
          reform_string += nest_id_data_list_to_string(effect_config.emit_data) + "\t";
          reform_string += effect_config.animation_type + "\t";
          reform_string += effect_config.animation_name + "\t";
          reform_string += Float2String2f(effect_config.duration) + "\t";
          reform_string += effect_config.trigger_range_type + "\t";
          reform_string += Float2String2f(effect_config.trigger_range_width) + "\t";
          reform_string += Float2String2f(effect_config.trigger_range_height) + "\t";
          reform_string += Int2String(effect_config.trigger_range_x) + "\t";
          reform_string += Int2String(effect_config.trigger_range_y) + "\t";
          reform_string += effect_config.trigger_check_data + "\t";
        }

        save_string_to_file(reform_string, FILE_NAME_REFORM_EFFECT_CONFIG.c_str());
      }




      CCLog("[SaveData] saving effect timeline... total: %d", effect_timeline_map_.size());
      //effect timeline //to text and to file
      {
        std::string reform_string = "[EFFECT_TIMELINE]";
        reform_string += "\n";
        reform_string += "id\t";
        reform_string += "key\t";
        reform_string += "desc\t";
        reform_string += "x\t";
        reform_string += "y\t";
        reform_string += "delay\t";
        reform_string += "duration\t";
        reform_string += "movement_origin_type\t";
        reform_string += "movement_type\t";
        reform_string += "movement_data\t";
        reform_string += "movement_speed\t";
        reform_string += "direction\t";
        reform_string += "direction_type\t";
        reform_string += "animation_item_layer\t";
        reform_string += "animation_item_type\t";
        reform_string += "animation_item_name\t";
        

        for (std::map<std::string, EffectTimeline>::iterator iterator = effect_timeline_map_.begin(); iterator != effect_timeline_map_.end(); iterator ++)
        {
          EffectTimeline &effect_timeline = iterator->second;

          reform_string += "\n";
          reform_string += Int2String(effect_timeline.id) + "\t";
          reform_string += effect_timeline.key + "\t";
          reform_string += effect_timeline.desc + "\t";

          reform_string += Int2String(effect_timeline.x) + "\t";
          reform_string += Int2String(effect_timeline.y) + "\t";
          reform_string += Float2String2f(effect_timeline.delay) + "\t";
          reform_string += Float2String2f(effect_timeline.duration) + "\t";

          for (std::list<EffectTimelineItem>::iterator iterator = effect_timeline.item_list.begin(); iterator != effect_timeline.item_list.end(); iterator ++)
          {
            EffectTimelineItem &effect_timeline_item = *iterator;

            reform_string += "\n";
            reform_string += /*"item" + Int2String(effect_timeline_item.id) + */"\t";
            reform_string += /*effect_timeline_item.key + */"\t";
            reform_string += effect_timeline_item.desc + "\t";

            reform_string += Int2String(effect_timeline_item.x) + "\t";
            reform_string += Int2String(effect_timeline_item.y) + "\t";
            reform_string += Float2String2f(effect_timeline_item.delay) + "\t";
            reform_string += Float2String2f(effect_timeline_item.duration) + "\t";
            
            reform_string += effect_timeline_item.movement_origin_type + "\t";
            reform_string += effect_timeline_item.movement_type + "\t";
            reform_string += effect_timeline_item.movement_data + "\t";
            reform_string += Float2String2f(effect_timeline_item.movement_speed) + "\t";

            reform_string += Int2String(effect_timeline_item.direction) + "\t";
            reform_string += effect_timeline_item.direction_type + "\t";
            
            reform_string += effect_timeline_item.animation_item_layer + "\t";
            reform_string += effect_timeline_item.animation_item_type + "\t";
            reform_string += effect_timeline_item.animation_item_name + "\t";
          }
        }

        save_string_to_file(reform_string, FILE_NAME_REFORM_EFFECT_TIMELINE.c_str());
      }




      CCLog("[SaveData] saving buff status animation... total: %d", buff_status_animation_map_.size());
      //buff status animation //to text and to file
      {
        std::string reform_string = "[BUFF_STATUS_ANIMATION]";
        reform_string += "\n";
        reform_string += "id\t";
        reform_string += "key\t";
        reform_string += "desc\t";
        reform_string += "display_type\t";
        reform_string += "start\t";
        reform_string += "start_type\t";
        reform_string += "loop\t";
        reform_string += "loop_type\t";
        reform_string += "end\t";
        reform_string += "end_type\t";

        for (std::map<std::string, BuffStatusAnimation>::iterator iterator = buff_status_animation_map_.begin(); iterator != buff_status_animation_map_.end(); iterator ++)
        {
          BuffStatusAnimation &buff_status_animation = iterator->second;

          reform_string += "\n";
          reform_string += Int2String(buff_status_animation.id) + "\t";
          reform_string += buff_status_animation.key + "\t";
          reform_string += buff_status_animation.desc + "\t";
          reform_string += buff_status_animation.display_type + "\t";
          reform_string += buff_status_animation.start + "\t";
          reform_string += buff_status_animation.start_type + "\t";
          reform_string += buff_status_animation.loop + "\t";
          reform_string += buff_status_animation.loop_type + "\t";
          reform_string += buff_status_animation.end + "\t";
          reform_string += buff_status_animation.end_type + "\t";
        }

        save_string_to_file(reform_string, FILE_NAME_REFORM_BUFF_STATUS_ANIMATION.c_str());
      }



      CCLog("[SaveData] saving buff config... total: %d", buff_config_map_.size());
      //buff config //to text and to file
      {
        std::string reform_string = "[BUFF_CONFIG]";
        reform_string += "\n";
        reform_string += "id\t";
        reform_string += "key\t";
        reform_string += "desc\t";
        reform_string += "buff_status_animation_id\t";
        reform_string += "is_positive\t";
        reform_string += "buff_key\t";
        reform_string += "replace_type\t";
        reform_string += "stack_type\t";
        reform_string += "apply_data\t";
        reform_string += "buff_data\t";
        reform_string += "mod_data\t";

        
        for (std::map<std::string, BuffConfig>::iterator iterator = buff_config_map_.begin(); iterator != buff_config_map_.end(); iterator ++)
        {
          BuffConfig &buff_config = iterator->second;

          reform_string += "\n";
          reform_string += Int2String(buff_config.id) + "\t";
          reform_string += buff_config.key + "\t";
          reform_string += buff_config.desc + "\t";
          reform_string += Int2String(buff_config.buff_status_animation_id) + "\t";
          reform_string += Int2String(buff_config.is_positive) + "\t";
          reform_string += buff_config.buff_key + "\t";
          reform_string += buff_config.replace_type + "\t";
          reform_string += buff_config.stack_type + "\t";
          reform_string += buff_config.apply_data + "\t";
          reform_string += buff_config.buff_data + "\t";
          reform_string += buff_config.mod_data + "\t";
        }

        save_string_to_file(reform_string, FILE_NAME_REFORM_BUFF_CONFIG.c_str());
      }
    }


    //ActorSkillDataExtractor











    void save_string_to_file(const std::string& string_text, const std::string& file_path)
    {
      //C style save to file
      FILE* file = fopen(file_path.c_str(), "w");
      fwrite(string_text.c_str(), sizeof(char), string_text.size(), file);
      fclose(file);
    }



    void save_json_to_file(const CSJson::Value& root, const std::string& file_path)
    {
      //to JSON string
      //CSJson::FastWriter json_writer;
      CSJson::StyledWriter json_writer;
      std::string json_string = json_writer.write(root);

      save_string_to_file(json_string, file_path);
    }


    //load and return armature data, can be used to check exist
    CCAnimationData* quick_load_armature_animation_data(const std::string& animation_name)
    {
      if(CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(animation_name.c_str()) == NULL)
      {
        std::string skeleton_texture = taomee::kDefaultSkeletonFilePath + animation_name + ".pvr.ccz";
        std::string skeleton_plist = taomee::kDefaultSkeletonFilePath + animation_name + ".plist";
        std::string skeleton_config = taomee::kDefaultSkeletonFilePath + animation_name + ".xml";

        if (CCFileUtils::sharedFileUtils()->isFileExist(CCFileUtils::sharedFileUtils()->fullPathForFilename(skeleton_texture.c_str()))
          && CCFileUtils::sharedFileUtils()->isFileExist(CCFileUtils::sharedFileUtils()->fullPathForFilename(skeleton_plist.c_str()))
          && CCFileUtils::sharedFileUtils()->isFileExist(CCFileUtils::sharedFileUtils()->fullPathForFilename(skeleton_config.c_str())))
        {
          CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(
            skeleton_texture.c_str(), 
            skeleton_plist.c_str(), 
            skeleton_config.c_str());
        }
      }

      return CCArmatureDataManager::sharedArmatureDataManager()->getAnimationData(animation_name.c_str());
    }


  
    std::string quick_load_projectile_animation_data(const std::string& animation_name)
    {
      if (animation_name.empty())
        return "";

      ProjectilesData* projectile_data = DataManager::GetInstance().GetProjectilesDataTable()->GetProjectiles(animation_name);

      if (!projectile_data)
        return "";

      std::string folder = "textures/projectile/";
      const std::string& projectile_name = projectile_data->GetExportName();
      const std::string& particle_name = projectile_data->GetParticleEmitter();

      std::string loaded_content;

      if (projectile_name.size() != 0) 
      {
        string plist_file = folder + projectile_name + ".plist";
        string pvr_ccz_file = folder + projectile_name + ".pvr.ccz";
        string animation_plist_file = folder + projectile_name + "_animation.plist";

        // load animation texture and config 
        CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile(
          plist_file.c_str(),
          pvr_ccz_file.c_str());

        CCAnimationCache::sharedAnimationCache()->addAnimationsWithFile(animation_plist_file.c_str());

        taomee::ProjectileAnimationCacheManager::GetInstance().AddCacheProjectileAnimationInfo(
          plist_file.c_str(), 
          pvr_ccz_file.c_str(), 
          projectile_name.c_str());

        loaded_content += projectile_name + "<projectile>";
      }

      if (particle_name.size() != 0)
      {
        taomee::ParticleManager::GetInstance().Load(particle_name);

        loaded_content += particle_name + "<particle>";
      }

      return loaded_content;
    }



    CSJson::Value extract_armature_animation_movement_frame_data(CCMovementData* movement_data)
    {
      CSJson::Value json_frame_event_tag_data(CSJson::objectValue);
      CSJson::Value json_event_tag_frame_data(CSJson::objectValue);

      CCDictElement *dict_element = NULL;
      CCDictionary *cc_dict = &(movement_data->movBoneDataDic);
      CCDICT_FOREACH(cc_dict, dict_element)
      {
        CCMovementBoneData* movementBoneData = (CCMovementBoneData*)dict_element->getObject();

        CCObject *array_object = NULL;
        CCArray *cc_array = &(movementBoneData->frameList);
        CCARRAY_FOREACH(cc_array, array_object)
        {
          CCFrameData *frameData = (CCFrameData*)array_object;
          std::string event_tag = frameData->strEvent;
        
          //switch release to hit
          if (event_tag == FRAME_EVENT_TAG_RELEASE)
            event_tag = FRAME_EVENT_TAG_HIT;

          if (event_tag.empty() == false)
          {
            std::string frame_id = Int2String(frameData->frameID);
            FIX_JSON_APPEND(json_frame_event_tag_data[frame_id], event_tag);
            FIX_JSON_APPEND(json_event_tag_frame_data[event_tag], frame_id);
          }
        }
      }


      CSJson::Value json_data(CSJson::objectValue);

      if (json_frame_event_tag_data.size() > 0) json_data["frame_event_tag_map"] = json_frame_event_tag_data;
      if (json_event_tag_frame_data.size() > 0) json_data["event_tag_frame_map"] = json_event_tag_frame_data;

      return json_data;
    }


    CSJson::Value extract_armature_animation_movement_data(std::string animation_name, std::string movement_name)
    {
      CSJson::Value json_data(CSJson::objectValue);



      CCAnimationData* animation_data = quick_load_armature_animation_data(animation_name);
      if (!animation_data)
      {
        LOG_ERROR("[extract_armature_animation_movement_data] missing animation_data! animation_name: %s", animation_name.c_str());
        return json_data;
      }

      CCMovementData* movement_data = animation_data->getMovement(movement_name.c_str());
      if (!movement_data)
      {
        LOG_ERROR("[extract_armature_animation_movement_data] missing movement_data! animation_name: %s, movement_name: %s", animation_name.c_str(), movement_name.c_str());
        return json_data;
      }

      //default values
      float frame_per_second = 1.0f / 24.0f;
      float speed_scale = 1.0f;
      int duration_to = -1;
      int duration_tween = -1;

      //movement_data->duration is not use , just as reference, the CCTween may generate more frames
      //get parameter like <CCArmatureAnimation::play>, check for detail meaning
      speed_scale = speed_scale * movement_data->scale;

      duration_to = (duration_to == -1) ? movement_data->durationTo : duration_to;

      duration_tween = (duration_tween == -1) ? movement_data->durationTween : duration_tween;
      duration_tween = (duration_tween == 0) ? movement_data->duration : duration_tween;

      //the normal smooth switch frame count(note if not smooth switch in, no duration_to time)
      int frame_count = duration_to + duration_tween;

      //record data
      json_data["animation_name"] = animation_name;
      json_data["movement_name"] = movement_name;
      json_data["speed_scale"] = speed_scale;
      json_data["duration"] = frame_per_second * frame_count * speed_scale;

      json_data["frame_raw"] = movement_data->duration; //the frame count in data
      json_data["frame_duration_to"] = duration_to;
      json_data["frame_duration_tween"] = duration_tween;
      json_data["frame_data"] = extract_armature_animation_movement_frame_data(movement_data);

      return json_data;
    }


    CSJson::Value extract_armature_animation_data(std::string animation_name)
    {
      CSJson::Value json_data(CSJson::objectValue);

      CCAnimationData* animation_data = quick_load_armature_animation_data(animation_name);
      if (!animation_data)
      {
        LOG_ERROR("[extract_armature_animation_data] missing animation_data! animation_name: %s", animation_name.c_str());
        return json_data;
      }

      std::vector<std::string>::iterator iterator = animation_data->movementNames.begin();
      while (iterator != animation_data->movementNames.end())
      {
        std::string movement_name = *iterator;

        CSJson::Value movement_data = extract_armature_animation_movement_data(animation_name, movement_name);

        if (movement_data.empty() == false)
        {
          json_data[movement_name] = movement_data;
        }

        iterator ++;
      }

      return json_data;
    }



    CSJson::Value extract_projectile_animation_data(std::string animation_name)
    {
      CSJson::Value json_data(CSJson::objectValue);

      std::string loaded_content = quick_load_projectile_animation_data(animation_name);
      if (loaded_content.empty())
      {
        LOG_ERROR("[extract_projectile_animation_data] missing animation_data! animation_name: %s", animation_name.c_str());
        return json_data;
      }

      json_data["content"] = loaded_content;

      return json_data;
    }



    void quick_add_skill_aura_data(CSJson::Value& root, const std::string& aura_id_string, const std::string& aura_type, int aura_apply_possibility, int skill_id)
    {
      if (aura_apply_possibility <= 0 || aura_id_string.empty())
        return;

      std::list<std::string>* aura_id_string_list = ActorStringSplit(std::string(aura_id_string), "/");

      for (std::list<std::string>::iterator iterator = aura_id_string_list->begin(); iterator != aura_id_string_list->end(); ++iterator)
      {
        int aura_id = atoi(iterator->c_str());

        if (aura_id > 0)
        {
          if (DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id))
          {
            root[Int2String(aura_id)]["type"] = aura_type;
            root[Int2String(aura_id)]["apply_possibility"] = aura_apply_possibility;
          }
          else
          {
            LOG_ERROR("[quick_add_skill_aura_data] missing aura aura_id: %d, aura_type: %s, skill_id: %d", aura_id, aura_type, skill_id);
          }
        }
      }

      delete aura_id_string_list;
    }
























    //for enemy boss
    const char* __preset_card_skill_link[] = {
      "80001|40115,40204,40204,40228,40115,40204,40228",
      "80002|50015,50016,50015,50016,50015,50016,50017",
      "80003|50019,50021,50022,50021,50022,50020,50021",
      "80004|40103,40407,40407,40406,40103,40406,40407",
      "80005|40405,40408,40103,40406,40405,40406,40408",
      "80006|40115,40405,40405,40204,40115,40405,40204",
      "80007|50001,40427,40428,50002,40428,40429,50001,50002,40427,40428,40429",
      "80008|40104,40103,40103,40102,40104,40103,40102",
      "80009|40226,40110,40110,40225,40226,40110,40225",
      "80010|40108,40103,40402,40103,40108,40402,40103",
      "80011|50015,50016,50015,50016,50015,50016,50017",
      "80012|40228,40405,40405,40402,40228,40405,40402",
      "80013|40219,40410,40410,40411,40219,40410,40411",
      "80014|40116,40114,40114,40232,40116,40114,40232",
      "80015|40216,40223,40223,40224,40216,40223,40224",
      "80016|50012,50013,50012,50014,50012,50013,50014",
      "80017|50010,0,50011,0,50010,50011,0",
      "80018|40207,40209,40209,40208,40207,40209,40208",
      "80019|40215,40440,40440,40441,40215,40440,40441",
      "80020|40221,40222,40222,0,40221,40222,0",
      "80021|40107,40401,40401,40214,40107,40401,40214",
      "80022|50019,50020,50019,50022,50019,50020,50022",
      "81003|40206,40205,40205,0,40206,40205,0",
      "81005|40210,40211,40211,0,40210,40211,0",
      "81015|40212,40213,40213,40106,40212,40213,40106",
      "80023|50019,50021,50019,50021,50019,50021",
      "80024|50011,40223,50011,40223,50011,40223",
      "80025|40413,40414,40413,40414,16033,40413,40414",
      "80026|16035,16036,16036,16037,16035,16036,16037",
      "80027|16030,16031,16024,16023,16020,16023,16024",
      "80028|15021,40104,92008,40104,92008,40104,40216",
      "80029|16043,194204,93105,50025,16034,50025",
      "80030|95023,70008,60013,160028,60028,160028"
    };
    const int __preset_card_skill_link_size = 33;

    const int __skill_type_array[] = {
      kSkillNormal,
      kSkillPower1,
      kSkillPower2,
      kSkillSpecial,
      kSkillPassive1,
      kSkillPassive2
    };
    const int __skill_type_array_size = 6;

    void add_preset_cark_skill_link(
      std::map<int, std::list<int> >& card_skill_link_map, 
      std::map<int, SkillBase* >& skill_map)
    {
      for (int i = 0; i < __preset_card_skill_link_size; i ++)
      {
        std::string preset_data = __preset_card_skill_link[i];
        std::list<std::string>* card_id_skill_id_data = ActorStringSplit(preset_data, "|");

        std::list<std::string>::iterator iterator_card_id_skill_id = card_id_skill_id_data->begin();
        int card_id = atoi(iterator_card_id_skill_id->c_str());

        std::list<int> &skill_id_list = card_skill_link_map[card_id];

        iterator_card_id_skill_id ++;
        std::list<std::string>* skill_id_data_list = ActorStringSplit(*iterator_card_id_skill_id, ",");

        std::list<std::string>::iterator iterator_skill_id = skill_id_data_list->begin();
        while (iterator_skill_id != skill_id_data_list->end())
        {
          int skill_id = atoi(iterator_skill_id->c_str());

          //check
          if (skill_map.find(skill_id) != skill_map.end())
          {
            skill_id_list.push_back(skill_id);
          }
          else if (skill_id > 0)
          {
            LOG_ERROR("[generate_card_skill_link] skill missing! card_id: %d, skill_id: %d", card_id, skill_id);
            //assert(false);  //skill not found
          }

          iterator_skill_id ++;
        }

        delete card_id_skill_id_data;
        delete skill_id_data_list;
      }
      CCLog("[generate_card_skill_link] added preset card skill link: %d", __preset_card_skill_link_size);
    }


    void map_list_link_deduplication(std::map<int, std::list<int> >& link_map)
    {
      //de-duplicate card_id_list
      std::map<int, std::list<int> >::iterator iterator_link = link_map.begin();
      while (iterator_link != link_map.end())
      {
        std::list<int> &id_list = iterator_link->second;

        //de-duplicate
        id_list.sort();
        id_list.unique();

        iterator_link ++;
      }
    }


    void generate_card_skill_link(
      std::map<int, std::list<int> >& card_skill_link_map, 
      std::map<int, std::list<int> >& skill_card_link_map,
      std::map<int, SkillBase* >& skill_map)
    {
      card_skill_link_map.empty();
      skill_card_link_map.empty();


      //add preset
      add_preset_cark_skill_link(card_skill_link_map, skill_map);


      //loop card
      const vector<int>* card_id_array = &(DataManager::GetInstance().GetCharacterDataTable()->GetAllCharacterID());
      vector<int>::const_iterator iterator_card_id = card_id_array->begin();
      while (iterator_card_id != card_id_array->end())
      {
        int card_id = *iterator_card_id;
        CharacterData* card_data = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id);

        std::list<int> &skill_id_list = card_skill_link_map[card_id];

        for (int i = 0; i < __skill_type_array_size; i ++)
        {
          int skill_type = __skill_type_array[i];
          int skill_id = card_data->GetSkillId(skill_type);

          //check
          if (skill_map.find(skill_id) != skill_map.end())
          {
            skill_id_list.push_back(skill_id);
          }
          else if (skill_id > 0)
          {
            LOG_ERROR("[generate_card_skill_link] skill missing! card_id: %d, skill_id: %d", card_id, skill_id);
            //assert(false);  //skill not found
          }
        }

        iterator_card_id++;
      }
      CCLog("[generate_card_skill_link] get card count: %d", card_skill_link_map.size());


      //de-duplicate card_skill_link_map
      map_list_link_deduplication(card_skill_link_map);


      //reverse create skill
      std::map<int, std::list<int> >::iterator iterator_card_skill_link = card_skill_link_map.begin();
      while (iterator_card_skill_link != card_skill_link_map.end())
      {
        int card_id = iterator_card_skill_link->first;
        std::list<int> &skill_id_list = iterator_card_skill_link->second;

        std::list<int>::iterator iterator_skill_id = skill_id_list.begin();
        while (iterator_skill_id != skill_id_list.end())
        {
          int skill_id = *iterator_skill_id;

          skill_card_link_map[skill_id].push_back(card_id); //no need to check here

          iterator_skill_id ++;
        }

        iterator_card_skill_link ++;
      }
      CCLog("[generate_card_skill_link] get skill card link count: %d", skill_card_link_map.size());


      //de-duplicate skill_card_link_map
      map_list_link_deduplication(skill_card_link_map);
    }


    void quick_check_add_break(
      std::map<int, std::list<int> >& break_skill_link_map, 
      int break_id,
      int skill_id)
    {
      if (break_id <= 0)
      {
        return;
      }

      if (DataManager::GetInstance().GetSkillBrkTable()->TryGetSkillBrk(break_id))
      {
        break_skill_link_map[break_id].push_back(skill_id);
      }
      else
      {
        LOG_ERROR("[quick_check_add_break] missing skill break! break_id: %d, skill_id: %d", break_id, skill_id);
      }
    }

    void generate_skill_break_link(
      std::map<int, std::list<int> >& skill_card_link_map,
      std::map<int, std::list<int> >& break_skill_link_map, 
      std::map<int, SkillBase* >& skill_map)
    {
      break_skill_link_map.empty();


      std::map<int, std::list<int> >::iterator iterator_skill_card_link = skill_card_link_map.begin();
      while (iterator_skill_card_link != skill_card_link_map.end())
      {
        int skill_id = iterator_skill_card_link->first;
        SkillBase* skill_base = static_skill_map[skill_id];


        //break in skill data
        // note the triple break caused by triple hit frame event tag
        int skill_max_hit_count = static_skill_max_hit_count_map.find(skill_id) != static_skill_max_hit_count_map.end() 
          ? static_skill_max_hit_count_map[skill_id].max_hit_count
          : 0;
        int hit_break_id = skill_base->GetTagBreakId(); //will be triggered by hit

        bool is_hit_event_exist = skill_max_hit_count > 0;
        bool is_hit_break_exist = hit_break_id > 0;

        //check valid
        if (is_hit_event_exist != is_hit_break_exist)
        {
          LOG_ERROR("[generate_skill_break_link] error mismatch skill_hit_event - skill_hit_break! hit_event_exist: %d, hit_break_exist: %d, skill_id: %d, hit_break_id: %d",
            is_hit_event_exist,
            is_hit_break_exist, 
            skill_id, 
            hit_break_id);
        }
        else if (is_hit_event_exist)
        {
          while (skill_max_hit_count > 0)
          {
            quick_check_add_break(break_skill_link_map, hit_break_id, skill_id);

            hit_break_id ++;
            skill_max_hit_count --;
          }
        }


        //effect break
        quick_check_add_break(break_skill_link_map, skill_base->GetSelfBreakId(), skill_id);
        quick_check_add_break(break_skill_link_map, skill_base->GetEffBreakId(), skill_id);


        iterator_skill_card_link ++;
      }
      CCLog("[generate_card_skill_link] get break skill link count: %d", break_skill_link_map.size());


      //de-duplicate break_skill_link_map
      map_list_link_deduplication(break_skill_link_map);
    }



    void quick_check_add_aura(
      std::map<int, std::list<int> >& aura_skill_link_map, 
      const std::string& aura_id_string,
      int skill_id)
    {
      if (aura_id_string.empty())
        return;

      std::list<std::string>* aura_id_string_list = ActorStringSplit(std::string(aura_id_string), "/");
      for (std::list<std::string>::iterator iterator = aura_id_string_list->begin(); iterator != aura_id_string_list->end(); ++iterator)
      {
        int aura_id = atoi(iterator->c_str());
        if (aura_id > 0)
        {
          if (DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id))
          {
            aura_skill_link_map[aura_id].push_back(skill_id);
          }
          else
          {
            LOG_ERROR("[json_skill_aura_data] missing skill aura! aura_id: %d, skill_id: %d", aura_id, skill_id);
          }
        }
      }

      delete aura_id_string_list;
    }



    const int __preset_aura_id[] = {
      10031, 10059, 10064, 10101, 10121, 10125, 10126, 
      10127, 10131, 10132, 10133, 10134, 10135, 10136, 
      10138, 10139, 10144, 10145, 20004, 20013, 20017, 
      20027, 20033, 20034, 20037, 29998, 29999, 30000, 
      30001, 30004, 30005, 40001, 50000, 50022, 60005
    };
    const int __preset_aura_id_size = 35;


    void generate_skill_aura_link(
      std::map<int, std::list<int> >& skill_card_link_map,
      std::map<int, std::list<int> >& aura_skill_link_map, 
      std::map<int, SkillBase* >& skill_map)
    {
      aura_skill_link_map.empty();

      //preset
      for (int i = 0; i < __preset_aura_id_size; i ++)
      {
        int aura_id = __preset_aura_id[i];

        if (DataManager::GetInstance().GetAuraDataTable()->GetByID(aura_id))
        {
          aura_skill_link_map[aura_id].push_back(-1);
        }
        else
        {
          LOG_ERROR("[json_skill_aura_data] missing preset aura! aura_id: %d", aura_id);
        }
      }


      std::map<int, std::list<int> >::iterator iterator_skill_card_link = skill_card_link_map.begin();
      while (iterator_skill_card_link != skill_card_link_map.end())
      {
        int skill_id = iterator_skill_card_link->first;
        SkillBase* skill_base = static_skill_map[skill_id];

        //aura in skill data
        quick_check_add_aura(aura_skill_link_map, skill_base->GetTagPlayerStatus(), skill_id);
        quick_check_add_aura(aura_skill_link_map, skill_base->GetSelfStatus(),  skill_id);
        quick_check_add_aura(aura_skill_link_map, skill_base->GetTagStatus(),  skill_id);

        iterator_skill_card_link ++;
      }
      CCLog("[generate_card_skill_link] get aura skill link count: %d", aura_skill_link_map.size());


      //de-duplicate aura_skill_link_map
      map_list_link_deduplication(aura_skill_link_map);
    }





    void collect_card_skill_armature_movement_data(CSJson::Value& root, CharacterData* card_data, SkillBase* skill_base)
    {
      if (skill_base->GetMotion().empty())
      {
        return;
      }

      std::string animation_name = card_data->GetName();
      std::string movement_name = skill_base->GetMotion();

      CCAnimationData* animation_data = quick_load_armature_animation_data(animation_name);
      if (!animation_data)
      {
        LOG_ERROR("[collect_card_skill_armature_movement_data] missing animation for card_id: %d, skill_id: %d, animation: %s", 
          card_data->getID(), 
          skill_base->getSkillID(), 
          animation_name.c_str());
        return;
      }

      CCMovementData* movement_data = animation_data->getMovement(movement_name.c_str());
      if (!movement_data)
      {
        LOG_ERROR("[collect_card_skill_armature_movement_data] missing movement for card_id: %d, skill_id: %d, animation: %s, movement: %s", 
          card_data->getID(), 
          skill_base->getSkillID(), 
          animation_name.c_str(), 
          movement_name.c_str());
        return;
      }

      CSJson::Value json_armature_movement_data(CSJson::objectValue);

      json_armature_movement_data["skill_id"] = skill_base->getSkillID();

      json_armature_movement_data["movement_name"] = movement_name;
      json_armature_movement_data["movement_speed_scale"] = skill_base->GetMotionSpeedRate();
      json_armature_movement_data["movement_cycle_count"] = skill_base->GetMotionCount();

      root[Int2String(skill_base->getSkillID())] = json_armature_movement_data;
    }




  } // namespace data_extractor
} // namespace actor
#endif