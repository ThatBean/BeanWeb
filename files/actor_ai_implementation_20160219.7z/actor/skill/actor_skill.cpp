#include "actor_skill.h"

#include "game/actor/actor.h"
#include "game/actor/animation/actor_animation_skeleton_animation.h"
#include "game/actor/actor_ext/actor_ext_effect.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_config_data_table.h"
#include "game/data_table/card_addon_armature_data_table.h"

#include "engine/script/lua_tinker_manager.h"
#include "engine/base/utils_string.h"

//Skill Data Need To Parse
//Skill Data Need To Parse
//Skill Data Need To Parse

//the basic skill data shared by most sub-data
typedef struct tActorSkillBasicData {
  int     skill_key;
  int     skill_id;
  int     actor_id;

  float skill_duration;
  bool is_hit_frame;
  bool is_release_frame;
} ActorSkillBasicData;


//the animation actor will play during the skill
typedef struct tActorSkillActorAnimationData {
  int skill_id;

  float animation_duration;
  bool is_hit_frame;
  bool is_release_frame;

  std::string animation_name;
  std::string movement_name;
} ActorSkillActorAnimationData;

//Skill Data Need To Parse
//Skill Data Need To Parse
//Skill Data Need To Parse



/*
  Actor Skill
    Skill is Data, packed data for Effect, Damage(but not Buff).

    Life Span:
      Init: 
        need: skill_id, source_actor_link(id + data + dead event + ...)

      Update: 
        play actor animation, create Effect by time/trigger

      OnStart:
        create start Effect

      OnHit: 
        (may or may not), triggered, create hit Effect

      OnEnd:
        create end Effect

      Clear: 
        self removal, when actor animation finished, or forced to stop
*/





namespace actor {


  static std::map<int, bool> skill_key_map;
  int RequestSkillKey(int start_from)
  {
    int possible_valid_id = start_from;
    if (start_from == ACTOR_INVALID_ID) possible_valid_id = skill_key_map.size() > 0 ? skill_key_map.rbegin()->first + 1 : 0; //guess best id
    while (skill_key_map.find(possible_valid_id) != skill_key_map.end()) possible_valid_id++; //check valid
    skill_key_map[possible_valid_id] = true;
    return possible_valid_id;
  }
  void ReturnSkillKey(int skill_key)
  {
    skill_key_map.erase(skill_key);
  }







  Actor* __decide_target_actor_id(const std::list<std::string>& movement_data, Actor* actor, const cocos2d::CCPoint& origin_position)
  {
    if (movement_data.empty() || !actor)
      return NULL;

    std::list<std::string>::const_iterator iterator = movement_data.begin();

    bool is_ally = (*iterator) == "ally";
    iterator ++;
    int index_in_near_first_list = String2Int(*iterator);
    iterator ++;

    bool is_user_support = actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport;
    eActorFactionType target_faction_type = (is_user_support == is_ally) 
      ? kActorFactionUserSupport
      : kActorFactionUserOppose;

    return actor->GetActorExtEnv()->GetActorExtGrid()->QuickGetActorByFactionAndPosition(
      target_faction_type, 
      origin_position, 
      index_in_near_first_list);
  }







  //ActorSkill
  ActorSkill::ActorSkill(Actor* actor)
    : actor_(actor)
    , skill_hit_count_(0)
    , skill_speed_scale_(1.0f)
    , movement_mod_type_(kActorSkillMovementMod)
  {
    
  }

  ActorSkill::~ActorSkill()
  {
    Clear();
  }


  void ActorSkill::Clear()
  { 
    DetachActorAnimationEvent();

    movement_data_list_.clear();

    ReturnSkillKey(skill_link_data_.skill_key);

    skill_link_data_.Clear();

    skill_hit_count_ = 0;

    skill_speed_scale_ = 1.0f;

    movement_mod_type_ = kActorSkillMovementMod;
  }


  void ActorSkill::Update(float delta_time)
  {
    switch (movement_mod_type_)
    {
    case kActorSkillMovementModLine:
      {
        cocos2d::CCPoint origin_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);

        cocos2d::CCPoint speed_vector = movement_mod_position_data_ - origin_position;

        if (speed_vector.getLengthSq() > 100)
        {
          actor_->GetActorData()->SetActorPosition(kActorPositionAnimation,
            origin_position 
            + (speed_vector.normalize() * actor_->GetActorData()->GetActorAttribute(kActorAttributeSpeedMove) * 1.5f * delta_time));
        }
        else
        {
          actor_->GetActorData()->SetActorPosition(kActorPositionAnimation, movement_mod_position_data_);
        }
      }
      break;
    }
  }





  void ActorSkill::StartSkill(int skill_id)
  {
    SkillConfigData* skill_config_data = DataManager::GetInstance().GetSkillConfigDataTable()->GetSkillConfig(skill_id);

    //check valid
    if (!skill_config_data)
    {
      CCLog("[ActorSkill][StartSkill] invalid skill_id: %d!", skill_id);
      assert(false);
      return;
    }
    //check valid

    Clear();

    ActorSkillInfo*  skill_info = actor_->GetActorData()->GetSkillData()->GetSkillInfoById(skill_id);

    //pack link data
    skill_link_data_.skill_key = RequestSkillKey(ACTOR_INVALID_ID);
    skill_link_data_.skill_id = skill_id;
    skill_link_data_.actor_id = actor_->GetScriptObjectId();
    //quick access
    skill_link_data_.actor_level = actor_->GetActorData()->GetActorStatus(kActorStatusLevel);
    skill_link_data_.skill_level = skill_info ? skill_info->skill_level : 0;
    skill_link_data_.skill_config_data = skill_config_data;

    //pack animation data
    movement_data_list_ = skill_config_data->GetActorMovementData(); //copy

    //adjust skill speed scale if is normal attack
    if (skill_info && skill_info->skill_type == kActorSkillNormal && actor_->GetAnimation()->GetAnimationSkeletonAnimation())
    {
      float normal_attack_per_second = actor_->GetActorData()->GetActorAttribute(kActorAttributeSpeedAttack);

      if (normal_attack_per_second <= 0)
      {
        actor_->GetActorData()->GetLog()->AddErrorLogF("[ActorSkill][StartSkill] error normal_attack_per_second: %f", normal_attack_per_second);
        normal_attack_per_second = 1.0f;
        //EndSkill(); //return;
      }


      //get total animation duration
      float normal_attack_animation_duration = 0.0f;
      cocos2d::extension::CCArmature* actor_armature = actor_->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->GetArmatureNode();
      for (std::list<ActorSkillMovementData>::iterator iterator = movement_data_list_.begin(); iterator != movement_data_list_.end(); iterator ++)
      {
        ActorSkillMovementData& skill_movement_data = *iterator;

        if (skill_movement_data.movement_name.empty())
          continue;

        normal_attack_animation_duration += ActorAnimation::GetAnimationMovementDuration(
          actor_armature->getArmatureData()->name, 
          skill_movement_data.movement_name,
          1.0f / 24.0f,  //FPS, check <CCProcessBase - m_fAnimationInternal>
          1.0f, //FPS scale of each frame
          -1,   //Set to 0 if no movement change exist; The frame set to generate for changing to this animation
          -1) * skill_movement_data.speed_scale;
      }

      if (normal_attack_animation_duration <= 0)
      {
        actor_->GetActorData()->GetLog()->AddErrorLogF("[ActorSkill][StartSkill] error normal_attack_animation_duration: %f", normal_attack_animation_duration);
        EndSkill();
        return;
      }

      float normal_attack_data_duration = 1.0f / normal_attack_per_second;
      skill_speed_scale_ = normal_attack_animation_duration / normal_attack_data_duration;
    }

    actor_->GetActorData()->SetActorStatusBool(kActorStatusSkillIsBusy, true);  //lock motion

    //attach skill event
    AttachActorAnimationEvent();

    OnStart();
  }


  void ActorSkill::EndSkill()
  {
    actor_->GetActorData()->SetActorStatusBool(kActorStatusSkillIsBusy, false); //unlock motion

    //detach skill event
    DetachActorAnimationEvent();

    Clear();
  }




  void ActorSkill::OnStart()
  {
    //emit
    actor_->GetActorExtEnv()->ApplyEmitDataList(skill_link_data_.skill_config_data->GetEmitDataStart(), skill_link_data_.actor_id, skill_link_data_);

    //play movement
    OnMovement();
  }


  void ActorSkill::OnMovement()
  {

    //animation
    if (movement_data_list_.empty())
    {
      //no more moves
      OnEnd();
      return;
    }
    else
    {
      //play movement
      ActorSkillMovementData movement_data = *(movement_data_list_.begin());
      movement_data_list_.pop_front();

      //reset hit count
      skill_hit_count_ = 0;


      movement_mod_type_ = kActorSkillMovementMod;

      if (movement_data.movement_mod_data)
      {
        //movement mod logic
        switch (movement_data.movement_mod_data->mod_type)
        {
        case kActorSkillMovementModBlink:
        case kActorSkillMovementModLine:
          {
            movement_mod_type_ = movement_data.movement_mod_data->mod_type;

            cocos2d::CCPoint origin_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);

            Actor* target_actor = __decide_target_actor_id(
              movement_data.movement_mod_data->argument_list, 
              actor_, 
              origin_position);

            if (target_actor)
            {
              cocos2d::CCPoint target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

              bool is_target_facing_right = target_actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) ==kActorAnimationDirectionRight;

              target_position.x += (is_target_facing_right ? 1 : -1) 
                * 0.5 * (actor_->GetAnimation()->GetActorBox().size.width
                  + target_actor->GetAnimation()->GetActorBox().size.width);

              switch (movement_data.movement_mod_data->mod_type)
              {
              case kActorSkillMovementModBlink:
                actor_->GetActorData()->SetActorPosition(kActorPositionAnimation, target_position);
                break;
              case kActorSkillMovementModLine:
                movement_mod_position_data_ = target_position;
                break;
              }
            }
          }
          break;
        }
      }

      if (movement_data.movement_name.empty() == false)
      {
        bool is_success = actor_->GetAnimation()->GetAnimationSkeletonAnimation()->ChangeMovement(movement_data.movement_name, 1, movement_data.speed_scale * skill_speed_scale_);

        if (!is_success)
        {
          OnEnd();
          return;
        }
      }
      else
      {
        OnMovement();
        return;
      }
    }
  }


  void ActorSkill::OnHit()
  {
    //emit by skill_hit_count_
    switch (skill_hit_count_)
    {
    case 0:
      actor_->GetActorExtEnv()->ApplyEmitDataList(skill_link_data_.skill_config_data->GetEmitDataHit1(), skill_link_data_.actor_id, skill_link_data_);
      break;
    case 1:
      actor_->GetActorExtEnv()->ApplyEmitDataList(skill_link_data_.skill_config_data->GetEmitDataHit2(), skill_link_data_.actor_id, skill_link_data_);
      break;
    case 2:
      actor_->GetActorExtEnv()->ApplyEmitDataList(skill_link_data_.skill_config_data->GetEmitDataHit3(), skill_link_data_.actor_id, skill_link_data_);
      break;
    }

    skill_hit_count_ ++;
  }


  void ActorSkill::OnEnd()
  {
    //emit
    actor_->GetActorExtEnv()->ApplyEmitDataList(skill_link_data_.skill_config_data->GetEmitDataEnd(), skill_link_data_.actor_id, skill_link_data_);

    //report to skill data
    actor_->GetActorData()->GetSkillData()->FinishedSkill(skill_link_data_.skill_id);

    EndSkill();
  }










  void ActorSkill::AttachActorAnimationEvent()
  {
    DetachActorAnimationEvent();

    movement_event_connection_ = actor_->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->SubscribeActionEvent<ActorSkill>(this, &ActorSkill::OnActorAnimationMovementEvent);
    frame_event_connection_ = actor_->GetAnimation()->GetAnimationSkeletonAnimation()->GetSkeletonAnimationNode()->SubscribeFrameEvent<ActorSkill>(this, &ActorSkill::OnActorAnimationFrameEvent);
  }
  void ActorSkill::DetachActorAnimationEvent()
  {
    movement_event_connection_.disconnect();
    frame_event_connection_.disconnect();
  }


  void ActorSkill::OnActorAnimationMovementEvent(cocos2d::extension::CCArmature* armature,
    cocos2d::extension::MovementEventType event_type,
    const char* movement_name)
  {
    switch (event_type)
    {
    case cocos2d::extension::START:
      //check unexpected movement change
//       actor_->GetActorData()->GetLog()->AddErrorLogF("[ActorSkill][OnActorAnimationMovementEvent] unexpected movement change, stop current skill_id: %d", skill_link_data_.skill_id);
//       //assert(false);
//       EndSkill();
      break;
    case cocos2d::extension::COMPLETE:
      //finished current movement, play next movement
      OnMovement();
      break;
    }
  }
  void ActorSkill::OnActorAnimationFrameEvent(cocos2d::extension::CCBone *bone,
    const char* frame_event_name,
    int origin_frame_index,
    int current_frame_index)
  {
    std::string frame_event_name_string = frame_event_name;

    //check card addon armature
    CardAddonArmatureData* card_addon_armature_data = DataManager::GetInstance().GetCardAddonArmatureDataTable()->GetCardAddonArmatureByCardIdSkillIdEventTag(
      actor_->GetActorData()->GetActorStatus(kActorStatusCardId), 
      skill_link_data_.skill_id,
      frame_event_name_string);
    
    if (card_addon_armature_data)
    {
      actor::ActorAnimationQueueData queue_data; 
      queue_data.animation_type = actor::kActorAnimationQueueDataArmature;
      queue_data.animation_name = "bsj";
      queue_data.armature_name = card_addon_armature_data->GetCardAddonArmatureName();
      queue_data.position = CCPointZero;
      queue_data.rotation = 0;
      queue_data.is_filp_x = (actor_->GetActorData()->GetActorStatus(actor::kActorStatusAnimationDirection) == actor::kActorAnimationDirectionRight);
      queue_data.loop_count = 1;

      actor::ActorAnimationQueue* animation_queue = actor_->GetAnimation()->CreateAnimationQueue();
      animation_queue->Append(queue_data);
      animation_queue->AutoPlayAndDetach();//just play on and release for auto delete
    }


    if (frame_event_name_string == GetFrameEventName(kFrameEventRelease) 
      || frame_event_name_string == GetFrameEventName(kFrameEventHit))
    {
      OnHit();
    }
  }

  std::string ActorSkill::GetDebugInfo(Actor* actor, const std::string& pre_text)
  {
    std::ostringstream string_stream;  // associate stream buffer to stream

    ActorSkill* actor_skill = actor->GetSkill();

    if (actor_skill->skill_link_data_.skill_key == ACTOR_INVALID_ID)
    {
      return string_stream.str();
    }
    
    string_stream << pre_text << " >SkillHitCount" << actor_skill->skill_hit_count_ << std::endl;
    string_stream << pre_text << " >SkillSpeedScale" << actor_skill->skill_speed_scale_ << std::endl;

    string_stream << pre_text << " >SkillLinkData>SkillKey" << actor_skill->skill_link_data_.skill_key << std::endl;
    string_stream << pre_text << " >SkillLinkData>SkillId" << actor_skill->skill_link_data_.skill_id << std::endl;
    string_stream << pre_text << " >SkillLinkData>SkillLevel" << actor_skill->skill_link_data_.skill_level << std::endl;
    string_stream << pre_text << " >SkillLinkData>ActorId" << actor_skill->skill_link_data_.actor_id << std::endl;
    string_stream << pre_text << " >SkillLinkData>ActorLevel" << actor_skill->skill_link_data_.actor_level << std::endl;
    for (std::list<int>::iterator iterator = actor_skill->skill_link_data_.target_actor_id_list.begin(); iterator != actor_skill->skill_link_data_.target_actor_id_list.end(); iterator ++)
    {
      int target_actor_id = *iterator;
      string_stream << pre_text << " >SkillLinkData>TargetActorId" << target_actor_id << std::endl;
    }

    return string_stream.str();
  }
  //ActorSkill

} // namespace actor