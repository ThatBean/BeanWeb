#include "actor_motion_state_idle.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_animation_data_typedef.h"

namespace actor {

  const int MotionStateIdle::STATE_TYPE = kActorMotionStateIdle;

  MotionStateIdle* MotionStateIdle::Instance()
  {
    static MotionStateIdle instance;
    return &instance;
  }


  void MotionStateIdle::OnEnter(Actor* actor)
  {
    actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
  }

  void MotionStateIdle::OnExit(Actor* actor)
  {

  }

  void MotionStateIdle::Update(Actor* actor, float delta_time)
  {

  }
} // namespace actor