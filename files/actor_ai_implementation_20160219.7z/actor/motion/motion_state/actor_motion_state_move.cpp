#include "actor_motion_state_move.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_animation_data_typedef.h"

namespace actor {

  const int MotionStateMove::STATE_TYPE = kActorMotionStateMove;

  MotionStateMove* MotionStateMove::Instance()
  {
    static MotionStateMove instance;
    return &instance;
  }


  void MotionStateMove::OnEnter(Actor* actor)
  {
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, true);
    actor->GetAnimation()->ChangeMovement(kActorAnimationMovementWalk);
  }

  void MotionStateMove::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetActorPositionData(kActorPositionMotionMoveTarget)->Reset();

    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
  }

  void MotionStateMove::Update(Actor* actor, float delta_time)
  {
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    bool is_set_target = false;
    cocos2d::CCPoint target_position;

    //check target available
    ActorControlOperationData* operation_position_move_data = control_data->CheckOperationData(kActorControlOperationPositionMove) ? control_data->GetOperationData(kActorControlOperationPositionMove) : NULL;
    ActorControlOperationData* operation_id_target_move_data = control_data->CheckOperationData(kActorControlOperationIdTargetMove) ? control_data->GetOperationData(kActorControlOperationIdTargetMove) : NULL;
    if (operation_position_move_data && (!operation_id_target_move_data || (operation_position_move_data->priority > operation_id_target_move_data->priority)))
    {  
      target_position = operation_position_move_data->data_position;
      is_set_target = true;
    }
    else if (operation_id_target_move_data && (!operation_position_move_data || (operation_id_target_move_data->priority > operation_position_move_data->priority)))
    {
      Actor* target_actor = actor->GetActorExtEnv()->GetActorById(operation_id_target_move_data->data_id);

      if (target_actor && target_actor->GetIsActorAlive())
      {
        target_position = target_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
        is_set_target = true;
      }
      else
      {
        control_data->RemoveOperationData(kActorControlOperationIdTargetMove);
      }
    }
    
    if (is_set_target) 
      UpdateMoveToPosition(actor, delta_time, target_position); //update move
    else 
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false); //lost target
  }


  void MotionStateMove::UpdateMoveToPosition(Actor* actor, float delta_time, cocos2d::CCPoint target_position)
  {
    //check if target changed, and update MoveSpeedUnit
    if (actor->GetActorData()->GetActorPosition(kActorPositionMotionMoveTarget).equals(target_position) == false)
    {
      actor->GetActorData()->SetActorPosition(kActorPositionMotionMoveTarget, target_position);
    }

    //limit time delta
    delta_time = (delta_time > 0.1 ? 0.1 : delta_time);

    cocos2d::CCPoint animation_position = actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

    //calculate delta move
    float speed_scalar = actor->GetActorData()->GetActorAttribute(kActorAttributeSpeedMove) * delta_time;
    cocos2d::CCPoint move_speed_unit = actor->GetActorData()->GetActorPosition(kActorPositionMotionMoveSpeedUnit);
    cocos2d::CCPoint move_delta_vector = ccp(move_speed_unit.x * speed_scalar, move_speed_unit.y * speed_scalar);

    float move_distance = animation_position.getDistance(target_position);
    if (move_distance <= speed_scalar)
    {
      //Reached Position
      actor->GetActorData()->SetActorPosition(kActorPositionAnimation, target_position);
      actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
    }
    else
    {
      //update animation position
      actor->GetActorData()->SetActorPosition(kActorPositionAnimation, ccpAdd(animation_position, move_delta_vector));
    }
  }

} // namespace actor