#include "actor_motion_state_incontrollable.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_animation_data_typedef.h"

namespace actor {

  const int MotionStateIncontrollable::STATE_TYPE = kActorMotionStateIncontrollable;

  MotionStateIncontrollable* MotionStateIncontrollable::Instance()
  {
    static MotionStateIncontrollable instance;
    return &instance;
  }

  void MotionStateIncontrollable::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateIncontrollable][OnExit]");

    //should assist buff system to adjust actor animation
    switch (actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationTypeIncontrollable))
    {
    case kActorIncontrollableBuff:
      {
        ActorBuffStatusBitSet status_bit_set = actor->GetActorData()->GetBuffData()->GetBuffStatusBitSet();

        //animation
        if (status_bit_set[kActorBuffStatusStiff])
        {
          bool is_success = actor->GetAnimation()->ChangeMovement(kActorAnimationMovementStiff);
          if (is_success) actor->GetAnimation()->ChangeMovement(kActorAnimationMovementDead); //fail safe
        }
        else if (status_bit_set[kActorBuffStatusKnockBack])
        {
          bool is_success = actor->GetAnimation()->ChangeMovement(kActorAnimationMovementKnockBack);
          if (is_success) actor->GetAnimation()->ChangeMovement(kActorAnimationMovementDead); //fail safe
        }
        else
        {
          actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
        }
      }
      break;
    case kActorIncontrollableSkill:
    case kActorIncontrollableScript:
    case kActorIncontrollable:
    default:
      //should check
      actor->GetAnimation()->ChangeMovement(kActorAnimationMovementIdle);
      break;
    }

    //Always Give Motion control to Buff system
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);
  }

  void MotionStateIncontrollable::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetLog()->AddLog("[MotionStateIncontrollable][OnExit]");
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false); //for Force Exit
  }

  void MotionStateIncontrollable::Update(Actor* actor, float delta_time)
  {
    //Always Give Motion control to Buff system
    actor->GetActorData()->SetActorStatusBool(kActorStatusMotionIsBusy, false);

    switch (actor->GetActorData()->GetControlData()->GetIdOperationData(kActorControlOperationTypeIncontrollable))
    {
    case kActorIncontrollableBuff:
      {
        ActorBuffStatusBitSet status_bit_set = actor->GetActorData()->GetBuffData()->GetBuffStatusBitSet();

        //animation
        if (status_bit_set[kActorBuffStatusKnockBack])
        {
          bool is_actor_facing_right = actor->GetActorData()->GetActorStatus(kActorStatusAnimationDirection) == kActorAnimationDirectionRight;
          cocos2d::CCPoint knock_back_speed_vector((is_actor_facing_right ? -1 : 1) * GetGridBoxAverageWidth() * 2, 0.0f);

          actor->GetActorData()->SetActorPosition(kActorPositionAnimation, actor->GetActorData()->GetActorPosition(kActorPositionAnimation) + knock_back_speed_vector * delta_time);
        }
      }
      break;
    case kActorIncontrollableSkill:
    case kActorIncontrollableScript:
    case kActorIncontrollable:
    default:
      break;
    }
  }

} // namespace actor