#ifndef ACTOR_GRID_TYPEDEF_H
#define ACTOR_GRID_TYPEDEF_H



namespace actor {


  // [Actor Grid]		
  //
  //    grid_x |                             |
  //      0    |  1   2   3      4   5   6   |    7
  //  x_extend | Left                  Right | x_extend
  //           |                             |
  //           |                             |          4    y_extend
  //  ---------|-----------------------------|---------------
  //           |                             |          3    Top
  //           |     <The Battle field>      |          2
  //           |                             |          1    Bottom
  //  ---------|-----------------------------|---------------
  //           |                             |          0    y_extend
  //           |                             |        grid_y


  // metric for auto grid calculation
  const float METRIC_GRID_TOP_LEFT_X = 109.84f;
  const float METRIC_GRID_TOP_LEFT_Y = 445.31f;

  const float METRIC_GRID_TOP_RIGHT_X = 1026.16f;
  const float METRIC_GRID_TOP_RIGHT_Y = 445.31f;

  const float METRIC_GRID_BOTTOM_LEFT_X = 73.84f;
  const float METRIC_GRID_BOTTOM_LEFT_Y = 46.70f;

  const float METRIC_GRID_BOTTOM_RIGHT_X = 1062.16f;
  const float METRIC_GRID_BOTTOM_RIGHT_Y = 46.70f;


  const int GRID_X_RANGE = 6;
  const int GRID_X_EXTEND = 1; // default grid x range is [1 - GRID_X_EXTEND, GRID_X_RANGE + GRID_X_EXTEND]

  const int GRID_Y_RANGE = 3;
  const int GRID_Y_EXTEND = 1; // default grid x range is [1 - GRID_Y_EXTEND, GRID_Y_RANGE + GRID_Y_EXTEND]

  const int PLAYER_IDLE_VALID_GRID_X_RANGE = 4; // for player controlled actor in PVE


  //auto calculated
  const int GRID_X_RANGE_LEFT = 1;
  const int GRID_X_RANGE_RIGHT = GRID_X_RANGE_LEFT + (GRID_X_RANGE - 1);

  const float GRID_X_RANGE_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE) * 0.5;
  const float GRID_X_RANGE_LEFT_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE_MIDDLE) * 0.5;
  const float GRID_X_RANGE_RIGHT_MIDDLE = (GRID_X_RANGE_MIDDLE + GRID_X_RANGE_RIGHT) * 0.5;


  const int GRID_Y_RANGE_BOTTOM = 1;
  const int GRID_Y_RANGE_TOP = GRID_Y_RANGE_BOTTOM + (GRID_Y_RANGE - 1);

  const float GRID_Y_RANGE_MIDDLE = (GRID_Y_RANGE_BOTTOM + GRID_Y_RANGE) * 0.5;


  const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = GRID_X_RANGE_LEFT + (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = GRID_X_RANGE_RIGHT - (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);

} // namespace actor



#endif // ACTOR_GRID_TYPEDEF_H