#ifndef ACTOR_SKILL_DATA_TYPEDEF_H
#define ACTOR_SKILL_DATA_TYPEDEF_H

#include "actor_data_typedef.h"
#include <string>
#include <list>

namespace actor {

  enum eActorSkillMovementModType {
    kActorSkillMovementModBlink = 1,
    kActorSkillMovementModLine,

    kActorSkillMovementMod = -1
  };

  class ActorSkillMovementModData {
  public:
    ActorSkillMovementModData()
      : mod_type(kActorSkillMovementMod)
    {}
  public:
    eActorSkillMovementModType mod_type;
    std::list<std::string> argument_list;
  };

  class ActorSkillMovementData {
  public:
    ActorSkillMovementData()
      : speed_scale(1.0f)
      , movement_mod_data(NULL)
    {}
  public:
    std::string movement_name;
    float speed_scale;
    ActorSkillMovementModData* movement_mod_data;
  };


} // namespace actor

#endif // ACTOR_SKILL_DATA_TYPEDEF_H