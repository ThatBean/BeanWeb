#ifndef ACTOR_ANIMATION_DATA_TYPEDEF_H
#define ACTOR_ANIMATION_DATA_TYPEDEF_H

#include <string>

namespace actor {

  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_CIRCLE = "attack_range_circle_red.png";
  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_BOX    = "attack_red.png";

  const std::string kActorAnimationMovementIdle         = "idle";
  const std::string kActorAnimationMovementIdleWeak     = "weak";

  const std::string kActorAnimationMovementWalk         = "walk";
  const std::string kActorAnimationMovementWalkWeak     = "weak_walk";

  const std::string kActorAnimationMovementStiff        = "behit";
  const std::string kActorAnimationMovementKnockBack    = "behit";

  const std::string kActorAnimationMovementDead         = "dead";
  const std::string kActorAnimationMovementDeadExplode  = "dead_2";


  const float ACTOR_WEAK_THRESHOLD = 0.20f; //health ratio
  
  const float ACTOR_DIRECTION_CHANGE_THRESHOLD = 20;  //the minimum distance needed for a direction change

  const float ACTOR_ANIMATION_HEALTH_DISPLAY_TIME = 2.0f; //The health display time

} // namespace actor

#endif // ACTOR_ANIMATION_DATA_TYPEDEF_H