#ifndef ACTOR_MODEL_TYPEDEF_H
#define ACTOR_MODEL_TYPEDEF_H


namespace actor {

  enum eActorModuleType {
    kActorModuleScriptExporter  = 1 << 0,
    kActorModuleData            = 1 << 1,
    kActorModuleAnimation       = 1 << 2,
    kActorModuleControl         = 1 << 3,
    kActorModuleLogic           = 1 << 4,
    kActorModuleMotion          = 1 << 5,
    kActorModuleSkill           = 1 << 6,
    kActorModuleBuff            = 1 << 7,

    kActorModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_MODEL_ACTOR = 0
    | kActorModuleScriptExporter
    | kActorModuleData
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleSkill
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_MODEL_EFFECT = 0
    | kActorModuleScriptExporter
    | kActorModuleData
    | kActorModuleAnimation
    | 0;
  const unsigned long ACTOR_MODEL_DATA = 0
    | kActorModuleScriptExporter
    | kActorModuleData
    | 0;


  //data dependency
  const unsigned long ACTOR_DATA_DEPENDENCY_BASIC = 0
    | kActorModuleLogic
    | kActorModuleMotion
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_SKILL = 0
    | kActorModuleControl
    | kActorModuleLogic
    | kActorModuleMotion
    | kActorModuleSkill
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_BUFF = 0
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_DAMAGE = 0
    | kActorModuleAnimation
    | kActorModuleBuff
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_CONTROL = 0
    | kActorModuleScriptExporter
    | kActorModuleAnimation
    | kActorModuleControl
    | kActorModuleBuff
    | kActorModuleLogic
    | kActorModuleMotion
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_LOGIC = 0
    | kActorModuleLogic
    | 0;
  const unsigned long ACTOR_DATA_DEPENDENCY_MOTION = 0
    | kActorModuleMotion
    | 0;
  


  enum eActorAnimationModuleType {
    kActorAnimationModuleSkeletonAnimation  = 1 << 0,
    kActorAnimationModuleOverheadLayer      = 1 << 1,
    kActorAnimationModuleBottomSyncLayer    = 1 << 2,
    kActorAnimationModuleEffect             = 1 << 3,
    //kActorAnimationModule = 1 << 0,
    kActorAnimationModule = -1
  };

  //packed actor type
  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR = 0
    | kActorAnimationModuleSkeletonAnimation
    //| kActorAnimationModuleEffect
    | kActorAnimationModuleOverheadLayer
    | kActorAnimationModuleBottomSyncLayer
    | 0;
  const unsigned long ACTOR_ANIMATION_MODEL_ACTOR_LITE = 0
    | kActorAnimationModuleSkeletonAnimation
    //| kActorAnimationModuleEffect
    | kActorAnimationModuleOverheadLayer
    //| kActorAnimationModuleBottomSyncLayer
    | 0;
  const unsigned long ACTOR_ANIMATION_MODEL_EFFECT = 0
    //| kActorAnimationModuleSkeletonAnimation
    | kActorAnimationModuleEffect
    //| kActorAnimationModuleOverheadLayer
    //| kActorAnimationModuleBottomSyncLayer
    | 0;
  const unsigned long ACTOR_ANIMATION_MODEL_DATA = 0
    //| kActorAnimationModuleSkeletonAnimation
    //| kActorAnimationModuleEffect
    //| kActorAnimationModuleOverheadLayer
    //| kActorAnimationModuleBottomSyncLayer
    | 0;


  //Model
  enum eActorModelType {
    kActorModelActor = ACTOR_MODEL_ACTOR,
    kActorModelEffect = ACTOR_MODEL_EFFECT,
    kActorModelData = ACTOR_MODEL_DATA,
    //kActorModel = 1 << 0,
    kActorModel = -1
  };

  enum eActorAnimationModelType {
    kActorAnimationModelActor = ACTOR_ANIMATION_MODEL_ACTOR,
    kActorAnimationModelActorLite = ACTOR_ANIMATION_MODEL_ACTOR_LITE,
    kActorAnimationModelEffect = ACTOR_ANIMATION_MODEL_EFFECT,
    kActorAnimationModelData = ACTOR_ANIMATION_MODEL_DATA,
    //kActorAnimationModel = 1 << 0,
    kActorAnimationModel = -1
  };

} // namespace actor



#endif // ACTOR_MODEL_TYPEDEF_H