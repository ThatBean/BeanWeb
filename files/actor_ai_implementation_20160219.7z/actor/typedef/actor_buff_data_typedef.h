#ifndef ACTOR_BUFF_DATA_TYPEDEF_H
#define ACTOR_BUFF_DATA_TYPEDEF_H

#include "actor_data_typedef.h"

namespace actor {

  const int ACTOR_DEFAULT_BUFF_ID_STIFF = 1;
  const int ACTOR_DEFAULT_BUFF_ID_KNOCK_BACK_S = 11;
  const int ACTOR_DEFAULT_BUFF_ID_KNOCK_BACK_M = 12;
  const int ACTOR_DEFAULT_BUFF_ID_KNOCK_BACK_L = 13;
  const int ACTOR_DEFAULT_BUFF_ID_KNOCK_BACK_XL = 14;

  //Buff
  enum eActorBuffStatusStateOperationType { 
    kActorBuffStatusStateOperationAdd = 1,
    kActorBuffStatusStateOperationSub,
    kActorBuffStatusStateOperationImmuneAdd,
    kActorBuffStatusStateOperationImmuneSub,

    kActorBuffStatusStateOperation = -1
  };
  enum eActorBuffStatusType { //each status represents on, off, immune
    kActorBuffStatusDebug = 1,
    //kActorBuffStatusAll, //Multi-Status

    kActorBuffStatusMuteAllPositive,
    kActorBuffStatusMuteAllNegative,

    kActorBuffStatusAutoMove,
    kActorBuffStatusMuteMove,

    //kActorBuffStatusMuteAttack, //Multi-Status
    kActorBuffStatusMuteAttackNormal,
    kActorBuffStatusMuteAttackPower,
    kActorBuffStatusMuteAttackSpecial,

    //kActorBuffStatusMuteReceiveDamageAll, //Multi-Status
    kActorBuffStatusMuteReceiveDamagePhysical,
    kActorBuffStatusMuteReceiveDamageMagical,

    kActorBuffStatusBlind,
    kActorBuffStatusSlience,
    kActorBuffStatusInvisible,

    kActorBuffStatusStiff, //Apply BuffId: 1
    kActorBuffStatusKnockBack, //Speed: 2 Grid/Sec

    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
    kActorBuffStatusStun,
    kActorBuffStatusInterwine,
    kActorBuffStatusFear,
    kActorBuffStatusCharmed,

    //kActorBuffStatusElementAll, //Multi-Status
    kActorBuffStatusElementFire,
    kActorBuffStatusElementWater,
    kActorBuffStatusElementWind,
    kActorBuffStatusElementLight,
    kActorBuffStatusElementDark,

    kActorBuffStatusMax,

    kActorBuffStatus = -1
  };
  typedef std::bitset<kActorBuffStatusMax> ActorBuffStatusBitSet;





  enum eActorBuffConfigApplyType {
    kActorBuffConfigApplyLimitTime        = 1 << 0,
    kActorBuffConfigApplyLimitCount       = 1 << 1,
    kActorBuffConfigApplyLimitEvent       = 1 << 2,
    kActorBuffConfigApplyLimitCondition   = 1 << 3,

    kActorBuffConfigApplyTriggerOnCreate  = 1 << 4,
    kActorBuffConfigApplyTriggerTime      = 1 << 5,
    kActorBuffConfigApplyTriggerEvent     = 1 << 6,
    kActorBuffConfigApplyTriggerCondition = 1 << 7,

    kActorBuffConfigApply = 0
  };


  enum eActorBuffConfigEventFilterType {
    kActorBuffConfigEventFilterSelf   = 1 << 0,
    kActorBuffConfigEventFilterAlly   = 1 << 1,
    kActorBuffConfigEventFilterEnemy  = 1 << 2,

    kActorBuffConfigEventFilterNone   = ((1 << 3) - 1),

    kActorBuffConfigEventFilter = 0
  };


  enum eActorBuffConfigConditionType {
    kActorBuffConfigConditionCheckValuePerChange = 1,
    kActorBuffConfigConditionCheckValuePerAbove,
    kActorBuffConfigConditionCheckValuePerBelow,

    kActorBuffConfigCondition = -1
  };


  enum eActorBuffConfigCheckDataType {
    kActorBuffConfigCheckDataHealthPercent = 1,

    kActorBuffConfigCheckDataAttackCount,
    kActorBuffConfigCheckDataAttackCountNormal,
    kActorBuffConfigCheckDataAttackCountPower,
    kActorBuffConfigCheckDataAttackCountSpecial,
    kActorBuffConfigCheckDataAttackCountPowerSpecial,

    kActorBuffConfigCheckDataKillCount,

    kActorBuffConfigCheckData = -1
  };


  enum eActorBuffConfigReplaceType {
    kActorBuffConfigReplaceAddNew = 1,
    kActorBuffConfigReplaceReplacePrevious,
    kActorBuffConfigReplaceReplacePreviousOnly,

    kActorBuffConfigReplace = -1
  };


  enum eActorBuffConfigStackType {
    //non-stack
    kActorBuffConfigStackDropNew = 1,
    kActorBuffConfigStackCreate,

    //stack
    kActorBuffConfigStackReset,
    kActorBuffConfigStackMerge,

    kActorBuffConfigStack = -1
  };


  class ActorBuffConfigApplyData
  {
  public:
    ActorBuffConfigApplyData()
      : apply_flag(kActorBuffConfigApply)

      , limit_time(-1)
      , is_revert_on_end(false)
      , revert_start_time(0.0f)
      , revert_tick_count(-1)

      , limit_count(-1)

      , limit_event(kActorEvent)
      , limit_event_filter_flag(kActorBuffConfigEventFilter)

      , limit_condition(kActorBuffConfigCondition)
      , limit_condition_extra_data_int(0)
      , limit_condition_extra_data_float(0.0f)

      , trigger_time(-1)

      , trigger_event(kActorEvent)
      , trigger_event_filter_flag(kActorBuffConfigEventFilter)

      , trigger_condition(kActorBuffConfigCondition)
      , trigger_condition_extra_data_int(0)
      , trigger_condition_extra_data_float(0.0f)
    {}

  public:
    int apply_flag;

    float limit_time;
    bool is_revert_on_end;
    float revert_start_time;
    int revert_tick_count;

    int limit_count;
    
    eActorEventType limit_event;
    int limit_event_filter_flag;

    eActorBuffConfigConditionType limit_condition;
    int limit_condition_extra_data_int;
    float limit_condition_extra_data_float;

    float trigger_time;

    eActorEventType trigger_event;
    int trigger_event_filter_flag;

    eActorBuffConfigConditionType trigger_condition;
    int trigger_condition_extra_data_int;
    float trigger_condition_extra_data_float;
  };
  
} // namespace actor

#endif // ACTOR_BUFF_DATA_TYPEDEF_H