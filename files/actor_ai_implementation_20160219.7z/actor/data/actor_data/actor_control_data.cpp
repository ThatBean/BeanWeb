#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorControlData
  ActorControlData::ActorControlData()
  {
    Reset();
  }

  ActorControlData::~ActorControlData()
  {
    Reset();
  }

  void ActorControlData::Reset()
  {
    operation_data_map_.clear();

    countdown_ = 0;
  }

  void ActorControlData::Update(float delta_time)
  {
    UpdateCountdown(delta_time);
  }

  bool ActorControlData::IsSetOperation()
  {
    return operation_data_map_.size() > 0;
  }

  eActorControlPriority ActorControlData::GetMaxPriority()
  {
    eActorControlPriority max_priority = kActorControlPriorityMin;

    std::map<eActorControlOperationType, sActorControlOperationData>::iterator iterator = operation_data_map_.begin();
    while(iterator != operation_data_map_.end())
    {
      max_priority = max(max_priority, iterator->second.priority);
      iterator++;
    }

    return max_priority;
  }
  //  std::map<eActorControlOperationType, sActorControlOperationData> operation_data_map_;

  eActorControlOperationType ActorControlData::GetMaxPriorityOperationType()
  {
    eActorControlPriority max_priority = kActorControlPriorityMin;
    eActorControlOperationType max_priority_operation_type = kActorControlOperation;

    std::map<eActorControlOperationType, sActorControlOperationData>::iterator iterator = operation_data_map_.begin();
    while(iterator != operation_data_map_.end())
    {
      if (max_priority < iterator->second.priority)
      {
        max_priority = iterator->second.priority;
        max_priority_operation_type = iterator->first;
      }

      iterator++;
    }

    return max_priority_operation_type;
  }

  void ActorControlData::AddIdOperation(eActorControlOperationType operation_type, eActorControlPriority priority, int data_id)
  {
    if (operation_data_map_.find(operation_type) != operation_data_map_.end())
    {
      if (operation_data_map_[operation_type].priority > priority) return; //failed to replace
    }

    //mutex operation
    switch (operation_type)
    {
    case kActorControlOperationPositionMove:
      if (operation_data_map_.find(kActorControlOperationIdTargetMove) != operation_data_map_.end())
      {
        if (operation_data_map_[kActorControlOperationIdTargetMove].priority > priority) return; //failed to replace
        else RemoveOperationData(kActorControlOperationIdTargetMove);
      }
      break;
    case kActorControlOperationIdTargetMove:

      if (operation_data_map_.find(kActorControlOperationPositionMove) != operation_data_map_.end())
      {
        if (operation_data_map_[kActorControlOperationPositionMove].priority > priority) return; //failed to replace
        else RemoveOperationData(kActorControlOperationPositionMove);
      }
      break;

    case kActorControlOperationIdSkillAttack:

      if (operation_data_map_.find(kActorControlOperationTypeSkillAttack) != operation_data_map_.end())
      {
        if (operation_data_map_[kActorControlOperationTypeSkillAttack].priority > priority) return; //failed to replace
        else RemoveOperationData(kActorControlOperationTypeSkillAttack);
      }
      break;
    case kActorControlOperationTypeSkillAttack:

      if (operation_data_map_.find(kActorControlOperationIdSkillAttack) != operation_data_map_.end())
      {
        if (operation_data_map_[kActorControlOperationIdSkillAttack].priority > priority) return; //failed to replace
        else RemoveOperationData(kActorControlOperationIdSkillAttack);
      }
      break;
    }

    operation_data_map_[operation_type].operation_type = operation_type;
    operation_data_map_[operation_type].priority = priority;
    operation_data_map_[operation_type].data_id = data_id;
  }
  void ActorControlData::AddPositionOperation(eActorControlOperationType operation_type, eActorControlPriority priority, cocos2d::CCPoint data_position)
  {
    if (operation_data_map_.find(operation_type) != operation_data_map_.end())
    {
      if (operation_data_map_[operation_type].priority > priority) return; //failed to replace
    }

    operation_data_map_[operation_type].operation_type = operation_type;
    operation_data_map_[operation_type].priority = priority;
    operation_data_map_[operation_type].data_position = data_position;
  }


  ActorControlOperationData* ActorControlData::GetOperationData(eActorControlOperationType operation_type)
  {
    if (CheckOperationData(operation_type)) 
    {
      return &operation_data_map_[operation_type];
    }
    else 
    {
      assert(false);
      return NULL;
    }
  }
  int ActorControlData::GetIdOperationData(eActorControlOperationType operation_type)
  {
    if (CheckOperationData(operation_type)) 
    {
      return operation_data_map_[operation_type].data_id;
    }
    else 
    {
      assert(false);
      return ACTOR_INVALID_ID;
    }
  }
  cocos2d::CCPoint ActorControlData::GetPositionOperationData(eActorControlOperationType operation_type)
  {
    if (CheckOperationData(operation_type)) 
    {
      return operation_data_map_[operation_type].data_position;
    }
    else 
    {
      assert(false);
      return ccp(0, 0);
    }
  }


  bool ActorControlData::CheckOperationData(eActorControlOperationType operation_type)
  {
    return operation_data_map_.find(operation_type) != operation_data_map_.end();
  }
  bool ActorControlData::CheckTopOperationData(eActorControlOperationType operation_type)
  {
    return operation_data_map_.find(operation_type) != operation_data_map_.end() && operation_data_map_[operation_type].priority == GetMaxPriority();
  }
  void ActorControlData::RemoveOperationData(eActorControlOperationType operation_type)
  {
    operation_data_map_.erase(operation_type);
  }



  std::string ActorControlData::GetDebugInfo(Actor* actor, const std::string& pre_text)
  {
    std::ostringstream string_stream;  // associate stream buffer to stream

    ActorControlData* actor_control_data = actor->GetActorData()->GetControlData();

    string_stream << pre_text << " >OperationCount:" << actor_control_data->operation_data_map_.size() << std::endl;
    for (std::map<eActorControlOperationType, sActorControlOperationData>::iterator iterator = actor_control_data->operation_data_map_.begin(); iterator != actor_control_data->operation_data_map_.end(); iterator ++)
    {
      sActorControlOperationData& operation_data = iterator->second;

      switch (operation_data.operation_type)
      {
      case kActorControlOperationPositionMove:
        string_stream << pre_text 
          << " >>OperationType:PositionMove" 
          << " Priority:" << operation_data.priority 
          << " Data:[" << operation_data.data_position.x << "," << operation_data.data_position.x << "]" 
          << std::endl;
        break;
      case kActorControlOperationIdTargetMove:
        string_stream << pre_text 
          << " >>OperationType:IdTargetMove" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      case kActorControlOperationIdTargetAttack:
        string_stream << pre_text 
          << " >>OperationType:IdTargetAttack" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      case kActorControlOperationIdSkillAttack:
        string_stream << pre_text 
          << " >>OperationType:IdSkillAttack" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      case kActorControlOperationTypeSkillAttack:
        string_stream << pre_text 
          << " >>OperationType:TypeSkillAttack" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      case kActorControlOperationTypeBorn:
        string_stream << pre_text 
          << " >>OperationType:TypeBorn" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      case kActorControlOperationTypeDead:
        string_stream << pre_text 
          << " >>OperationType:TypeDead" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      case kActorControlOperationTypeIncontrollable:
        string_stream << pre_text 
          << " >>OperationType:TypeIncontrollable" 
          << " Priority:" << operation_data.priority 
          << " Data:" << operation_data.data_id
          << std::endl;
        break;
      }
    }

    return string_stream.str();
  }
  //ActorControlData



} // namespace actor