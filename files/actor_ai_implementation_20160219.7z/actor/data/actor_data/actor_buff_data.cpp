#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "game/actor/buff/actor_buff.h"
#include "game/actor/skill/actor_skill.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/buff_config_data_table.h"
#include "game/data_table/buff_status_animation_data_table.h"

#include "game/battle/damage/damage_constants.h"
#include "game/shader/shader_manager.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {


  ActorBuffStatusBitSet get_buff_status_bit_set(const eActorBuffStatusType* status_type_array, int status_type_array_size)
  {
    ActorBuffStatusBitSet status_bit_set;
    for (int i = 0; i < status_type_array_size; i ++) 
      status_bit_set.set(status_type_array[i]);
    return status_bit_set;
  }


  // init buff bit set

  const eActorBuffStatusType actor_buff_status_array_insearchable[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusInvisible,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_INSEARCHABLE = get_buff_status_bit_set(actor_buff_status_array_insearchable, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_insearchable))
    ;


  const eActorBuffStatusType actor_buff_status_array_inattackable[] = {
    kActorBuffStatusDebug,

  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_INATTACKABLE = get_buff_status_bit_set(actor_buff_status_array_inattackable, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_inattackable))
    ;


  const eActorBuffStatusType actor_buff_status_array_faction_reversed[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusCharmed,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_FACTION_REVERSED = get_buff_status_bit_set(actor_buff_status_array_faction_reversed, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_faction_reversed))
    ;


  const eActorBuffStatusType actor_buff_status_array_move_lock[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusMuteMove,

    kActorBuffStatusStiff,
    kActorBuffStatusKnockBack,

    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
    kActorBuffStatusStun,
    kActorBuffStatusInterwine,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_MOVE_LOCK = get_buff_status_bit_set(actor_buff_status_array_move_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_move_lock))
    ;


  const eActorBuffStatusType actor_buff_status_array_move_auto[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusAutoMove,

    kActorBuffStatusFear,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_MOVE_AUTO = get_buff_status_bit_set(actor_buff_status_array_move_auto, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_move_auto))
    ;


  const eActorBuffStatusType actor_buff_status_array_incontrollable[] = {
    kActorBuffStatusDebug,

  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_INCONTROLLABLE = get_buff_status_bit_set(actor_buff_status_array_incontrollable, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_incontrollable))
    | ACTOR_BUFF_STATUS_MOVE_LOCK
    | ACTOR_BUFF_STATUS_MOVE_AUTO
    ;



  const eActorBuffStatusType actor_buff_status_array_disable_user_operation[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusCharmed,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_DISABLE_USER_OPERATION = get_buff_status_bit_set(actor_buff_status_array_disable_user_operation, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_disable_user_operation))
    | ACTOR_BUFF_STATUS_INCONTROLLABLE
    ;


  const eActorBuffStatusType actor_buff_status_array_attack_lock[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusStiff,
    kActorBuffStatusKnockBack,

    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
    kActorBuffStatusStun,

    kActorBuffStatusFear,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_LOCK = get_buff_status_bit_set(actor_buff_status_array_attack_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_lock))
    ;


  const eActorBuffStatusType actor_buff_status_array_attack_normal_lock[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusBlind,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_NORMAL_LOCK = get_buff_status_bit_set(actor_buff_status_array_attack_normal_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_normal_lock))
    | ACTOR_BUFF_STATUS_ATTACK_LOCK 
    ;



  const eActorBuffStatusType actor_buff_status_array_attack_power_lock[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusBlind,
    kActorBuffStatusSlience,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_POWER_LOCK = get_buff_status_bit_set(actor_buff_status_array_attack_power_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_power_lock))
    | ACTOR_BUFF_STATUS_ATTACK_LOCK 
    ;



  const eActorBuffStatusType actor_buff_status_array_attack_special_lock[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusSlience,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ATTACK_SPECIAL_LOCK = get_buff_status_bit_set(actor_buff_status_array_attack_special_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_attack_special_lock))
    | ACTOR_BUFF_STATUS_ATTACK_LOCK 
    ;


  const eActorBuffStatusType actor_buff_status_array_animation_lock[] = {
    kActorBuffStatusDebug,

    kActorBuffStatusFreeze,
    kActorBuffStatusPetrify,
  };
  const ActorBuffStatusBitSet ACTOR_BUFF_STATUS_ANIMATION_LOCK = get_buff_status_bit_set(actor_buff_status_array_animation_lock, CALC_ARRAY_LEN_BY_SIZE_OF(actor_buff_status_array_animation_lock))
    ;








  //ActorBuffStatusData
  ActorBuffStatusData::ActorBuffStatusData()
  {
    Clear();
  }

  ActorBuffStatusData::~ActorBuffStatusData()
  {

  }

  void ActorBuffStatusData::Clear()
  {
    stack_active_ = 0;
    stack_immune_ = 0;
  }

  bool ActorBuffStatusData::GetIsActive()
  {
    return !GetIsImmune() && stack_active_ > 0;
  }

  bool ActorBuffStatusData::GetIsImmune()
  {
    return stack_immune_ > 0;
  }

  bool ActorBuffStatusData::StackState(eActorBuffStatusStateOperationType status_state_operation) 
  { 
    switch (status_state_operation)
    {
    case kActorBuffStatusStateOperationAdd:
      if (!GetIsImmune())
      {
        stack_active_++;
        return true;
      }
      else
      {
        return false;
      }
      break;
    case kActorBuffStatusStateOperationSub:
      if (stack_active_ > 0)
      {
        stack_active_--;
        return true;
      }
      else
      {
        return false;
      }
      break;
    case kActorBuffStatusStateOperationImmuneAdd:
      stack_immune_++;
      assert(stack_active_ == 0);  // NOTE: upper logic should clear related buff first
      return true;
      break;
    case kActorBuffStatusStateOperationImmuneSub:
      if (stack_immune_ > 0)
      {
        stack_immune_--;
        return true;
      }
      else
      {
        return false;
      }
      break;
    default:
      assert(false);
      break;
    }
    return false;
  }
  //ActorBuffStatusData















  //ActorBuffData
  ActorBuffData::ActorBuffData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }



  void ActorBuffData::Update(float delta_time)
  {
    ActorBuffStatusBitSet status_bit_set = GetBuffStatusBitSet();

    //update status
    actor_data_->SetActorStatusBool(kActorStatusIsSearchable, (status_bit_set & ACTOR_BUFF_STATUS_INSEARCHABLE).any() == false);
    actor_data_->SetActorStatusBool(kActorStatusIsAttackable, (status_bit_set & ACTOR_BUFF_STATUS_INATTACKABLE).any() == false);

    actor_data_->SetActorStatusBool(kActorStatusIsFactionReversed, (status_bit_set & ACTOR_BUFF_STATUS_FACTION_REVERSED).any());
    actor_data_->SetActorStatusBool(kActorStatusIsDisableUserOperation, (status_bit_set & ACTOR_BUFF_STATUS_FACTION_REVERSED).any());
    

    actor_data_->SetActorStatusBool(kActorStatusBuffIsIncontrollable, (status_bit_set & ACTOR_BUFF_STATUS_INCONTROLLABLE).any());

    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteMove, (status_bit_set & ACTOR_BUFF_STATUS_MOVE_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsAutoMove, (status_bit_set & ACTOR_BUFF_STATUS_MOVE_AUTO).any());

    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttack, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttackNormal, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_NORMAL_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttackPower, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_POWER_LOCK).any());
    actor_data_->SetActorStatusBool(kActorStatusBuffIsMuteAttackSpecial, (status_bit_set & ACTOR_BUFF_STATUS_ATTACK_SPECIAL_LOCK).any());


    bool is_pause_animation = (status_bit_set & ACTOR_BUFF_STATUS_ANIMATION_LOCK).any();
    if (is_pause_animation != actor_data_->GetActorStatusBool(kActorStatusBuffIsPauseAnimation)) 
    {
      actor_data_->SetActorStatusBool(kActorStatusBuffIsPauseAnimation, is_pause_animation);
      actor_data_->GetActorStatusData(kActorStatusAnimationIsPaused)->Stack(is_pause_animation);
    }


    //actor_data_->SetActorStatusBool(kActorStatusBuffIsChangeColor, ((buff_flag & ACTOR_BUFF_FLAG_COLORED) != 0));  // TODO:
    

    //update shader
    taomee::shader::eShaderType shader_type = taomee::shader::kShaderDefault;

    if (status_bit_set[kActorBuffStatusFreeze]) shader_type = taomee::shader::kShaderFrozen;
    if (status_bit_set[kActorBuffStatusPetrify]) shader_type = taomee::shader::kShaderGray;
    if (status_bit_set[kActorBuffStatusInvisible]) shader_type = taomee::shader::kShaderBlur;
    if (status_bit_set[kActorBuffStatusDebug]) shader_type = taomee::shader::kShaderGrayPercent70;
    
    actor_data_->SetActorStatus(kActorStatusBuffShaderType, shader_type);
  }




  //link OnDataOperation to selected signal
  void ActorBuffData::ConnectDataSignal()
  {
    //add data signal
    //actor_data_->GetActorStatusData(kActorStatusBuffIsPauseAnimation)->Connect<ActorBuffData>(this, &ActorBuffData::OnDataOperation);
  }

  //callback for data operation signal
  void ActorBuffData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

//     switch (actor_data_type)
//     {
//     case kActorStatusBuffIsPauseAnimation:
//       {
//         switch (operation_type)
//         {
//         case kActorDataOperationReset:
//         case kActorDataOperationSet:
//           {
//             bool is_pause = actor_data_->GetActorStatusBool(kActorStatusBuffIsPauseAnimation);
// 
//             actor_data_->GetActorStatusData(kActorStatusAnimationIsPaused)->Stack(is_pause);
//           }
//           break;
//         }
//       }
//       break;
//     }
  }

  bool ActorBuffData::RegisterBuff(ActorBuffLinkData* buff_link_data) //return is success
  {
    bool is_success = true;


    //check mute positive/negative
    if ((buff_status_map_[kActorBuffStatusMuteAllPositive].GetIsActive() && buff_link_data->buff_config_data->GetIsPositive())
      || (buff_status_map_[kActorBuffStatusMuteAllNegative].GetIsActive() && !buff_link_data->buff_config_data->GetIsPositive()))
    {
      is_success = false;
    }


    //check buff_id
    if (is_success)
    {
      if (buff_id_register_map_.find(buff_link_data->buff_id) != buff_id_register_map_.end())
      {
        switch (buff_id_register_map_[buff_link_data->buff_id].register_type)
        {
        case kActorBuffConfigStackDropNew:
          {
            is_success = false;
          }
          break;
        case kActorBuffConfigStackCreate:
          {
            //register self
            buff_id_register_map_[buff_link_data->buff_id].buff_list.push_back(buff_link_data);
          }
          break;
        case kActorBuffConfigStackReset:
          {
            ActorBuffLinkData* existing_buff_link_data = *(buff_id_register_map_[buff_link_data->buff_id].buff_list.begin());
            existing_buff_link_data->StackReset(*buff_link_data);
            is_success = false;
          }
          break;
        case kActorBuffConfigStackMerge:
          {
            ActorBuffLinkData* existing_buff_link_data = *(buff_id_register_map_[buff_link_data->buff_id].buff_list.begin());
            existing_buff_link_data->StackMerge(*buff_link_data);
            is_success = false;
          }
          break;
        default:
          assert(false);
          break;
        }
      }
      else
      {
        //register self
        buff_id_register_map_[buff_link_data->buff_id].register_type = buff_link_data->buff_config_data->GetStackType();
        buff_id_register_map_[buff_link_data->buff_id].buff_list.push_back(buff_link_data);
      }
    }


    //check keyword
    if (is_success)
    {
      std::set<std::string>& keyword_set = buff_link_data->buff_config_data->GetKeywordSet();
      for (std::set<std::string>::iterator iterator = keyword_set.begin(); iterator != keyword_set.end(); iterator ++)
      {
        std::string buff_keyword = *iterator;

        if (buff_keyword_register_map_.find(buff_keyword) != buff_keyword_register_map_.end())
        {
          //found overlap keyword

          switch (buff_keyword_register_map_[buff_keyword].register_type)
          {
          case kActorBuffConfigReplaceAddNew:
            {
              //register self
              buff_keyword_register_map_[buff_keyword].buff_list.push_back(buff_link_data);
            }
            break;
          case kActorBuffConfigReplaceReplacePrevious:
          case kActorBuffConfigReplaceReplacePreviousOnly:
            {
              //replace_previous (by keyword)
              buff_link_data->actor_buff->DeactivateBuffByKeyword(buff_keyword);
            }
            break;
          default:
            assert(false);
            break;
          }
        }
        else
        {
          //no overlap keyword
          switch (buff_link_data->buff_config_data->GetReplaceType())
          {
          case kActorBuffConfigReplaceAddNew:
          case kActorBuffConfigReplaceReplacePrevious:
            {
              //register self
              buff_keyword_register_map_[buff_keyword].register_type = buff_link_data->buff_config_data->GetReplaceType();
              buff_keyword_register_map_[buff_keyword].buff_list.push_back(buff_link_data);
            }
            break;
          case kActorBuffConfigReplaceReplacePreviousOnly:
            {
              is_success = false;
              UnregisterBuff(buff_link_data); //revert
            }
            break;
          default:
            assert(false);
            break;
          }
        }
      }
    }


    //check buff_status_animation
    if (is_success)
    {
      int buff_status_animation_id = buff_link_data->buff_config_data->GetStatusAnimationId();
      if (buff_status_animation_id > 0)
      {
        BuffStatusAnimationData* status_animation_data = DataManager::GetInstance().GetBuffStatusAnimationDataTable()->GetBuffStatusAnimation(buff_status_animation_id);
        if (status_animation_data && status_animation_data->GetStatusIconName().empty() == false)
        {
          //register self
          buff_status_animation_register_map_[buff_status_animation_id].register_type = 0;  //no use for now
          buff_status_animation_register_map_[buff_status_animation_id].buff_list.push_back(buff_link_data);

          actor_data_->SetActorStatusBool(kActorStatusAnimationIsBuffChanged, true);
        }
      }
    }


    return is_success;
  }




  void ActorBuffData::UnregisterBuff(ActorBuffLinkData* buff_link_data)
  {
    //check buff_id
    {
      std::list<ActorBuffLinkData*>& buff_list = buff_id_register_map_[buff_link_data->buff_id].buff_list;
      std::list<ActorBuffLinkData*>::iterator iterator = buff_list.begin();
      while (iterator != buff_list.end())
      {
        if ((*iterator)->buff_key == buff_link_data->buff_key)
        {
          iterator = buff_list.erase(iterator);
        }
        else
        {
          iterator ++;
        }
      }
      if (buff_list.empty())
      {
        buff_id_register_map_.erase(buff_link_data->buff_id);
      }
    }

    //check keyword
    std::set<std::string>& keyword_set = buff_link_data->buff_config_data->GetKeywordSet();
    for (std::set<std::string>::iterator buff_keyword_iterator = keyword_set.begin(); buff_keyword_iterator != keyword_set.end(); buff_keyword_iterator ++)
    {
      std::string buff_keyword = *buff_keyword_iterator;

      std::list<ActorBuffLinkData*>& buff_list = buff_keyword_register_map_[buff_keyword].buff_list;
      std::list<ActorBuffLinkData*>::iterator iterator = buff_list.begin();
      while (iterator != buff_list.end())
      {
        if ((*iterator)->buff_key == buff_link_data->buff_key)
        {
          iterator = buff_list.erase(iterator);
        }
        else
        {
          iterator ++;
        }
      }
      if (buff_list.empty())
      {
        buff_keyword_register_map_.erase(buff_keyword);
      }
    }

    //check status animation
    if (buff_link_data->buff_config_data->GetStatusAnimationId() > 0)
    {
      std::list<ActorBuffLinkData*>& buff_list = buff_status_animation_register_map_[buff_link_data->buff_config_data->GetStatusAnimationId()].buff_list;
      std::list<ActorBuffLinkData*>::iterator iterator = buff_list.begin();
      while (iterator != buff_list.end())
      {
        if ((*iterator)->buff_key == buff_link_data->buff_key)
        {
          iterator = buff_list.erase(iterator);
        }
        else
        {
          iterator ++;
        }
      }
      if (buff_list.empty())
      {
        buff_status_animation_register_map_.erase(buff_link_data->buff_config_data->GetStatusAnimationId());
      }

      actor_data_->SetActorStatusBool(kActorStatusAnimationIsBuffChanged, true);
    }
  }



  bool ActorBuffData::CheckBuffKeyword(const std::string& buff_keyword)
  {
    return (buff_keyword_register_map_.find(buff_keyword) != buff_keyword_register_map_.end());
  }


  ActorBuffStatusBitSet ActorBuffData::AddBuffStatusBitSet(const ActorBuffStatusBitSet& buff_status_bit_set, eActorBuffStatusStateOperationType status_state_operation)
  {
    ActorBuffStatusBitSet applied_status_bit_set;
    for (int i = 0; i < buff_status_bit_set.size(); i++)
      if (buff_status_bit_set[i]) 
        applied_status_bit_set[i] = buff_status_map_[eActorBuffStatusType(i)].StackState(status_state_operation);

    flush_quick_status_bit_set();

    return applied_status_bit_set;
  }

  void ActorBuffData::FlushImmuneBuffStatusBitSet(const ActorBuffStatusBitSet& buff_status_bit_set)
  {
    ActorBuffStatusBitSet reverse_status_bit_set;
    for (int i = 0; i < buff_status_bit_set.size(); i++)
    {
      if (buff_status_bit_set[i] && buff_status_map_[eActorBuffStatusType(i)].GetIsImmune() == false)
      {
        reverse_status_bit_set.set(i);
        buff_status_map_[eActorBuffStatusType(i)].stack_active_ = 0;  //reset active
      }
    }
    if (reverse_status_bit_set.none())
    {
      return; //nothing to flush
    }
    else
    {
      reverse_status_bit_set.flip();  //now all flush-able status-bit is 0
      flush_quick_status_bit_set();
    }


    //flush
    for (std::map<std::string, ActorBuffRegisterData>::iterator iterator = buff_keyword_register_map_.begin(); iterator != buff_keyword_register_map_.end(); iterator ++)
    {
      ActorBuffRegisterData& buff_reg_data = iterator->second;
      for (std::list<ActorBuffLinkData*>::iterator iterator_buff = buff_reg_data.buff_list.begin(); iterator_buff != buff_reg_data.buff_list.end(); iterator_buff ++)
      {
        ActorBuffLinkData* buff_link_data = *iterator_buff;
        if (buff_link_data->applied_status_state_operation_type == kActorBuffStatusStateOperationAdd 
          || buff_link_data->applied_status_state_operation_type == kActorBuffStatusStateOperationSub)
        {
          //remove revert record
          buff_link_data->applied_buff_status_bit_set &= reverse_status_bit_set;
        }
      }
    }
  }

  bool ActorBuffData::CheckBuffStatusBitSet(const ActorBuffStatusBitSet& buff_status_bit_set)
  {
//     bool is_all_set = true;
//     for (int i = 0; i < buff_status_bit_set.size(); i++)
//       if (buff_status_bit_set[i]) 
//         is_all_set &= (buff_status_map_.find(eActorBuffStatusType(i)) != buff_status_map_.end());
//     return is_all_set;

    return (buff_status_bit_set & quick_status_bit_set_).any();
  }

  const ActorBuffStatusBitSet& ActorBuffData::GetBuffStatusBitSet()
  {
//     ActorBuffStatusBitSet status_bit_set;
//     for (std::map<eActorBuffStatusType, ActorBuffStatusData>::iterator iterator = buff_status_map_.begin(); iterator != buff_status_map_.end(); iterator ++)
//       status_bit_set.set(iterator->first, iterator->second.GetIsActive());
//     return status_bit_set;

    return quick_status_bit_set_;
  }


  std::map<int, int> ActorBuffData::GetBuffStatusDisplayData()
  {
    std::map<int, int> status_display_data;

    for (std::map<int, ActorBuffRegisterData>::iterator iterator = buff_status_animation_register_map_.begin(); iterator != buff_status_animation_register_map_.end(); iterator ++)
    {
      int buff_status_animation_id = iterator->first;
      ActorBuffRegisterData& buff_reg_data = iterator->second;
      int stack_count = buff_reg_data.buff_list.size();
      status_display_data[buff_status_animation_id] = stack_count;
    }

    return status_display_data;
  }



  void ActorBuffData::flush_quick_status_bit_set()
  {
    for (std::map<eActorBuffStatusType, ActorBuffStatusData>::iterator iterator = buff_status_map_.begin(); iterator != buff_status_map_.end(); iterator ++)
      quick_status_bit_set_.set(iterator->first, iterator->second.GetIsActive());
  }






  std::string ActorBuffData::GetDebugInfo(Actor* actor, const std::string& pre_text)
  {
    std::ostringstream string_stream;  // associate stream buffer to stream

    ActorBuffData* actor_buff_data = actor->GetActorData()->GetBuffData();

    string_stream << pre_text << " >BuffStatusBitSet:" << actor_buff_data->GetBuffStatusBitSet().to_string() << std::endl;

    string_stream << pre_text << " >RegisteredBuffKeywordCount:" << actor_buff_data->buff_keyword_register_map_.size() << std::endl;
    for (std::map<std::string, ActorBuffRegisterData>::iterator iterator = actor_buff_data->buff_keyword_register_map_.begin(); iterator != actor_buff_data->buff_keyword_register_map_.end(); iterator ++)
    {
      const std::string& buff_keyword = iterator->first;
      ActorBuffRegisterData& buff_reg_data = iterator->second;
      string_stream << pre_text << " >>Keyword:" << buff_keyword << " Type:" << buff_reg_data.register_type << std::endl;

      for (std::list<ActorBuffLinkData*>::iterator iterator_buff = buff_reg_data.buff_list.begin(); iterator_buff != buff_reg_data.buff_list.end(); iterator_buff ++)
      {
        ActorBuffLinkData* buff_link_data = *iterator_buff;
        string_stream << pre_text << " >>>Keyword:" << buff_keyword << " RegisteredBuffId:" << buff_link_data->buff_id << std::endl;
      }
    }

    string_stream << pre_text << " >RegisteredBuffIdCount:" << actor_buff_data->buff_id_register_map_.size() << std::endl;
    for (std::map<int, ActorBuffRegisterData>::iterator iterator = actor_buff_data->buff_id_register_map_.begin(); iterator != actor_buff_data->buff_id_register_map_.end(); iterator ++)
    {
      int buff_id = iterator->first;
      ActorBuffRegisterData& buff_reg_data = iterator->second;
      string_stream << pre_text << " >>BuffId:" << buff_id << " Type:" << buff_reg_data.register_type << std::endl;

      for (std::list<ActorBuffLinkData*>::iterator iterator_buff = buff_reg_data.buff_list.begin(); iterator_buff != buff_reg_data.buff_list.end(); iterator_buff ++)
      {
        ActorBuffLinkData* buff_link_data = *iterator_buff;
        string_stream << pre_text << " >>>BuffId:" << buff_id << " RegisteredBuffId:" << buff_link_data->buff_id << std::endl;
      }
    }

    return string_stream.str();
  }
  //ActorBuffData


} // namespace actor