#ifndef ACTOR_SPECIFIED_DATA_H
#define ACTOR_SPECIFIED_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  
  class ActorSpecifiedData
  {
  public:
    ActorSpecifiedData(ActorData* actor_data, Actor* actor);

    void Update(float delta_time);
    bool IsPositionValid(cocos2d::CCPoint position);
    bool IsGridValid(cocos2d::CCPoint grid_position);
    bool IsGridIdleValid(cocos2d::CCPoint grid_position);
    cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position);

  private:
    Actor* actor_;

    ActorData* actor_data_;
  };
} // namespace actor


#endif // ACTOR_SPECIFIED_DATA_H