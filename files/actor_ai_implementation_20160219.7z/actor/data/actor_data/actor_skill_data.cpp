#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "game/actor/skill/actor_skill.h"
#include "game/actor/trigger/actor_trigger.h"

#include "game/actor/actor_adapter.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/skill_config_data_table.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  ActorSkillData::ActorSkillData(ActorData* actor_data, Actor* actor)
    : actor_data_(actor_data)
    , actor_(actor)
    , attack_trigger_(NULL)
    , guard_trigger_(NULL)
    , auto_trigger_(NULL)
  {
    Reset();
  }

  ActorSkillData::~ActorSkillData()
  {
    Reset();
  }

  void ActorSkillData::Reset()
  {
    actor_data_->GetActorAttributeData(kActorAttributeAttackCount)->Reset();
    actor_data_->GetActorAttributeData(kActorAttributeAttackNormalCount)->Reset();
    actor_data_->GetActorAttributeData(kActorAttributeAttackPowerCount)->Reset();
    actor_data_->GetActorAttributeData(kActorAttributeAttackSpecialCount)->Reset();


    skill_info_map_.clear();
    skill_cycle_list_.clear();


    if (attack_trigger_) delete attack_trigger_;
    if (guard_trigger_) delete guard_trigger_;
    if (auto_trigger_) delete auto_trigger_;

    attack_trigger_ = NULL;
    guard_trigger_ = NULL;
    auto_trigger_ = NULL;
  }

  void ActorSkillData::Update(float delta_time)
  {
    std::map<int, ActorSkillInfo>::iterator iterator = skill_info_map_.begin();
    while (iterator != skill_info_map_.end())
    {
      if (iterator->second.skill_cooldown_current > 0)
      {
        iterator->second.skill_cooldown_current -= delta_time;
      }
      iterator++;
    }
  }



  //link OnDataOperation to selected signal
  void ActorSkillData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorStatusData(kActorStatusSkillIsPaused)->Connect<ActorSkillData>(this, &ActorSkillData::OnDataOperation);
  }

  //callback for data operation signal
  void ActorSkillData::OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    ActorData* actor_data = signal_data->actor_data;

    switch (actor_data_type)
    {
    case kActorStatusSkillIsPaused:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            bool is_pause = actor_data_->GetActorStatusBool(kActorStatusSkillIsPaused);

            // TODO: if needed to pause skill, implement logic here
            //actor_->GetSkill()->SetIsPause(is_pause);
          }
          break;
        }
      }
      break;
    }
  }











  bool ActorSkillData::IsSkillValid(int skill_id)
  {
    if (actor_data_->GetActorStatusBool(kActorStatusIsMuteAttack)
      || actor_data_->GetActorStatusBool(kActorStatusBuffIsMuteAttack))
      return false;//no attack
    
    bool is_attack_valid = true;

    //valid check
    switch(GetSkillTypeById(skill_id))
    {
    case kActorSkillNormal:
      is_attack_valid &= !actor_data_->GetActorStatusBool(kActorStatusIsMuteAttackNormal);
      is_attack_valid &= !actor_data_->GetActorStatusBool(kActorStatusBuffIsMuteAttackNormal);
      break;
    case kActorSkillPower:
      is_attack_valid &= !actor_data_->GetActorStatusBool(kActorStatusIsMuteAttackPower);
      is_attack_valid &= !actor_data_->GetActorStatusBool(kActorStatusBuffIsMuteAttackPower);
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      is_attack_valid &= !actor_data_->GetActorStatusBool(kActorStatusIsMuteAttackSpecial);
      is_attack_valid &= !actor_data_->GetActorStatusBool(kActorStatusBuffIsMuteAttackSpecial);
      break;
    default:
      //assert(false);
      is_attack_valid = false;
      break;
    }

    //cost/cooldown check
    actor::ActorSkillInfo *skill_info = GetSkillInfoById(skill_id);
    if (skill_info)
    {
      //cool down check
      is_attack_valid &= skill_info->skill_cooldown_current <= 0;

      //energy check
      is_attack_valid &= actor_data_->GetActorAttribute(kActorAttributeEnergyCurrent) >= -1.0 * skill_info->skill_energy_cost;
    }

    return is_attack_valid;
  }



  bool ActorSkillData::CheckAttackTrigger()
  {
    if (!attack_trigger_)
      return false;
    if (NextSkill() == ACTOR_INVALID_ID || IsSkillValid(NextSkill()) == false)
      return false; //skill not ready
    if (actor_data_->GetControlData()->CheckOperationData(kActorControlOperationPositionMove) && actor_data_->GetControlData()->GetOperationData(kActorControlOperationPositionMove)->priority > kActorControlPriorityCheckAttackAuto) 
      return false;//user set position, ignore all target

    attack_trigger_->Update();//update trigger

    if (attack_trigger_->GetIsTriggered() == false) 
      return false;//no target

    //decide target
    ActorControlData* control_data = actor_data_->GetControlData();
    Actor* target_actor = NULL;
    std::list<Actor*>* triggered_actor_list = attack_trigger_->GetTriggeredActorList();
    if (control_data->CheckOperationData(kActorControlOperationIdTargetMove) && control_data->GetOperationData(kActorControlOperationIdTargetMove)->priority > kActorControlPriorityCheckAttackAuto) 
    {
      int target_actor_id = control_data->GetIdOperationData(kActorControlOperationIdTargetMove); //user set target

      std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
      while (iterator != triggered_actor_list->end())
      {
        Actor* triggered_actor = *iterator;
        if (target_actor_id == triggered_actor->GetScriptObjectId()) 
        {
          target_actor = triggered_actor;
          break;
        }
        iterator ++;
      }
    }
    else
    {
      target_actor = *(triggered_actor_list->begin());
    }

    // no target
    if (!target_actor)
      return false;

    int next_skill_id = NextSkill();

    switch (GetSkillTypeById(next_skill_id))
    {
    case kActorSkillNormal:
      control_data->AddIdOperation(kActorControlOperationIdSkillAttack, kActorControlPriorityAttackNormalAuto, next_skill_id);
      CycleSkillCycleList();//cycle attack cycle
      break;
    case kActorSkillPower:
      control_data->AddIdOperation(kActorControlOperationIdSkillAttack, kActorControlPriorityAttackPowerAuto, next_skill_id);
      CycleSkillCycleList();//cycle attack cycle
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      actor_data_->GetLog()->AddErrorLogF("[CheckAttackTrigger] Get Special/Overload Skill! id:%d type:%d", next_skill_id, GetSkillTypeById(next_skill_id));
      control_data->AddIdOperation(kActorControlOperationIdSkillAttack, kActorControlPriorityAttackSpecialAuto, next_skill_id);
      break;
    default:
      actor_data_->GetLog()->AddErrorLogF("[CheckAttackTrigger] Error skill type! id:%d type:%d", next_skill_id, GetSkillTypeById(next_skill_id));
      assert(false);
      break;
    }

    //set to control data
    control_data->RemoveOperationData(kActorControlOperationIdTargetMove); // found the target, clear control priority for attack
    control_data->AddIdOperation(kActorControlOperationIdTargetAttack, kActorControlPriorityMin, target_actor->GetScriptObjectId()); // found the target, clear control priority for attack
    return true;
  }


  bool ActorSkillData::CheckGuardTrigger()
  {
    if (!guard_trigger_) 
      return false;
    if (actor_data_->GetActorStatusBool(kActorStatusIsMuteGuard) || actor_data_->GetActorStatusBool(kActorStatusBuffIsMuteGuard))
      return false;//no guard
    if (NextSkill() == ACTOR_INVALID_ID || IsSkillValid(NextSkill()) == false)
      return false; //skill not ready
    if (actor_data_->GetControlData()->GetMaxPriority() > kActorControlPriorityCheckGuardAuto) 
      return false; //has other target set

    guard_trigger_->Update();
    if (guard_trigger_->GetIsTriggered())
    {
      int target_id = *(guard_trigger_->GetTriggeredActorIdList()->begin());
      actor_data_->GetControlData()->AddIdOperation(kActorControlOperationIdTargetMove, kActorControlPriorityMoveAuto, target_id);
      return true;
    }

    return false;
  }


  void ActorSkillData::AddSkillInfo(ActorSkillInfo& skill_info)
  {
    if (GetSkillInfoById(skill_info.skill_id))
    {
      actor_data_->GetLog()->AddErrorLogF("[Error][ActorSkillData][AddSkillInfo] Already has this skill in map! id:%d", skill_info.skill_id);
      assert(false);
      return;
    }

    int skill_index = skill_info.skill_type * 1000000 + skill_info.skill_id;

    skill_info_map_[skill_index] = skill_info;
  }


  ActorSkillInfo* ActorSkillData::GetSkillInfoById(int skill_id)
  {
    //not allowed
    if (skill_id == ACTOR_INVALID_ID) return NULL;

    //check map
    std::map<int, ActorSkillInfo>::iterator iterator = skill_info_map_.begin();
    while (iterator != skill_info_map_.end())
    {
      if (iterator->second.skill_id == skill_id) return &(iterator->second);
      iterator++;
    }

    return NULL;
  }



  eActorSkillType ActorSkillData::GetSkillTypeById(int skill_id)
  {
    //not allowed
    if (skill_id == ACTOR_INVALID_ID) return kActorSkill;

    //check map
    ActorSkillInfo* skill_info = GetSkillInfoById(skill_id);
    if (skill_info) return skill_info->skill_type;
    else return kActorSkillOverload;
  }


  int ActorSkillData::GetSkillIdByType(int skill_type, int skip_count/* = 0*/)
  {
    //check map
    std::map<int, ActorSkillInfo>::iterator iterator = skill_info_map_.begin();

    while (iterator != skill_info_map_.end())
    {
      if (skill_type & kActorSkillOverload || iterator->second.skill_type & skill_type)
      {
        if (skip_count == 0) return iterator->second.skill_id;
        else skip_count--;
      }
      iterator++;
    }

    return ACTOR_INVALID_ID;
  }


  int ActorSkillData::NextSkill()
  {
    bool is_disable_skill_cycle = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_disable_skill_cycle");

    if (is_disable_skill_cycle)
    {
      eActorSkillType next_skill_type = kActorSkill;
      int next_skill_id = ACTOR_INVALID_ID;

      for (std::map<int, ActorSkillInfo>::iterator iterator = skill_info_map_.begin(); iterator != skill_info_map_.end(); iterator ++)
      {
        ActorSkillInfo& skill_info = iterator->second;

        switch (skill_info.skill_type)
        {
        case kActorSkillNormal:
        case kActorSkillPower:
          if (
            (
              next_skill_type < skill_info.skill_type
              || (next_skill_type == skill_info.skill_type && next_skill_id < skill_info.skill_id)
            )
            && IsSkillValid(skill_info.skill_id)
          )
          {
            next_skill_type = skill_info.skill_type;
            next_skill_id = skill_info.skill_id;
          }
          break;
        default:
          //skip, not here
          break;
        }
      }

      return next_skill_id;
    }
    else
    {
      if (skill_cycle_list_.size() == 0)
      {
        //actor_data_->GetLog()->AddErrorLogF("[Error][ActorSkillData][NextSkill] No skill at all in list!");
        //assert(false);
        return ACTOR_INVALID_ID;
      }

      return *(skill_cycle_list_.begin());
    }
  }


  void ActorSkillData::CycleSkillCycleList()
  {
    int skill_id = *(skill_cycle_list_.begin());
    skill_cycle_list_.pop_front();
    skill_cycle_list_.push_back(skill_id);
  }


  void ActorSkillData::SetSkillCycleList(std::string& skill_cycle_string)
  {
    std::list<std::string>* result_list = ActorStringSplit(skill_cycle_string, std::string("|,"));

    assert(result_list->size() > 0);

    skill_cycle_list_.clear();

    std::list<std::string>::iterator iterator = result_list->begin();
    while (iterator != result_list->end())
    {
      int skill_id = ACTOR_INVALID_ID;
      
      if (iterator->c_str()[0] >= '0' && iterator->c_str()[0] <= '9')
      {
        //normal skill
        int skip_count = atoi(iterator->c_str());
        skill_id = GetSkillIdByType(kActorSkillNormal | kActorSkillPower, skip_count);
      }

      if (iterator->c_str()[0] >= 'a' && iterator->c_str()[0] <= 'z')
      {
        //special skill
        int skip_count = iterator->c_str()[0] - 'a';
        skill_id = GetSkillIdByType(kActorSkillSpecial, skip_count);
      }

      if (skill_id != ACTOR_INVALID_ID) skill_cycle_list_.push_back(skill_id);
      else actor_data_->GetLog()->AddErrorLogF("[Error][ActorSkillData][SetSkillCycleList] skipped invalid symbol: [%s]", iterator->c_str());

      iterator++;
    }

    delete result_list;
  }



  void ActorSkillData::CommitSkill(int skill_id, int pre_selected_target_actor_id)
  {
    if (skill_id <= 0) return;

    eActorSkillType skill_type = GetSkillTypeById(skill_id);
    switch (skill_type)
    {
    case kActorSkillSpecial:
    case kActorSkillOverload:
      if (actor_data_->GetActorStatusBool(kActorStatusSkillIsBusy) == true) 
      {
        actor_data_->GetLog()->AddLogF("[ActorSkillData][CommitSkill] Reset Previous Skill. Current skill_id:%d type:%d count:%d", 
          skill_id, 
          skill_type, 
          (int)actor_data_->GetActorAttribute(kActorAttributeAttackCount));
        
        actor_->GetSkill()->EndSkill();
      }
      break;
    case kActorSkillNormal:
    case kActorSkillPower:
    case kActorSkillBornWith:
      // nothing
      break;
    default:
      assert(false);
      break;
    }

    actor_data_->GetLog()->AddLogF("[ActorSkillData][CommitSkill] <!> Attack! Current skill_id:%d type:%d count:%d", skill_id, skill_type, (int)actor_data_->GetActorAttribute(kActorAttributeAttackCount));
    
    //init skill
    actor_->GetSkill()->StartSkill(skill_id);

    //check preset target(for melee attack)
    if (pre_selected_target_actor_id != ACTOR_INVALID_ID)
    {
      actor_->GetActorData()->GetLog()->AddLogF("[MotionStateAttack][SkillStart] <!> pre_selected_target_actor_id:%d", pre_selected_target_actor_id);
      actor_->GetSkill()->GetSkillLinkData().target_actor_id_list.push_back(pre_selected_target_actor_id);
    }
  }



  void ActorSkillData::FinishedSkill(int skill_id)
  {
    if (skill_id <= 0) return;

    actor_data_->GetActorAttributeData(kActorAttributeAttackCount)->Add(1);

    eActorSkillType skill_type = GetSkillTypeById(skill_id);
    switch (skill_type)
    {
    case kActorSkillNormal:
      actor_data_->GetActorAttributeData(kActorAttributeAttackNormalCount)->Add(1);
      break;
    case kActorSkillPower:
      actor_data_->GetActorAttributeData(kActorAttributeAttackPowerCount)->Add(1);
      break;
    case kActorSkillSpecial:
    case kActorSkillOverload:
      actor_data_->GetActorAttributeData(kActorAttributeAttackSpecialCount)->Add(1);
      break;
    case kActorSkillBornWith:
      // nothing
      break;
    default:
      assert(false);
      break;
    }

    actor_data_->GetLog()->AddLogF("[ActorSkillData][FinishedSkill] <!> Finished Skill skill_id:%d type:%d count:%d", skill_id, skill_type, (int)actor_data_->GetActorAttribute(kActorAttributeAttackCount));
  }



  std::string ActorSkillData::GetDebugInfo(Actor* actor, const std::string& pre_text)
  {
    std::ostringstream string_stream;  // associate stream buffer to stream

    ActorSkillData* actor_skill_data = actor->GetActorData()->GetSkillData();

    string_stream << pre_text << " >SkillInfoCount:" << actor_skill_data->skill_info_map_.size() << std::endl;
    for (std::map<int, ActorSkillInfo>::iterator iterator = actor_skill_data->skill_info_map_.begin(); iterator != actor_skill_data->skill_info_map_.end(); iterator ++)
    {
      int skill_index = iterator->first;
      ActorSkillInfo& skill_info = iterator->second;

      string_stream << pre_text << " >>Index:" << skill_index 
        << " SkillId:" << skill_info.skill_id 
        << " SkillType:" << skill_info.skill_type 
        << " SkillLevel:" << skill_info.skill_level 
        << " SkillDamageScale:" << skill_info.skill_damage_scale 
        << " SkillEnergyCost:" << skill_info.skill_energy_cost 
        << " SkillEnergyRecover:" << skill_info.skill_energy_recover 
        << " SkillCoolDown:" << skill_info.skill_cooldown_current << "/" << skill_info.skill_cooldown 
        << std::endl;
    }

    return string_stream.str();
  }
  //ActorSkillData

} // namespace actor