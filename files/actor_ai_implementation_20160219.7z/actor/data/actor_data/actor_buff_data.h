#ifndef ACTOR_BUFF_DATA_H
#define ACTOR_BUFF_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/typedef/actor_buff_data_typedef.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorBuff;
  class ActorBuffLinkData;
  class ActorSkillLinkData;


  //also animation tag
  enum eActorAnimationPositionType
  {
    kActorAnimationPositionTop      = 7890001,
    kActorAnimationPositionMiddle   = 7890002,
    kActorAnimationPositionBottom   = 7890003,
    kActorAnimationPosition
  };
  
  
  struct ActorBuffRegisterData {
    int register_type;
    std::list<ActorBuffLinkData*> buff_list;
  };



  class ActorBuffStatusData
  {
  public:
    ActorBuffStatusData();
    ~ActorBuffStatusData();

    void Clear();

    bool GetIsActive();
    bool GetIsImmune();

    //return is changed
    bool StackState(eActorBuffStatusStateOperationType status_state_operation);

  public:
    int stack_active_;
    int stack_immune_;
  };
  



  //buff data storage on the Actor, mainly for buff interaction (other data will be on Buff / Effect Object)
  class ActorBuffData
  {
  public:
    ActorBuffData(ActorData* actor_data);
    ~ActorBuffData();

    void Update(float delta_time);

    //link OnDataOperation to selected signal
    void ConnectDataSignal();

    //callback for data operation signal
    void OnDataOperation(int operation_type, int actor_data_type, ActorDataSignalData* signal_data);

    bool RegisterBuff(ActorBuffLinkData* buff_link_data); //return is success
    void UnregisterBuff(ActorBuffLinkData* buff_link_data);

    //keyword: mark only, for "buff grouping", deal replace and stack
    bool CheckBuffKeyword(const std::string& buff_keyword);

    //status, logic linked, will cause actor behavior change, return applied_status_bit_set(may lose all buff_status_bit_set)
    ActorBuffStatusBitSet AddBuffStatusBitSet(const ActorBuffStatusBitSet& buff_status_bit_set, eActorBuffStatusStateOperationType status_state_operation);
    void FlushImmuneBuffStatusBitSet(const ActorBuffStatusBitSet& buff_status_bit_set);  //reset status stack, remove buff status revert
    bool CheckBuffStatusBitSet(const ActorBuffStatusBitSet& buff_status_bit_set);

    const ActorBuffStatusBitSet& GetBuffStatusBitSet();
    
    std::map<int, int> GetBuffStatusDisplayData();  //buff_status_animation_id - count

  protected:
    void flush_quick_status_bit_set();

  private:
    ActorData*    actor_data_;

    std::map<std::string, ActorBuffRegisterData> buff_keyword_register_map_;  //buff grouped by keyword, for replace check
    std::map<int, ActorBuffRegisterData> buff_id_register_map_;  //buff by buff_id, for stack check
    std::map<int, ActorBuffRegisterData> buff_status_animation_register_map_; //buff icon by buff_status_animation_id

    std::map<eActorBuffStatusType, ActorBuffStatusData> buff_status_map_;

    ActorBuffStatusBitSet quick_status_bit_set_;

  public:
    static std::string GetDebugInfo(Actor* actor, const std::string& pre_text);

  };


} // namespace actor


#endif // ACTOR_BUFF_DATA_H