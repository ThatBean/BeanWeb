#include "game/actor/data/actor_data.h"

#include "game/actor/actor.h"

#include "game/actor/typedef/actor_grid_typedef.h"

#include "game/actor/actor_adapter.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {

  ActorSpecifiedData::ActorSpecifiedData(ActorData* actor_data, Actor* actor)
    : actor_data_(actor_data)
    , actor_(actor)
  {}


  void ActorSpecifiedData::Update(float delta_time)
  {
    switch (actor_data_->GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      //nothing
      break;
    case kActorAppearanceEnemyBoss:
    case kActorAppearanceEnemyPawn:
      {
        cocos2d::CCPoint grid_position = GetGridFromPosition(actor_->GetActorData()->GetActorPosition(kActorPositionAnimation));

        // TODO: need move? | show enemy warning
        if (grid_position.x >= (GRID_X_RANGE_RIGHT_MIDDLE - 1))
        {
          LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/battleOverlayUI/BattleOverlayUI.lua", 
            "CallFuncBattleOverlayUI", "NotifySubDisplay", "NOTIFIER_WARNING", "warning");
        }

        // TODO: need move? | reduce enemy's speed
        if (grid_position.x >= GRID_X_RANGE_RIGHT_MIDDLE)
        {
          ActorAttributeData* speed_attribute = actor_->GetActorData()->GetActorAttributeData(kActorAttributeSpeedMove);
          speed_attribute->Set(speed_attribute->GetAdd(), 0.5);
        }

        if (grid_position.x > GRID_X_RANGE_RIGHT)
        {
          actor_->Emit("EnemyPassRightBorder");
          AlertEnemyPassRightBorder(actor_->GetScriptObjectId());
        }
      }
      break;
    default:
      break;
    }
  }


  bool ActorSpecifiedData::IsPositionValid(cocos2d::CCPoint position)
  {
    switch (actor_data_->GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      {
        if (IsPositionInGrid(position))
        {
          cocos2d::CCPoint grid_position = GetGridFromPosition(position);
          if (actor_->GetActorData()->GetActorStatusBool(kActorStatusSpecifiedIsLimitGridX) && ((int)(grid_position.x) < 2))
            return (position.x > (GetPositionFromGrid(ccp(2,grid_position.y)).x));
          else
            return true;
        }
        else
          return false;
      }
      break;
    case kActorAppearanceEnemyBoss:
    case kActorAppearanceEnemyPawn:
      {
        return IsPositionYInGrid(position);
      }
      break;
    default:
      return IsPositionInGrid(position);
      break;
    }
  }

  bool ActorSpecifiedData::IsGridValid(cocos2d::CCPoint grid_position)
  {
    bool is_valid = grid_position.x >= GRID_X_RANGE_LEFT
      && grid_position.x <= GRID_X_RANGE_RIGHT
      && grid_position.y >= GRID_Y_RANGE_BOTTOM
      && grid_position.y <= GRID_Y_RANGE_TOP;

    switch (actor_data_->GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      {
        if (is_valid && actor_->GetActorData()->GetActorStatusBool(kActorStatusSpecifiedIsLimitGridX))
        {
          switch (actor_->GetActorData()->GetActorStatus(kActorStatusHomeDirection))
          {
          case kActorAnimationDirectionLeft:
            is_valid = grid_position.x <= PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT;
            break;
          case kActorAnimationDirectionRight:
            is_valid = grid_position.x >= PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT;
            break;
          default:
            assert(false);
            is_valid = true;
            break;
          }
        }
      }
      break;
    case kActorAppearanceEnemyBoss:
    case kActorAppearanceEnemyPawn:
    default:
      break;
    }

    return is_valid;
  }


  cocos2d::CCPoint ActorSpecifiedData::PositionCorrection(cocos2d::CCPoint position)
  {
    switch (actor_data_->GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      {
        if (IsPositionValid(position))
        {
          return SnapToGrid(position);
        }
        else
        {
          cocos2d::CCPoint grid_position = GetGridFromPosition(position);

          if (actor_->GetActorData()->GetActorStatusBool(kActorStatusSpecifiedIsLimitGridX) && ((int)(grid_position.x) == 1))
            grid_position.x = 2;  // TODO: strange logic

          return GetPositionFromGrid(grid_position);
        }
      }
      break;
    case kActorAppearanceEnemyBoss:
    case kActorAppearanceEnemyPawn:
    default:
      {
        return SnapYToGrid(position);
      }
      break;
    }
  }


  bool ActorSpecifiedData::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);
  }

} // namespace actor