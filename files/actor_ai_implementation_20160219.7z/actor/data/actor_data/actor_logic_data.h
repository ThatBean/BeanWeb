#ifndef ACTOR_LOGIC_DATA_H
#define ACTOR_LOGIC_DATA_H

#include "game/actor/typedef/actor_data_typedef.h"


namespace actor {

  class Actor;
  class ActorData;
  
  
  class ActorLogicData
  {
  public:
    ActorLogicData(ActorData* actor_data);
    ~ActorLogicData();
    
    void Init();

  private:
    ActorData*    actor_data_;


  };
} // namespace actor


#endif // ACTOR_LOGIC_DATA_H