#ifndef ACTOR_SIGNAL_HUB_H
#define ACTOR_SIGNAL_HUB_H

#include <boost/bind.hpp>
#include <boost/signal.hpp>

/*
  A template of a Simple Event Center
  For cpp, data_map event
  Use boost::signals::connection

  Emit contents:
    signal_type - the type/key/id of the Event/Signal
    linked_value - the type/key/id of this SignalHub
    linked_data - a pointer of struct/class to pass for customized data

  Once defined, 1 SignalHub should be used for 1 type of event for 1 type of data

  The default_id_ and default_data_ 
    saved for default value for Emit(int signal_type) 
    can be override using Emit(int signal_type, int linked_value, t_data* linked_data) directly
*/

namespace actor {

  typedef boost::signals::connection ActorSignalConnection;

  template <typename t_data>
  class ActorSignalHub {
  public:
    ActorSignalHub() 
      : signal_hub_(NULL)
      , default_id_(-1)
      , default_data_(NULL)
    {

    }
    ~ActorSignalHub() {
      if (signal_hub_) delete signal_hub_;
    }

  public:
    //typedef boost::signal<void (int, eActorDataOperationType, t_data*)> tActorDataSignal;
    //typedef boost::signals::connection tActorDataConnection;

    template <typename T>
    ActorSignalConnection Connect(T* pt, void (T::*method)(int, int, t_data*)) 
    {
      if (!signal_hub_) 
      {
        signal_hub_ = new boost::signal<void (int, int, t_data*)>;
      }

      return signal_hub_->connect(boost::bind(method, pt, _1, _2, _3));
    }

    void Disconnect(ActorSignalConnection connection) 
    {
      connection.disconnect();
    }

    void Emit(int signal_type, int linked_value, t_data* linked_data) 
    {
      if (signal_hub_) 
      {
        (*signal_hub_)(signal_type, linked_value, linked_data);
      }
    }

    //for ActorData to link
    void SetDefault(int actor_data_type, t_data* actor_data) 
    {
      default_id_ = actor_data_type;
      default_data_ = actor_data;
    }

    void Emit(int signal_type) 
    {
      if (signal_hub_) 
      {
        assert(default_id_ != -1 || default_data_ != NULL);  //maybe unlinked signal miss
        Emit(signal_type, default_id_, default_data_);
      }
    }

  private:
    boost::signal<void (int, int, t_data*)>* signal_hub_;  //will be created after first connect

    int default_id_;
    t_data* default_data_;
  };

} // namespace actor


#endif // ACTOR_SIGNAL_HUB_H
