#ifndef ACTOR_DATA_CLASS_H
#define ACTOR_DATA_CLASS_H

#include "float.h"
#include "cocos2d.h"
#include "actor_signal_hub.h"


namespace actor {

  enum eActorDataOperationType 
  {
    kActorDataOperationReset,
    kActorDataOperationSet,
    kActorDataOperation
  };


  template <typename t_attribute_data>
  //calc: ((base_ + add_) * multiplier_ + extra_)
  class ActorTemplateAttributeData : public ActorSignalHub<t_attribute_data> {
  public:
    ActorTemplateAttributeData()
      : base_(0)
      , add_(0)
      , multiplier_(1)
      , extra_(0)
      , is_limit_(false)
      , limit_min_(FLT_MIN)
      , limit_max_(FLT_MAX)
    {}
    ~ActorTemplateAttributeData()
    {}

    void Init(float base = 0, float add = 0, float multiplier = 1, float extra = 0)
    {
      base_ = base;
      add_ = add;
      multiplier_ = multiplier;
      extra_ = extra;

      this->Emit(kActorDataOperationReset);
    }


    void Reset()
    {
      add_ = 0;
      multiplier_ = 1;
      extra_ = 0;

      is_limit_ = false;
      limit_min_ = FLT_MIN; 
      limit_max_ = FLT_MAX; 

      this->Emit(kActorDataOperationReset);
    }


    void Set(float add = 0, float multiplier = 1, float extra = 0)
    {
      if (add == add_ && multiplier == multiplier_ && extra == extra_) return;

      add_ = add;
      multiplier_ = multiplier;
      extra_ = extra;

      this->Emit(kActorDataOperationSet);
    }

    void SetLimit(float min = FLT_MIN, float max = FLT_MAX) 
    { 
      if (min > max)
      {
        assert(min <= max);
        return;
      }

      limit_min_ = min; 
      limit_max_ = max; 
      is_limit_ = true;

      this->Emit(kActorDataOperationSet);
    }

    float ResetLimit() 
    { 
      is_limit_ = false;
      limit_min_ = FLT_MIN; 
      limit_max_ = FLT_MAX; 

      this->Emit(kActorDataOperationSet);
    }

    void Add(float add = 0, float multiplier = 0, float extra = 0)
    {
      if (add == 0 && multiplier == 0 && extra == 0) return;

      add_ += add;
      multiplier_ += multiplier;
      extra_ += extra;

      this->Emit(kActorDataOperationSet);
    }
    
    void Scale(float add = 1, float multiplier = 1, float extra = 1)
    {
      if (add == 1 && multiplier == 1 && extra == 1) return;

      add_ *= add;
      multiplier_ *= multiplier;
      extra_ *= extra;

      this->Emit(kActorDataOperationSet);
    }

    float Get() 
    { 
      float value = ((base_ + add_) * multiplier_ + extra_);
      
      if (is_limit_)
      {
        value = (limit_min_ > value ? limit_min_ : value);
        value = (limit_max_ < value ? limit_max_ : value);
      }
      return value; 
    }
    float GetBase() { return base_; }
    float GetAdd() { return add_; }
    float GetMultiplier() { return multiplier_; }
    float GetExtra() { return extra_; }


  private:
    float base_;          //original value
    float add_;           //modify
    float multiplier_;    //modify
    float extra_;         //modify

    bool is_limit_;
    float limit_min_;
    float limit_max_;
  };



  template <typename t_status_data>
  //status: 
  //    Default = 0
  //    Enum = [0, n]
  //    False = <= 0, True = >= 1
  //    False and True is stackable
  class ActorTemplateStatusData : public ActorSignalHub<t_status_data> {
  public:
    ActorTemplateStatusData()
      : base_(0)
      , current_(0)
    {}
    ~ActorTemplateStatusData()
    {}

    void Reset() { 
      current_ = base_; 

      this->Emit(kActorDataOperationReset);
    }

    // Use as Enum / Int
    void Init(int status) { 
      base_ = status; 
      current_ = base_; 

      this->Emit(kActorDataOperationReset);
    }
    void Set(int status) { 
      if (current_ == status) return;

      current_ = status; 

      this->Emit(kActorDataOperationSet);
    }
    int Get() { return current_; }
    int GetBase() { return base_; }

    // Use as Bool
    void  InitBool(bool bool_status) { 
      base_ = (bool_status ? 1 : 0); 
      current_ = base_; 

      this->Emit(kActorDataOperationReset);
    }

    void SetBool(bool bool_status) { Set(bool_status ? 1 : 0); }
    bool GetBool() { return (current_ > 0); }

    void SetFalse() { Set(0); }
    void SetTrue() { Set(1); }

    //if use stack, make sure other method is not used also(will cause messy logic)
    void StackFalse() { Set(current_ - 1); }
    void StackTrue() { Set(current_ + 1); }
    void Stack(bool bool_status) { Set(current_ + (bool_status ? 1 : -1)); }


  private:
    int base_;     //original value
    int current_;  //current
  };


  template <typename t_position_data>
  //geometry: 
  //    default = (0, 0)
  class ActorTemplatePositionData : public ActorSignalHub<t_position_data> {
  public:
    ActorTemplatePositionData()
    {
      base_.setPoint(0, 0);
      current_.setPoint(0, 0);
    }
    ~ActorTemplatePositionData()
    {}

    void Init(cocos2d::CCPoint &position) { 
      base_ = position; 
      current_ = base_;

      this->Emit(kActorDataOperationReset);
    }
    void Reset() { 
      current_ = base_;

      this->Emit(kActorDataOperationReset);
    }

    void Set(cocos2d::CCPoint &position) { 
      if (current_.equals(position)) return;

      current_ = position; 

      this->Emit(kActorDataOperationSet);
    }
    cocos2d::CCPoint& Get() { return current_; }

  private:
    cocos2d::CCPoint base_;
    cocos2d::CCPoint current_;
  };
} // namespace actor


#endif // ACTOR_DATA_CLASS_H