#include "actor_trigger_module_searchable.h"

#include "game/actor/actor.h"

namespace actor 
{
  void ActorTriggerModuleDataSearchable::ResetQuickFilter()
  {
//     _filter_is_use_attribute_ = false;
//     _filter_is_use_status_ = false;
//     _filter_is_use_position_ = false;
//     _filter_is_use_alive_actor_ = false;
  }
  bool ActorTriggerModuleDataSearchable::InitQuickFilter(Actor* actor)  //return init result: true = need filter, false = keep all
  {
//     ResetQuickFilter();
// 
//     return _filter_is_use_attribute_ 
//       || _filter_is_use_status_ 
//       || _filter_is_use_position_ 
//       || _filter_is_use_alive_actor_;
    return true;
  }
  bool ActorTriggerModuleDataSearchable::QuickFilter(Actor* ref_actor)  //return is_filtered: true = remove, false = keep
  {
    if (/*ref_actor->GetActorModelType() != kActorModelActor || */ref_actor->GetIsActorAlive() == false)
      return true;
    
    if (ref_actor->GetActorData()->GetActorStatusBool(kActorStatusIsSearchable) == false)
      return true;

    return false;
  }


  ActorTriggerModuleSearchable* ActorTriggerModuleSearchable::Instance()
  {
    static ActorTriggerModuleSearchable instance;
    return &instance;
  }

  bool ActorTriggerModuleSearchable::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataSearchable* trigger_module_data = dynamic_cast<ActorTriggerModuleDataSearchable*>(trigger_module_data_);

    assert(trigger_module_data);

    UpdateActorData(actor, trigger_module_data, actor_list);

    return (actor_list->size() > 0);
  }

  void ActorTriggerModuleSearchable::UpdateActorData(Actor* actor, ActorTriggerModuleDataSearchable* trigger_module_data, std::list<Actor*>* actor_list)
  {
//     bool is_filter_needed = trigger_module_data->InitQuickFilter(actor);
//     if (is_filter_needed == false) return;

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* ref_actor = *iterator;

      bool is_filter = trigger_module_data->QuickFilter(ref_actor);

      if (is_filter)
        actor_list->erase(iterator++);
      else
        ++iterator;
    }
  }

}  // namespace actor