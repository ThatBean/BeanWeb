#ifndef ACTOR_TRIGGER_MODULE_FACTION_H
#define ACTOR_TRIGGER_MODULE_FACTION_H


#include "game/actor/trigger/actor_trigger_module.h"


namespace actor 
{
  enum eActorTriggerFactionFlag
  {
    kActorTriggerFactionFlagUserSupport   = 1 << 0, //absolute faction
    kActorTriggerFactionFlagUserOppose    = 1 << 1,
    kActorTriggerFactionFlagFriendly      = 1 << 2, //relative faction
    kActorTriggerFactionFlagHostile       = 1 << 3,
    kActorTriggerFactionFlagNeutral       = 1 << 4, //above faction will exclude/filter neutral
    kActorTriggerFactionFlagSelf          = 1 << 5, //above faction will exclude/filter self(the actor)
    kActorTriggerFactionFlag = 0
  };


  class ActorTriggerModuleDataFaction : public ActorTriggerModuleData
  {
  public:
    virtual eActorTriggerModule   GetTargetTriggerModuleType() { return kActorTriggerModuleFaction; }

    //faster loop filter
    void  ResetQuickFilter();
    bool  InitQuickFilter(Actor* actor);  //return init result: true = need filter, false = keep all
    bool  QuickFilter(Actor* ref_actor);  //return is_filtered: true = remove, false = keep
    
  private:

    //quick filter data
    bool    _filter_is_filter_user_support_;
    bool    _filter_is_filter_user_oppose_;
    bool    _filter_is_filter_user_self_;
    bool    _filter_is_filter_neutral_;

    Actor*  _filter_actor_user_self_;
  };

  class ActorTriggerModuleFaction : public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleFaction() {}

  public:
    static ActorTriggerModuleFaction* Instance();
    ~ActorTriggerModuleFaction() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateFaction(Actor* actor, ActorTriggerModuleDataFaction* trigger_module_data, std::list<Actor*>* actor_list);
    
    virtual eActorTriggerModule   GetTriggerModuleType() { return kActorTriggerModuleFaction; }
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_FACTION_H