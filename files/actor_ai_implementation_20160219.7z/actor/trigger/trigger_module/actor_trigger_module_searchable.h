#ifndef ACTOR_TRIGGER_MODULE_SEARCHABLE_H
#define ACTOR_TRIGGER_MODULE_SEARCHABLE_H


#include "game/actor/trigger/actor_trigger_module.h"
#include "game/actor/typedef/actor_data_typedef.h"
#include "cocos2d.h"


namespace actor 
{
  enum eActorTriggerSearchableFlag
  {
    kActorTriggerSearchableFlagDebug = 1 << 0,

    kActorTriggerSearchableFlag = 0
  };

  class ActorTriggerModuleDataSearchable: public ActorTriggerModuleData
  {
  public:
    virtual eActorTriggerModule   GetTargetTriggerModuleType() { return kActorTriggerModuleSearchable; }

    ActorTriggerModuleDataSearchable() 
      : ActorTriggerModuleData()
    {}


    ActorTriggerModuleDataSearchable(const ActorTriggerModuleDataSearchable& source) 
      : ActorTriggerModuleData(source)
    {}

    //faster loop filter
    void ResetQuickFilter();
    bool InitQuickFilter(Actor* actor);  //return init result: true = need filter, false = keep all
    bool QuickFilter(Actor* ref_actor);  //return is_filtered: true = remove, false = keep

  private:

    //quick filter data
    bool  _filter_is_use_attribute_;
    bool  _filter_is_use_status_;
    bool  _filter_is_use_position_;
    bool  _filter_is_use_alive_actor_;
  };

  class ActorTriggerModuleSearchable: public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleSearchable() {}

  public:
    static ActorTriggerModuleSearchable* Instance();
    ~ActorTriggerModuleSearchable() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateActorData(Actor* actor, ActorTriggerModuleDataSearchable* trigger_module_data, std::list<Actor*>* actor_list);

    virtual eActorTriggerModule   GetTriggerModuleType() { return kActorTriggerModuleSearchable; }
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_SEARCHABLE_H