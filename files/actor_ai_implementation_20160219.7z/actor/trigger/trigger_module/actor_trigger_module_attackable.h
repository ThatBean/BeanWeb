#ifndef ACTOR_TRIGGER_MODULE_ATTACKABLE_H
#define ACTOR_TRIGGER_MODULE_ATTACKABLE_H


#include "game/actor/trigger/actor_trigger_module.h"
#include "game/actor/typedef/actor_data_typedef.h"
#include "cocos2d.h"


namespace actor 
{
  enum eActorTriggerAttackableFlag
  {
    kActorTriggerAttackableFlagDebug = 1 << 0,

    kActorTriggerAttackableFlag = 0
  };

  class ActorTriggerModuleDataAttackable: public ActorTriggerModuleData
  {
  public:
    virtual eActorTriggerModule   GetTargetTriggerModuleType() { return kActorTriggerModuleAttackable; }

    ActorTriggerModuleDataAttackable() 
      : ActorTriggerModuleData()
    {}

    ActorTriggerModuleDataAttackable(const ActorTriggerModuleDataAttackable& source) 
      : ActorTriggerModuleData(source)
    {}

    //faster loop filter
    void ResetQuickFilter();
    bool InitQuickFilter(Actor* actor);  //return init result: true = need filter, false = keep all
    bool QuickFilter(Actor* ref_actor);  //return is_filtered: true = remove, false = keep

  private:

    //quick filter data
    bool  _filter_is_use_attribute_;
    bool  _filter_is_use_status_;
    bool  _filter_is_use_position_;
    bool  _filter_is_use_alive_actor_;
  };

  class ActorTriggerModuleAttackable: public ActorTriggerModule //Single Instanced, process id list, should store data in trigger / actor
  {
  private:
    ActorTriggerModuleAttackable() {}

  public:
    static ActorTriggerModuleAttackable* Instance();
    ~ActorTriggerModuleAttackable() {}

    bool     Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list);

    void     UpdateActorData(Actor* actor, ActorTriggerModuleDataAttackable* trigger_module_data, std::list<Actor*>* actor_list);

    virtual eActorTriggerModule   GetTriggerModuleType() { return kActorTriggerModuleAttackable; }
  };

}  // namespace actor

#endif  // ACTOR_TRIGGER_MODULE_ATTACKABLE_H