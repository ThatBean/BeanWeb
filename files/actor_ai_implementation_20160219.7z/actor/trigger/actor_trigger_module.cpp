#include "actor_trigger_module.h"

#include "trigger_module/actor_trigger_module_faction.h"
#include "trigger_module/actor_trigger_module_geometry.h"
#include "trigger_module/actor_trigger_module_status.h"
#include "trigger_module/actor_trigger_module_searchable.h"
#include "trigger_module/actor_trigger_module_attackable.h"

#include "trigger_module/actor_trigger_module_sort.h"


namespace actor 
{

  ActorTriggerModule* GetActorTriggerModule(eActorTriggerModule module_type)
  {
    switch(module_type)
    {
    case kActorTriggerModuleFaction:
      return ActorTriggerModuleFaction::Instance();
      break;
    case kActorTriggerModuleGeometry:
      return ActorTriggerModuleGeometry::Instance();
      break;
    case kActorTriggerModuleStatus:
      return ActorTriggerModuleStatus::Instance();
      break;
    case kActorTriggerModuleSearchable:
      return ActorTriggerModuleSearchable::Instance();
      break;
    case kActorTriggerModuleAttackable:
      return ActorTriggerModuleAttackable::Instance();
      break;
    case kActorTriggerModuleSort:
      return ActorTriggerModuleSort::Instance();
      break;
    default:
      assert(false);
      return 0;
      break;
    }
  }

  ActorTriggerModuleData* GetActorTriggerModuleData(eActorTriggerModule module_type, uint_32 trigger_flag/* = 0*/)
  {
    ActorTriggerModuleData* module_data = NULL;
    
    switch(module_type)
    {
    case kActorTriggerModuleFaction:
      module_data = new ActorTriggerModuleDataFaction;
      break;
    case kActorTriggerModuleGeometry:
      module_data = new ActorTriggerModuleDataGeometry;
      break;
    case kActorTriggerModuleStatus:
      module_data = new ActorTriggerModuleDataStatus;
      break;
    case kActorTriggerModuleSearchable:
      module_data = new ActorTriggerModuleDataSearchable;
      break;
    case kActorTriggerModuleAttackable:
      module_data = new ActorTriggerModuleDataAttackable;
      break;
    case kActorTriggerModuleSort:
      module_data = new ActorTriggerModuleDataSort;
      break;
    default:
      module_data = NULL;
      break;
    }

    if (module_data)
      module_data->SetTriggerFlag(trigger_flag);
    else
      assert(false);

    return module_data;
  }


  ActorTriggerModuleData* GetActorTriggerModuleDataCopy(ActorTriggerModuleData* module_data)
  {
    ActorTriggerModuleData* result_module_data = NULL;

    switch(module_data->GetTargetTriggerModuleType())
    {
    case kActorTriggerModuleFaction:
      result_module_data = new ActorTriggerModuleDataFaction(*dynamic_cast<ActorTriggerModuleDataFaction*>(module_data));
      break;
    case kActorTriggerModuleGeometry:
      result_module_data = new ActorTriggerModuleDataGeometry(*dynamic_cast<ActorTriggerModuleDataGeometry*>(module_data));
      break;
    case kActorTriggerModuleStatus:
      result_module_data = new ActorTriggerModuleDataStatus(*dynamic_cast<ActorTriggerModuleDataStatus*>(module_data));
      break;
    case kActorTriggerModuleSearchable:
      result_module_data = new ActorTriggerModuleDataSearchable(*dynamic_cast<ActorTriggerModuleDataSearchable*>(module_data));
      break;
    case kActorTriggerModuleAttackable:
      result_module_data = new ActorTriggerModuleDataAttackable(*dynamic_cast<ActorTriggerModuleDataAttackable*>(module_data));
      break;
    case kActorTriggerModuleSort:
      result_module_data = new ActorTriggerModuleDataSort(*dynamic_cast<ActorTriggerModuleDataSort*>(module_data));
      break;
    default:
      result_module_data = NULL;
      break;
    }

    if (!result_module_data)
      assert(false);

    return result_module_data;
  }
}  // namespace actor