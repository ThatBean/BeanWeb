#ifndef ACTOR_ACTOR_H
#define ACTOR_ACTOR_H

#include "actor_ext_env.h"
#include "actor_ext/actor_ext_grid.h"

#include "data/actor_data.h"
#include "animation/actor_animation.h"

#include "template_class/script_object.h"

#include "typedef/actor_model_typedef.h"

namespace actor {

  class ActorScriptExporter;

  class ActorControl;
  class ActorBuff;
  class ActorSkill;
  class LogicStateMachine;
  class MotionStateMachine;

  class Actor : public ScriptObject
  {
  public:
    Actor();
    ~Actor();

    void    LinkScript(int actor_id, ActorExtEnv* actor_ext_env);  //script object, the link upwards to actor pool, auto called when created in ActorExtEnv
    void    UnLinkScript();
    void*   GetScriptExporter() { return actor_script_exporter_; }  //script object, for lua ActorScript access exported actor method

    void    Init(eActorModelType actor_model_type = kActorModelActor); //eActorModelType will decide how sub class is inited
    void    Update(float delta_time);

    ActorExtEnv*          GetActorExtEnv() { return actor_ext_env_; }

    ActorData*            GetActorData() { return actor_data_; }

    ActorControl*         GetControl() { return actor_control_; }
    ActorBuff*            GetBuff() { return actor_buff_; }
    ActorSkill*           GetSkill() { return actor_skill_; }
    LogicStateMachine*    GetLogicStateMachine() { return logic_state_machine_; }
    MotionStateMachine*   GetMotionStateMachine() { return motion_state_machine_; }

    ActorAnimation*       GetAnimation() { return actor_animation_; }

  public:
    eActorModelType  GetActorModelType() { return actor_model_type_; }
    bool             GetIsActorAlive();
    
    void             SetIsPause(bool is_pause);

  private:
    void OnEvent(int signal_type, int linked_value, ActorEventData* event_data);

  private:
    eActorModelType       actor_model_type_;
    bool                  is_pause_;

    ActorExtEnv*          actor_ext_env_;

    //Notice: below class will be & should be updated in Actor Update() by order
    ActorScriptExporter*  actor_script_exporter_; //provide wrapped function&data access to Lua
    ActorData*            actor_data_;  //collection of all actor-data-class, provide both data&functions

    ActorControl*         actor_control_; //Manual or Auto, may change Logic State
    ActorBuff*            actor_buff_; // TODO: Manage actor-side buff data&logic
    ActorSkill*           actor_skill_; // TODO: Manage actor-side skill data&logic
    LogicStateMachine*    logic_state_machine_; //Manage Both Logic-State&Motion-State 
    MotionStateMachine*   motion_state_machine_;  //Manage Position and Animation

    ActorAnimation*       actor_animation_; //Manage Animation

    //event signal
    ActorSignalConnection signal_connection_;
  };



} // namespace actor


#endif // actor/actor.h
