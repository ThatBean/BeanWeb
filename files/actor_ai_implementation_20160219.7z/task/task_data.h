#ifndef TASK_DATA_H
#define TASK_DATA_H

#include "task_data_typedef.h"
#include "engine/script/lua_data_tunnel.h"

namespace task {
  //============================================================================================

  class SubTaskData
  {
  public:
    SubTaskData(eTaskType type_init, eTaskSubType sub_type_init);
    
    virtual bool CheckValid(); //is any item at all
    virtual bool CheckUnlock();  //is any item waiting to complete
    virtual bool CheckComplete(); //is any item waiting to finish

    virtual void Update(int update_value);
    
    virtual bool FinishItem();  //return is more item

    virtual void Init(lua_tinker::table& init_data_table);

    virtual lua_tinker::table GetLuaDisplayData(); //lua display data

  public:
    eTaskType     type;
    eTaskSubType  sub_type;

    bool is_finished;  //already get reward

    int data_count_current;
  };

  //============================================================================================

  class TaskData
  {
  public:
    TaskData(eTaskType type_init)
      : type(type_init)
    {}

    ~TaskData();

    virtual bool  CheckValid(); //is any sub_task at all
    virtual bool  CheckNotify(); //is any sub_task waiting to complete/finish
    
    virtual void  UpdateSubTask(eTaskSubType sub_type, int update_value);

    virtual bool  FinishSubTask(eTaskSubType sub_type);  //return is more sub_task

    virtual void  InitSubTask(eTaskSubType sub_type, lua_tinker::table& init_data_table);

  public:
    eTaskType     type;
    std::map<eTaskSubType, SubTaskData*> sub_task_map;
  };

} // namespace task


#endif // TASK_DATA_H