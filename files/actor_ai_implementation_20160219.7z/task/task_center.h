#ifndef TASK_CENTER_H
#define TASK_CENTER_H

#include "task_data_typedef.h"
#include "engine/script/lua_data_tunnel.h"
#include "engine/platform/SingleInstance.h"

namespace task {

  class TaskData;
  class SubTaskData;

  class TaskCenter : public SingleInstanceObj
  {
  public:
    static TaskCenter& GetInstance();
    virtual ~TaskCenter();

  private:
    DISALLOW_COPY_AND_ASSIGN(TaskCenter);
    TaskCenter();

  public:
    void Clear(); //drop all task data
    void Init();

    void AddTaskData(TaskData* task_data);

    void FinishTask(eTaskType type, eTaskSubType sub_type);
    
    bool CheckValid(eTaskType type);
    bool CheckNotify(eTaskType type);

    void InitTaskDataFromLua(int key_id);//pop lua task init data
    void UpdateTaskDataFromLua(int key_id);//pop lua task update data

    void PushDataTunnelLuaDisplayData(int key_id, eTaskType type, bool is_active_only = true);//lua display data

  private:
    std::map<eTaskType, TaskData*> task_data_map_; // -> sub_task_data_map -> sub_task
  };


} // namespace task


#endif // TASK_CENTER_H