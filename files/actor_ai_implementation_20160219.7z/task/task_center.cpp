#include "task_center.h"

#include "task_data.h"
#include "task_custom_data.h"
#include "task_custom_method.h"

#include "game/data_table/daily_work_table.h"
#include "game/data_table/challenge_data_table.h"
#include "game/data_table/eventwork_data_table.h"

#include "game/game_manager/data_manager.h"

namespace task {
  //TaskCenter

  TaskCenter& TaskCenter::GetInstance()
  {
    static TaskCenter* TaskCenterInstance = NULL;
    if (!TaskCenterInstance)
    {
      TaskCenterInstance = new TaskCenter();
      SingleInstanceManager::GetInstance().registerSingleInstance((SingleInstanceObj**)&TaskCenterInstance, "TaskCenter");
    }
    return *TaskCenterInstance;
  }


  TaskCenter::~TaskCenter()
  {
    Clear();
  }


  TaskCenter::TaskCenter()
  {
    Clear();
    Init();
  }

  void TaskCenter::Clear()
  {
    for (std::map<eTaskType, TaskData*>::iterator iterator = task_data_map_.begin(); iterator != task_data_map_.end(); iterator ++)
    {
      TaskData* task_data = iterator->second;

      delete task_data;
    }
    task_data_map_.clear();
  }

  void TaskCenter::Init()
  {
    AddTaskData(PackTaskData(
      kTaskDaily, 
      DataManager::GetInstance().GetDailyWorkTable()->GetSubTaskItemDataList()));

    AddTaskData(PackTaskData(
      kTaskChallenge, 
      DataManager::GetInstance().GetChallengeDataTable()->GetSubTaskItemDataList()));

    AddTaskData(PackTaskData(
      kTaskEvent, 
      DataManager::GetInstance().GetEventworkDataTable()->GetSubTaskItemDataList()));
  }

  void TaskCenter::AddTaskData(TaskData* task_data)
  {
    if (!task_data)
      return;

    task_data_map_[task_data->type] = task_data;
  }


  void TaskCenter::FinishTask(eTaskType type, eTaskSubType sub_type)
  {
    if (task_data_map_.find(type) != task_data_map_.end())
    {
      task_data_map_[type]->FinishSubTask(sub_type);
    }
  }

  bool TaskCenter::CheckValid(eTaskType type)
  {
    if (task_data_map_.find(type) != task_data_map_.end())
    {
      return task_data_map_[type]->CheckValid();
    }

    return false;
  }

  bool TaskCenter::CheckNotify(eTaskType type)
  {
    if (task_data_map_.find(type) != task_data_map_.end())
    {
      return task_data_map_[type]->CheckNotify();
    }

    return false;
  }

  void TaskCenter::InitTaskDataFromLua(int key_id)
  {
    // server_task_init_data = {
    //   {
    //     task_type,
    //     task_sub_type,
    // 
    //     {
    //       task_sub_init_value,
    //       {
    //         {
    //           task_sub_item_id,
    //           task_sub_item_is_finished,
    //           task_sub_item_last_finished_timestamp,
    //         },
    //       },
    //     },
    //   },
    // }

    lua_tinker::table lua_data_table = lua_data_tunnel::PopLuaDataTableFromLua(key_id);

    //for speed
    UpdateQuickTaskDataCount();

    for (int index = 1, table_length = lua_data_table.length(); index <= table_length; index ++)
    {
      lua_tinker::table task_update_data = lua_data_table.get<lua_tinker::table>(index);

      eTaskType task_type = eTaskType(task_update_data.get<int>(1));
      eTaskSubType task_sub_type = eTaskSubType(task_update_data.get<int>(2));
      lua_tinker::table init_data_table = task_update_data.get<lua_tinker::table>(3);

      if (task_data_map_.find(task_type) != task_data_map_.end())
      {
        task_data_map_[task_type]->InitSubTask(task_sub_type, init_data_table);
      }
      else
      {
        //missed
      }
    }
  }

  void TaskCenter::UpdateTaskDataFromLua(int key_id)
  {
    // server_task_update_data = {
    //   {
    //     task_type,
    //     task_sub_type,
    // 
    //     task_sub_update_value,
    //   }
    // }

    lua_tinker::table lua_data_table = lua_data_tunnel::PopLuaDataTableFromLua(key_id);

    //for speed
    UpdateQuickTaskDataCount();

    for (int index = 1, table_length = lua_data_table.length(); index <= table_length; index ++)
    {
      lua_tinker::table task_update_data = lua_data_table.get<lua_tinker::table>(index);

      eTaskType task_type = eTaskType(task_update_data.get<int>(1));
      eTaskSubType task_sub_type = eTaskSubType(task_update_data.get<int>(2));
      int task_sub_update_value = task_update_data.get<int>(3);

      if (task_data_map_.find(task_type) != task_data_map_.end())
      {
        task_data_map_[task_type]->UpdateSubTask(task_sub_type, task_sub_update_value);
      }
      else
      {
        //missed
      }
    }
  }

  void TaskCenter::PushDataTunnelLuaDisplayData(int key_id, eTaskType type, bool is_active_only/* = true*/)
  {
    //create lua_data_table
    lua_tinker::table lua_data_table = lua_tinker::table(lua_data_tunnel::GetLuaState());

    if (task_data_map_.find(type) != task_data_map_.end())
    {
      eTaskType task_type = type;
      TaskData* task_data = task_data_map_[type];

      if (task_data->CheckValid())
      {
        int lua_table_index = 1;
        for (std::map<eTaskSubType, SubTaskData*>::iterator iterator = task_data->sub_task_map.begin(); iterator != task_data->sub_task_map.end(); iterator ++)
        {
          eTaskSubType sub_type = iterator->first;
          SubTaskData* sub_task = iterator->second;

          if (
            (!sub_task->CheckValid() || !sub_task->CheckUnlock()) 
            || (is_active_only && sub_task->is_finished)
          )
            continue;

          lua_data_table.set(lua_table_index ++, sub_task->GetLuaDisplayData());
        }

        CCLog("[TaskCenter][PushDataTunnelLuaDisplayData] packed data: %d. eTaskType: %d, is_active_only: %s", 
          lua_table_index - 1, 
          type, 
          is_active_only ? "true" : "false");
      }
    }

    lua_data_tunnel::PushLuaDataTableToLua(key_id, lua_data_table);
  }
  //TaskCenter



} // namespace task