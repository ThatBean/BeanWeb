#ifndef TASK_CUSTOM_METHOD_H
#define TASK_CUSTOM_METHOD_H

#include "task_data_typedef.h"

namespace task {
  class TaskData;
  class SubTaskData;
  class SubTaskItemData;

  typedef void (*SubTaskCustomFunction)(SubTaskData* sub_task_data, int update_value);

  
  SubTaskCustomFunction GetSubTaskCustomInitFunction(eTaskType type, eTaskSubType sub_type);
  SubTaskCustomFunction GetSubTaskCustomUpdateFunction(eTaskType type, eTaskSubType sub_type);
  SubTaskCustomFunction GetSubTaskCustomFinishFunction(eTaskType type, eTaskSubType sub_type);

  enum eTaskQuickUserDataType {
    kTaskQuickUserDataUserLevel = 1,
    kTaskQuickUserDataUserCardStar,
    kTaskQuickUserDataCardCount,
    kTaskQuickUserDataCardCountStar3,
    kTaskQuickUserDataCardCountStar4,
    kTaskQuickUserDataCardCountStar5,
    kTaskQuickUserDataCardCountEvolve3,
    kTaskQuickUserDataCardCountEvolve6,
    kTaskQuickUserDataCardCountEvolve10,
    kTaskQuickUserDataPowerTeam,
    kTaskQuickUserDataPurchasedGem,

    kTaskQuickUserDataMax,

    kTaskQuickUserData = -1,
  };

  void UpdateQuickTaskDataCount();
} // namespace task


#endif // TASK_CUSTOM_METHOD_H