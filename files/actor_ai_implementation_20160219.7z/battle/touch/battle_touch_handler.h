//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_touch_handler.h
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_TOUCH_HANDLER_H_
#define BATTLE_TOUCH_HANDLER_H_

#include "game/battle/touch/touch_handler.h"

#include "engine/base/basictypes.h"

#include "cocoa/CCGeometry.h"

namespace cocos2d {
  class CCNode;
  class CCSprite;
  class CCLabelTTF;
}

namespace battle_data {
  class BattleDataCenter;
}

namespace taomee {
  namespace battle {

    class BattleController;

    enum TouchState {
      kTouchInvalid = 0,
      kTouchBegan,
      kTouchMoved,
      kTouchEnded
    };

    class BattleTouchHandler : public TouchHandler 
    {
    public:
      BattleTouchHandler(BattleController* battle_controller);
      virtual ~BattleTouchHandler();

      void Reset();

      virtual void OnTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent* e, cocos2d::CCLayer* target_layer);
      virtual void OnTouchesMoved(cocos2d::CCSet* touches, cocos2d::CCEvent* e, cocos2d::CCLayer* target_layer);
      virtual void OnTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* e, cocos2d::CCLayer* target_layer);

      void UpdateEachFrame(float delta_time);

      void AddLine();
      void UpdateLine();
      void RemoveLine();

      void AddArea(const cocos2d::CCPoint& position);
      void RemoveArea();

      void AddAim(const int actor_id_to, const int actor_id_from);
      void RemoveAim(bool is_hide_now = true);

      void AddFocus(const int actor_id);
      void RemoveFocus();

      void AddGuardArea(const int actor_id);
      void RemoveGuardArea();

    private:
      BattleController*     battle_controller_;
      battle_data::BattleDataCenter* battle_data_center_;

      TouchState            touch_state_;

      cocos2d::CCSprite*    line_;
      cocos2d::CCNode*      area_node_;
      int                   aimed_actor_id_;
      int                   focused_actor_id_;
      int                   guard_area_actor_id_;
    };
  } /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_TOUCH_HANDLER_H_ */
