//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_touch_handler.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 22, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 22, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/touch/battle_touch_handler.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"

#include "game/battle/view/aim_mark.h"
#include "game/battle/view/battle_view.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"

#include "engine/script/lua_tinker_manager.h"


//actor
#include "game/actor/actor.h"
#include "game/actor/actor_ext_env.h"
#include "game/actor/actor_ext/actor_ext_grid.h"
#include "game/actor/actor_ext/actor_ext_user_operation.h"
#include "game/actor/animation/actor_animation_bottom_sync_layer.h"

using namespace cocos2d;

namespace taomee {
  namespace battle {

    BattleTouchHandler::BattleTouchHandler(BattleController* battle_controller)
      : touch_state_(kTouchInvalid)
      , line_(NULL)
      , area_node_(NULL)
      , aimed_actor_id_(actor::ACTOR_INVALID_ID)
      , focused_actor_id_(actor::ACTOR_INVALID_ID)
      , guard_area_actor_id_(actor::ACTOR_INVALID_ID)
    {
      battle_controller_ = battle_controller;
      battle_data_center_ = battle_controller->GetBattleDataCenter();
    }

    BattleTouchHandler::~BattleTouchHandler()
    {
      battle_controller_ = NULL;
      battle_data_center_ = NULL;

      CC_SAFE_RELEASE_NULL(line_);
      CC_SAFE_RELEASE_NULL(area_node_);

      aimed_actor_id_ = actor::ACTOR_INVALID_ID;
      focused_actor_id_ = actor::ACTOR_INVALID_ID;
      guard_area_actor_id_ = actor::ACTOR_INVALID_ID;
    }



    void BattleTouchHandler::Reset()
    {
      touch_state_ = kTouchInvalid;
      battle_controller_->GetActorExtEnv()->GetUserOperation()->Clear();
      RemoveGuardArea();
      RemoveArea();
      RemoveLine();
      RemoveFocus();
      RemoveAim();
    }

    void BattleTouchHandler::AddFocus(int actor_id)
    {
      assert(focused_actor_id_ == actor::ACTOR_INVALID_ID);

      actor::Actor* actor = battle_controller_->GetActorExtEnv()->GetActorById(actor_id);

      assert(actor);

      focused_actor_id_ = actor_id;
    }

    void BattleTouchHandler::RemoveFocus()
    {
      if (focused_actor_id_ == actor::ACTOR_INVALID_ID)
        return;

      actor::Actor* actor = battle_controller_->GetActorExtEnv()->GetActorById(focused_actor_id_);
      focused_actor_id_ = actor::ACTOR_INVALID_ID;
      if (!actor) return;
    }

    void BattleTouchHandler::AddGuardArea(int actor_id)
    {
      assert(guard_area_actor_id_ == actor::ACTOR_INVALID_ID);

      actor::Actor* actor = battle_controller_->GetActorExtEnv()->GetActorById(actor_id);

      if (!actor) return;
      actor->GetAnimation()->GetAnimationBottomSyncLayer()->StartGuardArea(10.0f);
      actor->GetAnimation()->SetColorShader(ccc4f(1.0f, 0.0f, 0.0f, 0.6f), 0.5f);

      guard_area_actor_id_ = actor_id;
    }

    void BattleTouchHandler::RemoveGuardArea()
    {
      if (guard_area_actor_id_ == actor::ACTOR_INVALID_ID)
        return;

      actor::Actor* actor = battle_controller_->GetActorExtEnv()->GetActorById(guard_area_actor_id_);
      guard_area_actor_id_ = actor::ACTOR_INVALID_ID;
      if (!actor) return;

      actor->GetAnimation()->GetAnimationBottomSyncLayer()->RemoveGuardArea();
    }




    void BattleTouchHandler::AddArea(const cocos2d::CCPoint& position)
    {
      actor::ActorExtUserOperation* user_operation = battle_controller_->GetActorExtEnv()->GetUserOperation();
      actor::Actor* actor = battle_controller_->GetActorExtEnv()->GetActorById(user_operation->GetTouchFromActorId());

      if ( !actor || !actor->GetScriptObjectIsActive()) return;

      if (area_node_ == NULL)
      {
        area_node_ = actor->GetAnimation()->GetAnimationBottomSyncLayer()->CreateGuardArea();
        area_node_->retain();
        battle_controller_->AddNodeByLayerType(area_node_, kBattleLayerBottom);
      }

      area_node_->setPosition(position);
    }

    void BattleTouchHandler::RemoveArea()
    {
      if (area_node_ != NULL)
      {
        area_node_->removeFromParentAndCleanup(true);
        CC_SAFE_RELEASE_NULL(area_node_);
      }
    }


    const int kAimMarkTag = 23333; 

    void BattleTouchHandler::AddAim(const int actor_id_to, const int actor_id_from)
    {
      if (actor_id_to == aimed_actor_id_)
        return;

      //assert(aimed_actor_id_ == actor::ACTOR_INVALID_ID);
      RemoveAim();

      actor::Actor* actor_to = battle_controller_->GetActorExtEnv()->GetActorById(actor_id_to);
      actor::Actor* actor_from = battle_controller_->GetActorExtEnv()->GetActorById(actor_id_from);

      assert(actor_to);
      CCNode* actor_node = actor_to->GetAnimation()->GetActorNode();

      taomee::battle::AimMark* aim_mark = dynamic_cast<AimMark*>(actor_node->getChildByTag(kAimMarkTag));
      if (aim_mark == NULL)
      {
        // add aim target
        aim_mark = taomee::battle::AimMark::Create(taomee::battle::kAimMarkFriend);
        aim_mark->setPositionY(actor_to->GetAnimation()->GetActorVisualHeight() * 0.5);

        actor_node->addChild(aim_mark, 10, kAimMarkTag);
      }

      bool is_same_faction = (actor_from->GetActorData()->GetActorStatus(actor::kActorStatusFaction) == actor_to->GetActorData()->GetActorStatus(actor::kActorStatusFaction));

      if (is_same_faction)
        aim_mark->OnSelected(taomee::battle::kAimMarkFriend);
      else
        aim_mark->OnSelected(taomee::battle::kAimMarkEnemy);

      aimed_actor_id_ = actor_id_to;
    }

    void BattleTouchHandler::RemoveAim(bool is_hide_now)
    {
      if (aimed_actor_id_ == actor::ACTOR_INVALID_ID)
        return;

      actor::Actor* actor = battle_controller_->GetActorExtEnv()->GetActorById(aimed_actor_id_);
      aimed_actor_id_ = actor::ACTOR_INVALID_ID;
      if (!actor) return;

      CCNode* actor_node = actor->GetAnimation()->GetActorNode();

      AimMark* aim_mark = dynamic_cast<AimMark*>(actor_node->getChildByTag(kAimMarkTag));
      if (aim_mark != NULL)
        aim_mark->OnUnselected(is_hide_now);
      else
        assert(aim_mark != NULL);
    }





    void BattleTouchHandler::AddLine()
    {
      if (line_ == NULL)
      {
        line_ = CCSprite::createWithSpriteFrameName("line.png");  //DANGER DANGER
        line_->setFlipX(true);
        line_->retain();
        line_->setAnchorPoint(ccp(0.0f, 0.5f));
      }

      if (line_->getParent() == NULL)
      {
        battle_controller_->AddNodeByLayerType(line_, kBattleLayerBottom);
      }
    }


    void BattleTouchHandler::UpdateLine()
    {
      if (touch_state_ != kTouchMoved)
      {
        if (line_ != NULL) line_->setVisible(false);
        return;
      }
      else
      {
        actor::ActorExtUserOperation* user_operation = battle_controller_->GetActorExtEnv()->GetUserOperation();

        actor::Actor* actor_from = battle_controller_->GetActorExtEnv()->GetActorById(user_operation->GetTouchFromActorId());
        if (!actor_from)
        {
          Reset();
          return;
        }

        cocos2d::CCPoint selected_position_from = actor_from->GetActorData()->GetActorPosition(actor::kActorPositionAnimation);
        cocos2d::CCPoint selected_position_to;

        if (user_operation->GetTouchToActorId() != actor::ACTOR_INVALID_ID)
        {
          actor::Actor* actor_to = battle_controller_->GetActorExtEnv()->GetActorById(user_operation->GetTouchToActorId());
          if (!actor_to)
          {
            Reset();
            return;
          }
          selected_position_to = actor_to->GetActorData()->GetActorPosition(actor::kActorPositionAnimation);
        }
        else
        {
          selected_position_to = user_operation->GetTouchToPosition();
        }


        line_->setVisible(true);
        line_->setPosition(selected_position_from);

        float line_length = selected_position_to.getDistance(selected_position_from);
        line_->setScaleX(line_length / line_->getContentSize().width);

        float radian = 2 * M_PI - ccpSub(selected_position_to, selected_position_from).getAngle();
        line_->setRotation(CC_RADIANS_TO_DEGREES(radian));
      }
    }


    void BattleTouchHandler::RemoveLine()
    {
      if (line_ != NULL) line_->setVisible(false);
    }






    void BattleTouchHandler::OnTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent*, cocos2d::CCLayer* target_layer)
    {
      if (battle_controller_->GetBattleDataCenter()->GetBattleStatusBool(battle_data::kBattleStatusIsTouchEnabled) == false)
        return;

      //reset all, including user operation
      Reset();

      // TODO(leohou): should process multi touches?
      if (touches->count() > 1)
        return;

      CCTouch* touch = dynamic_cast<CCTouch*>(touches->anyObject());
      CCPoint location_in_target_layer = target_layer->convertToNodeSpace(touch->getLocation());

      actor::ActorExtUserOperation* user_operation = battle_controller_->GetActorExtEnv()->GetUserOperation();
      actor::eActorExtUserOperationType operation_result = user_operation->UpdateTouchStart(location_in_target_layer);

      switch (operation_result)
      {
      case actor::kActorExtUserOperationCanceled:
        //clean up
        Reset();
        break;
      case actor::kActorExtUserOperationSelected:
        {
          int selected_actor_id = user_operation->GetTouchFromActorId();

          //check if the actor is predefined in script(in battle tutorial)
          if (
            battle_data_center_->GetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited)
            && (
              battle_data_center_->GetBattleStatus(battle_data::kBattleStatusTouchLimitSourceId) != actor::ACTOR_INVALID_ID 
              && battle_data_center_->GetBattleStatus(battle_data::kBattleStatusTouchLimitSourceId) != selected_actor_id
            )
          )
          {
            //clean up
            printf("Touch Invalid! Check <Touch From> Failed!\n");
            Reset();
            //no need to clear up
          }
          else
          {
            touch_state_ = kTouchBegan;
            AddFocus(selected_actor_id);
            AddGuardArea(selected_actor_id);
          }
        }
        break;
      default:
        assert(false);  //should not have other case
        //clean up
        Reset();
        break;
      }
    }


    void BattleTouchHandler::OnTouchesMoved(cocos2d::CCSet* touches, cocos2d::CCEvent*, cocos2d::CCLayer* target_layer)
    {
      if (battle_controller_->GetBattleDataCenter()->GetBattleStatusBool(battle_data::kBattleStatusIsTouchEnabled) == false)
        return;

      if (touch_state_ != kTouchBegan && touch_state_ != kTouchMoved)
        return;

      CCTouch* touch = dynamic_cast<CCTouch*>(touches->anyObject());
      CCPoint location_in_target_layer = target_layer->convertToNodeSpace(touch->getLocation());

      actor::ActorExtUserOperation* user_operation = battle_controller_->GetActorExtEnv()->GetUserOperation();

      // Note: on some android devices, just touch down and up may trigger touch moved event, so we have to filter touch moved event
      if (touch_state_ != kTouchMoved &&
        fabs(user_operation->GetTouchFromPosition().x - location_in_target_layer.x) <= actor::GetGridBoxAverageWidth() * 0.33f &&
        fabs(user_operation->GetTouchFromPosition().y - location_in_target_layer.y) <= actor::GetGridBoxAverageHeight() * 0.33f)
        return;

      RemoveGuardArea();

      bool is_last_valid_position_available = user_operation->IsTouchToSet();
      CCPoint last_valid_position = is_last_valid_position_available ? user_operation->GetTouchToPosition() : location_in_target_layer;

      actor::eActorExtUserOperationType operation_result = user_operation->UpdateTouchMove(location_in_target_layer);

      //position tweak before
      if (is_last_valid_position_available) 
      {
        switch (operation_result)
        {
        case actor::kActorExtUserOperationAttack:
        case actor::kActorExtUserOperationSwitch:
        case actor::kActorExtUserOperationMove:
          if (
            battle_data_center_->GetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited)
            && (
              (
                battle_data_center_->GetBattleStatus(battle_data::kBattleStatusTouchLimitTargetId) != actor::ACTOR_INVALID_ID
                && battle_data_center_->GetBattleStatus(battle_data::kBattleStatusTouchLimitTargetId) != user_operation->GetTouchToActorId()
              )
              || (
                battle_data_center_->GetBattlePosition(battle_data::kBattlePositionTouchLimitTargetGrid).equals(CCPointZero) == false
                && battle_data_center_->GetBattlePosition(battle_data::kBattlePositionTouchLimitTargetGrid).equals(actor::GetGridFromPosition(user_operation->GetTouchToPosition())) == false
              )
            )
          )
          {
            printf("Touch Move Invalid! Revert to last Valid\n");
            operation_result = user_operation->UpdateTouchMove(last_valid_position);
          }
        }
      }

      switch (operation_result)
      {
      case actor::kActorExtUserOperationCanceled:
        //clean up
        Reset();
        break;
      case actor::kActorExtUserOperationAttack:
      case actor::kActorExtUserOperationSwitch:
        {
          int selected_actor_id = user_operation->GetTouchToActorId();

          touch_state_ = kTouchMoved;
          RemoveFocus();
          RemoveArea();
          AddLine();
          AddAim(selected_actor_id, user_operation->GetTouchFromActorId());
        }
        break;
      case actor::kActorExtUserOperationMove:
        {
          cocos2d::CCPoint selected_position_to = user_operation->GetTouchToPosition();

          touch_state_ = kTouchMoved;
          RemoveFocus();
          RemoveAim();
          AddLine();
          AddArea(selected_position_to);
        }
        break;
      case actor::kActorExtUserOperationSkip:
        //may be the position is unable to move to
        break;
      default:
        assert(false);  //should not have other case
        Reset();
        break;
      }

      //visual tweak after
      //     switch (operation_result)
      //     {
      //     case actor::kActorExtUserOperationAttack:
      //     case actor::kActorExtUserOperationSwitch:
      //     case actor::kActorExtUserOperationMove:
      //       if ((battle_controller_->handling_target_obj_id() != actor::ACTOR_INVALID_ID
      //         && battle_controller_->handling_target_obj_id() != user_operation->GetTouchToActorId())
      //         || (battle_controller_->handling_target_tile_idx() != taomee::battle::kUnexistTileIndex
      //         && battle_controller_->handling_target_tile_idx() != GetTileIndexByCurrentPointPosition(user_operation->GetTouchToPosition())))
      //       {
      //         printf("Touch Move Invalid! Check <Touch To> Failed!\n");
      //         RemoveFocus();
      //         RemoveArea();
      //         RemoveAim();
      //         //only line left
      //       }
      //     }
    }

    void BattleTouchHandler::OnTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent*, cocos2d::CCLayer*)
    {
      if (battle_controller_->GetBattleDataCenter()->GetBattleStatusBool(battle_data::kBattleStatusIsTouchEnabled) == false)
        return;

      if (touch_state_ != kTouchMoved)
      {
        Reset();//clean up
        return;
      } 

      actor::ActorExtUserOperation* user_operation = battle_controller_->GetActorExtEnv()->GetUserOperation();



      bool is_touch_valid = true;
      if (
        battle_data_center_->GetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited)
        && (
          (
            battle_data_center_->GetBattleStatus(battle_data::kBattleStatusTouchLimitTargetId) != actor::ACTOR_INVALID_ID
            && battle_data_center_->GetBattleStatus(battle_data::kBattleStatusTouchLimitTargetId) != user_operation->GetTouchToActorId()
          )
          || (
            battle_data_center_->GetBattlePosition(battle_data::kBattlePositionTouchLimitTargetGrid).equals(CCPointZero) == false
            && battle_data_center_->GetBattlePosition(battle_data::kBattlePositionTouchLimitTargetGrid).equals(actor::GetGridFromPosition(user_operation->GetTouchToPosition())) == false
          )
        )
      )
      {
        printf("Touch Invalid! Check <Touch To> Failed!\n");
        is_touch_valid = false;
      }

      actor::eActorExtUserOperationType operation_result = user_operation->UpdateTouchEnd();

      operation_result = is_touch_valid ? operation_result : actor::kActorExtUserOperationCanceled;

      switch (operation_result)
      {
      case actor::kActorExtUserOperationFinished:
        if (is_touch_valid && battle_data_center_->GetBattleStatusBool(battle_data::kBattleStatusIsTouchLimited))
        {
          LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/battleOverlayUI/BattleOverlayUI.lua", 
            "CallFuncBattleOverlayUI", 
            "NotifySubDisplay",
            "NOTIFIER_TUTORIAL", 
            "touch_operation_finished");


          bool is_disable_legacy_level_script = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "GetActorDebugConfig", "is_disable_legacy_level_script");
          if (is_disable_legacy_level_script == false)
          {
            // [LEGACY_CHECKPOINT_SCRIPT] 
            LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
              "CallActiveBattleDataScriptFunc", 
              "Battle_Move_End");
          }
        }
        break;
      default:
        break;
      }

      //clean up
      Reset();
    }



    void BattleTouchHandler::UpdateEachFrame(float delta_time)
    {
      UpdateLine();
    }

  } /* namespace battle */
} /* namespace taomee */
