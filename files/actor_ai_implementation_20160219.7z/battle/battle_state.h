//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_state.h
//        Author: leohou
//       Version:
//          Date: Oct 20, 2013
//          Time: 10:18:30 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     10:18:30 PM
//
//////////////////////////////////////////////////////////////

#ifndef BATTLE_STATE_H_
#define BATTLE_STATE_H_

#include "engine/base/basictypes.h"
#include "engine/base/state_machine/state.h"

class BattleResourceLoader;

namespace taomee {
  namespace battle {

    class BattleController;

    // state request session
    class BattleStateMessage : public State<BattleController> {
    public:
      virtual ~BattleStateMessage();
      static BattleStateMessage* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateMessage();
      DISALLOW_COPY_AND_ASSIGN(BattleStateMessage);
    };


    // state prepare
    class BattleStatePreload : public State<BattleController> {
    public:
      virtual ~BattleStatePreload();
      static BattleStatePreload* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStatePreload();
      DISALLOW_COPY_AND_ASSIGN(BattleStatePreload);

      bool is_preload_actor_;
      bool is_preload_battle_class_;
      std::list<int> preload_id_list_;

      BattleResourceLoader* battle_resource_loader_;
    };


    // state drama
    class BattleStateDrama : public State<BattleController> {
    public:
      virtual ~BattleStateDrama();
      static BattleStateDrama* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateDrama();
      DISALLOW_COPY_AND_ASSIGN(BattleStateDrama);
    };


    // state battle start
    class BattleStateBattleStart : public State<BattleController> {
    public:
      virtual ~BattleStateBattleStart();
      static BattleStateBattleStart* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateBattleStart();
      DISALLOW_COPY_AND_ASSIGN(BattleStateBattleStart);

      int update_index_;
    };


    // state battle end
    class BattleStateBattleEnd : public State<BattleController> {
    public:
      virtual ~BattleStateBattleEnd();
      static BattleStateBattleEnd* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateBattleEnd();
      DISALLOW_COPY_AND_ASSIGN(BattleStateBattleEnd);
    };


    // state battle
    class BattleStateBattle : public State<BattleController> {
    public:
      virtual ~BattleStateBattle();
      static BattleStateBattle* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateBattle();
      DISALLOW_COPY_AND_ASSIGN(BattleStateBattle);
    };


    // state pause
    class BattleStatePause : public State<BattleController> {
    public:
      virtual ~BattleStatePause();
      static BattleStatePause* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStatePause();
      DISALLOW_COPY_AND_ASSIGN(BattleStatePause);
    };


    // state switch wave
    class BattleStateSwitchWave : public State<BattleController> {
    public:
      virtual ~BattleStateSwitchWave();
      static BattleStateSwitchWave* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateSwitchWave();
      DISALLOW_COPY_AND_ASSIGN(BattleStateSwitchWave);
    };


    // state result
    class BattleStateResult : public State<BattleController> {
    public:
      virtual ~BattleStateResult();
      static BattleStateResult* Instance();

      virtual void Enter(BattleController* battle_controller);
      virtual void UpdateEachFrame(BattleController* battle_controller, float delta);
      virtual void Exit(BattleController* battle_controller);

    private:
      BattleStateResult();
      DISALLOW_COPY_AND_ASSIGN(BattleStateResult);
    };

  } /* namespace battle */
} /* namespace taomee */

#endif /* BATTLE_STATE_H_ */
