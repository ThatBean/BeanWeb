//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_controller.h
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_CONTROLLER_H_
#define BATTLE_CONTROLLER_H_

#include "game/battle/battle_constants.h"
#include "game/battle/damage/damage_constants.h"

#include "game/user_data/user_data_constants.h"
#include "game/battle/data/battle_data_typedef.h"

#include "engine/platform/SingleInstance.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/basictypes.h"

#include <map>

USING_NS_CC;
USING_NS_CC_EXT;

namespace actor 
{
  class ActorExtEnv;
}

namespace battle_data
{
  class BattleDataCenter;
}

namespace taomee {

  class LoadHelper;

  template <typename Entity> class StateMachine;

  namespace ui
  {
    class BattleUIController;
  }

  namespace battle {

    class BattleHub;
    class BattleView;
    class LevelBase;


    /**
    * singleton, use BattleController::GetInstance() to get the instance
    */
    class BattleController : public SingleInstanceObj {
    private:
      BattleController();
      DISALLOW_COPY_AND_ASSIGN(BattleController);

    public:
      virtual ~BattleController();
      static BattleController& GetInstance();

    public: //StateMachine
      StateMachine<BattleController>* GetStateMachine();
      void UpdateEachFrame(float delta);
      void Prepare(LoadHelper* load_helper);// strange logic for "game_state_scene_transition.h"
      
    public: //all logic entrance/exit
      void Start(eBattleType battle_type,eBattleSceneType scene_type,int level_id); // Enter Battle State, will check critical data
      void End(); // End Battle State, clear all data and return to City State
      void AppEnterBackgroundDuringBattleState();

    public:
      bool BattleClassPreload();  //return is init complete
      void BattleClassClear();  //clear battle class
      void BattleResult();  //check result

      void BattleUpdate(float delta_time); //update for state battle
      void SwitchWaveUpdate(float delta_time); //update for switch wave battle

    public: //Battle Procedure
      void SwitchBattleStateMessage();  //both start and end
      void SwitchBattleStateDrama();    //both start and end

      void SwitchBattleStatePreload();
      void SwitchBattleStateBattleStart();
      void SwitchBattleStateBattle(); //may switch to BattleStatePause multiple times
      void SwitchBattleStatePause();  //may switch to BattleStateBattle multiple times
      void SwitchBattleStateSwitchWave();  //may switch to BattleStateSwitchWave multiple times
      void SwitchBattleStateBattleEnd();
      void SwitchBattleStateResult();


    //Access of Instance of Related Method/Data Bundle Class
    public:
      battle_data::BattleDataCenter* GetBattleDataCenter() { return battle_data_center_; }
      
      actor::ActorExtEnv* GetActorExtEnv() { return actor_ext_env_; }
      
      LevelBase* GetLevelEntity() { return level_entity_; }
      
      BattleView* GetBattleView() { return battle_view_; }
      
      ui::BattleUIController* GetBattleUIController() { return battle_ui_controller_; }


    // Lua API 2.0  
    public: 
      //Control
      void ToggleBattleStatePause(bool is_pause); //switch battle state logic, for Pause Menu UI
      void TriggerSpecialSkillRelease(int actor_id);  //skill release with mask layer, will check actor state
      
      //Touch //Touch limiting method for user guide  
      void ClearTouchLimit();
      bool SetTouchLimitFromActorId(int actor_id_from);
      bool SetTouchLimitFromActorIdToActorId(int actor_id_from, int actor_id_to);
      bool SetTouchLimitFromActorIdToGrid(int actor_id_from, cocos2d::CCPoint grid_position_to);
      
      //UI
      void AddNodeByLayerType(cocos2d::CCNode *node, eBattleLayerType layer_type = kBattleLayerTop);
      void AddCCLayeToBattleSceneCenter(cocos2d::CCLayer *layer);
      
      //Sandbox method for debug 
      void SandboxWin(bool is_battle_win);

      
      //Battle Data Access
      //direct access to BattleAttributeData
      bool  CheckBattleAttribute(int data_key);
      void  InitBattleAttribute(int data_key, float base = 0, float add = 0, float multiplier = 1, float extra = 0);
      void  SetBattleAttribute(int data_key, float add = 0, float multiplier = 1, float extra = 0);
      void  AddBattleAttribute(int data_key, float add = 0, float multiplier = 0, float extra = 0);
      float GetBattleAttribute(int data_key);

      //direct access to BattleStatusData
      bool  CheckBattleStatus(int data_key);
      void  InitBattleStatus(int data_key, int status);
      void  SetBattleStatus(int data_key, int status);
      int   GetBattleStatus(int data_key);
      void  InitBattleStatusBool(int data_key, bool bool_status);
      void  SetBattleStatusBool(int data_key, bool bool_status);
      bool  GetBattleStatusBool(int data_key);

      //direct access to BattlePositionData
      bool  CheckBattlePosition(int data_key);
      void  InitBattlePosition(int data_key, cocos2d::CCPoint position);
      void  SetBattlePosition(int data_key, cocos2d::CCPoint position);
      cocos2d::CCPoint&   GetBattlePosition(int data_key);


    //Instance of Related Method/Data Bundle Class
    private:
      battle_data::BattleDataCenter*    battle_data_center_; //All basic type(int/float/bool/String/CCPoint) battle data, access by key

      actor::ActorExtEnv*               actor_ext_env_; //Actor container

      LevelBase*                        level_entity_; // contains customized battle state procedure logic

      StateMachine<BattleController>*   battle_state_machine_;  // battle state contains additional procedure logic

      cocos2d::CCScene*                 root_scene_;  //root of battle ui and battle view

      ui::BattleUIController*           battle_ui_controller_;  // where button, menu add to

      BattleView*                       battle_view_; // where background, map, actor, effect add to
    };

  } /* namespace battle */
} /* namespace taomee */

#endif /* BATTLE_CONTROLLER_H_ */
