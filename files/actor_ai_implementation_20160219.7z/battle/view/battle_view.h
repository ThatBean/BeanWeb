//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_view.h
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#ifndef BATTLE_VIEW_H_
#define BATTLE_VIEW_H_

#include "game/battle/battle_constants.h"
#include "engine/base/basictypes.h"

namespace taomee {
  class TouchHelper;
}

namespace taomee {
  namespace battle {

    class BattleLayer;
    class BattleTouchHandler;

    class BattleView
    {
    public:
      BattleView(cocos2d::CCScene* root_scene);
      virtual ~BattleView();

    public:
      void Update(float delta_time);

      void CreateBattleView();

      void PauseBattleLayer();
      void ResumeBattleLayer();

      void SetTouchFliterEnable(bool flag);
      void AddNodeByLayerType(cocos2d::CCNode* element, eBattleLayerType layer_type);

      void CreateEnemyIndicatorArrow(int grid_y);

    private:
      TouchHelper* touch_helper_; //with root_scene_, mainly used the same as "root_scene_->setTouchEnable(bool)"
      BattleTouchHandler* battle_touch_handler_;  //process touch for actor

      cocos2d::CCScene* root_scene_;
      
      BattleLayer* battle_layer_; //provide Top, Middle, Bottom Layer for battle

      cocos2d::CCSpriteBatchNode* grid_batch_layer_;  //in battle_layer_ - kBattleLayerBottom
    };

  } /* namespace battle */
} /* namespace taomee */
#endif /* BATTLE_VIEW_H_ */
