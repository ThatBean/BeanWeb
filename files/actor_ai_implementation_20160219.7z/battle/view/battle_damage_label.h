//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  tiled_map.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-9-29
//          Time:  9:56
//   Description:  creation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-9-29        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_damage_label_h
#define ChainChronicle_battle_damage_label_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"
#include "game/battle/damage/damage_constants.h"

namespace taomee {
  namespace battle {

    enum eDamageType
    {
      eDamageTypeMiss                   = 1,
      eDamageTypeDamageHealthNormal     = 4,
      eDamageTypeDamageHealthCritical   = 2,
      eDamageTypeHealHealth             = 3,

      eDamageTypeStatus                 = 5,

      //not yet
      eDamageTypeDamageEnergy,
      eDamageTypeHealEnergy,

      eDamageTypeDamageMutePhysical,
      eDamageTypeDamageMuteMagical,
    };

    enum eDamageElementType
    {
      eDamageElementTypeNormal  = 0,
      eDamageElementTypeFire    = 1,
      eDamageElementTypeWater   = 2,
      eDamageElementTypeWind    = 3,
      eDamageElementTypeLight   = 4,
      eDamageElementTypeDark    = 5,
    };

    class DamageLabel : public cocos2d::CCNode
    {
    public:
      static DamageLabel* create();
      ~DamageLabel();
    protected:
      DamageLabel();

    public:
      static void ShowDamageLabelOnBattleLayer(
        cocos2d::CCPoint label_postion,
        eDamageType damage_type, 
        eDamageElementType damage_element_type,
        int element_correction, 
        int damage_value, 
        int actor_faction);
    };

  } // namespace battle
} // namespace taomee

#endif // ChainChronicle_battle_damage_label_h
