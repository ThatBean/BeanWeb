//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: aim_mark.h
//        Author: leohou
//       Version:
//          Date: Oct 13, 2013
//          Time: 11:04:00 PM
//   Description:
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     11:04:00 PM
//
//////////////////////////////////////////////////////////////

#ifndef AIM_MARK_H_
#define AIM_MARK_H_

#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
namespace battle {

enum AimMarkType {
  kAimMarkFriend = 0,
  kAimMarkEnemy
};

class AimMark : public cocos2d::CCNode {
public:
  virtual ~AimMark();

  // create a autorelease object
  static AimMark* Create(AimMarkType aim_mark_type);

  void OnSelected(AimMarkType aim_mark_type = kAimMarkEnemy);
  void OnUnselected(bool is_hide_now = true);

private:
  AimMark();

  void Init(AimMarkType aim_mark_type);

  enum State {
    kStateUnselected = 0,
    kStateSelected = 1,
  };

  void onInitScaleCompleted(cocos2d::CCNode* node);
  void onDelayFinished();

private:
  State state_;
};

} /* namespace battle */
} /* namespace taomee */
#endif /* AIM_MARK_H_ */
