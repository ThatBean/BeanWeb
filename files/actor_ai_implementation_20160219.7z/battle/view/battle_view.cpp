
//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName: battle_view.cpp
//        Author: leohou
//       Version: 
//          Date: Sep 16, 2013
//          Time:
//   Description: 
//
// History:
//      <author>    <time>      <version>   <descript>
//      leohou     Sep 16, 2013
//////////////////////////////////////////////////////////////

#include "game/battle/view/battle_view.h"

#include "game/game_manager/data_manager.h"
#include "game/game_manager/game_manager.h"

#include "game/battle/battle_controller.h"
#include "game/battle/view/battle_layer.h"

#include "game/battle/touch/battle_touch_handler.h"
#include "game/touch_helper/touch_helper.h"

#include "game/shader/shader_manager.h"

#include "game/actor/actor_ext/actor_ext_grid.h"

#include "engine/animation/skeleton_animation.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/base/cocos2d_wrapper.h"
#include "engine/base/random_helper.h"
#include "engine/base/utils_string.h"

using namespace cocos2d;

namespace taomee {
  namespace battle {

    void reversivelyPauseAllChildren(cocos2d::CCNode* node)
    {
      node->pauseSchedulerAndActions();

      cocos2d::CCObject* obj = NULL;
      CCARRAY_FOREACH(node->getChildren(), obj)
      {
        cocos2d::CCNode* child = dynamic_cast<cocos2d::CCNode*>(obj);
        reversivelyPauseAllChildren(child);
      }
    }

    void reversivelyResumeAllChildren(cocos2d::CCNode* node)
    {
      node->resumeSchedulerAndActions();

      cocos2d::CCObject* obj = NULL;
      CCARRAY_FOREACH(node->getChildren(), obj)
      {
        cocos2d::CCNode* child = dynamic_cast<cocos2d::CCNode*>(obj);
        reversivelyResumeAllChildren(child);
      }
    }

    void create_map_background(cocos2d::CCNode* parent)
    {
      string map_bg_name;
      switch(battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusBattleType))
      {
      case battle::kBattleType_PVE_Manual:
        { 
          int mapId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
            "QueryCheckPointBattleBgID",
            battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusLevelId));
          map_bg_name = "textures/map/battlemap_" + Int2String(mapId) + ".png";
        }
        break;
      case battle::kBattleType_PVP_Auto:
        map_bg_name = "textures/map/battlemap_13.png";
        break;
      case battle::kBattleType_PVP_Manual:
        map_bg_name = "textures/map/battlemap_13.png";
        break;
      case battle::kBattleType_Sandbox:
        map_bg_name = "textures/map/battlemap_debug.png";
        break;
      default:
        break;
      }  

      CCSprite* map_bg_sprite = CCSprite::create(map_bg_name.c_str());
      map_bg_sprite->setAnchorPoint(ccp(0.5f, 0.5f));
      map_bg_sprite->setPosition(CCPointZero);
      parent->addChild(map_bg_sprite, kBattleBackgroundLayer, kBattleBackgroundLayer);
    }


    void create_map_foreground(CCNode* parent)
    {
      switch(battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusBattleType))
      {
      case battle::kBattleType_PVE_Manual:
        //good
        break;
      case battle::kBattleType_PVP_Auto:
      case battle::kBattleType_PVP_Manual:
      case battle::kBattleType_Sandbox:
      default:
        return; //no foreground?
        break;
      }

      int mapId = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua",
        "QueryCheckPointBattleBgID",
        BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusLevelId));

      int foreground_shader = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/config/map_foreground_config.lua"
        ,"GetMapForeGroundShader"
        , mapId);

      std::string battle_fore_image_name = "textures/map_foreground/battlemap_" + Int2String(mapId) + "_foreground.pvr.ccz";

      if (CCFileUtils::sharedFileUtils()->isFileExist(CCFileUtils::sharedFileUtils()->fullPathForFilename(battle_fore_image_name.c_str())))
      {
        CCLayer* map_foreground_layer = CCLayer::create();
        map_foreground_layer->setContentSize(CCSizeMake(1136,640));
        map_foreground_layer->setPosition(CCPointZero);
        map_foreground_layer->setAnchorPoint(ccp(0.5f, 0.5f));
        map_foreground_layer->ignoreAnchorPointForPosition(false);

        CCSprite* map_fore_sprite_left = CCSprite::create(battle_fore_image_name.c_str());
        map_fore_sprite_left->setPosition(ccp(-50, 0));
        map_fore_sprite_left->setAnchorPoint(ccp(0, 0));
        if(foreground_shader != 0)
          map_fore_sprite_left->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderGrass));

        CCSprite* map_fore_sprite_right = CCSprite::create(battle_fore_image_name.c_str());
        map_fore_sprite_right->setFlipX(true);
        map_fore_sprite_right->setPosition(ccp(map_foreground_layer->getContentSize().width + 50,0));
        map_fore_sprite_right->setAnchorPoint(ccp(1,0));
        if(foreground_shader != 0)
          map_fore_sprite_right->setShaderProgram(shader::ShaderManager::GetInstance()->GetShaderWithType(shader::kShaderGrassReverse));

        map_foreground_layer->addChild(map_fore_sprite_left);
        map_foreground_layer->addChild(map_fore_sprite_right);

        parent->addChild(map_foreground_layer, kBattleForegroundLayer, kBattleForegroundLayer);
      }
    }


    void create_fail_marker(CCNode* parent)
    {
      bool is_create_fail_marker = true;

      switch(battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusBattleType))
      {
      case battle::kBattleType_Unknown:
      case battle::kBattleType_PVP_Auto:
      case battle::kBattleType_PVP_Manual:
      case battle::kBattleType_Sandbox:
        is_create_fail_marker = false;
      }

      switch(battle::BattleController::GetInstance().GetBattleStatus(battle_data::kBattleStatusSceneType))
      {
      case battle::kBattleSceneType_TongTianTa:
      case battle::kBattleSceneType_Daily_JinBi:
      case battle::kBattleSceneType_Daily_JingYanYaoShui:
        is_create_fail_marker = false;
      }

      if (is_create_fail_marker) 
      {
        CCSprite* colorField = CCSprite::createWithSpriteFrameName("failed_area.png");
        CCPoint pos = actor::GetPositionFromGrid(ccp(6, 2));
        colorField->setPosition(ccp(pos.x + 50, pos.y));
        colorField->setAnchorPoint(ccp(0.0f, 0.5f));

        parent->addChild(colorField);
      }
    }






    BattleView::BattleView(cocos2d::CCScene* root_scene)
      : root_scene_(root_scene)
      , touch_helper_(NULL)
      , battle_layer_(NULL)
      , grid_batch_layer_(NULL)
      , battle_touch_handler_(NULL)
    {
      touch_helper_ = TouchHelper::CreateWithRootNode(root_scene_);
      touch_helper_->retain();
      touch_helper_->registerWithTouchDispatcher(0, true);
    }

    BattleView::~BattleView()
    {
      touch_helper_->unregisterWithTouchDispatcher();
      CC_SAFE_RELEASE_NULL(touch_helper_);
      SAFE_DEL(battle_touch_handler_);
    }


    void BattleView::Update(float delta_time)
    {
      battle_touch_handler_->UpdateEachFrame(delta_time);
    }

    void BattleView::CreateBattleView()
    {
      //cover ui for different screen size
      CCLayer* ui_top_board_layer = LuaTinkerManager::GetInstance().CallLuaFunc<CCLayer*>("script/ui/ui_top_borad_layer.lua", 
        "CreateUITopBoradLayer");
      ui_top_board_layer->ignoreAnchorPointForPosition(false);
      ui_top_board_layer->setAnchorPoint(ccp(0.5f, 0.5f));
      ui_top_board_layer->setPosition(
        root_scene_->getContentSize().width * 0.5f, 
        root_scene_->getContentSize().height * 0.5f);
      root_scene_->addChild(ui_top_board_layer, kBattleTopBoardLayer);


      //container_layer_
      cocos2d::CCLayer* container_layer = CCLayer::create();
      container_layer->setPosition(
        root_scene_->getContentSize().width * 0.5f,
        root_scene_->getContentSize().height * 0.5f);
      root_scene_->addChild(container_layer, kBattleContainerLayer, kBattleContainerLayer);

      create_map_background(container_layer);
      create_map_foreground(container_layer);


      //battle_layer_ & battle_touch_handler_
      battle_layer_ = BattleLayer::create();
      battle_touch_handler_ = new BattleTouchHandler(&battle::BattleController::GetInstance());
      battle_layer_->setPosition(CCPointZero);
      battle_layer_->SetTouchHandler(battle_touch_handler_);
      container_layer->addChild(battle_layer_, kBattleLayer, kBattleLayer);
#if CC_TARGET_PLATFORM == CC_PLATFORM_IOS
      cocos2d::CCSize size = cocos2d::CCDirector::sharedDirector()->getVisibleSize();
      if (size.width == 1136) battle_layer_->setScale(1.05f);
#endif


      // grid_batch_layer_
      grid_batch_layer_ = CCSpriteBatchNode::create("textures/battle/battle_ex.pvr.ccz", 128);
      grid_batch_layer_->setAnchorPoint(ccp(0, 0));
      grid_batch_layer_->setPosition(CCPointZero);
      battle_layer_->AddNodeToLayer(grid_batch_layer_, kBattleLayerBottom);

      create_fail_marker(grid_batch_layer_);
    }


    void BattleView::AddNodeByLayerType(cocos2d::CCNode* element, eBattleLayerType layer_type)
    {
      assert(element != NULL);
      assert(battle_layer_ != NULL);

      battle_layer_->AddNodeToLayer(element, layer_type);
    }


    void BattleView::CreateEnemyIndicatorArrow(int grid_y)
    {
      if (!grid_batch_layer_ || grid_batch_layer_->getChildByTag(grid_y * 3)) 
      {
        return;
      }

      // loop and create 3 arrows with delayed animation
      for (int i = 0; i < 3; ++i) 
      {
        CCSprite* sprite_arrow = CCSprite::createWithSpriteFrameName("arrows.png");
        sprite_arrow->setPosition(ccp(20 + i * 50 + (grid_y - 1) * 10, actor::GetPositionFromGrid(1, grid_y).y - 35));
        sprite_arrow->setScale(1.0f - (grid_y - 1) * 0.1f);
        sprite_arrow->setTag(grid_y * 3 + i);
        sprite_arrow->setColor(ccc3(255, 0, 0));
        sprite_arrow->setAnchorPoint(ccp(0, 0));
        sprite_arrow->setVisible(false);
        sprite_arrow->runAction(
          CCSequence::create(
          CCDelayTime::create(i * 0.2f), 
          CCBlink::create(4.0f, 3), 
          CCRemoveSelf::create(), 
          NULL));  
        grid_batch_layer_->addChild(sprite_arrow);
      }
    }

    void BattleView::PauseBattleLayer()
    {
      reversivelyPauseAllChildren(battle_layer_);
    }

    void BattleView::ResumeBattleLayer()
    {
      reversivelyResumeAllChildren(battle_layer_);
    }

    void BattleView::SetTouchFliterEnable( bool flag )
    {
      //this is used to prevent Touch helper shield the Touch event before the ui receive it
      if (touch_helper_)
      {
        touch_helper_->SetTouchFliterEnable(flag);
      }
    }


  } /* namespace battle */
} /* namespace taomee */
