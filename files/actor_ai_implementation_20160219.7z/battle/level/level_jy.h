#ifndef Battle_Level_Elite_H
#define Battle_Level_Elite_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {
  namespace battle {

    class LevelElite : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();
      virtual void CustomBattleResult();
    };

  }//namespace battle
}//namespace taomee

#endif