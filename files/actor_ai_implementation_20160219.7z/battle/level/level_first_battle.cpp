#include "level_first_battle.h"

#include "game/battle/battle_controller.h"
#include "game/battle/battle_state.h"

#include "engine/base/state_machine/state_machine.h"

namespace taomee {
  namespace battle {
    void LevelFirstBattle::Initialize()
    {
      LevelBase::Initialize();

      m_battle_controller->InitBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
      m_battle_controller->InitBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
      m_battle_controller->InitBattleStatusBool(battle_data::kBattleStatusLevelConfigIsHideToolButton, true);
    }

    void LevelFirstBattle::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamMainIndex);
      //TransferUserTeamInitData(data::kTeamMainIndex);
    }

  }//namespace battle
}//namespace taomee