#ifndef Battle_Level_CROSS_FACTION_NPC_H
#define Battle_Level_CROSS_FACTION_NPC_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {
  namespace battle {
    class LevelCrossFactionBattleNPC : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();
    protected:
      virtual void CustomBattleResult();
    protected:
      uint_32 m_world_boss_id;
    };

  }//namespace battle
}//namespace taomee

#endif