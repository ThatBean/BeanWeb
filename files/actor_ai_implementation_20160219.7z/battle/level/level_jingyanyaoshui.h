#ifndef Battle_Level_LimitTimeKO_H
#define Battle_Level_LimitTimeKO_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {
  namespace battle {

    class LevelLimitTimeKO : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();
      virtual void CustomBattleResult();

      virtual void notifyMonsterMoveToRightBorder(uint_32 monster_id);
    };

  }//namespace battle
}//namespace taomee

#endif