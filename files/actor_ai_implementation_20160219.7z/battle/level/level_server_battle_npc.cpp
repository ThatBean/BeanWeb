#include "level_server_battle_npc.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"
#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {
    void LevelServerBattleNPC::CreateBattleActorData()
    {
	  DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamServerBattle);
	  TransferLuaUserTeamHybridInitData(data::kTeamServerBattle);



    }

    void LevelServerBattleNPC::CustomBattleResult()
    {
		LevelBase::CustomBattleResult();

		//User Quit Skip All Result logic
		if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
		{
			m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
			m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
			m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
			return;
		}

		if ( m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusResultIsWin) )
		{
			m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->DispenseWaveRecover();
		}
    }
  }//namespace battle
}//namespace taomee