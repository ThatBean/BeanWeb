
#include "level_cross_faction_pk.h"
#include "game/battle/battle_controller.h"
#include "game/actor/typedef/actor_data_typedef.h"

namespace taomee {
  namespace battle {
    void LevelCrossFactionBattle::CreateBattleActorData()
    {
		  DataManager::GetInstance().user_info()->set_default_team_index(data::kCrossFactionBattleTeam);

      TransferLuaTeamInitData("user_support", kActorIdUserSupportStart, actor::kActorFactionUserSupport);
      TransferLuaTeamInitData("user_oppose", kActorIdUserOpposeStart, actor::kActorFactionUserOppose);

    }
  }//namespace battle
}//namespace taomee