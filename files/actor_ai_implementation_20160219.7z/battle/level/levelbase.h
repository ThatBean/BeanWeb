#ifndef Battle_Level_Base_H
#define Battle_Level_Base_H

#include "game/battle/battle_constants.h"
#include "game/game_manager/data_manager.h"


namespace taomee {
  namespace battle {

    class BattleController;


    enum eActorIdType {
      kActorIdUserSupportCount = 100,//��ҽ�ɫ������
      kActorIdUserSupportStart = 0,//��ҽ�ɫ��ʼId
      kActorIdUserSupportEnd = kActorIdUserSupportStart + kActorIdUserSupportCount - 1,//��ҽ�ɫ���Id

      kActorIdUserOpposeCount = 10000,//�з���ɫ������
      kActorIdUserOpposeStart = 1000,//�з���ɫ��ʼid
      kActorIdUserOpposeEnd = kActorIdUserOpposeStart + kActorIdUserOpposeCount - 1,//�з���ɫ���id
    };


    class LevelBase
    {
    public:
      static LevelBase* CreateLevel(eBattleType battle_type, eBattleSceneType battle_scene_type);

    public:
      LevelBase();
      virtual ~LevelBase() = 0;

      virtual void Initialize();
      virtual void CreateBattleActorData();
      virtual void SetBattleEndState(eBattleEndResultType battle_end_result);

      virtual void BattleUpdate(float delta);
      virtual void SwitchWaveUpdate(float delta);

      virtual void notifyMonsterMoveToRightBorder(uint_32 monster_id);

    protected:
      virtual void CheckBattleOver();
      virtual void CustomBattleResult();

    protected:
      BattleController* m_battle_controller;
      bool m_battle_over;
    };

    // for quickly pull user cpp team card data to cpp BattleActorData
    void TransferUserTeamInitData(int team_type);

    // for quickly pull lua team card data to cpp BattleActorData
    void TransferLuaTeamInitData(const char* team_key, int start_id, int team_faction);

    // lua health/energy percent + cpp user team init
    void TransferLuaUserTeamHybridInitData(int team_type);

    // for quickly pull lua card data to cpp BattleActorData
    void TransferLuaMercenaryInitData();
  }//namespace battle
}//namespace taomee

#endif