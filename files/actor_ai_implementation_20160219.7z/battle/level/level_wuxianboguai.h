#ifndef Battle_Level_WUXIANBOGUAI_H
#define Battle_Level_WUXIANBOGUAI_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {
  namespace battle {

    class LevelWuXianBoGuai : public LevelBase
    {
    public:
	    virtual void Initialize();
      virtual void CreateBattleActorData();
      virtual void BattleUpdate(float delta);

    protected:
      virtual void CustomBattleResult();
    };

  }//namespace battle
}//namespace taomee

#endif