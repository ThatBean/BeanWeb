#include "level_faction_boss.h"

#include "game/battle/battle_controller.h"
#include "game/battle/data/battle_data_center.h"
#include "game/actor/actor.h"

#include "game/game_manager/data_manager.h"
#include "engine/script/lua_tinker_manager.h"

namespace taomee {

  namespace battle {

    LevelFaction::LevelFaction()
      : m_world_boss_id(actor::ACTOR_INVALID_ID)
    {

    }

    void LevelFaction::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamFaction);
      TransferUserTeamInitData(data::kTeamFaction);


      //get level boss id
      m_world_boss_id = actor::ACTOR_INVALID_ID;
      std::list<int> battle_actor_data_id_list = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorDataIdList();
      std::list<int>::iterator iterator = battle_actor_data_id_list.begin();
      while (iterator != battle_actor_data_id_list.end())
      {
        int actor_id = *iterator;
        battle_data::BattleActorData* battle_actor_data = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(actor_id);
        if (battle_actor_data->status_map[battle_data::kBattleStatusActorInitMarkIsWaveBoss])
        {
          assert(m_world_boss_id == actor::ACTOR_INVALID_ID);//check multi BOSS

          m_world_boss_id = actor_id;//found the BOSS!!
        }

        iterator ++;
      }

      assert(m_world_boss_id != actor::ACTOR_INVALID_ID);//check have BOSS


      //set different health
      int current_boss_hp = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "GetLuaBattleData", "FactionRaidBossHp");
      battle_data::BattleActorData* battle_actor_data = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(m_world_boss_id);
      battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthCurrent] = current_boss_hp;
      LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", 
        "SetLuaBattleData", 
        "FactionRaidBossHpStart", 
        current_boss_hp);
    }

    void LevelFaction::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      //this battle always result in win
      m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, true);


      //data transfer logic
      if (m_world_boss_id != actor::ACTOR_INVALID_ID)
      {
        actor::Actor* actor = m_battle_controller->GetActorExtEnv()->GetActorById(m_world_boss_id);
        battle_data::BattleActorData* battle_actor_data = m_battle_controller->GetBattleDataCenter()->GetBattleActorDataCenter()->GetBattleActorData(m_world_boss_id);


        float boss_health_max = battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthMax];
        float boss_health_damage = battle_actor_data->attribute_map[battle_data::kBattleAttributeActorInitHealthCurrent]
        - (actor ? actor->GetActorData()->GetActorAttribute(actor::kActorAttributeHealthCurrent) : 0.0f);
        float boss_health_damage_percent = boss_health_max > 0 
          ? (boss_health_damage / boss_health_max * 100.0f)
          : 0.0f;

        int grade = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
          "script/battle_level/level_result_grade_config.lua", 
          "GetLevelResultGrade", 
          m_battle_controller->GetBattleStatus(battle_data::kBattleStatusBattleType),
          m_battle_controller->GetBattleStatus(battle_data::kBattleStatusSceneType),
          m_battle_controller->GetBattleStatus(battle_data::kBattleStatusLevelId),
          boss_health_damage_percent);

        BattleController::GetInstance().SetBattleStatus(battle_data::kBattleStatusFinishedUnexplainableGrade, grade);


        LuaTinkerManager::GetInstance().CallLuaFunc<int>(
          "script/battle/lua_battle_data.lua", 
          "SetLuaBattleData", 
          "FactionRaidBossDamage",
          boss_health_damage);
      }
    }

  }//namespace battle
}//namespace taomee