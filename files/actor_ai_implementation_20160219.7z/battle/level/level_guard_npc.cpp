#include "level_guard_npc.h"

#include "game/battle/battle_controller.h"

namespace taomee {
  namespace battle {

    void LevelGuardNpc::CreateBattleActorData()
    {
      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamExploreExp);
      TransferUserTeamInitData(data::kTeamExploreExp);
    }

  }//namespace battle
}//namespace taomee