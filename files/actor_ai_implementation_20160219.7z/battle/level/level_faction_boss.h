#ifndef Battle_Level_Faction_H
#define Battle_Level_Faction_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {

  namespace battle {

    class LevelFaction : public LevelBase
    {
    public:
      LevelFaction();
      virtual void CreateBattleActorData();
      virtual void CustomBattleResult();

    protected:
      uint_32 m_world_boss_id;
    };

  }//namespace battle
}//namespace taomee

#endif