#ifndef Battle_Level_Cross_Faction_Battle_H
#define Battle_Level_Cross_Faction_Battle_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelbase.h"

namespace taomee {
  namespace battle {

    class LevelCrossFactionBattle : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();
    };

  }//namespace battle
}//namespace taomee

#endif