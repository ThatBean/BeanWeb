#ifndef BATTLE_LEVEL_GUARD_NPC_H
#define BATTLE_LEVEL_GUARD_NPC_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/level_mission.h"

namespace taomee {

  namespace battle {

    class LevelGuardNpc
    {
    public:
      virtual void CreateBattleActorData();
    };

  }//namespace battle
}//namespace taomee

#endif