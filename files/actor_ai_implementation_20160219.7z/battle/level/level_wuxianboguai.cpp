#include "level_wuxianboguai.h"

#include "game/battle/battle_controller.h"

#include "game/game_manager/data_manager.h"
#include "game/data_table/grade_reward_data_table.h"

#include "engine/script/lua_tinker_manager.h"

namespace taomee {
  namespace battle {
    void LevelWuXianBoGuai::Initialize()
    {
      LevelBase::Initialize();
      m_battle_controller->InitBattleAttribute(battle_data::kBattleAttributeTimeSwitchWaveLimit, -1);
    }

    void LevelWuXianBoGuai::CreateBattleActorData()
    {
      taomee::battle::BattleController::GetInstance().InitBattleStatus(battle_data::kBattleAttributeTimeBattleActiveLimit, -1);

      DataManager::GetInstance().user_info()->set_default_team_index(data::kTeamExploreWuXian);
      TransferUserTeamInitData(data::kTeamExploreWuXian);
    }

    void LevelWuXianBoGuai::CustomBattleResult()
    {
      LevelBase::CustomBattleResult();

      //User Quit Skip All Result logic
      if (m_battle_controller->GetBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit))
      {
        m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);
        //m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipMessageEnd, true);
        //m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusLevelConfigIsSkipResult, true);
        return;
      }

      //this battle always result in win
      m_battle_controller->SetBattleStatusBool(battle_data::kBattleStatusResultIsWin, true);

      // [LEGACY_CHECKPOINT_SCRIPT] data transfer logic
      float enemy_dead = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeDead);
      float enemy_total = m_battle_controller->GetBattleAttribute(battle_data::kBattleAttributeActorCountUserOpposeTotal);
      float enemy_kill_percent = enemy_total > 0 
        ? (enemy_dead / enemy_total * 100.0f)
        : 0.0f;

      int grade = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
        "script/battle_level/level_result_grade_config.lua", 
        "GetLevelResultGrade", 
        m_battle_controller->GetBattleStatus(battle_data::kBattleStatusBattleType),
        m_battle_controller->GetBattleStatus(battle_data::kBattleStatusSceneType),
        m_battle_controller->GetBattleStatus(battle_data::kBattleStatusLevelId),
        enemy_kill_percent);

      BattleController::GetInstance().SetBattleStatus(battle_data::kBattleStatusFinishedUnexplainableGrade, grade);
    }

    void LevelWuXianBoGuai::BattleUpdate(float delta)
    {
      CheckBattleOver();
    }

  }//namespace battle
}//namespace taomee