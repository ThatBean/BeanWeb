#ifndef Battle_Level_LongMarch_H
#define Battle_Level_LongMarch_H

#include "game/battle/battle_constants.h"
#include "game/battle/level/levelbase.h"

namespace taomee {

  namespace battle {

    class LevelLongMarch : public LevelBase
    {
    public:
      virtual void CreateBattleActorData();

    protected:
      virtual void CustomBattleResult();
    };

  }//namespace battle
}//namespace taomee

#endif