// /*
// 	
// #include "levelinfinitwavemonster.h"
// 
// namespace taomee {
// 
// namespace battle {
// 
// LevelInfiniteWaveMonster::LevelInfiniteWaveMonster()
// 	: m_is_waitting_award(false)
// 	, m_protecter_id(army::kUnexistTargetId)
// {
// 	m_battle_main_type = kBattleType_PVE_Manual;
// 	m_battle_scene_type = kBattleSceneType_InfiniteWaveMonster;
// }
// 
// LevelInfiniteWaveMonster::~LevelInfiniteWaveMonster()
// {
// 
// }
// 
// void LevelInfiniteWaveMonster::onInitialize()
// {
//   m_battle_data->set_team_id(data::kTeamExploreExp);
// }
// 
// void LevelInfiniteWaveMonster::notifyBattleStart()
// {
// 	LevelMission::notifyBattleStart();
// }
// 
// void LevelInfiniteWaveMonster::notifyMoveObjBorn(uint_32 move_obj_id)
// {
// 	if ( move_obj_id >= army::kCharaterObject_StartId && move_obj_id <= army::kCharaterObject_EndId )
// 	{
// 
// 	}
// 	else if ( move_obj_id >= army::kMonsterObject_StartId && move_obj_id <= army::kMonsterObject_EndId )
// 	{
//     LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/battle/lua_battle_data.lua", "CallActiveBattleDataScriptFunc", "Battle_Monster_Born", move_obj_id);
// 	}
// }
// 
// void LevelInfiniteWaveMonster::notifyMonsterMoveToRightBorder(uint_32 monster_id)
// {
// 	army::MoveObject* monster = m_monster_hub->GetUnitById(monster_id);
// 	if ( monster )
// 	{
// 		LuaTinkerManager::GetInstance().CallLuaFunc<int>(
// 			"script/battle/lua_battle_data.lua", "CallActiveBattleDataScriptFunc", "MonsterMoveToRightBorder",
// 			monster_id);
// 		monster->GoDeadStation(battle::kDeadReason_Disappear);
// 	}
// }
// 
// void LevelInfiniteWaveMonster::notifyMonsterDead(uint_32 monster_id, bool last_one, bool last_wave)
// {
// 	if ( last_wave)
// 	{
// 		if ( last_one )
// 		{
// 			if ( m_own_hub->troops()->active_ids_count() > 0)
// 			{
// 				switchBattleState(kBattleStateWin);
// 			}
// 			else
// 			{
// 				switchBattleState(kBattleStateOver);
// 			}
// 		}
// 	}
// 	else
// 	{
// 		if ( last_one)
// 		{
// 			if ( m_protecter_id == army::kUnexistTargetId )
// 			{
// // 				army::MoveObject* character0 = m_own_hub->GetUnitById(0);
// // 				if ( character0 )
// // 				{
// // 					army::Summon* summon = character0->SummonElement(1, 85022, 10);
// // 					summon->ChangeAnimationToIndex(army::kUnitAnimationIdle);
// // 					summon->set_anima_direction(kDirectionLeft);
// // 					battle::BattleController::AuraMgr()->AddAura( summon, 10064, summon->move_object_id());
// // 					m_protecter_id = summon->move_object_id();
// // 				}
// 			}
// 
// 			MonsterHub* monster_hub = dynamic_cast<MonsterHub*>(m_monster_hub);
// 			int current_round = monster_hub->GetCurrRound() + 1;
// 
// 			m_is_waitting_award = 
// 				LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", "CallActiveBattleDataScriptFunc", "Battle_RoundMonsterDead", current_round);
// 			if ( m_is_waitting_award == false)
// 			{
// 				monster_hub->emitNextWaveMonster();
// 			}
// 		}
// 	}
// }
// 
// void LevelInfiniteWaveMonster::onAwardEnd()
// {
// 	MonsterHub* monster_hub = dynamic_cast<MonsterHub*>(m_monster_hub);
// 	monster_hub->emitNextWaveMonster();
// }
// 
// void LevelInfiniteWaveMonster::notifyPlayerDead(uint_32 player_id, bool last_one)
// {
// 	if ( last_one )
// 	{
// 		switchBattleState( kBattleStateOver);
// 	}
// 	else 
// 	{
// 		if ( m_protecter_id == player_id )
// 		{
// 			switchBattleState( kBattleStateOver);
// 		}
// 	}
// }
// 
// void LevelInfiniteWaveMonster::Update(float delta)
// {
// 	if ( m_battle_over )
// 	{
// 		if ( battle_win_delay_time_ >= 0.0f )
// 		{
// 			battle_win_delay_time_ -= delta;
// 			if ( battle_win_delay_time_ < 0.0f)
// 			{
// 				onFightResult();
// 			}
// 		}
// 		return;
// 	}
// 
// 	LevelBase::Update( delta);
// 
// 	if ( m_is_waitting_award )
// 	{
// 		bool isAwardEnd = 
// 			LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/battle/lua_battle_data.lua", "CallActiveBattleDataScriptFunc", "IsAwardEnd");
// 		if ( isAwardEnd )
// 		{
// 			m_is_waitting_award = false;
// 			onAwardEnd();
// 		}
// 	}
// 
// 	if ( isBattleOver() || isBattleWin() )
// 	{
// 		int grade = LuaTinkerManager::GetInstance().CallLuaFunc<int>(
// 			"script/battle/lua_battle_data.lua", "CallActiveBattleDataScriptFunc", "GetBattleGrade",
// 			0);
//     //m_battle_data->set_pass_grade(grade);
//     BattleController::GetInstance().SetBattleStatus(battle_data::kBattleStatusFinishedUnexplainableGrade, grade);
// 
// 		m_battle_over = true;
// 		m_battle_data->set_battle_win(true);
// 		onFightEnd();
// 	}
// 	else if ( isBattleQuit())
// 	{
// 		m_battle_over = true;
// 		m_battle_data->set_battle_win(false);
// 		onFightEnd();
// 	}
// }
// 
// void LevelInfiniteWaveMonster::createUnit()
// {
//   TransferUserTeamInitData(data::kTeamExploreExp);
// }
// 
// }//namespace battle
// }//namespace taomee*/