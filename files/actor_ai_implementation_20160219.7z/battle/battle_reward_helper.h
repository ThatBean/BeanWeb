//////////////////////////////////////////////////////////////
//
//  Copyright 2008 - 2014 TaoMee Inc. 
//
//      FileName: battle_reward_helper.h
//        Author: coldouyang
//          Date: 2014/10/28 21:59
//   Description: 
//
// History:
//      <author>    <time>        <descript>
//     coldouyang    2014/10/28      add
//////////////////////////////////////////////////////////////

#ifndef BATTLE_REWARD_HELPER_H
#define BATTLE_REWARD_HELPER_H
#include "game/game_manager/data_manager.h"
#include "cocos2d.h"

template <typename Entity, typename MAP>
void addServerRewardAfterBattleWin(Entity it, Entity end, MAP& battle_reward_map_, MAP& gain_card_map_)
{
  for (; it != end; ++it)
  {
    cocos2d::CCLog("*it.get_type()==%d",(*it).get_type());
    if (((*it).get_type()&0xff) == kNormalItemType)
    {
      const std::vector<std::vector<int> >& items = (*it).get_seq();
      for (std::vector<std::vector<int> >::const_iterator it_item = items.begin();
        it_item != items.end(); ++it_item)
      {
        battle_reward_map_.insert(std::pair<int,int>(it_item->at(0),it_item->at(1)));
        DataManager::GetInstance().user_info()->AddLocalItemToUserBag(it_item->at(0),it_item->at(1));
      }      
    }
    //card
    else if (((*it).get_type()&0xff) == kCharacterType)
    {
      //to bag
      if ( (((*it).get_type()>>8)&0xff) == 1 )
      {
        const std::vector<std::vector<int > >& cards = (*it).get_seq();
        for (std::vector<std::vector<int > >::const_iterator it_card = cards.begin();
          it_card != cards.end(); ++it_card)
        {
          if ( battle_reward_map_.find(it_card->at(1)) != battle_reward_map_.end() )
          {
            std::map<uint_32,uint_32>::iterator it = battle_reward_map_.find(it_card->at(1));
            it->second = it->second + 1;
          }
          else
            battle_reward_map_.insert(std::pair<int,int>(it_card->at(1),1));
          //this->AddOneGainCardMap(it_card->at(0), it_card->at(1));
          gain_card_map_.insert(std::pair<int, int>(it_card->at(0), it_card->at(1)));
          DataManager::GetInstance().user_info()->AddServerItemToUserBag(it_card->at(0), it_card->at(1));
        }
      }
      //to mail
      else if ( (((*it).get_type()>>8)&0xff) == 2 )
      {
        cocos2d::CCLog("battle over item should drop into bag!!!");
      }
    }
}
}
#endif