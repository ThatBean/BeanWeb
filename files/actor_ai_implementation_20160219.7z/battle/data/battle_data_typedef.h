#ifndef BATTLE_DATA_TYPEDEF_H
#define BATTLE_DATA_TYPEDEF_H

#include "engine/base/basictypes.h"

namespace battle_data {

  const int BATTLE_INVALID_ID = -1;
  
  const float BATTLE_PVP_TIME_ACTIVE_LIMIT = 120.0f;
  const float BATTLE_DEFAULT_WAVE_SWITCH_TIME_LIMIT = 3.0f;
  
  //BELOW WILL BE EXPORTED TO LUA IN [battle_data_typedef.pkg]
  //BELOW WILL BE EXPORTED TO LUA IN [battle_data_typedef.pkg]
  //BELOW WILL BE EXPORTED TO LUA IN [battle_data_typedef.pkg]

  enum {
    BATTLE_ACTOR_ENEMGY_MAX = 100
  };

  enum eBattleDataClassType
  {
    kBattleDataClassAttribute = 1,
    kBattleDataClassStatus,
    kBattleDataClassPosition,
    kBattleDataClass = -1
  };


  //from 30000 to 39999
  enum eBattleAttributeType  //independent float value
  {
    kBattleAttributeInvalid = 30000, //min

    //Time
    kBattleAttributeTimeTotal,  //time passed since battle start, debug delay included
    kBattleAttributeTimeBattleTotal, //time passed without pause, without debug delay
    kBattleAttributeTimeBattleActive, //[used for display/logic]time passed without pause, without skill pause, without debug delay
    kBattleAttributeTimeBattleActiveLimit,  //limit time for TimeBattleActive, -1 for unlimited

    kBattleAttributeTimeSwitchWave, //time passed since battle wave switch, without debug delay
    kBattleAttributeTimeSwitchWaveLimit,  //limit time for wave switch, -1 for unlimited
    
    //Wave
    kBattleAttributeWaveCurrent,
    kBattleAttributeWaveCurrentTime,
    kBattleAttributeWaveSize,
    kBattleAttributeWaveCurrentActorLeft,

    //ActorCount
    kBattleAttributeActorCountTotal,  //total actor_id set in wave_map, may change during battle by script-inserting-Actor
    kBattleAttributeActorCountAlive,
    kBattleAttributeActorCountLeft,
    kBattleAttributeActorCountDead,
    
    kBattleAttributeActorCountUserSupportTotal,
    kBattleAttributeActorCountUserSupportAlive,
    kBattleAttributeActorCountUserSupportLeft,
    kBattleAttributeActorCountUserSupportDead,

    kBattleAttributeActorCountUserOpposeTotal,
    kBattleAttributeActorCountUserOpposeAlive,
    kBattleAttributeActorCountUserOpposeLeft,
    kBattleAttributeActorCountUserOpposeDead,

    // common reward win/lose, TODO: nice but still in different csv to extract, hold off
    //     kBattleAttributeRewardWinExpUser,
    //     kBattleAttributeRewardWinExpPlayer,
    //     kBattleAttributeRewardWinAp,
    //     
    //     kBattleAttributeRewardLoseExpUser,
    //     kBattleAttributeRewardLoseExpPlayer,
    //     kBattleAttributeRewardLoseAp,


    //Actor Init
    kBattleAttributeActorInitBornDelay,
    kBattleAttributeActorInitWaveHealthRecover,
    kBattleAttributeActorInitWaveEnergyRecover,

    kBattleAttributeActorInitAnimationScale,
    kBattleAttributeActorInitAttackRangeScale,
    kBattleAttributeActorInitGuardRangeScale,

    //Actor Init Attribute
    kBattleAttributeActorInitHealthMax,
    kBattleAttributeActorInitHealthCurrent,
    kBattleAttributeActorInitHealthRecover,

    kBattleAttributeActorInitEnergyMax,
    kBattleAttributeActorInitEnergyCurrent,
    kBattleAttributeActorInitEnergyRecover,

    kBattleAttributeActorInitFactorCritical,
    kBattleAttributeActorInitFactorCriticalResist,
    kBattleAttributeActorInitFactorCriticalExtra,
    
    kBattleAttributeActorInitFactorHit,

    kBattleAttributeActorInitFactorDodge,
    kBattleAttributeActorInitFactorDodgeExtra,

    kBattleAttributeActorInitFactorDamageAdjust,
    kBattleAttributeActorInitFactorDamageAdjustResist,
    kBattleAttributeActorInitFactorDamageAdjustExtra,

    kBattleAttributeActorInitFactorSkillDamage,
    kBattleAttributeActorInitFactorSkillDamageResist,

    kBattleAttributeActorInitSpeedAttack,
    kBattleAttributeActorInitSpeedMove,

    kBattleAttributeActorInitAttackPhysical,
    kBattleAttributeActorInitAttackMagical,
    kBattleAttributeActorInitAttackCritical,

    kBattleAttributeActorInitDefensePhysical,
    kBattleAttributeActorInitDefenseMagical,

    kBattleAttributeActorInitDamageAddition,
    kBattleAttributeActorInitDamageReduction,

    kBattleAttribute = 39999  //max
  };


  //from 40000 to 49999
  enum eBattleStatusType  //independent bool/enum/int value
  {
    kBattleStatusInvalid = 40000,  //min
    
    //Basic
    kBattleStatusBattleType,  //eBattleType
    kBattleStatusSceneType,   //eBattleSceneType
    kBattleStatusLevelId, //or the so called "CheckpointId" scattered all over the world?

    kBattleStatusState, //eBattleStateType, current battle state, connect signal to track change

    kBattleStatusIsPaused,
    kBattleStatusIsSkillMask,
    kBattleStatusIsUserQuit,

    //used for signal connect
    kBattleStatusConnectorActorSkillReady,
    kBattleStatusConnectorActorSkillRelease,
    kBattleStatusConnectorActorBorn,
    kBattleStatusConnectorActorDead,
    //kBattleStatusConnector,

    kBattleStatusResultIsWin, //result ui related, "over"(neither win or lose) is considered win also
    kBattleStatusResultStar,

    //battle finish "grade" related
    kBattleStatusFinishedIsUserQuit,  // special user quit

    kBattleStatusFinishedInLimitedTime,
    kBattleStatusFinishedAllAllyAlive,
    kBattleStatusFinishedWithSkillKill,
    kBattleStatusFinishedUnexplainableGrade,


    //Touch
    kBattleStatusIsTouchEnabled,
    kBattleStatusIsTouchLimited,
    kBattleStatusTouchLimitSourceId,
    kBattleStatusTouchLimitTargetId,


    //level config data
    kBattleStatusLevelConfigIsSkipMessageEnd, //skip result message, for first level, or user quit for some level
    //level config ui
    kBattleStatusLevelConfigIsSkipSwitchWaveUI, //skip switch wave ui
    kBattleStatusLevelConfigIsSkipResult, //skip Result
    kBattleStatusLevelConfigIsHideToolButton, //not speed_up/pause/auto tool button, for full auto level


    //Actor Init Status
    kBattleStatusActorInitCardId,
    kBattleStatusActorInitCardSeqId,

    kBattleStatusActorInitLevel,
    kBattleStatusActorInitEvolve,
    kBattleStatusActorInitStar,
    
    kBattleStatusActorInitFaction,
    kBattleStatusActorInitHomeDirection,

    kBattleStatusActorInitMarkIsSimpleInit, //mark for battle win user actor creation
    kBattleStatusActorInitMarkIsWaveBoss, //mark for battle wave boss

    kBattleStatusActorInitMarkIsSetDynamicAttributeData,  //goo of level/star/evolve...
    kBattleStatusActorInitMarkIsSetDynamicSkillData,  //skill unlock & level
    kBattleStatusActorInitMarkIsSetStaticAttributeData, //only from Card Data <- CardId
    kBattleStatusActorInitMarkIsVarified,

    kBattleStatus = 49999  //max
  };

  //from 50000 to 59999
  enum eBattlePositionType {
    kBattlePositionInvalid = 50000,  //min

    kBattlePositionTouchLimitTargetGrid,

    //Actor Init Position
    kBattlePositionActorInit, //either this or kBattlePositionActorInitPlacingGrid must be set for init put
    kBattlePositionActorInitPlacingGrid,  //where to place this actor, auto set to target grid
    kBattlePositionActorInitTargetGridBorn, //first forced moving target grid(combine use with actor routine), auto set grid_x by faction, career, random grid_y

    kBattlePosition = 59999  //max
  };


  enum eBattleStateType {
    kBattleStateInit = 1, //the very beginning, just init most necessary class, BattleType/SceneType/LevelID exist

    kBattleStateMarkDataReady,  //[MARK] actor, level necessary data is all collected

    kBattleStatePreLoad,    //
    kBattleStateMessageStart,
    kBattleStateDramaStart,
    
    kBattleStateMarkBattleStart,  //[MARK] battle additional init logic here, the first time to kBattleStateBattle

    kBattleStateBattle, // may enter multiple times: kBattleStateBattle <--> kBattleStateBattlePaused
    kBattleStateBattlePaused, // may enter multiple times: kBattleStateBattle <--> kBattleStateBattlePaused
    kBattleStateBattleSwitchWave, // may enter multiple times: kBattleStateBattle <--> kBattleStateSwitchWave

    kBattleStateMarkBattleEnd,  //[MARK] is_win, result stat is generated

    kBattleStateMessageEnd,
    kBattleStateResult,
    kBattleStateDramaEnd,

    kBattleStateMarkEnd,  //[MARK] last chance, will all be clean up

    kBattleState = -1
  };  

    
  enum eBattleMessageStateType {
    kBattleMessageStateError = -1,
    kBattleMessageStateWait = 1,
    kBattleMessageStateForceEnd,
    kBattleMessageStateComplete,
  };
  
  
  //ABOVE WILL BE EXPORTED TO LUA IN [battle_data_typedef.pkg]
  //ABOVE WILL BE EXPORTED TO LUA IN [battle_data_typedef.pkg]
  //ABOVE WILL BE EXPORTED TO LUA IN [battle_data_typedef.pkg]

} // namespace battle_data


#endif // BATTLE_DATA_TYPEDEF_H