#include "battle_data_center.h"

#include "game/battle/battle_controller.h"
#include "game/battle/battle_constants.h"

#include "game/battle/level/levelbase.h"

#include "game/actor/typedef/actor_data_typedef.h"
#include "game/actor/actor_ext_env.h"
#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

using namespace cocos2d;
using namespace cocos2d::extension;

using namespace actor;

namespace battle_data {

  BattleDataCenter::BattleDataCenter(taomee::battle::BattleController* battle_controller)
  {
    battle_controller_ = battle_controller;

    default_attribute_signal_data_.battle_controller = battle_controller;
    default_attribute_signal_data_.battle_data_center = this;
    default_attribute_signal_data_.type = kBattleDataClassAttribute;

    default_status_signal_data_.battle_controller = battle_controller;
    default_status_signal_data_.battle_data_center = this;
    default_status_signal_data_.type = kBattleDataClassStatus;

    default_position_signal_data_.battle_controller = battle_controller;
    default_position_signal_data_.battle_data_center = this;
    default_position_signal_data_.type = kBattleDataClassPosition;

    battle_actor_data_center_ = new BattleActorDataCenter(this);

    data_log_ = new actor::DataLog;
    data_log_->SetMute(true);
  }

  BattleDataCenter::~BattleDataCenter()
  {
    ResetData();

    if (battle_actor_data_center_)
    {
      delete battle_actor_data_center_;
      battle_actor_data_center_ = NULL;
    }

    GetLog()->AddLog("[BattleDataCenter][~BattleDataCenter]");
    //GetLog()->ShowLog(-1);
    if (data_log_) delete data_log_;
  }


  //will init to 0
  const int __battle_attribute_init_key_array_size = 16;
  const eBattleAttributeType __battle_attribute_init_key_array[] = {
    //Wave
    kBattleAttributeWaveCurrent,
    kBattleAttributeWaveCurrentTime,
    kBattleAttributeWaveSize,
    kBattleAttributeWaveCurrentActorLeft,

    //ActorCount
    kBattleAttributeActorCountTotal,  //total actor_id set in wave_map, may change during battle by script-inserting-Actor
    kBattleAttributeActorCountAlive,
    kBattleAttributeActorCountLeft,
    kBattleAttributeActorCountDead,

    kBattleAttributeActorCountUserSupportTotal,
    kBattleAttributeActorCountUserSupportAlive,
    kBattleAttributeActorCountUserSupportLeft,
    kBattleAttributeActorCountUserSupportDead,

    kBattleAttributeActorCountUserOpposeTotal,
    kBattleAttributeActorCountUserOpposeAlive,
    kBattleAttributeActorCountUserOpposeLeft,
    kBattleAttributeActorCountUserOpposeDead,
  };


  void BattleDataCenter::Init(int battle_type, int scene_type, int level_id)
  {
    ResetData();


    //Important data
    InitBattleStatus(battle_data::kBattleStatusBattleType, battle_type);
    InitBattleStatus(battle_data::kBattleStatusSceneType, scene_type);
    InitBattleStatus(battle_data::kBattleStatusLevelId, level_id);
    InitBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleState);

    InitBattleStatusBool(battle_data::kBattleStatusIsPaused, false);
    InitBattleStatusBool(battle_data::kBattleStatusIsSkillMask, false);
    InitBattleStatusBool(battle_data::kBattleStatusIsUserQuit, false);
    InitBattleStatusBool(battle_data::kBattleStatusResultIsWin, false);


    //Battle Time
    InitBattleAttribute(battle_data::kBattleAttributeTimeTotal, 0);
    InitBattleAttribute(battle_data::kBattleAttributeTimeBattleTotal, 0);
    InitBattleAttribute(battle_data::kBattleAttributeTimeBattleActive, 0);
    int time_battle_active_limit = -1;
    if (battle_type == taomee::battle::kBattleType_PVP_Auto || battle_type == taomee::battle::kBattleType_PVP_Manual)
    {
      time_battle_active_limit = battle_data::BATTLE_PVP_TIME_ACTIVE_LIMIT;
    }
    else
    {
      time_battle_active_limit = LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/mission/checkpoint_data_util.lua", 
        "QueryCheckPointMaxBattleTime", 
        level_id);
    }
    InitBattleAttribute(battle_data::kBattleAttributeTimeBattleActiveLimit, time_battle_active_limit);

    InitBattleAttribute(battle_data::kBattleAttributeTimeSwitchWave, 0);
    InitBattleAttribute(battle_data::kBattleAttributeTimeSwitchWaveLimit, battle_data::BATTLE_DEFAULT_WAVE_SWITCH_TIME_LIMIT);
    

    //Touch
    InitBattleStatusBool(battle_data::kBattleStatusIsTouchEnabled, true);
    InitBattleStatusBool(battle_data::kBattleStatusIsTouchLimited, false);
    InitBattleStatus(battle_data::kBattleStatusTouchLimitSourceId, actor::ACTOR_INVALID_ID);
    InitBattleStatus(battle_data::kBattleStatusTouchLimitTargetId, actor::ACTOR_INVALID_ID);
    InitBattlePosition(battle_data::kBattlePositionTouchLimitTargetGrid, CCPointZero);


    //flush init attribute
    for (int i = 0; i < __battle_attribute_init_key_array_size; i++)
    {
      eBattleAttributeType key_type = __battle_attribute_init_key_array[i];
      InitBattleAttribute(key_type, 0);
    }


    //default finish status
    InitBattleStatusBool(battle_data::kBattleStatusFinishedIsUserQuit, false);
    InitBattleStatusBool(battle_data::kBattleStatusFinishedInLimitedTime, true);
    InitBattleStatusBool(battle_data::kBattleStatusFinishedAllAllyAlive, true);
    InitBattleStatusBool(battle_data::kBattleStatusFinishedWithSkillKill, false);

    InitBattleStatus(battle_data::kBattleStatusFinishedUnexplainableGrade, 0);


    //init actor center
    battle_actor_data_center_->Init();


    // BATTLE STATE CHANGE
    SetBattleStatus(battle_data::kBattleStatusState, battle_data::kBattleStateInit);

    ConnectDataSignal();

    GetLog()->SetId(0);
    GetLog()->AddErrorLogF("[BattleDataCenter][Init]");
  }

  void BattleDataCenter::ResetData()
  {
    battle_actor_data_center_->ResetData();

    attribute_map_.GetDataMap()->clear();
    status_map_.GetDataMap()->clear();
    position_map_.GetDataMap()->clear();

    //keep more log
    //GetLog()->Clear();

    GetLog()->AddLog("[BattleDataCenter][ResetData]");
    GetLog()->ResetStartTime();
  }


  void BattleDataCenter::Update(float delta_time)
  {
    battle_actor_data_center_->Update(delta_time);
  }





  void BattleDataCenter::ConnectDataSignal()
  {
    //add data signal
    GetBattleStatusData(kBattleStatusIsUserQuit)->Connect<BattleDataCenter>(this, &BattleDataCenter::OnDataOperation);
  }


  void BattleDataCenter::OnDataOperation(int operation_type, int battle_data_type, BattleDataSignalData* signal_data)
  {
    int data_class_type = signal_data->type;
    BattleDataCenter* battle_data_center = signal_data->battle_data_center;
    taomee::battle::BattleController* battle_controller = signal_data->battle_controller;

    switch (battle_data_type)
    {
    case kBattleStatusIsUserQuit:
      switch (operation_type)
      {
      case kActorDataOperationReset:
      case kActorDataOperationSet:
        {
          bool battle_status_is_user_quit = battle_data_center->GetBattleStatusBool(kBattleStatusIsUserQuit);

          CCLog("[BattleDataCenter][OnDataOperation] get battle_status_is_user_quit: %s", battle_status_is_user_quit ? "true" : "false");

          if (battle_status_is_user_quit)
          {
            battle_controller->GetLevelEntity()->SetBattleEndState(taomee::battle::kBattleEndResultUserQuit);
          }
        }
        break;
      }
      break;
    }
  }


} // namespace battle_data