//////////////////////////////////////////////////////////////
//
// Copyright 2008 - 2012 TaoMee Inc.
//
//      FileName:  battle_hub.h
//        Author:  Gaven
//       Version:  1
//          Date:  2013-11-26
//          Time:  4:26
//   Description:  creatation
//
// History:
//      <author>    <time>      <version>   <descript>
//       Gaven     2013-11-26        1         create
//////////////////////////////////////////////////////////////

#ifndef ChainChronicle_battle_constants_h
#define ChainChronicle_battle_constants_h

#include "engine/base/basictypes.h"
#include "engine/base/cocos2d_wrapper.h"

namespace taomee {
  namespace battle {

    enum eBattleEndResultType
    {
      kBattleEndResultWin,
      kBattleEndResultFailed,
      kBattleEndResultUserQuit,
    };

    enum eBattleType
    {
      kBattleType_Unknown = -1,
      kBattleType_PVE_Manual = 0,
      kBattleType_PVP_Auto = 1,
      kBattleType_PVP_Manual = 2,
      kBattleType_Sandbox = 3,
      kBattleType_Count = 4
    };

    enum eBattleSceneType
    {
      kBattleSceneType_Unknown = -1,
      // ����
      kBattleSceneType_Mission = 0,
      //��������
      kBattleSceneType_Daily_WuLiMianYi,
      //ħ������
      kBattleSceneType_Daily_MoFaMianYi,
      //����ҩˮ(ʷ��ķ)
      kBattleSceneType_Daily_JingYanYaoShui,
      //���(��)
      kBattleSceneType_Daily_JinBi,
      // ͨ����
      kBattleSceneType_TongTianTa,
      // ��Ӣ����
      kBattleSceneType_JY,
      // ���ḱ��
      kBattleSceneType_FactionBoss,
      // �ػ�NPC
      kBattleSceneType_GuardNpc,
      // city PK
      kBattleSceneType_CityPK,
      // arena PK
      kBattleSceneType_ArenaPK,
      // ���� PK
      kBattleSceneType_FactionBattlePK,
      // ���޲���
      kBattleSceneType_Daily_WuXianBoGuai,
      // ����ս��
      kBattleSceneType_First_Battle,
      //�������ս
      kBattleSceneType_CrossFactionBattle,
      kBattleSceneType_CrossFactionBattleNPC,
	  //��ս��
      kBattleSceneType_ServerBattleNPC,
      kBattleSceneType_Count,
    };


    enum
    {
      kCoverLayerZorder		  = (1024<<8) - 1,
      kMaxAnimationZorder	  = 1024<<8,
    };


    /**
      * battle scene hierarchy
      *
      * battle_scene
      * ������ top_board (z = 200, a cover for designed size, "ui_top_board_layer")
      * ������ ui_layer (z = 100+)
      * ������ container_layer (z = 0)
      *     ������ top_battle_layer(z = 2)
      *     ������ battle_layer(z = 1)
      *     ��   ������ top_layer
      *     ��   ������ character_layer
      *     ��   ������ bottom_layer
      *     ������ map_layer
      */

    enum eBattleLayerType {
      kBattleContainerLayer   = 0,
      kBattleBackgroundLayer  = 1,
  
      kBattleLayer            = 10,
      kBattleLayerBottom      = 11,
      kBattleLayerMiddle      = 12,
      kBattleLayerTop         = 13,
  
      kBattleForegroundLayer  = 20,
  
      kBattleUIMenu           = 100,  // for battle ui layer
      kBattleUITop            = 101,   // for hero card show layer only
      kBattleUIMax            = 102,

      kBattleTopBoardLayer    = 200,
    };

    const cocos2d::CCSize BATTLE_DESIGN_SIZE(1136, 640);

  } // namespace battle
} // namespace taomee

#endif // ChainChronicle_battle_constants_h
