#include "actor_script_exporter.h"

#include "game/actor/actor.h"
#include "game/actor/control/actor_control.h"
#include "engine/script/lua_tinker_manager.h"

#define SCRIPT_LUA_ACTOR "script/actor/lua_actor.lua"
#define ACTOR_LUA_DEFAULT_UPDATE_MIN_DELTA_TIME 0.5


namespace actor {

  bool ActorScriptExporter::is_auto_control_ = false;

  ActorScriptExporter::ActorScriptExporter(Actor* actor)
    :actor_(actor),
    lua_actor_id_(ACTOR_ID_INVALID),
    cached_delta_time_(0),
    update_min_delta_time_(ACTOR_LUA_DEFAULT_UPDATE_MIN_DELTA_TIME)
  {
    //
  }

  ActorScriptExporter::~ActorScriptExporter()
  {
    Clear();
  }

  void ActorScriptExporter::Connect()
  {
    Clear();

    if (actor_->GetActorId() == ACTOR_ID_INVALID)
    {
      printf("[ActorScriptExporter][Connect] get <ACTOR_ID_INVALID>, skipped connect");
      assert(false);
      return;
    }

    lua_actor_id_ = LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "CreateLuaActor", actor_->GetActorId());

    assert(lua_actor_id_ == actor_->GetActorId()); //currently should be the same
  }



  void ActorScriptExporter::Init()
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID)
    {
      printf("[ActorScriptExporter][Init] get <ACTOR_ID_INVALID>, skipped init");
      assert(false);
      return;
    }

    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "InitLuaActor", lua_actor_id_, this);
  }

  void ActorScriptExporter::Clear()
  {
    if (lua_actor_id_ != ACTOR_ID_INVALID)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "RemoveLuaActor", lua_actor_id_);
    }
   
    lua_actor_id_ = ACTOR_ID_INVALID;
    cached_delta_time_ = 0;

    lua_signal_connection_map_.clear();
  }

  void ActorScriptExporter::CallLuaActorFunction(const std::string& function_name, int value_int)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "CallLuaActorFunction", lua_actor_id_, function_name.c_str(), value_int);
  }
  void ActorScriptExporter::CallLuaActorFunction(const std::string& function_name, float value_float)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "CallLuaActorFunction", lua_actor_id_, function_name.c_str(), value_float);
  }
  void ActorScriptExporter::CallLuaActorFunction(const std::string& function_name, const std::string& value_string)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "CallLuaActorFunction", lua_actor_id_, function_name.c_str(), value_string.c_str());
  }

  void ActorScriptExporter::AddLuaActorData(const std::string& key_string, int value_int)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "AddLuaActorData", lua_actor_id_, key_string.c_str(), value_int);
  }
  void ActorScriptExporter::AddLuaActorData(const std::string& key_string, float value_float)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "AddLuaActorData", lua_actor_id_, key_string.c_str(), value_float);
  }
  void ActorScriptExporter::AddLuaActorData(const std::string& key_string, const std::string& value_string)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "AddLuaActorData", lua_actor_id_, key_string.c_str(), value_string.c_str());
  }

  void ActorScriptExporter::Emit(const std::string& key)
  {
     CallLuaActorFunction("Emit", key);
  }

  void ActorScriptExporter::Update(float delta_time)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;
    cached_delta_time_ += delta_time;

    if (cached_delta_time_ >= update_min_delta_time_)  //Lua update will be less often
    {
      CallLuaActorFunction("Update", cached_delta_time_);
      cached_delta_time_ = 0;
    }
  }


  void ActorScriptExporter::OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassAttribute, actor_data_type, actor_data);
  }
  void ActorScriptExporter::OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassStatus, actor_data_type, actor_data);
  }
  void ActorScriptExporter::OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassPosition, actor_data_type, actor_data);
  }


  void ActorScriptExporter::OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;

    printf("[ActorScriptExporter][OnDataOperation] id: %d | get op: %d, c: %d, d: %d\n", actor_->GetActorId(), operation_type, data_class_type, actor_data_type);

    if (lua_signal_connection_map_.find(data_class_type) != lua_signal_connection_map_.end()
      && lua_signal_connection_map_[data_class_type].find(actor_data_type) != lua_signal_connection_map_[data_class_type].end()
      )
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "CallLuaActorFunction", lua_actor_id_, 
        "EmitDataSignal", 
        operation_type, data_class_type, actor_data_type);
    }
  }

  void ActorScriptExporter::ActorDataSignalConnect(int data_class_type, int actor_data_type)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;

    ActorSignalConnection connection;
    
    if (data_class_type == kActorDataClassAttribute)
    {
      connection = actor_->GetActorData()->GetActorAttributeData(eActorAttributeType(actor_data_type))->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnAttributeDataOperation);
    }
    if (data_class_type == kActorDataClassStatus)
    {
      connection = actor_->GetActorData()->GetActorStatusData(eActorStatusType(actor_data_type))->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnStatusDataOperation);
    }
    if (data_class_type == kActorDataClassPosition)
    {
      connection = actor_->GetActorData()->GetActorPositionData(eActorPositionType(actor_data_type))->Connect<ActorScriptExporter>(this, &ActorScriptExporter::OnPositionDataOperation);
    }

    lua_signal_connection_map_[data_class_type][actor_data_type] = connection;
  }
  void ActorScriptExporter::ActorDataSignalDisconnect(int data_class_type, int actor_data_type)
  {
    if (lua_actor_id_ == ACTOR_ID_INVALID) return;

    if (lua_signal_connection_map_.find(data_class_type) != lua_signal_connection_map_.end()
      && lua_signal_connection_map_[data_class_type].find(actor_data_type) != lua_signal_connection_map_[data_class_type].end())
    {
      if (data_class_type == kActorDataClassAttribute)
      {
        actor_->GetActorData()->GetActorAttributeData(eActorAttributeType(actor_data_type))->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      }

      if (data_class_type == kActorDataClassStatus)
      {
        actor_->GetActorData()->GetActorStatusData(eActorStatusType(actor_data_type))->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      }

      if (data_class_type == kActorDataClassPosition)
      {
        actor_->GetActorData()->GetActorPositionData(eActorPositionType(actor_data_type))->Disconnect(lua_signal_connection_map_[data_class_type][actor_data_type]);
      }

      lua_signal_connection_map_[data_class_type].erase(lua_signal_connection_map_[data_class_type].find(actor_data_type));
    }
  }


  //static
  void ActorScriptExporter::RemoveAllLuaActor()
  {
    LuaTinkerManager::GetInstance().CallLuaFunc<int>(SCRIPT_LUA_ACTOR, "RemoveAllLuaActor");
  }











  //export to lua // common static
  
  cocos2d::CCPoint ActorScriptExporter::GetPositionFromGrid(int grid_x, int grid_y)
  {
    return actor::GetPositionFromGrid(grid_x, grid_y);
  }
  cocos2d::CCPoint ActorScriptExporter::GetGridFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridFromPosition(position);
  }
  int ActorScriptExporter::GetGridXFromPositionX(float position_x)
  {
    return actor::GetGridXFromPositionX(position_x);
  }
  int ActorScriptExporter::GetGridYFromPositionY(float position_y)
  {
    return actor::GetGridYFromPositionY(position_y);
  }


  void ActorScriptExporter::ScriptAssert(bool expression, const std::string& message)
  {
    assert(expression);
    printf("[ActorScriptExporter][Assert] <%s> %s\n", expression ? "True" : "False", message.c_str());
  }


  //for debug
  void ActorScriptExporter::SimulateTouchAt(float x, float y)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);
    cocos2d::CCSet* touch_set = new cocos2d::CCSet;
    touch_set->addObject(touch);

    printf("[ActorScriptExporter][SimulateTouchAt] x:%f, y:%f\n", x, y);

    SimulateTouch(touch_set, CCTOUCHBEGAN);
    SimulateTouch(touch_set, CCTOUCHENDED);

    //delete touch;
    delete touch_set;
#endif
  }


  void ActorScriptExporter::SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    switch (touch_event_id)
    {
    case CCTOUCHBEGAN:
    case CCTOUCHMOVED:
    case CCTOUCHENDED:
    case CCTOUCHCANCELLED:
      CCDirector::sharedDirector()->getTouchDispatcher()->touches(touch_set, NULL, touch_event_id);
      break;
    default:
      assert(false);
      //touch_event_id error
      break;
    }
#endif
  }

  static CCSet* _touch_set = NULL;
  cocos2d::CCSet* ActorScriptExporter::GetTouchSet(float x, float y)
  {
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);

    //cocos2d::CCSet* touch_set = new cocos2d::CCSet;
    //touch_set->addObject(touch);
    //return touch_set;

    if (_touch_set) delete _touch_set;
    _touch_set = new cocos2d::CCSet;
    _touch_set->addObject(touch);
    return _touch_set;
  }

  const static char* __DefaultSkeletonFilePath = "textures/skeleton/";
  bool ActorScriptExporter::TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node)
  {
    std::string skeleton_config = __DefaultSkeletonFilePath + animation_name + ".xml";
    std::string skeleton_plist = __DefaultSkeletonFilePath + animation_name + ".plist";
    std::string skeleton_texture = __DefaultSkeletonFilePath + animation_name + ".pvr.ccz";

    CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(
      skeleton_texture.c_str(),
      skeleton_plist.c_str(),
      skeleton_config.c_str());
    CCArmature* armature = CCArmature::create(animation_name.c_str());
    upper_node->addChild(armature);
    armature->getAnimation()->play("bsj", 0, -1, 0);

    return true;
  }




  //export to lua // actor based

  float ActorScriptExporter::GetActorHealthPercent()
  {
    assert(actor_);
    return actor_->GetActorData()->GetBasicData()->GetCurrentHealth() * 100.0f / actor_->GetActorData()->GetBasicData()->GetTotalHealth();
  }

  cocos2d::CCPoint ActorScriptExporter::GetActorPosition()
  {
    assert(actor_);
    return actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
  }



  void ActorScriptExporter::SetActorIsAutoGuard(bool is_auto)
  {
    assert(actor_);

    if (is_auto == true)
      actor_->GetActorData()->GetActorStatusData(kActorControlStatusAutoGuardType)->Reset();
    else
      actor_->GetActorData()->SetActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardInvalid);
  }

  void ActorScriptExporter::UpdateSpecialGuard(int type)
  {
    assert(actor_);
    actor_->GetControl()->UpdateSpecialGuard(type);
  }

  ActorControlData* ActorScriptExporter::GetActorRoutineControlData()
  {
    assert(actor_);
    return actor_->GetActorData()->GetRoutineControlData();
  }

  void ActorScriptExporter::ShowActorLog(int max_line)
  {
    assert(actor_);
    actor_->GetActorData()->ShowLog(max_line);
  }

  void ActorScriptExporter::ActorScriptAssert(bool expression, const std::string& message)
  {
    assert(actor_);
    ScriptAssert(expression, message);
  }
} // namespace actor