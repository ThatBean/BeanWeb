#ifndef ACTOR_DAMAGE_DATA_H
#define ACTOR_DAMAGE_DATA_H


#include "actor_data_typedef.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorAttributeData;


  class DamagePackage {
  public:
    DamagePackage();
    ~DamagePackage();

    //new damage process
    //actor -> skill -> buff -> [final damage result] -> buff -> actor -> health change(mostly) & damage label

  public:
    //basic method
    void InitDamage();
    void AddDamage(
      eActorDamageType   damage_type,
      float   damage_add = 0,
      float   damage_multiplier = 1,
      float   damage_extra = 0
      );
    float GetDamage(Actor* actor); //get result damage(target actor)


    //will happen on skill releaser
    // [Process] actor -> skill -> buff -> final damage result
    void AddActorBasicDamage(Actor* actor); //actor status
    void AddActorSkillDamage(Actor* actor);  //skill
    void AddActorBuffDamage(Actor* actor); //buff


    //will happen on damage holder
    // [Process] final damage result -> buff -> actor -> health change(mostly) & damage label
    void ReduceActorBuffDamage(Actor* actor);
    void ReduceActorBasicDamage(Actor* actor);


  private:
    //source info
    int  source_actor_id_; //
    int  source_skill_id_; //
    std::list<int>  source_buff_id_list_; //

    //typed damage data list
    std::map<eActorDamageType, ActorAttributeData> damage_data_map_;  //each type of damage data

    //miscellaneous type info
    bool    is_normal_attack_; //normal attack can apply buff, critical, missed
    bool    is_critical_hit_;  //normal attack only
    bool    is_missed_hit_;  //normal attack only, missed, all damage useless

    bool    is_special_attack_; //special attack will ignore buff, critical, missed
  };



















  class ActorDamageData
  {
  public:
    ActorDamageData(ActorData* actor_data);
    ~ActorDamageData();


  private:
    ActorData*    actor_data_;
    //add more below
    //add more below
    //add more below
  };
} // namespace actor


#endif // ACTOR_DAMAGE_DATA_H