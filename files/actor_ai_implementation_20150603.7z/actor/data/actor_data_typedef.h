#ifndef ACTOR_DATA_TYPEDEF_H
#define ACTOR_DATA_TYPEDEF_H

#include "../actor_adapter.h"

namespace actor {

  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_CIRCLE = "attack_range_circle_red.png";
  const std::string ACTOR_GUARD_AREA_TEXTURE_NAME_BOX = "attack_red.png";


  const int ACTOR_ID_INVALID = -1;
  const int ACTOR_SKILL_ID_INVALID = -1;
  const int ACTOR_BUFF_ID_INVALID = -1;

  const float ACTOR_CONTROL_COUNTDOWN = 0.5f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_GUARD = 0.1f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_ATTACK = 0.05f; //control update interval, in second.
  const float ACTOR_CONTROL_COUNTDOWN_DEAD = 1.5f; //control update interval, in second.


  const int GRID_Y_RANGE = 3;
  const int GRID_Y_RANGE_TOP = 1;
  const int GRID_Y_RANGE_MIDDLE = 2;
  const int GRID_Y_RANGE_BOTTOM = 3;
//   const int GRID_Y_RANGE_MIDDLE = (GRID_Y_RANGE_TOP + GRID_Y_RANGE) * 0.5;
//   const int GRID_Y_RANGE_BOTTOM = GRID_Y_RANGE_TOP + (GRID_Y_RANGE - 1);

  const int GRID_X_RANGE = 6;
  const int GRID_X_RANGE_LEFT = 1;
  //const float GRID_X_RANGE_MIDDLE = 3.5;
  const int GRID_X_RANGE_RIGHT = 6;
  const int GRID_X_RANGE_LEFT_MIDDLE = 2;
  const int GRID_X_RANGE_RIGHT_MIDDLE = 5;
//   const float GRID_X_RANGE_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE) * 0.5;
//   const int GRID_X_RANGE_RIGHT = GRID_X_RANGE_LEFT + (GRID_X_RANGE - 1);
//   const int GRID_X_RANGE_LEFT_MIDDLE = (GRID_X_RANGE_LEFT + GRID_X_RANGE_MIDDLE) * 0.5;
//   const int GRID_X_RANGE_RIGHT_MIDDLE = (GRID_X_RANGE_MIDDLE + GRID_X_RANGE_RIGHT) * 0.5;


  // for player controlled actor in PVE
  const int PLAYER_IDLE_VALID_GRID_X_RANGE = 5;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = 5;
  const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = 2;
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT = GRID_X_RANGE_LEFT + (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);
//   const int PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT = GRID_X_RANGE_RIGHT - (PLAYER_IDLE_VALID_GRID_X_RANGE - 1);


  const float ACTOR_DIRECTION_CHANGE_THRESHOLD = 20;  //the minimum distance needed for a direction change


  enum eActorDataClassType
  {
    kActorDataClassAttribute,
    kActorDataClassStatus,
    kActorDataClassPosition,
    kActorDataClass
  };


  enum eActorDataOperationType {
    kActorDataOperationInit,
    kActorDataOperationReset,
    kActorDataOperationSet,
    kActorDataOperationAdd,
    //kActorDataOperation,
    kActorDataOperation
  };

  
  
  //from 1 to 9999
  enum eActorAttributeType  //independent float value
  {
    kActorAttributeInvalid = 0, //min

    //basic
    kActorAttributeTimeActive,

    kActorAttributeGuardAreaRadius, //by the number of grid, not pixel
    kActorAttributeGuardAreaWidth, //by the number of grid, not pixel
    kActorAttributeGuardAreaHeight, //by the number of grid, not pixel

    kActorAttributeAttackAreaRadius, //by the number of grid, not pixel
    kActorAttributeAttackAreaWidth, //by the number of grid, not pixel
    kActorAttributeAttackAreaHeight, //by the number of grid, not pixel


    //Health & Energy
    kActorAttributeHealthCurrent,  //battle only
    kActorAttributeEnergyCurrent,
    kActorAttributeHealthMax,  //normal
    kActorAttributeEnergyMax,

    //Rate
    kActorAttributeRateCritical,
    kActorAttributeRateHit,
    kActorAttributeRateMiss,

    //Speed
    kActorAttributeSpeedAttack,
    kActorAttributeSpeedMove,

    //Damage Related
    kActorAttributeAttackPhysical,
    kActorAttributeAttackMagical,
    kActorAttributeAttackCritical,

    kActorAttributeDefensePhysical,
    kActorAttributeDefenseMagical,
    kActorAttributeDefenseCritical,

    //kActorAttributeDamage,
    kActorAttributeDamageAddition,  //for all kinds
    kActorAttributeDamageAdditionPhysical,
    kActorAttributeDamageAdditionMagical,
    kActorAttributeDamageAdditionCritical,
    kActorAttributeDamageAdditionIce,
    kActorAttributeDamageAdditionFire,
    kActorAttributeDamageAdditionWind,
    kActorAttributeDamageAdditionHealth,
    kActorAttributeDamageAdditionEnergy,


    kActorAttributeDamageReduction, //for all kinds
    kActorAttributeDamageReductionPhysical,
    kActorAttributeDamageReductionMagical,
    kActorAttributeDamageReductionCritical,
    kActorAttributeDamageReductionIce,
    kActorAttributeDamageReductionFire,
    kActorAttributeDamageReductionWind,
    kActorAttributeDamageReductionHealth,
    kActorAttributeDamageReductionEnergy,


    kActorLogicAttributeInvalid = 1000,

    kActorMotionAttributeInvalid = 2000,

    kActorControlAttributeInvalid = 3000,

    kActorBuffAttributeInvalid = 4000,

    kActorSkillAttributeInvalid = 5000,

    kActorSkillAttributeAttackCount,
    kActorSkillAttributeAttackNormalCount,
    kActorSkillAttributeAttackPowerCount,
    kActorSkillAttributeAttackSpecialCount,


    kActorAnimationAttributeInvalid = 6000,


    kActorSpecifiedAttributeInvalid = 7000,

    //kActorAnimationAttribute,

    kActorAttribute = 9999  //max
  };







  //from 10000 to 19999
  enum eActorStatusType  //independent bool/enum/int value
  {
    kActorStatusInvalid = 10000,  //min

    //Info
    kActorStatusCardId,

    //Basic
    kActorStatusLevel,
    kActorStatusAppearance,
    kActorStatusFaction,
    kActorStatusCareer,

    kActorStatusGuardAreaType, //eActorPredefinedGuardTriggerType
    kActorStatusAttackAreaType, //eActorPredefinedAttackTriggerType

    kActorStatusLogicState,
    kActorStatusMotionState,

    //AcceptDamage(Immune = do not accept)
    kActorStatusAcceptDamage,
    kActorStatusAcceptDamagePhysical,
    kActorStatusAcceptDamageMagical,
    kActorStatusAcceptDamageCritical,
    kActorStatusAcceptDamageIce,
    kActorStatusAcceptDamageFire,
    kActorStatusAcceptDamageWind,

    //Logic & Motion
    kActorLogicStatusInvalid = 11000,

    kActorLogicStatusIsIncontrollable,
    kActorLogicStatusCanMove,
    kActorLogicStatusCanAttack,
    kActorLogicStatusCanAttackNormal,
    kActorLogicStatusCanAttackPower,
    kActorLogicStatusCanAttackSpecial,


    kActorMotionStatusInvalid = 12000,

    kActorMotionStatusIsBusy,  //IsMotionAnimationEnded

    kActorControlStatusInvalid = 13000,

    kActorControlStatusIsAuto,
    kActorControlStatusIsManual,
    kActorControlStatusAutoGuardType,
    kActorControlStatusAutoReleaseSpecialSkillType,
    kActorControlStatusAutoReleaseSpecialSkillCount,
    kActorControlStatusAutoReleaseSpecialSkillProbability,

    //Experimental & Future
    //     kActorStatusCanChangeDirection,
    //     kActorStatusCanAttackAlly,
    //     kActorStatusCanThreatAlly,  //Threat level


    kActorBuffStatusInvalid = 14000,

    kActorBuffStatusIsPauseAnimation,
    kActorBuffStatusIsChangeColor,


    kActorSkillStatusInvalid = 15000,

    kActorSkillStatusCurrentSkillId,
    kActorSkillStatusCurrentSkillType,
    kActorSkillStatusIsBusy,
    kActorSkillStatusIsPaused,
    kActorSkillStatusGuardType,
    kActorSkillStatusAttackNormalType,
    kActorSkillStatusAttackNormalSkillId,
    kActorSkillStatusAttackPowerSkillId,
    kActorSkillStatusAttackSpecialSkillId,


    kActorAnimationStatusInvalid = 16000,

    kActorAnimationStatusIsPaused,
    kActorAnimationStatusIsWeakAnimation,  //IsWeakStatusAnimation
    kActorAnimationStatusDirection,

    kActorSpecifiedStatusInvalid = 17000,

    kActorSpecifiedStatusHomeDirection,
    kActorSpecifiedStatusIsLimitGridX,

    kActorStatus = 19999  //max
  };




  //from 20000 to 29999
  enum eActorPositionType  //independent CCPoint value
  {
    kActorPositionInvalid = 20000,  //min

    //Info
    kActorPositionAnimation,  // TODO: Animation position
    kActorPositionGrid,     // TODO: Grid position
    kActorPositionMotion,     // TODO:  Motion position



    kActorLogicPositionInvalid = 21000,

    kActorMotionPositionInvalid = 22000,

    kActorMotionPositionMoveTarget,     //  Target move position
    kActorMotionPositionMoveSpeedUnit,     // Normalized speed vector(the Direction)

    kActorControlPositionInvalid = 23000,
    
    kActorBuffPositionInvalid = 24000,

    kActorSkillPositionInvalid = 25000,

    kActorAnimationPositionInvalid = 26000,

    kActorSpecifiedPositionInvalid = 27000,

    kActorSpecifiedPositionLastIdleGrid,

    //kActorPosition,
    kActorPosition = 29999  //max
  };








  enum eActorAppearanceType
  {
    kActorAppearanceCharacter,
    kActorAppearanceEnemyPawn,
    kActorAppearanceEnemyBoss,
    kActorAppearance
  };


  enum eActorFactionType
  {
    kActorFactionUserSupport,    //where user are
    kActorFactionUserOppose,   //who attacks user
    kActorFactionNeutral, //usually for some special actor that doesn't attack, or attack both
    kActorFaction
  };


  enum eActorCareerType
  {
    kActorCareerWarrior,
    kActorCareerKnight,
    kActorCareerPriest,
    kActorCareerWizard,
    kActorCareerArcher,
    kActorCareer
  };




  enum eActorControlAutoGuardType
  {
    kActorControlAutoGuardInvalid = -1,
    kActorControlAutoGuardDefault,
    kActorControlAutoGuardPreferY,  //will first respond to enemy with same grid Y
    kActorControlAutoGuard
  };


  enum eActorControlAutoReleaseSkillType
  {
    kActorControlAutoReleaseSkillInvalid = -1,
    kActorControlAutoReleaseSkillNoPause,
    kActorControlAutoReleaseSkillWithPause,
    kActorControlAutoReleaseSkillWithProbability,
    kActorControlAutoReleaseSkillByAttackCount,
    kActorControlAutoReleaseSkill
  };


  enum eActorControlIncontrollableType  //the reason why the actor is incontrollable
  {
    kActorControlIncontrollableBuff,
    kActorControlIncontrollableSkill,
    kActorControlIncontrollableScript,
    kActorControlIncontrollableOther,
    kActorControlIncontrollable
  };


  //priority of control
  //need to keep update in lua
  enum eActorControlPriority
  {
    kActorControlPriorityMin = 0,

    kActorControlPriorityCheckGuardAuto, //logic_idle check guard(result in auto move to target)

    kActorControlPriorityMoveAuto,

    kActorControlPriorityCheckAttackAuto, //logic_move check attack(result in auto normal attack)

    kActorControlPriorityAttackNormalAuto,
    kActorControlPriorityAttackNormalManual,

    kActorControlPriorityMoveManual,

    kActorControlPriorityAttackPowerAuto,

    kActorControlPriorityCounterAttackAuto, //not in use

    kActorControlPriorityAttackSpecialAuto,
    kActorControlPriorityAttackSpecialManual,

    kActorControlPriorityIncontrollable,

    kActorControlPriorityMax,

    kActorControlPriority = -1
  };





  enum eActorDamageType
  {
    kActorDamageInvalid = -1,

    kActorDamageDefault,  //mix of all

    //basic
    kActorDamagePhysical,
    kActorDamageMagical,  //mix of Elemental?
    kActorDamageCritical,

    //elemental
    kActorDamageIce,
    kActorDamageFire,
    kActorDamageWind,

    //modify directly
    kActorDamageHealth,   //Should be Healing, and should have (damage_value < 0)
    kActorDamageEnergy,   //Should be Energy Charging, and should have (damage_value < 0)

    kActorDamage,
  };



  enum eActorAnimationDirection
  {
    kActorAnimationDirectionLeft,
    kActorAnimationDirectionRight,
    kActorAnimationDirection
  };



//   enum eActorIncontrollableMotionType
//   {
//     kActorIncontrollableMotionFreezed,  //Animation Stopped, No Move, No Direction Change
//     kActorIncontrollableMotionDelayed,  //Animation Idle, No Move, No Direction Change
//     kActorIncontrollableMotionRunHome,  //Animation Move, Move To Left/Right Most, Normal Direction Change
//     kActorIncontrollableMotionPushBack, //Animation Stopped, Move Backwards a little, No Direction Change
//     kActorIncontrollableMotion
//   };
// 
// 
//   enum eActorBuffColorType  //These Type will be converted to color or shader
//   {
//     kActorBuffColorFreezed,
//     kActorBuffColorOnFire,
//     kActorBuffColorPosioned,
//     kActorBuffColorShocked,
//     kActorBuffColorStoned,
//     kActorBuffColorEtc,
//     kActorBuffColor
//   };
// 
// 
//   enum eActorBuffAnimationType  //These will be overload animation, mostly used in motion Incontrollable
//   {
//     kActorBuffAnimationIdle,
//     kActorBuffAnimationMove,
//     kActorBuffAnimationAttacked,
//     kActorBuffAnimationEtc,
//     kActorBuffAnimation
//   };


  enum eActorGuardType
  {
    kActorGuardMelee, //Circle
    kActorGuardRanged, //Rectangle front & same row
    //kActorGuard,
    kActorGuard
  };


  enum eActorAttackType
  {
    kActorAttackMelee = 1 << 0,
    kActorAttackRanged = 1 << 1,
    kActorAttackHeal = 1 << 2,
    kActorAttackPower = 1 << 3,
    kActorAttackSpecial = 1 << 4,
    kActorAttackOverload = 1 << 5,
    kActorAttack
  };




  enum eActorSpecifiedGridPreferenceType
  {
    kActorSpecifiedGridPreferNear,
    kActorSpecifiedGridPreferNearX,
    kActorSpecifiedGridPreferNearY,
    kActorSpecifiedGridPrefer
  };












} // namespace actor


#endif // ACTOR_DATA_TYPEDEF_H