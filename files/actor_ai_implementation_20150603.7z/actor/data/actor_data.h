#ifndef ACTOR_DATA_H
#define ACTOR_DATA_H

#include "actor_data_typedef.h"
#include "game/actor/template_class/actor_signal_hub.h"

// include specialized data operation class
#include "actor_basic_data.h"
#include "actor_skill_data.h"
#include "actor_buff_data.h"
#include "actor_control_data.h"
#include "actor_logic_data.h"
#include "actor_motion_data.h"
#include "actor_damage_data.h"
#include "actor_specified_data.h"

#include "cocos2d.h"



namespace actor {

  class Actor;
  class ActorData;
  class ActorTrigger;


  //calc: ((base_ + add_) * multiplier_ + extra_)
  class ActorAttributeData : public ActorSignalHub<ActorData> {
  public:
    ActorAttributeData()
      :base_(0),
      add_(0),
      multiplier_(1),
      extra_(0)
    {}

    ~ActorAttributeData()
    {}

    void  Init(float base = 0, float add = 0, float multiplier = 1, float extra = 0)
    {
      base_ = base;
      add_ = add;
      multiplier_ = multiplier;
      extra_ = extra;

      Emit(kActorDataOperationInit);
    }


    void  Reset()
    {
      add_ = 0;
      multiplier_ = 1;
      extra_ = 0;

      Emit(kActorDataOperationInit);
    }


    void  Set(float add = 0, float multiplier = 1, float extra = 0)
    {
      add_ = add;
      multiplier_ = multiplier;
      extra_ = extra;

      Emit(kActorDataOperationSet);
    }

    void  Add(float add = 0, float multiplier = 0, float extra = 0)
    {
      add_ += add;
      multiplier_ += multiplier;
      extra_ = +extra;

      Emit(kActorDataOperationAdd);
    }

    float Get() { return ((base_ + add_) * multiplier_ + extra_); }
    float GetBase() { return base_; }
    float GetAdd() { return add_; }
    float GetMultiplier() { return multiplier_; }
    float GetExtra() { return extra_; }

  private:
    float base_;          //original value
    float add_;           //modify
    float multiplier_;    //modify
    float extra_;         //modify

  };



  //status: 
  //    Default = 0
  //    Enum = [0, n]
  //    False = <= 0, True = >= 1
  //    False and True is stackable
  class ActorStatusData : public ActorSignalHub<ActorData> {
  public:
    ActorStatusData()
      :base_(0),
      current_(0)
    {}
    ~ActorStatusData()
    {}

    void  Reset() { 
      current_ = base_; 

      Emit(kActorDataOperationReset);
    }

    // Use as Enum / Int
    void  Init(int status) { 
      base_ = status; 
      current_ = base_; 

      Emit(kActorDataOperationInit);
    }
    void  Set(int status) { 
      current_ = status; 

      Emit(kActorDataOperationSet);
    }
    int   Get() { return current_; }

    // Use as Bool
    void  InitBool(bool bool_status) { 
      base_ = (bool_status ? 1 : 0); 
      current_ = base_; 

      Emit(kActorDataOperationInit);
    }
    void  SetBool(bool bool_status) { Set(bool_status ? 1 : 0); }
    bool  GetBool() { return (current_ > 0); }

    void  SetFalse() { Set(0); }
    void  SetTrue() { Set(1); }

    //if use stack, make sure other method is not used also(will cause messy logic)
    void  StackFalse() { Set(current_ - 1); }
    void  StackTrue() { Set(current_ + 1); }
    void  Stack(bool bool_status) { Set(current_ + (bool_status ? 1 : -1)); }


  private:
    int   base_;     //original value
    int   current_;  //current
  };


  //geometry: 
  //    default = (0, 0)
  class ActorPositionData : public ActorSignalHub<ActorData> {
  public:
    ActorPositionData()
    {
      base_.setPoint(0, 0);
      current_.setPoint(0, 0);
    }
    ~ActorPositionData()
    {}

    void  Init(cocos2d::CCPoint &position) { 
      base_ = position; 
      current_ = base_;

      Emit(kActorDataOperationInit);
    }
    void  Reset() { 
      current_ = base_;

      Emit(kActorDataOperationReset);
    }

    void  Set(cocos2d::CCPoint &position) { 
      current_ = position; 

      Emit(kActorDataOperationSet);
    }
    cocos2d::CCPoint& Get() { return current_; }

  private:
    cocos2d::CCPoint   base_;
    cocos2d::CCPoint   current_;
  };


















  class ActorData
  {
  public:
    ActorData(Actor* actor);
    ~ActorData();


    void Init();
    void ResetData();

    void ConnectDataSignal();

    void Update(float delta_time);

    void AddLogF(const char* format, ...);
    void AddLog(const std::string &log);
    void ShowLog(int max_line = 20);  //max_line = -1 for all log
    std::string GetLogText(int max_line = 20);  //max_line = -1 for all log

    //// Data with predefined enum keys
    //direct access to ActorAttributeData
    std::map<eActorAttributeType, ActorAttributeData>* GetActorAttributeMap() { return &actor_attribute_map_; }
    bool CheckActorAttribute(eActorAttributeType actor_attribute_type) { return (actor_attribute_map_.find(actor_attribute_type) != actor_attribute_map_.end()); }
    //get data to connect event
    ActorAttributeData* GetActorAttributeData(eActorAttributeType actor_attribute_type) { return &(actor_attribute_map_[actor_attribute_type]); }
    //normal access, with event
    void  InitActorAttribute(eActorAttributeType actor_attribute_type, float base = 0, float add = 0, float multiplier = 1, float extra = 0) 
    { 
      actor_attribute_map_[actor_attribute_type].Init(base, add, multiplier, extra); 
      actor_attribute_map_[actor_attribute_type].Link(actor_attribute_type, this);
    }
    void  SetActorAttribute(eActorAttributeType actor_attribute_type, float add = 0, float multiplier = 1, float extra = 0) { actor_attribute_map_[actor_attribute_type].Set(add, multiplier, extra); }
    void  AddActorAttribute(eActorAttributeType actor_attribute_type, float add = 0, float multiplier = 0, float extra = 0) { actor_attribute_map_[actor_attribute_type].Add(add, multiplier, extra); }
    float GetActorAttribute(eActorAttributeType actor_attribute_type) { return actor_attribute_map_[actor_attribute_type].Get(); }

    //direct access to ActorStatusData
    std::map<eActorStatusType, ActorStatusData>* GetActorStatusMap() { return &actor_status_map_; }
    bool CheckActorStatus(eActorStatusType actor_status_type) { return (actor_status_map_.find(actor_status_type) != actor_status_map_.end()); }
    //get data to connect event
    ActorStatusData* GetActorStatusData(eActorStatusType actor_status_type) { return &(actor_status_map_[actor_status_type]); }
    //normal access, with event
    void  InitActorStatus(eActorStatusType actor_status_type, int status) 
    { 
      actor_status_map_[actor_status_type].Init(status); 
      actor_status_map_[actor_status_type].Link(actor_status_type, this);
    }
    void  SetActorStatus(eActorStatusType actor_status_type, int status) { actor_status_map_[actor_status_type].Set(status); }
    int   GetActorStatus(eActorStatusType actor_status_type) { return actor_status_map_[actor_status_type].Get(); }
    //normal access, with event
    void  InitActorStatusBool(eActorStatusType actor_status_type, bool bool_status) 
    { 
      actor_status_map_[actor_status_type].InitBool(bool_status); 
      actor_status_map_[actor_status_type].Link(actor_status_type, this);
    }
    void  SetActorStatusBool(eActorStatusType actor_status_type, bool bool_status) { actor_status_map_[actor_status_type].SetBool(bool_status); }
    bool  GetActorStatusBool(eActorStatusType actor_status_type) { return actor_status_map_[actor_status_type].GetBool(); }


    //direct access to ActorPositionData
    std::map<eActorPositionType, ActorPositionData>* GetActorPositionMap() { return &actor_position_map_; }
    bool CheckActorPosition(eActorPositionType actor_position_type) { return (actor_position_map_.find(actor_position_type) != actor_position_map_.end()); }
    //get data to connect event
    ActorPositionData* GetActorPositionData(eActorPositionType actor_position_type) { return &(actor_position_map_[actor_position_type]); }
    //normal access, with event
    void  InitActorPosition(eActorPositionType actor_position_type, cocos2d::CCPoint position) 
    { 
      actor_position_map_[actor_position_type].Init(position); 
      actor_position_map_[actor_position_type].Link(actor_position_type, this);
    }
    void  SetActorPosition(eActorPositionType actor_position_type, cocos2d::CCPoint position) { actor_position_map_[actor_position_type].Set(position); }
    cocos2d::CCPoint&   GetActorPosition(eActorPositionType actor_position_type) { return actor_position_map_[actor_position_type].Get(); }



    //Actor*                GetActor() { return actor_; } //should not often be accessed directly in data

    ActorBasicData*       GetBasicData() { return basic_data_; }
    ActorSkillData*       GetSkillData() { return skill_data_; }
    ActorBuffData*        GetBuffData() { return buff_data_; }
    ActorDamageData*      GetDamageData() { return damage_data_; }

    ActorControlData*     GetUserControlData() { return user_control_data_; };
    ActorControlData*     GetRoutineControlData() { return routine_control_data_; };
    ActorControlData*     GetControlData() { return control_data_; }
    ActorLogicData*       GetLogicData() { return logic_data_; }
    ActorMotionData*      GetMotionData() { return motion_data_; }

    ActorSpecifiedData*   GetSpecifiedData();
    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter);
  private:
    Actor*                actor_; //should not often be accessed directly in data
    
    std::list<std::string> actor_log_;  //debug use

    //key reserved, limited to declared type enum only
    std::map<eActorAttributeType, ActorAttributeData> actor_attribute_map_;
    std::map<eActorStatusType, ActorStatusData> actor_status_map_;
    std::map<eActorPositionType, ActorPositionData> actor_position_map_;
    

    //Notice:
    // data in ActorData should avoid obtaining a direct pointer of Actor (Actor* actor_)
    // instead, a pointer of ActorData with actor back link is better
    ActorBasicData*       basic_data_;
    ActorSkillData*       skill_data_;
    ActorBuffData*        buff_data_; //store actor buff data
    ActorDamageData*      damage_data_;

    ActorControlData*     user_control_data_; //control data directly obtained by user operation(touch), processed by Control-Manual
    ActorControlData*     routine_control_data_;  //data for script based ActorControlRoutine
    ActorControlData*     control_data_;      //processed control data to be used in logic / motion, also a ActorControlData
    ActorLogicData*       logic_data_;        //logic input and output, (directly change this can affect logic in next Logic Update)
    ActorMotionData*      motion_data_;       //keep motion data(speed, target ...), mostly for animation

    ActorSpecifiedData*   specified_data_;    //different for each type of actor(mostly by Appearance), provide different function with the same name
  };



} // namespace actor


#endif // ACTOR_DATA_H