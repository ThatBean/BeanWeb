#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger.h"

namespace actor {
  //ActorData
  ActorData::ActorData(Actor* actor)
    :actor_(actor),
    specified_data_(NULL)
  {
    Init();
  }

  ActorData::~ActorData()
  {
    delete basic_data_;
    delete skill_data_;
    delete buff_data_;
    delete damage_data_;

    delete user_control_data_;
    delete routine_control_data_;
    delete control_data_;
    delete logic_data_;
    delete motion_data_;

    if (specified_data_) delete specified_data_;

    AddLog("[ActorData][~ActorData]");
    //ShowLog(-1);
    actor_log_.clear();
  }

  void ActorData::Init()
  {
    basic_data_ = new ActorBasicData(this);
    skill_data_ = new ActorSkillData(this);
    buff_data_ = new ActorBuffData(this);
    damage_data_ = new ActorDamageData(this); // TODO: use it

    user_control_data_ = new ActorControlData();
    routine_control_data_ = new ActorControlData();
    control_data_ = new ActorControlData();
    logic_data_ = new ActorLogicData(this);
    motion_data_ = new ActorMotionData(this);

    ResetData();

    AddLog("[ActorData][Init]");
  }

  void ActorData::ResetData()
  {
    //reset skill data
    skill_data_->Reset();

    //reset specified data
    if (specified_data_) delete specified_data_;

    basic_data_->SetCreateTime(clock());

    AddLog("[ActorData][ResetData]");
  }

  void ActorData::ConnectDataSignal()
  {
    basic_data_->ConnectDataSignal();
    skill_data_->ConnectDataSignal();
    buff_data_->ConnectDataSignal();
    motion_data_->ConnectDataSignal();
  }

  void ActorData::Update(float delta_time)
  {
    //for Debug quick watch
    Actor* debug_actor = actor_;
    ActorData* debug_actor_data = this;
    
    basic_data_->Update(delta_time);
    user_control_data_->Update(delta_time);
    routine_control_data_->Update(delta_time);
    control_data_->Update(delta_time);
    if (specified_data_) specified_data_->Update(delta_time);
  }



  void ActorData::AddLogF(const char* format, ...)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    char temp_text[1024];
    va_list ap;
    va_start(ap, format);
    vsnprintf(temp_text, 1024, format, ap);
    va_end(ap);
    AddLog(temp_text);
#endif
  }


  void ActorData::AddLog(const std::string &log)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    std::string log_string;
    char time_text[255];
    sprintf(time_text, "<ID:%d|%.3fs|%.3fs>\t", 
      actor_->GetActorId(), 
      double(clock() - basic_data_->GetCreateTime()) / CLOCKS_PER_SEC, 
      double(clock()) / CLOCKS_PER_SEC);
    log_string += time_text;
    log_string += log;
    log_string += "\n";
    actor_log_.push_front(log_string);
#endif
  }

  void ActorData::ShowLog(int max_line/* = 20*/)
  {
    CCLog("%s",GetLogText(max_line).c_str());
  }


  std::string ActorData::GetLogText(int max_line/* = 20*/)
  {
    std::string log_text = "";
    int line_count = 0;
    std::list<std::string>::iterator iterator = actor_log_.begin();
    while (iterator != actor_log_.end() && (max_line < 0 || line_count < max_line))
    {
      log_text += *iterator;
      line_count++;
      iterator++;
    }
    return log_text;
  }





  ActorSpecifiedData* ActorData::GetSpecifiedData()
  {
    if (specified_data_) 
      return specified_data_;

    switch (GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      specified_data_ = new ActorSpecifiedDataCharacter(actor_);
      break;
    case kActorAppearanceEnemyPawn:
      specified_data_ = new ActorSpecifiedDataEnemyPawn(actor_);
      break;
    case kActorAppearanceEnemyBoss:
      specified_data_ = new ActorSpecifiedDataEnemyBoss(actor_);
      break;
    default:
      assert(false);
      specified_data_ = NULL;
      break;
    }

    return specified_data_;
  }


  void ActorData::SetActorAdapter(ActorAdapter* actor_adapter)
  {
    basic_data_->SetActorAdapter(actor_adapter);
    skill_data_->SetActorAdapter(actor_adapter);
    buff_data_->SetActorAdapter(actor_adapter);

    ConnectDataSignal();
  }

  //ActorData

} // namespace actor