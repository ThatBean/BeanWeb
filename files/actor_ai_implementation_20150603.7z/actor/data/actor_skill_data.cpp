#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {
  ActorSkillData::ActorSkillData(ActorData* actor_data)
    :actor_data_(actor_data),
    attack_trigger_(NULL),
    guard_trigger_(NULL),
    guard_trigger_auto_(NULL)
  {
    Reset();
  }

  ActorSkillData::~ActorSkillData()
  {
    Reset();
  }

  void ActorSkillData::Reset()
  {
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackCount)->Reset();
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackNormalCount)->Reset();
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackPowerCount)->Reset();
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackSpecialCount)->Reset();


    skill_info_map_.clear();
    skill_cycle_list_.clear();


    if (attack_trigger_) delete attack_trigger_;
    if (guard_trigger_) delete guard_trigger_;
    if (guard_trigger_auto_) delete guard_trigger_auto_;

    attack_trigger_ = NULL;
    guard_trigger_ = NULL;
    guard_trigger_auto_ = NULL;
  }




  //link OnDataOperation to selected signal
  void ActorSkillData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorStatusData(kActorSkillStatusIsPaused)->Connect<ActorSkillData>(this, &ActorSkillData::OnStatusDataOperation);
  }

  //callback for data operation signal
  void ActorSkillData::OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassAttribute, actor_data_type, actor_data);
  }
  void ActorSkillData::OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassStatus, actor_data_type, actor_data);
  }
  void ActorSkillData::OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassPosition, actor_data_type, actor_data);
  }
  void ActorSkillData::OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data)
  {
    switch (actor_data_type)
    {
    case kActorSkillStatusIsPaused:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            bool is_pause = actor_data_->GetActorStatusBool(kActorSkillStatusIsPaused);

            if (is_pause)
              PauseSkillAdapter(actor_adapter_);
            else
              ResumeSkillAdapter(actor_adapter_);
          }
          break;
        }
      }
      break;
    }
  }











  bool ActorSkillData::IsSkillValid(int skill_id)
  {
    bool is_attack_valid = true;
    eActorAttackType attack_type = GetSkillTypeById(skill_id);

    switch(attack_type)
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
      is_attack_valid = actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackNormal);
      break;
    case kActorAttackPower:
      is_attack_valid = actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackPower);
      break;
    case kActorAttackSpecial:
    case kActorAttackOverload:
      is_attack_valid = actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackSpecial);
      break;
    case kActorAttack:
    default:
      assert(false);
      is_attack_valid = false;
      break;
    }

    //cool down check - this only used to add cool down time between skill, default = 0
    is_attack_valid = is_attack_valid && (GetSkillCooldownByType(attack_type) <= actor_data_->GetControlData()->GetSkillCountdown());

    return is_attack_valid;
  }



  bool ActorSkillData::CheckAttackTrigger()
  {
    if (!attack_trigger_)
      return false;

    ActorControlData* control_data = actor_data_->GetControlData();

    if (control_data->IsSetPosition() && control_data->GetPositionPriority() > kActorControlPriorityCheckAttackAuto) 
      return false;//user set position, ignore all target

    attack_trigger_->Update();//update trigger
    if (attack_trigger_->GetIsTriggered() == false) 
      return false;//no target

    //decide target
    Actor* target_actor = NULL;
    std::list<Actor*>* triggered_actor_list = attack_trigger_->GetTriggeredActorList();
    if (control_data->IsSetTarget() && control_data->GetTargetPriority() > kActorControlPriorityCheckAttackAuto) 
    {
      int target_actor_id = control_data->GetTarget(); //user set target

      std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
      while (iterator != triggered_actor_list->end())
      {
        Actor* triggered_actor = *iterator;
        if (target_actor_id == triggered_actor->GetActorId()) 
        {
          target_actor = triggered_actor;
          control_data->ResetTarget(); // found the target, clear control priority for attack
        }
        iterator ++;
      }
    }
    else
    {
      target_actor = *(triggered_actor_list->begin());
    }

    //set to control data
    if (target_actor)
    {
      if (actor_data_->GetActorStatus(kActorSkillStatusAttackPowerSkillId) != ACTOR_SKILL_ID_INVALID
        && (int)actor_data_->GetActorAttribute(kActorSkillAttributeAttackCount) % 4 == 3 
        && actor_data_->GetActorStatus(kActorLogicStatusCanAttackPower) )
      {
        //Upgrade to power skill
        actor_data_->AddLogF("[ActorSkillData][CheckAttackTrigger] Upgrade Attack! count:%d", (int)actor_data_->GetActorAttribute(kActorSkillAttributeAttackCount));
        control_data->SetSkill(actor_data_->GetActorStatus(kActorSkillStatusAttackPowerSkillId), kActorControlPriorityAttackPowerAuto);
      }
      else
      {
        //normal attack
        control_data->SetSkill(actor_data_->GetActorStatus(kActorSkillStatusAttackNormalSkillId), kActorControlPriorityAttackNormalAuto);
      }

      control_data->SetTarget(target_actor->GetActorId(), kActorControlPriorityMoveAuto); //if can't attack, just Move

      if (IsSkillValid(control_data->GetSkill()) == false)
      {
        //clear control data
        control_data->ResetSkill(); //Invalid Attack(Buff caused)
        control_data->Reset(); //Invalid Attack(Buff caused)
        actor_data_->AddLog("[ActorSkillData][CheckAttackTrigger] Invalid Attack");
        return false;
      }
      else
      {
        // TODO: remove | currently set critical
        ClearCriticalHit();
        RandomCriticalHit(target_actor);
        return true;
      }
    }
    else
    {
      return false;
    }
  }


  bool ActorSkillData::CheckGuardTrigger()
  {
    if (!guard_trigger_) 
      return false;
    if (actor_data_->GetControlData()->GetMaximumControlPriority() > kActorControlPriorityCheckGuardAuto) 
      return false; //has other target set

    guard_trigger_->Update();

    if (guard_trigger_->GetIsTriggered() && actor_data_->GetActorStatusBool(kActorLogicStatusCanAttackNormal))
    {
      int target_id = *(guard_trigger_->GetTriggeredActorIdList()->begin());
      actor_data_->GetControlData()->SetTarget(target_id, kActorControlPriorityMoveAuto);
      return true;
    }

    return false;
  }




  void ActorSkillData::AddSkillInfo(int skill_id, int skill_level, eActorAttackType skill_type)
  {
    if (skill_info_map_.find(skill_id) != skill_info_map_.end())
    {
      printf("[ActorSkillData][AddSkillInfo] Already has this skill in map! id:%d\n", skill_id);
      assert(false);
      return;
    }

    skill_info_map_[skill_id].skill_id = skill_id;
    skill_info_map_[skill_id].skill_level = skill_level;
    skill_info_map_[skill_id].skill_type = skill_type;
  }

  ActorSkillInfo* ActorSkillData::GetSkillInfoById(int skill_id)
  {
    if (skill_info_map_.find(skill_id) == skill_info_map_.end())
    {
      printf("[ActorSkillData][GetSkillInfoById] No skill in map! id:%d\n", skill_id);
      assert(false);
      return NULL;
    }

    return &(skill_info_map_[skill_id]);
  }

  eActorAttackType ActorSkillData::GetSkillTypeById(int skill_id)
  {
    //not allowed
    if (skill_id == ACTOR_SKILL_ID_INVALID) 
      return kActorAttack;

    //check map
    if (skill_info_map_.find(skill_id) == skill_info_map_.end())
      return kActorAttackOverload;
    else
      return skill_info_map_[skill_id].skill_type;
  }


  int ActorSkillData::NextSkillFromSkillCycleList()
  {
    if (skill_cycle_list_.size() == 0)
    {
      printf("[ActorSkillData][NextSkillFromSkillCycleList] No skill at all in list!\n");
      assert(false);
      return ACTOR_SKILL_ID_INVALID;
    }

    int skill_id = *(skill_cycle_list_.begin());

    //cycle
    skill_cycle_list_.pop_front();
    skill_cycle_list_.push_back(skill_id);

    return skill_id;
  }




  void ActorSkillData::CommitSkill(int skill_id, int target_actor_id)
  {
    actor_data_->GetActorAttributeData(kActorSkillAttributeAttackCount)->Add(1);

    if (skill_id <= 0) return;
     
    eActorAttackType attack_type = GetSkillTypeById(skill_id);
    switch (attack_type)
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
      actor_data_->GetActorAttributeData(kActorSkillAttributeAttackNormalCount)->Add(1);
      break;
    case kActorAttackPower:
      actor_data_->GetActorAttributeData(kActorSkillAttributeAttackPowerCount)->Add(1);
      break;
    case kActorAttackSpecial:
    case kActorAttackOverload:
      actor_data_->GetActorAttributeData(kActorSkillAttributeAttackSpecialCount)->Add(1);
      actor_data_->SetActorAttribute(kActorAttributeEnergyCurrent, 0);
      if (actor_data_->GetActorStatusBool(kActorSkillStatusIsBusy) == true) 
      {
        actor_data_->AddLogF("[ActorSkillData][CommitSkill] Reset Previous Skill. Current skill_id:%d type:%d count:%d", skill_id, attack_type, (int)actor_data_->GetActorAttribute(kActorSkillAttributeAttackCount));
        ResetSkillAdapter(actor_adapter_);
      }
      break;
    default:
      assert(false);
      break;
    }

    actor_data_->AddLogF("[ActorSkillData][CommitSkill] Attack! Current skill_id:%d type:%d count:%d", skill_id, attack_type, (int)actor_data_->GetActorAttribute(kActorSkillAttributeAttackCount));
    CommitSkillAdapter(actor_adapter_, skill_id, attack_type, target_actor_id);
  }

  bool ActorSkillData::GetIsSpecialSkillReady()
  {
    return actor_data_->GetActorAttribute(kActorAttributeEnergyCurrent) >= actor_data_->GetActorAttribute(kActorAttributeEnergyMax);
  }

  float ActorSkillData::GetSkillCooldownByType(eActorAttackType attack_type)
  {
    switch (attack_type)
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
    case kActorAttackPower:
      return actor_data_->GetActorAttribute(kActorAttributeSpeedAttack);
    default:
      return 0;
    }
  }


  void ActorSkillData::RandomCriticalHit(Actor* target_actor)
  {
    actor::RandomCriticalHit(actor_adapter_, target_actor);
  }

  void ActorSkillData::ClearCriticalHit()
  {
    actor::ClearCriticalHit(actor_adapter_);
  }


  //ActorSkillData

} // namespace actor