#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  bool ActorSpecifiedData::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionInGrid(position);
  }

  bool ActorSpecifiedData::IsGridValid(cocos2d::CCPoint grid_position)
  {
    return grid_position.x >= GRID_X_RANGE_LEFT
      && grid_position.x <= GRID_X_RANGE_RIGHT
      && grid_position.y >= GRID_Y_RANGE_TOP
      && grid_position.y <= GRID_Y_RANGE_BOTTOM;
  }


  cocos2d::CCPoint ActorSpecifiedData::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
      return SnapToGrid(position);
    else
      return SnapYToGrid(position);
  }

  bool ActorSpecifiedData::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);  //for enemy pawn / boss
  }


  std::list<cocos2d::CCPoint>* ActorSpecifiedData::GetValidGridList(std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list)  //need delete after use
  {
    //record grid taken status
    int grid_position_taken[GRID_X_RANGE][GRID_Y_RANGE] = {0};
    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list->begin();
    while (iterator != actor_grid_list->end())
    {
      Actor* ref_actor = iterator->first;

      if (ref_actor != actor_ && ref_actor->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection))
      {
        cocos2d::CCPoint ref_grid_position = iterator->second;
        grid_position_taken[(int)(ref_grid_position.x - 1)][(int)(ref_grid_position.y - 1)] += 1;
      }

      ++iterator;
    }

    //search and check valid grid
    std::list<cocos2d::CCPoint>* valid_grid_list = new std::list<cocos2d::CCPoint>;
    int i, j;
    for (i = GRID_X_RANGE_LEFT; i <= GRID_X_RANGE_RIGHT; i++) {
      for (j = GRID_Y_RANGE_TOP; j <= GRID_Y_RANGE_BOTTOM; j++) {
        cocos2d::CCPoint grid_position = ccp(i, j);
        if (grid_position_taken[i - 1][j - 1] == 0 && IsGridIdleValid(grid_position)) valid_grid_list->push_back(grid_position);
      }
    }

    return valid_grid_list;
  }

  cocos2d::CCPoint ActorSpecifiedData::GetValidGrid(
    cocos2d::CCPoint preferred_grid_position, 
    std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list, 
    eActorSpecifiedGridPreferenceType prefer_type)
  {
    if (IsGridIdleValid(preferred_grid_position) == false)
    {
      float preferred_grid_x = actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT_MIDDLE : GRID_X_RANGE_RIGHT_MIDDLE;
      preferred_grid_position = ccp(preferred_grid_x, GRID_Y_RANGE_MIDDLE);
    }

    std::list<cocos2d::CCPoint>* valid_grid_list = GetValidGridList(actor_grid_list);
    
    bool is_backup_grid_position_valid = false;
    cocos2d::CCPoint backup_grid_position;
    float nearest_valid_grid_distance = 99999;

    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;

        if (IsGridIdleValid(grid_position))
        {
          float distance = preferred_grid_position.getDistance(grid_position);

          if (distance == 0)
          {
            backup_grid_position = preferred_grid_position;
            is_backup_grid_position_valid = true;
            break;  //stop searching
          }

          bool is_keep = false;

          switch (prefer_type)
          {
          case kActorSpecifiedGridPreferNear:
            is_keep = nearest_valid_grid_distance > distance;
            break;
          case kActorSpecifiedGridPreferNearX:
            if (abs(backup_grid_position.x - preferred_grid_position.x) < abs(grid_position.x - preferred_grid_position.x))
            {
              if (abs(backup_grid_position.x - preferred_grid_position.x) == abs(grid_position.x - preferred_grid_position.x))
                is_keep = nearest_valid_grid_distance > distance;
              else
                is_keep = true;
            }
            break;
          case kActorSpecifiedGridPreferNearY:
            if (abs(backup_grid_position.y - preferred_grid_position.y) < abs(grid_position.y - preferred_grid_position.y))
            {
              if (abs(backup_grid_position.y - preferred_grid_position.y) == abs(grid_position.y - preferred_grid_position.y))
                is_keep = nearest_valid_grid_distance > distance;
              else
                is_keep = true;
            }
            break;
          }

          if (is_keep)
          {
            nearest_valid_grid_distance = distance;
            backup_grid_position = grid_position;
          }
          is_backup_grid_position_valid = true;
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    if (is_backup_grid_position_valid)
    {
      actor_grid_list->push_back(std::pair<Actor*, cocos2d::CCPoint>(actor_, backup_grid_position));  //prevent another actor move to 
      return backup_grid_position;
    }
    else
    {
      //so sad the lame makeshift position
      return ccp(actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT_MIDDLE : GRID_X_RANGE_RIGHT_MIDDLE, GRID_Y_RANGE_MIDDLE);
    }
  }

  //ActorSpecifiedDataCharacter================================================================
  ActorSpecifiedDataCharacter::ActorSpecifiedDataCharacter(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataCharacter::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
    {
      cocos2d::CCPoint grid_position = GetGridFromPosition(position);
      if (actor_->GetActorData()->GetActorStatusBool(kActorSpecifiedStatusIsLimitGridX) && ((int)(grid_position.x) == 1))
        return (position.x > (GetPositionFromGrid(grid_position).x + 10));
      else
        return true;
    }
    else
      return false;
  }

  bool ActorSpecifiedDataCharacter::IsGridValid(cocos2d::CCPoint grid_position)
  {
    bool is_valid = ActorSpecifiedData::IsGridValid(grid_position);
    
    if (is_valid && actor_->GetActorData()->GetActorStatusBool(kActorSpecifiedStatusIsLimitGridX))
    {
      switch (actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection))
      {
      case kActorAnimationDirectionLeft:
        is_valid = grid_position.x <= PLAYER_IDLE_VALID_GRID_X_RANGE_LEFT;
        break;
      case  kActorAnimationDirectionRight:
        is_valid = grid_position.x >= PLAYER_IDLE_VALID_GRID_X_RANGE_RIGHT;
        break;
      default:
        assert(false);
        is_valid = true;
        break;
      }
    }

    return is_valid;
  }

  bool ActorSpecifiedDataCharacter::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    return IsGridValid(grid_position);  //not different from Valid
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
    {
      if (IsPositionValid(position))
        return SnapToGrid(position);
      else
      {
        cocos2d::CCPoint grid_position = GetGridFromPosition(position);

        if (actor_->GetActorData()->GetActorStatusBool(kActorSpecifiedStatusIsLimitGridX) && ((int)(grid_position.x) == 1))
          grid_position.x = 2;  // TODO: strange logic
        
        return GetPositionFromGrid(grid_position);
      }
    }
    else
      return SnapYToGrid(position);
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::GetValidGrid()
  {
    if (IsGridIdleValid(actor_->GetActorData()->GetActorPosition(kActorSpecifiedPositionLastIdleGrid)) == false)
    {
      actor_->GetActorData()->SetActorPosition(kActorSpecifiedPositionLastIdleGrid, ccp(actor_->GetActorData()->GetActorStatus(kActorSpecifiedStatusHomeDirection) == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT_MIDDLE : GRID_X_RANGE_RIGHT_MIDDLE, GRID_Y_RANGE_MIDDLE));
    }

    return ActorSpecifiedData::GetValidGrid(
      actor_->GetActorData()->GetActorPosition(kActorSpecifiedPositionLastIdleGrid), 
      actor_->GetActorExtEnv()->GetActorExtGrid()->GetActorGridList(), 
      kActorSpecifiedGridPreferNear);
  }

  //ActorSpecifiedDataCharacter================================================================

  //ActorSpecifiedDataEnemyPawn================================================================
  ActorSpecifiedDataEnemyPawn::ActorSpecifiedDataEnemyPawn(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyPawn::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionYInGrid(position);
  }
  //ActorSpecifiedDataEnemyPawn================================================================

  //ActorSpecifiedDataEnemyBoss================================================================
  ActorSpecifiedDataEnemyBoss::ActorSpecifiedDataEnemyBoss(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyBoss::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionYInGrid(position);
  }
  //ActorSpecifiedDataEnemyBoss================================================================
} // namespace actor