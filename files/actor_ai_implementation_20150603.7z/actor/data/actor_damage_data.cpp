#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  DamagePackage::DamagePackage()
  {
    InitDamage();
  }
  DamagePackage::~DamagePackage()
  {
    //
  }


  //basic method
  void DamagePackage::InitDamage()
  {
    source_actor_id_ = ACTOR_ID_INVALID;
    source_skill_id_ = ACTOR_SKILL_ID_INVALID;
    source_buff_id_list_.clear();

    damage_data_map_.clear();

    is_normal_attack_ = false;
    is_critical_hit_ = false;
    is_missed_hit_ = false;
    is_special_attack_ = false;
  }

  void DamagePackage::AddDamage(
    eActorDamageType   damage_type,
    float   damage_add/* = 0*/,
    float   damage_multiplier/* = 1*/,
    float   damage_extra/* = 0*/
    )
  {
    if (damage_type == kActorDamageInvalid 
      && damage_type == kActorDamage)
    {
      assert(false);
      return;
    }

    damage_data_map_[damage_type].Set(damage_add, damage_multiplier, damage_extra);
  }

  float DamagePackage::GetDamage(Actor* actor)
  {
    float result_damage = 0;

    std::map<eActorDamageType, ActorAttributeData>::iterator iterator = damage_data_map_.begin();
    while (iterator != damage_data_map_.end())
    {
      result_damage += iterator->second.Get();
      ++iterator;
    }

    return result_damage;
  }


  //will happen on skill releaser
  void DamagePackage::AddActorBasicDamage(Actor* actor)
  {

  }
  void DamagePackage::AddActorSkillDamage(Actor* actor)
  {

  }
  void DamagePackage::AddActorBuffDamage(Actor* actor)
  {

  }


  //will happen on damage holder
  void DamagePackage::ReduceActorBuffDamage(Actor* actor)
  {

  }
  void DamagePackage::ReduceActorBasicDamage(Actor* actor)
  {

  }





  ActorDamageData::ActorDamageData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }
  ActorDamageData::~ActorDamageData()
  {

  }

  //ActorDamageData

} // namespace actor