#ifndef ACTOR_CONTROL_DATA_H
#define ACTOR_CONTROL_DATA_H

#include "actor_data_typedef.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorTrigger;


  //there will be 2 ActorControlData:
  //   user_control_data_ will buffer user control
  //   ActorControl will apply user_control_data_ change to control_data_
  //   control_data_ will be used in Logic update

  //#########################################################################################################
  //#########################################################################################################
  class ActorControlData
  {
  public:
    ActorControlData();
    ~ActorControlData();
    
    virtual void    Reset();
    virtual bool    IsSet();
    virtual void    Update(float delta_time);

    eActorControlPriority GetMaximumControlPriority();

    void              SetPosition(const cocos2d::CCPoint& position, eActorControlPriority control_priority = kActorControlPriorityMoveAuto);
    cocos2d::CCPoint  GetPosition();
    eActorControlPriority GetPositionPriority() { return control_priority_position_; }
    bool              IsSetPosition() { return is_set_position_; }
    void              ResetPosition();
    
    void              SetTarget(int target_id, eActorControlPriority control_priority = kActorControlPriorityMoveAuto);
    int               GetTarget();
    eActorControlPriority GetTargetPriority() { return control_priority_target_; }
    bool              IsSetTarget() { return is_set_target_; }
    void              ResetTarget();

    void              SetSkill(int skill_id, eActorControlPriority control_priority = kActorControlPriorityAttackNormalAuto);
    int               GetSkill();
    eActorControlPriority GetSkillPriority() { return control_priority_skill_; }
    bool              IsSetSkill() { return is_set_skill_; }
    void              ResetSkill();

    void              SetIncontrollable(eActorControlIncontrollableType incontrollable_type, eActorControlPriority control_priority = kActorControlPriorityIncontrollable);
    eActorControlIncontrollableType GetIncontrollable();
    eActorControlPriority GetIncontrollablePriority() { return control_priority_incontrollable_; }
    bool              IsSetIncontrollable() { return is_set_incontrollable_; }
    void              ResetIncontrollable();

    void              SetCountdown(float countdown) { countdown_ = countdown; }
    float             GetCountdown() { return countdown_; }
    void              UpdateCountdown(float delta_time) { countdown_ = (countdown_ <= delta_time ? 0 : countdown_ - delta_time); }
    void              ResetCountdown(float delta_time = ACTOR_CONTROL_COUNTDOWN) { countdown_ = delta_time; }
    
    void              ResetCountdownGuard() { countdown_ = ACTOR_CONTROL_COUNTDOWN_GUARD; }
    void              ResetCountdownAttack() { countdown_ = ACTOR_CONTROL_COUNTDOWN_ATTACK; }
    void              ResetCountdownDead() { countdown_ = ACTOR_CONTROL_COUNTDOWN_DEAD; }

    float             GetSkillCountdown() { return skill_countdown_; }
    void              UpdateSkillCountdown(float delta_time) { skill_countdown_ += delta_time; }
    void              ResetSkillCountdown() { skill_countdown_ = 0; }

  private:
    cocos2d::CCPoint  position_;
    int               target_id_;
    int               skill_id_;
    eActorControlIncontrollableType incontrollable_type_;

    bool              is_set_position_;
    bool              is_set_target_;
    bool              is_set_skill_;
    bool              is_set_incontrollable_;

    eActorControlPriority control_priority_position_;
    eActorControlPriority control_priority_target_;
    eActorControlPriority control_priority_skill_;
    eActorControlPriority control_priority_incontrollable_;
    
    float             countdown_;
    float             skill_countdown_;
  };
} // namespace actor


#endif // ACTOR_CONTROL_DATA_H