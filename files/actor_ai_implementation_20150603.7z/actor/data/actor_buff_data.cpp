#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/battle/damage/damage_constants.h"

namespace actor {

  const unsigned long ACTOR_BUFF_FLAG_MOVE_AUTO = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_MOVE_LOCK = 0
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | taomee::battle::kDamageIntertwine
    | 0;



  const unsigned long ACTOR_BUFF_FLAG_ATTACK_LOCK = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | taomee::battle::kDamageIntertwine
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_NORMAL_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageBlinded
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_POWER_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageBlinded
	| taomee::battle::kDamageSilence
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_SPECIAL_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageSilence
    | 0;


  const unsigned long ACTOR_BUFF_FLAG_ANIMATION_LOCK = 0
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_COLORED = 0
    | taomee::battle::kDamageFireProperty
    | taomee::battle::kDamageFireProperty
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_INCONTROLLABLE = 0
    | ACTOR_BUFF_FLAG_MOVE_AUTO 
    | ACTOR_BUFF_FLAG_MOVE_LOCK
    | 0;



  ActorBuffData::ActorBuffData(ActorData* actor_data)
    :actor_data_(actor_data)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }



  //link OnDataOperation to selected signal
  void ActorBuffData::ConnectDataSignal()
  {
    //add data signal
    actor_data_->GetActorStatusData(kActorBuffStatusIsPauseAnimation)->Connect<ActorBuffData>(this, &ActorBuffData::OnStatusDataOperation);
  }

  //callback for data operation signal
  void ActorBuffData::OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassAttribute, actor_data_type, actor_data);
  }
  void ActorBuffData::OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassStatus, actor_data_type, actor_data);
  }
  void ActorBuffData::OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data)
  {
    OnDataOperation(operation_type, kActorDataClassPosition, actor_data_type, actor_data);
  }
  void ActorBuffData::OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data)
  {
    switch (actor_data_type)
    {
    case kActorBuffStatusIsPauseAnimation:
      {
        switch (operation_type)
        {
        case kActorDataOperationReset:
        case kActorDataOperationSet:
          {
            bool is_pause = actor_data_->GetActorStatusBool(kActorBuffStatusIsPauseAnimation);

            actor_data_->GetActorStatusData(kActorAnimationStatusIsPaused)->Stack(is_pause);
          }
          break;
        }
      }
      break;
    }
  }












  void ActorBuffData::UpdateIncontrollable()
  {
    uint_32 buff_flag = actor_adapter_->battle_status_flag();

    actor_data_->SetActorStatusBool(kActorLogicStatusIsIncontrollable, ((buff_flag & ACTOR_BUFF_FLAG_INCONTROLLABLE) != 0));

    actor_data_->SetActorStatusBool(kActorLogicStatusCanMove, ((buff_flag & ACTOR_BUFF_FLAG_MOVE_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttack, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttackNormal, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_NORMAL_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttackPower, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_POWER_LOCK) == 0));
    actor_data_->SetActorStatusBool(kActorLogicStatusCanAttackSpecial, ((buff_flag & ACTOR_BUFF_FLAG_ATTACK_SPECIAL_LOCK) == 0));

    actor_data_->SetActorStatusBool(kActorBuffStatusIsPauseAnimation, ((buff_flag & ACTOR_BUFF_FLAG_ANIMATION_LOCK) != 0));
    actor_data_->SetActorStatusBool(kActorBuffStatusIsChangeColor, ((buff_flag & ACTOR_BUFF_FLAG_COLORED) != 0));
    //actor_data_->SetActorStatusBool(kActorBuffStatusForceMoveAuto, ((buff_flag & ACTOR_BUFF_FLAG_MOVE_AUTO) == 0));  // TODO:

  }



  //currently in adapter

} // namespace actor