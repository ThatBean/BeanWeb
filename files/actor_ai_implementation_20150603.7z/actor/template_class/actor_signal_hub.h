#ifndef ACTOR_SIGNAL_HUB_H
#define ACTOR_SIGNAL_HUB_H

#include <boost/bind.hpp>
#include <boost/signal.hpp>

namespace actor {

  typedef boost::signals::connection ActorSignalConnection;


  template <class t_data>
  class ActorSignalHub {
  public:
    ActorSignalHub() 
      :signal_hub_(NULL),
      linked_type_(-1),
      linked_data_(NULL)
    {

    }
    ~ActorSignalHub() {
      if (signal_hub_) delete signal_hub_;
    }

  public:
    //typedef boost::signal<void (int, eActorDataOperationType, t_data*)> tActorDataSignal;
    //typedef boost::signals::connection tActorDataConnection;

    template <typename T>
    ActorSignalConnection Connect(T* pt, void (T::*method)(int, int, t_data*)) 
    {
      if (!signal_hub_) signal_hub_ = new boost::signal<void (int, int, t_data*)>;
      return signal_hub_->connect(boost::bind(method, pt, _1, _2, _3));
    }

    void Disconnect(ActorSignalConnection connection) 
    {
      connection.disconnect();
    }

    void Emit(int signal_type, int linked_type, t_data* linked_data) 
    {
      if (signal_hub_) (*signal_hub_)(signal_type, linked_type, linked_data);
    }

    //for ActorData to link
    void Link(int actor_data_type, t_data* actor_data) 
    {
      linked_type_ = actor_data_type;
      linked_data_ = actor_data;
    }
    void Emit(int signal_type) 
    {
      if (signal_hub_) Emit(signal_type, linked_type_, linked_data_);
    }

  private:
    boost::signal<void (int, int, t_data*)>* signal_hub_;  //for data change signal, will be created after first connect

    int linked_type_;
    t_data* linked_data_;
  };

} // namespace actor


#endif // ACTOR_SIGNAL_HUB_H
