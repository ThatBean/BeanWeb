#include "actor_motion_state_idle.h"

#include "game/actor/actor.h"

namespace actor {

  const int MotionStateIdle::STATE_TYPE = kActorMotionStateIdle;

  MotionStateIdle* MotionStateIdle::Instance()
  {
    static MotionStateIdle instance;
    return &instance;
  }


  void MotionStateIdle::OnEnter(Actor* actor)
  {
    actor->GetAnimation()->ChangeSkeletonAnimation(taomee::army::kUnitAnimationIdle);
    CheckWeakStatus(actor);
  }

  void MotionStateIdle::OnExit(Actor* actor)
  {

  }

  void MotionStateIdle::Update(Actor* actor, float delta_time)
  {
    CheckWeakStatus(actor);
  }

  void MotionStateIdle::CheckWeakStatus(Actor* actor)
  {
    bool is_weak_status = actor->GetActorData()->GetBasicData()->GetIsWeakStatus();
    if (is_weak_status != actor->GetActorData()->GetActorStatusBool(kActorAnimationStatusIsWeakAnimation))
    {
      actor->GetActorData()->SetActorStatusBool(kActorAnimationStatusIsWeakAnimation, is_weak_status);
    }
  }

} // namespace actor