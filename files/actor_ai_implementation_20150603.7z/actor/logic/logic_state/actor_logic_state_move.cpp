#include "actor_logic_state_move.h"

#include "game/actor/actor.h"
#include "game/actor/motion/actor_motion_state_machine.h"

namespace actor {

  const int LogicStateMove::STATE_TYPE = kActorLogicStateMove;

  LogicStateMove* LogicStateMove::Instance()
  {
    static LogicStateMove instance;
    return &instance;
  }


  void LogicStateMove::OnEnter(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateMove][OnEnter]");

    //position correction(always move to the center of tile)
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    if (control_data->IsSetPosition())
    {
      ActorSpecifiedData* specified_Data = actor->GetActorData()->GetSpecifiedData();

      if (specified_Data->IsPositionValid(control_data->GetPosition())) //check position
      {
        control_data->SetPosition(specified_Data->PositionCorrection(control_data->GetPosition()), control_data->GetPositionPriority());
      }
      else
      {
        actor->GetActorData()->AddLogF("[LogicStateMove][OnEnter] Position not Valid (%f, %f)", control_data->GetPosition().x, control_data->GetPosition().y);
        control_data->ResetPosition();
      }
    }

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateMove));
  }

  void LogicStateMove::OnExit(Actor* actor)
  {
    //clear control data
    actor->GetActorData()->GetControlData()->ResetPosition();
    //actor->GetActorData()->GetControlData()->ResetTarget(); //keep for Attack

    actor->GetActorData()->AddLog("[LogicStateMove][OnExit]");
  }

  void LogicStateMove::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->AddLog("[LogicStateMove][Update]");
    //Position
    //Target
    
    //Finished State Logic?
    if (actor->GetActorData()->GetActorStatusBool(kActorMotionStatusIsBusy) == false)
    {
      actor->GetActorData()->GetControlData()->ResetPosition();
      //back to idle
      //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
    }

    //check trigger
    if (/*actor->GetActorData()->GetControlData()->IsSet() == false 
        && */actor->GetActorData()->GetControlData()->GetCountdown() == 0
        && IsPositionInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation))) //logic only run when actor entered grid
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdownAttack();

      //check attack
      if (actor->GetActorData()->GetSkillData()->CheckAttackTrigger())
      {
        //goto Attack, commit attack
        //actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
        return;
      }
    }
  }

} // namespace actor