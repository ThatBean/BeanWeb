#ifndef ACTOR_LOGIC_STATE_IDLE_H
#define ACTOR_LOGIC_STATE_IDLE_H

#include "game/actor/logic/actor_logic_state.h"


namespace actor {

  class LogicStateIdle : public LogicState
  {
  public:
    virtual ~LogicStateIdle() {}
    static LogicStateIdle* Instance();
    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }

    virtual void OnEnter(Actor* actor);
    virtual void OnExit(Actor* actor);
    virtual void Update(Actor* actor, float delta_time);

  private:
    LogicStateIdle() {}
  };

} // namespace actor


#endif // ACTOR_LOGIC_STATE_IDLE_H
