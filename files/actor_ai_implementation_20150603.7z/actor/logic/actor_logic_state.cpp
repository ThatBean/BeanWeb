#include "actor_logic_state.h"

#include "logic_state/actor_logic_state_idle.h"
#include "logic_state/actor_logic_state_move.h"
#include "logic_state/actor_logic_state_attack.h"
#include "logic_state/actor_logic_state_incontrollable.h"
#include "logic_state/actor_logic_state_born.h"
#include "logic_state/actor_logic_state_dead.h"

#include "game/actor/actor.h"

namespace actor {
  const int LogicState::STATE_TYPE = kActorLogicState;

  LogicState* GetActorLogicState(eActorLogicState state_type)
  {
    switch(state_type)
    {
    case kActorLogicStateIdle:
      return LogicStateIdle::Instance();
      break;
    case kActorLogicStateMove:
      return LogicStateMove::Instance();
      break;
    case kActorLogicStateAttack:
      return LogicStateAttack::Instance();
      break;
    case kActorLogicStateIncontrollable:
      return LogicStateIncontrollable::Instance();
      break;
    case kActorLogicStateBorn:
      return LogicStateBorn::Instance();
      break;
    case kActorLogicStateDead:
      return LogicStateDead::Instance();
      break;
    case kActorLogicStateInvalid:
    default:
      return NULL;
      break;
    }
  }


  //{CONDITIONALLY}
  bool CommonCheckGridPosition(Actor* actor)
  {
    if (IsPositionInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)) == true
      && actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)
    {
      //if the actor is a character, run some nasty check
      ActorSpecifiedDataCharacter* specified_data = dynamic_cast<ActorSpecifiedDataCharacter*>(actor->GetActorData()->GetSpecifiedData());
      cocos2d::CCPoint grid_position = GetGridFromPosition(actor->GetActorData()->GetActorPosition(kActorPositionAnimation));

      bool is_move_needed = false;

      //check overlap
      if (actor->GetActorExtEnv()->GetActorExtGrid()->CheckActorGridOverlap(actor) 
        || specified_data->IsGridIdleValid(grid_position) == false)
      {
        //move away from grid
        grid_position = specified_data->GetValidGrid();
        is_move_needed = true;
      }

      //check snap to grid
      if (GetPositionFromGrid(grid_position).getDistance(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)) > 2.0f)
      {
        is_move_needed = true;
      }

      if (is_move_needed)
      {
        actor->GetActorData()->GetControlData()->SetPosition(GetPositionFromGrid(grid_position), kActorControlPriorityMoveManual);
        return true;
      }
    }
    return false;
  }
} // namespace actor