#ifndef ACTOR_LOGIC_STATE_H
#define ACTOR_LOGIC_STATE_H

#include "game/actor/template_class/state.h"
#include "cocos2d.h"

namespace actor {

  class Actor;

  enum eActorLogicState
  {
    kActorLogicStateInvalid = -1,
    kActorLogicStateIdle,
    kActorLogicStateMove,
    kActorLogicStateAttack,
    kActorLogicStateIncontrollable,
    kActorLogicStateBorn,
    kActorLogicStateDead,
    kActorLogicState
  };


  class LogicState : public State<Actor>
  {
  public:
    virtual ~LogicState() {}

    static const int     STATE_TYPE;
    virtual int          GetStateType() { return STATE_TYPE; }
  };

  LogicState* GetActorLogicState(eActorLogicState state_type);

  //{CONDITIONALLY} 
  //Update Attack/GuardTrigger
  bool CommonCheckGridPosition(Actor* actor);  //check Overlap and off grid center
} // namespace actor


#endif // ACTOR_LOGIC_STATE_H
