#ifndef ACTOR_TRIGGER_PREDEFINED_H
#define ACTOR_TRIGGER_PREDEFINED_H

#include "actor_trigger.h"
#include "actor_trigger_module.h"

namespace actor {

  class Actor;

  enum eActorPredefinedGuardTriggerType
  {
    kActorPredefinedGuardTriggerMeleeCircle,
    kActorPredefinedGuardTriggerRangedRect,
    kActorPredefinedGuardTriggerMeleeRect,
    kActorPredefinedGuardTrigger
  };

  enum eActorPredefinedAttackTriggerType
  {
    kActorPredefinedAttackTriggerMeleeCircle,
    kActorPredefinedAttackTriggerRangedRect,
    kActorPredefinedAttackTriggerHeal,
    kActorPredefinedAttackTriggerMeleeRect,
    //kActorPredefinedTrigger,
    kActorPredefinedAttackTrigger
  };

  enum eActorPredefinedTriggerType
  {
    //kActorPredefinedTrigger,
    kActorPredefinedTrigger
  };

  ActorTrigger* GetPredefinedGuardTrigger(eActorPredefinedGuardTriggerType predefined_trigger_type, Actor* actor, float size_multiplier = 1.0f);
  ActorTrigger* GetPredefinedAttackTrigger(eActorPredefinedAttackTriggerType predefined_trigger_type, Actor* actor, float size_multiplier = 1.0f);

  ActorTrigger* GetPredefinedGuardTriggerAuto(eActorPredefinedGuardTriggerType predefined_trigger_type, Actor* actor);
  //ActorTrigger* GetPredefinedAttackTriggerAuto(eActorPredefinedAttackTriggerType predefined_trigger_type, Actor* actor);  not in use

} // namespace actor


#endif // ACTOR_TRIGGER_PREDEFINED_H
