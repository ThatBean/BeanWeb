#include "actor_trigger_module_status.h"

#include "game/actor/actor.h"

namespace actor 
{
  const eActorTriggerModule ActorTriggerModuleStatus::trigger_module_type_ = kActorTriggerModuleStatus;
  const uint_32 ActorTriggerModuleDataStatus::TARGET_MODULE_TYPE = kActorTriggerModuleStatus;

  void ActorTriggerModuleDataStatus::SetHealthRatio(float ratio_a, float ratio_b/* = 0*/) 
  { 
    assert(ratio_a != ratio_b);
    health_ratio_max_ = max(ratio_a, ratio_b); 
    health_ratio_min_ = min(ratio_a, ratio_b); 
  }

  void ActorTriggerModuleDataStatus::ResetQuickFilter()
  {
    _filter_is_use_health_ratio_ = false;
  }
  bool ActorTriggerModuleDataStatus::InitQuickFilter(Actor* actor)  //return init result: true = need filter, false = keep all
  {
    if (GetTriggerFlag() & kActorTriggerStatusFlagHealthRatio) 
      _filter_is_use_health_ratio_ = true;

    return _filter_is_use_health_ratio_;
  }
  bool ActorTriggerModuleDataStatus::QuickFilter(Actor* ref_actor)  //return is_filtered: true = remove, false = keep
  {
    if (_filter_is_use_health_ratio_)
    {
      float ref_health_ratio = ref_actor->GetActorData()->GetBasicData()->GetCurrentHealth() * 1.0f / ref_actor->GetActorData()->GetBasicData()->GetTotalHealth();

      if (health_ratio_max_ > 0 && ref_health_ratio >= health_ratio_max_) return true;
      if (health_ratio_min_ >= 0 && ref_health_ratio < health_ratio_min_) return true;
    }

    return false;
  }


  ActorTriggerModuleStatus* ActorTriggerModuleStatus::Instance()
  {
    static ActorTriggerModuleStatus instance;
    return &instance;
  }

  bool ActorTriggerModuleStatus::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataStatus* trigger_module_data = dynamic_cast<ActorTriggerModuleDataStatus*>(trigger_module_data_);

    assert(trigger_module_data);

    UpdateStatus(actor, trigger_module_data, actor_list);

    return (actor_list->size() > 0);
  }

  void ActorTriggerModuleStatus::UpdateStatus(Actor* actor, ActorTriggerModuleDataStatus* trigger_module_data, std::list<Actor*>* actor_list)
  {
    bool is_filter_needed = trigger_module_data->InitQuickFilter(actor);
    if (is_filter_needed == false) return;

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* ref_actor = *iterator;

      bool is_filter = trigger_module_data->QuickFilter(ref_actor);

      if (is_filter)
        actor_list->erase(iterator++);
      else
        ++iterator;
    }
  }

}  // namespace actor