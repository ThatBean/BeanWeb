#include "actor_trigger_module_faction.h"

#include "game/actor/actor.h"

namespace actor 
{
  const eActorTriggerModule ActorTriggerModuleFaction::trigger_module_type_ = kActorTriggerModuleFaction;
  const uint_32 ActorTriggerModuleDataFaction::TARGET_MODULE_TYPE = kActorTriggerModuleFaction;
  


  void ActorTriggerModuleDataFaction::ResetQuickFilter()
  {
    //initial state: filter anything
    _filter_is_filter_user_support_ = true;
    _filter_is_filter_user_oppose_ = true;
    _filter_is_filter_user_self_ = true;
    _filter_is_filter_neutral_ = true;
    _filter_actor_user_self_ = NULL;
  }
  bool ActorTriggerModuleDataFaction::InitQuickFilter(Actor* actor)  //return init result: true = need filter, false = keep all
  {
    ResetQuickFilter();

    uint_32 trigger_flag = GetTriggerFlag();
    int actor_faction = actor->GetActorData()->GetActorStatus(kActorStatusFaction);

    //check flag
    if (trigger_flag & kActorTriggerFactionFlagUserSupport) _filter_is_filter_user_support_ = false;
    if (trigger_flag & kActorTriggerFactionFlagUserOppose) _filter_is_filter_user_oppose_ = false;
    if (trigger_flag & kActorTriggerFactionFlagFriendly)
    {
      if (actor_faction == kActorFactionUserSupport) _filter_is_filter_user_support_ = false;
      if (actor_faction == kActorFactionUserOppose) _filter_is_filter_user_oppose_ = false;
    }
    if (trigger_flag & kActorTriggerFactionFlagHostile)
    {
      if (actor_faction == kActorFactionUserSupport) _filter_is_filter_user_oppose_ = false;
      if (actor_faction == kActorFactionUserOppose) _filter_is_filter_user_support_ = false;
    }
    if (trigger_flag & kActorTriggerFactionFlagSelf) 
    {
      _filter_is_filter_user_self_ = false;
      _filter_actor_user_self_ = actor;
    }
    if (trigger_flag & kActorTriggerFactionFlagNeutral) _filter_is_filter_neutral_ = false;

    return (_filter_is_filter_user_support_
        || _filter_is_filter_user_oppose_
        || _filter_is_filter_user_self_
        || _filter_is_filter_neutral_); //if no filter is needed, return false to skip this filter
  }
  bool ActorTriggerModuleDataFaction::QuickFilter(Actor* ref_actor)  //return is_filtered: true = remove, false = keep
  {
    if (_filter_actor_user_self_ == ref_actor) //filter self
      return _filter_is_filter_user_self_;
    
    int ref_actor_faction = ref_actor->GetActorData()->GetActorStatus(kActorStatusFaction);

    if (ref_actor_faction == kActorFactionNeutral) //filter neutral
      return _filter_is_filter_neutral_;

    if (_filter_is_filter_user_support_ && ref_actor_faction == kActorFactionUserSupport) return true;
    if (_filter_is_filter_user_oppose_ && ref_actor_faction == kActorFactionUserOppose) return true;

    return false; //don't filter
  }



  ActorTriggerModuleFaction* ActorTriggerModuleFaction::Instance()
  {
    static ActorTriggerModuleFaction instance;
    return &instance;
  }

  bool ActorTriggerModuleFaction::Update(Actor* actor, ActorTriggerModuleData* trigger_module_data_, std::list<Actor*>* actor_list)
  {
    ActorTriggerModuleDataFaction* trigger_module_data = dynamic_cast<ActorTriggerModuleDataFaction*>(trigger_module_data_);

    assert(trigger_module_data);

    UpdateFaction(actor, trigger_module_data, actor_list);
    
    return (actor_list->size() > 0);
  }

  void ActorTriggerModuleFaction::UpdateFaction(Actor* actor, ActorTriggerModuleDataFaction* trigger_module_data, std::list<Actor*>* actor_list)
  {
    bool is_filter_needed = trigger_module_data->InitQuickFilter(actor);
    if (is_filter_needed == false) return;

    std::list<Actor*>::iterator iterator = actor_list->begin();
    while (iterator != actor_list->end())
    {
      Actor* ref_actor = *iterator;

      bool is_filter = trigger_module_data->QuickFilter(ref_actor);

      if (is_filter)
        actor_list->erase(iterator++);
      else
        ++iterator;
    }
  }
}  // namespace actor