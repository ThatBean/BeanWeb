#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "game/actor/template_class/actor_signal_hub.h"
#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorData;
  class ActorControlData;

  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

  public:
    void Connect();  //create Lua actor script
    void Init();  //init and start Lua actor script update
    void Clear();

    void CallLuaActorFunction(const std::string& function_name, int value_int);
    void CallLuaActorFunction(const std::string& function_name, float value_float);
    void CallLuaActorFunction(const std::string& function_name, const std::string& value_string);

    void AddLuaActorData(const std::string& key_string, int value_int);
    void AddLuaActorData(const std::string& key_string, float value_float);
    void AddLuaActorData(const std::string& key_string, const std::string& value_string);

    void Emit(const std::string& key);

    void Update(float delta_time);

    //for data signal
    void OnAttributeDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnStatusDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);
    void OnPositionDataOperation(int operation_type, int actor_data_type, ActorData* actor_data);

    void OnDataOperation(int operation_type, int data_class_type, int actor_data_type, ActorData* actor_data);


  public:
    static void RemoveAllLuaActor();


    //export to lua for data
  public: //global
    static void SetIsAutoControl(bool is_auto_control) { is_auto_control_ = is_auto_control; }
    static bool GetIsAutoControl() { return is_auto_control_; }


    static cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
    static cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
    static int GetGridXFromPositionX(float position_x);
    static int GetGridYFromPositionY(float position_y);

    static void ScriptAssert(bool expression, const std::string& message);

    //for debug
    //for debug

    //danger...
    //danger...
    static void SimulateTouchAt(float x, float y); 
    //touch_event_id = 0, 1, 2, 3; safer to use CCTOUCHBEGAN etc
    static void SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id); 
    //this will get a modified static touch set in c++
    static cocos2d::CCSet* GetTouchSet(float x, float y);

    //tester
    //tester
    static bool TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node);



  public: //actor_based
    float GetActorHealthPercent();  //
    cocos2d::CCPoint GetActorPosition();
    ActorControlData* GetActorRoutineControlData();

    void SetActorIsAutoGuard(bool is_auto);
    void UpdateSpecialGuard(int type);
    
    void ShowActorLog(int max_line);
    void ActorScriptAssert(bool expression, const std::string& message);  //target actor linked, neat


    //Experiment event
    void ActorDataSignalConnect(int data_class_type, int actor_data_type);
    void ActorDataSignalDisconnect(int data_class_type, int actor_data_type);
    //export to lua for data


  private:
    Actor*  actor_;  //keep actor pointer
    int     lua_actor_id_;

    float   cached_delta_time_;
    float   update_min_delta_time_;

    //int data_class_type, int actor_data_type, int callback_id
    std::map<int, std::map<int, ActorSignalConnection > > lua_signal_connection_map_;

    static bool is_auto_control_;
  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H