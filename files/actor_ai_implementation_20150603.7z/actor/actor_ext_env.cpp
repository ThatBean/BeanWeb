#include "actor_ext_env.h"

#include "actor.h"
#include "actor_ext_grid.h"
#include "actor_ext_user_operation.h"

//#include "game/battle/tiled_map/coordinate_helper.h"

namespace actor {
    ActorExtEnv::ActorExtEnv()
      :actor_next_valid_id_(1),
      is_pause_(false)
    {
      actor_map_.clear();
      actor_id_list_.clear();

      actor_ext_grid_ = new ActorExtGrid(this);
      actor_ext_user_operation_ = new ActorExtUserOperation(this);

      actor_focus_map_.clear();
    }

    ActorExtEnv::~ActorExtEnv()
    {
      Clear();


      if (actor_ext_grid_) delete actor_ext_grid_;
      if (actor_ext_user_operation_) delete actor_ext_user_operation_;

      actor_ext_grid_ = NULL;
      actor_ext_user_operation_ = NULL;
    }

    void ActorExtEnv::Clear()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        
        printf("[ActorExtEnv][Clear] possible leaking actor, ID:%d", actor->GetActorId());
        //delete actor;

        ++iterator;
      }

      actor_map_.clear();
      actor_id_list_.clear();

      if (actor_ext_grid_) actor_ext_grid_->Clear();
      if (actor_ext_user_operation_) actor_ext_user_operation_->Clear();

      actor_focus_map_.clear();
    }


    void ActorExtEnv::Update(float delta_time)
    {
      delta_time = delta_time > 0.05f ? 0.05f : delta_time; //prevent debug lag
      
      //update grid
      actor_ext_grid_->UpdateActorGridList();

      //update pause
      if (is_pause_)
        PauseActorByFocus();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while(iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        if (actor->GetIsActorActive() == true)
          actor->Update(delta_time);

        ++iterator;
      }
    }

    int ActorExtEnv::AddActor(Actor* actor) //will return actor_id
    {
      int actor_id = actor_next_valid_id_;
      
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      //add code here if actor id needs following some strange rule
      
      AddActor(actor_id, actor);
      return actor_id;
    }

    void ActorExtEnv::AddActor(int actor_id, Actor* actor) //alternative, predefined actor_id
    {
      assert(actor_map_.find(actor_id) == actor_map_.end());

      if (actor->GetActorId() != ACTOR_ID_INVALID)
      {
        RemoveActor(actor->GetActorId());
      }

      actor->SetActorId(actor_id);
      actor->SetActorExtEnv(this);
      actor_map_[actor_id] = actor;
      actor_id_list_.push_back(actor_id);
      
      actor_next_valid_id_ = (actor_id > actor_next_valid_id_ ? actor_id : actor_next_valid_id_) + 1;
    }

    Actor* ActorExtEnv::RemoveActor(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        Actor* actor = actor_map_.at(actor_id);
        actor_map_.erase(actor_id);
        std::list<int>::iterator iterator = actor_id_list_.begin();
        while (iterator != actor_id_list_.end())
        {
          if (*iterator == actor_id)
          {
            actor_id_list_.erase(iterator);
            break;
          }
          ++iterator;
        }
        actor->SetActorExtEnv(NULL);
        return actor;
      }
      else
      {
        assert(false);
        return NULL;
      }
    }

    Actor* ActorExtEnv::GetActorById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
        return actor_map_.at(actor_id);
      else
        return NULL;
    }

    int ActorExtEnv::GetActorCount()
    {
      return actor_id_list_.size();
    }

    std::list<Actor*>* ActorExtEnv::GetActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        if (actor->GetIsActorActive() == true 
          && IsPositionXInGrid(actor->GetActorData()->GetActorPosition(kActorPositionAnimation)) == true
          && actor->GetActorData()->GetBasicData()->GetIsDeadStatus() == false)
          actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }

    std::list<Actor*>* ActorExtEnv::GetAllActorList()  //should delete after use
    {
      std::list<Actor*>* actor_list = new std::list<Actor*>();

      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;
        actor_list->push_back(actor);
        ++iterator;
      }

      return actor_list;
    }

//     //for lua
//     cocos2d::CCArray*         GetActorIdCCArray(bool is_active_only = true, eActorFactionType actor_faction = kActorFaction);
// 
//     cocos2d::CCArray* ActorExtEnv::GetActorIdCCArray(bool is_active_only/* = true*/, eActorFactionType actor_faction/* = kActorFaction*/)
//     {
//       CCArray *cc_array = CCArray::create();
//
//       std::map<int, Actor*>::iterator iterator = actor_map_.begin();
//       while (iterator != actor_map_.end())
//       {
//         int actor_id = iterator->first;
//         Actor* actor = iterator->second;
//         if (
//           (actor_faction == kActorFaction || actor_faction == actor->GetActorData()->GetActorStatus(kActorStatusFaction))
//           && (is_active_only == false || actor->GetIsActorActive())
//           )
//         {
//           cc_array->addObject(cocos2d::CCInteger::create(actor_id));
//         }
//         
//         ++iterator;
//       }
//       return cc_array;
//     }



    //should move ? should move
    //for skill pause need
    void ActorExtEnv::AddActorFocusById(int actor_id)
    {
      if (actor_map_.find(actor_id) != actor_map_.end())
      {
        actor_focus_map_[actor_id] = actor_map_[actor_id];
      }
      else
        assert(false);
    }

    void ActorExtEnv::PauseActorByFocus()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;

        if (actor_focus_map_.find(actor_id) != actor_focus_map_.end())
          actor->SetIsActorPause(false);
        else
          actor->SetIsActorPause(true);

        ++iterator;
      }
    }

    void ActorExtEnv::ClearActorPause()
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        Actor* actor = iterator->second;

        actor->SetIsActorPause(false);

        ++iterator;
      }
    }

    void ActorExtEnv::SetIsPause(bool is_pause) 
    { 
      if (is_pause_ != is_pause)
      {
        if (is_pause)
          PauseActorByFocus();
        else
          ClearActorPause();

        is_pause_ = is_pause; 
      }
    }

    void ActorExtEnv::SetPauseActorByFaction(int actor_faction, bool is_pause)
    {
      std::map<int, Actor*>::iterator iterator = actor_map_.begin();
      while (iterator != actor_map_.end())
      {
        int actor_id = iterator->first;
        Actor* actor = iterator->second;

        if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == actor_faction)
          actor->SetIsActorPause(is_pause);

        ++iterator;
      }
    }

    //for skill counter attack
    void ActorExtEnv::SkillAttackedNotification(int from_actor_id, int to_actor_id, int skill_id, int health_change)
    {
      Actor* from_actor = GetActorById(from_actor_id);
      Actor* to_actor = GetActorById(to_actor_id);

      if (!from_actor || !to_actor || health_change <= 0)
        return;

      cocos2d::CCPoint from_actor_position = from_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);
      cocos2d::CCPoint to_actor_position = to_actor->GetActorData()->GetActorPosition(kActorPositionAnimation);

      float distance = from_actor_position.getDistance(to_actor_position);

      if (distance > to_actor->GetAnimation()->GetSkeletonAnimationBox().size.width * 1.5
        || from_actor->GetActorData()->GetActorStatus(kActorStatusFaction) == to_actor->GetActorData()->GetActorStatus(kActorStatusFaction))
        return;

      //move to position only
      to_actor->GetActorData()->GetUserControlData()->SetPosition(from_actor_position, kActorControlPriorityMoveAuto);
    }
    //should move ? should move

} // namespace actor