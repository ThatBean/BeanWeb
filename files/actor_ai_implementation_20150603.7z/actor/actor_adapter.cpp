#include "actor_adapter.h"

#include "actor.h"
#include "game/actor/control/actor_control.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/motion/actor_motion_state_machine.h"
#include "game/actor/trigger/actor_trigger_predefined.h"


#include "game/army/unit/monster.h"
#include "game/army/unit/character.h"

#include "game/battle/battle_controller.h"
#include "game/battle/level/levelbase.h"

#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "game/user_interface/battle_ui/battle_ui_constants.h"

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
//#include "game/artificial_intelligence/ai_config.h"

#include "game/ago_skill/control/ASkillControl.h"

#include "game/battle/view/battle_view.h"
#include "game/battle/view/battle_layer.h"
#include "game/battle/view/aim_mark.h"
#include "game/battle/view/battle_view_constant.h"

#include "game/game_manager/data_manager.h"

#include "engine/base/random_helper.h"
#include "engine/script/lua_tinker_manager.h"
#include "engine/ui_factory/ui_factory.h"
#include "base/utils_string.h"

namespace actor
{

  // TODO: remove
  //used only in this file
  //don't want tile index in actor system, used only:
  //  PositionCorrection (Primary)
  //  position (Secondary)
  //  grid x/y (Remedy, should be enough)
  //below only used for tile_index to grid_x/y
  const int tile_index_to_grid_x_list[18] = {
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6
  };
  const int tile_index_to_grid_y_list[18] = {
    3,  3,  3,      3,  3,  3,
    2,  2,  2,      2,  2,  2,
    1,  1,  1,      1,  1,  1
  };

  int GetGridXFromTileIndex(int tile_index) { return tile_index_to_grid_x_list[tile_index]; }
  int GetGridYFromTileIndex(int tile_index) { return tile_index_to_grid_y_list[tile_index]; }
  //used only in this file


  void ResetSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->removeAllActorSkill();
  }


  void CommitSkillAdapter(ActorAdapter* actor_adapter, int skill_id, int attack_type, int target_actor_id)
  {
    int skill_release_type = -1;

    switch (eActorAttackType(attack_type))
    {
    case kActorAttackMelee:
      skill_release_type = kSkillNormalHitNear;
      break;
    case kActorAttackRanged:
    case kActorAttackHeal:
      skill_release_type = kSkillNormalHitFar;
      break;
    case kActorAttackPower:
      skill_release_type = kSkillSkill_Little;
      break;
    case kActorAttackSpecial:
      skill_release_type = kSkillSkill;
      break;
    }

    //actor_adapter_->set_selected_skill_id(skill_id);
    actor_adapter->getSkillControl()->playSkillByID(skill_id, skill_release_type, target_actor_id);
  }
  
  void PauseSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->pauseAllSkill();
  }

  void ResumeSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->resumeAllSkill();
  }

  void AutoReleaseSpecialSkill(int actor_id)
  {
    taomee::battle::BattleController::GetInstance().battle_ui()->SkillReleaseButtonSelected(actor_id);
  }
  
  void RandomCriticalHit(ActorAdapter* actor_adapter, Actor* target_actor)
  {
    // fighter crit
    float rand_value = taomee::random_0_1();
    float unit_critical = actor_adapter->critical_probability(target_actor->GetActorData()->GetBasicData()->GetActorLevel());
    if ( (rand_value < unit_critical) ) 
    {
      actor_adapter->set_critical_hit(true);
    }    
  }

  void ClearCriticalHit(ActorAdapter* actor_adapter)
  {
    actor_adapter->set_critical_hit(false);
  }


  bool GetIsAllyActorAuto()
  {
    return (ActorScriptExporter::GetIsAutoControl() || GetIsActorExtEnvArena());
  }
  
  bool GetIsActorExtEnvBabel()
  {
    return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_PVP_Manual;  //same thing
  }
  bool GetIsActorExtEnvArena()
  {
    return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_PVP_Auto;
  }

  ActorExtEnv* GetActorExtEnv()
  {
    return taomee::battle::BattleController::GetInstance().GetActorExtEnv();
  }







  void InitActorAttribute(ActorAdapter* actor_adapter, Actor* actor);
  void InitActorStatus(ActorAdapter* actor_adapter, Actor* actor);
  void InitActorPosition(ActorAdapter* actor_adapter, Actor* actor);


  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->set_is_active(false);
    actor_adapter->set_motion_state(taomee::ai::kMotionStateDead);
  }


  void NastyActorInitAfterBasicDataInitAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    CharacterData* character_data = actor_adapter->character_card_data();

    //first reset data(skill and specified)
    actor->GetActorData()->ResetData();


    InitActorAttribute(actor_adapter, actor);
    InitActorStatus(actor_adapter, actor);


    //set data
    actor->GetActorData()->InitActorStatus(kActorStatusFaction, actor_adapter->IsPlayer() ? kActorFactionUserSupport : kActorFactionUserOppose);
    
    if (character_data->GetIsEnemy())
    {
      if (character_data->GetMonsterLevel() > 0)
        actor->GetActorData()->InitActorStatus(kActorStatusAppearance, kActorAppearanceEnemyBoss);
      else
        actor->GetActorData()->InitActorStatus(kActorStatusAppearance, kActorAppearanceEnemyPawn);
    }
    else
      actor->GetActorData()->InitActorStatus(kActorStatusAppearance, kActorAppearanceCharacter);

    switch (taomee::army::eCareerType(character_data->GetJobType()))
    {
    case taomee::army::kCareerTypeWarrior:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerWarrior);
      break;
    case taomee::army::kCareerTypeArcher:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerArcher);
      break;
    case taomee::army::kCareerTypeWizard:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerWizard);
      break;
    case taomee::army::kCareerTypeMonk:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerPriest);
      break;
    case taomee::army::kCareerTypeKnight:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareerKnight);
      break;
    default:
      actor->GetActorData()->InitActorStatus(kActorStatusCareer, kActorCareer);
      break;
    }

    actor->GetActorData()->InitActorStatus(kActorAnimationStatusDirection, actor_adapter->IsPlayer() ? kActorAnimationDirectionLeft : kActorAnimationDirectionRight);

    //specified
    actor->GetActorData()->InitActorStatus(kActorSpecifiedStatusHomeDirection, actor_adapter->IsPlayer() ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);


    

    if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter
      && actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport
      && GetIsActorExtEnvArena() == false && GetIsActorExtEnvBabel() == false)
    {
      actor->GetActorData()->InitActorStatusBool(kActorSpecifiedStatusIsLimitGridX, true);
    }
    else
    {
      actor->GetActorData()->InitActorStatusBool(kActorSpecifiedStatusIsLimitGridX, false);
    }

    //control
    actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsManual, actor_adapter->IsPlayer());
    actor->GetActorData()->InitActorStatusBool(kActorControlStatusIsAuto, true);

  }



  void NastyActorInitAnimationInitAdapter(ActorAdapter* actor_adapter, Actor* actor, bool is_simple_init)
  {
    //clean up, for the data-reuse
    actor->GetAnimation()->ClearSkeletonAnimation();
    

    ActorData* actor_data = actor->GetActorData();
    int actor_id = actor->GetActorId();


    if (is_simple_init == false) 
    {

      //create a node under all actor - BottomLayerSyncNode
      cocos2d::CCLayer* battle_view_bottom_layer = taomee::battle::BattleController::GetInstance().battle_view()->GetLayer(taomee::battle::kBottomLayer);
      cocos2d::CCNode* bottom_layer_sync_node = battle_view_bottom_layer->getChildByTag(actor_id);
      if (bottom_layer_sync_node == NULL) 
      {
        bottom_layer_sync_node = cocos2d::CCNode::create();
        bottom_layer_sync_node->setTag(actor_id);
        battle_view_bottom_layer->addChild(bottom_layer_sync_node);
      }
      actor->GetAnimation()->SetBottomLayerSyncNode(bottom_layer_sync_node);

    }



    //link and initialize SkeletonAnimationNode
    taomee::SkeletonAnimation* skeleton_animation_node = actor_adapter->anima_node();
    // create animation node & shadow
    int card_id = actor_data->GetActorStatus(kActorStatusCardId);
    std::string card_name = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id)->GetName();
    float armature_scale = DataManager::GetInstance().GetCharacterDataTable()->GetCharacter(card_id)->GetSkeletonScale();

    skeleton_animation_node->Init(card_name.c_str(), card_name.c_str());
    std::string string_card_id = Int2String(card_id);
    CCString *str_card_id = CCString::create(string_card_id);
    //str_card_id->retain();
    skeleton_animation_node->GetArmatureNode()->setUserObject(str_card_id);
    skeleton_animation_node->GetArmatureNode()->setTag(card_id);
    skeleton_animation_node->SetAnimationScale(armature_scale);
    skeleton_animation_node->AddShadow();




    //create UILayer for health bar update
    
    UILayer* overhead_layer = UILayer::create();//����һ��UILayer��
    overhead_layer->scheduleUpdate(); //����ˢ�º���
    overhead_layer->setPosition(skeleton_animation_node->GetBonePositionInSkeleton(taomee::kBoneTypeHealthBar));
    skeleton_animation_node->addChild(overhead_layer, taomee::army::kHitPointBarFlag, taomee::army::kHitPointBarFlag); //��UILayer����뵽���ﶯ��
    actor->GetAnimation()->SetOverheadLayer(overhead_layer);


    switch (actor->GetActorData()->GetActorStatus(kActorStatusAppearance))
    {
    case kActorAppearanceCharacter:
      {
        UIWidget* health_bar_widget = UIFactory::createWidgetFromFile("ui/agoui_player_hp.json");//ʹ��json�ļ���Layer������CocoStudio���ɵĿؼ�
        health_bar_widget->setScale(0.8f);
        overhead_layer->addWidget(health_bar_widget);

        if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserOppose) //change color for PVP enemy player
        {
          UILoadingBar* health_bar_widget = dynamic_cast<UILoadingBar*>(overhead_layer->getWidgetByName("progress_hp"));
          health_bar_widget->loadTexture("agoui_redblood01.png", UI_TEX_TYPE_PLIST);
        }

        UILabelBMFont* label_friend_name = dynamic_cast<UILabelBMFont*>(overhead_layer->getWidgetByName("Label_Friend"));
        label_friend_name->setVisible(false);
      }
      break;
    case kActorAppearanceEnemyBoss:
    case kActorAppearanceEnemyPawn:
      {
        // add health bar for monster
        overhead_layer->addWidget(UIFactory::createWidgetFromFile("ui/agoui_monster_hp.json"));
      }
      break;
    }

    //common health bar init
    UILoadingBar* health_bar_widget = dynamic_cast<UILoadingBar*>(overhead_layer->getWidgetByName("progress_hp"));
    health_bar_widget->setPercent(100);
    health_bar_widget->retain();

    UILoadingBar* health_bar_bg_widget = dynamic_cast<UILoadingBar*>(overhead_layer->getWidgetByName("progress_bg"));
    health_bar_bg_widget->setPercent(100);
    health_bar_bg_widget->setIsHaveAni(true);
    health_bar_bg_widget->retain();


    if (is_simple_init == false) 
    {
      // TODO: currently don't hold widget for Exp update
      actor->GetAnimation()->SetHealthBarWidget(health_bar_widget);
      actor->GetAnimation()->SetHealthBarBgWidget(health_bar_bg_widget);
    }


    // TODO: remove? | Boss Effect
    if (actor_data->GetActorStatus(kActorStatusAppearance) == kActorAppearanceEnemyBoss)
    {
      LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/ui/WarningUI.lua", "ShowBossWarningUIToBattleScene");
      //Add Boss Effect
      taomee::SkeletonAnimation* boss_effect = new taomee::SkeletonAnimation();
      boss_effect->Init("boss_bjtx", "boss_bjtx");
      boss_effect->Play("bsj");
      skeleton_animation_node->addChild(boss_effect, -1);
    }

    actor->GetAnimation()->InitSkeletonAnimation(skeleton_animation_node);
  }







  void NastyActorInitAfterAnimationInitAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    CharacterData* character_data = actor_adapter->character_card_data();
    

    InitActorPosition(actor_adapter, actor);


    if (character_data->GetMoveType() != 8)
    { 
      switch ( actor->GetActorData()->GetActorStatus(kActorStatusCareer))
      {
        break;
      case kActorCareerWarrior:
      case kActorCareerKnight:
        if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceEnemyBoss)
        {
          actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuardMelee);
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalType, kActorAttackMelee);
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalSkillId, character_data->GetSkillId(kSkillNormalHitNear));

          actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerMeleeRect, actor));
          actor->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerMeleeRect, actor));
          actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerMeleeCircle, actor));
        }
        else
        {
          actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuardMelee);
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalType, kActorAttackMelee);
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalSkillId, character_data->GetSkillId(kSkillNormalHitNear));

          actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerMeleeCircle, actor));
          actor->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerMeleeCircle, actor));
          actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerMeleeCircle, actor));
        }
        break;
      case kActorCareerPriest:
        if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) != kActorAppearanceCharacter)
        {
          actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuard);
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalType, kActorAttackHeal);
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalSkillId, character_data->GetSkillId(kSkillNormalHitFar));

          actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerHeal, actor));
          actor->GetActorData()->GetSkillData()->SetGuardTrigger(NULL);
          actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(NULL);
          break;
        }
        //else goto Ranged
      case kActorCareerArcher:
      case kActorCareerWizard:
        actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuard);
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalType, kActorAttackRanged);
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalSkillId, character_data->GetSkillId(kSkillNormalHitFar));

        actor->GetActorData()->GetSkillData()->SetAttackTrigger(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerRangedRect, actor));
        actor->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerRangedRect, actor));
        actor->GetActorData()->GetSkillData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerRangedRect, actor));
        break;
      default:
        actor->GetActorData()->InitActorStatus(kActorSkillStatusGuardType, kActorGuard);
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalType, kActorAttack);
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackNormalSkillId, ACTOR_SKILL_ID_INVALID);
        assert(false);
        break;
      }
      if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport
        && actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)
      {
        taomee::army::Character* actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);
        assert(actor_adapter_character);

        if (character_data->GetSkillId(kSkillSkill_Little) > 0 
          && actor_adapter_character->getSkillLevel(character_data->GetSkillId(kSkillSkill_Little)) > 0)
        {
          actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackPowerSkillId, character_data->GetSkillId(kSkillSkill_Little));
        }

        if (character_data->GetSkillId(kSkillSkill) > 0)
        {
          if (actor_adapter_character->getSkillLevel(character_data->GetSkillId(kSkillSkill)) <= 0)
          {
            printf("[ERROR] Special Skill Level in character info is invalid \n");
            printf("[ERROR] -- actor_id: %d \n", actor->GetActorId());
            printf("[ERROR] -- actor_card_id: %d \n", character_data->GetCid());
            printf("[ERROR] -- actor_skill_id: %d \n", character_data->GetSkillId(kSkillSkill));
            printf("[ERROR] -- Special Skill Level: %d \n", actor_adapter_character->getSkillLevel(character_data->GetSkillId(kSkillSkill)));
            printf("[ERROR] This Assert can be safely ignored \n");
            //assert(false);
          }
        }
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackSpecialSkillId, character_data->GetSkillId(kSkillSkill) > 0 ? character_data->GetSkillId(kSkillSkill) : ACTOR_SKILL_ID_INVALID);
      }
      else
      {
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackPowerSkillId, character_data->GetSkillId(kSkillSkill_Little) > 0 ? character_data->GetSkillId(kSkillSkill_Little) : ACTOR_SKILL_ID_INVALID);
        actor->GetActorData()->InitActorStatus(kActorSkillStatusAttackSpecialSkillId, character_data->GetSkillId(kSkillSkill) > 0 ? character_data->GetSkillId(kSkillSkill) : ACTOR_SKILL_ID_INVALID);
      }


      //monster not auto guard by default
      if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) != kActorAppearanceCharacter
        && actor->GetActorData()->GetSkillData()->GetGuardTriggerAuto())
      {
        actor->GetActorData()->GetSkillData()->GetGuardTriggerAuto()->SetIsPause(true);
      }
    }

    //check skill
    assert(actor->GetActorData()->GetActorStatus(kActorSkillStatusAttackNormalSkillId) != 0);
    assert(actor->GetActorData()->GetActorStatus(kActorSkillStatusAttackPowerSkillId) != 0);
    assert(actor->GetActorData()->GetActorStatus(kActorSkillStatusAttackSpecialSkillId) != 0);




    ActorScriptExporter* actor_script_exporter = actor->GetActorScriptExporter();

    actor_script_exporter->Connect();

    if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserOppose)
    {
      if (character_data->GetMoveType() != 8)
      {
        //routine_config_enemy_pawn
        actor_script_exporter->AddLuaActorData(std::string("ROUTINE_NAME"), std::string("routine_config_enemy_pawn"));

        taomee::army::Monster* actor_adapter_monster = dynamic_cast<taomee::army::Monster*>(actor_adapter);
        if (actor_adapter_monster)
        {
          int stay_grid_x;
          switch(character_data->GetMoveType())
          {
          case 2: //near attack warrior, need stay on column 1 for some seconds
          case 4: //range attack archer, need stay on column 1 for some seconds
          case 7: //big boss, stay on column x forever
            stay_grid_x = 2;  // left center
            break;
          case 3: //normal range attack archer, need stay on column 0 for some seconds
          case 5: //assassin, need stay on column 1 for some seconds to search suitable row path
          case 6: //monk, singer, dancer, need stay on column 1 for some seconds util teammate dead
            stay_grid_x = 1;  // left base line
            break;
          case 1: //normal near attack warrior, need not stop
          case 8: //blind, walk walk walk
          default:
            stay_grid_x =  -1;  // not stay
            break;
          }

          if (battle::BattleController::GetInstance().getBattleType() == battle::kBattleType_SandBox)
          {
            stay_grid_x = 2;  // left center
          }
          
          int born_grid_x = stay_grid_x > 0 ? stay_grid_x : -1;
          int born_grid_y = GetGridYFromPositionY(actor_adapter->anima_node()->getPosition().y);
          actor_script_exporter->AddLuaActorData(std::string("born_grid_x"), born_grid_x);
          actor_script_exporter->AddLuaActorData(std::string("born_grid_y"), born_grid_y);
        }
      }
      else
      {
        //routine_config_enemy_blind
        actor_script_exporter->AddLuaActorData(std::string("ROUTINE_NAME"), std::string("routine_config_enemy_blind"));

        //not born grid
      }
    }
    else
    {
      //routine_config_character
      actor_script_exporter->AddLuaActorData(std::string("ROUTINE_NAME"), std::string("routine_config_character"));

      taomee::army::Character* actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);
      if (actor_adapter_character)
      {
        int born_tile_index = actor_adapter_character->garrison_tile_index();

        int born_grid_x = GetGridXFromTileIndex(born_tile_index);
        int born_grid_y = GetGridYFromTileIndex(born_tile_index);
        actor_script_exporter->AddLuaActorData(std::string("born_grid_x"), born_grid_x);
        actor_script_exporter->AddLuaActorData(std::string("born_grid_y"), born_grid_y);
      }
    }
    //activate
    actor_script_exporter->Init();

    //first reset direction
    actor->GetActorData()->GetActorStatusData(kActorAnimationStatusDirection)->Reset();


    //initial logic state
    actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateBorn));





    //init control auto guard
    if ((GetIsActorExtEnvBabel() == true && actor_adapter->IsPlayer() == false) || (GetIsActorExtEnvArena() == true))
    {
      actor->GetActorData()->InitActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardPreferY);

      if (
        actor->GetActorData()->GetSkillData()->GetGuardTrigger()
        && (
          actor->GetActorData()->GetActorStatus(kActorStatusCareer) == kActorCareerWarrior
          || actor->GetActorData()->GetActorStatus(kActorStatusCareer) == kActorCareerKnight
        ))
      {
        delete actor->GetActorData()->GetSkillData()->GetGuardTrigger();
        actor->GetActorData()->GetSkillData()->SetGuardTrigger(NULL);
      }
    }
    else
    {
      actor->GetActorData()->InitActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardDefault);
    }
    //auto guard will be enabled in actor routine control





    //init control auto release skill
    if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)
    {
      if (actor->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserSupport || GetIsActorExtEnvBabel() == true || GetIsActorExtEnvArena() == true)
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillWithPause);
      else
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillNoPause);

    }
    else
    {
      if (actor->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceEnemyPawn
        && character_data->GetSkillId(kSkillSkill) > 0
        && character_data->GetSkillRate() > 0)
      {
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillByAttackCount);
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillCount, character_data->GetSkillRate());
      }
      else
      {
        actor->GetActorData()->InitActorStatus(kActorControlStatusAutoReleaseSpecialSkillType, kActorControlAutoReleaseSkillInvalid);
      }
    }

    
    
    //Activate
    actor->SetIsActorActive(true);
  }



  void NastyActorClearAnimationAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    //clean up, for the data-reuse
    actor->GetAnimation()->ClearSkeletonAnimation();
  }





  const std::string GetDeadAnimationName(ActorAdapter* actor_adapter)
  {
    const taomee::battle::eDeadReason dead_reason = actor_adapter->get_dead_reason();

    switch (dead_reason)
    {
    case taomee::battle::kDeadReason_Disappear:
      return taomee::army::kUnitAnimationIdle;
    case taomee::battle::kDeadReason_Normal:
    case taomee::battle::kDeadReason_Timeout:
      return taomee::army::kUnitAnimationDead;
    case taomee::battle::kDeadReason_Suicide:
      return taomee::army::kUnitAnimationDead_2;
    default:
      //strange???
      return "";
    }
  }






  //add & experimental


  void InitActorAttribute(ActorAdapter* actor_adapter, Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();
    CharacterData* character_data = actor_adapter->character_card_data();

    actor_data->InitActorAttribute(kActorAttributeTimeActive, 0);

    actor_data->InitActorAttribute(kActorAttributeHealthCurrent, actor_adapter->currnet_health_point());
    actor_data->InitActorAttribute(kActorAttributeEnergyCurrent, actor_adapter->energy_value());
    actor_data->InitActorAttribute(kActorAttributeHealthMax, actor_adapter->total_health_point());
    actor_data->InitActorAttribute(kActorAttributeEnergyMax, taomee::ui::getKMaxAngry());

    actor_data->InitActorAttribute(kActorAttributeRateCritical, character_data->GetCritical());
    actor_data->InitActorAttribute(kActorAttributeRateHit, character_data->GetAddHitRate(), character_data->GetAddHitRate());
    actor_data->InitActorAttribute(kActorAttributeRateMiss, character_data->GetDodge(), character_data->GetAddDodge());

    actor_data->InitActorAttribute(kActorAttributeSpeedAttack, character_data->GetAtkSpeed());
    actor_data->InitActorAttribute(kActorAttributeSpeedMove, character_data->GetMovSpeed() * taomee::battle::kMapTileAverageLength);

    actor_data->InitActorAttribute(kActorAttributeAttackPhysical, actor_adapter->physics_attack());
    actor_data->InitActorAttribute(kActorAttributeAttackMagical, actor_adapter->magic_attack());
    actor_data->InitActorAttribute(kActorAttributeAttackCritical, character_data->GetCritical());

    actor_data->InitActorAttribute(kActorAttributeDefensePhysical, actor_adapter->physics_defense());
    actor_data->InitActorAttribute(kActorAttributeDefenseMagical, actor_adapter->magic_defense());
    actor_data->InitActorAttribute(kActorAttributeDefenseCritical, 0);


    actor_data->InitActorAttribute(kActorAttributeDamageAddition, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionPhysical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionMagical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionCritical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionIce, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionFire, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionWind, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionHealth, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageAdditionEnergy, 0);


    actor_data->InitActorAttribute(kActorAttributeDamageReductionPhysical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionMagical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionCritical, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionIce, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionFire, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionWind, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionHealth, 0);
    actor_data->InitActorAttribute(kActorAttributeDamageReductionEnergy, 0);


    actor_data->InitActorAttribute(kActorSkillAttributeAttackCount, 0);
    actor_data->InitActorAttribute(kActorSkillAttributeAttackNormalCount, 0);
    actor_data->InitActorAttribute(kActorSkillAttributeAttackPowerCount, 0);
    actor_data->InitActorAttribute(kActorSkillAttributeAttackSpecialCount, 0);
  }



  void InitActorStatus(ActorAdapter* actor_adapter, Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();
    CharacterData* character_data = actor_adapter->character_card_data();
    

    actor_data->InitActorStatus(kActorStatusCardId, actor_adapter->card_id());
    actor_data->InitActorStatus(kActorStatusLevel, actor_adapter->level());
    //get above
//     actor_data->InitActorStatus(kActorStatusAppearance, 0);
//     actor_data->InitActorStatus(kActorStatusFaction, 0);
//     actor_data->InitActorStatus(kActorStatusCareer, 0);

    actor_data->InitActorStatusBool(kActorStatusAcceptDamage, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamagePhysical, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageMagical, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageCritical, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageIce, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageFire, 1);
    actor_data->InitActorStatusBool(kActorStatusAcceptDamageWind, 1);


    actor_data->InitActorStatusBool(kActorLogicStatusIsIncontrollable, false);
    actor_data->InitActorStatusBool(kActorLogicStatusCanMove, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttack, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttackNormal, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttackPower, true);
    actor_data->InitActorStatusBool(kActorLogicStatusCanAttackSpecial, true);


    actor_data->InitActorStatusBool(kActorAnimationStatusIsPaused, false);
    actor_data->InitActorStatusBool(kActorAnimationStatusIsWeakAnimation, false);


    actor_data->InitActorStatus(kActorStatusLogicState, kActorLogicStateInvalid);
    actor_data->InitActorStatus(kActorStatusMotionState, kActorMotionStateInvalid);

    actor_data->InitActorStatus(kActorControlStatusAutoGuardType, kActorControlAutoGuardInvalid);


    actor_data->InitActorStatusBool(kActorMotionStatusIsBusy, false);
    actor_data->InitActorStatusBool(kActorSkillStatusIsBusy, false);

    actor_data->InitActorStatus(kActorSkillStatusCurrentSkillId, ACTOR_SKILL_ID_INVALID);

    actor_data->InitActorStatus(kActorSkillStatusAttackNormalSkillId, ACTOR_SKILL_ID_INVALID);
    actor_data->InitActorStatus(kActorSkillStatusAttackPowerSkillId, ACTOR_SKILL_ID_INVALID);
    actor_data->InitActorStatus(kActorSkillStatusAttackSpecialSkillId, ACTOR_SKILL_ID_INVALID);

  }



  void InitActorPosition(ActorAdapter* actor_adapter, Actor* actor)
  {
    ActorData* actor_data = actor->GetActorData();
    CharacterData* character_data = actor_adapter->character_card_data();
    
    //apply animation position
    actor_data->InitActorPosition(kActorPositionAnimation, actor_adapter->anima_node()->getPosition());

    actor_data->InitActorPosition(kActorMotionPositionMoveTarget, ccp(0, 0));
    actor_data->InitActorPosition(kActorMotionPositionMoveSpeedUnit, ccp(0, 0));

  }
}