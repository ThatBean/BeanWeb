#ifndef ACTOR_ANIMATION_H
#define ACTOR_ANIMATION_H

#include "game/actor/actor_adapter.h"
#include "cocos2d.h"

namespace taomee {
  class SkeletonAnimation;
}


namespace actor {

  class Actor;


  class ActorAnimation
  {
  public:
    ActorAnimation(Actor* actor_);
    ~ActorAnimation();

    void ClearSkeletonAnimation();
    void InitSkeletonAnimation(taomee::SkeletonAnimation* skeleton_animation_node);

    void Update(float delta_time);

    taomee::SkeletonAnimation* GetSkeletonAnimationNode() { return skeleton_animation_node_; }
    cocos2d::CCRect GetSkeletonAnimationBox();
    bool IsPointInAnimation(cocos2d::CCPoint position);

    void ChangeSkeletonAnimation(
      const std::string animation_name, 
      const int cycle_count = -1, 
      const float speed = 1.0f);

    void SetBottomLayerSyncNode(cocos2d::CCNode* bottom_layer_sync_node);
    cocos2d::CCNode* GetBottomLayerSyncNode() { return bottom_layer_sync_node_; };
    void SetOverheadLayer(UILayer* overhead_layer) { overhead_layer_ = overhead_layer; };
    UILayer* GetOverheadLayer() { return overhead_layer_; };
    void SetHealthBarWidget(cocos2d::extension::UILoadingBar* health_bar_widget) { health_bar_widget_ = health_bar_widget; };
    cocos2d::extension::UILoadingBar* GetHealthBarWidget() { return health_bar_widget_; };
    void SetHealthBarBgWidget(cocos2d::extension::UILoadingBar* health_bar_bg_widget) { health_bar_bg_widget_ = health_bar_bg_widget; };
    cocos2d::extension::UILoadingBar* GetHealthBarBgWidget() { return health_bar_bg_widget_; };

    void DeadAnimation(std::string animation_name);  //play dead cc action


    cocos2d::CCLayer* CreateGuardArea(bool is_circle_area = true);
    void StartGuardArea(float last_time);
    void RemoveGuardArea();

    void SetColorShader(cocos2d::ccColor4F shader_color, float last_time);
    void RemoveColorShader();

    void SetStatusShader(uint_32 shader_type);
    

  private:
    Actor* actor_;

    // animation parts:
    taomee::SkeletonAnimation*  skeleton_animation_node_;

    cocos2d::CCSize skeleton_animation_box_size_;
    cocos2d::CCPoint skeleton_animation_box_origin_offset_; //skeleton_animation_position + skeleton_animation_box_center_offset_ = skeleton_animation_box_center

    cocos2d::CCNode* bottom_layer_sync_node_;  // for shadow or other effect that must be under all actor, position sync will be updated from here
    
    UILayer* overhead_layer_; //a UILayer mainly for actor health display, under skeleton animation, no need to clean up
    
    cocos2d::extension::UILoadingBar* health_bar_widget_;
    cocos2d::extension::UILoadingBar* health_bar_bg_widget_;
    
    cocos2d::extension::UILabelBMFont* label_debug_info_widget_;
    
    //selection guard area
    cocos2d::CCLayer* guard_area_layer_;
    float guard_area_left_time_;
    
    //selection shader
    cocos2d::ccColor4F shader_color_;
    cocos2d::CCGLProgram* program_shader_color_;  //actually taomee::shader::ProgramChangeColor*
    float shader_color_left_time_;
    float shader_color_total_time_;
    
    // TODO: save to actor data
    //status shader | will conflict with selection shader(will use selection shader)
    uint_32 shader_type_; //default is kShaderDefault
  };

} // namespace actor


#endif // ACTOR_ANIMATION_H