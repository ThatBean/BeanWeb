#include "actor_animation.h"

#include "game/actor/actor.h"
#include "game/actor/trigger/actor_trigger_predefined.h"
#include "game/actor/logic/actor_logic_state_machine.h"
#include "game/actor/motion/actor_motion_state_machine.h"


#include "engine/script/lua_tinker_manager.h"

#include "game/shader/shader_manager.h"
#include "game/shader/shader_program/program_change_color.h"

namespace actor {

  //ActorAnimation
  ActorAnimation::ActorAnimation(Actor* actor)
    :actor_(actor),
    skeleton_animation_node_(NULL),
    bottom_layer_sync_node_(NULL),
    overhead_layer_(NULL),
    health_bar_widget_(NULL),
    health_bar_bg_widget_(NULL),
    label_debug_info_widget_(NULL),

    guard_area_layer_(NULL),
    guard_area_left_time_(0),
    
    program_shader_color_(NULL),
    shader_color_left_time_(0),
    shader_color_total_time_(0)
    
    
  {
    shader_type_ = taomee::shader::kShaderDefault;
  }

  ActorAnimation::~ActorAnimation()
  {
    ClearSkeletonAnimation();
  }

  void ActorAnimation::ClearSkeletonAnimation()
  {
    //skeleton_animation_node_ will be cleared outside
    if (bottom_layer_sync_node_) bottom_layer_sync_node_->removeFromParentAndCleanup(true);
    //overhead_layer_ will be cleared with skeleton_animation_node_
    if (health_bar_widget_) health_bar_widget_->release();
    if (health_bar_bg_widget_) health_bar_bg_widget_->release();
    //label_debug_info_widget_ will be cleared with overhead_layer_ and skeleton_animation_node_
    //guard_area_layer_ will be cleared with bottom_layer_sync_node_

    //clean up
    skeleton_animation_node_ = NULL;
    bottom_layer_sync_node_ = NULL;
    overhead_layer_ = NULL;
    health_bar_widget_ = NULL;
    health_bar_bg_widget_ = NULL;
    
    label_debug_info_widget_ = NULL;

    guard_area_layer_ = NULL;
    guard_area_left_time_ = 0;

    program_shader_color_ = NULL;
    shader_color_left_time_ = 0;
    shader_color_total_time_ = 0;

    shader_type_ = taomee::shader::kShaderDefault;
  }

  void ActorAnimation::InitSkeletonAnimation(taomee::SkeletonAnimation* skeleton_animation_node)
  {

    skeleton_animation_node_ = skeleton_animation_node;
    
    
    if (!skeleton_animation_node_) assert(false);
    
    //calculate box and center point offset
    cocos2d::CCPoint skeleton_animation_position = skeleton_animation_node_->getPosition();
    cocos2d::CCRect skeleton_animation_bounding_box = CCRectApplyAffineTransform(
      CCRectApplyAffineTransform(
        skeleton_animation_node_->GetArmatureNode()->boundingBox(), skeleton_animation_node_->GetArmatureNode()->nodeToParentTransform()), 
      skeleton_animation_node_->nodeToParentTransform());

    skeleton_animation_box_size_.setSize(
      int(max(skeleton_animation_bounding_box.size.width, taomee::battle::kMapTileMinLength) / taomee::battle::kMapTileMinLength) * taomee::battle::kMapTileMinLength,
      int(max(skeleton_animation_bounding_box.size.height, taomee::battle::kMapTileAverageHeight) / taomee::battle::kMapTileAverageHeight) * taomee::battle::kMapTileAverageHeight);

    skeleton_animation_box_origin_offset_ = ccp(
      skeleton_animation_bounding_box.origin.x - skeleton_animation_position.x, 
      skeleton_animation_bounding_box.origin.y - skeleton_animation_position.y);

    //skeleton_animation_box debug
    bool is_show_skeleton_animation_box = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "IsShowCharacterBoundBox");
    if (is_show_skeleton_animation_box && skeleton_animation_node_)
    {
      CCDrawNode* debug_box_draw_node = CCDrawNode::create();
      CCRect rect_box = GetSkeletonAnimationBox();
      rect_box.origin = skeleton_animation_box_origin_offset_;
      rect_box.size.setSize(skeleton_animation_box_size_.width, skeleton_animation_box_size_.height);
      CCPoint vertex_list[4]={
        ccp(rect_box.getMinX(), rect_box.getMinY()), ccp(rect_box.getMaxX(), rect_box.getMinY()),
        ccp(rect_box.getMaxX(), rect_box.getMaxY()), ccp(rect_box.getMinX(), rect_box.getMaxY())};
      ccColor4F fill_color = {0, 0, 0, 0};  //transparent
      float debug_box_border_width = 5;
      ccColor4F border_color = {1, 1, 0, 1};  //yellow
      debug_box_draw_node->drawPolygon(vertex_list, 4, fill_color, debug_box_border_width, border_color);
      skeleton_animation_node_->addChild(debug_box_draw_node, 246810);
    }

    //debug Info
    bool is_show_debug_info = LuaTinkerManager::GetInstance().CallLuaFunc<bool>("script/config/debug_config.lua", "IsShowObjID");
    if (is_show_debug_info)
    {
      if (label_debug_info_widget_) label_debug_info_widget_->removeFromParentAndCleanup(true);
      label_debug_info_widget_ = UILabelBMFont::create();
      label_debug_info_widget_->setFntFile("ui/font/font_2.fnt"); // TODO: use relative path
      label_debug_info_widget_->setPosition(ccp(0, 10));
      label_debug_info_widget_->setAnchorPoint(ccp(0.5, 0));
      label_debug_info_widget_->setScale(0.4);
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance))
      {
      case kActorAppearanceCharacter:
        label_debug_info_widget_->setColor(ccc3(255, 220, 220));
        break;
      case kActorAppearanceEnemyBoss:
        label_debug_info_widget_->setColor(ccc3(220, 255, 220));
        break;
      case kActorAppearanceEnemyPawn:
        label_debug_info_widget_->setColor(ccc3(220, 220, 255));
        break;
      }
      overhead_layer_->addWidget(label_debug_info_widget_);
    }

  }


  void ActorAnimation::Update(float delta_time)
  { 
    if (!skeleton_animation_node_) return;

    //pause
    bool is_status_pause = actor_->GetActorData()->GetActorStatusBool(kActorAnimationStatusIsPaused);
    bool is_animation_pause = (skeleton_animation_node_->state() == taomee::SkeletonAnimation::kStatePaused);

    if (is_status_pause != is_animation_pause)
    {
      if (is_status_pause) skeleton_animation_node_->Pause();
      else skeleton_animation_node_->Resume();
      actor_->GetActorData()->AddLogF("[ActorAnimation][Update] is pause: %s\n", is_status_pause ? "true" : "false");
    }

    //direction
    eActorAnimationDirection status_direction = (eActorAnimationDirection)actor_->GetActorData()->GetActorStatus(kActorAnimationStatusDirection);
    eActorAnimationDirection animation_direction = (skeleton_animation_node_->GetDirection() == taomee::kDirectionLeft ? kActorAnimationDirectionLeft : kActorAnimationDirectionRight);

    if (status_direction != animation_direction)
    {
      skeleton_animation_node_->ChangeDirection(status_direction == kActorAnimationDirectionLeft ? taomee::kDirectionLeft : taomee::kDirectionRight);
      printf("[ActorAnimation][Update] change direction: %s\n", status_direction == kActorAnimationDirectionLeft ? "left" : "right");
    }

    //weak animation
    if (actor_->GetActorData()->GetActorStatus(kActorStatusAppearance) == kActorAppearanceCharacter)  //only character has weak animation
    {
      bool is_weak_animation = actor_->GetActorData()->GetActorStatusBool(kActorAnimationStatusIsWeakAnimation);
      eActorMotionState motion_state = (eActorMotionState)actor_->GetActorData()->GetActorStatus(kActorStatusMotionState);

      switch (motion_state)
      {
      case kActorMotionStateIdle:
        {
          if (is_weak_animation) ChangeSkeletonAnimation(taomee::army::kUnitAnimationWeak);
          else ChangeSkeletonAnimation(taomee::army::kUnitAnimationIdle);
        }
        break;
      case kActorMotionStateMove:
        {
          if (is_weak_animation) ChangeSkeletonAnimation(taomee::army::kUnitAnimationWeakWalk);
          else ChangeSkeletonAnimation(taomee::army::kUnitAnimationWalk);
        }
        break;
      }
    }

    //animation position
    cocos2d::CCPoint animation_position = actor_->GetActorData()->GetActorPosition(kActorPositionAnimation);
    cocos2d::CCPoint skeleton_animation_position = skeleton_animation_node_->getPosition();

    if (actor_->GetActorData()->GetSpecifiedData()->IsPositionValid(animation_position) == false
      && actor_->GetActorData()->GetSpecifiedData()->IsPositionValid(skeleton_animation_position) == true) //check position, only moving out of box is blocked
    {
      actor_->GetActorData()->AddLogF("[kActorPositionAnimation] moving out of box is blocked (%f, %f)", animation_position.x, animation_position.y);
      if (actor_->GetActorData()->GetControlData()->IsSetTarget()) actor_->GetActorData()->GetControlData()->ResetTarget();
      if (actor_->GetActorData()->GetControlData()->IsSetPosition()) actor_->GetActorData()->GetControlData()->SetPosition(skeleton_animation_position);
    }
    else
    {
      skeleton_animation_node_->setPosition(animation_position);

      // TODO: need move? | show enemy warning
      if (actor_->GetActorData()->GetActorStatus(kActorStatusFaction) == kActorFactionUserOppose 
        && GetIsActorExtEnvArena() == false && animation_position.x > taomee::battle::kMapRightMostX * 0.6)
        LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/WarningUI.lua", "AutoExtendWarningUIToBattleScene");
    }


    //update tagged node position
    if (bottom_layer_sync_node_) bottom_layer_sync_node_->setPosition(skeleton_animation_node_->getPosition());

    if (health_bar_widget_ && health_bar_bg_widget_)
    {
      float health_percent = 100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax);
      health_bar_widget_->setPercent(health_percent);
      health_bar_bg_widget_->setPercent(health_percent);
    }

    //update guard_area
    if (guard_area_layer_)
    {
      if (guard_area_left_time_ > 0)
      {
        guard_area_left_time_ -= delta_time;
      }
      else 
      {
        RemoveGuardArea();
      }
    }

    //update color shader
    if (program_shader_color_)
    {
      if (shader_color_left_time_ > 0) 
      {
        shader_color_left_time_ -= delta_time;
        taomee::shader::ProgramChangeColor* program_shader_color = (taomee::shader::ProgramChangeColor*)program_shader_color_;
        float time_progress = shader_color_left_time_ / shader_color_total_time_ * 2.0; //0 ~ 1 opacity++, 1 ~ 2 opacity--
        float color_opacity = (time_progress <= 1 ? time_progress : 2 - time_progress);
        program_shader_color->SetTime(color_opacity);
      }
      else 
      {
        RemoveColorShader();
      }
    }

    //debug info
    if (label_debug_info_widget_)
    {
      cocos2d::CCPoint position = skeleton_animation_node_->getPosition();
      cocos2d::CCPoint grid = GetGridFromPosition(position);

      char debug_info[1024];  //please don't overflow
      sprintf(debug_info, " ID:%ld CID:%ld \n HP:%d%% EN:%d%% \n [%d,%d] [%d,%d]", 
        actor_->GetActorId(), 
        actor_->GetActorData()->GetActorStatus(kActorStatusCardId), 
        int(100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeHealthMax)),
        int(100.0f * actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyCurrent) / actor_->GetActorData()->GetActorAttribute(kActorAttributeEnergyMax)),
        int(position.x), int(position.y),
        int(grid.x), int(grid.y));
      label_debug_info_widget_->setText(debug_info);
    }
  }


  void ActorAnimation::ChangeSkeletonAnimation(
    const std::string animation_name, 
    const int cycle_count/* = -1 */, 
    const float speed/* = 1.0f */)
  {
    //check first
    if (animation_name == "" || skeleton_animation_node_->existedAnimationName(animation_name) == false)
    {
      printf("[ActorAnimation][ChangeSkeletonAnimation] failed to change to <%s>", animation_name.c_str());
      assert(false);
      return;
    }

    //check again
    std::string current_animation_name = skeleton_animation_node_->GetArmatureNode()->getAnimation()->getCurrentMovementID();
    if (cycle_count != -1 || current_animation_name != animation_name) 
    {
      skeleton_animation_node_->Play(animation_name, cycle_count, speed);
    }
  }



  bool ActorAnimation::IsPointInAnimation(cocos2d::CCPoint position)
  {
    return skeleton_animation_node_ ? GetSkeletonAnimationBox().containsPoint(position) : false;
  }



  cocos2d::CCRect ActorAnimation::GetSkeletonAnimationBox()
  {
    cocos2d::CCPoint skeleton_animation_position = skeleton_animation_node_->getPosition();

    return cocos2d::CCRect(
      skeleton_animation_box_origin_offset_.x + skeleton_animation_position.x, 
      skeleton_animation_box_origin_offset_.y + skeleton_animation_position.y, 
      skeleton_animation_box_size_.width, skeleton_animation_box_size_.height);
  }


  void ActorAnimation::SetBottomLayerSyncNode(cocos2d::CCNode* bottom_layer_sync_node)
  {
    if (bottom_layer_sync_node_) bottom_layer_sync_node_->removeFromParentAndCleanup(true);

    bottom_layer_sync_node_ = bottom_layer_sync_node;
  }




  void ActorAnimation::DeadAnimation(std::string animation_name)
  {
    skeleton_animation_node_->FadeOutShadow();
    overhead_layer_->setVisible(false);
    skeleton_animation_node_->GetBodyNode()->runAction(cocos2d::CCFadeOut::create(ACTOR_CONTROL_COUNTDOWN_DEAD));

    ChangeSkeletonAnimation(animation_name);
  }



  cocos2d::CCLayer* ActorAnimation::CreateGuardArea(bool is_circle_area)
  {
    cocos2d::CCLayer* guard_area_layer = new cocos2d::CCLayer;
    guard_area_layer->autorelease();

    float actor_radius_x = actor_->GetAnimation()->GetSkeletonAnimationBox().size.width * 0.5;
    float actor_radius_y = actor_->GetAnimation()->GetSkeletonAnimationBox().size.height * 0.5;


    if (is_circle_area)
    {
      CCSprite* sprite = CCSprite::createWithSpriteFrameName(ACTOR_GUARD_AREA_TEXTURE_NAME_CIRCLE.c_str());
      sprite->setAnchorPoint(ccp(0.5f, 0.5f));

      int tile_radius = actor_->GetActorData()->GetActorAttribute(kActorAttributeGuardAreaRadius);
      tile_radius = tile_radius > 0 ? tile_radius : actor_radius_x;
      float texture_width = sprite->getContentSize().width;
      float scale = 2 * tile_radius / texture_width;
      sprite->setScaleX(scale);
      sprite->setScaleY(scale * actor_radius_y / actor_radius_x);

      guard_area_layer->addChild(sprite);
    }
    else
    {
      CCScale9Sprite* sprite = CCScale9Sprite::createWithSpriteFrameName(ACTOR_GUARD_AREA_TEXTURE_NAME_BOX.c_str());
      sprite->setInsetBottom(40);
      sprite->setInsetLeft(40);
      sprite->setInsetRight(40);
      sprite->setInsetTop(40);

      int tile_width = actor_->GetActorData()->GetActorAttribute(kActorAttributeGuardAreaWidth);
      int tile_height = actor_->GetActorData()->GetActorAttribute(kActorAttributeGuardAreaHeight);
      float width = tile_width;
      float height = tile_height;
      sprite->setPreferredSize(CCSizeMake(width, height));
      sprite->setAnchorPoint(ccp(0.5f, 0.5f));

      guard_area_layer->addChild(sprite);
    }

    return guard_area_layer;
  }


  void ActorAnimation::StartGuardArea(float last_time)
  {
    guard_area_left_time_ = last_time;
    if (!guard_area_layer_ && bottom_layer_sync_node_)
    {
      bool is_circle_area;
      switch (actor_->GetActorData()->GetActorStatus(kActorStatusGuardAreaType))
      {
      case kActorPredefinedGuardTriggerMeleeCircle:
        is_circle_area = true;
        break;
      case kActorPredefinedGuardTriggerRangedRect:
      case kActorPredefinedGuardTriggerMeleeRect:
        is_circle_area = false;
        break;
      default:
        assert(false);
        return;
        break;
      }

      guard_area_layer_ = CreateGuardArea(is_circle_area);
      bottom_layer_sync_node_->addChild(guard_area_layer_);
    }
  }

  void ActorAnimation::RemoveGuardArea()
  {
    if (guard_area_layer_)
    {
      guard_area_layer_->runAction(CCSequence::create(CCDelayTime::create(0.5f), CCRemoveSelf::create(), NULL));
      guard_area_layer_ = NULL;
    }
  }



  void ActorAnimation::SetColorShader(cocos2d::ccColor4F shader_color, float last_time)
  {
    shader_color_total_time_ = last_time;
    shader_color_left_time_ = last_time;
    if (!program_shader_color_ && skeleton_animation_node_)
    {
      taomee::shader::ProgramChangeColor* program_shader_color = (taomee::shader::ProgramChangeColor*)taomee::shader::ShaderManager::GetInstance()->GetShaderWithType(taomee::shader::kShaderChangeColorTime);
      program_shader_color_ = program_shader_color;
      shader_color_ = shader_color;

      program_shader_color->SetTime(0.0f);
      program_shader_color->SetColor(shader_color);
      taomee::shader::SetAllNodeWithShader(skeleton_animation_node_->GetBodyNode(), program_shader_color);
    }
  }


  void ActorAnimation::RemoveColorShader()
  {
    if (program_shader_color_)
    {
      program_shader_color_ = NULL; //first clear color shader
      SetStatusShader(shader_type_);  //then reset shader to status shader
    }
  }


  void ActorAnimation::SetStatusShader(uint_32 shader_type)
  {
    shader_type_ = shader_type;
    
    if (!program_shader_color_ && skeleton_animation_node_)
    {
      taomee::shader::SetAllNodeWithShaderType(skeleton_animation_node_->GetBodyNode(), (taomee::shader::eShaderType)shader_type_);
    }
  }

  //ActorAnimation

} // namespace actor