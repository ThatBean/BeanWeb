#!/bin/bash

## or call explicitly

## svn permission problem
chmod +x ./build_process/build_bash_script/*

echo "*************************** Pre - Build ***************************"

if [ "$ANDROID_CM_STORE_SWITCH" != "[CHOOSE ONE BELOW]" ]; then
	echo "** Android CM Store Version Switch **"
	node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/assets $ANDROID_CM_STORE_SWITCH
	node ./node_script/version_file.js ./node_script/version_file_config_android_cm.json ../project/android_channel/liebao/jni $ANDROID_CM_STORE_SWITCH
fi

echo "*************************** Start Build ***************************"

cd ./node_script/
node job_command.js job_command_config.json