#!/usr/bin/python
#coding:utf-8 

import subprocess


##--------------------------------------------------------------------------------------
def RunShellCommmand (cmd_string):
	output_string = ""
	
	try:
		output_string = subprocess.check_output(cmd_string, shell = True, stderr = subprocess.STDOUT, universal_newlines = True)
		
	except subprocess.CalledProcessError as error_data:
		output_string = "[subprocess.CalledProcessError] Error Message: " + "\n"
		output_string += "-- returncode  : " + str(error_data.returncode) + "\n"
		output_string += "-- cmd         : " + str(error_data.cmd) + "\n"
		output_string += "-- output      : " + str(error_data.output) + "\n"
		print(output_string)
		exit(1)
	
	return output_string


##--------------------------------------------------------------------------------------	


if __name__ == "__main__":
	import sys
	self_module_name = sys.argv[0].split(".")[0]
	print('''
#Run Shell Command#
run Cmd or Bash shell command and return output in string

Usage:
	import %s
	output_string = %s.RunShellCommmand("echo 123")
	print(output_string)
	''' % (self_module_name, self_module_name))