#!/usr/bin/python
#coding:utf-8 

import json
import os
import re


##--------------------------------------------------------------------------------------
class JSONFileReader:
	##--------------------------------------------------------------------------------------
	def __init__(self):
		self.comment_line_regexp_obj = re.compile(r"^[\t ]*\/\/")
		
	##--------------------------------------------------------------------------------------
	def write_file(self, file_name, loaded_obj):
		if (not os.path.isfile(file_name)):
			print("[error] not a file!", file_name)
			exit(1)
		else:
			self._save_json(file_name, loaded_obj)
			return
	
	##--------------------------------------------------------------------------------------
	def _save_json(self, file_name, loaded_obj):
		serialized_obj = json.dumps(loaded_obj, indent = 4)
		
		file = open(file_name, 'w')
		file.write(serialized_obj)
		file.close()

	##--------------------------------------------------------------------------------------
	def read_file(self, file_name):
		if (not os.path.isfile(file_name)):
			print("[error] not a file!", file_name)
			exit(1)
		else:
			res_string = self._get_json_string(file_name)
			loaded_obj = json.loads(res_string)
			return loaded_obj
	
	##--------------------------------------------------------------------------------------
	def _get_json_string(self, file_name):
		line_array = []
		comment_line_regexp_obj = self.comment_line_regexp_obj
		
		file = open(file_name, 'r')
		
		#parse lines
		for line in file:
			if (line and len(line) > 0):
				if (comment_line_regexp_obj.match(line)):
					pass
				else:
					line_array.append(line)
		
		file.close()
		
		#array to string
		if (len(line_array) > 0):
			res_string = "\n".join([str(i) for i in line_array])
			
			#print("[_get_json_string][result]")
			#print(res_string)
			
			return res_string
		else:
			return None

##--------------------------------------------------------------------------------------	


if __name__ == "__main__":
	import sys
	self_module_name = sys.argv[0].split(".")[0]
	print('''
#JSON File Reader#
load json formatted file, will skip commented lines ("//")
will return python object, or None

Usage:
	import %s
	jfr = %s.JSONFileReader()
	print(jfr.read_file("config.json"))
	''' % (self_module_name, self_module_name))