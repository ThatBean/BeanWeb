#!/usr/bin/python
#coding:utf-8 

import os
import sys

import env_info
import run_shell_command
#import JSON_file_reader

def _print_log_kv (key, value):
	print("-- " + key + ":", value)
	

def _push_to_env_by_key(version_pack, key):
	if (key in version_pack):
		value = version_pack[key]
		env_info.SetEnvInfo(key, value)
		_print_log_kv("added to env <" + key + ">", value)
	else:
		print("[Error] get version key failed:", key)
		exit(1)


def _push_to_env(env_pack):
	for key in env_pack:
		_push_to_env_by_key(env_pack, key)



'''
#deprecated(needed before)
	PLATFORM
	
#melted(combined)
	PATH_WORKSPACE
	STRING_LANGUAGE_VERSION
	
	STRING_PRODUCT_NAME
	PATH_RELATIVE_PROJECT
	
	STRING_VERSION_CURRENT_DEVELOPMENT
	STRING_VERSION_CODE_ANDROID
	STRING_VERSION_CURRENT_BUILD
'''

android_target_list = {
	"TARGET_DEBUG" : "android",
	"TARGET_RELEASE" : "android",
	"TARGET_SDK_CM_RELEASE" : "android_channel/liebao",
}

android_target_abbr_list = {
	"TARGET_DEBUG" : "DBG",
	"TARGET_RELEASE" : "REL",
	"TARGET_SDK_CM_RELEASE" : "CM",
}

def _get_android_env_pack(task_pack):
	platform_env_pack = {}
	
	platform_env_pack["PATH_PROJECT"] = os.path.normpath(os.path.join(task_pack["PATH_WORKSPACE"], task_pack["PATH_RELATIVE_PROJECT"], android_target_list[task_pack["STRING_BUILD_TARGET"]]))
	platform_env_pack["PATH_PRODUCT_VERSION_SPECIFIC"] = os.path.normpath(os.path.join(task_pack["PATH_PRODUCT"], "android", task_pack["STRING_LANGUAGE_VERSION"], "develop", task_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]))
	platform_env_pack["PATH_NDK_MODULE_0"] = os.path.normpath(os.path.join(task_pack["PATH_WORKSPACE"]))
	platform_env_pack["PATH_NDK_MODULE_1"] = os.path.normpath(os.path.join(task_pack["PATH_WORKSPACE"], "../common"))
	platform_env_pack["PATH_NDK_MODULE_2"] = os.path.normpath(os.path.join(task_pack["PATH_WORKSPACE"], "../common/cocos2dx"))
	platform_env_pack["PATH_NDK_MODULE_3"] = os.path.normpath(os.path.join(task_pack["PATH_WORKSPACE"], "../common/cocos2dx/cocos2dx/platform/third_party/android/prebuilt"))
	
	platform_env_pack["FILE_VERSION_CONFIG"] = os.path.normpath(os.path.join(platform_env_pack["PATH_PROJECT"], "ant.properties"))
	platform_env_pack["FILE_MANIFEST"] = os.path.normpath(os.path.join(platform_env_pack["PATH_PROJECT"], "AndroidManifest.xml"))
	
	platform_env_pack["STRING_PRODUCT_NAME"] = android_target_abbr_list[task_pack["STRING_BUILD_TARGET"]] + "_" + task_pack["STRING_VERSION_CURRENT_BUILD"] + "_" + task_pack["STRING_PRODUCT_NAME"] + "_" + task_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]
	platform_env_pack["STRING_VERSION_NAME"] = task_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]
	platform_env_pack["STRING_VERSION_CODE"] = task_pack["STRING_VERSION_CODE_ANDROID"]
	
	return platform_env_pack


xcode_target_list = {
	"TARGET_DEBUG" : "ChainChronicle",
	"TARGET_RELEASE" : "ChainChronicle",
	"TARGET_SDK_PP_RELEASE" : "ChainChronicle_PP",
	"TARGET_SDK_91_RELEASE" : "ChainChronicle_ns91",
	"TARGET_SDK_XY_RELEASE" : "ChainChronicle_xy",
	"TARGET_SDK_TBT_RELEASE" : "ChainChronicle_TB",
}

xcode_target_abbr_list = {
	"TARGET_DEBUG" : "debug",
	"TARGET_RELEASE" : "release",
	"TARGET_SDK_PP_RELEASE" : "PP",
	"TARGET_SDK_91_RELEASE" : "91",
	"TARGET_SDK_XY_RELEASE" : "XY",
	"TARGET_SDK_TBT_RELEASE" : "TB",
}

def _get_ios_env_pack(task_pack):
	platform_env_pack = {}
	
	platform_env_pack["PATH_PROJECT"] = os.path.normpath(os.path.join(task_pack["PATH_WORKSPACE"], task_pack["PATH_RELATIVE_PROJECT"], "ios"))
	platform_env_pack["PATH_PRODUCT_VERSION_SPECIFIC"] = os.path.normpath(os.path.join(task_pack["PATH_PRODUCT"], "ios", task_pack["STRING_LANGUAGE_VERSION"], "develop", task_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]))
	
	platform_env_pack["STRING_VERSION_NAME"] = task_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]
	platform_env_pack["STRING_KEYCHAIN_PASSWORD"] = task_pack["STRING_KEYCHAIN_PASSWORD"]
	platform_env_pack["STRING_XCODE_CONFIGURATION"] = task_pack["STRING_XCODE_CONFIGURATION"]
	platform_env_pack["STRING_XCODE_SDK"] = task_pack["STRING_XCODE_SDK"]
	platform_env_pack["STRING_XCODE_TARGET_NAME"] = xcode_target_list[task_pack["STRING_BUILD_TARGET"]]
	platform_env_pack["STRING_PRODUCT_NAME"] = xcode_target_abbr_list[task_pack["STRING_BUILD_TARGET"]] + "_" +task_pack["STRING_VERSION_CURRENT_BUILD"] + "_" + task_pack["STRING_PRODUCT_NAME"] + "_" + platform_env_pack["STRING_XCODE_CONFIGURATION"] + "_" + task_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]
	
	return platform_env_pack


def ExecuteBuild(task_pack):
	build_target = task_pack["STRING_BUILD_TARGET"]
	build_platform = task_pack["STRING_BUILD_PLATFORM"]
	
	platform_env_pack = None
	if (build_platform == "PLATFORM_ANDROID"):
		platform_env_pack = _get_android_env_pack(task_pack)
	if (build_platform == "PLATFORM_IOS"):
		platform_env_pack = _get_ios_env_pack(task_pack)
	
	#_push_to_env(task_pack)
	_push_to_env(platform_env_pack)
	
	sys.stdout.flush()
	
	#execute build script
	if (not int(env_info.GetEnvInfo("DEBUG_SKIP_BUILD"))):
		if (sys.platform.startswith('linux') or sys.platform.startswith('darwin')):
			if (build_platform == "PLATFORM_ANDROID"):
				print(run_shell_command.RunShellCommmand("./build_bash_script/build_android.sh"))
			if (build_platform == "PLATFORM_IOS"):
				print(run_shell_command.RunShellCommmand("./build_bash_script/build_ios.sh"))
		else:
			print("[Error] Build scripts need Linux/Unix BASH!")
			print(run_shell_command.RunShellCommmand("echo PATH_PROJECT"))
			print(run_shell_command.RunShellCommmand("echo %PATH_PROJECT%"))
			#exit(1)
	else:
		print("[Skipped] DEBUG_SKIP_BUILD found, Build skipped...")