#!/usr/bin/python
#coding:utf-8 
import sys
import re

import env_info
import JSON_file_reader
import run_shell_command

def _get_version_string(version_pack):
	version_sub_string_1 = version_pack["STRING_VERSION_CURRENT_DEVELOPMENT"]
	version_sub_string_2 = version_pack["STRING_VERSION_CURRENT_BUILD"]
	
	#get svn revision
	if (sys.platform.startswith('linux') or sys.platform.startswith('darwin')):
		svn_revision_string = run_shell_command.RunShellCommmand("svn info|grep vision")
		
		version_sub_string_2 = re.findall(r"[^\d]*(\d+)", svn_revision_string)[0]
		version_pack["STRING_VERSION_CURRENT_BUILD"] = version_sub_string_2
		
		print("Get <SVN_REVISION> as <STRING_VERSION_CURRENT_BUILD> success!")
		print("  <SVN_REVISION> :", svn_revision_string)
		print("  <STRING_VERSION_CURRENT_BUILD>:", version_sub_string_2)
	else:
		print("[Error] Get SVN revision need Linux/Unix BASH!")
		#exit(1)
	
	if (version_sub_string_1 and version_sub_string_2):
		version_string = version_sub_string_1 + "." + version_sub_string_2
		version_pack["__VERSION_STRING"] = version_string
		
		print("-- Version string:", version_string)
	else:
		print("[Error] can't get version string")
		exit(1)

	
def ProcessBuildVersion(version_file_name):
	version_pack = JSON_file_reader.JSONFileReader().read_file(version_file_name)
	
	if (version_pack):
		_get_version_string(version_pack)
		JSON_file_reader.JSONFileReader().write_file(version_file_name, version_pack)
		
		if (sys.platform.startswith('linux') or sys.platform.startswith('darwin')):
			print("update version file:", version_file_name)
			print(run_shell_command.RunShellCommmand("svn commit " + version_file_name + " -m \"update version file\""))
		else:
			print("[Error] SVN need Linux/Unix BASH!")
			#exit(1)
		
		return version_pack
	else:
		print("[Error] can't open version file:", version_file_name)
		exit(1)