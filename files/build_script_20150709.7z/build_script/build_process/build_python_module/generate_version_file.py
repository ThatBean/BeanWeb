#!/usr/bin/python
#coding:utf-8 

import sys

import run_shell_command
import env_info

def GenerateVersionFile(version_string, lua_version_file_path):
	version_file = open(lua_version_file_path, "w")
	
	version_file.write("function GetDebugVersion()\n")
	version_file.write("  return \"" + version_string + "\" \n")
	version_file.write("end")
	
	version_file.close()
	
	print("Generated version file:", lua_version_file_path)
	
	if (sys.platform.startswith('linux') or sys.platform.startswith('darwin')):
		print(run_shell_command.RunShellCommmand("svn commit " + lua_version_file_path + " -m \"update version number\""))
	else:
		print("[Error] SVN need Linux/Unix BASH!")
		#exit(1)
	
	print("Finished commit file modification to SVN")