#!/usr/bin/python
#coding:utf-8 

import os
import sys

#add python module path
sys.path.append("./python_module")
import JSON_file_reader
#import run_shell_command
import env_info

#add build module path
sys.path.append("./build_python_module")
import process_build_version
import process_build_target
import process_build_platform
import generate_version_file
import execute_build


def _print_log_kv (key, value):
	print("-- " + key + ":", value)


def _combine_pack (base_pack, append_pack):
	if (None == base_pack):
		print("[Error] Nine base pack")
		exit(1)
	
	if (len(append_pack) > 0):
		#combine config
		for key in append_pack:
			base_pack[key] = append_pack[key]
	else:
		print("[Error] empty append pack")
		exit(1)
	
	return base_pack


def _combine_config_pack_file (pack_file_name_list):
	config_pack = {}
	
	if (len(pack_file_name_list) > 1):
		#combine config
		for index in range(1, len(pack_file_name_list)):
			json_config_file_name = pack_file_name_list[index]
			append_config_pack = JSON_file_reader.JSONFileReader().read_file(json_config_file_name)
			_combine_pack(config_pack, append_config_pack)
			print("<added pack>", json_config_file_name)
			
		print("[result pack]")
		print(config_pack)
	else:
		print("[Error] empty pack list")
		exit(1)
	
	return config_pack
	

if (__name__ != "__main__"):
	self_module_name = sys.argv[0].split(".")[0]
	print('''
	#Start Build#
	Should be run as "__main__"

	Usage:
		python %s <target config json> <target config extension json> <target config extension json> ..
	''' % (self_module_name))
	exit(1)

else:
	build_config_pack = {}
	
	if (sys.platform.startswith('win')):
		##debug use
		print("[Warning] debug use added Env Info")
		env_info.SetEnvInfo("WORKSPACE", "../build/")
		env_info.SetEnvInfo("LANGUAGE_VERSION", "ago")
	
	
	#get workspace path
	path_workspace = env_info.GetEnvInfo("WORKSPACE")
	build_config_pack["PATH_WORKSPACE"] = path_workspace
	string_language_version = env_info.GetEnvInfo("LANGUAGE_VERSION")
	build_config_pack["STRING_LANGUAGE_VERSION"] = string_language_version
	
	#read config file from input
	env_build_config_ext = env_info.GetEnvInfo("BUILD_CONFIG_EXT")
	config_pack = {}
	if (env_build_config_ext):
		temp_pack_file_name_list = list(sys.argv)
		temp_pack_file_name_list.append(env_build_config_ext)
		config_pack = _combine_config_pack_file(temp_pack_file_name_list)
	else:
		config_pack = _combine_config_pack_file(sys.argv)
	
	_combine_pack(build_config_pack, config_pack)
	_print_log_kv("Build task list", config_pack["LIST_BUILD_TASK"])
	_print_log_kv("Version file", config_pack["FILE_BUILD_VERSION"])
	
	if (env_info.GetEnvInfo("OVERWRITE_PRODUCT_NAME")):
		build_config_pack["STRING_PRODUCT_NAME"] = env_info.GetEnvInfo("OVERWRITE_PRODUCT_NAME")
	else:
		print("[Skipped] OVERWRITE_PRODUCT_NAME skipped replace product name...")
	
	#process build version
	version_file_name = config_pack["FILE_BUILD_VERSION"]
	version_pack = process_build_version.ProcessBuildVersion(version_file_name)
	
	if (int(env_info.GetEnvInfo("ANDROID_BUILD_VERSION_CODE")) != -1):
		version_pack["STRING_VERSION_CODE_ANDROID"] = int(env_info.GetEnvInfo("ANDROID_BUILD_VERSION_CODE"))
	else:
		print("Use STRING_VERSION_CODE_ANDROID from file:", version_pack["STRING_VERSION_CODE_ANDROID"])
		
	_combine_pack(build_config_pack, version_pack)
	
	#generate version file
	version_string = build_config_pack["__VERSION_STRING"]
	lua_version_file_path = os.path.join(build_config_pack["PATH_WORKSPACE"], build_config_pack["FILE_RELATIVE_LUA_DEBUG_VERSION"])
	
	if (int(env_info.GetEnvInfo("IS_GENERATE_VERSION_FILE"))):
		generate_version_file.GenerateVersionFile(version_string, lua_version_file_path)
	else:
		print("[Skipped] IS_GENERATE_VERSION_FILE = 0, skipped generate version file...")
	
	for build_task_pack in config_pack["LIST_BUILD_TASK"]:
		print("start build task:", build_task_pack)
		
		#copy env config
		task_pack = {}
		_combine_pack(task_pack, build_config_pack)
		
		#process build target
		build_target = build_task_pack["TARGET"]
		string_build_target = process_build_target.ProcessBuildTarget(build_target)
		task_pack["STRING_BUILD_TARGET"] = string_build_target
		
		#process build version
		build_platform = build_task_pack["PLATFORM"]
		string_build_platform = process_build_platform.ProcessBuildPlatform(build_platform)
		task_pack["STRING_BUILD_PLATFORM"] = string_build_platform
		
		#execute build
		execute_build.ExecuteBuild(task_pack)
		##print(task_pack)