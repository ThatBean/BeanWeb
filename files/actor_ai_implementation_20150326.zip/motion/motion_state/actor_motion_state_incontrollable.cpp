#include "actor_motion_state_incontrollable.h"

#include "game/actor/actor.h"

#include "game/actor/motion/actor_motion_animation_operation.h"

namespace actor {

  const int MotionStateIncontrollable::STATE_TYPE = kActorMotionStateIncontrollable;

  MotionStateIncontrollable* MotionStateIncontrollable::Instance()
  {
    static MotionStateIncontrollable instance;
    return &instance;
  }

  void MotionStateIncontrollable::OnEnter(Actor* actor)
  {
    //should assist buff system to adjust actor animation
    switch (actor->GetActorData()->GetControlData()->GetIncontrollable())
    {
    case kActorControlIncontrollableBuff:
      
      break;
    case kActorControlIncontrollableSkill:
      //should check
      break;
    case kActorControlIncontrollableScript:
      //for future?
      break;
    case kActorControlIncontrollable:
    default:
      break;
    }

    CheckBuffForAnimationEffect(actor);  //change actor animation according to buff data

    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(false);
  }

  void MotionStateIncontrollable::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);
  }

  void MotionStateIncontrollable::Update(Actor* actor, float delta_time)
  {
    ChangeAnimation(actor, taomee::army::kUnitAnimationIdle);

    //Give Motion control to Buff system
    if (actor->GetActorData()->GetBuffData()->GetIsIncontrollableFinished())
    {
      //back to idle
      actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);
    }
  }

} // namespace actor