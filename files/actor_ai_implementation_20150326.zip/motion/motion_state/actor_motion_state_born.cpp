#include "actor_motion_state_born.h"

#include "game/actor/actor.h"

#include "game/actor/motion/actor_motion_animation_operation.h"

namespace actor {

  const int MotionStateBorn::STATE_TYPE = kActorMotionStateBorn;

  MotionStateBorn* MotionStateBorn::Instance()
  {
    static MotionStateBorn instance;
    return &instance;
  }


  void MotionStateBorn::OnEnter(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(false);
    //ChangeAnimation(actor, taomee::army::kUnitAnimationIdle); //currently no animation
    ChangeAnimation(actor, taomee::army::kUnitAnimationIdle);
  }

  void MotionStateBorn::OnExit(Actor* actor)
  {
    actor->GetActorData()->GetMotionData()->SetIsMotionAnimationEnded(true);

  }

  void MotionStateBorn::Update(Actor* actor, float delta_time)
  {
  }

} // namespace actor