﻿#include "actor_motion_state_machine.h"

#include "game/actor/actor.h"

namespace actor {

  eActorMotionState MotionStateMachine::GetCurrentMotionStateType()
  {
    if (current_state_)
    {
      return eActorMotionState(current_state_->GetStateType());
    }
    return kActorMotionState;
  }


  void MotionStateMachine::Update(float delta_time)
  { 
    if (current_state_) 
      current_state_->Update(entity_, delta_time); 
  }

  void MotionStateMachine::ChangeState(State<Actor>* next_state)
  {
    Actor* actor = entity_;
    actor->GetActorData()->AddLogF(
      "[MotionStateMachine][ChangeState] %d -> %d", 
      current_state_ ? current_state_->GetStateType() : -1, 
      next_state ? next_state->GetStateType() : -1);

    last_state_ = current_state_;
    if (last_state_) 
      last_state_->OnExit(entity_);

    current_state_ = next_state;
    if (current_state_) 
      current_state_->OnEnter(entity_);
  }

} // namespace actor