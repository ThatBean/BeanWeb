﻿#include "actor_motion_animation_operation.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  //private method
  taomee::SkeletonAnimation* GetActorAnimationNode(Actor* actor)
  {
    taomee::SkeletonAnimation* actor_animation_node = actor->GetActorData()->GetMotionData()->GetAnimationNode();

    assert(actor_animation_node);

    return actor_animation_node;
  }

  void CheckAndCacheMoveToPosition(Actor* actor, cocos2d::CCPoint target_position)
  {
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    taomee::SkeletonAnimation* actor_animation_node = GetActorAnimationNode(actor);
    bool is_change_direction = false;

    //check if target_position cached
    if (motion_data->GetIsCachedPosition() == false
      || motion_data->GetCachedTargetPosition().equals(target_position) == false)
    {
      motion_data->SetCachedTargetPosition(target_position);

      cocos2d::CCPoint move_speed_vector = ccpSub(target_position, motion_data->GetPosition()).normalize();
      move_speed_vector.x *= motion_data->GetMoveSpeedBase();
      move_speed_vector.y *= motion_data->GetMoveSpeedBase();

      motion_data->SetCachedMoveSpeedVector(move_speed_vector);

      //check if direction change
      is_change_direction = abs(motion_data->GetPosition().x - target_position.x) >= ACTOR_DIRECTION_CHANGE_THRESHOLD;

      //change direction
      if (is_change_direction)
      {
        if (target_position.x > motion_data->GetPosition().x)
          motion_data->SetAnimationDirection(kActorAnimationDirectionRight);
        else
          motion_data->SetAnimationDirection(kActorAnimationDirectionLeft);
      }
    }
  }
  //private method


  //public method

  void ChangeAnimation(Actor* actor, const std::string animation_name, const int cycle_count/* = -1 */, const float speed/* = 1.0f */)
  {
    taomee::SkeletonAnimation* actor_animation_node = GetActorAnimationNode(actor);

    if (cycle_count != -1 || actor->GetActorData()->GetMotionData()->GetCurrentAnimationName() != animation_name)
      actor_animation_node->Play(animation_name, cycle_count, speed);
    else 
      assert(false);
  }


  void ResetAnimationDirection(Actor* actor)
  {
    actor->GetActorData()->AddLog("[ResetAnimationDirection]");
    actor->GetActorData()->GetMotionData()->ResetAnimationDirection();
  }


  void SetAnimationPosition(Actor* actor, cocos2d::CCPoint position, bool is_change_direction/* = true*/)
  {
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    cocos2d::CCPoint actor_position = actor->GetActorData()->GetMotionData()->GetPosition();
    
    if (actor->GetActorData()->GetSpecifiedData()->IsPositionValid(position) == false
      && actor->GetActorData()->GetSpecifiedData()->IsPositionValid(actor_position) == true) //check position, only moving out of box is blocked
    {
      actor->GetActorData()->AddLogF("[actor_motion_animation_operation][SetAnimationPosition] moving out of box is blocked (%f, %f)", position.x, position.y);
      actor->GetActorData()->GetControlData()->ResetTarget();
      actor->GetActorData()->GetControlData()->ResetPosition();
      CommonCheckGridPosition(actor);
//       if (actor->GetActorData()->GetControlData()->IsSetPosition())
//         actor->GetActorData()->GetControlData()->SetPosition(actor->GetActorData()->GetSpecifiedData()->PositionCorrection(actor->GetActorData()->GetControlData()->GetPosition()));
//       
//       if (actor->GetActorData()->GetControlData()->IsSetTarget())
//       {
//         Actor* target = actor->GetActorExtEnv()->GetActorById(actor->GetActorData()->GetControlData()->GetTarget());
//         if (target->GetIsActorActive() && target->GetActorData()->GetBasicData()->GetIsDeadStatus() == false)
//           actor->GetActorData()->GetControlData()->SetPosition(
//             actor->GetActorData()->GetSpecifiedData()->PositionCorrection(
//               target->GetActorData()->GetMotionData()->GetPosition()));
//         else
//           actor->GetActorData()->GetControlData()->ResetTarget();
//       }

      return;
    }

    //change direction
    if (is_change_direction)
    {
      actor->GetActorData()->AddLog("[SetAnimationPosition] change direction");
      if (position.x > actor_position.x)
        motion_data->SetAnimationDirection(kActorAnimationDirectionRight);
      else
        motion_data->SetAnimationDirection(kActorAnimationDirectionLeft);
    }

    //set direction
    actor->GetActorData()->GetMotionData()->SetPosition(position);
  }


  void UpdateMoveToPositionCached(Actor* actor, cocos2d::CCPoint target_position, float delta_time, float move_speed_modifier/* = 1.0f*/)
  {
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    bool is_change_direction = false;

    //check if needed to cache
    CheckAndCacheMoveToPosition(actor, target_position);

    //need move?
    //reduce enemy's speed and show warning
    if (actor->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserOppose 
      && GetIsActorExtEnvArena() == false)
    {
      if (motion_data->GetPosition().x > taomee::battle::kMapRightMostX * 0.5)
      {
        move_speed_modifier *= 0.5;
        if (motion_data->GetPosition().x > taomee::battle::kMapRightMostX * 0.6)
          LuaTinkerManager::GetInstance().CallLuaFunc<int>("script/ui/WarningUI.lua", "AutoExtendWarningUIToBattleScene");
      }
    }

    //limit
    delta_time = delta_time > 0.1 ? 0.1 : delta_time;

    //delta move
    cocos2d::CCPoint move_delta_vector = ccp(
      motion_data->GetCachedMoveSpeedVector().x * delta_time * move_speed_modifier, 
      motion_data->GetCachedMoveSpeedVector().y * delta_time * move_speed_modifier);

    SetAnimationPosition(actor, ccpAdd(motion_data->GetPosition(), move_delta_vector), is_change_direction);
  }

  //if all the enemy is behind the actor, change the direction.
  void CheckEnemyForBetterDirection(Actor* actor)
  {
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    ActorMotionData* motion_data = actor->GetActorData()->GetMotionData();
    ActorSkillData* skill_data = actor->GetActorData()->GetSkillData();

    float actor_position_x = actor->GetActorData()->GetMotionData()->GetPosition().x;
    bool is_actor_facing_left = (motion_data->GetAnimationDirection() == kActorAnimationDirectionLeft);
    bool is_need_change_direction;

    switch(skill_data->GetSkillTypeById(control_data->GetSkill()))
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
    case kActorAttackPower:
      {
        //check for normal attack, only check target
        ActorTrigger* attack_trigger = skill_data->GetTriggeredAttackTrigger();
        if (!attack_trigger)
        {
          assert(false);
          return;
        }
        attack_trigger->Update();
        if (attack_trigger->GetIsTriggered() == false) return;

        Actor* target_actor = *(attack_trigger->GetTriggeredActorList()->begin());
        bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetMotionData()->GetPosition().x;
        //if the enemy is in front of the actor, don't change the direction (0 | 1 | 0 = false)
        is_need_change_direction = !(is_actor_facing_left == is_enemy_at_left_side);
      }
      break;
    case kActorAttackSpecial:
    case kActorAttackOverload:
      {
        //check for special skill, need check all enemy
        std::list<Actor*>* actor_list = actor->GetActorExtEnv()->GetActorList();
        if (!actor_list || actor_list->size() == 0) return;

        is_need_change_direction = true;
        bool is_enemy_exist = false;

        eActorFactionType actor_faction = actor->GetActorData()->GetBasicData()->GetFactionType();

        std::list<Actor*>::iterator iterator = actor_list->begin();
        while (iterator != actor_list->end())
        {
          Actor* target_actor = *iterator;

          if (target_actor->GetActorData()->GetBasicData()->GetFactionType() != actor_faction)
          {
            bool is_enemy_at_left_side = actor_position_x > target_actor->GetActorData()->GetMotionData()->GetPosition().x;
            //if there is one enemy in front of the actor, don't change the direction (1 & 0 & 1 = false)
            is_need_change_direction &= !(is_actor_facing_left == is_enemy_at_left_side);
            is_enemy_exist = true;
          }
          ++iterator;
        }

        //or no enemy at all
        is_need_change_direction &= is_enemy_exist;
      }
      break;
    case kActorAttack:
    default:
      assert(false);
      break;
    }

    if (is_need_change_direction)
    {
      actor->GetActorData()->AddLogF("[CheckEnemyForBetterDirection] change direction, is_change_to_right:%d", is_actor_facing_left);
      motion_data->SetAnimationDirection(is_actor_facing_left ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);
    }
  }


  void CheckBuffForAnimationEffect(Actor* actor) //change actor animation according to buff data
  {
    //what to do?
  }
  //public method

} // namespace actor