#ifndef ACTOR_ADAPTER_H
#define ACTOR_ADAPTER_H


#include "game/army/unit/move_object.h"
// 
// namespace taomee {
//   namespace army {
//     class MoveObject;
//   }
// }

namespace actor {
  class ActorExtEnv;
  
  typedef taomee::army::MoveObject ActorAdapter;



  //Position & Grid
  cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
  cocos2d::CCPoint GetPositionFromGrid(cocos2d::CCPoint grid_position);

  cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
  int GetGridXFromPositionX(float position_x);
  int GetGridYFromPositionY(float position_y);

  bool IsPositionInGrid(cocos2d::CCPoint position);
  bool IsPositionXInGrid(int position_x);
  bool IsPositionYInGrid(int position_y);
  cocos2d::CCPoint SnapToGrid(cocos2d::CCPoint position);
  cocos2d::CCPoint SnapYToGrid(cocos2d::CCPoint position);


  //Skill
  void ResetSkillAdapter(ActorAdapter* actor_adapter);
  void AddSkillTargetAdapter(ActorAdapter* actor_adapter, int target_id);
  void CommitSkillAdapter(ActorAdapter* actor_adapter, int skill_id, int attack_type);

  void PauseSkillAdapter(ActorAdapter* actor_adapter);
  void ResumeSkillAdapter(ActorAdapter* actor_adapter);

  bool GetIsSkillFinishedAdapter(ActorAdapter* actor_adapter);
  
  bool GetIsSpecialSkillReady(ActorAdapter* actor_adapter);
  float GetSkillCooldown(ActorAdapter* actor_adapter);

  void AutoReleaseSpecialSkill(int actor_id);
  void RandomCrititalHit(ActorAdapter* actor_adapter, Actor* target_actor);
  void ClearCrititalHit(ActorAdapter* actor_adapter);


  //Battle
  bool GetIsAllyActorAuto();
  bool GetIsActorExtEnvBabel();
  bool GetIsActorExtEnvArena();
  ActorExtEnv* GetActorExtEnv();

  //Actor Init & Data
  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter);

  void NastyActorInitAdapter(ActorAdapter* actor_adapter, Actor* actor);
  void NastyActorInitRoutineDataAdapter(ActorAdapter* actor_adapter, Actor* actor);

} // namespace actor


#endif // ACTOR_ADAPTER_H
