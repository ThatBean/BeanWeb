#include "actor_control.h"

#include "game/actor/actor.h"
#include "game/actor/data/actor_data.h"

namespace actor {


  //#####################################################################


  ActorControl::ActorControl(Actor* actor)
    : actor_ (actor),
    actor_control_type_(kActorControl),
    actor_control_routine_(NULL)
  {

  }

  ActorControl::~ActorControl()
  {
    if (actor_control_routine_)
    {
      actor_control_routine_->Clear();
      delete actor_control_routine_;
    }
  }

  void ActorControl::Update(float delta_time)
  {
    if (!actor_control_type_)
    {
      assert(false);
      return;
    }

    if (actor_control_routine_)
      actor_control_routine_->Update(delta_time);

    //update first, this affects state change
    UpdateBuff();

    if (actor_control_type_ & kActorControlAuto) 
    {
      UpdateAuto();
    }
    //if (actor_control_type_ & kActorControlManual) //all the time, auto ai will use this to relase skill
    {
      UpdateManual();
    }
    
    result_logic_state_type_ = DecideLogicState();
    if (ControlLogicStateChange(result_logic_state_type_))
    {
      actor_->GetActorData()->AddLogF(
        "[ActorControl][Update] ControlLogicStateChange PASS result_logic_state_type_:%d control_priority:%d", 
        result_logic_state_type_, 
        actor_->GetActorData()->GetControlData()->GetMaximumControlPriority());
      actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(result_logic_state_type_));
    }
  }

  void ActorControl::UpdateManual()
  {
    ActorControlDataBase* user_control_data = actor_->GetActorData()->GetUserControlData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
    
    ApplyControlData(user_control_data, control_data);
  }

  void ActorControl::UpdateAuto()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    if (control_data->GetIsAutoReleaseSkill())
    {
      UpdateAutoReleaseSkill();
    }

    if (actor_->GetActorData()->GetLogicData()->GetIsStateIdle())
    {
      //check and apply routine control
      if (actor_control_routine_)
      {
        ActorControlDataBase* routine_control_data = actor_control_routine_->GetRoutineControlData();
        ApplyControlData(routine_control_data, control_data);
      }

      if (control_data->GetIsAutoGuard())
      {
        UpdateAutoGuard();
      }
    }
  }

  void ActorControl::UpdateBuff()
  {
    ActorBuffData* buff_data = actor_->GetActorData()->GetBuffData();
    ActorLogicData* logic_data = actor_->GetActorData()->GetLogicData();
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    buff_data->UpdateIncontrollable();

    //check lock
    logic_data->SetIsMoveLock(buff_data->GetIsMoveLock());
    logic_data->SetIsAttackLock(buff_data->GetIsAttackLock());

    //check if incontrollable
    if (buff_data->GetIsIncontrollableFinished() == false)
      control_data->SetIncontrollable(kActorControlIncontrollableBuff, kActorControlPriorityIncontrollable);
    else
      control_data->ResetIncontrollable();
  }



  void ActorControl::UpdateAutoGuard()
  {
    if (actor_->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserSupport
      && GetIsAllyActorAuto() == false)  //user actor auto subject to battle control
    {  
      return;
    }

    //check trigger
    ActorTrigger* guard_trigger = actor_->GetActorData()->GetControlData()->GetGuardTriggerAuto();
    if (guard_trigger)
    {
      guard_trigger->Update();
      if (guard_trigger->GetIsTriggered())
      {
        switch(actor_->GetActorData()->GetControlData()->GetAutoGuardType())
        {
        case kActorControlAutoGuardDefault:
          switch (actor_->GetActorData()->GetBasicData()->GetCareerType())
          {
          case kActorCareerWarrior:
            //for melee character
            UpdateAutoGuardMelee(guard_trigger);
            break;
          case kActorCareerKnight:
            //special for home defenders
            UpdateAutoGuardMeleeX(guard_trigger);
            break;
          case kActorCareerArcher:
          case kActorCareerWizard:
          case kActorCareerPriest:
            //for ranged character
            if (rand() > 0.7f * RAND_MAX)
              UpdateAutoGuardRangedNearestX(guard_trigger);
            else
              UpdateAutoGuardRangedNearestY(guard_trigger);
            break;
          }
          break;
        case kActorControlAutoGuardPreferY:
          switch (actor_->GetActorData()->GetBasicData()->GetCareerType())
          {
          case kActorCareerWarrior:
          case kActorCareerKnight:
            //special for home defenders
            UpdateAutoGuardMeleeY(guard_trigger);
            break;
          case kActorCareerArcher:
          case kActorCareerWizard:
          case kActorCareerPriest:
            //for ranged character
            UpdateAutoGuardRangedNearestY(guard_trigger);
            break;
          }
          break;
        case kActorControlAutoGuard:
        default:
          assert(false);
          break;
        }
      }
    }
  }


  void ActorControl::UpdateAutoReleaseSkill()
  {
    if (actor_->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserSupport
      && GetIsAllyActorAuto() == false)  //user actor auto subject to battle control
    {
      //pass UpdateAutoReleaseSkill
      return;
    }

    ActorControlData* control_data = actor_->GetActorData()->GetControlData();
    ActorSkillData* skill_data = actor_->GetActorData()->GetSkillData();

    switch (control_data->GetAutoReleaseSkillType())
    {
    case kActorControlAutoReleaseSkillNoPause:
      {
        if (skill_data->GetIsSpecialSkillReady() == true
          && actor_->GetActorData()->GetBuffData()->GetIsAttackSpecialLock() == false
          && skill_data->GetSkillIdByType(kActorAttackSpecial) != ACTOR_SKILL_ID_INVALID)
        {
          actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill NoPause PASS SetSkill:%d", skill_data->GetSkillIdByType(kActorAttackSpecial));
          actor_->GetActorData()->GetUserControlData()->SetSkill(skill_data->GetSkillIdByType(kActorAttackSpecial), kActorControlPriorityAttackSpecialAuto);
        }
      }
      break;
    case kActorControlAutoReleaseSkillWithPause:
      {
        if (skill_data->GetIsSpecialSkillReady() == true
          && actor_->GetActorData()->GetBuffData()->GetIsAttackSpecialLock() == false
          && skill_data->GetSkillIdByType(kActorAttackSpecial) != ACTOR_SKILL_ID_INVALID)
        {
          actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill WithPause PASS AutoReleaseSpecialSkill");
          AutoReleaseSpecialSkill(actor_->GetActorId());//more directly
        }
      }
      break;
    case kActorControlAutoReleaseSkillWithProbability:
      {
        if (actor_->GetActorData()->GetLogicData()->GetIsStateIdle()
          && ((rand() % 100) < control_data->GetAutoReleaseSkillProbability() * 100))
        {
          actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill WithProbability PASS SetSkill:%d", skill_data->GetSkillIdByType(kActorAttackSpecial));
          actor_->GetActorData()->GetUserControlData()->SetSkill(skill_data->GetSkillIdByType(kActorAttackSpecial), kActorControlPriorityAttackSpecialAuto);
        }
      }
      break;
    case kActorControlAutoReleaseSkillByAttackCount:
      {
        if (actor_->GetActorData()->GetLogicData()->GetIsStateIdle()
          && ((skill_data->GetActorNormalAttackCount() + skill_data->GetActorPowerAttackCount() + skill_data->GetActorSpecialAttackCount()) % control_data->GetAutoReleaseSkillAttackCount() == (control_data->GetAutoReleaseSkillAttackCount() - 1)))
        {
          actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoReleaseSkill] UpdateAutoReleaseSkill WithProbability PASS SetSkill:%d", skill_data->GetSkillIdByType(kActorAttackSpecial));
          actor_->GetActorData()->GetUserControlData()->SetSkill(skill_data->GetSkillIdByType(kActorAttackSpecial), kActorControlPriorityAttackSpecialAuto);
        }
      }
      break;
    case kActorControlAutoReleaseSkill:
    default:
      assert(false);
      break;
    }
  }

  void ActorControl::UpdateAutoGuardMelee(ActorTrigger* guard_trigger)
  {
    int target_id = *(guard_trigger->GetTriggeredActorIdList()->begin());
    //move to target
    actor_->GetActorData()->GetControlData()->SetTarget(target_id, kActorControlPriorityMoveAuto);

    actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoGuardMelee] target_id:%d", target_id);
  }

  void ActorControl::UpdateAutoGuardMeleeX(ActorTrigger* guard_trigger)
  {
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    int target_id = -1;
    float target_position_x_min = 9999999;
    eActorAnimationDirection home_direction = actor_->GetActorData()->GetSpecifiedData()->GetActorHomeDirection();
    float home_position_x = (home_direction == kActorAnimationDirectionLeft ? 0 : 1500);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetMotionData()->GetPosition();
      if (target_position_x_min > abs(home_position_x - target_position.x))
      {
        target_position_x_min = abs(home_position_x - target_position.x);
        target_id = target_actor->GetActorId();
      }

      ++iterator;
    }

    if (target_id >= 0 && target_position_x_min > 0)
    {
      //move to target
      actor_->GetActorData()->GetControlData()->SetTarget(target_id, kActorControlPriorityMoveAuto);

      actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoGuardMeleeX] target_id:%d", target_id);
    }
  }


  void ActorControl::UpdateAutoGuardMeleeY(ActorTrigger* guard_trigger)
  {
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    int target_id = -1;
    bool has_same_grid_y_target = false;
    float target_distance_min = 9999999;
    cocos2d::CCPoint actor_position = actor_->GetActorData()->GetMotionData()->GetPosition();
    int actor_grid_y= GetGridYFromPositionY(actor_position.y);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetMotionData()->GetPosition();

      float target_distance = actor_position.getDistance(target_position);
      bool is_same_grid_y_target = (GetGridYFromPositionY(target_position.y) == actor_grid_y);

//       if (has_same_grid_y_target)  //has same grid target, search only same grid nearest
//       {
//         if (is_same_grid_y_target && target_distance_min > target_distance)
//         {
//           target_distance_min = target_distance;
//           target_id = target_actor->GetActorId();
//         }
//       }
//       else  //no same grid yet, grid first, then distance
//       {
//         if (is_same_grid_y_target)
//         {
//           target_distance_min = target_distance;
//           target_id = target_actor->GetActorId();
//           has_same_grid_y_target = true;
//         }
//         else if (target_distance_min > target_distance)
//         {
//           target_distance_min = target_distance;
//           target_id = target_actor->GetActorId();
//         }
//       }

      //same logic as above
      if ( (has_same_grid_y_target == false && is_same_grid_y_target == true) //same grid y first, highest priority
        || (has_same_grid_y_target == is_same_grid_y_target && target_distance_min > target_distance) ) //then distance
      {
        target_distance_min = target_distance;
        has_same_grid_y_target = is_same_grid_y_target;
        target_id = target_actor->GetActorId();
      }

      ++iterator;
    }

    if (target_id >= 0 && target_distance_min > 0)
    {
      //move to target
      actor_->GetActorData()->GetControlData()->SetTarget(target_id, kActorControlPriorityMoveAuto);

      actor_->GetActorData()->AddLogF("[ActorControl][UpdateAutoGuardMeleeY] target_id:%d", target_id);
    }
  }

  void ActorControl::UpdateAutoGuardRangedNearestX(ActorTrigger* guard_trigger)
  {
    // -- the grid-y of the closest to home enemy
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    int target_grid_y = -1;
    float target_position_x_min = 9999999;
    eActorAnimationDirection home_direction = actor_->GetActorData()->GetSpecifiedData()->GetActorHomeDirection();
    float home_position_x = (home_direction == kActorAnimationDirectionLeft ? 0 : 1500);

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      cocos2d::CCPoint target_position = target_actor->GetActorData()->GetMotionData()->GetPosition();
      if (target_position_x_min > abs(home_position_x - target_position.x))
      {
        target_position_x_min = abs(home_position_x - target_position.x);
        target_grid_y = GetGridYFromPositionY(target_position.y);
      }

      ++iterator;
    }

    if (target_grid_y > 0 && target_position_x_min > 0)
    {
      bool is_grid_y_valid[GRID_Y_RANGE] = {false, false, false};
      is_grid_y_valid[target_grid_y - 1] = true;
      actor_->GetActorData()->AddLog("[ActorControl][UpdateAutoGuardRangedNearestX]");
      ApplyAutoRangedPosition(is_grid_y_valid);
    }
  }

  void ActorControl::UpdateAutoGuardRangedNearestY(ActorTrigger* guard_trigger)
  {
    // -- the least-moving-possible-grid-y change
    std::list<Actor*>* triggered_actor_list = guard_trigger->GetTriggeredActorList();

    bool is_grid_y_valid[GRID_Y_RANGE] = {false, false, false};

    std::list<Actor*>::iterator iterator = triggered_actor_list->begin();
    while (iterator != triggered_actor_list->end())
    {
      Actor* target_actor = *iterator;
      int target_grid_y = GetGridYFromPositionY(target_actor->GetActorData()->GetMotionData()->GetPosition().y);
      is_grid_y_valid[target_grid_y - 1] = true;
      ++iterator;
    }

    actor_->GetActorData()->AddLog("[ActorControl][UpdateAutoGuardRangedNearestY]");
    ApplyAutoRangedPosition(is_grid_y_valid);
  }

  void ActorControl::ApplyAutoRangedPosition(bool is_grid_y_valid[])  //find the valid position close to home base line
  {
    cocos2d::CCPoint actor_grid = GetGridFromPosition(actor_->GetActorData()->GetMotionData()->GetPosition());
    if (is_grid_y_valid[(int)(actor_grid.y) - 1])
      return; // target and actor already in row

    //set target Grid to home base line
    eActorAnimationDirection actor_home_direction = actor_->GetActorData()->GetSpecifiedData()->GetActorHomeDirection();
    cocos2d::CCPoint target_grid = ccp(actor_home_direction == kActorAnimationDirectionLeft ? GRID_X_RANGE_LEFT : GRID_X_RANGE_RIGHT, actor_grid.y);

    //find best grid (is_grid_y_valid + nearest available)
    bool is_target_grid_position_valid = false;
    float target_grid_distance_min = 99999;
    cocos2d::CCPoint target_grid_position;

    std::list<cocos2d::CCPoint>* valid_grid_list = actor_->GetActorData()->GetSpecifiedData()->GetValidGridList(actor_->GetActorExtEnv()->GetActorGridList());
    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;
        if (is_grid_y_valid[(int)(grid_position.y) - 1])
        {
          float target_grid_distance = grid_position.getDistance(target_grid);
          if (target_grid_distance < target_grid_distance_min)
          {
            is_target_grid_position_valid = true;
            target_grid_distance_min = target_grid_distance;
            target_grid_position = grid_position;
          }
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    //move to grid
    if (is_target_grid_position_valid)
    {
      actor_->GetActorData()->GetControlData()->SetPosition(GetPositionFromGrid(target_grid_position), kActorControlPriorityMoveManual);
      actor_->GetActorExtEnv()->GetActorGridList()->push_back(std::pair<Actor*, cocos2d::CCPoint>(actor_, target_grid_position));  //prevent another actor move to 

      actor_->GetActorData()->AddLogF("[ActorControl][ApplyAutoRangedPosition] target_grid_position:(%f,%f)", target_grid_position.x, target_grid_position.y);
    }
  }


  void ActorControl::UpdateSpecialGuard(int type)
  {
    //check trigger
    ActorTrigger* guard_trigger = actor_->GetActorData()->GetControlData()->GetGuardTriggerAuto();

    if (guard_trigger)
    {
      bool is_pause = guard_trigger->GetIsPause();
      guard_trigger->SetIsPause(false);
      guard_trigger->Update();
      if (guard_trigger->GetIsTriggered())
      {
        switch (type)
        {
        case 0:
        default:
          switch (actor_->GetActorData()->GetBasicData()->GetCareerType())
          {
          case kActorCareerWarrior:
          case kActorCareerKnight:
            {
              Actor* target_actor = *(guard_trigger->GetTriggeredActorList()->begin());
              float distance = target_actor->GetActorData()->GetMotionData()->GetPosition().getDistance(actor_->GetActorData()->GetMotionData()->GetPosition());

              if (distance <= taomee::battle::kMapTileMaxLength * 3)
              {
                int target_id = target_actor->GetActorId();
                //move to target
                actor_->GetActorData()->GetControlData()->SetTarget(target_id, kActorControlPriorityMoveAuto);
                actor_->GetActorData()->AddLogF("[ActorControl][UpdateSpecialGuard] type:%d, target_id:%d", type, target_id);
              }
            }
            break;
          default:
            break;
          }
          break;
        }
      }
      guard_trigger->SetIsPause(is_pause);
    }

  }



  void ActorControl::ApplyControlData(ActorControlDataBase* from_control_data, ActorControlDataBase* to_control_data)
  {
    if (!from_control_data || !to_control_data)
    {
      assert(false);
      return;
    }

    if (from_control_data->IsSet())
    {
      if (from_control_data->IsSetPosition())
      {
        cocos2d::CCPoint set_position = from_control_data->GetPosition();
        eActorControlPriority control_priority = from_control_data->GetPositionPriority();

        //check position
        to_control_data->SetPosition(set_position, control_priority);
        if (to_control_data->GetTargetPriority() <= control_priority)
          to_control_data->ResetTarget(); //clear previous move operation
        //check position
      }

      if (from_control_data->IsSetTarget())
      {
        int set_target = from_control_data->GetTarget();
        eActorControlPriority control_priority = from_control_data->GetTargetPriority();

        //check target
        to_control_data->SetTarget(set_target, control_priority);
        if (to_control_data->GetPositionPriority() <= control_priority)
          to_control_data->ResetPosition(); //clear previous move operation
        //check target
      }

      if (from_control_data->IsSetSkill())
      {
        int set_skill = from_control_data->GetSkill();
        eActorControlPriority control_priority = from_control_data->GetSkillPriority();

        //check skill
        to_control_data->SetSkill(set_skill, control_priority);

        if (control_priority >= kActorControlPriorityAttackSpecialAuto)
        {
          //flush actor logic state, re-enter to overload current skill
          actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));

          actor_->GetActorData()->AddLogF("[ActorControl][ApplyControlData] AttackSpecial re-enter Attack set_skill:%d", set_skill);
        }
        //check skill
      }

      if (from_control_data->IsSetIncontrollable())
      {
        eActorControlIncontrollableType set_incontrollable = from_control_data->GetIncontrollable();
        eActorControlPriority control_priority = from_control_data->GetIncontrollablePriority();

        //check incontrollable
        to_control_data->SetIncontrollable(set_incontrollable, control_priority);
        //check incontrollable
      }

      from_control_data->Reset(); //clear user data
    }
  }



  //decide logic state, this will be checked every update
  eActorLogicState ActorControl::DecideLogicState()
  {
    ActorControlData* control_data = actor_->GetActorData()->GetControlData();

    switch (control_data->GetMaximumControlPriority())
    {
    case kActorControlPriorityMoveAuto:
    case kActorControlPriorityMoveManual:
      //clear control data skill
      actor_->GetActorData()->GetControlData()->ResetSkill();
      return kActorLogicStateMove;
      break;
    case kActorControlPriorityAttackNormalAuto:
    case kActorControlPriorityAttackPowerAuto:
    case kActorControlPriorityAttackNormalManual:
    case kActorControlPriorityAttackSpecialAuto:
    case kActorControlPriorityAttackSpecialManual:
      return kActorLogicStateAttack;
      break;
    case kActorControlPriorityIncontrollable:
      return kActorLogicStateIncontrollable;
      break;
    case kActorControlPriorityMin:
      return kActorLogicState;  //nothing set
      break;
    case kActorControlPriorityMax:
    default:
      assert(false);  //error priority
      break;
    }

    return kActorLogicState;
  }

  bool ActorControl::ControlLogicStateChange(eActorLogicState next_logic_state)
  {
    if (next_logic_state == kActorLogicState)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == kActorLogicStateDead)
      return false;
    if (actor_->GetLogicStateMachine()->GetCurrentLogicStateType() == next_logic_state)
      return false;

    return actor_->GetLogicStateMachine()->CommonCheckOnChange(next_logic_state);
  }


  void ActorControl::SetActorControlRoutine(ActorControlRoutine* actor_control_routine)
  {
    if (actor_control_routine_) 
    {
      actor_control_routine_->Clear();
      delete actor_control_routine_;
    }
    actor_control_routine_ = actor_control_routine;
  }
  ActorControlRoutine* ActorControl::GetActorControlRoutine()
  {
    return actor_control_routine_;
  }
} // namespace actor