#include "actor_logic_state_idle.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateIdle::STATE_TYPE = kActorLogicStateIdle;

  LogicStateIdle* LogicStateIdle::Instance()
  {
    static LogicStateIdle instance;
    return &instance;
  }


  void LogicStateIdle::OnEnter(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateIdle][OnEnter]");

    actor->GetActorData()->GetLogicData()->SetIsStateIdle(true);  //move to update
    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateIdle));
    actor->GetActorData()->GetControlData()->SetCountdown(0);
  }

  void LogicStateIdle::OnExit(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateIdle][OnExit]");
    actor->GetActorData()->GetLogicData()->SetIsStateIdle(false);

    if (actor->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter
      && IsPositionInGrid(actor->GetActorData()->GetMotionData()->GetPosition()))
    {
      ActorSpecifiedDataCharacter* specified_data = dynamic_cast<ActorSpecifiedDataCharacter*>(actor->GetActorData()->GetSpecifiedData());
      specified_data->SetLastIdleGrid(GetGridFromPosition(actor->GetActorData()->GetMotionData()->GetPosition()));
    }
  }

  void LogicStateIdle::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->AddLog("[LogicStateIdle][Update]");
    //check trigger
    if (actor->GetActorData()->GetControlData()->IsSet() == false
      && actor->GetActorData()->GetControlData()->GetCountdown() == 0)
    {
      //reset CD
      actor->GetActorData()->GetControlData()->ResetCountdownGuard();
      
      if (IsPositionInGrid(actor->GetActorData()->GetMotionData()->GetPosition())) //logic only run when actor entered grid
      {
        if (CommonCheckAttackTrigger(actor))
        {
          //goto Attack, commit attack
          actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateAttack));
          return;
        }

        if (CommonCheckGuardTrigger(actor))
        {
          //goto Move, move closer and guard
          actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
          return;
        }

        //check overlap and off grid center
        if (CommonCheckGridPosition(actor))
        {
          actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateMove));
          return;
        }
      }

    }
  }
} // namespace actor