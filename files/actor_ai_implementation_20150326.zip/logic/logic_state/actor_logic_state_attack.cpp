#include "actor_logic_state_attack.h"

#include "game/actor/actor.h"

namespace actor {

  const int LogicStateAttack::STATE_TYPE = kActorLogicStateAttack;

  LogicStateAttack* LogicStateAttack::Instance()
  {
    static LogicStateAttack instance;
    return &instance;
  }

  void LogicStateAttack::OnEnter(Actor* actor)
  {
    actor->GetActorData()->AddLog("[LogicStateAttack][OnEnter]");

    //make sure there is a skill in control data
    //make sure there is a skill in control data
    ActorSkillData* skill_data = actor->GetActorData()->GetSkillData();
    ActorControlData* control_data = actor->GetActorData()->GetControlData();
    
    // not special attack, check if target in normal attack range
    if (control_data->IsSetSkill() == false)
    {
      switch (skill_data->GetNormalAttackTriggeredType())
      {
      case kActorAttackMelee:
        control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackMelee), kActorControlPriorityAttackNormalAuto);
        break;
      case kActorAttackRanged:
        control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackRanged), kActorControlPriorityAttackNormalAuto);
        break;
      case kActorAttackHeal:
        control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackHeal), kActorControlPriorityAttackNormalAuto);
        break;
      case kActorAttack:
      default:
        //no target for normal attack, attack failed, pop back to idle
        actor->GetActorData()->AddLog("[LogicStateAttack][OnEnter] target for normal attack");
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
        break;
      }

      if (skill_data->GetTriggeredAttackTrigger())
      {
        //Upgrade to power skill
        if (/*actor->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter 
          && */skill_data->GetSkillIdByType(kActorAttackPower) > 0
          && (skill_data->GetActorNormalAttackCount() + skill_data->GetActorPowerAttackCount() + skill_data->GetActorSpecialAttackCount()) % 4 == 3 
		      && actor->GetActorData()->GetBuffData()->GetIsAttackPowerLock() == false )
        {
          control_data->SetSkill(skill_data->GetSkillIdByType(kActorAttackPower), kActorControlPriorityAttackPowerAuto);
        }
        //Upgrade to power skill

        
        Actor* target_actor = *skill_data->GetTriggeredAttackTrigger()->GetTriggeredActorList()->begin();
        
        //to adapter, set target
        actor->GetActorData()->GetSkillData()->AddSkillTarget(target_actor->GetActorId());

        //currently set critical
        actor->GetActorData()->GetSkillData()->RandomCrititalHit(target_actor);

      }

    }
    else
    {
      actor->GetActorData()->AddLogF("[LogicStateAttack][OnEnter] target for special attack, skill id:%d", control_data->GetSkill());
    }
    //make sure there is a skill in control data
    //make sure there is a skill in control data

    bool is_skill_valid = true;
    eActorAttackType attack_type = skill_data->GetSkillTypeById(control_data->GetSkill());
    switch(attack_type)
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
      if (actor->GetActorData()->GetBuffData()->GetIsAttackNormalLock())
        is_skill_valid = false;
      break;
    case kActorAttackPower:
      if (actor->GetActorData()->GetBuffData()->GetIsAttackPowerLock())
        is_skill_valid = false;
      break;
    case kActorAttackSpecial:
    case kActorAttackOverload:
      if (actor->GetActorData()->GetBuffData()->GetIsAttackSpecialLock())
        is_skill_valid = false;
      break;
    case kActorAttack:
    default:
      assert(false);
      is_skill_valid = false;
      break;
    }

    //cool down check - this only used to add cool down time between skill, default = 0
    float cool_down = skill_data->GetSkillCooldownByType(attack_type);
    is_skill_valid &= (cool_down <= control_data->GetSkillCountdown());

    if (is_skill_valid == false)
    {
      //clear control data
      control_data->ResetSkill();
      //back to idle
      actor->GetActorData()->AddLog("[LogicStateAttack][OnEnter] is_skill_valid = false");
      actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
      return;
    }

    actor->GetMotionStateMachine()->ChangeState(GetActorMotionState(kActorMotionStateAttack));

    //skill init 
    actor->GetActorData()->AddLogF(
      "[ActorSkillData][CommitSkill] skill_id:%d attack_type:%d", 
      control_data->GetSkill(), 
      skill_data->GetSkillTypeById(control_data->GetSkill()));

    actor->GetActorData()->GetSkillData()->CommitSkill(control_data->GetSkill());
    //skill init 

    //reset move control
    control_data->ResetTarget();
    control_data->ResetPosition();
    //reset move control

  }

  void LogicStateAttack::OnExit(Actor* actor)
  {
    //currently set critical
    actor->GetActorData()->GetSkillData()->ClearCrititalHit();

    actor->GetActorData()->AddLog("[LogicStateAttack][OnExit]");
  }

  void LogicStateAttack::Update(Actor* actor, float delta_time)
  {
    //actor->GetActorData()->AddLog("[LogicStateAttack][Update]");
    //Wait for Skill system and Motion System to finish
    if (actor->GetActorData()->GetSkillData()->GetIsSkillFinished()
      && actor->GetActorData()->GetMotionData()->GetIsMotionAnimationEnded())
    {
      //not matter skill is successful released or countered

      actor->GetActorData()->AddLog("[LogicStateAttack][Update] finished");

      //clear control data
      actor->GetActorData()->GetControlData()->ResetSkill();

      //reset cool down
      actor->GetActorData()->GetControlData()->ResetSkillCountdown();

      //back to idle
      actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateIdle));
    }

  }

} // namespace actor