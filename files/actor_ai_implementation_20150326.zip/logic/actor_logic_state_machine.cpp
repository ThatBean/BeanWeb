#include "actor_logic_state_machine.h"

#include "game/actor/actor.h"

namespace actor {

  eActorLogicState LogicStateMachine::GetCurrentLogicStateType()
  {
    if (current_state_)
    {
      return eActorLogicState(current_state_->GetStateType());
    }
    return kActorLogicState;
  }


  void LogicStateMachine::Update(float delta_time)
  { 
    CommonCheckOnUpdate();

    if (current_state_) 
      current_state_->Update(entity_, delta_time); 
  }

  void LogicStateMachine::ChangeState(State<Actor>* next_state)
  {
    Actor* actor = entity_;
    if (next_state && CommonCheckOnChange(next_state))
    {
      actor->GetActorData()->AddLogF(
        "[LogicStateMachine][ChangeState] %d -> %d", 
        current_state_ ? current_state_->GetStateType() : -1, 
        next_state ? next_state->GetStateType() : -1);

      last_state_ = current_state_;
      if (last_state_) 
        last_state_->OnExit(entity_);

      current_state_ = next_state;
      if (current_state_) 
        current_state_->OnEnter(entity_);
    }
    else
    {
      actor->GetActorData()->AddLogF(
        "[LogicStateMachine][ChangeState][BLOCKED] %d -> %d", 
        current_state_ ? current_state_->GetStateType() : -1, 
        next_state ? next_state->GetStateType() : -1);
    }
  }


  //{ALWAYS RUN} 
  //When Logic State Update Check
  void LogicStateMachine::CommonCheckOnUpdate()
  {
    //     {ALWAYS RUN} Actor Status Caused State Change Check
    //       [if] Actor Die
    //       [if] Actor Born
    //       [if] Actor Incontrollable

    Actor* actor = entity_;
    if (actor->GetActorData()->GetBasicData()->GetIsDeadStatus())
    {
      if (current_state_->GetStateType() != kActorLogicStateDead)
        actor->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateDead));
    }
  }

  //When Logic State Change Check
  //return true if can change
  bool LogicStateMachine::CommonCheckOnChange(State<Actor>* next_state)
  {
    //     {ALWAYS RUN} Active State Change Check
    //       [if] Mute move
    //       [if] Mute attack
    //       ? [if] Mute defend ?
    // 
    //     {ALWAYS RUN} Passive State Change Check
    //     [if] Immune attacked
    //     {CHOOSE ONE TO RUN} Condition Check
    //     Affected
    //     [if] Cancelled  (Instant - Abandon Current State)
    //     Ignored
    eActorLogicState next_state_type = eActorLogicState(next_state->GetStateType());
    return CommonCheckOnChange(next_state_type);
  }

  bool LogicStateMachine::CommonCheckOnChange(eActorLogicState next_state_type)
  {
    Actor* actor = entity_;
    ActorLogicData* logic_data = actor->GetActorData()->GetLogicData();

    switch (next_state_type)
    {
    case kActorLogicStateMove:
      if (logic_data->GetIsMoveLock())
      {
        actor->GetActorData()->GetControlData()->ResetPosition();
        actor->GetActorData()->GetControlData()->ResetTarget();
        return false;
      }
      break;
    case kActorLogicStateAttack:
      if (logic_data->GetIsAttackLock())
      {
        actor->GetActorData()->GetControlData()->ResetSkill();
        return false;
      }
      break;
    default:
      break;
    }

    return true;
  }

} // namespace actor