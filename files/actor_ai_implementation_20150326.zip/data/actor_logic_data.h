#ifndef ACTOR_LOGIC_DATA_H
#define ACTOR_LOGIC_DATA_H

namespace actor {

  class Actor;
  class ActorTrigger;
  
  
  class ActorLogicData
  {
  public:
    ActorLogicData();
    ~ActorLogicData();
    
    void Init();


    void SetIsStateIdle(bool is_state_idle) { is_state_idle_ = is_state_idle; }
    bool GetIsStateIdle() { return is_state_idle_; }

    void SetIsMoveLock(bool is_move_lock) { is_move_lock_ = is_move_lock; }
    bool GetIsMoveLock() { return is_move_lock_; }
    
    void SetIsAttackLock(bool is_attack_lock) { is_attack_lock_ = is_attack_lock; }
    bool GetIsAttackLock() { return is_attack_lock_; }

  private:
    bool is_state_idle_;

    bool is_move_lock_;
    bool is_attack_lock_;
  };
} // namespace actor


#endif // ACTOR_LOGIC_DATA_H