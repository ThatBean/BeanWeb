#include "actor_data.h"

#include "game/actor/actor.h"
#include "game/battle/damage/damage_constants.h"

namespace actor {

  const unsigned long ACTOR_BUFF_FLAG_MOVE_AUTO = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_MOVE_LOCK = 0
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | taomee::battle::kDamageIntertwine
    | 0;


  const unsigned long ACTOR_BUFF_FLAG_ATTACK_LOCK = 0
    | taomee::battle::kDamageRepel
    | taomee::battle::kDamageEnchantment
    | taomee::battle::kDamageFear
    | taomee::battle::kDamageWitchcraft
    | taomee::battle::kDamageStunned
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | taomee::battle::kDamageIntertwine
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_NORMAL_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageBlinded
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_POWER_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageBlinded
	| taomee::battle::kDamageSilence
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_ATTACK_SPECIAL_LOCK = 0
    | ACTOR_BUFF_FLAG_ATTACK_LOCK
    | taomee::battle::kDamageSilence
    | 0;


  const unsigned long ACTOR_BUFF_FLAG_ANIMATION_LOCK = 0
    | taomee::battle::kDamageFreeze
    | taomee::battle::kDamagePetrifaction
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_COLORED = 0
    | taomee::battle::kDamageFireProperty
    | taomee::battle::kDamageFireProperty
    | 0;

  const unsigned long ACTOR_BUFF_FLAG_INCONTROLLABLE = 0
    | ACTOR_BUFF_FLAG_MOVE_AUTO 
    | ACTOR_BUFF_FLAG_MOVE_LOCK
    | 0;



  ActorBuffData::ActorBuffData()
    : is_buff_finished_(true),
    is_incontrollable_finished_(true)
  {

  }

  ActorBuffData::~ActorBuffData()
  {
  }

  void ActorBuffData::UpdateIncontrollable()
  {
    bool is_incontrollable = ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_INCONTROLLABLE) != 0);

    SetIsIncontrollableFinished(is_incontrollable == false);
  }


  bool ActorBuffData::GetIsMoveLock()
  {
    return ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_MOVE_LOCK) != 0);
  }
  bool ActorBuffData::GetIsMoveAuto()

  {
    return ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_MOVE_AUTO) != 0);
  }
  bool ActorBuffData::GetIsAttackLock()
  {
    return ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_ATTACK_LOCK) != 0);
  }
  bool ActorBuffData::GetIsAttackNormalLock()
  {
    return ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_ATTACK_NORMAL_LOCK) != 0);
  }
  bool ActorBuffData::GetIsAttackPowerLock()
  {
    return ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_ATTACK_POWER_LOCK) != 0);
  }
  bool ActorBuffData::GetIsAttackSpecialLock()
  {
    return ((GetActorBuffFlag() & ACTOR_BUFF_FLAG_ATTACK_SPECIAL_LOCK) != 0);
  }

  //currently in adapter
  uint_32 ActorBuffData::GetActorBuffFlag() 
  { 
    return actor_adapter_->battle_status_flag(); 
  }

} // namespace actor