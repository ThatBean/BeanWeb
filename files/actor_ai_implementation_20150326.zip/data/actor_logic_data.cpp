#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorLogicdata
  ActorLogicData::ActorLogicData()
    :is_state_idle_(true),
    is_move_lock_(false),
    is_attack_lock_(false)
  {
    Init();
  }

  ActorLogicData::~ActorLogicData()
  {
  }

  void ActorLogicData::Init()
  {
  }


  //ActorLogicdata

} // namespace actor