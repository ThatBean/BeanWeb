#ifndef ACTOR_SPECIFIED_DATA_H
#define ACTOR_SPECIFIED_DATA_H

#include "cocos2d.h"

#include "actor_motion_data.h"

namespace actor {

  class Actor;
  
  
  const int GRID_Y_RANGE = 3;
  const int GRID_Y_RANGE_TOP = 1;
  const int GRID_Y_RANGE_BOTTOM = GRID_Y_RANGE_TOP + (GRID_Y_RANGE - 1);

  const int GRID_X_RANGE = 6;
  const int GRID_X_RANGE_LEFT = 1;
  const int GRID_X_RANGE_RIGHT = GRID_X_RANGE_LEFT + (GRID_X_RANGE - 1);

  const int IDLE_VALID_GRID_X_RANGE = 5;
  const int IDLE_VALID_GRID_X_HOME_RANGE_LEFT = GRID_X_RANGE_LEFT + (IDLE_VALID_GRID_X_RANGE - 1);
  const int IDLE_VALID_GRID_X_HOME_RANGE_RIGHT = GRID_X_RANGE_RIGHT - (IDLE_VALID_GRID_X_RANGE - 1);

  enum eActorSpecifiedGridPreferenceType
  {
    kActorSpecifiedGridPreferNear,
    kActorSpecifiedGridPreferNearX,
    kActorSpecifiedGridPreferNearY,
    kActorSpecifiedGridPrefer
  };


  class ActorSpecifiedData  //a data class for each type of actor 
  {
  public:
    ActorSpecifiedData(Actor* actor)
      :actor_(actor),
      actor_home_direction_(kActorAnimationDirection)
    {
    }

    virtual void Update(float delta_time) = 0;

    virtual bool IsPositionValid(cocos2d::CCPoint position);
    virtual bool IsGridValid(cocos2d::CCPoint grid_position);
    virtual bool IsGridIdleValid(cocos2d::CCPoint grid_position);

    virtual cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position);

    void SetActorHomeDirection(eActorAnimationDirection direction) { actor_home_direction_ = direction; }
    eActorAnimationDirection GetActorHomeDirection() { return actor_home_direction_; }
  
    std::list<cocos2d::CCPoint>* GetValidGridList(std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list);  //need delete after use 
    
    cocos2d::CCPoint GetValidGrid(
      cocos2d::CCPoint preferred_grid_position, 
      std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list, 
      eActorSpecifiedGridPreferenceType prefer_type = kActorSpecifiedGridPreferNear);

  protected:
    Actor* actor_;

  private:
    eActorAnimationDirection   actor_home_direction_;
  };

  //######################################################################################################
  //######################################################################################################
  //used in character logic control flow
  
  class ActorSpecifiedDataCharacter : public ActorSpecifiedData
  {
  public:
    ActorSpecifiedDataCharacter(Actor* actor);

    virtual void Update(float delta_time) {}
    virtual bool IsPositionValid(cocos2d::CCPoint position);
    virtual bool IsGridValid(cocos2d::CCPoint grid_position);

    virtual cocos2d::CCPoint PositionCorrection(cocos2d::CCPoint position);

    void SetIsLimitGridX(bool is_limit) { is_limit_grid_x_ = is_limit; }

    void SetLastIdleGrid(cocos2d::CCPoint grid_position);
    cocos2d::CCPoint GetLastIdleGrid() { return last_idle_grid_position_; }

    cocos2d::CCPoint GetValidGrid();  //for idle grid decision
  private:
    bool is_limit_grid_x_;

    cocos2d::CCPoint last_idle_grid_position_;
  };




  //######################################################################################################
  //######################################################################################################

  class ActorSpecifiedDataEnemyPawn : public ActorSpecifiedData
  {
  public:
    ActorSpecifiedDataEnemyPawn(Actor* actor);

    virtual void Update(float delta_time) {}
    virtual bool IsPositionValid(cocos2d::CCPoint position);
  };




  //######################################################################################################
  //######################################################################################################


  class ActorSpecifiedDataEnemyBoss : public ActorSpecifiedData
  {
  public:
    ActorSpecifiedDataEnemyBoss(Actor* actor);

    virtual void Update(float delta_time) {}
    virtual bool IsPositionValid(cocos2d::CCPoint position);
  };

} // namespace actor


#endif // ACTOR_SPECIFIED_DATA_H