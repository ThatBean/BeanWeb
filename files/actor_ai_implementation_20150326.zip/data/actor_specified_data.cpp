#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  bool ActorSpecifiedData::IsPositionValid(cocos2d::CCPoint position)
  {
    return IsPositionInGrid(position);
  }

  bool ActorSpecifiedData::IsGridValid(cocos2d::CCPoint grid_position)
  {
    return grid_position.x >= GRID_X_RANGE_LEFT
      && grid_position.x <= GRID_X_RANGE_RIGHT
      && grid_position.y >= GRID_Y_RANGE_TOP
      && grid_position.y <= GRID_Y_RANGE_BOTTOM;
  }


  cocos2d::CCPoint ActorSpecifiedData::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
      return SnapToGrid(position);
    else
      return SnapYToGrid(position);
  }

  bool ActorSpecifiedData::IsGridIdleValid(cocos2d::CCPoint grid_position) 
  { 
    if (IsGridValid(grid_position))
    {
      switch (GetActorHomeDirection())
      {
      case kActorAnimationDirectionLeft:
        return grid_position.x <= IDLE_VALID_GRID_X_HOME_RANGE_LEFT;
        break;
      case  kActorAnimationDirectionRight:
        return grid_position.x >= IDLE_VALID_GRID_X_HOME_RANGE_RIGHT;
        break;
      default:
        assert(false);
        return true;
        break;
      }
    }
    return false;
  }


  std::list<cocos2d::CCPoint>* ActorSpecifiedData::GetValidGridList(std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list)  //need delete after use
  {
    std::list<cocos2d::CCPoint>* valid_grid_list = new std::list<cocos2d::CCPoint>;
    int grid_position_taken[GRID_X_RANGE][GRID_Y_RANGE] = {0};

    std::list< std::pair<Actor*, cocos2d::CCPoint> >::iterator iterator = actor_grid_list->begin();
    while (iterator != actor_grid_list->end())
    {
      Actor* ref_actor = iterator->first;

      if (ref_actor != actor_
        && ref_actor->GetActorData()->GetSpecifiedData()->GetActorHomeDirection() == GetActorHomeDirection())
      {
        cocos2d::CCPoint ref_grid_position = iterator->second;
        grid_position_taken[(int)(ref_grid_position.x - 1)][(int)(ref_grid_position.y - 1)] += 1;
      }

      ++iterator;
    }

    //search valid grid
    int i, j;
    int start_grid_x = (GetActorHomeDirection() == kActorAnimationDirectionLeft) ? 1 : IDLE_VALID_GRID_X_HOME_RANGE_RIGHT;
    for (i = start_grid_x; i < start_grid_x + IDLE_VALID_GRID_X_RANGE; i++)
    {
      for (j = GRID_Y_RANGE_TOP; j <= GRID_Y_RANGE_BOTTOM; j++)
      {
        cocos2d::CCPoint grid_position = ccp(i, j);
        if (grid_position_taken[i - 1][j - 1] == 0 && IsGridIdleValid(grid_position))
        {
          valid_grid_list->push_back(grid_position);
        }
      }
    }

    return valid_grid_list;
  }

  cocos2d::CCPoint ActorSpecifiedData::GetValidGrid(
    cocos2d::CCPoint preferred_grid_position, 
    std::list< std::pair<Actor*, cocos2d::CCPoint> >* actor_grid_list, 
    eActorSpecifiedGridPreferenceType prefer_type)
  {
    std::list<cocos2d::CCPoint>* valid_grid_list = GetValidGridList(actor_grid_list);
    
    bool is_backup_grid_position_valid = false;
    cocos2d::CCPoint backup_grid_position;
    float nearest_valid_grid_distance = 99999;

    if (valid_grid_list->size() > 0)
    {
      std::list<cocos2d::CCPoint>::iterator iterator = valid_grid_list->begin();
      while (iterator != valid_grid_list->end())
      {
        cocos2d::CCPoint grid_position = *iterator;

        if (IsGridIdleValid(grid_position))
        {
          float distance = preferred_grid_position.getDistance(grid_position);

          if (distance == 0)
          {
            backup_grid_position = preferred_grid_position;
            is_backup_grid_position_valid = true;
            break;  //stop searching
          }

          bool is_keep = false;

          switch (prefer_type)
          {
          case kActorSpecifiedGridPreferNear:
            is_keep = nearest_valid_grid_distance > distance;
            break;
          case kActorSpecifiedGridPreferNearX:
            if (abs(backup_grid_position.x - preferred_grid_position.x) < abs(grid_position.x - preferred_grid_position.x))
            {
              if (abs(backup_grid_position.x - preferred_grid_position.x) == abs(grid_position.x - preferred_grid_position.x))
                is_keep = nearest_valid_grid_distance > distance;
              else
                is_keep = true;
            }
            break;
          case kActorSpecifiedGridPreferNearY:
            if (abs(backup_grid_position.y - preferred_grid_position.y) < abs(grid_position.y - preferred_grid_position.y))
            {
              if (abs(backup_grid_position.y - preferred_grid_position.y) == abs(grid_position.y - preferred_grid_position.y))
                is_keep = nearest_valid_grid_distance > distance;
              else
                is_keep = true;
            }
            break;
          }

          if (is_keep)
          {
            nearest_valid_grid_distance = distance;
            backup_grid_position = grid_position;
          }
          is_backup_grid_position_valid = true;
        }

        ++iterator;
      }
    }

    delete valid_grid_list;

    if (is_backup_grid_position_valid)
    {
      actor_grid_list->push_back(std::pair<Actor*, cocos2d::CCPoint>(actor_, backup_grid_position));  //prevent another actor move to 
      return backup_grid_position;
    }

    //so sad the lame makeshift position
    return ccp(GetActorHomeDirection() == kActorAnimationDirectionLeft ? 2 : 5, 2);
  }

  //ActorSpecifiedDataCharacter================================================================
  ActorSpecifiedDataCharacter::ActorSpecifiedDataCharacter(Actor* actor)
    :ActorSpecifiedData(actor),
    is_limit_grid_x_(false)
  {
  }

  bool ActorSpecifiedDataCharacter::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
    {
      //return is_limit_grid_x_ ? GetGridXFromPositionX(position.x) != 1 : true;
      cocos2d::CCPoint grid_position = GetGridFromPosition(position);
      if (is_limit_grid_x_ && ((int)(grid_position.x) == 1))
      {
        return (position.x > GetPositionFromGrid(grid_position).x + 10);
      }
      else
        return true;
    }
    else
      return false;
  }

  bool ActorSpecifiedDataCharacter::IsGridValid(cocos2d::CCPoint grid_position)
  {
    bool is_valid = ActorSpecifiedData::IsGridValid(grid_position);
    if (is_valid)
      return is_limit_grid_x_ ? grid_position.x > 1 : true;
    else
      return false;
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::PositionCorrection(cocos2d::CCPoint position)
  {
    if (IsPositionInGrid(position))
    {
      if (IsPositionValid(position))
        return SnapToGrid(position);
      else
      {
        cocos2d::CCPoint grid_position = GetGridFromPosition(position);

        if (is_limit_grid_x_ && ((int)(grid_position.x) == 1))
          grid_position.x = 2;
        
        return GetPositionFromGrid(grid_position);
      }
    }
    else
      return SnapYToGrid(position);
  }

  void ActorSpecifiedDataCharacter::SetLastIdleGrid(cocos2d::CCPoint grid_position) 
  { 
    if (IsGridIdleValid(grid_position))
      last_idle_grid_position_ = grid_position; 
  }

  cocos2d::CCPoint ActorSpecifiedDataCharacter::GetValidGrid()
  {
    if (IsGridIdleValid(last_idle_grid_position_) == false)
    {
      last_idle_grid_position_ = ccp(GetActorHomeDirection() == kActorAnimationDirectionLeft ? 2 : 5, 2);
    }

    return ActorSpecifiedData::GetValidGrid(
      last_idle_grid_position_, 
      actor_->GetActorExtEnv()->GetActorGridList(), 
      kActorSpecifiedGridPreferNear);
  }

  //ActorSpecifiedDataCharacter================================================================

  //ActorSpecifiedDataEnemyPawn================================================================
  ActorSpecifiedDataEnemyPawn::ActorSpecifiedDataEnemyPawn(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyPawn::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
      return true;
    else
    {
      return IsPositionYInGrid(position.y);
    }
  }
  //ActorSpecifiedDataEnemyPawn================================================================

  //ActorSpecifiedDataEnemyBoss================================================================
  ActorSpecifiedDataEnemyBoss::ActorSpecifiedDataEnemyBoss(Actor* actor)
    :ActorSpecifiedData(actor)
  {
  }

  bool ActorSpecifiedDataEnemyBoss::IsPositionValid(cocos2d::CCPoint position)
  {
    bool is_in_grid = IsPositionInGrid(position);
    if (is_in_grid)
      return true;
    else
    {
      return IsPositionYInGrid(position.y);
    }
  }
  //ActorSpecifiedDataEnemyBoss================================================================
} // namespace actor