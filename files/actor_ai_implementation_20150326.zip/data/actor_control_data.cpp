#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {

  //ActorControlDataBase
  ActorControlDataBase::ActorControlDataBase()
  {
    Reset();
  }

  ActorControlDataBase::~ActorControlDataBase()
  {
  }

  void ActorControlDataBase::Reset()
  {
    is_set_position_ = false;
    is_set_skill_ = false;
    is_set_target_ = false;
    is_set_incontrollable_ = false;

    control_priority_position_ = kActorControlPriorityMin;
    control_priority_skill_ = kActorControlPriorityMin;
    control_priority_target_ = kActorControlPriorityMin;
    control_priority_incontrollable_ = kActorControlPriorityMin;

    countdown_ = 0;
    skill_countdown_ = 0;
  }

  void ActorControlDataBase::Update(float delta_time)
  {
    UpdateCountdown(delta_time);
    UpdateSkillCountdown(delta_time);
  }


  eActorControlPriority ActorControlDataBase::GetMaximumControlPriority()
  {
    eActorControlPriority maximum_control_priority = kActorControlPriorityMin;

    if (is_set_position_) maximum_control_priority = max(maximum_control_priority, control_priority_position_);
    if (is_set_skill_) maximum_control_priority = max(maximum_control_priority, control_priority_skill_);
    if (is_set_target_) maximum_control_priority = max(maximum_control_priority, control_priority_target_);
    if (is_set_incontrollable_) maximum_control_priority = max(maximum_control_priority, control_priority_incontrollable_);

    return maximum_control_priority;
  }

  void ActorControlDataBase::SetPosition(const cocos2d::CCPoint& position, eActorControlPriority control_priority)
  {
    if (is_set_position_ && control_priority_position_ > control_priority)
      return; //only preserve same or higher priority
    position_ = position;
    control_priority_position_ = control_priority;
    is_set_position_ = true;
  }

  void ActorControlDataBase::SetTarget(int target_id, eActorControlPriority control_priority)
  {
    if (is_set_target_ && control_priority_target_ > control_priority)
      return; //only preserve same or higher priority
    target_id_ = target_id;
    control_priority_target_ = control_priority;
    is_set_target_ = true;
  }

  void ActorControlDataBase::SetSkill(int skill_id, eActorControlPriority control_priority)
  {
    if (is_set_skill_ && control_priority_skill_ > control_priority)
      return; //only preserve same or higher priority
    skill_id_ = skill_id;
    control_priority_skill_ = control_priority;
    is_set_skill_ = true;
  }

  void ActorControlDataBase::SetIncontrollable(eActorControlIncontrollableType incontrollable_type, eActorControlPriority control_priority)
  {
    if (is_set_incontrollable_ && control_priority_incontrollable_ > control_priority)
      return; //only preserve same or higher priority
    incontrollable_type_ = incontrollable_type;
    control_priority_incontrollable_ = control_priority;
    is_set_incontrollable_ = true;
  }


  cocos2d::CCPoint ActorControlDataBase::GetPosition()
  {
    assert(is_set_position_ == true);
    return position_;
  }


  int ActorControlDataBase::GetSkill()
  {
    if (is_set_skill_)
      return (skill_id_);
    else
      return ACTOR_SKILL_ID_INVALID;
  }

  int ActorControlDataBase::GetTarget()
  {
    if (is_set_target_)
      return (target_id_);
    else
      return ACTOR_ID_INVALID;
  }

  eActorControlIncontrollableType ActorControlDataBase::GetIncontrollable()
  {
    if (is_set_incontrollable_)
      return (incontrollable_type_);
    else
      return kActorControlIncontrollable;
  }


  void ActorControlDataBase::ResetPosition() 
  { 
    is_set_position_ = false; 
    control_priority_position_ = kActorControlPriorityMin; 
  }

  void ActorControlDataBase::ResetSkill() 
  { 
    is_set_skill_ = false; 
    control_priority_skill_ = kActorControlPriorityMin; 
  }

  void ActorControlDataBase::ResetTarget() 
  { 
    is_set_target_ = false; 
    control_priority_target_ = kActorControlPriorityMin; 
  }

  void ActorControlDataBase::ResetIncontrollable() 
  { 
    is_set_incontrollable_ = false; 
    control_priority_incontrollable_ = kActorControlPriorityMin; 
  }


  bool ActorControlDataBase::IsSet()
  {
    return (is_set_position_ 
      || is_set_skill_ 
      || is_set_target_
      || is_set_incontrollable_);
  }
  //ActorControlDataBase





  //ActorControlData
  ActorControlData::ActorControlData()
    :attack_trigger_auto_(NULL),
    guard_trigger_auto_(NULL),
    auto_guard_type_(kActorControlAutoGuard),
    auto_release_skill_(kActorControlAutoReleaseSkill),
    is_auto_attack_(false),
    is_auto_guard_(false),
    is_auto_release_skill_(false),
    auto_release_skill_probability_(0),
    auto_release_skill_attack_count_(-1)
  {
    Reset();
  }

  ActorControlData::~ActorControlData()
  {
    if (attack_trigger_auto_) delete attack_trigger_auto_;
    if (guard_trigger_auto_) delete guard_trigger_auto_;
  }

  void ActorControlData::Update(float delta_time)
  {
    UpdateCountdown(delta_time);
    UpdateSkillCountdown(delta_time);
  }

  //ActorControlData

} // namespace actor