#ifndef ACTOR_BASIC_DATA_H
#define ACTOR_BASIC_DATA_H

#include "game/actor/actor_adapter.h"

namespace actor {

  class Actor;


  enum eActorType
  {
    kActorCharacter,
    kActorEnemyPawn,
    kActorEnemyBoss,
    kActor
  };
  
  enum eActorFactionType
  {
    kActorFactionUserSupport,    //where user are
    kActorFactionUserOppose,   //who attacks user
    kActorFactionNeutral, //usually for some special actor that doesn't attack, or attack both
    kActorFaction
  };
  
  enum eActorCareerType
  {
    kActorCareerWarrior,
    kActorCareerKnight,
    kActorCareerPriest,
    kActorCareerWizard,
    kActorCareerArcher,
    kActorCareerBoss,
    kActorCareer
  };

  class ActorBasicData
  {
  public:
    ActorBasicData()
      :actor_create_timestamp_(0),
      actor_active_time_(0)
    {

    }

    void  Update(float delta_time);

    void                 SetActorType(eActorType set_type) { actor_type_ = set_type; }
    eActorType           GetActorType() { return actor_type_; }

    void                 SetFactionType(eActorFactionType set_type) { actor_faction_ = set_type; }
    eActorFactionType    GetFactionType() { return actor_faction_; }
    
    void                 SetCareerType(eActorCareerType set_type) { actor_career_type_ = set_type; }
    eActorCareerType     GetCareerType() { return actor_career_type_; }

    void                 SetCreateTime(uint_32 timestamp) { actor_create_timestamp_ = timestamp; }
    uint_32              GetCreateTime() { return actor_create_timestamp_; }

    void                 SetActiveTime(float active_time) { actor_active_time_ = active_time; }
    void                 UpdateActiveTime(float delta_time) { actor_active_time_ += delta_time; }
    float                GetActiveTime() { return actor_active_time_; }

    bool                 GetIsWeakStatus();
    bool                 GetIsDeadStatus();


    //currently in adapter
    int       GetActorLevel();

    void      SetCurrentHealth(int current_health);
    int       GetCurrentHealth();

    void      SetTotalHealth(int max_health);
    int       GetTotalHealth();

    void      ActorDeadCleanUp();

    //messy but messy, link MoveObject data
    void      SetActorAdapter(ActorAdapter* actor_adapter) { actor_adapter_ = actor_adapter; }
  private:
    eActorType           actor_type_;
    eActorFactionType    actor_faction_;
    eActorCareerType     actor_career_type_;

    uint_32              actor_create_timestamp_;  //a time 
    float                actor_active_time_;   //another version of time maintained by update


  private:
    //Notice:
    // please [use getter&setter] to extract data from MoveObject
    ActorAdapter*        actor_adapter_; //messy but messy, hide MoveObject interface, bridge the data
  };


} // namespace actor


#endif // ACTOR_BASIC_DATA_H