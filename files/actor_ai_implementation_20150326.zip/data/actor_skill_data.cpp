#include "actor_data.h"

#include "game/actor/actor.h"

namespace actor {
  ActorSkillData::ActorSkillData()
  {
    Reset();
  }

  ActorSkillData::~ActorSkillData()
  {
    if (guard_trigger_) delete guard_trigger_;

    if (attack_trigger_melee_) delete attack_trigger_melee_;
    if (attack_trigger_heal_) delete attack_trigger_heal_;
    if (attack_trigger_ranged_) delete attack_trigger_ranged_;

    if (attack_trigger_power_) delete attack_trigger_power_;
    if (attack_trigger_special_) delete attack_trigger_special_;
  }

  void ActorSkillData::Reset()
  {
    actor_normal_attack_count_ = 0;
    actor_power_attack_count_ = 0;
    actor_special_attack_count_ = 0;

    actor_skill_id_melee_ = ACTOR_SKILL_ID_INVALID;
    actor_skill_id_ranged_ = ACTOR_SKILL_ID_INVALID;
    actor_skill_id_heal_ = ACTOR_SKILL_ID_INVALID;
    actor_skill_id_power_ = ACTOR_SKILL_ID_INVALID;
    actor_skill_id_special_ = ACTOR_SKILL_ID_INVALID;

    guard_type_ = kActorGuard;
    guard_trigger_ = NULL;

    attack_trigger_melee_ = NULL;
    attack_trigger_heal_ = NULL;
    attack_trigger_ranged_ = NULL;
    attack_trigger_power_ = NULL;
    attack_trigger_special_ = NULL;

    is_skill_pause_ = false;
  }

  void ActorSkillData::SetSkillIdByType(eActorAttackType attack_type, int skill_id)
  {
    if (skill_id >= 0)
    {
      assert((skill_id == actor_skill_id_melee_ && attack_type != kActorAttackMelee) == false);
      assert((skill_id == actor_skill_id_ranged_ && attack_type != kActorAttackRanged) == false);
      assert((skill_id == actor_skill_id_heal_ && attack_type != kActorAttackHeal) == false);
      assert((skill_id == actor_skill_id_power_ && attack_type != kActorAttackPower) == false);
      assert((skill_id == actor_skill_id_special_ && attack_type != kActorAttackSpecial) == false);
      
      bool is_error = false;

      if (skill_id == actor_skill_id_melee_ && attack_type != kActorAttackMelee) is_error = true;
      if (skill_id == actor_skill_id_ranged_ && attack_type != kActorAttackRanged) is_error = true;
      if (skill_id == actor_skill_id_heal_ && attack_type != kActorAttackHeal) is_error = true;
      if (skill_id == actor_skill_id_power_ && attack_type != kActorAttackPower) is_error = true;
      if (skill_id == actor_skill_id_special_ && attack_type != kActorAttackSpecial) is_error = true;

      if (is_error)
        return;
    }

    switch (attack_type)
    {
    case kActorAttackMelee:
      actor_skill_id_melee_ = skill_id;
      break;
    case kActorAttackRanged:
      actor_skill_id_ranged_ = skill_id;
      break;
    case kActorAttackHeal:
      actor_skill_id_heal_ = skill_id;
      break;
    case kActorAttackPower:
      actor_skill_id_power_ = skill_id;
      break;
    case kActorAttackSpecial:
      actor_skill_id_special_ = skill_id;
      break;
    case kActorAttack:
    default:
      assert(false);
      break;
    }
  }


  int ActorSkillData::GetSkillIdByType(eActorAttackType attack_type)
  {
    switch (attack_type)
    {
    case kActorAttackMelee:
      return actor_skill_id_melee_;
      break;
    case kActorAttackRanged:
      return actor_skill_id_ranged_;
      break;
    case kActorAttackHeal:
      return actor_skill_id_heal_;
      break;
    case kActorAttackPower:
      return actor_skill_id_power_;
      break;
    case kActorAttackSpecial:
      return actor_skill_id_special_;
      break;
    case kActorAttack:
    default:
      return ACTOR_SKILL_ID_INVALID;
      break;
    }
  }

  eActorAttackType ActorSkillData::GetSkillTypeById(int skill_id)
  {
    if (skill_id == ACTOR_SKILL_ID_INVALID) return kActorAttack;

    if (skill_id == actor_skill_id_melee_) return kActorAttackMelee;
    if (skill_id == actor_skill_id_ranged_) return kActorAttackRanged;
    if (skill_id == actor_skill_id_heal_) return kActorAttackHeal;

    if (skill_id == actor_skill_id_power_) return kActorAttackPower;
    if (skill_id == actor_skill_id_special_) return kActorAttackSpecial;

    return kActorAttackOverload;
  }


  void ActorSkillData::UpdateNormalAttackTrigger()
  {
    if (attack_trigger_melee_) attack_trigger_melee_->Update();
    if (attack_trigger_ranged_) attack_trigger_ranged_->Update();
    if (attack_trigger_heal_) attack_trigger_heal_->Update();
  }

  bool ActorSkillData::GetNormalAttackIsTriggered()
  {
    bool is_triggered = false;
    if(attack_trigger_melee_) is_triggered |= attack_trigger_melee_->GetIsTriggered();
    if(attack_trigger_ranged_) is_triggered |= attack_trigger_ranged_->GetIsTriggered();
    if(attack_trigger_heal_) is_triggered |= attack_trigger_heal_->GetIsTriggered();
    return is_triggered;
  }

  eActorAttackType ActorSkillData::GetNormalAttackTriggeredType()
  {
    if (attack_trigger_melee_)
    {
      if (attack_trigger_melee_->GetIsTriggered())
        return kActorAttackMelee;
    }

    if (attack_trigger_ranged_)
    {
      if (attack_trigger_ranged_->GetIsTriggered())
        return kActorAttackRanged;
    }

    if (attack_trigger_heal_)
    {
      if (attack_trigger_heal_->GetIsTriggered())
        return kActorAttackHeal;
    }

    return kActorAttack;
  }

  ActorTrigger* ActorSkillData::GetTriggeredAttackTrigger()
  {
    if (attack_trigger_special_)
    {
      if (attack_trigger_special_->GetIsTriggered())
        return attack_trigger_special_;
    }

    if (attack_trigger_power_)
    {
      if (attack_trigger_power_->GetIsTriggered())
        return attack_trigger_power_;
    }

    if (attack_trigger_melee_)
    {
      if (attack_trigger_melee_->GetIsTriggered())
        return attack_trigger_melee_;
    }

    if (attack_trigger_ranged_)
    {
      if (attack_trigger_ranged_->GetIsTriggered())
        return attack_trigger_ranged_;
    }

    if (attack_trigger_heal_)
    {
      if (attack_trigger_heal_->GetIsTriggered())
        return attack_trigger_heal_;
    }

    return NULL;
  }
   
  void ActorSkillData::ResetSkill()
  {
    ResetSkillAdapter(actor_adapter_);
  }

  void ActorSkillData::AddSkillTarget(int target_id)
  {
    AddSkillTargetAdapter(actor_adapter_, target_id);
  }

  void ActorSkillData::CommitSkill(int skill_id)
  {
    if (skill_id <= 0) return;
     
    eActorAttackType attack_type = GetSkillTypeById(skill_id);
    switch (attack_type)
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
      actor_normal_attack_count_++;
      break;
    case kActorAttackPower:
      actor_power_attack_count_++;
      break;
    case kActorAttackSpecial:
    case kActorAttackOverload:
      actor_special_attack_count_++;
      if (GetIsSkillFinished() == false) 
        ResetSkill();
      break;
    default:
      assert(false);
      break;
    }

    //if (GetIsSkillFinished() == false) 
      //assert(false);
    //ResetSkill();

    CommitSkillAdapter(actor_adapter_, skill_id, attack_type);
  }

  bool ActorSkillData::GetIsSkillFinished() 
  { 
    is_skill_finished_ = GetIsSkillFinishedAdapter(actor_adapter_);
    return is_skill_finished_; 
  }


  bool ActorSkillData::GetIsSpecialSkillReady()
  {
    return actor::GetIsSpecialSkillReady(actor_adapter_);
  }

  float ActorSkillData::GetSkillCooldownByType(eActorAttackType attack_type)
  {
    switch (attack_type)
    {
    case kActorAttackMelee:
    case kActorAttackRanged:
    case kActorAttackHeal:
    case kActorAttackPower:
      return actor::GetSkillCooldown(actor_adapter_);
    default:
      return 0;
    }
    
  }


  void ActorSkillData::RandomCrititalHit(Actor* target_actor)
  {
    actor::RandomCrititalHit(actor_adapter_, target_actor);
  }

  void ActorSkillData::ClearCrititalHit()
  {
    actor::ClearCrititalHit(actor_adapter_);
  }


  void ActorSkillData::SetSkillPause(bool is_pause)
  {
    if (is_skill_pause_ != is_pause)
    {
      if (is_pause)
        PauseSkillAdapter(actor_adapter_);
      else
        ResumeSkillAdapter(actor_adapter_);

      is_skill_pause_ = is_pause;
    }
  }

  //ActorSkillData

} // namespace actor