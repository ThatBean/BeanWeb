#ifndef ACTOR_STATE_H
#define ACTOR_STATE_H

namespace actor {

  template <class t_entity>
  class State
  {
  public:
    State() {}
    virtual ~State() {}

    //static const int     STATE_TYPE;
    virtual int          GetStateType() = 0;

    virtual void OnEnter(t_entity* entity) = 0;
    virtual void OnExit(t_entity* entity) = 0;
    virtual void Update(t_entity* entity, float delta_time) = 0;
  };

} // namespace actor


#endif // ACTOR_STATE_H
