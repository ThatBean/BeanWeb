#ifndef ACTOR_SCRIPT_EXPORTER_H
#define ACTOR_SCRIPT_EXPORTER_H

#include "cocos2d.h"

namespace actor {

  class Actor;
  class ActorControlDataBase;

  class ActorScriptExporter  //a data class mostly for link to lua actor auto control -- "routine"
  {
  public:
    ActorScriptExporter(Actor* actor);
    ~ActorScriptExporter();

    //export to lua for data
  public:
    static cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y);
    static cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position);
    static int GetGridXFromPositionX(float position_x);
    static int GetGridYFromPositionY(float position_y);

    static void ScriptAssert(bool expression, const std::string& message);

    //for debug
    static ActorScriptExporter* GetActorScriptExporterById(int actor_id); 
    
    //danger...
    static void SimulateTouchAt(float x, float y); 
    //touch_event_id = 0, 1, 2, 3; safer to use CCTOUCHBEGAN etc
    static void SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id); 
    //this will get a modified static touch set in c++
    static cocos2d::CCSet* GetTouchSet(float x, float y);

    //tester
    static bool TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node);

  public: //actor_based
    float GetActorHealthPercent();  //
    cocos2d::CCPoint GetActorPosition();
    ActorControlDataBase* GetActorRoutineControlData();

    void SetActorIsAutoGuard(bool is_auto);
    void UpdateSpecialGuard(int type);
    
    void ShowActorLog(int max_line);
    void ActorScriptAssert(bool expression, const std::string& message);  //target actor linked, neat
    //export to lua for data

  private:
    Actor* actor_;  //keep actor pointer
  };

} // namespace actor


#endif // ACTOR_SCRIPT_EXPORTER_H