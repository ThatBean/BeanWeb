#ifndef ACTOR_EXT_ENV_H
#define ACTOR_EXT_ENV_H

#include "cocos2d.h"
#include "engine/base/basictypes.h"

namespace actor {

  class Actor;
  class ActorExtUserOperation;
  class ActorScriptExporter;


  const int ACTOR_ID_INVALID = -1;


  // the map / battlefield where actors live in (Actor Pool)
  class ActorExtEnv  //ActorExternalEnvironment
  {
  public:
    ActorExtEnv();
    ~ActorExtEnv();

    void      Clear();
    void      Update(float delta_time);

    int       AddActor(Actor* actor); //will return actor_id
    void      AddActor(int actor_id, Actor* actor); //alternative, predefined actor_id

    Actor*    RemoveActor(int actor_id);

    Actor*    GetActorById(int actor_id);
    
    int                       GetActorCount();
    std::list<Actor*>*        GetActorList();  //should delete after use, alive and in grid actor only, mostly used in trigger raw actor list
    std::list<Actor*>*        GetAllActorList();  //should delete after use, alive or dead

    std::map<int, Actor*>*    GetActorMap() { return &actor_map_; }
    std::list<int>*           GetActorIdList() { return &actor_id_list_; }
    
    //std::map<int, Actor*>*    GetActorListByType(specific_actor_type actor_type);
    //std::list<int>*           GetActorIdListByType(specific_actor_type actor_type);


    //for touch
    ActorExtUserOperation*  GetUserOperation() { return actor_ext_user_operation_; }

    //for debug
    ActorScriptExporter*    GetActorScriptExporterById(int actor_id); 

  public:
    //should move ? should move
    //position/animation related
    Actor*    GetActorByPosition(cocos2d::CCPoint target_position);
    Actor*    GetActorByGrid(cocos2d::CCPoint target_grid_position);
    std::list<Actor*>*    GetActorListByGrid(cocos2d::CCPoint target_grid_position);
    std::list<Actor*>*    GetActorListByPosition(cocos2d::CCPoint target_position);
    //position/animation related

    //for actor grid need, update every Update()
    void UpdateActorGridList();
    std::list< std::pair<Actor*, cocos2d::CCPoint> >* GetActorGridList() { return &actor_grid_list_; }
    bool CheckActorGridOverlap(Actor* actor);
    bool CheckActorGridOverlap(Actor* actor, cocos2d::CCPoint grid_position);


    //for skill pause need
    void AddActorFocusById(int actor_id);
    void ClearActorFocus() { actor_focus_map_.clear(); }
    void PauseActorByFocus();
    void ClearActorPause();

    void SetIsPause(bool is_pause);
    void SetPauseActorByFaction(int actor_faction, bool is_pause);

    //for skill counter attack
    void SkillAttackedNotification(int from_actor_id, int to_actor_id, int skill_id, int health_change);

    //should move ? should move

  private:
    std::map<int, Actor*>     actor_map_;
    std::list<int>            actor_id_list_;
    int                       actor_next_valid_id_;

    ActorExtUserOperation*    actor_ext_user_operation_;

    //for actor grid need, update every Update()
    std::list< std::pair<Actor*, cocos2d::CCPoint> >     actor_grid_list_;

    //for skill pause need
    std::map<int, Actor*>     actor_focus_map_;
    bool                      is_pause_;
  };

} // namespace actor


#endif // ACTOR_EXT_ENV_H