#include "actor_adapter.h"

#include "actor.h"
#include "game/actor/trigger/actor_trigger_predefined.h"

#include "game/army/unit/monster.h"
#include "game/army/unit/character.h"

#include "game/battle/battle_controller.h"
#include "game/battle/level/levelbase.h"
#include "game/user_interface/battle_ui/battle_ui_controller.h"
#include "game/user_interface/battle_ui/battle_ui_constants.h"

#include "game/artificial_intelligence/intent_state/ai_state_machine.h"
#include "game/artificial_intelligence/ai_config.h"

#include "game/ago_skill/control/ASkillControl.h"

#include "engine/base/random_helper.h"

namespace actor
{
  //used only in this file
  //don't want tile index in actor system, used only:
  //  PositionCorrection (Primary)
  //  position (Secondary)
  //  grid x/y (Remedy, should be enough)
  //below only used for tile_index to grid_x/y
  const int tile_index_to_grid_x_list[18] = {
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6,
    1,  2,  3,      4,  5,  6
  };
  const int tile_index_to_grid_y_list[18] = {
    1,  1,  1,      1,  1,  1,
    2,  2,  2,      2,  2,  2,
    3,  3,  3,      3,  3,  3
  };

  int GetGridXFromTileIndex(int tile_index)
  {
    return tile_index_to_grid_x_list[tile_index];
  }
  int GetGridYFromTileIndex(int tile_index)
  {
    return tile_index_to_grid_y_list[tile_index];
  }

  //used only in this file





  //     <The Battle field>		  // grid_x  1   2   3      4   5   6   | grid_y
  //         ---------------------------|
  //         0   1   2      3   4   5   |      1
  //         6   7   8      9   10  11  |      2
  //         12  13  14     15  16  17  |      3
  //         tile index                 |
  const int grid_to_tile_index_list[18] = {
    0,  1,  2,      3,  4,  5,
    6,  7,  8,      9,  10, 11,
    12, 13, 14,     15, 16, 17
  };


  cocos2d::CCPoint GetPositionFromGrid(int grid_x, int grid_y)
  {
    int index = (grid_x - 1) + (grid_y - 1) * 6;
    assert(0 <= index && 17 >= index);
    int_8 target_tile_idx = grid_to_tile_index_list[index];
    assert(target_tile_idx != taomee::battle::kUnexistTileIndex);
    return taomee::battle::GetGarrisonPointForMoveObjectInTile(target_tile_idx);
  }

  cocos2d::CCPoint GetPositionFromGrid(cocos2d::CCPoint grid_position)
  {
    return GetPositionFromGrid(grid_position.x, grid_position.y);
  }


  cocos2d::CCPoint GetGridFromPosition(cocos2d::CCPoint position)
  {
    int_8 tile_index = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    assert(0 <= tile_index && 17 >= tile_index);
    return ccp(tile_index_to_grid_x_list[tile_index], tile_index_to_grid_y_list[tile_index]);
  }

  int GetGridXFromPositionX(float position_x)
  {
    int_8 tile_index = taomee::battle::GetTileIndexByCurrentPointPosition(ccp(position_x, taomee::battle::GetMidYInTile()));
    assert(0 <= tile_index && 17 >= tile_index);
    return tile_index_to_grid_x_list[tile_index];
  }
  int GetGridYFromPositionY(float position_y)
  {
    int_8 tile_index = taomee::battle::GetTileIndexByCurrentPointPosition(ccp(taomee::battle::GetMidXInTile(), position_y));
    assert(0 <= tile_index && 17 >= tile_index);
    return tile_index_to_grid_y_list[tile_index];
  }

  bool IsPositionInGrid(cocos2d::CCPoint position)
  {
    int_8 tile_index = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    if (tile_index <= taomee::battle::kUnexistTileIndex 
      || tile_index >= taomee::battle::kBorderRightFailedTileIndex)
      tile_index = taomee::battle::kUnexistTileIndex;
    return tile_index != taomee::battle::kUnexistTileIndex;
  }

  bool IsPositionXInGrid(int position_x)
  {
    return (position_x >= (taomee::battle::GetMinXInTile()) //this is how actor gird position is calculated...
      && position_x <= (taomee::battle::GetMaxXInTile()));
  }

  bool IsPositionYInGrid(int position_y)
  {
    return (position_y >= (taomee::battle::GetMinYInTile()) //this is how actor gird position is calculated...
      && position_y <= (taomee::battle::GetMaxYInTile()));
  }

  cocos2d::CCPoint SnapToGrid(cocos2d::CCPoint position)
  {
    int_8 tile_index = taomee::battle::GetTileIndexByCurrentPointPosition(position);
    assert(tile_index != taomee::battle::kUnexistTileIndex);
    return taomee::battle::GetGarrisonPointForMoveObjectInTile(tile_index);
  }

  cocos2d::CCPoint SnapYToGrid(cocos2d::CCPoint position)
  {
    position.y = min(position.y, taomee::battle::GetMaxYInTile());//this is how actor gird position is calculated...
    position.y = max(position.y, taomee::battle::GetMinYInTile());
    return position;
  }


  void ResetSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->removeAllActorSkill();
  }

  void AddSkillTargetAdapter(ActorAdapter* actor_adapter, int target_id)
  {
    actor_adapter->target_selection()->set_target_id(target_id);
  }

  void CommitSkillAdapter(ActorAdapter* actor_adapter, int skill_id, int attack_type)
  {
    int skill_release_type = -1;

    switch (eActorAttackType(attack_type))
    {
    case kActorAttackMelee:
      skill_release_type = kSkillNormalHitNear;
      break;
    case kActorAttackRanged:
    case kActorAttackHeal:
      skill_release_type = kSkillNormalHitFar;
      break;
    case kActorAttackPower:
      skill_release_type = kSkillSkill_Little;
      break;
    case kActorAttackSpecial:
      skill_release_type = kSkillSkill;
      break;
    }

    //actor_adapter_->set_selected_skill_id(skill_id);
    actor_adapter->getSkillControl()->playSkillByID(skill_id, skill_release_type);
  }
  
  void PauseSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->pauseAllSkill();
  }

  void ResumeSkillAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->getSkillControl()->resumeAllSkill();
  }

  bool GetIsSkillFinishedAdapter(ActorAdapter* actor_adapter)
  {
    return (actor_adapter->getSkillControl()->getSkillMotionState() == taomee::ai::kMotionResultCompelted)
      || (actor_adapter->getSkillControl()->getSkillMotionState() == taomee::ai::kMotionResultInvalid);
  }


  bool GetIsSpecialSkillReady(ActorAdapter* actor_adapter)
  {
//     if (GetIsActorExtEnvArena())
//     {
//       return actor_adapter->energy_value() >= taomee::ui::getKMaxAngry();
//     }
//     else
//     {
      return taomee::battle::BattleController::GetInstance().CanSkillBeReseaseOrNot(actor_adapter->move_object_id());
//     }
  }

  float GetSkillCooldown(ActorAdapter* actor_adapter)
  {
    return actor_adapter->attack_speed();
  }

  void AutoReleaseSpecialSkill(int actor_id)
  {
    taomee::battle::BattleController::GetInstance().battle_ui()->SkillReleaseButtonSelected(actor_id);
  }
  
  void RandomCrititalHit(ActorAdapter* actor_adapter, Actor* target_actor)
  {
    // fighter crit
    float rand_value = taomee::random_0_1();
    float unit_critical = actor_adapter->critical_probability(target_actor->GetActorData()->GetBasicData()->GetActorLevel());
    if ( (rand_value < unit_critical) ) 
    {
      actor_adapter->set_critical_hit(true);
    }    
  }

  void ClearCrititalHit(ActorAdapter* actor_adapter)
  {
    actor_adapter->set_critical_hit(false);
  }


  bool GetIsAllyActorAuto()
  {
    return (taomee::ai::AIConfig::GetInstance().GetIsAutoFight() || GetIsActorExtEnvArena());
  }

//   bool GetIsActorExtEnvMain()
//   {
//     return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_Main;
//   }

  bool GetIsActorExtEnvBabel()
  {
    return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_LongMarch;  //same thing
  }
  bool GetIsActorExtEnvArena()
  {
    return taomee::battle::BattleController::GetInstance().getBattleType() == taomee::battle::kBattleType_Pvp;
  }

  ActorExtEnv* GetActorExtEnv()
  {
    return taomee::battle::BattleController::GetInstance().GetActorExtEnv();
  }


  void NastyActorDeadCleanUpAdapter(ActorAdapter* actor_adapter)
  {
    actor_adapter->set_is_active(false);
    actor_adapter->set_ai_state(taomee::ai::KAIStateDead);
    taomee::ai::AIStateMachine::GetInstance().MotionMachine()->ChangeMotion(actor_adapter, taomee::ai::kMotionStateDead);
    actor_adapter->set_current_animation_state(taomee::ai::kMotionResultCompelted);
    //later will be checked in troops hub Update
//     if(!unit->is_active() && unit->motion_state() == ai::kMotionStateDead &&
//       unit->current_animation_state() == ai::kMotionResultCompelted)
  }

  void NastyActorInitAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    Actor* actor_ = actor;
    CharacterData* character_card_data_ = actor_adapter->character_card_data();

    //first reset data(skill and specified)
    actor_->GetActorData()->ResetData();

    //set data
    actor_->GetActorData()->GetBasicData()->SetFactionType(actor_adapter->IsPlayer() ? kActorFactionUserSupport : kActorFactionUserOppose);
    
    if (character_card_data_->GetIsEnemy())
    {
      if (character_card_data_->GetMonsterLevel() > 0)
        actor_->GetActorData()->GetBasicData()->SetActorType(kActorEnemyBoss);
      else
        actor_->GetActorData()->GetBasicData()->SetActorType(kActorEnemyPawn);
    }
    else
      actor_->GetActorData()->GetBasicData()->SetActorType(kActorCharacter);

    switch (taomee::army::eCareerType(character_card_data_->GetJobType()))
    {
    case taomee::army::kCareerTypeWarrior:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerWarrior);
      break;
    case taomee::army::kCareerTypeArcher:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerArcher);
      break;
    case taomee::army::kCareerTypeWizard:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerWizard);
      break;
    case taomee::army::kCareerTypeMonk:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerPriest);
      break;
    case taomee::army::kCareerTypeKnight:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareerKnight);
      break;
    default:
      actor_->GetActorData()->GetBasicData()->SetCareerType(kActorCareer);
      break;
    }

    actor_->GetActorData()->GetMotionData()->SetDefaultAnimationDirection(actor_adapter->IsPlayer() ? kActorAnimationDirectionLeft : kActorAnimationDirectionRight);

    //specified
    actor_->GetActorData()->GetSpecifiedData()->SetActorHomeDirection(actor_adapter->IsPlayer() ? kActorAnimationDirectionRight : kActorAnimationDirectionLeft);

    if (actor_->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter)
    {
      ActorSpecifiedDataCharacter* specified_data = dynamic_cast<ActorSpecifiedDataCharacter*>(actor_->GetActorData()->GetSpecifiedData());
      
      if (actor_->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserSupport
        && GetIsActorExtEnvArena() == false
        && GetIsActorExtEnvBabel() == false)
      {
        specified_data->SetIsLimitGridX(true);
      }
    }

    //control
    actor_->GetControl()->SetControlType(actor_adapter->IsPlayer() ? kActorControlSemiAuto : kActorControlAuto);
    
  }



  void NastyActorInitRoutineDataAdapter(ActorAdapter* actor_adapter, Actor* actor)
  {
    Actor* actor_ = actor;
    CharacterData* character_card_data = actor_adapter->character_card_data();

    if (character_card_data->GetMoveType() != 8)
    { 
      switch ( actor_->GetActorData()->GetBasicData()->GetCareerType())
      {
      case kActorCareerWarrior:
      case kActorCareerKnight:
        if (actor_->GetActorData()->GetBasicData()->GetActorType() == kActorEnemyBoss)
        {
          actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackMelee, character_card_data->GetSkillId(kSkillNormalHitNear));

          actor_->GetActorData()->GetSkillData()->SetGuardType(kActorGuardMelee);
          actor_->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerMeleeRect, actor_));

          actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttackMelee);
          actor_->GetActorData()->GetSkillData()->SetAttackTriggerMelee(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerMeleeRect, actor_));
          actor_->GetActorData()->GetControlData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerMelee, actor_));
        }
        else
        {
          actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackMelee, character_card_data->GetSkillId(kSkillNormalHitNear));

          actor_->GetActorData()->GetSkillData()->SetGuardType(kActorGuardMelee);
          actor_->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerMelee, actor_));

          actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttackMelee);
          actor_->GetActorData()->GetSkillData()->SetAttackTriggerMelee(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerMelee, actor_));
          actor_->GetActorData()->GetControlData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerMelee, actor_));
        }
        break;
      case kActorCareerPriest:
        if (actor_->GetActorData()->GetBasicData()->GetActorType() != kActorCharacter)
        {
          //special adapter for the True & Real Enemy Priest(Character Priest is a Wizard, lame)
          actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackHeal, character_card_data->GetSkillId(kSkillNormalHitFar));
          actor_->GetActorData()->GetSkillData()->SetGuardTrigger(NULL);

          actor_->GetActorData()->GetSkillData()->SetGuardType(kActorGuard);

          actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttackHeal);
          actor_->GetActorData()->GetSkillData()->SetAttackTriggerHeal(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerHeal, actor_));
          actor_->GetActorData()->GetControlData()->SetGuardTriggerAuto(NULL);
          break;
        }
      case kActorCareerArcher:
      case kActorCareerWizard:
        actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackRanged, character_card_data->GetSkillId(kSkillNormalHitFar));

        actor_->GetActorData()->GetSkillData()->SetGuardType(kActorGuard);
        actor_->GetActorData()->GetSkillData()->SetGuardTrigger(GetPredefinedGuardTrigger(kActorPredefinedGuardTriggerRanged, actor_));

        actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttackRanged);
        actor_->GetActorData()->GetSkillData()->SetAttackTriggerRanged(GetPredefinedAttackTrigger(kActorPredefinedAttackTriggerRanged, actor_));
        actor_->GetActorData()->GetControlData()->SetGuardTriggerAuto(GetPredefinedGuardTriggerAuto(kActorPredefinedGuardTriggerRanged, actor_));
        break;
      default:
        actor_->GetActorData()->GetSkillData()->SetAttackType(kActorAttack);
        assert(false);
        break;
      }
      if (actor_->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserSupport
        && actor_->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter)
      {
        taomee::army::Character* actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);
        assert(actor_adapter_character);

        if (character_card_data->GetSkillId(kSkillSkill_Little) > 0 
          && actor_adapter_character->getSkillLevel(character_card_data->GetSkillId(kSkillSkill_Little)) > 0)
          actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackPower, character_card_data->GetSkillId(kSkillSkill_Little));

//         if (character_card_data_->GetSkillId(kSkillSkill) > 0 
//           && actor_adapter_character->getSkillLevel(character_card_data_->GetSkillId(kSkillSkill)) > 0)
//           actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackSpecial, character_card_data_->GetSkillId(kSkillSkill));

        if (character_card_data->GetSkillId(kSkillSkill) > 0)
        {
          if (actor_adapter_character->getSkillLevel(character_card_data->GetSkillId(kSkillSkill)) <= 0)
          {
            printf("[ERROR] Special Skill Level in character info is invalid \n");
            printf("[ERROR] -- actor_id: %d \n", actor_->GetActorId());
            printf("[ERROR] -- actor_card_id: %d \n", character_card_data->GetCid());
            printf("[ERROR] -- actor_skill_id: %d \n", character_card_data->GetSkillId(kSkillSkill));
            printf("[ERROR] -- Special Skill Level: %d \n", actor_adapter_character->getSkillLevel(character_card_data->GetSkillId(kSkillSkill)));
            printf("[ERROR] This Assert can be safely ignored \n");
            
            //assert(false);
          }
        }
        actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackSpecial, character_card_data->GetSkillId(kSkillSkill));
      }
      else
      {
        actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackPower, character_card_data->GetSkillId(kSkillSkill_Little));
        actor_->GetActorData()->GetSkillData()->SetSkillIdByType(kActorAttackSpecial, character_card_data->GetSkillId(kSkillSkill));
      }


      //monster not auto guard by default
      if (actor_->GetActorData()->GetBasicData()->GetActorType() != kActorCharacter
        && actor_->GetActorData()->GetControlData()->GetGuardTriggerAuto())
      {
        actor_->GetActorData()->GetControlData()->GetGuardTriggerAuto()->SetIsPause(true);
      }
    }





    ActorControlRoutine* actor_control_routine = new ActorControlRoutine(actor_);
    actor_->GetControl()->SetActorControlRoutine(actor_control_routine);

    actor_control_routine->AddRoutineData(std::string("actor_type"), (int)(actor->GetActorData()->GetBasicData()->GetActorType()));
    actor_control_routine->AddRoutineData(std::string("fraction_type"), (int)(actor->GetActorData()->GetBasicData()->GetFactionType()));

    if (character_card_data->GetIsEnemy())
    {
      if (character_card_data->GetMoveType() != 8)
      {
        actor_control_routine->AddRoutineData(std::string("ROUTINE_NAME"), std::string("routine_config_enemy_pawn"));

        taomee::army::Monster* actor_adapter_monster = dynamic_cast<taomee::army::Monster*>(actor_adapter);
        if (actor_adapter_monster)
        {
          int born_grid_x = actor_adapter->stage_stay_column() + 1;
          int born_grid_y = -1;
          actor_control_routine->AddRoutineData(std::string("born_grid_x"), born_grid_x);
          actor_control_routine->AddRoutineData(std::string("born_grid_y"), born_grid_y);
        }
      }
      else
      {
        actor_control_routine->AddRoutineData(std::string("ROUTINE_NAME"), std::string("routine_config_enemy_blind"));
      }
    }
    else
    {
      actor_control_routine->AddRoutineData(std::string("ROUTINE_NAME"), std::string("routine_config_character"));

      taomee::army::Character* actor_adapter_character = dynamic_cast<taomee::army::Character*>(actor_adapter);
      if (actor_adapter_character)
      {
        int born_tile_index = actor_adapter_character->garrison_tile_index();

        int born_grid_x = GetGridXFromTileIndex(born_tile_index);
        int born_grid_y = GetGridYFromTileIndex(born_tile_index);
        actor_control_routine->AddRoutineData(std::string("born_grid_x"), born_grid_x);
        actor_control_routine->AddRoutineData(std::string("born_grid_y"), born_grid_y);
      }
    }
    //activate
    actor_control_routine->LoadRoutine();






    //first reset direction
    actor_->GetActorData()->GetMotionData()->ResetAnimationDirection();

    //initial logic state
    actor_->GetLogicStateMachine()->ChangeState(GetActorLogicState(kActorLogicStateBorn));





    //init control auto guard
    if ((GetIsActorExtEnvBabel() == true && actor_adapter->IsPlayer() == false) || (GetIsActorExtEnvArena() == true))
    {
      actor_->GetActorData()->GetControlData()->SetAutoGuardType(kActorControlAutoGuardPreferY);
      if (
        actor_->GetActorData()->GetSkillData()->GetGuardTrigger()
        && (
          actor_->GetActorData()->GetBasicData()->GetCareerType() == kActorCareerWarrior
          || actor_->GetActorData()->GetBasicData()->GetCareerType() == kActorCareerKnight
        ))
      {
        delete actor_->GetActorData()->GetSkillData()->GetGuardTrigger();
        actor_->GetActorData()->GetSkillData()->SetGuardTrigger(NULL);
      }
    }
    else
      actor_->GetActorData()->GetControlData()->SetAutoGuardType(kActorControlAutoGuardDefault);
    //auto guard will be enabled in actor routine control





    //init control auto release skill
    if (actor_->GetActorData()->GetBasicData()->GetActorType() == kActorCharacter)
    {
      if (actor_->GetActorData()->GetBasicData()->GetFactionType() == kActorFactionUserSupport || GetIsActorExtEnvBabel() == true || GetIsActorExtEnvArena() == true)
        actor_->GetActorData()->GetControlData()->SetAutoReleaseSkillType(kActorControlAutoReleaseSkillWithPause);
      else
        actor_->GetActorData()->GetControlData()->SetAutoReleaseSkillType(kActorControlAutoReleaseSkillNoPause);
      
      actor_->GetActorData()->GetControlData()->SetIsAutoReleaseSkill(true);
    }
    else
    {
      if (actor_->GetActorData()->GetBasicData()->GetActorType() == kActorEnemyPawn
        && character_card_data->GetSkillId(kSkillSkill) > 0
        && character_card_data->GetSkillRate() > 0)
      {
        actor_->GetActorData()->GetControlData()->SetAutoReleaseSkillType(kActorControlAutoReleaseSkillByAttackCount);
        actor_->GetActorData()->GetControlData()->SetAutoReleaseSkillAttackCount(character_card_data->GetSkillRate());

        //actor_->GetActorData()->GetControlData()->SetAutoReleaseSkillType(kActorControlAutoReleaseSkillWithProbability);
        //actor_->GetActorData()->GetControlData()->SetAutoReleaseSkillProbability(character_card_data->GetSkillRate() * 0.01f);

        actor_->GetActorData()->GetControlData()->SetIsAutoReleaseSkill(true);
      }
    }





    //Activate
    actor_->SetIsActorActive(true);
  }
}