#include "actor_script_exporter.h"

#include "game/actor/actor.h"

#include "engine/script/lua_tinker_manager.h"

namespace actor {
  ActorScriptExporter::ActorScriptExporter(Actor* actor)
    :actor_(actor)
  {

  }

  ActorScriptExporter::~ActorScriptExporter()
  {

  }

  //export to lua // common static
  
  cocos2d::CCPoint ActorScriptExporter::GetPositionFromGrid(int grid_x, int grid_y)
  {
    return actor::GetPositionFromGrid(grid_x, grid_y);
  }
  cocos2d::CCPoint ActorScriptExporter::GetGridFromPosition(cocos2d::CCPoint position)
  {
    return actor::GetGridFromPosition(position);
  }
  int ActorScriptExporter::GetGridXFromPositionX(float position_x)
  {
    return actor::GetGridXFromPositionX(position_x);
  }
  int ActorScriptExporter::GetGridYFromPositionY(float position_y)
  {
    return actor::GetGridYFromPositionY(position_y);
  }


  void ActorScriptExporter::ScriptAssert(bool expression, const std::string& message)
  {
    assert(expression);
    printf("[ActorScriptExporter][Assert] %s\n", message.c_str());
  }


  //for debug
  ActorScriptExporter* ActorScriptExporter::GetActorScriptExporterById(int actor_id)
  {
    ActorExtEnv* actor_ext_env = GetActorExtEnv();

    return actor_ext_env->GetActorScriptExporterById(actor_id);
  }


  void ActorScriptExporter::SimulateTouchAt(float x, float y)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);
    cocos2d::CCSet* touch_set = new cocos2d::CCSet;
    touch_set->addObject(touch);

    printf("[ActorScriptExporter][SimulateTouchAt] x:%f, y:%f\n", x, y);

    SimulateTouch(touch_set, CCTOUCHBEGAN);
    SimulateTouch(touch_set, CCTOUCHENDED);

    //delete touch;
    delete touch_set;
#endif
  }


  void ActorScriptExporter::SimulateTouch(cocos2d::CCSet* touch_set, unsigned int touch_event_id)
  {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
    switch (touch_event_id)
    {
    case CCTOUCHBEGAN:
    case CCTOUCHMOVED:
    case CCTOUCHENDED:
    case CCTOUCHCANCELLED:
      CCDirector::sharedDirector()->getTouchDispatcher()->touches(touch_set, NULL, touch_event_id);
      break;
    default:
      assert(false);
      //touch_event_id error
      break;
    }
#endif
  }

  static CCSet* _touch_set = NULL;
  cocos2d::CCSet* ActorScriptExporter::GetTouchSet(float x, float y)
  {
    cocos2d::CCTouch* touch = new cocos2d::CCTouch;
    touch->setTouchInfo(123456, x, y);

    //cocos2d::CCSet* touch_set = new cocos2d::CCSet;
    //touch_set->addObject(touch);
    //return touch_set;

    if (_touch_set) delete _touch_set;
    _touch_set = new cocos2d::CCSet;
    _touch_set->addObject(touch);
    return _touch_set;
  }

  const static char* __DefaultSkeletonFilePath = "textures/skeleton/";
  bool ActorScriptExporter::TestArmatureAnimation(const std::string& animation_name, cocos2d::CCNode* upper_node)
  {
    std::string skeleton_config = __DefaultSkeletonFilePath + animation_name + ".xml";
    std::string skeleton_plist = __DefaultSkeletonFilePath + animation_name + ".plist";
    std::string skeleton_texture = __DefaultSkeletonFilePath + animation_name + ".pvr.ccz";

    CCArmatureDataManager::sharedArmatureDataManager()->addArmatureFileInfo(
      skeleton_texture.c_str(),
      skeleton_plist.c_str(),
      skeleton_config.c_str());
    CCArmature* armature = CCArmature::create(animation_name.c_str());
    upper_node->addChild(armature);
    armature->getAnimation()->play("bsj", 0, -1, 0);

    return true;
  }




  //export to lua // actor based

  float ActorScriptExporter::GetActorHealthPercent()
  {
    assert(actor_);
    return actor_->GetActorData()->GetBasicData()->GetCurrentHealth() * 100.0f / actor_->GetActorData()->GetBasicData()->GetTotalHealth();
  }

  cocos2d::CCPoint ActorScriptExporter::GetActorPosition()
  {
    assert(actor_);
    return actor_->GetActorData()->GetMotionData()->GetPosition();
  }



  void ActorScriptExporter::SetActorIsAutoGuard(bool is_auto)
  {
    assert(actor_);
    actor_->GetActorData()->GetControlData()->SetIsAutoGuard(is_auto);
  }

  void ActorScriptExporter::UpdateSpecialGuard(int type)
  {
    assert(actor_);
    actor_->GetControl()->UpdateSpecialGuard(type);
  }

  ActorControlDataBase* ActorScriptExporter::GetActorRoutineControlData()
  {
    assert(actor_);
    return actor_->GetControl()->GetActorControlRoutine()->GetRoutineControlData();
  }

  void ActorScriptExporter::ShowActorLog(int max_line)
  {
    assert(actor_);
    actor_->GetActorData()->ShowLog(max_line);
  }

  void ActorScriptExporter::ActorScriptAssert(bool expression, const std::string& message)
  {
    assert(actor_);
    ScriptAssert(expression, message);
  }
} // namespace actor